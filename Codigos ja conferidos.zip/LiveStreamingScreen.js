// LiveStreamingScreen.js
// Componente para streaming ao vivo e videoconferência no KingChat

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  StyleSheet,
  Platform,
  Alert,
  FlatList,
  Modal
} from 'react-native';
import { RTCPeerConnection, RTCView, mediaDevices } from 'react-native-webrtc';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { createConference, joinConference, endConference, getParticipants } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const LiveStreamingScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { user } = useAuth();
  const { conferenceId, isHost = false, groupId } = route.params || {};
  
  const [localStream, setLocalStream] = useState(null);
  const [remoteStreams, setRemoteStreams] = useState({});
  const [participants, setParticipants] = useState([]);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isSettingsVisible, setIsSettingsVisible] = useState(false);
  const [conferenceStatus, setConferenceStatus] = useState(conferenceId ? 'joined' : 'creating');
  
  const peerConnections = useRef({});
  const socketRef = useRef(null);
  
  // Inicializar WebRTC e socket connection
  useEffect(() => {
    const setupMediaDevices = async () => {
      try {
        const constraints = {
          audio: true,
          video: {
            facingMode: 'user',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        };
        
        const stream = await mediaDevices.getUserMedia(constraints);
        setLocalStream(stream);
        
        if (conferenceId) {
          joinExistingConference(conferenceId);
        } else if (isHost) {
          createNewConference();
        }
      } catch (error) {
        console.error('Erro ao acessar câmera e microfone:', error);
        Alert.alert(
          'Erro na Transmissão',
          'Não foi possível acessar sua câmera e microfone. Verifique as permissões do aplicativo.'
        );
        navigation.goBack();
      }
    };
    
    setupMediaDevices();
    
    // Limpar ao desmontar
    return () => {
      cleanupConference();
    };
  }, []);
  
  const createNewConference = async () => {
    try {
      setConferenceStatus('creating');
      const { id, socketUrl } = await createConference({
        hostId: user.id,
        groupId: groupId,
        title: `Conferência de ${user.name}`
      });
      
      setConferenceStatus('created');
      initializeSocket(socketUrl, id);
    } catch (error) {
      console.error('Erro ao criar conferência:', error);
      Alert.alert('Erro', 'Não foi possível criar a conferência');
      navigation.goBack();
    }
  };
  
  const joinExistingConference = async (id) => {
    try {
      setConferenceStatus('joining');
      const { socketUrl } = await joinConference(id);
      setConferenceStatus('joined');
      loadParticipants(id);
      initializeSocket(socketUrl, id);
    } catch (error) {
      console.error('Erro ao entrar na conferência:', error);
      Alert.alert('Erro', 'Não foi possível entrar na conferência');
      navigation.goBack();
    }
  };
  
  const loadParticipants = async (confId) => {
    try {
      const participantsList = await getParticipants(confId || conferenceId);
      setParticipants(participantsList);
    } catch (error) {
      console.error('Erro ao carregar participantes:', error);
    }
  };
  
  const initializeSocket = (url, id) => {
    const socket = new WebSocket(url);
    
    socket.onopen = () => {
      socket.send(JSON.stringify({
        type: 'join',
        userId: user.id,
        conferenceId: id,
        userName: user.name
      }));
    };
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleSocketMessage(data);
    };
    
    socket.onerror = (error) => {
      console.error('Erro no WebSocket:', error);
      Alert.alert('Erro de Conexão', 'Houve um problema na conexão da videoconferência');
    };
    
    socketRef.current = socket;
  };
  
  const handleSocketMessage = (data) => {
    switch (data.type) {
      case 'new-participant':
        createPeerConnection(data.userId, data.userName);
        break;
      case 'participant-left':
        removePeerConnection(data.userId);
        break;
      case 'offer':
        handleOffer(data);
        break;
      case 'answer':
        handleAnswer(data);
        break;
      case 'ice-candidate':
        handleIceCandidate(data);
        break;
      case 'participant-list':
        setParticipants(data.participants);
        break;
      case 'mute-all':
        if (!isHost && data.exceptHost) {
          muteAudio();
        }
        break;
      case 'end-conference':
        Alert.alert('Conferência Encerrada', 'O anfitrião encerrou a conferência');
        cleanupConference();
        navigation.goBack();
        break;
    }
  };
  
  const createPeerConnection = (userId, userName) => {
    const configuration = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    };
    
    const peerConnection = new RTCPeerConnection(configuration);
    
    // Adicionar tracks locais para transmissão
    if (localStream) {
      localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
      });
    }
    
    // Manipular ICE candidates
    peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current.send(JSON.stringify({
          type: 'ice-candidate',
          candidate: event.candidate,
          userId: user.id,
          targetUserId: userId
        }));
      }
    };
    
    // Receber stream remoto
    peerConnection.ontrack = (event) => {
      setRemoteStreams(prev => ({
        ...prev,
        [userId]: { stream: event.streams[0], userName }
      }));
    };
    
    // Criar oferta se formos o iniciador
    if (isHost || (!isHost && user.id < userId)) {
      peerConnection.createOffer()
        .then(offer => peerConnection.setLocalDescription(offer))
        .then(() => {
          socketRef.current.send(JSON.stringify({
            type: 'offer',
            offer: peerConnection.localDescription,
            userId: user.id,
            targetUserId: userId
          }));
        })
        .catch(error => console.error('Erro ao criar oferta:', error));
    }
    
    peerConnections.current[userId] = peerConnection;
    return peerConnection;
  };
  
  const handleOffer = async (data) => {
    const { offer, userId, userName } = data;
    
    let pc = peerConnections.current[userId];
    if (!pc) {
      pc = createPeerConnection(userId, userName);
    }
    
    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    
    socketRef.current.send(JSON.stringify({
      type: 'answer',
      answer: pc.localDescription,
      userId: user.id,
      targetUserId: userId
    }));
  };
  
  const handleAnswer = (data) => {
    const { answer, userId } = data;
    const pc = peerConnections.current[userId];
    
    if (pc) {
      pc.setRemoteDescription(new RTCSessionDescription(answer))
        .catch(error => console.error('Erro ao configurar resposta remota:', error));
    }
  };
  
  const handleIceCandidate = (data) => {
    const { candidate, userId } = data;
    const pc = peerConnections.current[userId];
    
    if (pc) {
      pc.addIceCandidate(new RTCIceCandidate(candidate))
        .catch(error => console.error('Erro ao adicionar ICE candidate:', error));
    }
  };
  
  const removePeerConnection = (userId) => {
    if (peerConnections.current[userId]) {
      peerConnections.current[userId].close();
      delete peerConnections.current[userId];
    }
    
    setRemoteStreams(prev => {
      const newStreams = { ...prev };
      delete newStreams[userId];
      return newStreams;
    });
  };
  
  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
        setIsMuted(!track.enabled);
      });
    }
  };
  
  const muteAudio = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = false;
        setIsMuted(true);
      });
    }
  };
  
  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
        setIsVideoEnabled(!isVideoEnabled);
      });
    }
  };
  
  const toggleSpeaker = () => {
    // Implementação específica para cada plataforma
    setIsSpeakerOn(!isSpeakerOn);
  };
  
  const endConferenceAsHost = async () => {
    if (!isHost) return;
    
    try {
      await endConference(conferenceId);
      
      // Notificar todos os participantes
      socketRef.current.send(JSON.stringify({
        type: 'end-conference',
        userId: user.id,
        conferenceId
      }));
      
      cleanupConference();
      navigation.goBack();
    } catch (error) {
      console.error('Erro ao encerrar conferência:', error);
      Alert.alert('Erro', 'Não foi possível encerrar a conferência');
    }
  };
  
  const leaveConference = () => {
    if (isHost) {
      Alert.alert(
        'Encerrar Conferência',
        'Como anfitrião, encerrar a conferência irá desconectar todos os participantes. Deseja continuar?',
        [
          {
            text: 'Cancelar',
            style: 'cancel'
          },
          {
            text: 'Encerrar',
            style: 'destructive',
            onPress: endConferenceAsHost
          }
        ]
      );
    } else {
      cleanupConference();
      navigation.goBack();
    }
  };
  
  const cleanupConference = () => {
    // Fechar todas as conexões de pares
    Object.values(peerConnections.current).forEach(pc => pc.close());
    peerConnections.current = {};
    
    // Parar stream local
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    
    // Fechar socket
    if (socketRef.current) {
      socketRef.current.close();
    }
  };
  
  const muteAllParticipants = () => {
    if (!isHost) return;
    
    socketRef.current.send(JSON.stringify({
      type: 'mute-all',
      userId: user.id,
      conferenceId,
      exceptHost: true
    }));
  };
  
  const renderRemoteStreams = () => {
    const streams = Object.entries(remoteStreams);
    
    if (streams.length === 0) {
      return (
        <View style={styles.waitingContainer}>
          <Text style={styles.waitingText}>
            {isHost ? 'Aguardando participantes...' : 'Conectando à transmissão...'}
          </Text>
        </View>
      );
    }
    
    return (
      <FlatList
        data={streams}
        keyExtractor={([userId]) => userId}
        numColumns={streams.length === 1 ? 1 : 2}
        renderItem={({ item: [userId, { stream, userName }] }) => (
          <View style={styles.remoteStreamContainer}>
            <RTCView
              streamURL={stream.toURL()}
              style={styles.remoteStream}
              objectFit="cover"
            />
            <View style={styles.participantNameContainer}>
              <Text style={styles.participantName}>{userName}</Text>
            </View>
          </View>
        )}
      />
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={leaveConference}>
          <Icon name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {conferenceStatus === 'created' || conferenceStatus === 'joined'
            ? 'Videoconferência ao Vivo'
            : 'Conectando...'}
        </Text>
        {isHost && (
          <TouchableOpacity style={styles.settingsButton} onPress={() => setIsSettingsVisible(true)}>
            <Icon name="more-vert" size={24} color="#fff" />
          </TouchableOpacity>
        )}
      </View>
      
      <View style={styles.streamsContainer}>
        {localStream && (
          <View style={styles.localStreamContainer}>
            <RTCView
              streamURL={localStream.toURL()}
              style={styles.localStream}
              objectFit="cover"
              zOrder={1}
            />
            {!isVideoEnabled && (
              <View style={styles.videoDisabledIndicator}>
                <Icon name="videocam-off" size={40} color="#fff" />
              </View>
            )}
            <View style={styles.localNameContainer}>
              <Text style={styles.localName}>
                {isMuted && <Icon name="mic-off" size={16} color="#fff" />} Você
                {isHost && ' (Anfitrião)'}
              </Text>
            </View>
          </View>
        )}
        
        {renderRemoteStreams()}
      </View>
      
      <View style={styles.controlsContainer}>
        <TouchableOpacity
          style={[styles.controlButton, isMuted && styles.controlButtonActive]}
          onPress={toggleMute}
        >
          <Icon name={isMuted ? 'mic-off' : 'mic'} size={24} color="#fff" />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.controlButton, !isVideoEnabled && styles.controlButtonActive]}
          onPress={toggleVideo}
        >
          <Icon name={isVideoEnabled ? 'videocam' : 'videocam-off'} size={24} color="#fff" />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.controlButton, isSpeakerOn && styles.controlButtonActive]}
          onPress={toggleSpeaker}
        >
          <Icon name={isSpeakerOn ? 'volume-up' : 'volume-off'} size={24} color="#fff" />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.controlButton, styles.endCallButton]}
          onPress={leaveConference}
        >
          <Icon name="call-end" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
      
      {/* Modal de Configurações para o Host */}
      <Modal
        visible={isSettingsVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsSettingsVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Configurações do Anfitrião</Text>
            
            <TouchableOpacity style={styles.modalOption} onPress={muteAllParticipants}>
              <Icon name="mic-off" size={24} color="#333" />
              <Text style={styles.modalOptionText}>Silenciar todos os participantes</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.modalOption} onPress={() => loadParticipants()}>
              <Icon name="refresh" size={24} color="#333" />
              <Text style={styles.modalOptionText}>Atualizar lista de participantes</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.modalOption, { marginTop: 20 }]} 
              onPress={endConferenceAsHost}
            >
              <Icon name="call-end" size={24} color="#e74c3c" />
              <Text style={[styles.modalOptionText, { color: '#e74c3c' }]}>
                Encerrar conferência para todos
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.closeModalButton}
              onPress={() => setIsSettingsVisible(false)}
            >
              <Text style={styles.closeModalButtonText}>Fechar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#2a2a2a',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  settingsButton: {
    padding: 8,
  },
  streamsContainer: {
    flex: 1,
    padding: 8,
  },
  localStreamContainer: {
    height: 150,
    width: 100,
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 10,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#4285f4',
  },
  localStream: {
    flex: 1,
  },
  videoDisabledIndicator: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  localNameContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 4,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
  },
  localName: {
    fontSize: 12,
    color: '#fff',
    textAlign: 'center',
  },
  remoteStreamContainer: {
    flex: 1,
    height: 300,
    margin: 4,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#333',
  },
  remoteStream: {
    flex: 1,
  },
  participantNameContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
  },
  participantName: {
    fontSize: 14,
    color: '#fff',
  },
  waitingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  waitingText: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    padding: 16,
    backgroundColor: '#2a2a2a',
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButtonActive: {
    backgroundColor: '#4285f4',
  },
  endCallButton: {
    backgroundColor: '#e74c3c',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  modalOptionText: {
    fontSize: 16,
    marginLeft: 12,
  },
  closeModalButton: {
    marginTop: 20,
    padding: 12,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    alignItems: 'center',
  },
  closeModalButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default LiveStreamingScreen;