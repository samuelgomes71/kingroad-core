data class ContactInfo(
    val loadingDock: String?,
    val security: String?,
    val emergency: String?,
    val email: String?,
    val specialInstructions: String?
)

data class FactoryFacilities(
    val hasDriverRoom: Boolean = false,
    val hasRestroom: Boolean = false,
    val hasParking: Boolean = false,
    val parkingCapacity: Int = 0,
    val hasWaitingArea: Boolean = false,
    val hasCafeteria: Boolean = false,
    val hasWifi: Boolean = false
)

data class SecurityRequirements(
    val requiresPreRegistration: Boolean = true,
    val requiresIdentification: Boolean = true,
    val requiresVehicleInspection: Boolean = true,
    val specialDocuments: List<String> = listOf(),
    val instructions: String? = null
)

data class VehicleType(
    val make: String,
    val models: List<String>
)