import React, { useEffect, useState } from 'react';
import AppDownloadSection from '../components/download/AppDownloadSection';
import { getDeviceInfo } from '../utils/DeviceDetectorUtil';
import ResourceLoaderService from '../services/ResourceLoaderService';

/**
 * Página de download do aplicativo KingRoad
 * Detecta automaticamente o dispositivo do usuário e oferece a versão apropriada
 */
const DownloadPage = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [deviceInfo, setDeviceInfo] = useState(null);
  
  useEffect(() => {
    // Coleta informações do dispositivo
    const info = getDeviceInfo();
    setDeviceInfo(info);
    
    // Pré-carrega os recursos essenciais para esta página
    const preloadResources = async () => {
      try {
        // Carrega apenas o logo correspondente ao tamanho do dispositivo
        await ResourceLoaderService.preloadResource(
          ResourceLoaderService.getResourcePath('kingroad-logo')
        );
        
        setIsLoading(false);
      } catch (error) {
        console.error('Erro ao pré-carregar recursos:', error);
        // Mesmo com erro, permitimos que a página seja mostrada
        setIsLoading(false);
      }
    };
    
    preloadResources();
  }, []);
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-yellow-500 text-lg">Carregando...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-900">
      <header className="bg-gray-800 shadow-lg">
        <div className="container mx-auto py-6 px-4">
          <h1 className="text-3xl font-bold text-yellow-500">KingRoad</h1>
          <p className="text-gray-400">Navegação GPS especializada para caminhoneiros</p>
        </div>
      </header>
      
      <main className="container mx-auto py-8 px-4">
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            Baixe o KingRoad para o seu dispositivo
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Detectamos automaticamente seu dispositivo para oferecer a melhor versão do 
            aplicativo KingRoad, otimizada para o tamanho da sua tela e desempenho.
          </p>
        </div>
        
        {/* Componente de download que mostra o tamanho correto do app */}
        <AppDownloadSection />
        
        <div className="mt-12 bg-gray-800 rounded-lg p-6 max-w-3xl mx-auto">
          <h3 className="text-xl font-bold text-yellow-500 mb-4">
            Por que baixar o KingRoad?
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex">
              <div className="mr-4 text-yellow-500">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path>
                </svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Navegação especializada</h4>
                <p className="text-gray-400 text-sm">
                  Rotas otimizadas para caminhões, considerando altura, peso e restrições.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 text-yellow-500">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">POIs específicos</h4>
                <p className="text-gray-400 text-sm">
                  Locais de interesse para caminhoneiros: postos, restaurantes, food trucks e mais.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 text-yellow-500">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Modo offline</h4>
                <p className="text-gray-400 text-sm">
                  Navegue sem conexão com internet, ideal para áreas remotas.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="mr-4 text-yellow-500">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                </svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Otimizado para seu dispositivo</h4>
                <p className="text-gray-400 text-sm">
                  Interface adaptada ao tamanho da sua tela para melhor experiência.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 mt-16 py-8 px-4 text-center">
        <p className="text-gray-400 text-sm">
          © {new Date().getFullYear()} KingRoad - Todos os direitos reservados
        </p>
        <p className="text-gray-500 text-xs mt-2">
          Versão detectada para {deviceInfo.isAndroid ? 'Android' : deviceInfo.isIOS ? 'iOS' : 'Desktop'}
        </p>
      </footer>
    </div>
  );
};

export default DownloadPage;