import React, { useState, useEffect } from 'react';
import { 
  User, Truck, Bell, Moon, Sun, ChevronRight, 
  MapPin, Map, Shield, Download, Upload, Clock, 
  Award, Star, Settings, LogOut, Globe
} from 'lucide-react';

// Componente de tela de perfil do usuário
// Implementa as funcionalidades mencionadas em UserProfileScreen.js no relatório

const SimpleUserProfileScreen = ({
  userData = {
    name: 'Motorista KingRoad',
    email: 'usuario@exemplo.com',
    avatar: null,
    level: 3,
    experience: 756,
    nextLevel: 1000,
    since: '2023',
    vehicle: {
      type: 'truck',
      name: 'Scania R450',
      year: '2020'
    },
    stats: {
      routesCompleted: 248,
      reportsSubmitted: 76,
      alertsHelped: 39,
      kmTraveled: 25743
    }
  },
  language = 'pt',
  darkMode = false,
  onToggleDarkMode = () => {},
  onNotificationsPress = () => {},
  onSettingsPress = () => {},
  onLogout = () => {},
  onVehiclePress = () => {}
}) => {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      profile: 'Perfil',
      userSince: 'Usuário desde',
      vehicle: 'Veículo',
      stats: 'Estatísticas',
      routesCompleted: 'Rotas completadas',
      reportsSubmitted: 'Reportes enviados',
      alertsHelped: 'Alertas compartilhados',
      kmTraveled: 'Km percorridos',
      preferences: 'Preferências',
      notifications: 'Notificações',
      darkMode: 'Modo escuro',
      on: 'Ativado',
      off: 'Desativado',
      language: 'Idioma',
      dataUsage: 'Uso de dados',
      mapCache: 'Cache de mapas',
      settings: 'Configurações',
      logout: 'Sair',
      level: 'Nível',
      experience: 'Experiência',
      nextLevel: 'Próximo nível',
      yourVehicle: 'Seu veículo',
      vehicleTypes: {
        truck: 'Caminhão',
        car: 'Carro',
        motorcycle: 'Moto',
        hiking: 'Trilha'
      }
    },
    en: {
      profile: 'Profile',
      userSince: 'User since',
      vehicle: 'Vehicle',
      stats: 'Statistics',
      routesCompleted: 'Routes completed',
      reportsSubmitted: 'Reports submitted',
      alertsHelped: 'Alerts shared',
      kmTraveled: 'Km traveled',
      preferences: 'Preferences',
      notifications: 'Notifications',
      darkMode: 'Dark mode',
      on: 'On',
      off: 'Off',
      language: 'Language',
      dataUsage: 'Data usage',
      mapCache: 'Map cache',
      settings: 'Settings',
      logout: 'Logout',
      level: 'Level',
      experience: 'Experience',
      nextLevel: 'Next level',
      yourVehicle: 'Your vehicle',
      vehicleTypes: {
        truck: 'Truck',
        car: 'Car',
        motorcycle: 'Motorcycle',
        hiking: 'Hiking'
      }
    },
    es: {
      profile: 'Perfil',
      userSince: 'Usuario desde',
      vehicle: 'Vehículo',
      stats: 'Estadísticas',
      routesCompleted: 'Rutas completadas',
      reportsSubmitted: 'Reportes enviados',
      alertsHelped: 'Alertas compartidos',
      kmTraveled: 'Km recorridos',
      preferences: 'Preferencias',
      notifications: 'Notificaciones',
      darkMode: 'Modo oscuro',
      on: 'Activado',
      off: 'Desactivado',
      language: 'Idioma',
      dataUsage: 'Uso de datos',
      mapCache: 'Caché de mapas',
      settings: 'Ajustes',
      logout: 'Cerrar sesión',
      level: 'Nivel',
      experience: 'Experiencia',
      nextLevel: 'Próximo nivel',
      yourVehicle: 'Su vehículo',
      vehicleTypes: {
        truck: 'Camión',
        car: 'Coche',
        motorcycle: 'Moto',
        hiking: 'Senderismo'
      }
    }
  };
  
  // Texto conforme o idioma
  const text = translations[language] || translations.en;
  
  // Estilo para o tema
  const theme = {
    bg: darkMode ? 'bg-gray-900' : 'bg-white',
    bgSecondary: darkMode ? 'bg-gray-800' : 'bg-gray-50',
    text: darkMode ? 'text-white' : 'text-gray-800',
    textSecondary: darkMode ? 'text-gray-300' : 'text-gray-600',
    border: darkMode ? 'border-gray-700' : 'border-gray-200',
    card: darkMode ? 'bg-gray-800' : 'bg-white',
    progress: darkMode ? 'bg-blue-600' : 'bg-blue-500'
  };
  
  // Toggle de notificações
  const toggleNotifications = () => {
    setNotificationsEnabled(!notificationsEnabled);
    onNotificationsPress(!notificationsEnabled);
  };
  
  // Mapeia o tipo de veículo para exibição
  const getVehicleType = (type) => {
    return text.vehicleTypes[type] || type;
  };
  
  // Calcula a porcentagem de progresso para o próximo nível
  const calculateLevelProgress = () => {
    if (!userData.nextLevel) return 100;
    return Math.min(100, Math.round((userData.experience / userData.nextLevel) * 100));
  };
  
  return (
    <div className={`flex flex-col min-h-screen ${theme.bg}`}>
      {/* Cabeçalho do perfil */}
      <div className={`${theme.bgSecondary} px-4 py-6`}>
        <div className="flex items-center">
          {/* Avatar do usuário */}
          {userData.avatar ? (
            <img 
              src={userData.avatar} 
              alt={userData.name} 
              className="w-16 h-16 rounded-full object-cover"
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center text-white text-xl font-bold">
              {userData.name.charAt(0).toUpperCase()}
            </div>
          )}
          
          {/* Informações do usuário */}
          <div className="ml-4">
            <h1 className={`text-xl font-bold ${theme.text}`}>{userData.name}</h1>
            <p className={`${theme.textSecondary}`}>{userData.email}</p>
            <div className="flex items-center mt-1">
              <div className={`text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100`}>
                {text.level} {userData.level}
              </div>
              <div className={`ml-2 text-xs ${theme.textSecondary}`}>
                {text.userSince} {userData.since}
              </div>
            </div>
          </div>
        </div>
        
        {/* Barra de progresso de nível */}
        <div className="mt-4">
          <div className="flex justify-between items-center mb-1 text-xs">
            <span className={`${theme.textSecondary}`}>
              {text.experience}: {userData.experience} pts
            </span>
            <span className={`${theme.textSecondary}`}>
              {text.nextLevel}: {userData.nextLevel} pts
            </span>
          </div>
          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div 
              className={`h-full ${theme.progress}`} 
              style={{ width: `${calculateLevelProgress()}%` }}
            ></div>
          </div>
        </div>
      </div>
      
      {/* Conteúdo principal com rolagem */}
      <div className="flex-1 overflow-y-auto pb-6">
        <div className="px-4 py-4 space-y-6">
          {/* Seção do veículo */}
          <div>
            <h2 className={`text-lg font-semibold mb-3 ${theme.text}`}>{text.yourVehicle}</h2>
            <div
              className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} p-4`}
              onClick={onVehiclePress}
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                    <Truck size={24} />
                  </div>
                  <div className="ml-3">
                    <p className={`font-medium ${theme.text}`}>
                      {userData.vehicle.name}
                    </p>
                    <p className={`text-sm ${theme.textSecondary}`}>
                      {getVehicleType(userData.vehicle.type)} • {userData.vehicle.year}
                    </p>
                  </div>
                </div>
                <ChevronRight size={20} className={theme.textSecondary} />
              </div>
            </div>
          </div>
          
          {/* Seção de estatísticas */}
          <div>
            <h2 className={`text-lg font-semibold mb-3 ${theme.text}`}>{text.stats}</h2>
            <div className="grid grid-cols-2 gap-3">
              {/* Rotas completadas */}
              <div className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} p-4`}>
                <div className="flex flex-col">
                  <div className="p-2 w-10 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300">
                    <Map size={20} />
                  </div>
                  <p className={`mt-2 text-2xl font-bold ${theme.text}`}>
                    {userData.stats.routesCompleted}
                  </p>
                  <p className={`text-sm ${theme.textSecondary}`}>
                    {text.routesCompleted}
                  </p>
                </div>
              </div>
              
              {/* Reportes enviados */}
              <div className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} p-4`}>
                <div className="flex flex-col">
                  <div className="p-2 w-10 rounded-full bg-amber-100 dark:bg-amber-900 text-amber-600 dark:text-amber-300">
                    <Shield size={20} />
                  </div>
                  <p className={`mt-2 text-2xl font-bold ${theme.text}`}>
                    {userData.stats.reportsSubmitted}
                  </p>
                  <p className={`text-sm ${theme.textSecondary}`}>
                    {text.reportsSubmitted}
                  </p>
                </div>
              </div>
              
              {/* Alertas compartilhados */}
              <div className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} p-4`}>
                <div className="flex flex-col">
                  <div className="p-2 w-10 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300">
                    <Bell size={20} />
                  </div>
                  <p className={`mt-2 text-2xl font-bold ${theme.text}`}>
                    {userData.stats.alertsHelped}
                  </p>
                  <p className={`text-sm ${theme.textSecondary}`}>
                    {text.alertsHelped}
                  </p>
                </div>
              </div>
              
              {/* KM percorridos */}
              <div className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} p-4`}>
                <div className="flex flex-col">
                  <div className="p-2 w-10 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                    <MapPin size={20} />
                  </div>
                  <p className={`mt-2 text-2xl font-bold ${theme.text}`}>
                    {userData.stats.kmTraveled.toLocaleString()}
                  </p>
                  <p className={`text-sm ${theme.textSecondary}`}>
                    {text.kmTraveled}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Seção de preferências */}
          <div>
            <h2 className={`text-lg font-semibold mb-3 ${theme.text}`}>{text.preferences}</h2>
            <div className={`rounded-lg ${theme.card} shadow-sm border ${theme.border} divide-y ${theme.border}`}>
              {/* Notificações */}
              <button 
                className="w-full flex justify-between items-center p-4"
                onClick={toggleNotifications}
              >
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-300">
                    <Bell size={20} />
                  </div>
                  <span className={`ml-3 ${theme.text}`}>{text.notifications}</span>
                </div>
                <div className="flex items-center">
                  <span className={`mr-2 text-sm ${theme.textSecondary}`}>
                    {notificationsEnabled ? text.on : text.off}
                  </span>
                  <div 
                    className={`w-10 h-6 rounded-full flex items-center transition-colors duration-300 ${
                      notificationsEnabled ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  >
                    <div 
                      className={`bg-white w-5 h-5 rounded-full shadow transform transition-transform ${
                        notificationsEnabled ? 'translate-x-4' : 'translate-x-1'
                      }`}
                    />
                  </div>
                </div>
              </button>
              
              {/* Modo escuro */}
              <button 
                className="w-full flex justify-between items-center p-4"
                onClick={onToggleDarkMode}
              >
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300">
                    {darkMode ? <Moon size={20} /> : <Sun size={20} />}
                  </div>
                  <span className={`ml-3 ${theme.text}`}>{text.darkMode}</span>
                </div>
                <div className="flex items-center">
                  <span className={`mr-2 text-sm ${theme.textSecondary}`}>
                    {darkMode ? text.on : text.off}
                  </span>
                  <div 
                    className={`w-10 h-6 rounded-full flex items-center transition-colors duration-300 ${
                      darkMode ? 'bg-purple-500' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  >
                    <div 
                      className={`bg-white w-5 h-5 rounded-full shadow transform transition-transform ${
                        darkMode ? 'translate-x-4' : 'translate-x-1'
                      }`}
                    />
                  </div>
                </div>
              </button>
              
              {/* Idioma */}
              <div className="w-full flex justify-between items-center p-4">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300">
                    <Globe size={20} />
                  </div>
                  <span className={`ml-3 ${theme.text}`}>{text.language}</span>
                </div>
                <div className="flex items-center">
                  <span className={`mr-2 text-sm ${theme.textSecondary}`}>
                    {language === 'pt' ? 'Português' : language === 'es' ? 'Español' : 'English'}
                  </span>
                  <ChevronRight size={20} className={theme.textSecondary} />
                </div>
              </div>
              
              {/* Uso de dados */}
              <div className="w-full flex justify-between items-center p-4">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                    <Upload size={20} />
                  </div>
                  <span className={`ml-3 ${theme.text}`}>{text.dataUsage}</span>
                </div>
                <ChevronRight size={20} className={theme.textSecondary} />
              </div>
              
              {/* Cache de mapas */}
              <div className="w-full flex justify-between items-center p-4">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300">
                    <Download size={20} />
                  </div>
                  <span className={`ml-3 ${theme.text}`}>{text.mapCache}</span>
                </div>
                <ChevronRight size={20} className={theme.textSecondary} />
              </div>
            </div>
          </div>
          
          {/* Botões de ação */}
          <div className="space-y-3">
            <button 
              className={`w-full flex justify-between items-center p-4 rounded-lg ${theme.card} shadow-sm border ${theme.border}`}
              onClick={onSettingsPress}
            >
              <div className="flex items-center">
                <div className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                  <Settings size={20} />
                </div>
                <span className={`ml-3 ${theme.text}`}>{text.settings}</span>
              </div>
              <ChevronRight size={20} className={theme.textSecondary} />
            </button>
            
            <button 
              className="w-full flex justify-center items-center p-4 rounded-lg bg-red-500 hover:bg-red-600 text-white shadow-sm"
              onClick={onLogout}
            >
              <LogOut size={20} className="mr-2" />
              <span>{text.logout}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimpleUserProfileScreen;