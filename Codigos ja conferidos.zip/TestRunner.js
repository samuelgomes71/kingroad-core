import StorageService from '../utils/StorageService';
import DatabaseService from '../database/DatabaseService';
import MapCacheService from '../cache/MapCacheService';

/**
 * Serviço para executar testes de diagnóstico do sistema
 * Contém métodos para verificar diferentes componentes do sistema
 */
class TestRunner {
  /**
   * Executa todos os testes disponíveis
   * @param {Function} logError - Função para registrar erros
   * @returns {Object} Resultados dos testes
   */
  static async runAllTests(logError) {
    try {
      const storageResult = await this.runStorageTest(logError);
      const connectionResult = this.runConnectionTest(logError);
      const databaseResult = await this.runDatabaseTest(logError);
      const cacheResult = await this.runCacheTest(logError);
      const spaceInfo = await this.checkStorageSpace(logError);
      
      return {
        storage: storageResult,
        connection: connectionResult,
        database: databaseResult,
        cache: cacheResult,
        space: spaceInfo
      };
    } catch (error) {
      if (logError) logError('Test Suite', error);
      return {
        storage: false,
        connection: false,
        database: false,
        cache: false,
        space: null
      };
    }
  }

  /**
   * Testa o serviço de armazenamento
   * @param {Function} logError - Função para registrar erros
   * @returns {Promise<boolean>} Resultado do teste
   */
  static async runStorageTest(logError) {
    try {
      const testKey = 'test_storage';
      await StorageService.saveData(testKey, 'test');
      const testData = await StorageService.getData(testKey);
      const result = testData === 'test';
      await StorageService.removeData(testKey);
      return result;
    } catch (error) {
      if (logError) logError('Storage Test', error);
      return false;
    }
  }

  /**
   * Testa a conexão com a internet
   * @param {Function} logError - Função para registrar erros
   * @returns {boolean} Resultado do teste
   */
  static runConnectionTest(logError) {
    try {
      return navigator.onLine;
    } catch (error) {
      if (logError) logError('Connection Test', error);
      return false;
    }
  }

  /**
   * Testa o serviço de banco de dados
   * @param {Function} logError - Função para registrar erros
   * @returns {Promise<boolean>} Resultado do teste
   */
  static async runDatabaseTest(logError) {
    try {
      // Tentativa de inicializar o banco de dados
      await DatabaseService.initDatabase();
      return true;
    } catch (error) {
      if (logError) logError('Database Test', error);
      return false;
    }
  }

  /**
   * Testa o serviço de cache de mapas
   * @param {Function} logError - Função para registrar erros
   * @returns {Promise<boolean>} Resultado do teste
   */
  static async runCacheTest(logError) {
    try {
      // Obter cache index
      const cacheIndex = await MapCacheService.getCacheIndex();
      return true;
    } catch (error) {
      if (logError) logError('Cache Test', error);
      return false;
    }
  }

  /**
   * Verifica o espaço de armazenamento disponível
   * @param {Function} logError - Função para registrar erros
   * @returns {Promise<Object>} Informações sobre o espaço de armazenamento
   */
  static async checkStorageSpace(logError) {
    try {
      let used = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        used += (key.length + (value ? value.length : 0));
      }

      // Converter para KB
      used = Math.round(used / 1024);
      
      // Obter tamanho do cache de mapas
      try {
        const mapCacheInfo = await MapCacheService.getCachedTiles();
        if (mapCacheInfo && mapCacheInfo.totalSizeBytes) {
          used += Math.round(mapCacheInfo.totalSizeBytes / 1024);
        }
      } catch (error) {
        console.warn('Erro ao obter tamanho do cache de mapas:', error);
      }
      
      return {
        used,
        total: 5120, // Estimativa de 5MB
        percentage: Math.min(100, Math.round((used / 5120) * 100))
      };
    } catch (error) {
      if (logError) logError('Storage Space Check', error);
      return null;
    }
  }

  /**
   * Limpa o cache do sistema
   * @param {Function} logError - Função para registrar erros
   * @returns {Promise<boolean>} Resultado da operação
   */
  static async clearSystemCache(logError) {
    try {
      // Limpar cache de mapas
      await MapCacheService.clearCache({ all: true });
      
      // Obter logs antes de limpar
      const logs = await StorageService.getData('error_logs');
      const userPrefs = await StorageService.getData('userPreferences');
      
      // Limpar armazenamento local (preservando logs e preferências)
      await StorageService.clearAll();
      
      // Restaurar dados importantes
      if (logs) {
        await StorageService.saveData('error_logs', logs);
      }
      
      if (userPrefs) {
        await StorageService.saveData('userPreferences', userPrefs);
      }
      
      return true;
    } catch (error) {
      if (logError) logError('Cache Clear', error);
      return false;
    }
  }

  /**
   * Cria um backup dos dados do sistema
   * @param {Array} errorLogs - Logs de erro atuais
   * @returns {Promise<Object>} Dados do backup e resultado da operação
   */
  static async createBackup(errorLogs = []) {
    try {
      // Coletar dados para backup
      const backup = {
        localStorage: {},
        errorLogs,
        timestamp: Date.now(),
        device: navigator.userAgent,
        version: '1.0.0'
      };
      
      // Obter todos os dados do localStorage
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        try {
          backup.localStorage[key] = JSON.parse(localStorage.getItem(key));
        } catch (e) {
          backup.localStorage[key] = localStorage.getItem(key);
        }
      }
      
      return {
        success: true,
        data: backup
      };
    } catch (error) {
      console.error('Erro ao criar backup:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

export default TestRunner;