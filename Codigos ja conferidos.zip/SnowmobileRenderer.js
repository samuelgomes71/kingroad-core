import React from 'react';
import { View, Text, Switch, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

/**
 * Renderiza as configurações para o modo Snowmobile (Moto de Neve)
 * 
 * @param {Object} settings - Configurações atuais do modo Snowmobile
 * @param {Function} updateSetting - Função para atualizar uma configuração específica
 * @param {Object} styles - Estilos a serem aplicados aos componentes
 * @returns {JSX.Element} Componente com as configurações do modo Snowmobile
 */
export const renderSnowmobileSettings = (settings, updateSetting, styles) => (
  <View style={styles.settingsContainer}>
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="record-rec" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Gravação de Rota</Text>
      </View>
      <Switch
        value={settings.recordingEnabled}
        onValueChange={(value) => updateSetting('recordingEnabled', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.recordingEnabled ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="road-variant" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Mostrar Trilhas Preparadas</Text>
      </View>
      <Switch
        value={settings.showGroomedTrails}
        onValueChange={(value) => updateSetting('showGroomedTrails', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.showGroomedTrails ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="alert" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Mostrar Risco de Avalanche</Text>
      </View>
      <Switch
        value={settings.showAvalangeRisk}
        onValueChange={(value) => updateSetting('showAvalangeRisk', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.showAvalangeRisk ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="home" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Mostrar Abrigos</Text>
      </View>
      <Switch
        value={settings.showShelters}
        onValueChange={(value) => updateSetting('showShelters', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.showShelters ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="thermometer" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Registrar Temperatura</Text>
      </View>
      <Switch
        value={settings.recordTemperature}
        onValueChange={(value) => updateSetting('recordTemperature', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.recordTemperature ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="snowflake" size={20} color="#9C27B0" />
        <Text style={styles.settingLabel}>Mostrar Profundidade da Neve</Text>
      </View>
      <Switch
        value={settings.showSnowDepth}
        onValueChange={(value) => updateSetting('showSnowDepth', value)}
        trackColor={{ false: '#D1D1D1', true: '#E1BEE7' }}
        thumbColor={settings.showSnowDepth ? '#9C27B0' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Filtro de Trilhas não Preparadas</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.ungroomedFilter === 'all' && styles.optionButtonActive,
          { borderColor: '#9C27B0' }
        ]}
        onPress={() => updateSetting('ungroomedFilter', 'all')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.ungroomedFilter === 'all' && styles.optionButtonTextActive
        ]}>Todas</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.ungroomedFilter === 'avoid' && styles.optionButtonActive,
          { borderColor: '#9C27B0' }
        ]}
        onPress={() => updateSetting('ungroomedFilter', 'avoid')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.ungroomedFilter === 'avoid' && styles.optionButtonTextActive
        ]}>Evitar</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.ungroomedFilter === 'prefer' && styles.optionButtonActive,
          { borderColor: '#9C27B0' }
        ]}
        onPress={() => updateSetting('ungroomedFilter', 'prefer')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.ungroomedFilter === 'prefer' && styles.optionButtonTextActive
        ]}>Preferir</Text>
      </TouchableOpacity>
    </View>
  </View>
);