import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Serviço de geocodificação para o sistema KingRoad
 * Responsável por converter coordenadas geográficas em informações locais (país, cidade, etc.)
 * e vice-versa (geocodificação reversa)
 */
class GeocodingService {
  constructor() {
    this.apiKey = null;
    this.cacheExpirationMs = 7 * 24 * 60 * 60 * 1000; // 7 dias em milissegundos
    this.countryBoundariesCache = {}; // Cache de fronteiras dos países
    this.geocodingCache = {}; // Cache de resultados de geocodificação
    this.lastCacheCleanup = Date.now();
  }

  /**
   * Inicializa o serviço de geocodificação
   * @param {Object} config - Configurações do serviço
   */
  async initialize(config = {}) {
    try {
      // Configurar API key (em produção, seria um valor do ambiente ou servidor seguro)
      this.apiKey = config.apiKey || 'king_road_geocoding_api_key';
      
      // Carregar cache de geocodificação do armazenamento local
      await this.loadCacheFromStorage();
      
      // Limpar cache expirado
      this.cleanupExpiredCache();
      
      return true;
    } catch (error) {
      console.error('Erro ao inicializar GeocodingService:', error);
      return false;
    }
  }

  /**
   * Carrega o cache de geocodificação do armazenamento local
   */
  async loadCacheFromStorage() {
    try {
      const geocodingCacheJson = await AsyncStorage.getItem('kingroad_geocoding_cache');
      const countryBoundariesCacheJson = await AsyncStorage.getItem('kingroad_country_boundaries_cache');
      
      if (geocodingCacheJson) {
        this.geocodingCache = JSON.parse(geocodingCacheJson);
      }
      
      if (countryBoundariesCacheJson) {
        this.countryBoundariesCache = JSON.parse(countryBoundariesCacheJson);
      }
    } catch (error) {
      console.error('Erro ao carregar cache de geocodificação:', error);
      // Inicializar caches vazios em caso de erro
      this.geocodingCache = {};
      this.countryBoundariesCache = {};
    }
  }

  /**
   * Salva o cache de geocodificação no armazenamento local
   */
  async saveCacheToStorage() {
    try {
      await AsyncStorage.setItem(
        'kingroad_geocoding_cache',
        JSON.stringify(this.geocodingCache)
      );
      
      await AsyncStorage.setItem(
        'kingroad_country_boundaries_cache',
        JSON.stringify(this.countryBoundariesCache)
      );
    } catch (error) {
      console.error('Erro ao salvar cache de geocodificação:', error);
    }
  }

  /**
   * Limpa entradas expiradas do cache
   */
  cleanupExpiredCache() {
    const now = Date.now();
    
    // Limitar frequência de limpeza (no máximo uma vez por hora)
    if (now - this.lastCacheCleanup < 60 * 60 * 1000) {
      return;
    }
    
    let changed = false;
    
    // Limpar cache de geocodificação
    Object.keys(this.geocodingCache).forEach(key => {
      if (now - this.geocodingCache[key].timestamp > this.cacheExpirationMs) {
        delete this.geocodingCache[key];
        changed = true;
      }
    });
    
    // Limpar cache de fronteiras de países (geralmente menos volátil, mas ainda precisa ser atualizado)
    Object.keys(this.countryBoundariesCache).forEach(key => {
      if (now - this.countryBoundariesCache[key].timestamp > this.cacheExpirationMs * 2) {
        delete this.countryBoundariesCache[key];
        changed = true;
      }
    });
    
    if (changed) {
      this.saveCacheToStorage();
    }
    
    this.lastCacheCleanup = now;
  }

  /**
   * Obtém o país a partir de coordenadas geográficas
   * @param {Object} coordinates - Objeto com latitude e longitude
   * @returns {Promise<string>} Código do país em formato ISO (ex: 'US', 'BR')
   */
  async getCountryFromCoordinates(coordinates) {
    try {
      const { latitude, longitude } = coordinates;
      
      // Validar coordenadas
      if (typeof latitude !== 'number' || typeof longitude !== 'number') {
        throw new Error('Coordenadas inválidas');
      }
      
      // Gerar chave de cache (com precisão limitada para melhorar hits de cache)
      // Usamos apenas 2 casas decimais para aumentar a probabilidade de cache hit
      const cacheKey = `${latitude.toFixed(2)},${longitude.toFixed(2)}`;
      
      // Verificar cache
      if (this.geocodingCache[cacheKey] && 
          Date.now() - this.geocodingCache[cacheKey].timestamp < this.cacheExpirationMs) {
        return this.geocodingCache[cacheKey].country;
      }
      
      // Em um app real, faria uma chamada a um serviço de geocodificação reversa
      // Como Nominatim OpenStreetMap, Google Maps Geocoding API, etc.
      
      // Implementação simulada para exemplo
      const country = await this.simulateGeocodingRequest(latitude, longitude);
      
      // Armazenar resultado no cache
      this.geocodingCache[cacheKey] = {
        country,
        timestamp: Date.now()
      };
      
      // Salvar cache periodicamente (não em cada chamada para evitar overhead)
      if (Object.keys(this.geocodingCache).length % 10 === 0) {
        this.saveCacheToStorage();
      }
      
      return country;
    } catch (error) {
      console.error('Erro ao obter país a partir de coordenadas:', error);
      return null;
    }
  }

  /**
   * Determina se as coordenadas estão próximas de uma fronteira entre países
   * Útil para alertar motoristas sobre possíveis cruzamentos de fronteira
   * @param {Object} coordinates - Objeto com latitude e longitude
   * @returns {Promise<Object>} Informações sobre a fronteira próxima, ou null se não houver
   */
  async isNearCountryBorder(coordinates) {
    try {
      const { latitude, longitude } = coordinates;
      
      // Validar coordenadas
      if (typeof latitude !== 'number' || typeof longitude !== 'number') {
        throw new Error('Coordenadas inválidas');
      }
      
      // Obter país atual
      const currentCountry = await this.getCountryFromCoordinates(coordinates);
      if (!currentCountry) return null;
      
      // Verificar em direções ao redor do ponto atual (Norte, Sul, Leste, Oeste)
      // Deslocamento aproximado de 5km em cada direção
      const latOffset = 0.045; // Aproximadamente 5km em latitude
      const lonOffset = 0.045 / Math.cos(latitude * Math.PI / 180); // Ajuste para longitude
      
      const directions = [
        { name: 'norte', lat: latitude + latOffset, lon: longitude },
        { name: 'sul', lat: latitude - latOffset, lon: longitude },
        { name: 'leste', lat: latitude, lon: longitude + lonOffset },
        { name: 'oeste', lat: latitude, lon: longitude - lonOffset }
      ];
      
      // Verificar cada direção
      for (const direction of directions) {
        const neighborCountry = await this.getCountryFromCoordinates({
          latitude: direction.lat,
          longitude: direction.lon
        });
        
        if (neighborCountry && neighborCountry !== currentCountry) {
          return {
            currentCountry,
            neighborCountry,
            direction: direction.name,
            distanceKm: 5, // Aproximado
            coordinates: {
              latitude: direction.lat,
              longitude: direction.lon
            }
          };
        }
      }
      
      return null; // Não está próximo de uma fronteira
    } catch (error) {
      console.error('Erro ao verificar proximidade de fronteira:', error);
      return null;
    }
  }

  /**
   * Obtém endereço completo a partir de coordenadas (geocodificação reversa)
   * @param {Object} coordinates - Objeto com latitude e longitude
   * @returns {Promise<Object>} Detalhes do endereço
   */
  async getAddressFromCoordinates(coordinates) {
    try {
      const { latitude, longitude } = coordinates;
      
      // Validar coordenadas
      if (typeof latitude !== 'number' || typeof longitude !== 'number') {
        throw new Error('Coordenadas inválidas');
      }
      
      // Gerar chave de cache
      const cacheKey = `addr_${latitude.toFixed(5)},${longitude.toFixed(5)}`;
      
      // Verificar cache (mais preciso para endereços)
      if (this.geocodingCache[cacheKey] && 
          Date.now() - this.geocodingCache[cacheKey].timestamp < this.cacheExpirationMs) {
        return this.geocodingCache[cacheKey].address;
      }
      
      // Em um app real, faria uma chamada a um serviço de geocodificação reversa
      
      // Implementação simulada para exemplo
      const address = await this.simulateReverseGeocodingRequest(latitude, longitude);
      
      // Armazenar resultado no cache
      this.geocodingCache[cacheKey] = {
        address,
        timestamp: Date.now()
      };
      
      // Salvar cache periodicamente
      if (Object.keys(this.geocodingCache).length % 10 === 0) {
        this.saveCacheToStorage();
      }
      
      return address;
    } catch (error) {
      console.error('Erro ao obter endereço a partir de coordenadas:', error);
      return null;
    }
  }

  /**
   * Obtém coordenadas a partir de um endereço (geocodificação)
   * @param {string} address - Endereço a ser geocodificado
   * @returns {Promise<Object>} Coordenadas e informações adicionais
   */
  async getCoordinatesFromAddress(address) {
    try {
      // Validar endereço
      if (!address || typeof address !== 'string') {
        throw new Error('Endereço inválido');
      }
      
      // Normalizar endereço para cache (remover espaços extras, padronizar)
      const normalizedAddress = address.trim().toLowerCase();
      
      // Gerar chave de cache
      const cacheKey = `geocode_${normalizedAddress}`;
      
      // Verificar cache
      if (this.geocodingCache[cacheKey] && 
          Date.now() - this.geocodingCache[cacheKey].timestamp < this.cacheExpirationMs) {
        return this.geocodingCache[cacheKey].result;
      }
      
      // Em um app real, faria uma chamada a um serviço de geocodificação
      
      // Implementação simulada para exemplo
      const result = await this.simulateGeocodingAddressRequest(normalizedAddress);
      
      // Armazenar resultado no cache
      this.geocodingCache[cacheKey] = {
        result,
        timestamp: Date.now()
      };
      
      // Salvar cache periodicamente
      if (Object.keys(this.geocodingCache).length % 10 === 0) {
        this.saveCacheToStorage();
      }
      
      return result;
    } catch (error) {
      console.error('Erro ao obter coordenadas a partir de endereço:', error);
      return null;
    }
  }

  /**
   * Simula uma requisição de geocodificação reversa (apenas para exemplo)
   * Em um app real, usaria uma API como Google Maps, Nominatim, etc.
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @returns {Promise<string>} Código ISO do país
   */
  async simulateGeocodingRequest(latitude, longitude) {
    return new Promise(resolve => {
      // Simular atraso de rede
      setTimeout(() => {
        // Lógica simples de simulação - em produção seria uma API real
        if (latitude > 0 && latitude < 15 && longitude > -100 && longitude < -80) {
          resolve('MX'); // México
        } else if (latitude > 25 && latitude < 49 && longitude > -125 && longitude < -66) {
          resolve('US'); // EUA
        } else if (latitude > 49 && latitude < 70 && longitude > -140 && longitude < -50) {
          resolve('CA'); // Canadá
        } else if (latitude > -33 && latitude < 5 && longitude > -75 && longitude < -34) {
          resolve('BR'); // Brasil
        } else if (latitude > 36 && latitude < 70 && longitude > -10 && longitude < 40) {
          resolve('EU'); // Europa (simplificado)
        } else if (latitude > -35 && latitude < 37 && longitude > 112 && longitude < 154) {
          resolve('AU'); // Austrália
        } else {
          // Valor padrão para outras regiões
          resolve('US');
        }
      }, 50); // Atraso mínimo para simular processamento
    });
  }

  /**
   * Simula uma requisição de geocodificação reversa para obter endereço completo
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @returns {Promise<Object>} Detalhes do endereço
   */
  async simulateReverseGeocodingRequest(latitude, longitude) {
    return new Promise(resolve => {
      // Simular atraso de rede
      setTimeout(() => {
        // Exemplo de resposta para demonstração
        let address = {
          country: '',
          countryCode: '',
          state: '',
          city: '',
          district: '',
          street: '',
          houseNumber: '',
          zipCode: '',
          formattedAddress: ''
        };
        
        // Determinar país simulado com base nas coordenadas
        if (latitude > 0 && latitude < 15 && longitude > -100 && longitude < -80) {
          // México
          address = {
            country: 'México',
            countryCode: 'MX',
            state: 'Jalisco',
            city: 'Guadalajara',
            district: 'Centro',
            street: 'Av. Chapultepec',
            houseNumber: '123',
            zipCode: '44100',
            formattedAddress: 'Av. Chapultepec 123, Centro, Guadalajara, Jalisco, México'
          };
        } else if (latitude > 25 && latitude < 49 && longitude > -125 && longitude < -66) {
          // EUA
          address = {
            country: 'United States',
            countryCode: 'US',
            state: 'California',
            city: 'San Francisco',
            district: 'SoMa',
            street: 'Market St',
            houseNumber: '585',
            zipCode: '94105',
            formattedAddress: '585 Market St, San Francisco, CA 94105, USA'
          };
        } else if (latitude > -33 && latitude < 5 && longitude > -75 && longitude < -34) {
          // Brasil
          address = {
            country: 'Brasil',
            countryCode: 'BR',
            state: 'São Paulo',
            city: 'São Paulo',
            district: 'Vila Olímpia',
            street: 'Av. Brigadeiro Faria Lima',
            houseNumber: '3477',
            zipCode: '04538-133',
            formattedAddress: 'Av. Brigadeiro Faria Lima, 3477 - Vila Olímpia, São Paulo - SP, 04538-133, Brasil'
          };
        } else {
          // Padrão para outras regiões
          address = {
            country: 'United States',
            countryCode: 'US',
            state: 'New York',
            city: 'New York',
            district: 'Manhattan',
            street: 'Broadway',
            houseNumber: '1345',
            zipCode: '10018',
            formattedAddress: '1345 Broadway, New York, NY 10018, USA'
          };
        }
        
        resolve(address);
      }, 100);
    });
  }

  /**
   * Simula uma requisição de geocodificação a partir de um endereço
   * @param {string} address - Endereço a ser geocodificado
   * @returns {Promise<Object>} Resultado da geocodificação
   */
  async simulateGeocodingAddressRequest(address) {
    return new Promise(resolve => {
      // Simular atraso de rede
      setTimeout(() => {
        let result = {
          found: true,
          accuracy: 'high',
          latitude: 0,
          longitude: 0,
          formattedAddress: '',
          country: '',
          countryCode: '',
          state: '',
          city: ''
        };
        
        // Simulação básica baseada em palavras-chave no endereço
        if (address.includes('san francisco') || address.includes('california')) {
          result = {
            found: true,
            accuracy: 'high',
            latitude: 37.7749,
            longitude: -122.4194,
            formattedAddress: 'San Francisco, CA, USA',
            country: 'United States',
            countryCode: 'US',
            state: 'California',
            city: 'San Francisco'
          };
        } else if (address.includes('new york') || address.includes('manhattan')) {
          result = {
            found: true,
            accuracy: 'high',
            latitude: 40.7128,
            longitude: -74.0060,
            formattedAddress: 'New York, NY, USA',
            country: 'United States',
            countryCode: 'US',
            state: 'New York',
            city: 'New York'
          };
        } else if (address.includes('são paulo') || address.includes('sao paulo') || address.includes('brazil')) {
          result = {
            found: true,
            accuracy: 'high',
            latitude: -23.5505,
            longitude: -46.6333,
            formattedAddress: 'São Paulo, SP, Brasil',
            country: 'Brasil',
            countryCode: 'BR',
            state: 'São Paulo',
            city: 'São Paulo'
          };
        } else if (address.includes('mexico') || address.includes('guadalajara')) {
          result = {
            found: true,
            accuracy: 'high',
            latitude: 20.6597,
            longitude: -103.3496,
            formattedAddress: 'Guadalajara, Jalisco, México',
            country: 'México',
            countryCode: 'MX',
            state: 'Jalisco',
            city: 'Guadalajara'
          };
        } else {
          // Endereço não reconhecido
          result = {
            found: false,
            accuracy: 'none',
            latitude: null,
            longitude: null,
            formattedAddress: '',
            country: '',
            countryCode: '',
            state: '',
            city: ''
          };
        }
        
        resolve(result);
      }, 150);
    });
  }

  /**
   * Calcula a distância entre dois pontos geográficos (fórmula de Haversine)
   * @param {Object} point1 - Primeiro ponto {latitude, longitude}
   * @param {Object} point2 - Segundo ponto {latitude, longitude}
   * @returns {number} Distância em quilômetros
   */
  calculateDistance(point1, point2) {
    const R = 6371; // Raio da Terra em km
    const dLat = this.deg2rad(point2.latitude - point1.latitude);
    const dLon = this.deg2rad(point2.longitude - point1.longitude);
    
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(point1.latitude)) * Math.cos(this.deg2rad(point2.latitude)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distância em km
    
    return distance;
  }
  
  /**
   * Converte graus para radianos
   * @param {number} deg - Ângulo em graus
   * @returns {number} Ângulo em radianos
   */
  deg2rad(deg) {
    return deg * (Math.PI/180);
  }
}

// Criar uma instância singleton
const geocodingService = new GeocodingService();

export default geocodingService;
export const getCountryFromCoordinates = geocodingService.getCountryFromCoordinates.bind(geocodingService);