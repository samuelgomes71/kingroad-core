/**
 * DangerReportScreenPreview.js
 * 
 * Tela para visualização prévia e envio de relatórios de perigo
 * Permite ao usuário ver, editar e enviar informações sobre perigos na rota
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  Switch,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import MapView, { Marker } from 'react-native-maps';
import ImagePicker from 'react-native-image-picker';
import { useTheme } from '../contexts/ThemeContext';

// Importar serviços
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import DangerReportService from '../services/DangerReportService';
import LocationService from '../services/LocationService';
import UserService from '../services/UserService';

const DangerReportScreenPreview = ({ route, navigation }) => {
  const { theme } = useTheme();
  const { reportData } = route.params || { reportData: null };
  
  // Estado do relatório
  const [report, setReport] = useState(reportData || {
    type: 'roadwork',
    location: null,
    description: '',
    severity: 'medium',
    photos: [],
    isTemporary: true,
    estimatedDuration: '1d',
    anonymousReport: false,
    affectedLanes: 'partially',
    detourAvailable: false,
    detourDescription: '',
    validatedByUser: false
  });
  
  // Estados da UI
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [currentPosition, setCurrentPosition] = useState(null);
  const [mapReady, setMapReady] = useState(false);
  
  useEffect(() => {
    // Obter localização atual se não for fornecida
    if (!report.location) {
      getCurrentLocation();
    }
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Se necessário, atualizar algum estado baseado no idioma
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);
  
  const getCurrentLocation = async () => {
    setLoading(true);
    try {
      const position = await LocationService.getCurrentPosition();
      setCurrentPosition(position);
      setReport(prev => ({
        ...prev,
        location: position
      }));
      setLoading(false);
    } catch (error) {
      console.error('Erro ao obter localização:', error);
      setLoading(false);
      Alert.alert(
        t('alert.error'),
        t('error.location_access'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleTypeChange = (type) => {
    setReport(prev => ({
      ...prev,
      type
    }));
  };
  
  const handleSeverityChange = (severity) => {
    setReport(prev => ({
      ...prev,
      severity
    }));
  };
  
  const handleMapPress = (e) => {
    const { coordinate } = e.nativeEvent;
    setReport(prev => ({
      ...prev,
      location: coordinate
    }));
  };
  
  const handleAddPhoto = () => {
    const options = {
      title: t('screen.danger_report.select_photo'),
      cancelButtonTitle: t('button.cancel'),
      takePhotoButtonTitle: t('screen.danger_report.take_photo'),
      chooseFromLibraryButtonTitle: t('screen.danger_report.choose_from_library'),
      maxWidth: 1000,
      maxHeight: 1000,
      quality: 0.8
    };
    
    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        // Usuário cancelou
      } else if (response.error) {
        Alert.alert(
          t('alert.error'),
          t('error.photo_upload'),
          [{ text: t('button.ok') }]
        );
      } else {
        setReport(prev => ({
          ...prev,
          photos: [
            ...prev.photos, 
            { uri: response.uri, data: response.data }
          ]
        }));
      }
    });
  };
  
  const handleRemovePhoto = (index) => {
    setReport(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };
  
  const validateForm = () => {
    if (!report.location) {
      Alert.alert(
        t('alert.validation_error'),
        t('screen.danger_report.error_no_location'),
        [{ text: t('button.ok') }]
      );
      return false;
    }
    
    if (!report.description.trim()) {
      Alert.alert(
        t('alert.validation_error'),
        t('screen.danger_report.error_no_description'),
        [{ text: t('button.ok') }]
      );
      return false;
    }
    
    if (report.detourAvailable && !report.detourDescription.trim()) {
      Alert.alert(
        t('alert.validation_error'),
        t('screen.danger_report.error_no_detour_description'),
        [{ text: t('button.ok') }]
      );
      return false;
    }
    
    return true;
  };
  
  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    setSubmitting(true);
    try {
      // Enviar relatório para o serviço
      await DangerReportService.submitReport(report);
      
      setSubmitting(false);
      Alert.alert(
        t('alert.success'),
        t('screen.danger_report.report_submitted'),
        [
          { 
            text: t('button.ok'), 
            onPress: () => navigation.navigate('Home') 
          }
        ]
      );
    } catch (error) {
      console.error('Erro ao enviar relatório:', error);
      setSubmitting(false);
      Alert.alert(
        t('alert.error'),
        t('error.report_submission'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const getDangerTypeLabel = (type) => {
    const types = {
      'roadwork': t('screen.danger_report.type_roadwork'),
      'accident': t('screen.danger_report.type_accident'),
      'closure': t('screen.danger_report.type_closure'),
      'hazard': t('screen.danger_report.type_hazard'),
      'weather': t('screen.danger_report.type_weather'),
      'traffic': t('screen.danger_report.type_traffic'),
      'police': t('screen.danger_report.type_police'),
      'other': t('screen.danger_report.type_other')
    };
    
    return types[type] || type;
  };
  
  const getSeverityLabel = (severity) => {
    const severities = {
      'low': t('screen.danger_report.severity_low'),
      'medium': t('screen.danger_report.severity_medium'),
      'high': t('screen.danger_report.severity_high'),
      'extreme': t('screen.danger_report.severity_extreme')
    };
    
    return severities[severity] || severity;
  };
  
  const getLaneAffectionLabel = (affection) => {
    const affections = {
      'none': t('screen.danger_report.lanes_none'),
      'partially': t('screen.danger_report.lanes_partially'),
      'one_lane': t('screen.danger_report.lanes_one'),
      'multiple_lanes': t('screen.danger_report.lanes_multiple'),
      'all_lanes': t('screen.danger_report.lanes_all')
    };
    
    return affections[affection] || affection;
  };
  
  const getDurationLabel = (duration) => {
    const durations = {
      '1h': t('screen.danger_report.duration_1h'),
      '2h': t('screen.danger_report.duration_2h'),
      '4h': t('screen.danger_report.duration_4h'),
      '1d': t('screen.danger_report.duration_1d'),
      '2d': t('screen.danger_report.duration_2d'),
      '1w': t('screen.danger_report.duration_1w'),
      '2w': t('screen.danger_report.duration_2w'),
      '1m': t('screen.danger_report.duration_1m'),
      'unknown': t('screen.danger_report.duration_unknown')
    };
    
    return durations[duration] || duration;
  };
  
  const getDangerTypeIcon = (type) => {
    const icons = {
      'roadwork': 'construction',
      'accident': 'car-crash',
      'closure': 'block',
      'hazard': 'warning',
      'weather': 'cloudy',
      'traffic': 'traffic',
      'police': 'local-police',
      'other': 'help'
    };
    
    return icons[type] || 'warning';
  };
  
  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[styles.loadingText, { color: theme.text }]}>
          {t('screen.danger_report.loading')}
        </Text>
      </View>
    );
  }
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Mapa */}
          <View style={styles.mapContainer}>
            {report.location && (
              <MapView
                style={styles.map}
                initialRegion={{
                  latitude: report.location.latitude,
                  longitude: report.location.longitude,
                  latitudeDelta: 0.005,
                  longitudeDelta: 0.005
                }}
                onPress={handleMapPress}
                onMapReady={() => setMapReady(true)}
              >
                <Marker
                  coordinate={report.location}
                  title={t('screen.danger_report.danger_location')}
                  description={getDangerTypeLabel(report.type)}
                />
              </MapView>
            )}
            {!report.location && (
              <View style={[styles.noMapContainer, { backgroundColor: theme.cardDark }]}>
                <Icon name="location-off" size={40} color={theme.textSecondary} />
                <Text style={[styles.noMapText, { color: theme.textSecondary }]}>
                  {t('screen.danger_report.no_location')}
                </Text>
                <TouchableOpacity
                  style={[styles.getCurrentLocationButton, { backgroundColor: theme.primary }]}
                  onPress={getCurrentLocation}
                >
                  <Text style={styles.getCurrentLocationButtonText}>
                    {t('screen.danger_report.use_current_location')}
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
          
          {/* Tipo de perigo */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.danger_report.danger_type')}
            </Text>
            <View style={styles.dangerTypeContainer}>
              {['roadwork', 'accident', 'closure', 'hazard'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.dangerTypeButton,
                    report.type === type && { 
                      backgroundColor: theme.primaryLight,
                      borderColor: theme.primary 
                    },
                    { borderColor: theme.border }
                  ]}
                  onPress={() => handleTypeChange(type)}
                >
                  <Icon 
                    name={getDangerTypeIcon(type)} 
                    size={20} 
                    color={report.type === type ? theme.primary : theme.textSecondary} 
                  />
                  <Text 
                    style={[
                      styles.dangerTypeText, 
                      { color: report.type === type ? theme.primary : theme.text }
                    ]}
                  >
                    {getDangerTypeLabel(type)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <View style={styles.dangerTypeContainer}>
              {['weather', 'traffic', 'police', 'other'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.dangerTypeButton,
                    report.type === type && { 
                      backgroundColor: theme.primaryLight,
                      borderColor: theme.primary 
                    },
                    { borderColor: theme.border }
                  ]}
                  onPress={() => handleTypeChange(type)}
                >
                  <Icon 
                    name={getDangerTypeIcon(type)} 
                    size={20}
                    color={report.type === type ? theme.primary : theme.textSecondary} 
                  />
                  <Text 
                    style={[
                      styles.dangerTypeText, 
                      { color: report.type === type ? theme.primary : theme.text }
                    ]}
                  >
                    {getDangerTypeLabel(type)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          {/* Descrição */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.danger_report.description')}
            </Text>
            <TextInput
              style={[
                styles.descriptionInput, 
                { 
                  color: theme.text,
                  backgroundColor: theme.inputBackground,
                  borderColor: theme.border 
                }
              ]}
              multiline
              placeholder={t('screen.danger_report.description_placeholder')}
              placeholderTextColor={theme.textSecondary}
              value={report.description}
              onChangeText={(text) => setReport(prev => ({
                ...prev,
                description: text
              }))}
            />
          </View>
          
          {/* Severidade */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.danger_report.severity')}
            </Text>
            <View style={styles.severityContainer}>
              {['low', 'medium', 'high', 'extreme'].map(severity => (
                <TouchableOpacity
                  key={severity}
                  style={[
                    styles.severityButton,
                    report.severity === severity && { 
                      backgroundColor: 
                        severity === 'low' ? '#C8E6C9' :
                        severity === 'medium' ? '#FFE0B2' :
                        severity === 'high' ? '#FFCCBC' :
                        '#FFCDD2',
                      borderColor: 
                        severity === 'low' ? '#4CAF50' :
                        severity === 'medium' ? '#FF9800' :
                        severity === 'high' ? '#FF5722' :
                        '#F44336'
                    },
                    { borderColor: theme.border }
                  ]}
                  onPress={() => handleSeverityChange(severity)}
                >
                  <Text 
                    style={[
                      styles.severityText, 
                      { 
                        color: report.severity === severity ?
                          severity === 'low' ? '#2E7D32' :
                          severity === 'medium' ? '#E65100' :
                          severity === 'high' ? '#BF360C' :
                          '#B71C1C'
                          : theme.text
                      }
                    ]}
                  >
                    {getSeverityLabel(severity)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          {/* Fotos */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.danger_report.photos')}
            </Text>
            <View style={styles.photosContainer}>
              {report.photos.map((photo, index) => (
                <View key={index} style={styles.photoItem}>
                  <Image source={{ uri: photo.uri }} style={styles.photoThumbnail} />
                  <TouchableOpacity
                    style={styles.removePhotoButton}
                    onPress={() => handleRemovePhoto(index)}
                  >
                    <Icon name="close" size={16} color="white" />
                  </TouchableOpacity>
                </View>
              ))}
              
              <TouchableOpacity
                style={[styles.addPhotoButton, { borderColor: theme.border }]}
                onPress={handleAddPhoto}
              >
                <Icon name="add-a-photo" size={24} color={theme.textSecondary} />
                <Text style={[styles.addPhotoText, { color: theme.textSecondary }]}>
                  {t('screen.danger_report.add_photo')}
                </Text>
              </TouchableOpacity>
            </View>
            
            <Text style={[styles.photoHelp, { color: theme.textSecondary }]}>
              {t('screen.danger_report.photo_help')}
            </Text>
          </View>
          
          {/* Detalhes adicionais */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.danger_report.additional_details')}
            </Text>
            
            {/* Relatório temporário */}
            <View style={styles.optionRow}>
              <View style={styles.optionLabelContainer}>
                <Text style={[styles.optionLabel, { color: theme.text }]}>
                  {t('screen.danger_report.temporary_hazard')}
                </Text>
                <Text style={[styles.optionDescription, { color: theme.textSecondary }]}>
                  {t('screen.danger_report.temporary_description')}
                </Text>
              </View>
              <Switch
                value={report.isTemporary}
                onValueChange={(value) => setReport(prev => ({
                  ...prev,
                  isTemporary: value
                }))}
                trackColor={{ false: "#767577", true: theme.primaryLight }}
                thumbColor={report.isTemporary ? theme.primary : "#f4f3f4"}
              />
            </View>
            
            {/* Duração estimada (só mostra se for temporário) */}
            {report.isTemporary && (
              <View style={styles.durationContainer}>
                <Text style={[styles.durationLabel, { color: theme.text }]}>
                  {t('screen.danger_report.estimated_duration')}
                </Text>
                <View style={styles.durationOptions}>
                  {['1h', '4h', '1d', '1w', 'unknown'].map(duration => (
                    <TouchableOpacity
                      key={duration}
                      style={[
                        styles.durationButton,
                        report.estimatedDuration === duration && { 
                          backgroundColor: theme.primaryLight,
                          borderColor: theme.primary 
                        },
                        { borderColor: theme.border }
                      ]}
                      onPress={() => setReport(prev => ({
                        ...prev,
                        estimatedDuration: duration
                      }))}
                    >
                      <Text 
                        style={[
                          styles.durationButtonText, 
                          { color: report.estimatedDuration === duration ? theme.primary : theme.text }
                        ]}
                      >
                        {getDurationLabel(duration)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}
            
            {/* Faixas afetadas */}
            <View style={styles.lanesContainer}>
              <Text style={[styles.lanesLabel, { color: theme.text }]}>
                {t('screen.danger_report.affected_lanes')}
              </Text>
              <View style={styles.lanesOptions}>
                {['none', 'partially', 'one_lane', 'all_lanes'].map(lanes => (
                  <TouchableOpacity
                    key={lanes}
                    style={[
                      styles.laneButton,
                      report.affectedLanes === lanes && { 
                        backgroundColor: theme.primaryLight,
                        borderColor: theme.primary 
                      },
                      { borderColor: theme.border }
                    ]}
                    onPress={() => setReport(prev => ({
                      ...prev,
                      affectedLanes: lanes
                    }))}
                  >
                    <Text 
                      style={[
                        styles.laneButtonText, 
                        { color: report.affectedLanes === lanes ? theme.primary : theme.text }
                      ]}
                    >
                      {getLaneAffectionLabel(lanes)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            
            {/* Desvio disponível */}
            <View style={styles.optionRow}>
              <View style={styles.optionLabelContainer}>
                <Text style={[styles.optionLabel, { color: theme.text }]}>
                  {t('screen.danger_report.detour_available')}
                </Text>
                <Text style={[styles.optionDescription, { color: theme.textSecondary }]}>
                  {t('screen.danger_report.detour_description_label')}
                </Text>
              </View>
              <Switch
                value={report.detourAvailable}
                onValueChange={(value) => setReport(prev => ({
                  ...prev,
                  detourAvailable: value
                }))}
                trackColor={{ false: "#767577", true: theme.primaryLight }}
                thumbColor={report.detourAvailable ? theme.primary : "#f4f3f4"}
              />
            </View>
            
            {/* Descrição do desvio (só mostra se houver desvio) */}
            {report.detourAvailable && (
              <TextInput
                style={[
                  styles.detourInput, 
                  { 
                    color: theme.text,
                    backgroundColor: theme.inputBackground,
                    borderColor: theme.border 
                  }
                ]}
                multiline
                placeholder={t('screen.danger_report.detour_placeholder')}
                placeholderTextColor={theme.textSecondary}
                value={report.detourDescription}
                onChangeText={(text) => setReport(prev => ({
                  ...prev,
                  detourDescription: text
                }))}
              />
            )}
            
            {/* Relatório anônimo */}
            <View style={styles.optionRow}>
              <View style={styles.optionLabelContainer}>
                <Text style={[styles.optionLabel, { color: theme.text }]}>
                  {t('screen.danger_report.anonymous_report')}
                </Text>
                <Text style={[styles.optionDescription, { color: theme.textSecondary }]}>
                  {t('screen.danger_report.anonymous_description')}
                </Text>
              </View>
              <Switch
                value={report.anonymousReport}
                onValueChange={(value) => setReport(prev => ({
                  ...prev,
                  anonymousReport: value
                }))}
                trackColor={{ false: "#767577", true: theme.primaryLight }}
                thumbColor={report.anonymousReport ? theme.primary : "#f4f3f4"}
              />
            </View>
          </View>
          
          {/* Confirmação */}
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <View style={styles.confirmRow}>
              <Switch
                value={report.validatedByUser}
                onValueChange={(value) => setReport(prev => ({
                  ...prev,
                  validatedByUser: value
                }))}
                trackColor={{ false: "#767577", true: theme.primaryLight }}
                thumbColor={report.validatedByUser ? theme.primary : "#f4f3f4"}
              />
              <Text style={[styles.confirmText, { color: theme.text }]}>
                {t('screen.danger_report.confirm_accurate')}
              </Text>
            </View>
          </View>
          
          {/* Botões de ação */}
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.cancelButton, { borderColor: theme.border }]}
              onPress={() => navigation.goBack()}
            >
              <Text style={[styles.cancelButtonText, { color: theme.text }]}>
                {t('button.cancel')}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.submitButton, 
                { backgroundColor: theme.primary },
                (!report.validatedByUser || submitting) && { opacity: 0.5 }
              ]}
              onPress={handleSubmit}
              disabled={!report.validatedByUser || submitting}
            >
              {submitting ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <Text style={styles.submitButtonText}>
                  {t('button.submit')}
                </Text>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
  },
  section: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.18,
    shadowRadius: 1.00,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  mapContainer: {
    height: 200,
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 16,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  noMapContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  noMapText: {
    marginTop: 8,
    textAlign: 'center',
    marginBottom: 16,
  },
  getCurrentLocationButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
  },
  getCurrentLocationButtonText: {
    color: 'white',
    fontWeight: '500',
  },
  dangerTypeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  dangerTypeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 4,
    borderWidth: 1,
    marginBottom: 8,
    width: '48%',
  },
  dangerTypeText: {
    marginLeft: 8,
    fontSize: 14,
  },
  descriptionInput: {
    borderWidth: 1,
    borderRadius: 4,
    padding: 12,
    height: 100,
    textAlignVertical: 'top',
  },
  severityContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  severityButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderRadius: 4,
    borderWidth: 1,
    marginHorizontal: 4,
  },
  severityText: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  photosContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  photoItem: {
    width: 80,
    height: 80,
    borderRadius: 4,
    marginRight: 8,
    marginBottom: 8,
    position: 'relative',
  },
  photoThumbnail: {
    width: '100%',
    height: '100%',
    borderRadius: 4,
  },
  removePhotoButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addPhotoButton: {
    width: 80,
    height: 80,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addPhotoText: {
    fontSize: 10,
    marginTop: 4,
    textAlign: 'center',
  },
  photoHelp: {
    fontSize: 12,
    marginTop: 8,
    fontStyle: 'italic',
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  optionLabelContainer: {
    flex: 1,
    marginRight: 16,
  },
  optionLabel: {
    fontSize: 16,
  },
  optionDescription: {
    fontSize: 12,
    marginTop: 2,
  },
  durationContainer: {
    marginBottom: 16,
  },
  durationLabel: {
    fontSize: 16,
    marginBottom: 8,
  },
  durationOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  durationButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
    borderWidth: 1,
    marginRight: 8,
    marginBottom: 8,
  },
  durationButtonText: {
    fontSize: 12,
  },
  lanesContainer: {
    marginBottom: 16,
  },
  lanesLabel: {
    fontSize: 16,
    marginBottom: 8,
  },
  lanesOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  laneButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
    borderWidth: 1,
    marginRight: 8,
    marginBottom: 8,
  },
  laneButtonText: {
    fontSize: 12,
  },
  detourInput: {
    borderWidth: 1,
    borderRadius: 4,
    padding: 12,
    height: 80,
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  confirmRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  confirmText: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  cancelButton: {
    flex: 1,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    marginRight: 8,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '500',
  },
  submitButton: {
    flex: 2,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  }
});

export default DangerReportScreenPreview;