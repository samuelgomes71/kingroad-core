import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class SendAlertActivity : AppCompatActivity() {

    private lateinit var alertTypeSpinner: Spinner
    private lateinit var alertDetailsInput: EditText
    private lateinit var alertRadiusSpinner: Spinner
    private lateinit var sendAlertButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send_alert)

        alertTypeSpinner = findViewById(R.id.alert_type_spinner)
        val alertTypes = arrayOf("Caminhão desgovernado", "Acidente na pista", "Congestionamento", "Outro")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, alertTypes)
        alertTypeSpinner.adapter = adapter

        alertDetailsInput = findViewById(R.id.alert_details_input)
        
        alertRadiusSpinner = findViewById(R.id.alert_radius_spinner)
        val radiusOptions = arrayOf("5 km", "10 km", "20 km")
        val radiusAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, radiusOptions)
        alertRadiusSpinner.adapter = radiusAdapter
        
        sendAlertButton = findViewById(R.id.send_alert_button)
        sendAlertButton.setOnClickListener { 
            val alertType = alertTypeSpinner.selectedItem.toString()
            val alertDetails = alertDetailsInput.text.toString()
            val alertRadius = alertRadiusSpinner.selectedItem.toString()
            
            sendAlert(alertType, alertDetails, alertRadius)
        }
    }

    private fun sendAlert(type: String, details: String, radius: String) {
        // Lógica para enviar o alerta aqui
        // ...
    }
}