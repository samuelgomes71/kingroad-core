import React, { useState, useEffect } from 'react';
import { MapPin, Utensils, DollarSign, Star, Clock, AlertTriangle, Bus, Car, Truck, ChevronRight, Info } from 'lucide-react';

// Componente com abas para diferentes tipos de paradas
const VehicleSpecificStops = ({ route, vehicleType, onSelectStop }) => {
  const [stops, setStops] = useState({
    recommended: [],
    required: [],
    avoid: []
  });
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState('recommended');
  
  useEffect(() => {
    // Simula busca de paradas da API baseado no tipo de veículo
    const fetchStops = async () => {
      setLoading(true);
      
      // Simulação de dados para demonstração
      setTimeout(() => {
        // Paradas de caminhoneiros (boas e baratas)
        const truckStops = [
          {
            id: 'ts-001',
            name: 'Restaurante Parada do Caminhoneiro',
            distance: 2.3,
            rating: 4.7,
            priceLevel: 1, // $ = Barato
            openNow: true,
            foodType: 'Brasileira',
            specialty: 'PF do Caminhoneiro',
            coords: { lat: -23.5505, lng: -46.6333 }
          },
          {
            id: 'ts-002',
            name: 'Rancho da Parada',
            distance: 0.8,
            rating: 4.5,
            priceLevel: 1,
            openNow: true,
            foodType: 'Mineira',
            specialty: 'Feijão Tropeiro',
            coords: { lat: -23.5605, lng: -46.6433 }
          }
        ];
        
        // Paradas de ônibus (caras e obrigatórias para ônibus)
        const busStops = [
          {
            id: 'bs-001',
            name: 'Terminal Rodoviário Tietê',
            distance: 1.5,
            rating: 3.8,
            priceLevel: 3, // $$$ = Caro
            openNow: true,
            required: true,
            foodType: 'Diversa',
            specialty: 'Praça de Alimentação',
            coords: { lat: -23.5165, lng: -46.6221 }
          },
          {
            id: 'bs-002',
            name: 'Parada Obrigatória Ônibus',
            distance: 4.2,
            rating: 3.2,
            priceLevel: 3,
            openNow: true,
            required: true,
            foodType: 'Lanches',
            specialty: 'Refeições Rápidas',
            coords: { lat: -23.5105, lng: -46.6123 }
          }
        ];
        
        // Configura as paradas com base no tipo de veículo
        let stopsData = {
          recommended: [],
          required: [],
          avoid: []
        };
        
        switch(vehicleType) {
          case 'car':
            stopsData.recommended = truckStops;
            stopsData.avoid = busStops;
            break;
          case 'bus':
            stopsData.required = busStops;
            stopsData.recommended = [];
            break;
          case 'truck':
          default:
            stopsData.recommended = truckStops;
            break;
        }
        
        setStops(stopsData);
        setLoading(false);
        
        // Define a aba ativa com base no conteúdo disponível
        if (vehicleType === 'bus' && busStops.length > 0) {
          setActiveTab('required');
        } else {
          setActiveTab('recommended');
        }
      }, 1000);
    };
    
    fetchStops();
  }, [route, vehicleType]);
  
  // Renderiza o indicador de preço ($, $$, $$$)
  const renderPriceLevel = (level) => {
    const dollars = [];
    for (let i = 0; i < 3; i++) {
      dollars.push(
        <DollarSign 
          key={i} 
          size={14} 
          className={i < level ? (level >= 3 ? 'text-red-500' : 'text-green-500') : 'text-gray-400'} 
        />
      );
    }
    return <div className="flex">{dollars}</div>;
  };
  
  // Renderiza a classificação de estrelas
  const renderRating = (rating) => {
    return (
      <div className="flex items-center text-yellow-500">
        <Star size={14} className="fill-current" />
        <span className="ml-1 text-sm">{rating.toFixed(1)}</span>
      </div>
    );
  };
  
  // Renderiza o ícone e título baseado no tipo de veículo
  const renderHeader = () => {
    let icon, title, bgColor;
    
    switch(vehicleType) {
      case 'car':
        icon = <Car className="mr-2" size={18} />;
        title = "Paradas Recomendadas para Carros";
        bgColor = "bg-blue-700";
        break;
      case 'bus':
        icon = <Bus className="mr-2" size={18} />;
        title = "Paradas para Ônibus";
        bgColor = "bg-purple-700";
        break;
      case 'truck':
      default:
        icon = <Truck className="mr-2" size={18} />;
        title = "Paradas de Caminhoneiros";
        bgColor = "bg-green-700";
    }
    
    return (
      <div className={`flex justify-between items-center p-3 ${bgColor} text-white cursor-pointer`}>
        <div className="flex items-center">
          {icon}
          <h3 className="font-bold">{title}</h3>
        </div>
        <ChevronRight 
          size={20} 
          className={`transition-transform transform ${expanded ? 'rotate-90' : ''}`}
        />
      </div>
    );
  };
  
  // Renderiza as abas para os diferentes tipos de paradas
  const renderTabs = () => {
    return (
      <div className="flex border-b">
        {stops.recommended.length > 0 && (
          <button
            className={`flex-1 py-2 text-center text-sm font-medium ${
              activeTab === 'recommended' 
                ? 'border-b-2 border-blue-500 text-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('recommended')}
          >
            Recomendadas
          </button>
        )}
        
        {stops.required.length > 0 && (
          <button
            className={`flex-1 py-2 text-center text-sm font-medium ${
              activeTab === 'required' 
                ? 'border-b-2 border-purple-500 text-purple-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('required')}
          >
            Obrigatórias
          </button>
        )}
        
        {vehicleType === 'car' && stops.avoid.length > 0 && (
          <button
            className={`flex-1 py-2 text-center text-sm font-medium ${
              activeTab === 'avoid' 
                ? 'border-b-2 border-red-500 text-red-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('avoid')}
          >
            Evitar
          </button>
        )}
      </div>
    );
  };
  
  // Renderiza a mensagem informativa para cada tipo de parada
  const renderInfoMessage = () => {
    if (activeTab === 'recommended') {
      return (
        <div className="mb-3 flex items-start p-2 bg-blue-50 text-sm text-blue-800 rounded">
          <Info size={16} className="mr-2 mt-0.5 flex-shrink-0" />
          <span>Restaurantes frequentados por caminhoneiros - comida boa e preço acessível!</span>
        </div>
      );
    } else if (activeTab === 'required' && vehicleType === 'bus') {
      return (
        <div className="mb-3 flex items-start p-2 bg-purple-50 text-sm text-purple-800 rounded">
          <Info size={16} className="mr-2 mt-0.5 flex-shrink-0" />
          <span>Paradas obrigatórias para ônibus conforme regulamentações de transporte.</span>
        </div>
      );
    } else if (activeTab === 'avoid') {
      return (
        <div className="mb-3 flex items-start p-2 bg-red-50 text-sm text-red-800 rounded">
          <AlertTriangle size={16} className="mr-2 mt-0.5 flex-shrink-0" />
          <span>Paradas de ônibus geralmente têm preços mais elevados - recomendamos evitar.</span>
        </div>
      );
    }
    return null;
  };
  
  // Renderiza a lista de paradas
  const renderStopsList = (stopsArray) => {
    if (stopsArray.length === 0) {
      return (
        <div className="p-4 text-center text-gray-500">
          Nenhuma parada encontrada nesta categoria.
        </div>
      );
    }
    
    return (
      <div className="space-y-3">
        {stopsArray.map(stop => (
          <div 
            key={stop.id}
            className={`border rounded-md p-3 hover:bg-gray-50 cursor-pointer ${
              stop.required ? 'border-purple-200 bg-purple-50' : 'border-gray-200'
            }`}
            onClick={() => onSelectStop(stop)}
          >
            <div className="flex justify-between">
              <div className="font-medium">{stop.name}</div>
              <div className="text-sm text-blue-600">{stop.distance} km</div>
            </div>
            
            <div className="mt-1 text-sm text-gray-600">
              {stop.foodType} • {stop.specialty}
            </div>
            
            <div className="mt-2 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                {renderRating(stop.rating)}
                {renderPriceLevel(stop.priceLevel)}
              </div>
              
              <div className="flex items-center">
                {stop.required && (
                  <span className="mr-2 text-xs px-2 py-0.5 bg-purple-100 text-purple-800 rounded">
                    Obrigatória
                  </span>
                )}
                <span className={`text-xs px-2 py-0.5 rounded ${
                  stop.openNow ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {stop.openNow ? 'Aberto' : 'Fechado'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };
  
  // Componente principal
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-4">
      {/* Cabeçalho */}
      <div onClick={() => setExpanded(!expanded)}>
        {renderHeader()}
      </div>
      
      {/* Corpo expandido */}
      {expanded && (
        <div>
          {/* Abas de navegação */}
          {!loading && renderTabs()}
          
          {/* Conteúdo */}
          <div className="p-3">
            {loading ? (
              <div className="flex justify-center items-center py-6">
                <div className="w-6 h-6 border-2 border-t-blue-500 border-blue-200 rounded-full animate-spin"></div>
                <span className="ml-2 text-gray-600">Buscando paradas...</span>
              </div>
            ) : (
              <>
                {renderInfoMessage()}
                
                {activeTab === 'recommended' && renderStopsList(stops.recommended)}
                {activeTab === 'required' && renderStopsList(stops.required)}
                {activeTab === 'avoid' && renderStopsList(stops.avoid)}
                
                {activeTab !== 'avoid' && stops[activeTab].length > 0 && (
                  <button 
                    className="mt-3 w-full py-2 text-center text-blue-700 font-medium border border-blue-700 rounded-md hover:bg-blue-50"
                  >
                    Ver mais paradas
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleSpecificStops;