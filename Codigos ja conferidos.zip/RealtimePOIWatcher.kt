package com.kingroad.services

import android.content.Context
import android.location.Location
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.kingroad.database.POI
import com.kingroad.database.POIDao
import com.kingroad.utils.DistanceCalculator
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.concurrent.TimeUnit

/**
 * Observa atualizações de POIs feitas por outros motoristas em tempo real 
 * e atualiza a interface local sem recarregar.
 */
class RealtimePOIWatcher(
    private val context: Context,
    private val poiDao: POIDao,
    private val apiBaseUrl: String,
    private val apiKey: String? = null,
    private val websocketUrl: String? = null,
    private val firebaseEnabled: Boolean = true,
    private val distanceCalculator: DistanceCalculator? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "RealtimePOIWatcher"
        
        // Intervalo de polling para API REST (15 segundos)
        private const val REST_POLLING_INTERVAL = 15000L
        
        // Distância máxima para monitoramento de POIs (50km)
        private const val DEFAULT_MAX_DISTANCE_KM = 50.0
        
        // Tipos de POI
        enum class POIUpdateType {
            ADDED,    // Novo POI adicionado
            UPDATED,  // POI existente atualizado
            DELETED,  // POI removido
            NEARBY    // POI próximo detectado
        }
    }
    
    // Estado do watcher
    private val _watcherState = MutableStateFlow<WatcherState>(WatcherState.Stopped)
    val watcherState: StateFlow<WatcherState> = _watcherState.asStateFlow()
    
    // POIs recentemente atualizados
    private val _recentUpdates = MutableLiveData<List<POIUpdate>>(emptyList())
    val recentUpdates: LiveData<List<POIUpdate>> = _recentUpdates
    
    // POIs próximos que foram detectados
    private val _nearbyPOIs = MutableLiveData<List<POI>>(emptyList())
    val nearbyPOIs: LiveData<List<POI>> = _nearbyPOIs
    
    // Firebase listeners
    private var firebaseListener: ChildEventListener? = null
    
    // WebSocket
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient.Builder()
        .readTimeout(30, TimeUnit.SECONDS)
        .connectTimeout(30, TimeUnit.SECONDS)
        .build()
    
    // Thread de polling REST
    private var restPollingThread: Thread? = null
    private var isRestPollingActive = false
    
    // Timestamp da última atualização
    private var lastUpdateTimestamp = 0L
    
    // Configurações
    private var maxDistanceKm = DEFAULT_MAX_DISTANCE_KM
    private var currentLocation: Location? = null
    private var watchedCategories = setOf<String>() // Categorias de POI para monitorar
    private var notifyAllUpdates = false // Se true, notifica todas as atualizações, não apenas as próximas
    
    init {
        // Inicializa o timestamp com hora atual
        lastUpdateTimestamp = System.currentTimeMillis()
    }
    
    /**
     * Inicia o monitoramento de POIs
     * 
     * @param location Localização atual para filtrar POIs por proximidade
     * @param categories Categorias de POI para monitorar (vazio = todas)
     * @param maxDistance Distância máxima em KM (0 = sem limite)
     * @param method Método de monitoramento (Firebase, WebSocket, REST ou ALL)
     * @param notifyAll Se true, notifica todas as atualizações, não apenas as próximas
     * @return true se iniciado com sucesso
     */
    fun startWatching(
        location: Location? = null,
        categories: Set<String> = emptySet(),
        maxDistance: Double = DEFAULT_MAX_DISTANCE_KM,
        method: MonitoringMethod = MonitoringMethod.ALL,
        notifyAll: Boolean = false
    ): Boolean {
        // Verifica se já está monitorando
        if (_watcherState.value is WatcherState.Watching) {
            Log.w(TAG, "Já está monitorando POIs. Pare primeiro.")
            return false
        }
        
        try {
            // Atualiza configurações
            currentLocation = location
            watchedCategories = categories
            maxDistanceKm = maxDistance
            notifyAllUpdates = notifyAll
            
            // Limpa listas
            _recentUpdates.postValue(emptyList())
            
            // Inicia os métodos solicitados
            var methodStarted = false
            
            if (method == MonitoringMethod.FIREBASE || method == MonitoringMethod.ALL) {
                if (startFirebaseWatcher()) {
                    methodStarted = true
                }
            }
            
            if (method == MonitoringMethod.WEBSOCKET || method == MonitoringMethod.ALL) {
                if (startWebSocketWatcher()) {
                    methodStarted = true
                }
            }
            
            if (method == MonitoringMethod.REST || method == MonitoringMethod.ALL) {
                if (startRestWatcher()) {
                    methodStarted = true
                }
            }
            
            // Atualiza estado
            if (methodStarted) {
                _watcherState.value = WatcherState.Watching(method)
                Log.d(TAG, "Monitoramento de POIs iniciado: método=$method")
                
                // Carrega POIs próximos inicialmente
                if (currentLocation != null) {
                    scope.launch {
                        loadNearbyPOIs()
                    }
                }
                
                return true
            } else {
                _watcherState.value = WatcherState.Error("Não foi possível iniciar nenhum método de monitoramento")
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar monitoramento: ${e.message}", e)
            _watcherState.value = WatcherState.Error(e.message ?: "Erro desconhecido")
            return false
        }
    }
    
    /**
     * Para o monitoramento de POIs
     */
    fun stopWatching() {
        try {
            // Para Firebase
            stopFirebaseWatcher()
            
            // Para WebSocket
            stopWebSocketWatcher()
            
            // Para polling REST
            stopRestWatcher()
            
            // Atualiza estado
            _watcherState.value = WatcherState.Stopped
            Log.d(TAG, "Monitoramento de POIs parado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar monitoramento: ${e.message}", e)
            _watcherState.value = WatcherState.Error(e.message ?: "Erro ao parar monitoramento")
        }
    }
    
    /**
     * Atualiza a localização atual (para filtro de proximidade)
     */
    fun updateLocation(location: Location) {
        currentLocation = location
        
        // Se estiver monitorando, atualiza POIs próximos
        if (_watcherState.value is WatcherState.Watching) {
            scope.launch {
                loadNearbyPOIs()
            }
        }
    }
    
    /**
     * Inicia monitoramento via Firebase
     */
    private fun startFirebaseWatcher(): Boolean {
        if (!firebaseEnabled) {
            Log.w(TAG, "Firebase não está habilitado")
            return false
        }
        
        try {
            // Referência para o nó de POIs
            val poiRef = FirebaseDatabase.getInstance().getReference("pois")
            
            // Cria listener para novas atualizações
            firebaseListener = object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    handleFirebasePOI(snapshot, POIUpdateType.ADDED)
                }
                
                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    handleFirebasePOI(snapshot, POIUpdateType.UPDATED)
                }
                
                override fun onChildRemoved(snapshot: DataSnapshot) {
                    handleFirebasePOI(snapshot, POIUpdateType.DELETED)
                }
                
                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                    // Não é relevante para POIs
                }
                
                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "Erro no listener Firebase: ${error.message}")
                }
            }
            
            // Adiciona o listener
            poiRef.addChildEventListener(firebaseListener!!)
            
            // Adiciona listener de valor único para carregar POIs existentes
            if (notifyAllUpdates) {
                poiRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        snapshot.children.forEach { child ->
                            handleFirebasePOI(child, POIUpdateType.ADDED)
                        }
                    }
                    
                    override fun onCancelled(error: DatabaseError) {
                        Log.e(TAG, "Erro ao carregar POIs existentes: ${error.message}")
                    }
                })
            }
            
            Log.d(TAG, "Monitoramento Firebase iniciado")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar monitoramento Firebase: ${e.message}", e)
            return false
        }
    }
    
    /**
     * Para monitoramento via Firebase
     */
    private fun stopFirebaseWatcher() {
        try {
            // Remove listener
            if (firebaseListener != null) {
                FirebaseDatabase.getInstance().getReference("pois")
                    .removeEventListener(firebaseListener!!)
                firebaseListener = null
            }
            
            Log.d(TAG, "Monitoramento Firebase parado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar monitoramento Firebase: ${e.message}", e)
        }
    }
    
    /**
     * Processa um POI recebido do Firebase
     */
    private fun handleFirebasePOI(snapshot: DataSnapshot, updateType: POIUpdateType) {
        try {
            // Extrai dados
            val poiId = snapshot.key ?: return
            val poiData = snapshot.value as? Map<*, *> ?: return
            
            // Mapeia para objeto POI
            val poi = mapToPOI(poiId, poiData)
            
            // Processa o POI
            processPOIUpdate(poi, updateType)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar POI do Firebase: ${e.message}", e)
        }
    }
    
    /**
     * Inicia monitoramento via WebSocket
     */
    private fun startWebSocketWatcher(): Boolean {
        if (websocketUrl == null) {
            Log.w(TAG, "URL do WebSocket não configurada")
            return false
        }
        
        try {
            // Cria e configura conexão
            val request = Request.Builder()
                .url(websocketUrl)
                .build()
            
            // Listener de eventos do WebSocket
            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    Log.d(TAG, "WebSocket conectado")
                    
                    // Envia mensagem de inscrição
                    val subscribeMessage = JSONObject().apply {
                        put("type", "subscribe")
                        put("topic", "pois")
                        
                        // Adiciona filtros
                        if (watchedCategories.isNotEmpty()) {
                            val categoriesArray = JSONArray()
                            watchedCategories.forEach { categoriesArray.put(it) }
                            put("categories", categoriesArray)
                        }
                        
                        if (currentLocation != null) {
                            put("latitude", currentLocation!!.latitude)
                            put("longitude", currentLocation!!.longitude)
                            put("maxDistance", maxDistanceKm)
                        }
                        
                        put("notifyAll", notifyAllUpdates)
                    }
                    
                    webSocket.send(subscribeMessage.toString())
                }
                
                override fun onMessage(webSocket: WebSocket, text: String) {
                    Log.d(TAG, "Mensagem recebida no WebSocket: $text")
                    
                    try {
                        val message = JSONObject(text)
                        val type = message.optString("type")
                        
                        if (type == "poi_update") {
                            val updateType = when (message.optString("updateType")) {
                                "added" -> POIUpdateType.ADDED
                                "updated" -> POIUpdateType.UPDATED
                                "deleted" -> POIUpdateType.DELETED
                                "nearby" -> POIUpdateType.NEARBY
                                else -> POIUpdateType.UPDATED
                            }
                            
                            val poiData = message.optJSONObject("poi")
                            if (poiData != null) {
                                val poi = jsonToPOI(poiData)
                                if (poi != null) {
                                    processPOIUpdate(poi, updateType)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro ao processar mensagem do WebSocket: ${e.message}", e)
                    }
                }
                
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket fechando: $code - $reason")
                    webSocket.close(1000, null)
                }
                
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket fechado: $code - $reason")
                }
                
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.e(TAG, "Falha no WebSocket: ${t.message}")
                }
            }
            
            // Inicia conexão
            webSocket = okHttpClient.newWebSocket(request, listener)
            
            Log.d(TAG, "Monitoramento WebSocket iniciado")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar monitoramento WebSocket: ${e.message}", e)
            return false
        }
    }
    
    /**
     * Para monitoramento via WebSocket
     */
    private fun stopWebSocketWatcher() {
        try {
            // Fecha WebSocket
            webSocket?.let {
                it.close(1000, "Monitoramento parado pelo usuário")
                webSocket = null
            }
            
            Log.d(TAG, "Monitoramento WebSocket parado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar monitoramento WebSocket: ${e.message}", e)
        }
    }
    
    /**
     * Inicia monitoramento via REST (polling)
     */
    private fun startRestWatcher(): Boolean {
        try {
            // Define flag para thread de polling
            isRestPollingActive = true
            
            // Cria thread de polling
            restPollingThread = Thread {
                while (isRestPollingActive) {
                    try {
                        // Faz requisição para API
                        val pois = fetchPOIsFromREST()
                        
                        // Processa POIs recebidos
                        pois.forEach { poi ->
                            processPOIUpdate(poi, POIUpdateType.UPDATED)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro no polling REST: ${e.message}", e)
                    }
                    
                    // Aguarda intervalo
                    try {
                        Thread.sleep(REST_POLLING_INTERVAL)
                    } catch (e: InterruptedException) {
                        // Thread interrompida, sai do loop
                        break
                    }
                }
            }.apply {
                name = "POI-REST-Polling"
                isDaemon = true
                start()
            }
            
            Log.d(TAG, "Monitoramento REST iniciado")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar monitoramento REST: ${e.message}", e)
            return false
        }
    }
    
    /**
     * Para monitoramento via REST
     */
    private fun stopRestWatcher() {
        try {
            // Define flag para parar thread
            isRestPollingActive = false
            
            // Interrompe thread
            restPollingThread?.interrupt()
            restPollingThread = null
            
            Log.d(TAG, "Monitoramento REST parado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar monitoramento REST: ${e.message}", e)
        }
    }
    
    /**
     * Busca POIs da API REST
     */
    private fun fetchPOIsFromREST(): List<POI> {
        try {
            // Constrói URL com filtros
            var urlStr = "$apiBaseUrl/api/pois?since=${lastUpdateTimestamp}"
            
            if (watchedCategories.isNotEmpty()) {
                urlStr += "&categories=${watchedCategories.joinToString(",")}"
            }
            
            if (currentLocation != null && maxDistanceKm > 0) {
                urlStr += "&latitude=${currentLocation!!.latitude}" +
                          "&longitude=${currentLocation!!.longitude}" +
                          "&maxDistance=$maxDistanceKm"
            }
            
            // Adiciona parâmetro para todos os POIs ou só atualizações
            urlStr += "&notifyAll=${notifyAllUpdates}"
            
            val url = URL(urlStr)
            val connection = url.openConnection() as HttpURLConnection
            
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "Erro na requisição REST: $responseCode")
                return emptyList()
            }
            
            // Lê resposta
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val response = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                response.append(line)
            }
            reader.close()
            
            // Parse da resposta JSON
            val jsonArray = JSONArray(response.toString())
            val pois = mutableListOf<POI>()
            
            for (i in 0 until jsonArray.length()) {
                val poiJson = jsonArray.getJSONObject(i)
                val poi = jsonToPOI(poiJson)
                if (poi != null) {
                    pois.add(poi)
                }
            }
            
            // Atualiza o timestamp
            lastUpdateTimestamp = System.currentTimeMillis()
            
            return pois
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao buscar POIs via REST: ${e.message}", e)
            return emptyList()
        }
    }
    
    /**
     * Carrega POIs próximos do banco de dados local
     */
    private suspend fun loadNearbyPOIs() = withContext(dispatcher) {
        if (currentLocation == null) {
            _nearbyPOIs.postValue(emptyList())
            return@withContext
        }
        
        try {
            // Busca POIs próximos
            val location = currentLocation!!
            val pois = if (watchedCategories.isEmpty()) {
                poiDao.getNearbyPOIs(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    maxDistanceKm = maxDistanceKm
                )
            } else {
                poiDao.getNearbyPOIsByCategories(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    maxDistanceKm = maxDistanceKm,
                    categories = watchedCategories.toList()
                )
            }
            
            // Atualiza lista
            _nearbyPOIs.postValue(pois)
            
            // Se o usuário solicitou notificação de POIs próximos
            if (notifyAllUpdates) {
                pois.forEach { poi ->
                    // Calcula distância
                    val distance = calculateDistance(
                        location.latitude, location.longitude,
                        poi.latitude, poi.longitude
                    )
                    
                    // Adiciona à lista de atualizações
                    addPOIUpdate(poi, POIUpdateType.NEARBY, distance)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar POIs próximos: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma atualização de POI
     */
    private fun processPOIUpdate(poi: POI, updateType: POIUpdateType) {
        // Se o usuário restringiu categorias, verifica se o POI está incluso
        if (watchedCategories.isNotEmpty() && !watchedCategories.contains(poi.type)) {
            return
        }
        
        // Calcula distância se tiver localização atual
        var distance = -1.0
        if (currentLocation != null) {
            distance = calculateDistance(
                currentLocation!!.latitude, currentLocation!!.longitude,
                poi.latitude, poi.longitude
            )
            
            // Se não estiver notificando todos, verifica distância
            if (!notifyAllUpdates && (distance > maxDistanceKm || maxDistanceKm <= 0)) {
                return
            }
        } else if (!notifyAllUpdates) {
            // Se não tem localização e só quer POIs próximos, ignora
            return
        }
        
        // Atualiza banco de dados local com base no tipo de atualização
        scope.launch {
            updateLocalDatabase(poi, updateType)
        }
        
        // Adiciona à lista de atualizações recentes
        addPOIUpdate(poi, updateType, distance)
    }
    
    /**
     * Atualiza o banco de dados local
     */
    private suspend fun updateLocalDatabase(poi: POI, updateType: POIUpdateType) = withContext(dispatcher) {
        try {
            when (updateType) {
                POIUpdateType.ADDED, POIUpdateType.UPDATED -> {
                    // Verifica se já existe
                    val existingPOI = poiDao.getById(poi.id)
                    
                    if (existingPOI == null) {
                        // Novo POI
                        poiDao.insert(poi)
                    } else {
                        // Atualiza POI existente, mantendo alguns campos locais
                        val updatedPOI = poi.copy(
                            // Mantém campos que podem ter sido modificados localmente
                            isFavorite = existingPOI.isFavorite
                        )
                        poiDao.update(updatedPOI)
                    }
                }
                POIUpdateType.DELETED -> {
                    // Remove do banco
                    poiDao.deleteById(poi.id)
                }
                POIUpdateType.NEARBY -> {
                    // Não precisa atualizar o banco, apenas notificar
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao atualizar banco de dados local: ${e.message}", e)
        }
    }
    
    /**
     * Adiciona uma atualização à lista de atualizações recentes
     */
    private fun addPOIUpdate(poi: POI, updateType: POIUpdateType, distance: Double) {
        // Cria objeto de atualização
        val update = POIUpdate(
            poi = poi,
            type = updateType,
            distance = distance,
            timestamp = System.currentTimeMillis()
        )
        
        // Atualiza lista
        val currentList = _recentUpdates.value?.toMutableList() ?: mutableListOf()
        
        // Remove atualizações antigas do mesmo POI
        currentList.removeAll { it.poi.id == poi.id }
        
        // Adiciona a nova atualização
        currentList.add(0, update) // No topo da lista
        
        // Limita tamanho da lista (máximo 100 itens)
        if (currentList.size > 100) {
            currentList.removeAt(currentList.size - 1)
        }
        
        // Atualiza LiveData
        _recentUpdates.postValue(currentList)
    }
    
    /**
     * Calcula distância entre dois pontos
     */
    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        // Se tiver um calculador de distância personalizado, usa ele
        distanceCalculator?.let {
            return it.calculateDistance(lat1, lon1, lat2, lon2)
        }
        
        // Fórmula de Haversine para calcular distância em KM
        val R = 6371.0 // Raio da Terra em KM
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return R * c
    }
    
    /**
     * Converte um Map do Firebase para objeto POI
     */
    private fun mapToPOI(id: String, data: Map<*, *>): POI {
        return POI(
            id = id,
            name = data["name"] as? String ?: "POI desconhecido",
            type = data["type"] as? String ?: "unknown",
            latitude = (data["latitude"] as? Double) ?: 0.0,
            longitude = (data["longitude"] as? Double) ?: 0.0,
            description = data["description"] as? String,
            createdAt = (data["createdAt"] as? Long) ?: System.currentTimeMillis(),
            updatedAt = (data["updatedAt"] as? Long) ?: System.currentTimeMillis(),
            createdBy = data["createdBy"] as? String,
            isVerified = (data["isVerified"] as? Boolean) ?: false,
            isActive = (data["isActive"] as? Boolean) ?: true,
            isFavorite = false, // Valor local, não vem do Firebase
            metadata = data["metadata"] as? String,
            synced = true, // Já está sincronizado
            syncTimestamp = System.currentTimeMillis(),
            serverRef = id
        )
    }
    
    /**
     * Converte um JSONObject para objeto POI
     */
    private fun jsonToPOI(json: JSONObject): POI? {
        try {
            return POI(
                id = json.optString("id") ?: return null,
                name = json.optString("name", "POI desconhecido"),
                type = json.optString("type", "unknown"),
                latitude = json.optDouble("latitude", 0.0),
                longitude = json.optDouble("longitude", 0.0),
                description = json.optString("description", null),
                createdAt = json.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = json.optLong("updatedAt", System.currentTimeMillis()),
                createdBy = json.optString("createdBy", null),
                isVerified = json.optBoolean("isVerified", false),
                isActive = json.optBoolean("isActive", true),
                isFavorite = false, // Valor local
                metadata = json.optString("metadata", null),
                synced = true, // Já está sincronizado
                syncTimestamp = System.currentTimeMillis(),
                serverRef = json.optString("id")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao converter JSON para POI: ${e.message}", e)
            return null
        }
    }
    
    /**
     * Define filtros para o monitoramento
     */
    fun setFilters(
        categories: Set<String> = emptySet(),
        maxDistance: Double = DEFAULT_MAX_DISTANCE_KM,
        notifyAll: Boolean = false
    ) {
        // Atualiza configurações
        watchedCategories = categories
        maxDistanceKm = maxDistance
        notifyAllUpdates = notifyAll
        
        // Se estiver usando WebSocket, atualiza filtros
        webSocket?.let { ws ->
            val updateMessage = JSONObject().apply {
                put("type", "update_filters")
                
                // Adiciona filtros
                if (watchedCategories.isNotEmpty()) {
                    val categoriesArray = JSONArray()
                    watchedCategories.forEach { categoriesArray.put(it) }
                    put("categories", categoriesArray)
                }
                
                if (currentLocation != null) {
                    put("latitude", currentLocation!!.latitude)
                    put("longitude", currentLocation!!.longitude)
                    put("maxDistance", maxDistanceKm)
                }
                
                put("notifyAll", notifyAllUpdates)
            }
            
            ws.send(updateMessage.toString())
        }
        
        // Recarrega POIs próximos com novos filtros
        if (currentLocation != null) {
            scope.launch {
                loadNearbyPOIs()
            }
        }
    }
    
    /**
     * Limpa a lista de atualizações recentes
     */
    fun clearRecentUpdates() {
        _recentUpdates.postValue(emptyList())
    }
    
    /**
     * Libera recursos
     */
    fun shutdown() {
        // Para monitoramento se estiver ativo
        if (_watcherState.value is WatcherState.Watching) {
            stopWatching()
        }
    }
    
    /**
     * Classe que representa uma atualização de POI
     */
    data class POIUpdate(
        val poi: POI,
        val type: POIUpdateType,
        val distance: Double, // Em KM, -1 se desconhecido
        val timestamp: Long
    ) {
        val formattedDistance: String
            get() = if (distance >= 0) {
                if (distance < 1.0) {
                    "${(distance * 1000).toInt()}m"
                } else {
                    "%.1f km".format(distance)
                }
            } else {
                "Desconhecida"
            }
        
        val formattedTimestamp: String
            get() {
                val date = Date(timestamp)
                return android.text.format.DateFormat.format("dd/MM/yyyy HH:mm:ss", date).toString()
            }
    }
    
    /**
     * Estados possíveis do watcher
     */
    sealed class WatcherState {
        object Stopped : WatcherState()
        data class Watching(val method: MonitoringMethod) : WatcherState()
        data class Error(val message: String) : WatcherState()
    }
    
    /**
     * Métodos de monitoramento
     */
    enum class MonitoringMethod {
        FIREBASE,   // Via Firebase Realtime Database
        WEBSOCKET,  // Via WebSocket
        REST,       // Via API REST (polling)
        ALL         // Todos os métodos
    }
}