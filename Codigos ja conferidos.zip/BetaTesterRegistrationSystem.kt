class BetaTesterRegistrationSystem {
    private val betaTesters = mutableMapOf<String, BetaTester>()
    private val activationCodes = mutableMapOf<String, String>()
    private val emailsUsed = mutableSetOf<String>()

    // Estrutura principal do Beta Tester
    data class BetaTester(
        val id: String,
        val personalInfo: PersonalInfo,
        val truckInfo: TruckInfo,
        val testingInfo: TestingInfo,
        val activationCode: String,
        val registrationDate: Long = System.currentTimeMillis()
    )

    // Informações pessoais do motorista
    data class PersonalInfo(
        val name: String,
        val email: String,
        val phone: String,
        val country: String,
        val language: String,
        val yearsOfExperience: Int
    )

    // Informações do caminhão
    data class TruckInfo(
        val truckBrand: String,
        val truckModel: String,
        val year: Int,
        val type: TruckType,
        val hasGPS: Boolean,
        val hasSmartphone: Boolean,
        val operatingSystem: String // Android/iOS
    )

    // Informações de teste
    data class TestingInfo(
        val testingRegion: String,
        val routeType: RouteType,
        val availableForFeedback: Boolean,
        val preferredContactMethod: ContactMethod,
        val validUntil: Long,
        val status: TesterStatus = TesterStatus.ACTIVE
    )

    enum class TruckType {
        SEMI_TRUCK,
        BOX_TRUCK,
        FLATBED,
        TANKER,
        CAR_CARRIER,
        LIVESTOCK
    }

    enum class RouteType {
        LONG_HAUL,
        REGIONAL,
        LOCAL,
        INTERNATIONAL
    }

    enum class ContactMethod {
        EMAIL,
        PHONE,
        WHATSAPP,
        TELEGRAM
    }

    enum class TesterStatus {
        ACTIVE,
        INACTIVE,
        COMPLETED,
        CONVERTED_TO_PREMIUM
    }

    // Função principal para registrar novo beta tester
    fun registerNewTester(
        name: String,
        email: String,
        phone: String,
        country: String,
        language: String,
        yearsOfExperience: Int,
        truckBrand: String,
        truckModel: String,
        truckYear: Int,
        truckType: TruckType,
        hasGPS: Boolean,
        hasSmartphone: Boolean,
        operatingSystem: String,
        testingRegion: String,
        routeType: RouteType,
        availableForFeedback: Boolean,
        preferredContactMethod: ContactMethod
    ): RegistrationResult {
        // Validações básicas
        if (email in emailsUsed) {
            return RegistrationResult.Error("Email já registrado")
        }

        // Gerar ID único para o tester
        val testerId = generateTesterId()
        
        // Gerar código de ativação
        val activationCode = generateActivationCode(testingRegion, truckType)

        // Criar objeto PersonalInfo
        val personalInfo = PersonalInfo(
            name = name,
            email = email,
            phone = phone,
            country = country,
            language = language,
            yearsOfExperience = yearsOfExperience
        )

        // Criar objeto TruckInfo
        val truckInfo = TruckInfo(
            truckBrand = truckBrand,
            truckModel = truckModel,
            year = truckYear,
            type = truckType,
            hasGPS = hasGPS,
            hasSmartphone = hasSmartphone,
            operatingSystem = operatingSystem
        )

        // Criar objeto TestingInfo
        val testingInfo = TestingInfo(
            testingRegion = testingRegion,
            routeType = routeType,
            availableForFeedback = availableForFeedback,
            preferredContactMethod = preferredContactMethod,
            validUntil = System.currentTimeMillis() + (90L * 24 * 60 * 60 * 1000) // 90 dias
        )

        // Criar o beta tester
        val betaTester = BetaTester(
            id = testerId,
            personalInfo = personalInfo,
            truckInfo = truckInfo,
            testingInfo = testingInfo,
            activationCode = activationCode
        )

        // Salvar nas coleções
        betaTesters[testerId] = betaTester
        activationCodes[activationCode] = testerId
        emailsUsed.add(email)

        // Gerar documentação do beta tester
        val documentation = generateTesterDocumentation(betaTester)

        return RegistrationResult.Success(betaTester, documentation)
    }

    private fun generateTesterId(): String {
        return "BT${System.currentTimeMillis()}${(1000..9999).random()}"
    }

    private fun generateActivationCode(region: String, truckType: TruckType): String {
        val prefix = when(region.uppercase()) {
            "EU" -> "EU"
            "NA" -> "NA"
            "BR" -> "BR"
            else -> "WW"
        }

        val truckPrefix = when(truckType) {
            TruckType.SEMI_TRUCK -> "ST"
            TruckType.BOX_TRUCK -> "BT"
            TruckType.FLATBED -> "FB"
            TruckType.TANKER -> "TK"
            TruckType.CAR_CARRIER -> "CC"
            TruckType.LIVESTOCK -> "LV"
        }

        val chars = ('A'..'Z') + ('0'..'9')
        val randomPart = (1..4)
            .map { chars.random() }
            .joinToString("")

        return "${prefix}${truckPrefix}${randomPart}"
    }

    private fun generateTesterDocumentation(tester: BetaTester): TesterDocumentation {
        return TesterDocumentation(
            welcomeLetter = generateWelcomeLetter(tester),
            instructions = generateInstructions(tester),
            activationGuide = generateActivationGuide(tester),
            contactInformation = generateContactInfo(tester)
        )
    }

    data class TesterDocumentation(
        val welcomeLetter: String,
        val instructions: String,
        val activationGuide: String,
        val contactInformation: String
    )

    sealed class RegistrationResult {
        data class Success(val tester: BetaTester, val documentation: TesterDocumentation) : RegistrationResult()
        data class Error(val message: String) : RegistrationResult()
    }

    private fun generateWelcomeLetter(tester: BetaTester): String {
        return """
            Bem-vindo ao Programa Beta do King Road!
            
            Olá ${tester.personalInfo.name},
            
            É com grande satisfação que damos as boas-vindas ao nosso programa de testes beta.
            Seu código de ativação é: ${tester.activationCode}
            
            Esta é uma versão de testes válida até ${formatDate(tester.testingInfo.validUntil)}.
            
            Agradecemos sua participação!
        """.trimIndent()
    }

    private fun generateInstructions(tester: BetaTester): String {
        return """
            Instruções de Uso - King Road Beta
            
            1. Instalação:
               - Faça o download do aplicativo
               - Use o código: ${tester.activationCode}
               
            2. Teste as funcionalidades:
               - Navegação
               - Pontos de interesse
               - Cálculo de rotas
               
            3. Reporte problemas ou sugestões através do método: 
               ${tester.testingInfo.preferredContactMethod}
            
            4. Seu acesso beta é válido até: ${formatDate(tester.testingInfo.validUntil)}
        """.trimIndent()
    }

    private fun generateActivationGuide(tester: BetaTester): String {
        return """
            Guia de Ativação - King Road Beta
            
            Código de Ativação: ${tester.activationCode}
            
            Para ativar:
            1. Abra o aplicativo
            2. Clique em "Tenho um código"
            3. Digite seu código
            4. Clique em Ativar
            
            Em caso de problemas, contate o suporte.
        """.trimIndent()
    }

    private fun generateContactInfo(tester: BetaTester): String {
        return """
            Informações de Contato - Suporte Beta
            
            Email: suporte@kingroad.com
            WhatsApp: +XX XX XXXXX-XXXX
            Horário: 24/7
            
            Seu ID de beta tester: ${tester.id}
            Mantenha esse ID em suas comunicações.
        """.trimIndent()
    }

    private fun formatDate(timestamp: Long): String {
        // Implementar formatação de data adequada
        return java.text.SimpleDateFormat("dd/MM/yyyy").format(timestamp)
    }
}

// Exemplo de uso
fun main() {
    val registrationSystem = BetaTesterRegistrationSystem()
    
    val result = registrationSystem.registerNewTester(
        name = "João Silva",
        email = "joao@email.com",
        phone = "+55 11 98765-4321",
        country = "BR",
        language = "PT",
        yearsOfExperience = 10,
        truckBrand = "Volvo",
        truckModel = "FH 460",
        truckYear = 2020,
        truckType = BetaTesterRegistrationSystem.TruckType.SEMI_TRUCK,
        hasGPS = true,
        hasSmartphone = true,
        operatingSystem = "Android",
        testingRegion = "BR",
        routeType = BetaTesterRegistrationSystem.RouteType.LONG_HAUL,
        availableForFeedback = true,
        preferredContactMethod = BetaTesterRegistrationSystem.ContactMethod.WHATSAPP
    )

    when (result) {
        is BetaTesterRegistrationSystem.RegistrationResult.Success -> {
            println("Beta Tester registrado com sucesso!")
            println("Código de ativação: ${result.tester.activationCode}")
            println("\nDocumentação gerada:")
            println(result.documentation.welcomeLetter)
        }
        is BetaTesterRegistrationSystem.RegistrationResult.Error -> {
            println("Erro no registro: ${result.message}")
        }
    }
}