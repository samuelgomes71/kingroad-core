package com.kingroad.database.dao

import androidx.room.*
import com.kingroad.reports.InfrastructureReport
import com.kingroad.reports.ReportStatus
import com.kingroad.reports.StatusHistoryEntry
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Interface DAO para acessar a tabela de denúncias de infraestrutura pública
 */
@Dao
interface PublicInfrastructureReportDao {
    
    /**
     * Insere uma nova denúncia
     * @param report Denúncia a ser inserida
     * @return ID da denúncia inserida
     */
    @Insert
    suspend fun insert(report: InfrastructureReport): Long
    
    /**
     * Atualiza uma denúncia existente
     * @param report Denúncia atualizada
     */
    @Update
    suspend fun update(report: InfrastructureReport)
    
    /**
     * Remove uma denúncia
     * @param report Denúncia a ser removida
     */
    @Delete
    suspend fun delete(report: InfrastructureReport)
    
    /**
     * Busca uma denúncia pelo ID
     * @param id ID da denúncia
     * @return A denúncia encontrada ou null
     */
    @Query("SELECT * FROM infrastructure_reports WHERE id = :id")
    suspend fun findById(id: String): InfrastructureReport?
    
    /**
     * Busca todas as denúncias feitas por um usuário
     * @param userId ID do usuário
     * @return Lista de denúncias do usuário
     */
    @Query("SELECT * FROM infrastructure_reports WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun findByUserId(userId: String): List<InfrastructureReport>
    
    /**
     * Busca denúncias próximas a uma localização
     * @param latitude Latitude central
     * @param longitude Longitude central
     * @param radius Raio aproximado em graus
     * @return Lista de denúncias na área
     */
    @Query("""
        SELECT * FROM infrastructure_reports 
        WHERE (latitude BETWEEN :latitude - :radius AND :latitude + :radius) 
        AND (longitude BETWEEN :longitude - :radius AND :longitude + :radius)
        ORDER BY createdAt DESC
    """)
    suspend fun findNearby(latitude: Double, longitude: Double, radius: Double): List<InfrastructureReport>
    
    /**
     * Busca denúncias para uma municipalidade específica
     * @param municipalityId ID da municipalidade
     * @return Lista de denúncias para a municipalidade
     */
    @Query("SELECT * FROM infrastructure_reports WHERE municipalityId = :municipalityId ORDER BY createdAt DESC")
    suspend fun findByMunicipality(municipalityId: String): List<InfrastructureReport>
    
    /**
     * Busca denúncias por status
     * @param status Status para filtrar
     * @return Lista de denúncias com o status especificado
     */
    @Query("SELECT * FROM infrastructure_reports WHERE status = :status ORDER BY createdAt DESC")
    suspend fun findByStatus(status: ReportStatus): List<InfrastructureReport>
    
    /**
     * Busca denúncias por tipo
     * @param reportType Tipo de denúncia
     * @return Lista de denúncias do tipo especificado
     */
    @Query("SELECT * FROM infrastructure_reports WHERE reportType = :reportType ORDER BY createdAt DESC")
    suspend fun findByType(reportType: String): List<InfrastructureReport>
    
    /**
     * Atualiza o status de uma denúncia
     * @param reportId ID da denúncia
     * @param status Novo status
     * @param lastUpdatedAt Timestamp da atualização
     */
    @Query("UPDATE infrastructure_reports SET status = :status, lastUpdatedAt = :lastUpdatedAt WHERE id = :reportId")
    suspend fun updateStatus(reportId: String, status: ReportStatus, lastUpdatedAt: Long)
    
    /**
     * Atualiza o número de protocolo de uma denúncia
     * @param reportId ID da denúncia
     * @param protocolNumber Número de protocolo
     */
    @Query("UPDATE infrastructure_reports SET protocolNumber = :protocolNumber WHERE id = :reportId")
    suspend fun updateProtocolNumber(reportId: String, protocolNumber: String)
    
    /**
     * Adiciona uma entrada ao histórico de status
     * @param reportId ID da denúncia
     * @param historyEntry Nova entrada do histórico
     */
    @Transaction
    suspend fun addStatusHistoryEntry(reportId: String, historyEntry: StatusHistoryEntry) {
        val report = findById(reportId) ?: return
        val updatedHistory = report.statusHistory + historyEntry
        
        // Converter para JSON e atualizar no banco
        val json = Json.encodeToString(updatedHistory)
        updateStatusHistory(reportId, json)
    }
    
    /**
     * Atualiza o histórico de status (método interno)
     * @param reportId ID da denúncia
     * @param statusHistoryJson JSON do histórico de status
     */
    @Query("UPDATE infrastructure_reports SET statusHistory = :statusHistoryJson WHERE id = :reportId")
    suspend fun updateStatusHistory(reportId: String, statusHistoryJson: String)
    
    /**
     * Conta o número de denúncias por município
     * @return Map de municipalityId para contagem
     */
    @Query("SELECT municipalityId, COUNT(*) as count FROM infrastructure_reports GROUP BY municipalityId")
    suspend fun countByMunicipality(): Map<String, Int>
    
    /**
     * Conta o número de denúncias por tipo
     * @return Map de reportType para contagem
     */
    @Query("SELECT reportType, COUNT(*) as count FROM infrastructure_reports GROUP BY reportType")
    suspend fun countByType(): Map<String, Int>
    
    /**
     * Conta o número de denúncias por status
     * @return Map de status para contagem
     */
    @Query("SELECT status, COUNT(*) as count FROM infrastructure_reports GROUP BY status")
    suspend fun countByStatus(): Map<String, Int>
}

/**
 * Conversores para tipos complexos
 */
class InfrastructureReportConverters {
    private val json = Json { ignoreUnknownKeys = true }
    
    @TypeConverter
    fun fromStatusHistoryList(value: List<StatusHistoryEntry>): String = json.encodeToString(value)
    
    @TypeConverter
    fun toStatusHistoryList(value: String): List<StatusHistoryEntry> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)
    
    @TypeConverter
    fun fromStringList(value: List<String>): String = json.encodeToString(value)
    
    @TypeConverter
    fun toStringList(value: String): List<String> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)
}