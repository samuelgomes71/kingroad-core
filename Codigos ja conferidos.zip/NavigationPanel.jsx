import React, { useState } from 'react';
import locationIcon from '../assets/icons/location-icon.svg';
import destinationIcon from '../assets/icons/destination-icon.svg';
import routeIcon from '../assets/icons/route-icon.svg';
import truckIcon from '../assets/icons/truck-icon.svg';
import clockIcon from '../assets/icons/clock-icon.svg';
import moreIcon from '../assets/icons/more-icon.svg';

/**
 * Painel de navegação com design premium para KingRoad
 * Salvar em: web/src/components/NavigationPanel.jsx
 */
const NavigationPanel = () => {
  const [expanded, setExpanded] = useState(false);
  const [routeOptions, setRouteOptions] = useState({
    avoidTolls: false,
    preferHighways: true,
    avoidUrbanAreas: false,
    truckSpecific: true,
  });
  
  // Simulação de destinos recentes - substituir por dados reais da API
  const recentDestinations = [
    { id: 1, name: "Posto Ipiranga BR-101", type: "gas_station" },
    { id: 2, name: "Porto de Santos", type: "destination" },
    { id: 3, name: "São Paulo - Campinas", type: "route" }
  ];
  
  const handleRouteOptionChange = (option) => {
    setRouteOptions({
      ...routeOptions,
      [option]: !routeOptions[option]
    });
  };

  return (
    <div className="nav-panel">
      <div className="nav-header">
        <div className="nav-icon">
          <img src={routeIcon} alt="Navegação" />
        </div>
        <h2 className="nav-title">Navegação Premium</h2>
      </div>

      <div className="search-group">
        <div className="search-item origin">
          <div className="search-icon">
            <img src={locationIcon} alt="Origem" />
          </div>
          <input 
            type="text" 
            className="search-input" 
            placeholder="Sua localização atual" 
          />
        </div>
        
        <div className="route-connector"></div>
        
        <div className="search-item destination">
          <div className="search-icon">
            <img src={destinationIcon} alt="Destino" />
          </div>
          <input 
            type="text" 
            className="search-input" 
            placeholder="Digite o destino..." 
          />
        </div>
      </div>

      {expanded && (
        <div className="route-options">
          <div className="option-group">
            <h3 className="option-group-title">Opções de Rota</h3>
            
            <div className="option-row">
              <label className="option-label">
                <input 
                  type="checkbox" 
                  checked={routeOptions.avoidTolls} 
                  onChange={() => handleRouteOptionChange('avoidTolls')} 
                />
                <span className="checkmark"></span>
                <span className="label-text">Evitar pedágios</span>
              </label>
              
              <label className="option-label">
                <input 
                  type="checkbox" 
                  checked={routeOptions.preferHighways} 
                  onChange={() => handleRouteOptionChange('preferHighways')} 
                />
                <span className="checkmark"></span>
                <span className="label-text">Preferir rodovias</span>
              </label>
            </div>
            
            <div className="option-row">
              <label className="option-label">
                <input 
                  type="checkbox" 
                  checked={routeOptions.avoidUrbanAreas} 
                  onChange={() => handleRouteOptionChange('avoidUrbanAreas')} 
                />
                <span className="checkmark"></span>
                <span className="label-text">Evitar áreas urbanas</span>
              </label>
              
              <label className="option-label">
                <input 
                  type="checkbox" 
                  checked={routeOptions.truckSpecific} 
                  onChange={() => handleRouteOptionChange('truckSpecific')} 
                />
                <span className="checkmark"></span>
                <span className="label-text">Rota para caminhões</span>
              </label>
            </div>
          </div>
          
          <div className="vehicle-info">
            <div className="vehicle-icon">
              <img src={truckIcon} alt="Caminhão" />
            </div>
            <div className="vehicle-details">
              <span className="vehicle-name">Volvo FH 460</span>
              <span className="vehicle-plate">ABC-1234</span>
            </div>
            <button className="btn-change-vehicle">Trocar</button>
          </div>
        </div>
      )}

      <div className="recent-destinations">
        <h3 className="recent-title">Destinos Recentes</h3>
        
        <ul className="recent-list">
          {recentDestinations.map(destination => (
            <li key={destination.id} className="recent-item">
              <div className="recent-icon">
                <img 
                  src={
                    destination.type === 'gas_station' 
                      ? locationIcon 
                      : destination.type === 'destination' 
                        ? destinationIcon 
                        : routeIcon
                  } 
                  alt={destination.type} 
                />
              </div>
              <div className="recent-details">
                <span className="recent-name">{destination.name}</span>
                <span className="recent-type">
                  {destination.type === 'gas_station' 
                    ? 'Posto de combustível' 
                    : destination.type === 'destination' 
                      ? 'Destino' 
                      : 'Rota'}
                </span>
              </div>
              <div className="recent-time">
                <img src={clockIcon} alt="Tempo" />
                <span>1d</span>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="nav-actions">
        <button 
          className="btn-options"
          onClick={() => setExpanded(!expanded)}
        >
          <img src={moreIcon} alt="Mais opções" />
          <span>{expanded ? 'Menos opções' : 'Mais opções'}</span>
        </button>
        
        <button className="btn btn-primary">
          <span>Iniciar Navegação</span>
        </button>
      </div>
      
      <style jsx>{`
        .nav-panel {
          background-color: var(--black-secondary);
          border-radius: var(--border-radius-lg);
          border: 1px solid var(--gold-dark);
          padding: 1.5rem;
          box-shadow: var(--shadow-medium);
          max-width: 500px;
          width: 100%;
          position: relative;
          overflow: hidden;
        }
        
        .nav-panel:before {
          content: '';
          position: absolute;
          top: 0;
          right: 0;
          width: 100px;
          height: 100px;
          background: radial-gradient(circle, rgba(212, 175, 55, 0.1) 0%, transparent 70%);
          pointer-events: none;
        }
        
        .nav-header {
          display: flex;
          align-items: center;
          margin-bottom: 1.5rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid rgba(212, 175, 55, 0.3);
        }
        
        .nav-icon {
          width: 40px;
          height: 40px;
          background: var(--gold-gradient);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-right: 1rem;
          box-shadow: var(--shadow-soft);
        }
        
        .nav-icon img {
          width: 20px;
          height: 20px;
          filter: brightness(0);
        }
        
        .nav-title {
          color: var(--gold-primary);
          font-family: var(--font-primary);
          font-size: var(--font-size-xl);
          font-weight: 600;
          margin: 0;
        }
        
        .search-group {
          margin-bottom: 1.5rem;
          position: relative;
        }
        
        .search-item {
          display: flex;
          align-items: center;
          margin-bottom: 1rem;
          background-color: var(--black-primary);
          border: 1px solid var(--gold-dark);
          border-radius: var(--border-radius-md);
          padding: 0.75rem 1rem;
          transition: all 0.3s ease;
        }
        
        .search-item:focus-within {
          border-color: var(--gold-primary);
          box-shadow: var(--gold-glow);
        }
        
        .search-icon {
          width: 24px;
          height: 24px;
          margin-right: 0.75rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .search-icon img {
          width: 16px;
          height: 16px;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .search-input {
          flex: 1;
          background: transparent;
          border: none;
          color: var(--text-light);
          font-family: var(--font-secondary);
          font-size: var(--font-size-md);
        }
        
        .search-input:focus {
          outline: none;
        }
        
        .search-input::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }
        
        .route-connector {
          position: absolute;
          left: 12px;
          top: 30px;
          height: 20px;
          width: 2px;
          background: var(--gold-gradient-vertical);
        }
        
        .route-options {
          background-color: var(--black-accent);
          border-radius: var(--border-radius-md);
          padding: 1rem;
          margin-bottom: 1.5rem;
          border: 1px solid rgba(212, 175, 55, 0.2);
        }
        
        .option-group {
          margin-bottom: 1rem;
        }
        
        .option-group-title {
          color: var(--gold-primary);
          font-size: var(--font-size-sm);
          margin-bottom: 0.75rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .option-row {
          display: flex;
          flex-wrap: wrap;
          margin-bottom: 0.5rem;
        }
        
        .option-label {
          display: flex;
          align-items: center;
          margin-right: 1.5rem;
          margin-bottom: 0.5rem;
          cursor: pointer;
          position: relative;
          padding-left: 28px;
          user-select: none;
        }
        
        .option-label input {
          position: absolute;
          opacity: 0;
          height: 0;
          width: 0;
        }
        
        .checkmark {
          position: absolute;
          left: 0;
          top: 0;
          height: 18px;
          width: 18px;
          background-color: var(--black-primary);
          border: 1px solid var(--gold-dark);
          border-radius: 3px;
        }
        
        .option-label:hover .checkmark {
          border-color: var(--gold-primary);
        }
        
        .option-label input:checked ~ .checkmark {
          background-color: var(--gold-primary);
          border-color: var(--gold-primary);
        }
        
        .checkmark:after {
          content: "";
          position: absolute;
          display: none;
        }
        
        .option-label input:checked ~ .checkmark:after {
          display: block;
        }
        
        .option-label .checkmark:after {
          left: 6px;
          top: 2px;
          width: 5px;
          height: 10px;
          border: solid var(--black-primary);
          border-width: 0 2px 2px 0;
          transform: rotate(45deg);
        }
        
        .label-text {
          color: var(--text-light);
          font-size: var(--font-size-sm);
        }
        
        .vehicle-info {
          display: flex;
          align-items: center;
          background-color: rgba(212, 175, 55, 0.05);
          border-radius: var(--border-radius-md);
          padding: 0.75rem 1rem;
          border: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .vehicle-icon {
          width: 32px;
          height: 32px;
          margin-right: 0.75rem;
        }
        
        .vehicle-icon img {
          width: 100%;
          height: 100%;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .vehicle-details {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        
        .vehicle-name {
          color: var(--gold-primary);
          font-weight: 500;
          font-size: var(--font-size-sm);
        }
        
        .vehicle-plate {
          color: var(--text-light);
          font-size: var(--font-size-xs);
          opacity: 0.8;
        }
        
        .btn-change-vehicle {
          background: transparent;
          border: 1px solid var(--gold-dark);
          color: var(--gold-primary);
          padding: 0.3rem 0.75rem;
          border-radius: var(--border-radius-sm);
          font-size: var(--font-size-xs);
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .btn-change-vehicle:hover {
          background-color: rgba(212, 175, 55, 0.1);
          border-color: var(--gold-primary);
        }
        
        .recent-destinations {
          margin-bottom: 1.5rem;
        }
        
        .recent-title {
          color: var(--gold-primary);
          font-size: var(--font-size-sm);
          margin-bottom: 0.75rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .recent-list {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        
        .recent-item {
          display: flex;
          align-items: center;
          padding: 0.75rem;
          border-bottom: 1px solid rgba(212, 175, 55, 0.1);
          transition: all 0.2s ease;
          cursor: pointer;
        }
        
        .recent-item:last-child {
          border-bottom: none;
        }
        
        .recent-item:hover {
          background-color: rgba(212, 175, 55, 0.05);
        }
        
        .recent-icon {
          width: 24px;
          height: 24px;
          margin-right: 0.75rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .recent-icon img {
          width: 16px;
          height: 16px;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .recent-details {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        
        .recent-name {
          color: var(--text-light);
          font-size: var(--font-size-sm);
        }
        
        .recent-type {
          color: var(--text-light);
          font-size: var(--font-size-xs);
          opacity: 0.7;
        }
        
        .recent-time {
          display: flex;
          align-items: center;
          color: var(--text-light);
          opacity: 0.6;
          font-size: var(--font-size-xs);
        }
        
        .recent-time img {
          width: 12px;
          height: 12px;
          margin-right: 4px;
          filter: invert(70%) sepia(10%) saturate(300%) hue-rotate(180deg) brightness(95%) contrast(90%);
        }
        
        .nav-actions {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 1.5rem;
        }
        
        .btn-options {
          background: transparent;
          border: none;
          color: var(--gold-primary);
          display: flex;
          align-items: center;
          cursor: pointer;
          padding: 0.5rem;
          border-radius: var(--border-radius-sm);
          transition: all 0.2s ease;
        }
        
        .btn-options:hover {
          background-color: rgba(212, 175, 55, 0.1);
        }
        
        .btn-options img {
          width: 16px;
          height: 16px;
          margin-right: 0.5rem;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .btn-primary {
          background: var(--gold-gradient);
          color: var(--black-primary);
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius-md);
          font-family: var(--font-primary);
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: var(--shadow-soft);
        }
        
        .btn-primary:hover {
          box-shadow: var(--gold-glow), var(--shadow-medium);
          transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
          .nav-panel {
            padding: 1rem;
          }
          
          .option-row {
            flex-direction: column;
          }
          
          .option-label {
            margin-right: 0;
          }
          
          .nav-actions {
            flex-direction: column;
            gap: 0.75rem;
          }
          
          .btn-options, .btn-primary {
            width: 100%;
            justify-content: center;
          }
        }
      `}</style>
    </div>
  );
};

export default NavigationPanel;

