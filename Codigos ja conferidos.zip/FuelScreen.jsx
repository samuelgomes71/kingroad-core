import React, { useState } from 'react';
import { ChevronLeft, Check } from 'lucide-react';

const FuelScreen = ({ onBack, onSave }) => {
  const [selectedFuel, setSelectedFuel] = useState('diesel');
  
  const fuelTypes = [
    { id: 'gasoline', label: 'Gasoline' },
    { id: 'diesel', label: 'Diesel' },
    { id: 'lpg', label: 'LPG/Propane' },
    { id: 'cng', label: 'Compressed Natural Gas (CNG)' },
    { id: 'ethanol', label: 'Ethanol' }
  ];

  return (
    <div className="h-screen bg-[#121212]">
      {/* Header */}
      <div className="flex items-center p-4 bg-[#1E1E1E]">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="text-white" size={24} />
        </button>
        <h1 className="text-white text-xl ml-2">Fuel</h1>
      </div>

      {/* Description */}
      <div className="p-4 text-gray-400">
        Select the type of fuel your vehicle uses.
        This will affect search results for gas stations, routing, and points of interest.
      </div>

      {/* Options */}
      <div className="p-4">
        {fuelTypes.map(fuel => (
          <button
            key={fuel.id}
            className={`w-full p-4 mb-2 flex items-center justify-between rounded-lg ${
              selectedFuel === fuel.id ? 'bg-blue-600' : 'bg-[#1E1E1E]'
            }`}
            onClick={() => setSelectedFuel(fuel.id)}
          >
            <span className="text-white">{fuel.label}</span>
            {selectedFuel === fuel.id && (
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <Check size={16} className="text-blue-600" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default FuelScreen;