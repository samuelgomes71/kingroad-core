// web/src/components/auth/RegistrationForm.jsx

import React, { useState, useEffect } from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { useAuth } from '../../contexts/AuthContext';
import { useNotification } from '../../hooks/useNotification';
import { useDeviceInfo } from '../../hooks/useDeviceInfo';
import { LogoIcon, UserIcon, EmailIcon, PhoneIcon, MapPinIcon, GlobeIcon, LockIcon } from '../icons/AuthIcons';

/**
 * Formulário de registro de usuários do KingRoad
 * Coleta informações completas e verifica a elegibilidade para o período de teste
 */
const RegistrationForm = ({ onSuccess, onCancel }) => {
  const { t } = useTranslation('auth');
  const { registerUser } = useAuth();
  const { showSuccess, showError } = useNotification();
  const { getDeviceInfo } = useDeviceInfo();
  
  // Estados do formulário
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [country, setCountry] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  
  // Lista de países para o seletor
  const countries = [
    { code: 'BR', name: 'Brasil' },
    { code: 'US', name: 'United States' },
    { code: 'CA', name: 'Canada' },
    { code: 'MX', name: 'Mexico' },
    // Adicionar mais países conforme necessário
  ];
  
  // Valida o formulário
  const validateForm = () => {
    const newErrors = {};
    
    if (!fullName.trim()) newErrors.fullName = t('requiredField');
    if (!email.trim()) newErrors.email = t('requiredField');
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = t('invalidEmail');
    
    if (!phoneNumber.trim()) newErrors.phoneNumber = t('requiredField');
    if (!address.trim()) newErrors.address = t('requiredField');
    if (!country) newErrors.country = t('requiredField');
    
    if (!password) newErrors.password = t('requiredField');
    else if (password.length < 8) newErrors.password = t('passwordTooShort');
    
    if (password !== confirmPassword) newErrors.confirmPassword = t('passwordsDoNotMatch');
    
    if (!agreeTerms) newErrors.agreeTerms = t('mustAgreeTerms');
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Manipula o envio do formulário
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      // Obtém informações do dispositivo
      const deviceInfo = await getDeviceInfo();
      
      // Tenta registrar o usuário
      const result = await registerUser(
        fullName,
        email,
        phoneNumber,
        address,
        country,
        password,
        deviceInfo
      );
      
      // Processa o resultado
      if (result.success) {
        showSuccess(t('registrationSuccess'));
        onSuccess();
      } else {
        // Exibe mensagens de erro específicas
        if (result.duplicateAccount) {
          showError(t('duplicateAccountError'));
        } else if (result.validationErrors) {
          setErrors(result.validationErrors);
          showError(t('validationError'));
        } else {
          showError(result.error || t('registrationError'));
        }
      }
    } catch (error) {
      showError(t('registrationError'));
      console.error('Registration error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="registration-form-container bg-black text-white p-6 rounded-lg max-w-lg mx-auto">
      <div className="text-center mb-6">
        <LogoIcon className="w-16 h-16 mx-auto mb-2 text-amber-500" />
        <h2 className="text-2xl font-bold text-amber-500">{t('createAccount')}</h2>
        <p className="text-gray-400">{t('trialPeriodInfo')}</p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Nome completo */}
        <div className="form-group">
          <label className="block text-sm font-medium mb-1">{t('fullName')} *</label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray-500">
              <UserIcon className="w-5 h-5" />
            </span>
            <input
              type="text"
              className={`w-full p-3 pl-10 bg-gray-800 border rounded-lg focus:ring-1 focus:ring-amber-500 ${errors.fullName ? 'border-red-500' : 'border-gray-700'}`}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder={t('enterFullName')}
            />
          </div>
          {errors.fullName && <p className="mt-1 text-xs text-red-500">{errors.fullName}</p>}
        </div>
        
        {/* E-mail */}
        <div className="form-group">
          <label className="block text-sm font-medium mb-1">{t('email')} *</label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray-500">
              <EmailIcon className="w-5 h-5" />
            </span>
            <input
              type="email"
              className={`w-full p-3 pl-10 bg-gray-800 border rounded-lg focus:ring-1 focus:ring-amber-500 ${errors.email ? 'border-red-500' : 'border-gray-700'}`}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('enterEmail')}
            />
          </div>
          {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
        </div>
        
        {/* Restante dos campos de entrada... */}
        
        {/* Botões de ação */}
        <div className="flex justify-between mt-6">
          <button
            type="button"
            className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            {t('cancel')}
          </button>
          
          <button
            type="submit"
            className="px-4 py-2 bg-amber-500 text-black font-medium rounded-lg hover:bg-amber-400 disabled:opacity-50"
            disabled={isSubmitting}
          >
            {isSubmitting ? t('submitting') : t('createAccount')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default RegistrationForm;
