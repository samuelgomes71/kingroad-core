data class LoadingPoint(
    val id: String,
    val name: String,
    val type: LoadingType,
    val capacity: Int,  // número de veículos simultaneamente
    val restrictions: List<LoadingRestriction>,
    val coordinates: Location,
    val instructions: String,
    val status: LoadingPointStatus = LoadingPointStatus.OPERATIONAL
)

enum class LoadingType {
    TRUCK_LOADING,      // Carregamento em caminhão cegonha
    CONTAINER_LOADING,  // Carregamento em container
    SINGLE_LOADING,     // Carregamento unitário
    RAIL_LOADING       // Carregamento ferroviário
}

enum class LoadingPointStatus {
    OPERATIONAL,
    BUSY,
    MAINTENANCE,
    CLOSED
}

data class LoadingRestriction(
    val type: String,
    val description: String
)