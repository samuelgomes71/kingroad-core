// Sistema de Alerta de Saídas em Áreas Urbanas
// app/src/main/kotlin/com/kingroad/alerts/urban

import android.location.Location

class UrbanExitManager(
    private val locationService: LocationService,
    private val routeService: RouteService,
    private val alertService: AlertService
) {
    data class UrbanExit(
        val id: String,
        val location: Location,
        val name: String,
        val type: UrbanExitType,
        val instructions: String? = null,
        val warnings: List<Warning>? = null
    )

    enum class UrbanExitType {
        STREET,            // Rua comum
        AVENUE,            // Avenida
        CROSSING,          // Cruzamento
        ROUNDABOUT,        // Rotatória
        DESTINATION       // Destino final
    }

    data class Warning(
        val type: WarningType,
        val description: String
    )

    enum class WarningType {
        TIGHT_TURN,
        TRAFFIC_LIGHT,
        PEDESTRIAN_CROSSING,
        SPEED_BUMP,
        LOW_CLEARANCE
    }

    // Monitorar saídas em área urbana
    suspend fun startUrbanExitMonitoring() {
        locationService.startLocationUpdates { location ->
            val speed = location.getSpeedKmh()
            if (speed <= MAX_URBAN_SPEED_KMH) {
                checkNearbyUrbanExits(location, speed)
            }
        }
    }

    // Verificar saídas próximas em área urbana
    private suspend fun checkNearbyUrbanExits(
        location: Location,
        speedKmh: Float
    ) {
        val nextExits = routeService.getNextUrbanExits(
            location = location,
            maxDistance = URBAN_ALERT_RADIUS
        )

        nextExits.forEach { exit ->
            processUrbanExit(exit, location, speedKmh)
        }
    }

    // Processar saída urbana
    private suspend fun processUrbanExit(
        exit: UrbanExit,
        currentLocation: Location,
        speedKmh: Float
    ) {
        val distance = calculateDistance(currentLocation, exit.location)
        
        if (shouldAlertUrban(distance, speedKmh)) {
            showUrbanExitAlert(exit, distance, speedKmh)
        }
    }

    // Calcular distância entre dois pontos
    private fun calculateDistance(current: Location, target: Location): Double {
        val results = FloatArray(1)
        Location.distanceBetween(
            current.latitude, current.longitude,
            target.latitude, target.longitude,
            results
        )
        return results[0].toDouble()
    }

    // Determinar se deve alertar em área urbana
    private fun shouldAlertUrban(
        distance: Double,
        speedKmh: Float
    ): Boolean {
        return distance <= URBAN_ALERT_DISTANCE && 
               speedKmh <= MAX_URBAN_SPEED_KMH
    }

    // Mostrar alerta de saída urbana
    private suspend fun showUrbanExitAlert(
        exit: UrbanExit,
        distance: Double,
        speedKmh: Float
    ) {
        val message = buildString {
            append("Atenção! ")
            
            // Instrução básica
            append("${exit.type.description} em ${formatUrbanDistance(distance)}. ")
            
            // Adicionar instruções específicas
            exit.instructions?.let { 
                append(it)
                append(". ")
            }
            
            // Adicionar avisos importantes
            exit.warnings?.let { warnings ->
                warnings.forEach { warning ->
                    append(warning.description)
                    append(". ")
                }
            }
        }

        // Determinar prioridade do alerta
        val priority = when {
            exit.type == UrbanExitType.DESTINATION -> AlertPriority.HIGH
            exit.warnings?.isNotEmpty() == true -> AlertPriority.HIGH
            else -> AlertPriority.MEDIUM
        }

        alertService.showVoiceAlert(
            message = message,
            type = AlertType.URBAN_EXIT,
            priority = priority
        )
    }

    private val UrbanExitType.description: String
        get() = when (this) {
            UrbanExitType.STREET -> "Rua à frente"
            UrbanExitType.AVENUE -> "Avenida à frente"
            UrbanExitType.CROSSING -> "Cruzamento"
            UrbanExitType.ROUNDABOUT -> "Rotatória"
            UrbanExitType.DESTINATION -> "Destino"
        }

    private fun formatUrbanDistance(meters: Double): String {
        return "${meters.toInt()} metros"
    }

    companion object {
        const val MAX_URBAN_SPEED_KMH = 50.0f   // 50 km/h
        const val URBAN_ALERT_RADIUS = 200.0     // 200m
        const val URBAN_ALERT_DISTANCE = 70.0    // 70m
    }
}

// Extensão para converter velocidade (definida também no HighwayExitManager)
fun Location.getSpeedKmh(): Float {
    return (this.speed * 3.6f) // Converter m/s para km/h
}