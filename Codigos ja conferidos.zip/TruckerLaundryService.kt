data class TruckerLaundry(
    val id: String,
    val name: String,
    val location: Location,
    val locationType: LocationType, // Novo: especifica onde a lavanderia está localizada
    val parkingDetails: ParkingDetails, // Novo: detalhes específicos do estacionamento
    val truckAccess: TruckAccess, // Novo: informações de acesso para caminhões
    val country: String,
    val address: String,
    val services: List<WashingService>,
    val facilities: LaundryFacilities,
    val operatingHours: OperatingHours,
    val contact: ContactInfo,
    val lastUpdate: Long = System.currentTimeMillis()
)

// Novo: define onde a lavanderia está localizada
enum class LocationType {
    TRUCK_STOP,          // Posto de combustível com estrutura para caminhões
    REST_AREA,           // Área de descanso na rodovia
    TRUCK_CENTER,        // Centro de apoio ao caminhoneiro
    LOGISTICS_CENTER,    // Centro logístico
    PORT_AREA,          // Área portuária
    INDUSTRIAL_ZONE     // Zona industrial com acesso para caminhões
}

// Novo: detalhes específicos do estacionamento
data class ParkingDetails(
    val totalTruckSpots: Int,
    val currentAvailableSpots: Int,
    val maxTruckLength: Double, // em metros
    val maxHeight: Double,      // em metros
    val isIlluminated: Boolean,
    val isSecure: Boolean,
    val hasOvernightParking: Boolean,
    val parkingFee: ParkingFee?
)

// Novo: informações de acesso para caminhões
data class TruckAccess(
    val hasEasyAccess: Boolean,
    val restrictions: List<TruckRestriction>,
    val accessInstructions: String,
    val recommendedApproach: String
)

data class TruckRestriction(
    val type: RestrictionType,
    val value: String,
    val description: String
)

enum class RestrictionType {
    HEIGHT,
    LENGTH,
    WEIGHT,
    TIME_WINDOW,
    ROAD_TYPE
}

data class WashingService(
    val type: String,
    val capacity: String,      // ex: "20kg", "30kg"
    val duration: Int,         // minutos
    val price: Price,
    val isAvailable: Boolean = true,
    val supportsLargeItems: Boolean = false  // Novo: para itens grandes como cobertores de caminhão
)

data class LaundryFacilities(
    val totalWashers: Int,
    val totalDryers: Int,
    val hasRestArea: Boolean = false,
    val hasShowers: Boolean = false,
    val hasRestroom: Boolean = false,
    val hasWifi: Boolean = false,
    val hasCafeteria: Boolean = false,
    val hasDriversRoom: Boolean = false,
    val acceptsCards: Boolean = false,
    val hasChangeStation: Boolean = false
)

class TruckerLaundryService {
    private val laundries = mutableMapOf<String, TruckerLaundry>()

    fun addLaundry(laundry: TruckerLaundry) {
        // Verifica se a lavanderia atende os requisitos mínimos para caminhoneiros
        if (isValidTruckerLaundry(laundry)) {
            laundries[laundry.id] = laundry
        }
    }

    // Novo: validação específica para garantir que a lavanderia é adequada para caminhoneiros
    private fun isValidTruckerLaundry(laundry: TruckerLaundry): Boolean {
        return laundry.parkingDetails.totalTruckSpots >= 2 && // Mínimo de 2 vagas para caminhões
               laundry.parkingDetails.maxTruckLength >= 18.0 && // Comprimento mínimo para carretas
               laundry.facilities.hasRestroom && // Precisa ter banheiro
               laundry.truckAccess.hasEasyAccess // Precisa ter acesso fácil para caminhões
    }

    fun getNearbyLaundries(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 50.0,
        filters: LaundryFilters = LaundryFilters()
    ): List<TruckerLaundry> {
        return laundries.values.filter { laundry ->
            // Verifica distância
            val distance = calculateDistance(
                latitude, longitude,
                laundry.location.latitude, laundry.location.longitude
            )
            
            if (distance > radiusKm) return@filter false
            
            // Aplica filtros específicos para caminhoneiros
            if (filters.minParkingSpots > 0 && 
                laundry.parkingDetails.totalTruckSpots < filters.minParkingSpots) {
                return@filter false
            }
            
            if (filters.requiresOvernightParking && 
                !laundry.parkingDetails.hasOvernightParking) {
                return@filter false
            }
            
            if (filters.requiresShowers && !laundry.facilities.hasShowers) {
                return@filter false
            }
            
            if (filters.maxTruckLength > 0 && 
                laundry.parkingDetails.maxTruckLength < filters.maxTruckLength) {
                return@filter false
            }

            true
        }.sortedBy { laundry ->
            calculateDistance(
                latitude, longitude,
                laundry.location.latitude, laundry.location.longitude
            )
        }
    }

    // Exemplo de dados para teste com locais apropriados para caminhões
    fun initializeTestData() {
        // Exemplo em um posto de combustível
        addLaundry(
            TruckerLaundry(
                id = "truckstop_laundry_1",
                name = "Truck Stop Laundry Services",
                location = Location(45.5, -122.6),
                locationType = LocationType.TRUCK_STOP,
                parkingDetails = ParkingDetails(
                    totalTruckSpots = 15,
                    currentAvailableSpots = 8,
                    maxTruckLength = 25.0,
                    maxHeight = 4.5,
                    isIlluminated = true,
                    isSecure = true,
                    hasOvernightParking = true,
                    parkingFee = null
                ),
                truckAccess = TruckAccess(
                    hasEasyAccess = true,
                    restrictions = listOf(),
                    accessInstructions = "Entrada pela lateral do posto",
                    recommendedApproach = "Acesso pela rodovia BR-101"
                ),
                country = "BR",
                address = "Rodovia BR-101, km 123",
                services = listOf(
                    WashingService(
                        type = "Super Capacity",
                        capacity = "25kg",
                        duration = 60,
                        price = Price(20.0, "BRL"),
                        supportsLargeItems = true
                    )
                ),
                facilities = LaundryFacilities(
                    totalWashers = 6,
                    totalDryers = 6,
                    hasRestArea = true,
                    hasShowers = true,
                    hasRestroom = true,
                    hasWifi = true,
                    hasCafeteria = true,
                    hasDriversRoom = true,
                    acceptsCards = true
                ),
                operatingHours = OperatingHours(
                    weekday = Schedule("00:00", "23:59"),
                    saturday = Schedule("00:00", "23:59"),
                    sunday = Schedule("00:00", "23:59"),
                    is24Hours = true
                ),
                contact = ContactInfo(
                    phone = "+55 11 98765-4321",
                    whatsapp = "+55 11 98765-4321",
                    email = "laundry@truckstop.com"
                )
            )
        )
    }

    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val R = 6371.0 // Raio da Terra em km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }
}