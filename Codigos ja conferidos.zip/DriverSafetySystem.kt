package com.kingroad.driver

data class DriverProfile(
    val id: String,
    val personalInfo: PersonalInfo,
    val professionalInfo: ProfessionalInfo,
    val safetyStats: SafetyStatistics,
    val verificationStatus: VerificationStatus,
    val careerPreferences: CareerPreferences,
    val monthlyRatings: List<MonthlyRating>,
    val achievements: List<Achievement>,
    val privacySettings: PrivacySettings
)

data class PersonalInfo(
    val name: String,
    val photo: String?,
    val location: String,
    val country: String,
    val region: String,
    val languages: List<String>,
    val yearsOfExperience: Int,
    val contact: ContactInfo
)

data class ProfessionalInfo(
    val licenseNumber: String,
    val licenseType: String,
    val licenseCountry: String,
    val endorsements: List<String>,
    val experienceTypes: List<String>,
    val currentEmployer: String?,
    val verifiedDocuments: List<VerifiedDocument>
)

data class SafetyStatistics(
    val currentMonthStats: MonthlyStats,
    val historicalStats: List<MonthlyStats>,
    val totalSafeHours: Double,
    val totalSafeKilometers: Double,
    val perfectMonths: Int
)

data class MonthlyStats(
    val month: Int,
    val year: Int,
    val harshBraking: Int = 0,
    val harshTurning: Int = 0,
    val speedingEvents: Int = 0,
    val missedExits: Int = 0,
    val totalDriveHours: Double = 0.0,
    val totalDistance: Double = 0.0,
    val safetyScore: Double = 100.0
)

data class VerificationStatus(
    val isLicenseVerified: Boolean = false,
    val isIdentityVerified: Boolean = false,
    val isEmployerVerified: Boolean = false,
    val verificationDate: Long? = null,
    val verificationMethod: String? = null
)

data class CareerPreferences(
    val isOpenToOffers: Boolean = false,
    val desiredRouteType: List<String> = listOf(),
    val preferredRegions: List<String> = listOf(),
    val minimumSalary: Double? = null,
    val availability: String? = null
)

data class MonthlyRating(
    val month: Int,
    val year: Int,
    val overallScore: Double,
    val safetyScore: Double,
    val efficiencyScore: Double,
    val complianceScore: Double,
    val achievements: List<Achievement>
)

data class Achievement(
    val id: String,
    val type: AchievementType,
    val title: String,
    val description: String,
    val dateEarned: Long,
    val icon: String
)

enum class AchievementType {
    PERFECT_MONTH,           // Mês perfeito sem eventos
    SAFE_DISTANCE,          // Distância percorrida com segurança
    CONSISTENT_SAFETY,      // Vários meses seguidos seguros
    NAVIGATION_MASTER,      // Sem erros de navegação
    EFFICIENCY_EXPERT,      // Excelente eficiência de combustível
    TOP_DRIVER,            // Motorista do mês
    PROFESSIONAL_VERIFIED   // Verificação profissional completa
}

data class PrivacySettings(
    val shareProfileWithEmployers: Boolean = false,
    val showRealName: Boolean = true,
    val showPhoto: Boolean = true,
    val showAchievements: Boolean = true,
    val showStatistics: Boolean = true
)

data class ContactInfo(
    val email: String,
    val phone: String,
    val emergencyContact: String?
)

data class VerifiedDocument(
    val type: String,
    val number: String,
    val issuedBy: String,
    val expiryDate: Long,
    val verificationDate: Long
)

class DriverSafetySystem(
    private val config: SafetyConfig = SafetyConfig()
) {
    data class SafetyConfig(
        val harshBrakingThreshold: Double = -3.0,     // m/s²
        val harshTurningThreshold: Double = 0.3,      // rad/s
        val speedingThreshold: Double = 5.0,          // km/h acima do limite
        val eventCooldown: Long = 60000,              // ms entre eventos (evita múltiplos registros)
        val minimumMonthlyHours: Double = 60.0,       // horas mínimas para qualificação
        val perfectScoreThreshold: Double = 98.0      // pontuação para mês perfeito
    )

    fun calculateMonthlyScore(stats: MonthlyStats): Double {
        if (stats.totalDriveHours < config.minimumMonthlyHours) {
            return 0.0
        }

        // Base score de 100, deduz pontos por eventos
        var score = 100.0

        // Deduções por eventos
        score -= (stats.harshBraking * 2.0)      // -2 pontos por freada brusca
        score -= (stats.harshTurning * 2.0)      // -2 pontos por curva brusca
        score -= (stats.speedingEvents * 1.5)    // -1.5 pontos por excesso de velocidade
        score -= (stats.missedExits * 1.0)       // -1 ponto por saída perdida

        // Normaliza a pontuação entre 0 e 100
        return score.coerceIn(0.0, 100.0)
    }

    fun checkForAchievements(driver: DriverProfile): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        
        // Verifica mês perfeito
        val currentStats = driver.safetyStats.currentMonthStats
        if (calculateMonthlyScore(currentStats) >= config.perfectScoreThreshold) {
            achievements.add(Achievement(
                id = "perfect_month_${currentStats.month}_${currentStats.year}",
                type = AchievementType.PERFECT_MONTH,
                title = "Mês Perfeito",
                description = "Mês completo sem eventos de segurança",
                dateEarned = System.currentTimeMillis(),
                icon = "perfect_month_icon"
            ))
        }

        // Verifica distância segura
        if (driver.safetyStats.totalSafeKilometers >= 10000) {
            achievements.add(Achievement(
                id = "safe_distance_10k",
                type = AchievementType.SAFE_DISTANCE,
                title = "10.000 km Seguros",
                description = "Completou 10.000 km com excelente histórico de segurança",
                dateEarned = System.currentTimeMillis(),
                icon = "safe_distance_icon"
            ))
        }

        return achievements
    }

    fun isEligibleForDriverOfMonth(driver: DriverProfile): Boolean {
        val currentStats = driver.safetyStats.currentMonthStats
        return currentStats.totalDriveHours >= config.minimumMonthlyHours &&
               calculateMonthlyScore(currentStats) >= config.perfectScoreThreshold &&
               driver.verificationStatus.isLicenseVerified &&
               driver.verificationStatus.isIdentityVerified
    }

    fun generateDriverReport(driver: DriverProfile): DriverReport {
        val currentScore = calculateMonthlyScore(driver.safetyStats.currentMonthStats)
        val achievements = checkForAchievements(driver)
        
        return DriverReport(
            driverName = driver.personalInfo.name,
            month = driver.safetyStats.currentMonthStats.month,
            year = driver.safetyStats.currentMonthStats.year,
            safetyScore = currentScore,
            drivingHours = driver.safetyStats.currentMonthStats.totalDriveHours,
            distance = driver.safetyStats.currentMonthStats.totalDistance,
            achievements = achievements,
            recommendations = generateSafetyRecommendations(driver.safetyStats.currentMonthStats),
            isDriverOfMonthCandidate = isEligibleForDriverOfMonth(driver)
        )
    }

    private fun generateSafetyRecommendations(stats: MonthlyStats): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (stats.harshBraking > 0) {
            recommendations.add("Mantenha maior distância do veículo à frente para evitar freadas bruscas")
        }
        if (stats.harshTurning > 0) {
            recommendations.add("Reduza a velocidade antes das curvas para maior segurança")
        }
        if (stats.speedingEvents > 0) {
            recommendations.add("Mantenha-se dentro dos limites de velocidade da via")
        }
        if (stats.missedExits > 0) {
            recommendations.add("Prepare-se com antecedência para as saídas indicadas no GPS")
        }

        return recommendations
    }
}

data class DriverReport(
    val driverName: String,
    val month: Int,
    val year: Int,
    val safetyScore: Double,
    val drivingHours: Double,
    val distance: Double,
    val achievements: List<Achievement>,
    val recommendations: List<String>,
    val isDriverOfMonthCandidate: Boolean
)