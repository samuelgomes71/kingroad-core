/**
 * i18n/locales/en-US.js
 * 
 * Translation resources for English (United States).
 * This is one of the main languages of the application with complete translations.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

const enUS = {
  translation: {
    // App information
    app: {
      name: 'KingRoad',
      welcome: 'Welcome to KingRoad',
      tagline: 'Your personal travel assistant',
      version: 'Version {{version}}',
      copyright: '© 2025 KingRoad. All rights reserved.'
    },
    
    // Authentication
    auth: {
      login: 'Login',
      logout: 'Logout',
      register: 'Register',
      forgotPassword: 'Forgot password?',
      resetPassword: 'Reset password',
      emailPlaceholder: 'Email',
      passwordPlaceholder: 'Password',
      confirmPasswordPlaceholder: 'Confirm password',
      loginSuccess: 'Login successful!',
      loginError: 'Login failed. Please check your credentials.',
      logoutSuccess: 'You have been logged out.',
      passwordResetSent: 'Password reset instructions have been sent.',
      passwordsDontMatch: 'Passwords do not match.',
      passwordRequirements: 'Password must be at least 8 characters long, including uppercase, lowercase, and numbers.'
    },
    
    // Navigation
    nav: {
      home: 'Home',
      profile: 'Profile',
      settings: 'Settings',
      trips: 'Trips',
      explore: 'Explore',
      help: 'Help',
      about: 'About'
    },
    
    // User profile
    profile: {
      title: 'My Profile',
      edit: 'Edit Profile',
      save: 'Save Changes',
      cancel: 'Cancel',
      name: 'Name',
      email: 'Email',
      phone: 'Phone',
      address: 'Address',
      preferences: 'Preferences',
      changePassword: 'Change Password',
      language: 'Language',
      theme: 'Theme',
      notifications: 'Notifications',
      deleteAccount: 'Delete Account',
      deleteAccountConfirm: 'Are you sure you want to delete your account? This action cannot be undone.',
      profileUpdated: 'Profile updated successfully!',
      profileUpdateError: 'Error updating profile.'
    },
    
    // Settings
    settings: {
      title: 'Settings',
      general: 'General',
      account: 'Account',
      privacy: 'Privacy',
      notifications: 'Notifications',
      appearance: 'Appearance',
      language: 'Language',
      region: 'Region',
      theme: {
        title: 'Theme',
        light: 'Light',
        dark: 'Dark',
        system: 'System'
      },
      dataCurrency: 'Currency',
      dataUsage: 'Data Usage',
      wifiOnly: 'Wi-Fi Only',
      locationServices: 'Location Services',
      resetSettings: 'Reset Settings',
      resetSettingsConfirm: 'Are you sure you want to reset all settings?',
      settingsSaved: 'Settings saved!',
      settingsError: 'Error saving settings.'
    },
    
    // Common components
    common: {
      ok: 'OK',
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      add: 'Add',
      remove: 'Remove',
      search: 'Search',
      filter: 'Filter',
      sort: 'Sort',
      loading: 'Loading...',
      retry: 'Retry',
      error: 'Error',
      success: 'Success',
      warning: 'Warning',
      info: 'Information',
      yes: 'Yes',
      no: 'No',
      back: 'Back',
      next: 'Next',
      finish: 'Finish',
      continue: 'Continue',
      skip: 'Skip',
      done: 'Done',
      select: 'Select',
      today: 'Today',
      yesterday: 'Yesterday',
      tomorrow: 'Tomorrow',
      confirm: 'Confirm',
      apply: 'Apply',
      reset: 'Reset',
      close: 'Close',
      open: 'Open',
      show: 'Show',
      hide: 'Hide',
      all: 'All',
      none: 'None',
      required: 'Required',
      optional: 'Optional',
      more: 'More',
      less: 'Less',
      details: 'Details',
      upload: 'Upload',
      download: 'Download',
      noResults: 'No results found',
      noData: 'No data available',
      emptyState: 'There\'s nothing here yet',
      offline: 'You are offline',
      online: 'You are online',
      day: 'Day',
      week: 'Week',
      month: 'Month',
      year: 'Year'
    },
    
    // Error messages
    errors: {
      generic: 'An error occurred. Please try again.',
      connection: 'Connection error. Please check your internet.',
      timeout: 'Request timed out. Please try again.',
      unauthorized: 'Unauthorized. Please log in again.',
      notFound: 'Resource not found.',
      serverError: 'Server error. Please try again later.',
      validation: 'Please check your input.',
      requiredField: 'Required field',
      invalidEmail: 'Invalid email',
      weakPassword: 'Password is too weak',
      accountExists: 'This account already exists',
      uploadFailed: 'File upload failed',
      downloadFailed: 'File download failed',
      locationPermissionDenied: 'Location permission denied',
      cameraPermissionDenied: 'Camera permission denied',
      microphonePermissionDenied: 'Microphone permission denied',
      storagePermissionDenied: 'Storage permission denied',
      networkError: 'Network error',
      sessionExpired: 'Session expired. Please log in again.'
    },
    
    // Specific components
    components: {
      // LocationPicker
      locationPicker: {
        searchPlaceholder: 'Search address',
        currentLocationButton: 'Current location',
        confirmButton: 'Confirm location',
        permissionDeniedTitle: 'Permission denied',
        permissionDeniedMessage: 'Location permission denied. Please enable it in app settings.',
        locationErrorTitle: 'Location error',
        locationErrorMessage: 'Could not get current location',
        addressLabel: 'Address:',
        loadingLocation: 'Getting location...',
        loadingAddress: 'Getting address...',
        noAddressFound: 'Address not found',
        searchingAddresses: 'Searching addresses...',
        noSearchResults: 'No results found',
        latitudeLongitudeFormat: 'Lat: {{lat}}, Lng: {{lng}}',
        manualInputButton: 'Manual input',
        manualInputTitle: 'Enter coordinates',
        manualInputLatitude: 'Latitude',
        manualInputLongitude: 'Longitude',
        manualInputOk: 'OK',
        manualInputCancel: 'Cancel',
        manualInputError: 'Invalid coordinates',
        standardMap: 'Standard',
        satelliteMap: 'Satellite',
        hybridMap: 'Hybrid',
        terrainMap: 'Terrain'
      },
      
      // PhotoCapture
      photoCapture: {
        takePhoto: 'Take photo',
        selectFromGallery: 'Select from gallery',
        cancel: 'Cancel',
        retake: 'Retake',
        permissionDenied: 'Camera permission denied',
        error: 'Error capturing photo',
        processing: 'Processing...',
        rotateLeft: 'Rotate left',
        rotateRight: 'Rotate right',
        crop: 'Crop',
        save: 'Save',
        preview: 'Preview',
        addCaption: 'Add caption',
        removePhoto: 'Remove photo'
      },
      
      // AudioRecorder
      audioRecorder: {
        record: 'Record',
        stop: 'Stop',
        play: 'Play',
        pause: 'Pause',
        delete: 'Delete',
        save: 'Save',
        permissionDenied: 'Microphone permission denied',
        recording: 'Recording...',
        recordingComplete: 'Recording complete',
        errorRecording: 'Error recording audio',
        errorPlaying: 'Error playing audio',
        duration: 'Duration: {{duration}}',
        addNote: 'Add note',
        quality: {
          title: 'Quality',
          low: 'Low',
          medium: 'Medium',
          high: 'High'
        }
      },
      
      // Forms and validation
      forms: {
        required: 'Required field',
        minLength: 'Minimum {{count}} characters',
        maxLength: 'Maximum {{count}} characters',
        email: 'Invalid email',
        url: 'Invalid URL',
        number: 'Must be a number',
        integer: 'Must be an integer',
        alphanumeric: 'Letters and numbers only',
        password: 'Invalid password',
        match: 'Fields do not match',
        date: 'Invalid date',
        phoneNumber: 'Invalid phone number',
        zipCode: 'Invalid ZIP code',
        creditCard: 'Invalid credit card number'
      }
    },
    
    // Trip features
    trips: {
      title: 'My Trips',
      new: 'New Trip',
      edit: 'Edit Trip',
      delete: 'Delete Trip',
      details: 'Trip Details',
      itinerary: 'Itinerary',
      expenses: 'Expenses',
      photos: 'Photos',
      notes: 'Notes',
      map: 'Map',
      shareTrip: 'Share Trip',
      exportTrip: 'Export Trip',
      importTrip: 'Import Trip',
      deleteConfirm: 'Are you sure you want to delete this trip?',
      noTrips: 'You don\'t have any trips yet',
      createFirstTrip: 'Create your first trip',
      tripName: 'Trip name',
      destination: 'Destination',
      startDate: 'Start date',
      endDate: 'End date',
      companions: 'Companions',
      status: {
        upcoming: 'Upcoming',
        inProgress: 'In progress',
        completed: 'Completed',
        cancelled: 'Cancelled'
      },
      transportType: {
        title: 'Transport type',
        car: 'Car',
        bus: 'Bus',
        train: 'Train',
        airplane: 'Airplane',
        boat: 'Boat',
        walking: 'Walking',
        bicycle: 'Bicycle',
        other: 'Other'
      },
      accommodation: {
        title: 'Accommodation',
        hotel: 'Hotel',
        hostel: 'Hostel',
        apartment: 'Apartment',
        house: 'House',
        camping: 'Camping',
        other: 'Other'
      },
      budget: {
        title: 'Budget',
        estimated: 'Estimated',
        actual: 'Actual',
        remaining: 'Remaining',
        currency: 'Currency',
        expenses: 'Expenses',
        income: 'Income',
        categories: {
          accommodation: 'Accommodation',
          transportation: 'Transportation',
          food: 'Food',
          activities: 'Activities',
          shopping: 'Shopping',
          other: 'Other'
        }
      }
    },
    
    // Sync features
    sync: {
      title: 'Synchronization',
      lastSync: 'Last sync: {{time}}',
      syncing: 'Syncing...',
      syncComplete: 'Sync complete',
      syncError: 'Sync error',
      syncSettings: 'Sync settings',
      autoSync: 'Auto sync',
      syncNow: 'Sync now',
      offlineChanges: 'Offline changes',
      uploadingData: 'Uploading data...',
      downloadingData: 'Downloading data...',
      conflictResolution: {
        title: 'Conflict resolution',
        local: 'Keep local version',
        remote: 'Keep remote version',
        manual: 'Resolve manually'
      }
    },
    
    // Language and region features
    locale: {
      title: 'Language & Region',
      language: 'Language',
      region: 'Region',
      dateFormat: 'Date format',
      timeFormat: 'Time format',
      timezone: 'Time zone',
      currency: 'Currency',
      measurementSystem: 'Measurement system',
      decimal: 'Decimal separator',
      thousands: 'Thousands separator',
      firstDayOfWeek: 'First day of week',
      applyChanges: 'Apply changes',
      systemDefault: 'System default'
    }
  },
  
  // Language metadata
  metadata: {
    name: 'English (United States)',
    nameEnglish: 'English (United States)',
    isRTL: false,
    momentLocale: 'en',
    dateFormat: {
      short: 'MM/DD/YYYY',
      medium: 'MMM D, YYYY',
      long: 'MMMM D, YYYY',
      full: 'dddd, MMMM D, YYYY'
    },
    timeFormat: {
      short: 'h:mm A',
      medium: 'h:mm:ss A',
      long: 'h:mm:ss A z',
      full: 'h:mm:ss A zzzz'
    },
    currency: {
      code: 'USD',
      symbol: '$',
      format: '{symbol}{amount}',
      decimal: '.',
      thousand: ','
    },
    country: 'US',
    numberFormat: {
      decimal: '.',
      thousand: ',',
      precision: 2
    },
    units: {
      system: 'imperial',
      temperature: 'fahrenheit',
      distance: {
        short: 'ft',
        long: 'foot',
        plural: 'feet'
      },
      speed: 'mph',
      weight: 'lb'
    }
  }
};

export default enUS;