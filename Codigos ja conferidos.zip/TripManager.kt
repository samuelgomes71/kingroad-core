// TripManager.kt
package com.kingroad.native

import android.content.Context
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableArray
import com.kingroad.database.TripEntity
import com.kingroad.database.TripRepository
import com.kingroad.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Date

/**
 * Módulo nativo para gerenciamento de viagens no King Road
 */
class TripManager(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val MODULE_NAME = "TripManager"
        private const val TAG = "TripManager"
        private const val DAYS_TO_FETCH = 15 // Dias para buscar histórico
    }

    private val ioScope = CoroutineScope(Dispatchers.IO)
    
    override fun getName(): String = MODULE_NAME

    /**
     * Obtém viagens recentes (dos últimos 15 dias)
     * @param promise Promise para retorno assíncrono para o React Native
     */
    @ReactMethod
    fun getRecentTrips(promise: Promise) {
        ioScope.launch {
            try {
                val repository = TripRepository(reactContext)
                
                // Calcular data limite (15 dias atrás)
                val calendar = Calendar.getInstance()
                calendar.add(Calendar.DAY_OF_YEAR, -DAYS_TO_FETCH)
                val cutoffDate = calendar.timeInMillis
                
                // Buscar viagens
                val trips = repository.getTripsAfterDate(cutoffDate)
                
                // Ordenar por data (mais recente primeiro)
                val sortedTrips = trips.sortedByDescending { it.startDate }
                
                // Converter para formato ReactNative
                val result = convertTripsToWritableArray(sortedTrips)
                
                // Entregar resultado
                promise.resolve(result)
                
            } catch (e: Exception) {
                Logger.e(TAG, "Erro ao buscar viagens recentes: ${e.message}")
                promise.reject("TRIP_ERROR", "Falha ao buscar viagens recentes: ${e.message}")
            }
        }
    }
    
    /**
     * Converte lista de entidades de viagem para formato WritableArray do React Native
     * @param trips Lista de entidades de viagem
     * @return WritableArray para envio ao React Native
     */
    private suspend fun convertTripsToWritableArray(trips: List<TripEntity>): WritableArray = withContext(Dispatchers.Default) {
        val result = Arguments.createArray()
        
        trips.forEach { trip ->
            val tripMap = Arguments.createMap().apply {
                putDouble("id", trip.id.toDouble())
                putString("name", trip.name)
                putString("startAddress", trip.startAddress)
                putString("endAddress", trip.endAddress)
                putDouble("startLat", trip.startLat)
                putDouble("startLng", trip.startLng)
                putDouble("endLat", trip.endLat)
                putDouble("endLng", trip.endLng)
                putDouble("startDate", trip.startDate.toDouble())
                trip.endDate?.let { putDouble("endDate", it.toDouble()) }
                putDouble("distanceKm", trip.distanceKm)
                putInt("estimatedDurationMinutes", trip.estimatedDurationMinutes)
                trip.actualDurationMinutes?.let { putInt("actualDurationMinutes", it) }
                putBoolean("isActive", trip.isActive)
                putBoolean("isCompleted", trip.isCompleted)
                putBoolean("isFavorite", trip.isFavorite)
            }
            
            result.pushMap(tripMap)
        }
        
        return@withContext result
    }
}