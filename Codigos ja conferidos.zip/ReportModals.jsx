import React, { useState, useRef } from 'react';
import { CommonButton } from './commonButtons';

/**
 * Componente para exibir modais de reportes
 * Suporta diferentes tipos de reportes com formulários personalizados
 */
const ReportModals = ({ 
  type, 
  onClose, 
  onSubmit, 
  currentLocation,
  translations 
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    severity: 'medium',
    photos: [],
    anonymous: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef(null);
  
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length + formData.photos.length > 3) {
      alert(translations['Máximo de 3 fotos'] || 'Maximum of 3 photos allowed');
      return;
    }
    
    // Converter arquivos para URLs de preview
    const newPhotos = files.map(file => ({
      file,
      preview: URL.createObjectURL(file)
    }));
    
    setFormData({
      ...formData,
      photos: [...formData.photos, ...newPhotos]
    });
  };
  
  const handleRemovePhoto = (index) => {
    const newPhotos = [...formData.photos];
    const removedPhoto = newPhotos[index];
    
    // Liberar URL de preview para evitar vazamento de memória
    if (removedPhoto && removedPhoto.preview) {
      URL.revokeObjectURL(removedPhoto.preview);
    }
    
    newPhotos.splice(index, 1);
    setFormData({
      ...formData,
      photos: newPhotos
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Validações básicas
      if (!formData.title.trim()) {
        throw new Error(translations['Título é obrigatório'] || 'Title is required');
      }
      
      if (!formData.description.trim()) {
        throw new Error(translations['Por favor, adicione um comentário.'] || 'Description is required');
      }
      
      // Preparar dados para envio
      const reportData = {
        ...formData,
        type: type.id,
        location: {
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude
        }
      };
      
      // Envio de fotos seria feito aqui em um cenário real
      // Usaria upload para o Firebase Storage ou outro serviço
      
      await onSubmit(reportData);
    } catch (error) {
      alert(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Determinar o título do modal baseado no tipo
  const modalTitle = type ? (translations[type.name] || type.name) : '';
  
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity dark:bg-gray-900 dark:bg-opacity-75"></div>
      
      <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full dark:bg-gray-800">
          {/* Header */}
          <div className="bg-gray-50 px-4 py-3 sm:px-6 flex justify-between items-center dark:bg-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              {modalTitle}
            </h3>
            <button
              type="button"
              className="rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:hover:text-white"
              onClick={onClose}
            >
              <span className="sr-only">{translations['Fechar'] || 'Close'}</span>
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Formulário */}
          <form onSubmit={handleSubmit}>
            <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 dark:bg-gray-800">
              <div className="sm:flex sm:items-start">
                <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10 dark:bg-blue-900">
                  {type && type.icon}
                </div>
                <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                  <div className="mt-2">
                    {/* Título */}
                    <div className="mb-4">
                      <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        {translations['Título'] || 'Title'}*
                      </label>
                      <input
                        type="text"
                        name="title"
                        id="title"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        value={formData.title}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    
                    {/* Descrição */}
                    <div className="mb-4">
                      <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        {translations['Descrição'] || 'Description'}*
                      </label>
                      <textarea
                        name="description"
                        id="description"
                        rows="3"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        placeholder={translations['Descreva o problema detalhadamente...'] || 'Describe the issue in detail...'}
                        value={formData.description}
                        onChange={handleInputChange}
                        required
                      ></textarea>
                    </div>
                    
                    {/* Severidade */}
                    <div className="mb-4">
                      <label htmlFor="severity" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        {translations['Severidade'] || 'Severity'}
                      </label>
                      <select
                        name="severity"
                        id="severity"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        value={formData.severity}
                        onChange={handleInputChange}
                      >
                        <option value="low">{translations['Baixa'] || 'Low'}</option>
                        <option value="medium">{translations['Média'] || 'Medium'}</option>
                        <option value="high">{translations['Alta'] || 'High'}</option>
                      </select>
                    </div>
                    
                    {/* Upload de fotos */}
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        {translations['Fotos'] || 'Photos'} ({formData.photos.length}/3)
                      </label>
                      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md dark:border-gray-600">
                        <div className="space-y-1 text-center">
                          <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                          <div className="flex text-sm text-gray-600 dark:text-gray-400">
                            <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-500 dark:bg-gray-700 dark:text-blue-400 dark:hover:text-blue-300">
                              <span>{translations['Carregar fotos'] || 'Upload photos'}</span>
                              <input 
                                id="file-upload" 
                                name="file-upload" 
                                type="file"
                                accept="image/*"
                                multiple
                                className="sr-only"
                                ref={fileInputRef}
                                onChange={handlePhotoUpload}
                              />
                            </label>
                            <p className="pl-1">{translations['ou arraste e solte'] || 'or drag and drop'}</p>
                          </div>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            PNG, JPG, GIF {translations['até'] || 'up to'} 10MB
                          </p>
                        </div>
                      </div>
                      
                      {/* Preview de fotos */}
                      {formData.photos.length > 0 && (
                        <div className="mt-4 grid grid-cols-3 gap-4">
                          {formData.photos.map((photo, index) => (
                            <div key={index} className="relative">
                              <img 
                                src={photo.preview} 
                                alt={`Preview ${index}`} 
                                className="h-24 w-full object-cover rounded-md" 
                              />
                              <button
                                type="button"
                                className="absolute -top-2 -right-2 bg-red-600 rounded-full w-6 h-6 flex items-center justify-center text-white"
                                onClick={() => handleRemovePhoto(index)}
                              >
                                <span className="sr-only">{translations['Remover'] || 'Remove'}</span>
                                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    {/* Opção anônima */}
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="anonymous"
                          name="anonymous"
                          type="checkbox"
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                          checked={formData.anonymous}
                          onChange={handleInputChange}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="anonymous" className="font-medium text-gray-700 dark:text-gray-300">
                          {translations['Reportar anonimamente'] || 'Report anonymously'}
                        </label>
                        <p className="text-gray-500 dark:text-gray-400">
                          {translations['Seu nome não será exibido para outros usuários'] || 'Your name will not be shown to other users'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Botões de ação */}
            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse dark:bg-gray-700">
              <button
                type="submit"
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {translations['Enviando...'] || 'Submitting...'}
                  </>
                ) : (
                  translations['Enviar Reporte'] || 'Submit Report'
                )}
              </button>
              <button
                type="button"
                className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm dark:bg-gray-600 dark:border-gray-500 dark:text-white dark:hover:bg-gray-500"
                onClick={onClose}
              >
                {translations['Cancelar'] || 'Cancel'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ReportModals;