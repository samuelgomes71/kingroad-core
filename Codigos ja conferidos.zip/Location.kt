data class Location(
    val latitude: Double,
    val longitude: Double,
    val accessRoutes: List<AccessRoute> = emptyList()
)

data class AccessRoute(
    val name: String,
    val type: RouteType,
    val restrictions: List<RouteRestriction>,
    val recommendedForTrucks: Boolean,
    val instructions: String
)

enum class RouteType {
    MAIN_ENTRANCE,
    TRUCK_ENTRANCE,
    LOADING_ENTRANCE,
    EMERGENCY_ENTRANCE
}

data class RouteRestriction(
    val type: RestrictionType,
    val value: String
)

enum class RestrictionType {
    HEIGHT,
    WIDTH,
    WEIGHT,
    TIME_WINDOW,
    SPECIAL_PERMIT
}