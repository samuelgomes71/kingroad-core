import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Truck, Search, MapPin, Star, DollarSign, Calendar, Package, Flag, Menu, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Componente principal
const OwnerOperatorApp = () => {
  const [activePage, setActivePage] = useState('cargas');
  const [menuOpen, setMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [loads, setLoads] = useState([]);
  const [selectedLoad, setSelectedLoad] = useState(null);
  const [favoriteLoads, setFavoriteLoads] = useState([]);
  const [bookedLoads, setBookedLoads] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('all');
  
  // Menu itens
  const menuItems = [
    { id: 'cargas', icon: <Package size={28} />, label: 'Buscar Cargas', color: 'bg-amber-600' },
    { id: 'minhas-cargas', icon: <Truck size={28} />, label: 'Minhas Cargas', color: 'bg-amber-600' },
    { id: 'favoritas', icon: <Star size={28} />, label: 'Favoritas', color: 'bg-amber-600' },
    { id: 'melhor-preco', icon: <DollarSign size={28} />, label: 'Melhor Preço', color: 'bg-amber-600' },
    { id: 'perto-de-mim', icon: <MapPin size={28} />, label: 'Perto de Mim', color: 'bg-amber-600' }
  ];
// Mock data - Em produção viria da API
  useEffect(() => {
    setTimeout(() => {
      setLoads([
        {
          id: '1',
          origin: 'São Paulo, SP',
          destination: 'Rio de Janeiro, RJ',
          distance: '430 km',
          price: 'R$ 3.200',
          pickupDate: '18/03/2025',
          deliveryDate: '19/03/2025',
          broker: 'TransLog Brasil',
          brokerRating: 4.7,
          loadType: 'Carga seca',
          weight: '15.000 kg',
          highValue: true,
          quickPay: true,
          country: 'Brasil'
        },
        {
          id: '2',
          origin: 'Curitiba, PR',
          destination: 'Florianópolis, SC',
          distance: '310 km',
          price: 'R$ 2.480',
          pickupDate: '19/03/2025',
          deliveryDate: '20/03/2025',
          broker: 'SulCargas',
          brokerRating: 4.3,
          loadType: 'Refrigerada',
          weight: '12.000 kg',
          highValue: false,
          quickPay: true,
          country: 'Brasil'
        },
        {
          id: '3',
          origin: 'Houston, TX',
          destination: 'Dallas, TX',
          distance: '240 mi',
          price: '$780',
          pickupDate: '03/18/2025',
          deliveryDate: '03/19/2025',
          broker: 'US Logistics',
          brokerRating: 4.6,
          loadType: 'Dry van',
          weight: '35,000 lbs',
          highValue: false,
          quickPay: true,
          country: 'USA'
        },
        {
          id: '4',
          origin: 'Madrid',
          destination: 'Barcelona',
          distance: '620 km',
          price: '€780',
          pickupDate: '18/03/2025',
          deliveryDate: '19/03/2025',
          broker: 'Transporte Ibérico',
          brokerRating: 4.5,
          loadType: 'Carga general',
          weight: '12.500 kg',
          highValue: false,
          quickPay: true,
          country: 'España'
        },
        {
          id: '5',
          origin: 'Paris',
          destination: 'Lyon',
          distance: '470 km',
          price: '€690',
          pickupDate: '19/03/2025',
          deliveryDate: '20/03/2025',
          broker: 'TransportFR',
          brokerRating: 4.7,
          loadType: 'Fret sec',
          weight: '14.000 kg',
          highValue: true,
          quickPay: true,
          country: 'France'
        }
      ]);
      setIsLoading(false);
    }, 1000);
  }, []);

  // Funções de controle
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };
  
  const handlePageChange = (page) => {
    setActivePage(page);
    setSelectedLoad(null);
    setMenuOpen(false);
  };

  const toggleFavorite = (loadId) => {
    if (favoriteLoads.includes(loadId)) {
      setFavoriteLoads(favoriteLoads.filter(id => id !== loadId));
    } else {
      setFavoriteLoads([...favoriteLoads, loadId]);
    }
  };

  const handleBookLoad = (load) => {
    if (!bookedLoads.includes(load.id)) {
      setBookedLoads([...bookedLoads, load.id]);
      alert(`Carga de ${load.origin} para ${load.destination} reservada com sucesso!`);
    }
  };

  const handleLoadSelect = (load) => {
    setSelectedLoad(load);
  };
// Filtrar cargas
  const getFilteredLoads = () => {
    let filtered = [...loads];
    
    // Filtrar por país
    if (selectedCountry !== 'all') {
      filtered = filtered.filter(load => load.country === selectedCountry);
    }
    
    // Filtrar por busca
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(load => 
        load.origin.toLowerCase().includes(query) || 
        load.destination.toLowerCase().includes(query)
      );
    }
    
    // Filtrar por tipo de página
    if (activePage === 'minhas-cargas') {
      filtered = filtered.filter(load => bookedLoads.includes(load.id));
    } else if (activePage === 'favoritas') {
      filtered = filtered.filter(load => favoriteLoads.includes(load.id));
    } else if (activePage === 'melhor-preco') {
      filtered.sort((a, b) => {
        const priceA = parseFloat(a.price.replace(/[^0-9.,]/g, '').replace(',', '.'));
        const priceB = parseFloat(b.price.replace(/[^0-9.,]/g, '').replace(',', '.'));
        return priceA - priceB;
      });
    } else if (activePage === 'perto-de-mim') {
      filtered.sort((a, b) => {
        const distA = parseInt(a.distance.split(' ')[0].replace('.', ''));
        const distB = parseInt(b.distance.split(' ')[0].replace('.', ''));
        return distA - distB;
      });
    }
    
    return filtered;
  };

  // Renderização dos cartões de carga
  const renderLoadCard = (load) => {
    const isFavorite = favoriteLoads.includes(load.id);
    const isBooked = bookedLoads.includes(load.id);
    
    return (
      <Card 
        key={load.id} 
        className={`mb-3 border border-gray-700 ${selectedLoad?.id === load.id ? 'border-2 border-amber-500' : ''}`}
        onClick={() => handleLoadSelect(load)}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <MapPin size={20} className="text-amber-500" />
                <div className="font-bold text-lg">{load.origin}</div>
              </div>
              
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={20} className="text-red-500" />
                <div className="font-bold text-lg">{load.destination}</div>
              </div>
              
              <div className="flex flex-col gap-1 text-sm">
                <div className="flex items-center gap-2">
                  <Truck size={16} className="text-gray-400" />
                  <span>{load.distance} • {load.loadType}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Calendar size={16} className="text-gray-400" />
                  <span>Coleta: {load.pickupDate}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Flag size={16} className="text-gray-400" />
                  <span>{load.country}</span>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col items-end gap-2">
              <div className="flex items-center">
                <DollarSign size={18} className="text-green-500" />
                <span className="font-bold text-xl text-green-500">{load.price}</span>
              </div>
              
              <div className="flex">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(load.id);
                  }}
                >
                  <Star size={20} className={isFavorite ? "fill-amber-500 text-amber-500" : "text-gray-400"} />
                </Button>
              </div>
              
              {!isBooked && (
                <Button 
                  className="bg-amber-600 hover:bg-amber-700 mt-2" 
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleBookLoad(load);
                  }}
                >
                  Reservar Carga
                </Button>
              )}
              
              {isBooked && (
                <Badge className="bg-blue-900/30 text-blue-400 border-blue-600">
                  Carga Reservada
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };
// Renderizar os detalhes da carga selecionada
  const renderLoadDetails = () => {
    if (!selectedLoad) return null;
    
    const isBooked = bookedLoads.includes(selectedLoad.id);
    const isFavorite = favoriteLoads.includes(selectedLoad.id);
    
    return (
      <div className="p-4 bg-gray-900 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Detalhes da Carga</h2>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleFavorite(selectedLoad.id)}
            >
              <Star size={20} className={isFavorite ? "fill-amber-500 text-amber-500" : "text-gray-400"} />
              {isFavorite ? "Favorita" : "Favoritar"}
            </Button>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-4 mb-4">
          <div className="flex gap-4 items-center mb-3">
            <div className="w-4 h-4 rounded-full bg-green-500"></div>
            <div className="font-bold text-lg">{selectedLoad.origin}</div>
          </div>
          
          <div className="h-8 border-l-2 border-dashed border-gray-600 ml-2"></div>
          
          <div className="flex gap-4 items-center">
            <div className="w-4 h-4 rounded-full bg-red-500"></div>
            <div className="font-bold text-lg">{selectedLoad.destination}</div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="font-bold mb-2">Preço</h3>
            <div className="text-2xl font-bold text-green-500">{selectedLoad.price}</div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="font-bold mb-2">Datas</h3>
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <Calendar size={16} />
                <span>Coleta: {selectedLoad.pickupDate}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={16} />
                <span>Entrega: {selectedLoad.deliveryDate}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="font-bold mb-2">Detalhes</h3>
            <div className="flex flex-col gap-1">
              <div>Tipo: {selectedLoad.loadType}</div>
              <div>Peso: {selectedLoad.weight}</div>
              <div>Distância: {selectedLoad.distance}</div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-4">
            <h3 className="font-bold mb-2">Broker</h3>
            <div className="font-bold">{selectedLoad.broker}</div>
            <div className="flex items-center mt-1">
              <Star size={16} className="text-amber-500 fill-amber-500 mr-1" />
              <span>{selectedLoad.brokerRating}/5.0</span>
            </div>
          </div>
        </div>
        
        {!isBooked ? (
          <Button 
            className="w-full bg-amber-600 hover:bg-amber-700 text-lg py-6" 
            onClick={() => handleBookLoad(selectedLoad)}
          >
            <Truck size={24} className="mr-2" />
            Reservar esta Carga
          </Button>
        ) : (
          <div className="flex flex-col gap-2">
            <div className="bg-blue-900/30 text-blue-400 border border-blue-600 rounded-md p-3 text-center">
              Esta carga já está reservada por você
            </div>
            <Button className="w-full bg-amber-600 hover:bg-amber-700 text-lg py-6">
              <MapPin size={24} className="mr-2" />
              Iniciar Navegação
            </Button>
          </div>
        )}
      </div>
    );
  };
// Tela de carregamento
  if (isLoading) {
    return (
      <div className="bg-black text-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="text-xl">Carregando KingRoad...</p>
        </div>
      </div>
    );
  }

  // Lista de países disponíveis
  const countries = ['all', ...new Set(loads.map(load => load.country))];

  return (
    <div className="bg-black text-white min-h-screen">
      {/* Menu do topo */}
      <div className="bg-gray-900 border-b border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img 
                src="/api/placeholder/40/40" 
                alt="KingRoad Logo" 
                className="h-8 w-8 mr-2"
              />
              <span className="text-xl font-bold">KingRoad</span>
            </div>
            
            <div className="lg:hidden">
              <Button 
                onClick={toggleMenu} 
                className="bg-amber-600 hover:bg-amber-700 p-2 rounded-full"
                size="icon"
              >
                {menuOpen ? <X size={24} /> : <Menu size={24} />}
              </Button>
            </div>
            
            <div className="hidden lg:flex items-center space-x-2">
              {menuItems.map(item => (
                <Button
                  key={item.id}
                  onClick={() => handlePageChange(item.id)}
                  className={`${
                    activePage === item.id 
                      ? 'bg-amber-600 hover:bg-amber-700' 
                      : 'bg-gray-800 hover:bg-gray-700'
                  } px-4`}
                >
                  <div className="flex items-center">
                    <div className="mr-2">{item.icon}</div>
                    <span>{item.label}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Menu mobile */}
      {menuOpen && (
        <div className="lg:hidden bg-gray-900 border-b border-gray-800">
          <div className="container mx-auto p-4">
            <div className="grid grid-cols-2 gap-2">
              {menuItems.map(item => (
                <Button
                  key={item.id}
                  onClick={() => handlePageChange(item.id)}
                  className={`${
                    activePage === item.id 
                      ? 'bg-amber-600 hover:bg-amber-700' 
                      : 'bg-gray-800 hover:bg-gray-700'
                  } flex flex-col items-center py-4`}
                >
                  <div className="mb-1">{item.icon}</div>
                  <span>{item.label}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}
      
      {/* Conteúdo principal */}
      <div className="container mx-auto p-4">
        <div className="flex items-center mb-6">
          <Package size={32} className="text-amber-500 mr-3" />
          <h1 className="text-2xl font-bold">
            {activePage === 'cargas' && 'Cargas Disponíveis'}
            {activePage === 'minhas-cargas' && 'Minhas Cargas'}
            {activePage === 'favoritas' && 'Cargas Favoritas'}
            {activePage === 'melhor-preco' && 'Melhor Preço'}
            {activePage === 'perto-de-mim' && 'Cargas Próximas'}
          </h1>
        </div>
        
        {/* Barra de busca e filtros */}
        <div className="mb-6">
          <div className="flex flex-col md:flex-row gap-2">
            <div className="relative flex-1">
              <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar origem ou destino..."
                className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <select 
              className="bg-gray-800 border border-gray-700 rounded-lg p-3 text-white"
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
            >
              {countries.map(country => (
                <option key={country} value={country}>
                  {country === 'all' ? 'Todos os Países' : country}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        {/* Conteúdo principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lista de cargas */}
          <div className="lg:col-span-2">
            <div className="space-y-3">
              {getFilteredLoads().length > 0 ? (
                getFilteredLoads().map(load => renderLoadCard(load))
              ) : (
                <div className="text-center py-12 bg-gray-900 rounded-lg">
                  <Package size={48} className="mx-auto mb-4 text-gray-600" />
                  <p className="text-xl font-medium mb-2">Nenhuma carga encontrada</p>
                  <p className="text-gray-400 mb-6">
                    {activePage === 'minhas-cargas' && 'Você ainda não reservou nenhuma carga.'}
                    {activePage === 'favoritas' && 'Você ainda não marcou nenhuma carga como favorita.'}
                    {(activePage === 'cargas' || activePage === 'melhor-preco' || activePage === 'perto-de-mim') && 'Não encontramos cargas com os filtros atuais.'}
                  </p>
                  
                  {activePage !== 'cargas' && (
                    <Button 
                      className="bg-amber-600 hover:bg-amber-700" 
                      onClick={() => handlePageChange('cargas')}
                    >
                      <Search size={18} className="mr-2" />
                      Buscar Cargas
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
          
          {/* Detalhes da carga */}
          <div>
            {selectedLoad ? (
              renderLoadDetails()
            ) : (
              <div className="bg-gray-900 rounded-lg p-6 text-center">
                <Truck size={64} className="mx-auto mb-4 text-gray-600" />
                <h3 className="text-xl font-medium mb-2">Selecione uma carga</h3>
                <p className="text-gray-400 mb-4">
                  Toque em uma carga para ver mais detalhes e fazer a reserva.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Barra de navegação inferior para mobile */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 z-10">
        <div className="flex justify-around">
          {menuItems.map(item => (
            <Button
              key={item.id}
              onClick={() => handlePageChange(item.id)}
              className={`flex-1 flex flex-col items-center justify-center py-2 bg-transparent ${
                activePage === item.id ? 'text-amber-500' : 'text-white'
              }`}
              size="sm"
            >
              <div>{React.cloneElement(item.icon, { size: 24 })}</div>
              <span className="text-xs mt-1">{item.label.split(' ')[0]}</span>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OwnerOperatorApp;

