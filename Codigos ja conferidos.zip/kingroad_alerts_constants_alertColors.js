export const alertColors = {
  warning: {
    background: '#ffee00',
    triangle: '#111111',
    symbol: '#ffee00',
    text: '#111111'
  },
  danger: {
    background: '#ff5500',
    triangle: '#331111',
    symbol: '#ff5500',
    text: '#ffffff'
  },
  custom: {
    background: '#3366ff',
    triangle: '#112244',
    symbol: '#3366ff',
    text: '#ffffff'
  }
};