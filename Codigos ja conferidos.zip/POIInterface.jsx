import React, { useState } from 'react';
import { Truck, Home, Car, Bus, Bike, Filter, Map, Info } from 'lucide-react';

const POIInterface = () => {
  const [selectedVehicle, setSelectedVehicle] = useState('TRUCK');
  const [showFilters, setShowFilters] = useState(false);
  
  return (
    <div className="h-screen bg-gray-100">
      {/* Barra superior com seleção de veículo */}
      <div className="bg-blue-700 p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-white text-xl font-bold">Points of Interest</h1>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-blue-600 p-2 rounded-full"
          >
            <Filter className="text-white" />
          </button>
        </div>
        
        {/* Seleção de tipo de veículo */}
        <div className="mt-4 flex space-x-4">
          {[
            { icon: Truck, label: 'TRUCK' },
            { icon: Home, label: 'RV' },
            { icon: Car, label: 'CAR' },
            { icon: Bus, label: 'BUS' },
            { icon: Bike, label: 'MOTORCYCLE' }
          ].map(({ icon: Icon, label }) => (
            <button
              key={label}
              onClick={() => setSelectedVehicle(label)}
              className={`p-3 rounded-lg flex flex-col items-center ${
                selectedVehicle === label
                  ? 'bg-white text-blue-700'
                  : 'bg-blue-600 text-white'
              }`}
            >
              <Icon size={24} />
              <span className="text-xs mt-1">{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Lista de POIs */}
      <div className="p-4 space-y-4">
        {/* POI Card */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-lg">Flying J Truck Stop</h3>
              <p className="text-sm text-gray-600">I-95 Exit 145, Florida</p>
              
              {/* Informações específicas para caminhões */}
              {selectedVehicle === 'TRUCK' && (
                <div className="mt-2 space-y-1">
                  <div className="flex items-center text-sm text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                    15 vagas disponíveis
                  </div>
                  <div className="flex items-center text-sm">
                    <span className="font-medium mr-2">Altura máx:</span>
                    4.5m
                  </div>
                </div>
              )}
              
              {/* Serviços disponíveis */}
              <div className="mt-3 flex space-x-2">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                  Chuveiros
                </span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                  Restaurante
                </span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                  Diesel
                </span>
              </div>
            </div>
            
            <div className="flex space-x-2">
              <button className="p-2 hover:bg-gray-100 rounded-full">
                <Map size={20} className="text-blue-600" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full">
                <Info size={20} className="text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Painel de filtros */}
      {showFilters && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-xl font-bold mb-4">Filtros</h3>
            
            <div className="space-y-4">
              <div>
                <label className="font-medium">Serviços</label>
                <div className="mt-2 space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Estacionamento Seguro
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Chuveiros
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Restaurante
                  </label>
                </div>
              </div>
              
              <div>
                <label className="font-medium">Tipo de Estacionamento</label>
                <div className="mt-2 space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Gratuito
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Pernoite permitido
                  </label>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex space-x-4">
              <button
                onClick={() => setShowFilters(false)}
                className="flex-1 py-2 border border-gray-300 rounded-lg"
              >
                Cancelar
              </button>
              <button className="flex-1 py-2 bg-blue-600 text-white rounded-lg">
                Aplicar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default POIInterface;