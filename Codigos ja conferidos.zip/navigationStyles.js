// navigationStyles.js
// Estilos globais reutilizáveis no módulo de navegação do KingRoad

import { StyleSheet } from 'react-native';

const navigationStyles = StyleSheet.create({
  panelBase: {
    backgroundColor: '#f9f4ed', // Bege claro da Família King
    borderColor: '#4e342e',     // Bordas tom café escuro
    borderWidth: 1.5,
    borderRadius: 12,
    padding: 12,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4
  },

  panelDark: {
    backgroundColor: '#1a1a1a',
    borderColor: '#5e5e5e'
  },

  textBase: {
    fontSize: 14,
    color: '#3e2723'
  },

  textDark: {
    color: '#f5f5f5'
  },

  roundedButton: {
    borderRadius: 50,
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fbe9e7'
  },

  roundedButtonDark: {
    backgroundColor: '#333'
  },

  iconLight: {
    color: '#ffffff'
  },

  iconDark: {
    color: '#000000'
  },

  overlayContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(255, 235, 205, 0.9)',
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#a1887f',
    zIndex: 999
  },

  overlayText: {
    fontSize: 14,
    textAlign: 'center',
    color: '#3e2723'
  }
});

export default navigationStyles;