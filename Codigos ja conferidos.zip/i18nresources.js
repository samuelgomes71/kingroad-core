/**
 * i18n/resources.js
 * 
 * Arquivo de recursos de internacionalização.
 * Implementa estrutura básica para recursos de internacionalização,
 * com suporte aos 34 idiomas suportados pela aplicação.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

// Importações dos recursos de idioma específicos
import ptBR from './locales/pt-BR';
import enUS from './locales/en-US';
import esES from './locales/es-ES';
import frFR from './locales/fr-FR';
import deDE from './locales/de-DE';

/**
 * Recursos de internacionalização para todos os idiomas suportados
 * 
 * Estrutura:
 * {
 *   [locale]: {
 *     translation: {
 *       // Chaves de tradução para este idioma
 *       key: 'value'
 *     },
 *     // Metadados específicos do idioma
 *     metadata: {
 *       name: 'Nome do idioma na sua própria língua',
 *       nameEnglish: 'Nome do idioma em inglês',
 *       isRTL: false // Se o idioma é escrito da direita para a esquerda
 *     }
 *   }
 * }
 */
const resources = {
  // Português (Brasil) - Idioma padrão e completo
  'pt-BR': ptBR,
  
  // Inglês (EUA) - Segundo idioma mais importante, também completo
  'en-US': enUS,
  
  // Outros idiomas importantes com traduções completas
  'es-ES': esES,
  'fr-FR': frFR,
  'de-DE': deDE,
  
  // Idiomas adicionais
  // Nota: Para economizar espaço, os idiomas menos comuns importam apenas
  // os metadados e chaves básicas, com fallback para inglês
  
  // Italiano (Itália)
  'it-IT': {
    translation: {
      // Chaves essenciais específicas para italiano
      app: {
        name: 'KingRoad',
        welcome: 'Benvenuto in KingRoad',
        tagline: 'Il tuo assistente di viaggio personale'
      },
      // Outras traduções usarão o fallback (inglês)
      _extends: 'en-US'
    },
    metadata: {
      name: 'Italiano',
      nameEnglish: 'Italian',
      isRTL: false
    }
  },
  
  // Japonês (Japão)
  'ja-JP': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'KingRoadへようこそ',
        tagline: 'あなたの個人的な旅行アシスタント'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: '日本語',
      nameEnglish: 'Japanese',
      isRTL: false
    }
  },
  
  // Coreano (Coreia do Sul)
  'ko-KR': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'KingRoad에 오신 것을 환영합니다',
        tagline: '당신의 개인 여행 도우미'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: '한국어',
      nameEnglish: 'Korean',
      isRTL: false
    }
  },
  
  // Chinês Simplificado (China)
  'zh-CN': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: '欢迎使用KingRoad',
        tagline: '您的个人旅行助手'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: '简体中文',
      nameEnglish: 'Simplified Chinese',
      isRTL: false
    }
  },
  
  // Chinês Tradicional (Taiwan)
  'zh-TW': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: '歡迎使用KingRoad',
        tagline: '您的個人旅行助手'
      },
      _extends: 'zh-CN' // Usa chinês simplificado como base
    },
    metadata: {
      name: '繁體中文',
      nameEnglish: 'Traditional Chinese',
      isRTL: false
    }
  },
  
  // Russo (Rússia)
  'ru-RU': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Добро пожаловать в KingRoad',
        tagline: 'Ваш личный помощник в путешествии'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Русский',
      nameEnglish: 'Russian',
      isRTL: false
    }
  },
  
  // Árabe (Arábia Saudita) - RTL
  'ar-SA': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'مرحبًا بك في KingRoad',
        tagline: 'مساعدك الشخصي في السفر'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'العربية',
      nameEnglish: 'Arabic',
      isRTL: true // Importante: idioma da direita para a esquerda
    }
  },
  
  // Hindi (Índia)
  'hi-IN': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'KingRoad में आपका स्वागत है',
        tagline: 'आपका निजी यात्रा सहायक'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'हिन्दी',
      nameEnglish: 'Hindi',
      isRTL: false
    }
  },
  
  // Turco (Turquia)
  'tr-TR': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: "KingRoad'a Hoş Geldiniz",
        tagline: 'Kişisel seyahat asistanınız'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Türkçe',
      nameEnglish: 'Turkish',
      isRTL: false
    }
  },
  
  // Holandês (Países Baixos)
  'nl-NL': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Welkom bij KingRoad',
        tagline: 'Uw persoonlijke reisassistent'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Nederlands',
      nameEnglish: 'Dutch',
      isRTL: false
    }
  },
  
  // Polonês (Polônia)
  'pl-PL': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Witamy w KingRoad',
        tagline: 'Twój osobisty asystent podróży'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Polski',
      nameEnglish: 'Polish',
      isRTL: false
    }
  },
  
  // Sueco (Suécia)
  'sv-SE': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Välkommen till KingRoad',
        tagline: 'Din personliga resassistent'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Svenska',
      nameEnglish: 'Swedish',
      isRTL: false
    }
  },
  
  // Finlandês (Finlândia)
  'fi-FI': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Tervetuloa KingRoadiin',
        tagline: 'Henkilökohtainen matkustusavustajasi'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Suomi',
      nameEnglish: 'Finnish',
      isRTL: false
    }
  },
  
  // Dinamarquês (Dinamarca)
  'da-DK': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Velkommen til KingRoad',
        tagline: 'Din personlige rejseassistent'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Dansk',
      nameEnglish: 'Danish',
      isRTL: false
    }
  },
  
  // Norueguês (Noruega)
  'no-NO': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Velkommen til KingRoad',
        tagline: 'Din personlige reiseassistent'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Norsk',
      nameEnglish: 'Norwegian',
      isRTL: false
    }
  },
  
  // Tcheco (República Tcheca)
  'cs-CZ': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Vítejte v KingRoad',
        tagline: 'Váš osobní cestovní asistent'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Čeština',
      nameEnglish: 'Czech',
      isRTL: false
    }
  },
  
  // Húngaro (Hungria)
  'hu-HU': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Üdvözöljük a KingRoad-ban',
        tagline: 'Az Ön személyes utazási asszisztense'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Magyar',
      nameEnglish: 'Hungarian',
      isRTL: false
    }
  },
  
  // Romeno (Romênia)
  'ro-RO': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Bun venit la KingRoad',
        tagline: 'Asistentul tău personal de călătorie'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Română',
      nameEnglish: 'Romanian',
      isRTL: false
    }
  },
  
  // Búlgaro (Bulgária)
  'bg-BG': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Добре дошли в KingRoad',
        tagline: 'Вашият личен пътнически асистент'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Български',
      nameEnglish: 'Bulgarian',
      isRTL: false
    }
  },
  
  // Grego (Grécia)
  'el-GR': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Καλώς ήρθατε στο KingRoad',
        tagline: 'Ο προσωπικός σας ταξιδιωτικός βοηθός'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Ελληνικά',
      nameEnglish: 'Greek',
      isRTL: false
    }
  },
  
  // Hebraico (Israel) - RTL
  'he-IL': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'ברוכים הבאים ל-KingRoad',
        tagline: 'עוזר הנסיעות האישי שלך'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'עברית',
      nameEnglish: 'Hebrew',
      isRTL: true
    }
  },
  
  // Tailandês (Tailândia)
  'th-TH': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'ยินดีต้อนรับสู่ KingRoad',
        tagline: 'ผู้ช่วยการเดินทางส่วนตัวของคุณ'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'ไทย',
      nameEnglish: 'Thai',
      isRTL: false
    }
  },
  
  // Indonésio (Indonésia)
  'id-ID': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Selamat datang di KingRoad',
        tagline: 'Asisten perjalanan pribadi Anda'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Bahasa Indonesia',
      nameEnglish: 'Indonesian',
      isRTL: false
    }
  },
  
  // Malaio (Malásia)
  'ms-MY': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Selamat datang ke KingRoad',
        tagline: 'Pembantu perjalanan peribadi anda'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Bahasa Melayu',
      nameEnglish: 'Malay',
      isRTL: false
    }
  },
  
  // Vietnamita (Vietnã)
  'vi-VN': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Chào mừng đến với KingRoad',
        tagline: 'Trợ lý du lịch cá nhân của bạn'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Tiếng Việt',
      nameEnglish: 'Vietnamese',
      isRTL: false
    }
  },
  
  // Filipino (Filipinas)
  'fil-PH': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Maligayang pagdating sa KingRoad',
        tagline: 'Ang iyong personal na katulong sa paglalakbay'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Filipino',
      nameEnglish: 'Filipino',
      isRTL: false
    }
  },
  
  // Ucraniano (Ucrânia)
  'uk-UA': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'Ласкаво просимо до KingRoad',
        tagline: 'Ваш особистий помічник у подорожі'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'Українська',
      nameEnglish: 'Ukrainian',
      isRTL: false
    }
  },
  
  // Persa (Irã) - RTL
  'fa-IR': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'به KingRoad خوش آمدید',
        tagline: 'دستیار سفر شخصی شما'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'فارسی',
      nameEnglish: 'Persian',
      isRTL: true
    }
  },
  
  // Bengali (Bangladesh)
  'bn-BD': {
    translation: {
      app: {
        name: 'KingRoad',
        welcome: 'KingRoad এ স্বাগতম',
        tagline: 'আপনার ব্যক্তিগত ভ্রমণ সহকারী'
      },
      _extends: 'en-US'
    },
    metadata: {
      name: 'বাংলা',
      nameEnglish: 'Bengali',
      isRTL: false
    }
  }
};

/**
 * Obtém recursos de tradução para um idioma específico
 * @param {string} locale - Código do locale (ex: pt-BR)
 * @returns {Object} Recursos de tradução para o locale especificado
 */
export const getResourcesForLocale = (locale) => {
  if (!resources[locale]) {
    console.warn(`[i18n] Recursos para o locale "${locale}" não encontrados. Usando o locale padrão (pt-BR).`);
    return resources['pt-BR'];
  }
  
  return resources[locale];
};

/**
 * Obtém os metadados de todos os idiomas suportados
 * @returns {Array<Object>} Lista de metadados de idiomas
 */
export const getLanguagesMetadata = () => {
  return Object.keys(resources).map(locale => ({
    locale,
    ...resources[locale].metadata
  }));
};

/**
 * Processa os recursos para resolver as referências _extends
 * @returns {Object} Recursos processados
 */
export const processResources = () => {
  const processedResources = { ...resources };
  
  // Processa as referências _extends para cada locale
  Object.keys(processedResources).forEach(locale => {
    const resource = processedResources[locale];
    
    if (resource.translation && resource.translation._extends) {
      const baseLocale = resource.translation._extends;
      const baseTranslation = processedResources[baseLocale]?.translation;
      
      if (baseTranslation) {
        // Cria nova tradução combinando o base com as específicas
        const specificTranslations = { ...resource.translation };
        delete specificTranslations._extends;
        
        // Sobrescreve as traduções do base com as específicas
        processedResources[locale].translation = {
          ...baseTranslation,
          ...specificTranslations
        };
      } else {
        console.error(`[i18n] Locale base "${baseLocale}" não encontrado para extensão de "${locale}"`);
      }
    }
  });
  
  return processedResources;
};

export default processResources();