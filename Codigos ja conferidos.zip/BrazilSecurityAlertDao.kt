package com.kingroad.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.kingroad.database.entities.BrazilSecurityAlert
import kotlinx.coroutines.flow.Flow
import java.util.Date

/**
 * DAO para acessar e manipular os alertas de segurança do Brasil no banco de dados
 */
@Dao
interface BrazilSecurityAlertDao {
    
    /**
     * Insere um novo alerta no banco de dados
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: BrazilSecurityAlert): Long
    
    /**
     * Insere múltiplos alertas de uma vez
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<BrazilSecurityAlert>): List<Long>
    
    /**
     * Atualiza um alerta existente
     */
    @Update
    suspend fun updateAlert(alert: BrazilSecurityAlert)
    
    /**
     * Obtém um alerta específico pelo ID
     */
    @Query("SELECT * FROM brazil_security_alerts WHERE id = :alertId")
    suspend fun getAlertById(alertId: String): BrazilSecurityAlert?
    
    /**
     * Obtém todos os alertas ativos (não expirados)
     */
    @Query("SELECT * FROM brazil_security_alerts WHERE expirationTime > :currentTime ORDER BY creationTime DESC")
    fun getActiveAlerts(currentTime: Long = System.currentTimeMillis()): Flow<List<BrazilSecurityAlert>>
    
    /**
     * Obtém alertas próximos a uma localização específica
     * Nota: Este método não faz filtragem por distância, isso deve ser feito na camada de serviço
     */
    @Query("SELECT * FROM brazil_security_alerts WHERE expirationTime > :currentTime ORDER BY creationTime DESC")
    fun getNearbyAlerts(currentTime: Long = System.currentTimeMillis()): Flow<List<BrazilSecurityAlert>>
    
    /**
     * Obtém alertas por tipo
     */
    @Query("SELECT * FROM brazil_security_alerts WHERE type = :alertType AND expirationTime > :currentTime ORDER BY creationTime DESC")
    fun getAlertsByType(alertType: String, currentTime: Long = System.currentTimeMillis()): Flow<List<BrazilSecurityAlert>>
    
    /**
     * Incrementa o contador de confirmações de um alerta
     */
    @Query("UPDATE brazil_security_alerts SET confirmations = confirmations + 1, lastUpdated = :updateTime WHERE id = :alertId")
    suspend fun incrementConfirmations(alertId: String, updateTime: Long = System.currentTimeMillis())
    
    /**
     * Incrementa o contador de reportes falsos de um alerta
     */
    @Query("UPDATE brazil_security_alerts SET falseReports = falseReports + 1, lastUpdated = :updateTime WHERE id = :alertId")
    suspend fun incrementFalseReports(alertId: String, updateTime: Long = System.currentTimeMillis())
    
    /**
     * Marca um alerta como verificado
     */
    @Query("UPDATE brazil_security_alerts SET verified = :isVerified, lastUpdated = :updateTime WHERE id = :alertId")
    suspend fun setAlertVerification(alertId: String, isVerified: Boolean, updateTime: Long = System.currentTimeMillis())
    
    /**
     * Remove alertas expirados
     */
    @Query("DELETE FROM brazil_security_alerts WHERE expirationTime < :currentTime")
    suspend fun deleteExpiredAlerts(currentTime: Long = System.currentTimeMillis()): Int
    
    /**
     * Obtém contagem de alertas por tipo em uma área específica
     * Nota: A filtragem por área geográfica deve ser feita na camada de serviço
     */
    @Query("SELECT type, COUNT(*) as count FROM brazil_security_alerts WHERE expirationTime > :currentTime GROUP BY type")
    suspend fun getAlertCountsByType(currentTime: Long = System.currentTimeMillis()): Map<String, Int>
    
    /**
     * Obtém alertas reportados por um usuário específico
     */
    @Query("SELECT * FROM brazil_security_alerts WHERE reportedBy = :userId AND expirationTime > :currentTime ORDER BY creationTime DESC")
    fun getAlertsByUser(userId: String, currentTime: Long = System.currentTimeMillis()): Flow<List<BrazilSecurityAlert>>
}