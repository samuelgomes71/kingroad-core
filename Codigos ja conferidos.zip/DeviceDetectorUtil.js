/**
 * Utilitário para detectar o tipo de dispositivo e suas características
 * para otimizar downloads no aplicativo KingRoad
 */

/**
 * Enum para categorias de tamanho de dispositivo
 * @readonly
 * @enum {string}
 */
export const DeviceSize = {
  EXTRA_SMALL: 'xs', // ~6 polegadas
  SMALL: 'sm',       // ~7-8 polegadas
  MEDIUM: 'md',      // ~9-10 polegadas
  LARGE: 'lg'        // ~11-12 polegadas
};

/**
 * Detecta o tamanho do dispositivo com base na largura da tela
 * @returns {DeviceSize} O tamanho do dispositivo (xs, sm, md, lg)
 */
export const detectDeviceSize = () => {
  const width = window.innerWidth;
  
  if (width < 600) return DeviceSize.EXTRA_SMALL;
  if (width < 900) return DeviceSize.SMALL;
  if (width < 1200) return DeviceSize.MEDIUM;
  return DeviceSize.LARGE;
};

/**
 * Determina o caminho do recurso apropriado com base no tamanho do dispositivo
 * @param {string} basePath - Caminho base para o recurso (sem o sufixo de tamanho)
 * @param {string} extension - Extensão do arquivo (ex: 'png', 'jpg')
 * @returns {string} Caminho completo para o recurso otimizado
 */
export const getOptimizedResourcePath = (basePath, extension = 'png') => {
  const size = detectDeviceSize();
  return `${basePath}-${size}.${extension}`;
};

/**
 * Calcula o tamanho aproximado de download do aplicativo com base no dispositivo
 * Isso é útil para mostrar ao usuário quanto espaço o app ocupará
 * @returns {Object} Informações sobre o tamanho do download
 */
export const getAppDownloadSize = () => {
  const size = detectDeviceSize();
  
  // Tamanhos de download aproximados para cada categoria de dispositivo
  const baseSizeInMB = 25; // Tamanho base do aplicativo sem recursos específicos
  
  const additionalSizeMap = {
    [DeviceSize.EXTRA_SMALL]: 5,  // +5MB para recursos de tela pequena
    [DeviceSize.SMALL]: 8,        // +8MB para recursos de tela média-pequena
    [DeviceSize.MEDIUM]: 12,      // +12MB para recursos de tela média
    [DeviceSize.LARGE]: 15        // +15MB para recursos de alta resolução
  };
  
  const totalSizeInMB = baseSizeInMB + additionalSizeMap[size];
  
  return {
    deviceSize: size,
    baseSizeInMB,
    additionalResourcesInMB: additionalSizeMap[size],
    totalSizeInMB,
    formattedSize: `${totalSizeInMB} MB`
  };
};

/**
 * Gera a URL de download para a versão correta do aplicativo
 * @returns {string} URL para download da versão apropriada
 */
export const getAppDownloadUrl = () => {
  const size = detectDeviceSize();
  const baseUrl = 'https://download.kingroad.app';
  
  return `${baseUrl}/kingroad-${size}-latest.apk`;
};

/**
 * Informações completas sobre o dispositivo para debug
 * @returns {Object} Detalhes do dispositivo
 */
export const getDeviceInfo = () => {
  return {
    size: detectDeviceSize(),
    width: window.innerWidth,
    height: window.innerHeight,
    pixelRatio: window.devicePixelRatio || 1,
    userAgent: navigator.userAgent,
    isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
    isAndroid: /Android/i.test(navigator.userAgent),
    isIOS: /iPhone|iPad|iPod/i.test(navigator.userAgent)
  };
};