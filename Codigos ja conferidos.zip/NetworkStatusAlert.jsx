import React, { useState, useEffect, useCallback } from 'react';
import { WifiOff, Wifi, AlertTriangle, X, MapPin, Download, RefreshCw } from 'lucide-react';

const NetworkStatusAlert = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showBanner, setShowBanner] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [hasOfflineMaps, setHasOfflineMaps] = useState(true); // Simula que tem mapas offline
  const [lastConnectionTime, setLastConnectionTime] = useState(new Date());
  const [alertType, setAlertType] = useState('warning'); // warning, error, info
  
  // Monitora eventos de conexão
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setLastConnectionTime(new Date());
      
      // Mostra banner de conexão restabelecida brevemente
      setAlertType('info');
      setShowBanner(true);
      setTimeout(() => {
        setShowBanner(false);
      }, 5000);
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      setAlertType(hasOfflineMaps ? 'warning' : 'error');
      setShowBanner(true);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Inicializa o banner se estiver offline
    if (!navigator.onLine) {
      setAlertType(hasOfflineMaps ? 'warning' : 'error');
      setShowBanner(true);
    }
    
    // Simulação periódica para testar status da rede
    const checkConnection = () => {
      if (navigator.onLine !== isOnline) {
        setIsOnline(navigator.onLine);
        if (!navigator.onLine) {
          setAlertType(hasOfflineMaps ? 'warning' : 'error');
          setShowBanner(true);
        } else {
          setLastConnectionTime(new Date());
          setAlertType('info');
          setShowBanner(true);
          setTimeout(() => {
            setShowBanner(false);
          }, 5000);
        }
      }
    };
    
    const interval = setInterval(checkConnection, 5000);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [isOnline, hasOfflineMaps]);
  
  // Formata o tempo desde a última conexão
  const formatTimeSinceLastConnection = useCallback(() => {
    if (isOnline) return 'Conectado';
    
    const now = new Date();
    const diffMs = now - lastConnectionTime;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffHours > 0) {
      return `Última conexão há ${diffHours}h${diffMins % 60}min`;
    } else if (diffMins > 0) {
      return `Última conexão há ${diffMins}min`;
    } else {
      return 'Última conexão há poucos segundos';
    }
  }, [isOnline, lastConnectionTime]);
  
  // Não renderiza nada se estiver online e o banner não estiver visível
  if (isOnline && !showBanner) return null;
  
  // Classes condicionais baseadas no tipo de alerta
  const getBannerClasses = () => {
    switch (alertType) {
      case 'error':
        return 'bg-red-600 text-white';
      case 'info':
        return 'bg-green-600 text-white';
      case 'warning':
      default:
        return 'bg-amber-500 text-white';
    }
  };
  
  // Renderiza os detalhes expandidos
  const renderDetails = () => {
    if (!showDetails) return null;
    
    return (
      <div className="p-3 border-t border-white/20">
        <div className="space-y-3">
          <p className="text-sm">
            {isOnline 
              ? 'Sua conexão foi restabelecida. O King Road está sincronizando seus dados.' 
              : 'Você está usando o King Road no modo offline.'}
          </p>
          
          {!isOnline && (
            <>
              <div className="flex items-center text-sm">
                <MapPin size={16} className="mr-2" />
                <span>
                  {hasOfflineMaps 
                    ? 'Mapas offline disponíveis para sua região atual' 
                    : 'Mapas offline não disponíveis para esta região'}
                </span>
              </div>
              
              <div className="flex items-center text-sm">
                <AlertTriangle size={16} className="mr-2" />
                <span>Informações de tráfego em tempo real não disponíveis</span>
              </div>
              
              {!hasOfflineMaps && (
                <button className="w-full mt-2 py-2 bg-white text-amber-600 rounded font-medium flex items-center justify-center">
                  <Download size={16} className="mr-2" />
                  <span>Baixar mapa offline desta região</span>
                </button>
              )}
              
              <button className="w-full mt-1 py-2 bg-white/20 text-white rounded font-medium flex items-center justify-center">
                <RefreshCw size={16} className="mr-2" />
                <span>Verificar conexão</span>
              </button>
            </>
          )}
        </div>
      </div>
    );
  };
  
  return (
    <div className={`fixed inset-x-0 top-0 z-50 shadow-lg ${getBannerClasses()}`}>
      {/* Banner principal */}
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex-1 flex items-center">
          {isOnline ? (
            <Wifi size={20} className="mr-2" />
          ) : (
            <WifiOff size={20} className="mr-2" />
          )}
          
          <div>
            <div className="font-medium">
              {isOnline 
                ? 'Conexão restabelecida' 
                : (hasOfflineMaps ? 'Sem conexão - Modo offline' : 'Sem conexão - Recursos limitados')}
            </div>
            
            <div className="text-xs opacity-90">
              {formatTimeSinceLastConnection()}
            </div>
          </div>
        </div>
        
        <div className="flex items-center">
          <button 
            onClick={() => setShowDetails(!showDetails)}
            className="mr-2 p-1 rounded hover:bg-white/20"
            aria-label={showDetails ? "Esconder detalhes" : "Mostrar detalhes"}
          >
            <svg 
              width="20" 
              height="20" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className={`transition-transform ${showDetails ? 'rotate-180' : ''}`}
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </button>
          
          <button 
            onClick={() => setShowBanner(false)}
            className="p-1 rounded hover:bg-white/20"
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>
      </div>
      
      {/* Detalhes expandidos */}
      {renderDetails()}
    </div>
  );
};

// Hook personalizado para integrar o componente em qualquer parte do aplicativo
export const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  return isOnline;
};

export default NetworkStatusAlert;