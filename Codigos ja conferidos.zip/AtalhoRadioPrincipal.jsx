import React, { useState } from 'react';
import { Radio, Music, ChevronDown, Play, Pause, Settings, Clock } from 'lucide-react';

const AtalhoRadioPrincipal = () => {
  const [radioMode, setRadioMode] = useState('Automático');
  const [isPlaying, setIsPlaying] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  
  // Estilo "Família 15" mencionado no documento: borda café, fundo bege claro
  const familyStyle = {
    borderColor: '#8B4513', // café
    backgroundColor: '#F5F5DC', // bege claro
  };
  
  const handleModeChange = (mode) => {
    setRadioMode(mode);
    setShowDropdown(false);
  };
  
  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };
  
  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };
  
  // Ícones para os diferentes modos
  const getModeIcon = () => {
    switch(radioMode) {
      case 'Automático':
        return <Clock className="h-4 w-4" />;
      case 'Manual':
        return <Settings className="h-4 w-4" />;
      case 'Sempre Ativa':
        return <Radio className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  return (
    <div className="relative max-w-xs mx-auto">
      <div 
        className="flex items-center justify-between p-3 rounded-lg shadow-md" 
        style={{
          border: '2px solid',
          ...familyStyle
        }}
      >
        {/* Ícone e Nome da Rádio */}
        <div className="flex items-center space-x-2">
          <div className="bg-white p-1 rounded-full">
            <Music className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <p className="font-medium text-gray-800">Rádio Estrada FM</p>
            <p className="text-xs text-gray-600">Brasil • Português</p>
          </div>
        </div>
        
        {/* Controles */}
        <div className="flex items-center space-x-1">
          <button 
            onClick={togglePlay} 
            className="p-2 rounded-full hover:bg-gray-200 transition-colors"
          >
            {isPlaying ? <Pause className="h-5 w-5 text-gray-700" /> : <Play className="h-5 w-5 text-gray-700" />}
          </button>
          
          <div className="relative">
            <button 
              onClick={toggleDropdown}
              className="flex items-center space-x-1 px-2 py-1 rounded-md text-sm hover:bg-gray-200 transition-colors"
            >
              <span className="flex items-center">
                {getModeIcon()}
                <span className="ml-1">{radioMode}</span>
              </span>
              <ChevronDown className="h-4 w-4" />
            </button>
            
            {/* Dropdown de Modos */}
            {showDropdown && (
              <div 
                className="absolute right-0 mt-1 w-36 rounded-md shadow-lg z-10"
                style={{
                  backgroundColor: familyStyle.backgroundColor,
                  border: '1px solid',
                  borderColor: familyStyle.borderColor,
                }}
              >
                <div className="py-1">
                  {['Automático', 'Manual', 'Sempre Ativa'].map((mode) => (
                    <button
                      key={mode}
                      className={`block w-full text-left px-4 py-2 text-sm ${radioMode === mode ? 'font-bold bg-opacity-20 bg-brown-100' : 'hover:bg-opacity-10 hover:bg-gray-700'}`}
                      onClick={() => handleModeChange(mode)}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Tooltip explicativo */}
      <div className="bg-white border border-gray-300 rounded-md p-2 mt-2 shadow-sm text-xs">
        <p><strong>Modo Atual: {radioMode}</strong></p>
        {radioMode === 'Automático' && (
          <p>A rádio tocará quando não houver instruções de navegação próximas (>10km) e pausará quando você estiver se aproximando de uma manobra (≤2km).</p>
        )}
        {radioMode === 'Manual' && (
          <p>Você tem controle total sobre quando a rádio toca ou pausa, independente das instruções de navegação.</p>
        )}
        {radioMode === 'Sempre Ativa' && (
          <p>A rádio toca continuamente com pequenas pausas de 5 segundos antes das instruções de navegação, retomando logo após.</p>
        )}
      </div>
    </div>
  );
};

export default AtalhoRadioPrincipal;