// StartupReceiver.kt
package com.kingroad.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.kingroad.services.HistoryManagerService
import com.kingroad.utils.Logger

/**
 * Receiver para iniciar serviços quando o dispositivo é ligado
 */
class StartupReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "StartupReceiver"
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Logger.d(TAG, "Dispositivo iniciado, inicializando serviços")
            
            // Iniciar serviço de gerenciamento de histórico
            val serviceIntent = Intent(context, HistoryManagerService::class.java)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}