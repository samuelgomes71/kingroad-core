// modules/shared/alerts/index.js
import { AlertProvider } from './AlertContext';
import { useAlerts } from './useAlerts';
import { AlertAPI } from './AlertAPI';

export { 
  AlertProvider,
  useAlerts
};

// Exportar a API global como padrão para compatibilidade com a versão anterior
export default AlertAPI;