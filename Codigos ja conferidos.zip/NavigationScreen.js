import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image,
  Alert,
  Platform
} from 'react-native';
import MapView, { PROVIDER_GOOGLE, Polyline, Marker } from 'react-native-maps';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

// Componente principal de navegação
const NavigationScreen = ({ route }) => {
  const navigation = useNavigation();
  const [region, setRegion] = useState({
    latitude: -15.7801,
    longitude: -47.9292,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  const [mapType, setMapType] = useState('standard');
  const [mapLayers, setMapLayers] = useState({
    trânsito: false,
    clima: false,
    restrições: false
  });
  const [navigationMode, setNavigationMode] = useState('truck'); // 'truck', 'hike', 'bike', 'moto', 'snowmobile', '4x4'
  const [recordingRoute, setRecordingRoute] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState([]);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  
  // Verificar se está em modo offline
  useEffect(() => {
    const checkOfflineMode = async () => {
      try {
        const value = await AsyncStorage.getItem('offline_mode');
        setIsOfflineMode(value === 'true');
      } catch (error) {
        console.error('Erro ao verificar modo offline:', error);
      }
    };
    
    checkOfflineMode();
  }, []);

  // Simular obtenção de localização atual
  useEffect(() => {
    const getCurrentLocation = () => {
      // Em um app real, usaríamos Geolocation.getCurrentPosition
      // Mas para simplificar, simulamos uma atualização de posição
      const interval = setInterval(() => {
        if (recordingRoute) {
          const newCoordinate = {
            latitude: region.latitude + (Math.random() - 0.5) * 0.01,
            longitude: region.longitude + (Math.random() - 0.5) * 0.01,
          };
          
          setRouteCoordinates(prevCoordinates => [...prevCoordinates, newCoordinate]);
        }
      }, 5000);
      
      return () => clearInterval(interval);
    };
    
    getCurrentLocation();
  }, [recordingRoute, region]);

  // Alternar camada do mapa
  const toggleMapLayer = (layer) => {
    setMapLayers(prevLayers => ({
      ...prevLayers,
      [layer]: !prevLayers[layer]
    }));
  };

  // Alternar modo de navegação
  const changeNavigationMode = (mode) => {
    setNavigationMode(mode);
    setRouteCoordinates([]);
    
    // Reset da gravação ao mudar o modo
    if (recordingRoute) {
      setRecordingRoute(false);
    }
  };

  // Iniciar/Parar gravação de rota
  const toggleRouteRecording = () => {
    if (!recordingRoute) {
      // Iniciar gravação
      setRouteCoordinates([]);
      setRecordingRoute(true);
      Alert.alert('KingRoad', 'Gravação de rota iniciada');
    } else {
      // Parar gravação
      setRecordingRoute(false);
      saveRoute();
    }
  };

  // Simular salvamento de rota
  const saveRoute = async () => {
    if (routeCoordinates.length > 0) {
      try {
        const routeData = {
          mode: navigationMode,
          coordinates: routeCoordinates,
          timestamp: new Date().toISOString(),
          distance: calculateDistance(routeCoordinates),
        };
        
        // Em um app real, isso seria salvo no banco de dados
        const savedRoutes = await AsyncStorage.getItem('saved_routes');
        const routes = savedRoutes ? JSON.parse(savedRoutes) : [];
        routes.push(routeData);
        
        await AsyncStorage.setItem('saved_routes', JSON.stringify(routes));
        Alert.alert('KingRoad', 'Rota salva com sucesso!');
      } catch (error) {
        console.error('Erro ao salvar rota:', error);
        Alert.alert('Erro', 'Não foi possível salvar a rota');
      }
    }
  };

  // Função simples para calcular distância entre coordenadas
  const calculateDistance = (coords) => {
    if (coords.length < 2) return 0;
    
    let distance = 0;
    for (let i = 0; i < coords.length - 1; i++) {
      const lat1 = coords[i].latitude;
      const lon1 = coords[i].longitude;
      const lat2 = coords[i + 1].latitude;
      const lon2 = coords[i + 1].longitude;
      
      // Fórmula de Haversine simplificada
      const R = 6371e3; // raio da Terra em metros
      const φ1 = (lat1 * Math.PI) / 180;
      const φ2 = (lat2 * Math.PI) / 180;
      const Δφ = ((lat2 - lat1) * Math.PI) / 180;
      const Δλ = ((lon2 - lon1) * Math.PI) / 180;
      
      const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      
      distance += R * c;
    }
    
    return distance / 1000; // converter para km
  };

  // Abrir assistente IA
  const openAIAssistant = () => {
    navigation.navigate('AIAssistant');
  };

  // Exibir alertas de perigo
  const showDangerAlerts = () => {
    Alert.alert(
      'Alertas de Perigo',
      'Há restrições de altura no próximo túnel. Altura máxima: 4.5m',
      [{ text: 'Entendi', style: 'cancel' }]
    );
  };

  return (
    <View style={styles.container}>
      {/* Status do modo */}
      <View style={styles.statusBar}>
        <Text style={styles.statusText}>
          {isOfflineMode ? 'Modo Offline' : 'Modo Online'} | 
          Modo: {navigationMode.toUpperCase()} | 
          {recordingRoute ? ' GRAVANDO' : ''}
        </Text>
        {recordingRoute && <Text style={styles.recordingIndicator}>●</Text>}
      </View>

      {/* Mapa principal */}
      <MapView
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        region={region}
        mapType={mapType}
        showsTraffic={mapLayers.trânsito}
        onRegionChangeComplete={setRegion}
      >
        {/* Rota atual (quando gravando) */}
        {routeCoordinates.length > 1 && (
          <Polyline
            coordinates={routeCoordinates}
            strokeWidth={4}
            strokeColor="#FF6B6B"
          />
        )}

        {/* Marcador da posição atual */}
        <Marker
          coordinate={{
            latitude: region.latitude,
            longitude: region.longitude
          }}
          title="Sua posição"
        >
          <View style={[styles.markerContainer, { backgroundColor: navigationMode === 'truck' ? '#4A90E2' : '#50C878' }]}>
            <Icon 
              name={
                navigationMode === 'truck' ? 'truck' :
                navigationMode === 'hike' ? 'hiking' :
                navigationMode === 'bike' ? 'bike' :
                navigationMode === 'moto' ? 'motorbike' :
                navigationMode === 'snowmobile' ? 'snowflake' :
                'jeepney' // 4x4
              } 
              size={16} 
              color="#FFF" 
            />
          </View>
        </Marker>
      </MapView>

      {/* Controles de camadas */}
      <View style={styles.layersControl}>
        <TouchableOpacity 
          style={[styles.layerButton, mapLayers.trânsito && styles.activeLayer]} 
          onPress={() => toggleMapLayer('trânsito')}
        >
          <Icon name="car" size={20} color={mapLayers.trânsito ? "#FFF" : "#333"} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.layerButton, mapLayers.clima && styles.activeLayer]} 
          onPress={() => toggleMapLayer('clima')}
        >
          <Icon name="weather-partly-cloudy" size={20} color={mapLayers.clima ? "#FFF" : "#333"} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.layerButton, mapLayers.restrições && styles.activeLayer]} 
          onPress={() => toggleMapLayer('restrições')}
        >
          <Icon name="alert-circle" size={20} color={mapLayers.restrições ? "#FFF" : "#333"} />
        </TouchableOpacity>
      </View>

      {/* Botões de ação */}
      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.actionButton} onPress={openAIAssistant}>
          <Icon name="robot" size={24} color="#4A90E2" />
          <Text style={styles.actionText}>Tio Sam</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} onPress={showDangerAlerts}>
          <Icon name="alert-octagon" size={24} color="#FF6B6B" />
          <Text style={styles.actionText}>Alertas</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.recordButton, recordingRoute && styles.recordingActive]} 
          onPress={toggleRouteRecording}
        >
          <Icon 
            name={recordingRoute ? "stop-circle" : "record-circle"} 
            size={36} 
            color={recordingRoute ? "#FF6B6B" : "#50C878"} 
          />
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate('POI')}>
          <Icon name="map-marker" size={24} color="#50C878" />
          <Text style={styles.actionText}>POIs</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate('Settings')}>
          <Icon name="cog" size={24} color="#333" />
          <Text style={styles.actionText}>Config</Text>
        </TouchableOpacity>
      </View>

      {/* Seletor de modo de navegação */}
      <View style={styles.modeSelector}>
        <ScrollableModePicker 
          selectedMode={navigationMode}
          onSelectMode={changeNavigationMode}
        />
      </View>

      {/* Indicador de Beta */}
      <View style={styles.betaIndicator}>
        <Text style={styles.betaText}>BETA</Text>
      </View>
    </View>
  );
};

// Componente de seleção de modo horizontal com scroll
const ScrollableModePicker = ({ selectedMode, onSelectMode }) => {
  const modes = [
    { id: 'truck', icon: 'truck', label: 'Caminhão' },
    { id: 'hike', icon: 'hiking', label: 'Trilha' },
    { id: 'bike', icon: 'bike', label: 'Bike' },
    { id: 'moto', icon: 'motorbike', label: 'Moto' },
    { id: 'snowmobile', icon: 'snowflake', label: 'Snowmobile' },
    { id: '4x4', icon: 'jeepney', label: '4x4' },
  ];

  return (
    <View style={styles.modePickerContainer}>
      {modes.map((mode) => (
        <TouchableOpacity 
          key={mode.id}
          style={[
            styles.modeButton, 
            selectedMode === mode.id && styles.selectedMode
          ]}
          onPress={() => onSelectMode(mode.id)}
        >
          <Icon 
            name={mode.icon} 
            size={24} 
            color={selectedMode === mode.id ? "#FFF" : "#333"} 
          />
          <Text 
            style={[
              styles.modeText, 
              selectedMode === mode.id && styles.selectedModeText
            ]}
          >
            {mode.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  statusBar: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 10,
    left: 10,
    right: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 8,
    borderRadius: 20,
    zIndex: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  recordingIndicator: {
    color: '#FF4136',
    fontSize: 16,
    marginLeft: 5,
  },
  map: {
    flex: 1,
  },
  layersControl: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 100 : 60,
    right: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 10,
    padding: 5,
    zIndex: 5,
  },
  layerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 5,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  activeLayer: {
    backgroundColor: '#4A90E2',
  },
  actionButtons: {
    position: 'absolute',
    bottom: 100,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    paddingHorizontal: 10,
    zIndex: 5,
  },
  actionButton: {
    width: 60,
    height: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  recordButton: {
    width: 70,
    height: 70,
    backgroundColor: '#FFF',
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
  },
  recordingActive: {
    backgroundColor: '#FFF0F0',
  },
  actionText: {
    fontSize: 10,
    marginTop: 3,
    color: '#333',
  },
  modeSelector: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    height: 70,
    justifyContent: 'center',
    zIndex: 5,
  },
  modePickerContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 5,
    marginHorizontal: 10,
    justifyContent: 'space-around',
  },
  modeButton: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedMode: {
    backgroundColor: '#4A90E2',
  },
  modeText: {
    fontSize: 10,
    marginTop: 3,
    color: '#333',
  },
  selectedModeText: {
    color: '#FFF',
  },
  markerContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#4A90E2',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFF',
  },
  betaIndicator: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    zIndex: 100,
  },
  betaText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
});

export default NavigationScreen;