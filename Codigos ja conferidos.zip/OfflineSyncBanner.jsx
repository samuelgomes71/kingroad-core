import React, { useState, useEffect } from 'react';
import { AlertCircle, WifiOff, Check, UploadCloud, RefreshCw } from 'lucide-react';

/**
 * Componente visual que avisa o usuário sobre itens pendentes para sincronização.
 * 
 * @param {Object} props Propriedades do componente
 * @param {number} props.pendingItems Número de itens pendentes para sincronização
 * @param {string} props.syncStatus Status atual da sincronização ("idle", "syncing", "error", "no_connectivity", "waiting_for_wifi")
 * @param {Function} props.onSyncNow Callback executado quando o usuário clica no botão de sincronizar agora
 * @param {boolean} props.visible Define se o banner deve ser visível (padrão: true)
 * @param {string} props.className Classes CSS adicionais para o componente
 */
const OfflineSyncBanner = ({
  pendingItems = 0,
  syncStatus = 'idle',
  onSyncNow = () => {},
  visible = true,
  className = ''
}) => {
  const [expanded, setExpanded] = useState(false);
  const [progress, setProgress] = useState(0);

  // Simula progresso durante a sincronização
  useEffect(() => {
    let intervalId = null;
    
    if (syncStatus === 'syncing') {
      intervalId = setInterval(() => {
        setProgress(prev => {
          // Vai até 90% apenas, os 100% são atingidos quando a sincronização termina
          const nextProgress = prev + Math.random() * 5;
          return nextProgress > 90 ? 90 : nextProgress;
        });
      }, 300);
    } else if (syncStatus === 'idle') {
      setProgress(100); // Sincronização concluída
    } else {
      setProgress(0); // Reinicia progresso em outros estados
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [syncStatus]);

  // Reseta o progresso quando muda para idle
  useEffect(() => {
    if (syncStatus === 'idle') {
      const timeout = setTimeout(() => {
        setProgress(0);
      }, 1000);
      
      return () => clearTimeout(timeout);
    }
  }, [syncStatus]);

  // Se não houver itens pendentes e não estiver sincronizando, não mostra o banner
  if (!visible || (pendingItems === 0 && syncStatus === 'idle')) {
    return null;
  }

  // Define a cor e ícone do banner com base no status
  const getBannerConfig = () => {
    switch (syncStatus) {
      case 'error':
        return {
          bgColor: 'bg-red-100 dark:bg-red-900',
          textColor: 'text-red-800 dark:text-red-100',
          borderColor: 'border-red-300 dark:border-red-700',
          icon: <AlertCircle className="h-5 w-5 text-red-500 dark:text-red-400" />,
          title: 'Erro de sincronização'
        };
      case 'no_connectivity':
        return {
          bgColor: 'bg-amber-100 dark:bg-amber-900',
          textColor: 'text-amber-800 dark:text-amber-100',
          borderColor: 'border-amber-300 dark:border-amber-700',
          icon: <WifiOff className="h-5 w-5 text-amber-500 dark:text-amber-400" />,
          title: 'Sem conexão'
        };
      case 'waiting_for_wifi':
        return {
          bgColor: 'bg-blue-100 dark:bg-blue-900',
          textColor: 'text-blue-800 dark:text-blue-100',
          borderColor: 'border-blue-300 dark:border-blue-700',
          icon: <WifiOff className="h-5 w-5 text-blue-500 dark:text-blue-400" />,
          title: 'Aguardando Wi-Fi'
        };
      case 'syncing':
        return {
          bgColor: 'bg-indigo-100 dark:bg-indigo-900',
          textColor: 'text-indigo-800 dark:text-indigo-100',
          borderColor: 'border-indigo-300 dark:border-indigo-700',
          icon: <RefreshCw className="h-5 w-5 text-indigo-500 dark:text-indigo-400 animate-spin" />,
          title: 'Sincronizando dados'
        };
      default:
        return {
          bgColor: 'bg-blue-100 dark:bg-blue-900',
          textColor: 'text-blue-800 dark:text-blue-100',
          borderColor: 'border-blue-300 dark:border-blue-700',
          icon: <UploadCloud className="h-5 w-5 text-blue-500 dark:text-blue-400" />,
          title: 'Itens pendentes'
        };
    }
  };

  const config = getBannerConfig();

  // Texto do banner com base no status
  const getBannerText = () => {
    switch (syncStatus) {
      case 'error':
        return `Ocorreu um erro durante a sincronização. ${pendingItems} ${pendingItems === 1 ? 'item pendente' : 'itens pendentes'}.`;
      case 'no_connectivity':
        return `Sem conexão com a internet. ${pendingItems} ${pendingItems === 1 ? 'item aguardando' : 'itens aguardando'} sincronização.`;
      case 'waiting_for_wifi':
        return `Aguardando conexão Wi-Fi. ${pendingItems} ${pendingItems === 1 ? 'item pendente' : 'itens pendentes'}.`;
      case 'syncing':
        return `Sincronizando ${pendingItems} ${pendingItems === 1 ? 'item' : 'itens'}...`;
      default:
        return `${pendingItems} ${pendingItems === 1 ? 'item pendente' : 'itens pendentes'} para sincronização.`;
    }
  };

  const shouldShowSyncButton = syncStatus !== 'syncing' && syncStatus !== 'waiting_for_wifi';

  return (
    <div className={`rounded-md border p-4 mb-4 transition-all ${config.bgColor} ${config.borderColor} ${config.textColor} ${className}`}>
      <div className="flex justify-between items-start">
        <div className="flex items-start">
          <div className="flex-shrink-0 mt-0.5">{config.icon}</div>
          <div className="ml-3">
            <h3 className="text-sm font-medium">{config.title}</h3>
            <div className="mt-1 text-sm">
              {getBannerText()}
              {expanded && (
                <div className="mt-2">
                  <p className="text-xs">
                    {syncStatus === 'idle' && 'Seus dados serão sincronizados automaticamente quando houver conexão.'}
                    {syncStatus === 'error' && 'Tente novamente ou verifique sua conexão com a internet.'}
                    {syncStatus === 'no_connectivity' && 'Conecte-se à internet para sincronizar seus dados.'}
                    {syncStatus === 'waiting_for_wifi' && 'Seus dados serão sincronizados quando conectar a uma rede Wi-Fi.'}
                    {syncStatus === 'syncing' && 'Por favor, aguarde enquanto seus dados são sincronizados.'}
                  </p>
                </div>
              )}
              {syncStatus === 'syncing' && (
                <div className="mt-2 w-full h-1.5 bg-indigo-200 dark:bg-indigo-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 dark:bg-indigo-300 rounded-full transition-all duration-300" 
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center">
          {shouldShowSyncButton && (
            <button
              onClick={onSyncNow}
              className="inline-flex items-center rounded-md bg-white dark:bg-gray-800 px-2 py-1 text-xs font-medium text-gray-700 dark:text-gray-300 shadow-sm ring-1 ring-inset ring-gray-300 dark:ring-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Sincronizar agora
            </button>
          )}
          <button
            type="button"
            className="ml-2 inline-flex rounded text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
            onClick={() => setExpanded(!expanded)}
          >
            <span className="sr-only">{expanded ? 'Mostrar menos' : 'Mostrar mais'}</span>
            <svg className={`h-5 w-5 transition-transform ${expanded ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OfflineSyncBanner;