import React, { useState } from 'react';
import { Menu, Volume2, ChevronUp, X, AlertTriangle } from 'lucide-react';

const MainNavigationScreen = () => {
  const [showSearch, setShowSearch] = useState(false);

  // Barra superior de pesquisa
  const SearchBar = () => (
    <div className="absolute top-0 left-0 right-0 p-4 bg-[#1E1E1E] flex items-center">
      <div className="flex-1 bg-[#252525] rounded-full p-3 text-gray-400">
        Search
      </div>
      <button 
        className="ml-3 p-2 rounded-full bg-[#252525]"
        onClick={() => setShowSearch(false)}
      >
        <X size={24} className="text-gray-400" />
      </button>
    </div>
  );

  // Barra lateral de alertas
  const AlertSidebar = () => (
    <div className="absolute right-0 top-0 bottom-0 w-16 bg-red-900 bg-opacity-90 flex flex-col items-center py-4">
      {/* Peso máximo */}
      <div className="text-white text-center mb-4">
        <div className="font-bold">Max</div>
        <div>weight</div>
        <div className="font-bold">17 t</div>
      </div>

      {/* Ícone de caminhão com restrição */}
      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-4">
        <div className="text-red-900 text-2xl">↯</div>
      </div>

      {/* Distância */}
      <div className="mt-auto text-white font-bold">
        50m
      </div>
    </div>
  );

  // Barra inferior de controles
  const BottomControls = () => (
    <div className="absolute bottom-4 left-4 flex space-x-4">
      <button className="w-12 h-12 bg-[#1E1E1E] rounded-full flex items-center justify-center">
        <Menu size={24} className="text-gray-400" />
      </button>
      <button className="w-12 h-12 bg-[#1E1E1E] rounded-full flex items-center justify-center">
        <ChevronUp size={24} className="text-gray-400" />
      </button>
      <button className="w-12 h-12 bg-[#1E1E1E] rounded-full flex items-center justify-center">
        <Volume2 size={24} className="text-gray-400" />
      </button>
    </div>
  );

  // Informações da rodovia
  const RoadInfo = () => (
    <div className="absolute top-4 left-4 bg-green-700 rounded-lg overflow-hidden">
      <div className="p-4">
        <div className="flex items-center space-x-2">
          <div className="bg-green-600 px-2 py-1 rounded text-white font-bold">
            165
          </div>
          <div className="text-white">
            2e Rang
          </div>
        </div>
        <div className="mt-2 text-white font-bold">
          50 meters
        </div>
      </div>
      <div className="bg-green-800 p-2 text-white text-center">
        Then →
      </div>
    </div>
  );

  return (
    <div className="relative h-screen bg-[#121212]">
      {/* Mapa ao fundo - aqui seria integrado com a API de mapas */}
      <div className="absolute inset-0 bg-[#121212]">
        {/* Rota em azul */}
        <div className="absolute bottom-1/4 right-1/4 w-32 h-32 border-t-4 border-blue-500 rounded-tl-full" />
      </div>

      {/* Elementos da interface */}
      {showSearch ? (
        <SearchBar />
      ) : (
        <button 
          className="absolute top-4 left-4 bg-[#1E1E1E] rounded-full p-3 text-gray-400"
          onClick={() => setShowSearch(true)}
        >
          Search
        </button>
      )}

      <AlertSidebar />
      <BottomControls />
      <RoadInfo />

      {/* Alerta de restrição */}
      <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-80 p-4 rounded-lg">
        <div className="flex items-center space-x-3">
          <AlertTriangle size={24} className="text-red-500" />
          <div className="text-white">
            Weight restriction: 17t
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainNavigationScreen;