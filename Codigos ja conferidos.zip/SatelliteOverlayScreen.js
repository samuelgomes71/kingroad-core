/**
 * SatelliteOverlayScreen.js
 * 
 * Tela de gerenciamento de overlays de satélite
 * Permite aos usuários visualizar e gerenciar mapas offline e camadas de satélite
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Switch,
  Alert,
  ActivityIndicator,
  Animated,
  Dimensions,
  Platform
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import Slider from '@react-native-community/slider';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import SatelliteService from '../services/SatelliteService';
import MapCacheService from '../services/MapCacheService';
import LocationService from '../services/LocationService';
import { useTheme } from '../contexts/ThemeContext';

const { width } = Dimensions.get('window');

const SatelliteOverlayScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const mapRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [region, setRegion] = useState(null);
  const [satelliteOverlays, setSatelliteOverlays] = useState([]);
  const [selectedOverlay, setSelectedOverlay] = useState(null);
  const [offlineMaps, setOfflineMaps] = useState([]);
  const [downloadProgress, setDownloadProgress] = useState({});
  const [overlayOpacity, setOverlayOpacity] = useState(0.7);
  const [mapType, setMapType] = useState('standard');
  const [trafficEnabled, setTrafficEnabled] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const bottomSheetHeight = useRef(new Animated.Value(250)).current;
  const bottomSheetOpen = useRef(true);
  
  useEffect(() => {
    loadInitialData();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma
      loadOverlays();
      loadOfflineMaps();
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);
  
  const loadInitialData = async () => {
    setLoading(true);
    
    try {
      // Carrega localização atual
      const location = await LocationService.getCurrentLocation();
      
      if (location) {
        setRegion({
          latitude: location.latitude,
          longitude: location.longitude,
          latitudeDelta: 0.1,
          longitudeDelta: 0.1
        });
      }
      
      // Carrega overlays e mapas offline
      await Promise.all([loadOverlays(), loadOfflineMaps()]);
      
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar dados iniciais:', error);
      setLoading(false);
      Alert.alert(
        t('alert.error'),
        t('error.load_initial_data'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const loadOverlays = async () => {
    try {
      const overlays = await SatelliteService.getAvailableOverlays();
      setSatelliteOverlays(overlays);
      
      // Seleciona o primeiro overlay por padrão se não houver nenhum selecionado
      if (overlays.length > 0 && !selectedOverlay) {
        setSelectedOverlay(overlays[0]);
      }
    } catch (error) {
      console.error('Erro ao carregar overlays:', error);
      Alert.alert(
        t('alert.error'),
        t('error.load_overlays'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const loadOfflineMaps = async () => {
    try {
      const maps = await MapCacheService.getDownloadedMaps();
      setOfflineMaps(maps);
    } catch (error) {
      console.error('Erro ao carregar mapas offline:', error);
      Alert.alert(
        t('alert.error'),
        t('error.load_offline_maps'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleRegionChange = (newRegion) => {
    setRegion(newRegion);
  };
  
  const handleSelectOverlay = (overlay) => {
    setSelectedOverlay(overlay);
  };
  
  const handleMapTypeChange = (type) => {
    setMapType(type);
  };
  
  const handleTrafficToggle = () => {
    setTrafficEnabled(prev => !prev);
  };
  
  const handleOfflineModeToggle = () => {
    // Verifica se há mapas offline disponíveis
    if (!offlineMode && offlineMaps.length === 0) {
      Alert.alert(
        t('alert.warning'),
        t('alert.no_offline_maps'),
        [{ text: t('button.ok') }]
      );
      return;
    }
    
    setOfflineMode(prev => !prev);
  };
  
  const handleDownloadOverlay = async (overlay) => {
    try {
      // Verifica se há região selecionada
      if (!region) {
        Alert.alert(
          t('alert.error'),
          t('error.no_region_selected'),
          [{ text: t('button.ok') }]
        );
        return;
      }
      
      // Inicia download
      setDownloadProgress({
        ...downloadProgress,
        [overlay.id]: 0
      });
      
      // Configuração da área a ser baixada
      const downloadConfig = {
        minLat: region.latitude - region.latitudeDelta / 2,
        maxLat: region.latitude + region.latitudeDelta / 2,
        minLng: region.longitude - region.longitudeDelta / 2,
        maxLng: region.longitude + region.longitudeDelta / 2,
        minZoom: 12,
        maxZoom: 16
      };
      
      // Progress callback
      const progressCallback = (progress) => {
        setDownloadProgress(prev => ({
          ...prev,
          [overlay.id]: progress
        }));
      };
      
      // Executa download
      await SatelliteService.downloadOverlay(overlay.id, downloadConfig, progressCallback);
      
      // Limpa progresso e atualiza lista de mapas offline
      setDownloadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[overlay.id];
        return newProgress;
      });
      
      loadOfflineMaps();
      
      Alert.alert(
        t('alert.success'),
        t('success.overlay_downloaded'),
        [{ text: t('button.ok') }]
      );
    } catch (error) {
      console.error('Erro ao baixar overlay:', error);
      
      // Limpa progresso em caso de erro
      setDownloadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[overlay.id];
        return newProgress;
      });
      
      Alert.alert(
        t('alert.error'),
        t('error.download_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleDeleteOfflineMap = (map) => {
    Alert.alert(
      t('alert.confirm'),
      t('alert.confirm_delete_map'),
      [
        {
          text: t('button.cancel'),
          style: 'cancel'
        },
        {
          text: t('button.delete'),
          style: 'destructive',
          onPress: async () => {
            try {
              await MapCacheService.deleteMap(map.id);
              loadOfflineMaps();
            } catch (error) {
              console.error('Erro ao excluir mapa:', error);
              Alert.alert(
                t('alert.error'),
                t('error.delete_failed'),
                [{ text: t('button.ok') }]
              );
            }
          }
        }
      ]
    );
  };
  
  const toggleBottomSheet = () => {
    const targetHeight = bottomSheetOpen.current ? 50 : 250;
    
    Animated.spring(bottomSheetHeight, {
      toValue: targetHeight,
      useNativeDriver: false
    }).start();
    
    bottomSheetOpen.current = !bottomSheetOpen.current;
  };
  
  const formatSize = (bytes) => {
    return RegionalSettingsService.formatFileSize(bytes);
  };
  
  const renderOverlayItem = ({ item }) => {
    const isDownloading = downloadProgress[item.id] !== undefined;
    const isSelected = selectedOverlay?.id === item.id;
    const isDownloaded = offlineMaps.some(map => map.overlayId === item.id);
    
    return (
      <TouchableOpacity
        style={[
          styles.overlayItem,
          isSelected && { backgroundColor: theme.primaryLight },
          { borderColor: theme.border }
        ]}
        onPress={() => handleSelectOverlay(item)}
        disabled={isDownloading}
      >
        <View style={styles.overlayInfo}>
          <Text style={[styles.overlayName, { color: theme.text }]}>
            {item.name}
          </Text>
          <Text style={[styles.overlayMeta, { color: theme.textSecondary }]}>
            {item.date} • {item.type}
          </Text>
        </View>
        
        {isDownloading ? (
          <View style={styles.downloadProgress}>
            <ActivityIndicator size="small" color={theme.primary} />
            <Text style={[styles.downloadProgressText, { color: theme.textSecondary }]}>
              {downloadProgress[item.id]}%
            </Text>
          </View>
        ) : isDownloaded ? (
          <Icon name="check-circle" size={24} color={theme.success} />
        ) : (
          <TouchableOpacity
            style={[styles.downloadButton, { backgroundColor: theme.primary }]}
            onPress={() => handleDownloadOverlay(item)}
          >
            <Icon name="file-download" size={18} color="white" />
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  };
  
  const renderOfflineMapItem = ({ item }) => {
    return (
      <View style={[styles.offlineMapItem, { borderColor: theme.border }]}>
        <View style={styles.offlineMapInfo}>
          <Text style={[styles.offlineMapName, { color: theme.text }]}>
            {item.name}
          </Text>
          <Text style={[styles.offlineMapMeta, { color: theme.textSecondary }]}>
            {formatSize(item.size)} • {t('screen.satellite.downloaded')}: {item.date}
          </Text>
        </View>
        
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeleteOfflineMap(item)}
        >
          <Icon name="delete" size={24} color={theme.danger} />
        </TouchableOpacity>
      </View>
    );
  };
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Mapa */}
      <View style={styles.mapContainer}>
        {region && (
          <MapView
            ref={mapRef}
            style={styles.map}
            provider={PROVIDER_GOOGLE}
            initialRegion={region}
            onRegionChangeComplete={handleRegionChange}
            mapType={mapType}
            showsTraffic={trafficEnabled}
          >
            {selectedOverlay && (
              // Aqui seria renderizado o TileOverlay com a URL do overlay
              // Como é apenas para representação, não implementamos completamente
              <View />
            )}
          </MapView>
        )}
        
        {/* Controles do mapa */}
        <View style={styles.mapControls}>
          <TouchableOpacity
            style={[styles.mapControlButton, { backgroundColor: theme.card }]}
            onPress={() => handleMapTypeChange(mapType === 'standard' ? 'satellite' : 'standard')}
          >
            <Icon 
              name={mapType === 'standard' ? 'satellite' : 'map'} 
              size={24} 
              color={theme.primary} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.mapControlButton, { backgroundColor: theme.card }]}
            onPress={handleTrafficToggle}
          >
            <Icon 
              name="traffic" 
              size={24} 
              color={trafficEnabled ? theme.primary : theme.textSecondary} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.mapControlButton, { backgroundColor: theme.card }]}
            onPress={handleOfflineModeToggle}
          >
            <Icon 
              name="cloud-off" 
              size={24} 
              color={offlineMode ? theme.primary : theme.textSecondary} 
            />
          </TouchableOpacity>
        </View>
        
        {/* Loader */}
        {loading && (
          <View style={[styles.loaderContainer, { backgroundColor: 'rgba(0,0,0,0.1)' }]}>
            <ActivityIndicator size="large" color={theme.primary} />
          </View>
        )}
      </View>
      
      {/* Painel inferior */}
      <Animated.View 
        style={[
          styles.bottomSheet, 
          { 
            backgroundColor: theme.card,
            height: bottomSheetHeight 
          }
        ]}
      >
        <TouchableOpacity
          style={styles.bottomSheetHandle}
          onPress={toggleBottomSheet}
        >
          <View style={styles.bottomSheetHandleBar} />
          <Text style={[styles.bottomSheetTitle, { color: theme.text }]}>
            {bottomSheetOpen.current 
              ? t('screen.satellite.overlay_manager')
              : t('screen.satellite.overlay_manager_collapsed')
            }
          </Text>
          <Icon 
            name={bottomSheetOpen.current ? 'keyboard-arrow-down' : 'keyboard-arrow-up'} 
            size={24} 
            color={theme.textSecondary} 
          />
        </TouchableOpacity>
        
        <View style={styles.bottomSheetContent}>
          {/* Tabs */}
          <View style={styles.tabs}>
            <TouchableOpacity
              style={[
                styles.tab,
                styles.activeTab,
                { borderBottomColor: theme.primary }
              ]}
            >
              <Text style={[styles.tabText, { color: theme.primary }]}>
                {t('screen.satellite.available_overlays')}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.tab}
            >
              <Text style={[styles.tabText, { color: theme.textSecondary }]}>
                {t('screen.satellite.offline_maps')}
              </Text>
            </TouchableOpacity>
          </View>
          
          {/* Lista de overlays */}
          <FlatList
            data={satelliteOverlays}
            renderItem={renderOverlayItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.overlayList}
            ListEmptyComponent={() => (
              <View style={styles.emptyContainer}>
                <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
                  {t('screen.satellite.no_overlays')}
                </Text>
              </View>
            )}
          />
          
          {/* Controles de opacidade */}
          {selectedOverlay && (
            <View style={styles.opacityControl}>
              <Text style={[styles.opacityLabel, { color: theme.text }]}>
                {t('screen.satellite.overlay_opacity')}
              </Text>
              <View style={styles.opacitySlider}>
                <Icon name="opacity" size={16} color={theme.textSecondary} />
                <Slider
                  style={styles.slider}
                  minimumValue={0}
                  maximumValue={1}
                  value={overlayOpacity}
                  onValueChange={setOverlayOpacity}
                  minimumTrackTintColor={theme.primary}
                  maximumTrackTintColor={theme.border}
                  thumbTintColor={theme.primary}
                />
                <Text style={[styles.opacityValue, { color: theme.textSecondary }]}>
                  {Math.round(overlayOpacity * 100)}%
                </Text>
              </View>
            </View>
          )}
        </View>
      </Animated.View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapControls: {
    position: 'absolute',
    top: 16,
    right: 16,
    flexDirection: 'column',
  },
  mapControlButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  loaderContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  bottomSheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  bottomSheetHandle: {
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  bottomSheetHandleBar: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#ddd',
    position: 'absolute',
    top: 8,
    left: (width - 40) / 2,
  },
  bottomSheetTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  bottomSheetContent: {
    flex: 1,
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
  },
  overlayList: {
    padding: 12,
  },
  overlayItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 8,
  },
  overlayInfo: {
    flex: 1,
  },
  overlayName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  overlayMeta: {
    fontSize: 12,
  },
  downloadButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  downloadProgress: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  downloadProgressText: {
    marginLeft: 8,
    fontSize: 12,
  },
  offlineMapItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 8,
  },
  offlineMapInfo: {
    flex: 1,
  },
  offlineMapName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  offlineMapMeta: {
    fontSize: 12,
  },
  deleteButton: {
    padding: 8,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    textAlign: 'center',
  },
  opacityControl: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  opacityLabel: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 8,
  },
  opacitySlider: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  slider: {
    flex: 1,
    height: 40,
    marginHorizontal: 8,
  },
  opacityValue: {
    fontSize: 12,
    width: 40,
    textAlign: 'right',
  }
});

export default SatelliteOverlayScreen;