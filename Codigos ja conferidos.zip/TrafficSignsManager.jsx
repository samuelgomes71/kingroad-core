import React, { useState, useEffect } from 'react';
import { AlertTriangle, X, MessageSquare, Ban, Check, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const TrafficSignsManager = () => {
  const [ignoredSigns, setIgnoredSigns] = useState([]);
  const [showSignsMenu, setShowSignsMenu] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [selectedSign, setSelectedSign] = useState(null);

  // Estrutura de dados para sinalização ignorada
  const IgnoredSignData = {
    id: '',
    location: {
      name: '',
      coordinates: '',
      description: ''
    },
    signType: '', // tipo de sinalização (restrição_largura, restrição_peso, etc)
    restriction: {
      type: '',
      value: '',
      realValue: '' // valor real observado
    },
    dateAdded: null,
    reportSent: false,
    reportDetails: '',
    alternativeRoute: '',
    verifiedBy: 0, // número de usuários que confirmaram
    photos: [], // fotos da sinalização real (opcional)
    status: 'active' // active, resolved, pending
  };

  // Menu de Sinalizações Ignoradas
  const IgnoredSignsMenu = () => (
    <div className="absolute right-0 top-0 h-screen w-80 bg-gray-900 p-4 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold text-white">Sinalizações Ignoradas</h2>
          <p className="text-sm text-gray-400">Sinalizações marcadas como incorretas</p>
        </div>
        <button onClick={() => setShowSignsMenu(false)} className="text-gray-400">
          <X size={20} />
        </button>
      </div>

      <div className="space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
        {ignoredSigns.map((sign) => (
          <div key={sign.id} className="bg-gray-800 p-4 rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <Ban className="text-red-500" size={16} />
                  <h3 className="text-white font-medium">{sign.location.name}</h3>
                </div>

                <div className="mt-2 text-sm">
                  <p className="text-gray-300">{sign.location.description}</p>
                  <div className="mt-2 flex items-center space-x-2">
                    <span className="text-red-400">Sinalização: {sign.restriction.value}</span>
                    <AlertTriangle size={14} className="text-yellow-500" />
                    <span className="text-green-400">Real: {sign.restriction.realValue}</span>
                  </div>
                </div>

                {sign.reportSent && (
                  <div className="mt-2 bg-blue-900 bg-opacity-50 p-2 rounded">
                    <div className="flex items-center space-x-2">
                      <MessageSquare size={14} className="text-blue-400" />
                      <span className="text-blue-400 text-sm">Problema reportado</span>
                    </div>
                    <p className="text-sm text-gray-400 mt-1">
                      Verificado por {sign.verifiedBy} usuários
                    </p>
                  </div>
                )}

                {sign.alternativeRoute && (
                  <p className="text-sm text-gray-400 mt-2">
                    Rota alternativa: {sign.alternativeRoute}
                  </p>
                )}
              </div>

              <button 
                onClick={() => removeIgnoredSign(sign.id)}
                className="text-gray-400 hover:text-gray-300 ml-2"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Diálogo para reportar sinalização
  const ReportSignDialog = () => (
    <Alert className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-gray-900 border-red-600">
      <AlertCircle className="text-red-600" />
      <AlertTitle className="text-white">Reportar Sinalização Incorreta</AlertTitle>
      <AlertDescription>
        <div className="space-y-4 mt-4">
          <div>
            <label className="text-gray-300 text-sm">Local</label>
            <input 
              type="text"
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              placeholder="Ex: Ponte Vila Franca de Xira"
              value={selectedSign?.location.name || ''}
              onChange={(e) => setSelectedSign({
                ...selectedSign,
                location: {...selectedSign?.location, name: e.target.value}
              })}
            />
          </div>

          <div>
            <label className="text-gray-300 text-sm">Descrição do Local</label>
            <textarea 
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              rows="2"
              placeholder="Ex: Ponte com duas faixas em cada sentido"
              value={selectedSign?.location.description || ''}
              onChange={(e) => setSelectedSign({
                ...selectedSign,
                location: {...selectedSign?.location, description: e.target.value}
              })}
            />
          </div>

          <div>
            <label className="text-gray-300 text-sm">Tipo de Restrição</label>
            <select 
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              value={selectedSign?.restriction?.type || ''}
              onChange={(e) => setSelectedSign({
                ...selectedSign,
                restriction: {...selectedSign?.restriction, type: e.target.value}
              })}
            >
              <option value="">Selecione...</option>
              <option value="largura">Largura Máxima</option>
              <option value="altura">Altura Máxima</option>
              <option value="peso">Peso Máximo</option>
              <option value="outro">Outro</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-300 text-sm">Valor na Placa</label>
              <input 
                type="text"
                className="w-full mt-1 bg-gray-800 text-white rounded p-2"
                placeholder="Ex: 2m"
                value={selectedSign?.restriction?.value || ''}
                onChange={(e) => setSelectedSign({
                  ...selectedSign,
                  restriction: {...selectedSign?.restriction, value: e.target.value}
                })}
              />
            </div>
            <div>
              <label className="text-gray-300 text-sm">Valor Real</label>
              <input 
                type="text"
                className="w-full mt-1 bg-gray-800 text-white rounded p-2"
                placeholder="Ex: 3.5m"
                value={selectedSign?.restriction?.realValue || ''}
                onChange={(e) => setSelectedSign({
                  ...selectedSign,
                  restriction: {...selectedSign?.restriction, realValue: e.target.value}
                })}
              />
            </div>
          </div>

          <div>
            <label className="text-gray-300 text-sm">Detalhes do Problema</label>
            <textarea 
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              rows="3"
              placeholder="Descreva o problema detalhadamente..."
              value={selectedSign?.reportDetails || ''}
              onChange={(e) => setSelectedSign({...selectedSign, reportDetails: e.target.value})}
            />
          </div>

          <div>
            <label className="text-gray-300 text-sm">Rota Alternativa Atual</label>
            <textarea 
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              rows="2"
              placeholder="Descreva a rota alternativa que o GPS sugere..."
              value={selectedSign?.alternativeRoute || ''}
              onChange={(e) => setSelectedSign({...selectedSign, alternativeRoute: e.target.value})}
            />
          </div>

          <div className="flex items-center space-x-2">
            <input 
              type="checkbox"
              className="bg-gray-800 rounded"
              checked={selectedSign?.reportSent || false}
              onChange={(e) => setSelectedSign({...selectedSign, reportSent: e.target.checked})}
            />
            <label className="text-gray-300 text-sm">
              Reportar este problema para o King Road
            </label>
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <button 
            onClick={() => setShowReportDialog(false)}
            className="px-4 py-2 bg-gray-700 rounded text-white"
          >
            Cancelar
          </button>
          <button 
            onClick={confirmAddSign}
            className="px-4 py-2 bg-red-600 rounded text-white flex items-center space-x-2"
          >
            <Check size={16} />
            <span>Confirmar</span>
          </button>
        </div>
      </AlertDescription>
    </Alert>
  );

  // Adicionar sinalização à lista de ignorados
  const confirmAddSign = () => {
    if (!selectedSign?.location.name) return;

    const newSign = {
      ...IgnoredSignData,
      ...selectedSign,
      id: Date.now().toString(),
      dateAdded: new Date(),
      verifiedBy: 1
    };

    setIgnoredSigns([...ignoredSigns, newSign]);
    setShowReportDialog(false);
    setSelectedSign(null);
  };

  // Remover sinalização ignorada
  const removeIgnoredSign = (signId) => {
    setIgnoredSigns(ignoredSigns.filter(sign => sign.id !== signId));
  };

  // Botão flutuante do menu
  const MenuButton = () => (
    <button 
      onClick={() => setShowSignsMenu(true)}
      className="fixed bottom-52 right-4 w-12 h-12 bg-red-600 rounded-full flex items-center justify-center shadow-lg"
    >
      <Ban className="text-white" />
    </button>
  );

  // Botão para adicionar nova sinalização
  const AddSignButton = () => (
    <button 
      onClick={() => {
        setSelectedSign({...IgnoredSignData});
        setShowReportDialog(true);
      }}
      className="fixed bottom-4 right-4 bg-red-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
    >
      <AlertTriangle size={16} />
      <span>Reportar Sinalização</span>
    </button>
  );

  return (
    <div className="relative">
      {/* Menu de sinalizações ignoradas */}
      {showSignsMenu && <IgnoredSignsMenu />}

      {/* Diálogo de reporte */}
      {showReportDialog && <ReportSignDialog />}

      {/* Botões */}
      <MenuButton />
      {showSignsMenu && <AddSignButton />}
    </div>
  );
};

export default TrafficSignsManager;