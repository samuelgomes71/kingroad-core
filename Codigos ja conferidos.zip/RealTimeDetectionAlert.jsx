import React, { useState, useEffect } from 'react';
import { AlertTriangle, PhoneOutgoing, MapPin, Truck, Scissors, Wind, X, Volume2, VolumeX } from 'lucide-react';

// Componente separado para o modal de emergência
const EmergencyAlertModal = ({ alert, onClose, onCallPolice, onAddComment }) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [comment, setComment] = useState('');
  
  // Verificar se o alerta está definido
  if (!alert) {
    return null;
  }
  
  // Obter ícone baseado no tipo de alerta
  const getAlertIcon = () => {
    const alertType = alert?.alertType || 'unknown';
    
    switch (alertType) {
      case 'cargo_theft':
        return <Truck size={28} className="text-black" />;
      case 'curtain_cutting':
        return <Scissors size={28} className="text-black" />;
      case 'gas_attack':
        return <Wind size={28} className="text-black" />;
      default:
        return <AlertTriangle size={28} className="text-black" />;
    }
  };
  
  // Efeito para timer
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Formatar o tempo decorrido
  const formatElapsedTime = () => {
    const minutes = Math.floor(secondsElapsed / 60);
    const seconds = secondsElapsed % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Formatar timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return 'N/A';
    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString();
    } catch (e) {
      return 'N/A';
    }
  };
  
  // Submeter comentário
  const handleSubmitComment = () => {
    if (comment.trim() && typeof onAddComment === 'function') {
      onAddComment(comment);
      setComment('');
    }
  };
  
  // Controle de som
  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
  };
  
  // Renderizar informações do veículo suspeito
  const renderVehicleInfo = () => {
    if (!alert?.suspectVehicle) return null;
    
    const vehicle = alert.suspectVehicle;
    const vehicleType = vehicle?.vehicleType || '';
    const vehicleModel = vehicle?.vehicleModel || '';
    const vehicleColor = vehicle?.vehicleColor || '';
    const licensePlate = vehicle?.licensePlate || '';
    const suspectCount = vehicle?.suspectCount || 0;
    const suspectDescription = vehicle?.suspectDescription || '';
    
    return (
      <div className="mt-4 bg-black bg-opacity-40 p-3 rounded-lg border border-gray-700">
        <h4 className="font-bold mb-2">Informações do Veículo Suspeito:</h4>
        <div className="space-y-1 text-sm">
          {(vehicleType || vehicleModel || vehicleColor) && (
            <p>
              <span className="font-medium">Veículo: </span>
              {[vehicleColor, vehicleType, vehicleModel].filter(Boolean).join(' ')}
            </p>
          )}
          {licensePlate && <p><span className="font-medium">Placa: </span>{licensePlate}</p>}
          {suspectCount > 0 && <p><span className="font-medium">Suspeitos: </span>{suspectCount}</p>}
          {suspectDescription && <p><span className="font-medium">Descrição: </span>{suspectDescription}</p>}
        </div>
      </div>
    );
  };
  
  // Informações seguras do alerta
  const locationName = alert?.locationName || 'Localização desconhecida';
  const latitude = alert?.coordinates?.latitude;
  const longitude = alert?.coordinates?.longitude;
  const description = alert?.description || 'Sem descrição disponível';
  const timestamp = alert?.timestamp || Date.now();
  
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 p-4 bg-black bg-opacity-80">
      <div 
        className="w-full max-w-md bg-gray-900 rounded-lg overflow-hidden shadow-2xl border-2 border-amber-500 animate-pulse"
        style={{animationDuration: '2s'}}
      >
        {/* Cabeçalho estilo AMBER Alert */}
        <div className="bg-amber-600 p-4 flex justify-between items-center">
          <div className="flex items-center">
            {getAlertIcon()}
            <h2 className="text-xl font-bold text-black ml-2">
              EMERGENCY ALERT • ALERTA DE EMERGÊNCIA
            </h2>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={toggleSound}
              className="p-1 rounded-full bg-gray-800 hover:bg-gray-700"
            >
              {soundEnabled ? <Volume2 size={20} className="text-white" /> : <VolumeX size={20} className="text-white" />}
            </button>
            <button 
              onClick={() => typeof onClose === 'function' && onClose()}
              className="p-1 rounded-full bg-gray-800 hover:bg-gray-700"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>
        
        {/* Conteúdo */}
        <div className="p-4">
          {/* Info de tempo e localização */}
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-start">
              <MapPin size={18} className="text-red-500 mt-1 mr-1 flex-shrink-0" />
              <div>
                <p className="text-white font-medium">{locationName}</p>
                {latitude !== undefined && longitude !== undefined && (
                  <p className="text-xs text-gray-400">
                    Coordenadas: {latitude.toFixed(4)}, {longitude.toFixed(4)}
                  </p>
                )}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-400">Reportado às {formatTime(timestamp)}</p>
              <p className="text-xs font-bold text-red-500">Há {formatElapsedTime()}</p>
            </div>
          </div>
          
          {/* Descrição do Alerta */}
          <div className="bg-red-950 p-3 rounded-lg border border-red-800 mb-4">
            <p className="text-white">{description}</p>
          </div>
          
          {/* Informações do veículo suspeito */}
          {renderVehicleInfo()}
          
          {/* Instruções */}
          <div className="mt-4 text-sm text-amber-300 bg-amber-950 p-3 rounded-lg border border-amber-800">
            <p className="font-bold mb-1">INSTRUÇÕES DE SEGURANÇA:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Acenda os faróis do seu veículo</li>
              <li>Tranque as portas da cabine</li>
              <li>Buzine para alertar outros motoristas</li>
              <li>Não confronte os suspeitos</li>
              <li>Ligue para as autoridades se necessário</li>
            </ul>
          </div>
          
          {/* Botões de Ação */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <button
              onClick={() => typeof onCallPolice === 'function' && onCallPolice()}
              className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded"
            >
              <PhoneOutgoing size={18} className="mr-2" />
              Ligar Polícia
            </button>
            <button
              onClick={() => typeof onClose === 'function' && onClose()}
              className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded"
            >
              Entendi
            </button>
          </div>
          
          {/* Campo para adicionar informações */}
          <div className="mt-4">
            <label className="block text-gray-300 text-sm font-bold mb-2">
              Adicionar informações:
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
              placeholder="Descreva o que está vendo (veículos, pessoas, direção de fuga...)"
              rows={3}
            />
            <button
              onClick={handleSubmitComment}
              className="mt-2 w-full bg-green-700 hover:bg-green-800 text-white font-bold py-2 px-4 rounded"
            >
              Compartilhar Informação
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Componente principal de alerta em tempo real
const RealTimeDetectionAlert = ({ 
  isVisible = false, 
  alertInfo = null, 
  onDismiss, 
  onCallPolice,
  onAddComment
}) => {
  const [showFullModal, setShowFullModal] = useState(false);
  const [countdown, setCountdown] = useState(20); // 20 segundos para auto-expandir
  
  // Ao receber um novo alerta, iniciar contagem regressiva
  useEffect(() => {
    if (isVisible && alertInfo) {
      const timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            setShowFullModal(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [isVisible, alertInfo]);
  
  // Resetar countdown quando o alerta for dispensado
  useEffect(() => {
    if (!isVisible) {
      setCountdown(20);
      setShowFullModal(false);
    }
  }, [isVisible]);
  
  // Se não for visível ou não tiver informações de alerta, não renderizar nada
  if (!isVisible || !alertInfo) return null;
  
  // Obter ícone baseado no tipo de alerta
  const getAlertIcon = () => {
    const alertType = alertInfo?.alertType || 'unknown';
    
    switch (alertType) {
      case 'cargo_theft':
        return <Truck size={24} className="text-white" />;
      case 'curtain_cutting':
        return <Scissors size={24} className="text-white" />;
      case 'gas_attack':
        return <Wind size={24} className="text-white" />;
      default:
        return <AlertTriangle size={24} className="text-white" />;
    }
  };
  
  return (
    <>
      {/* Alerta Compacto estilo AMBER/Emergency Alert */}
      {!showFullModal && (
        <div className="fixed top-0 left-0 right-0 z-50">
          <div 
            className="mx-auto max-w-md bg-amber-500 text-black rounded-b-lg shadow-lg overflow-hidden animate-pulse"
            style={{animationDuration: '1s'}}
          >
            <div className="p-3 flex items-center justify-between">
              {/* Ícone e texto */}
              <div className="flex items-center">
                {getAlertIcon()}
                <div className="ml-3">
                  <h3 className="text-lg font-bold">EMERGENCY ALERT • ALERTA DE EMERGÊNCIA</h3>
                  <p className="text-sm text-black">
                    Possível tentativa de furto em andamento próximo a você
                  </p>
                </div>
              </div>
              
              {/* Contador */}
              <div className="flex-shrink-0 ml-2 rounded-full bg-black text-amber-400 w-8 h-8 flex items-center justify-center font-bold">
                {countdown}
              </div>
            </div>
            
            {/* Barra de progresso estilo AMBER Alert */}
            <div className="w-full bg-black h-1">
              <div 
                className="bg-amber-300 h-1"
                style={{ width: `${(countdown / 20) * 100}%`, transition: 'width 1s linear' }}
              />
            </div>
            
            {/* Botões estilo AMBER Alert */}
            <div className="flex divide-x divide-amber-700">
              <button 
                className="flex-1 py-2 bg-black hover:bg-gray-800 transition-colors flex items-center justify-center text-white"
                onClick={() => setShowFullModal(true)}
              >
                <AlertTriangle size={16} className="mr-1" />
                Ver Detalhes
              </button>
              <button 
                className="flex-1 py-2 bg-black hover:bg-gray-800 transition-colors flex items-center justify-center text-white"
                onClick={() => typeof onCallPolice === 'function' && onCallPolice()}
              >
                <PhoneOutgoing size={16} className="mr-1" />
                Polícia
              </button>
              <button 
                className="flex-1 py-2 bg-black hover:bg-gray-800 transition-colors flex items-center justify-center text-white"
                onClick={() => typeof onDismiss === 'function' && onDismiss()}
              >
                Dispensar
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Modal de alerta completo */}
      {showFullModal && alertInfo && (
        <EmergencyAlertModal 
          alert={alertInfo}
          onClose={() => {
            setShowFullModal(false);
            if (typeof onDismiss === 'function') {
              onDismiss();
            }
          }}
          onCallPolice={onCallPolice}
          onAddComment={onAddComment}
        />
      )}
    </>
  );
};

export default RealTimeDetectionAlert;