import React, { useState } from 'react';
import { Compass, Map, AlertTriangle, User, Settings, Menu, X, ChevronLeft, Bell } from 'lucide-react';

// Componente de navegação principal do aplicativo KingRoad
// Implementa as funcionalidades mencionadas em AppNavigator.js no relatório

const AppNavigator = ({
  currentRoute = 'map',
  onRouteChange = () => {},
  language = 'pt',
  userName = 'Usuário',
  notifications = 0,
  showMapQuickReports = true,
  onOpenMenu = () => {},
  onBackPress = null,
  darkMode = false
}) => {
  const [tabMenuOpen, setTabMenuOpen] = useState(false);
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      map: 'Mapa',
      routes: 'Rotas',
      alerts: 'Alertas',
      profile: 'Perfil',
      settings: 'Configurações',
      back: 'Voltar',
      menu: 'Menu',
      myAccount: 'Minha conta',
      notifications: 'Notificações'
    },
    en: {
      map: 'Map',
      routes: 'Routes',
      alerts: 'Alerts',
      profile: 'Profile',
      settings: 'Settings',
      back: 'Back',
      menu: 'Menu',
      myAccount: 'My Account',
      notifications: 'Notifications'
    },
    es: {
      map: 'Mapa',
      routes: 'Rutas',
      alerts: 'Alertas',
      profile: 'Perfil',
      settings: 'Ajustes',
      back: 'Volver',
      menu: 'Menú',
      myAccount: 'Mi cuenta',
      notifications: 'Notificaciones'
    }
  };
  
  // Textos conforme o idioma selecionado
  const text = translations[language] || translations.en;
  
  // Definição das rotas principais (tabs)
  const tabs = [
    { id: 'map', label: text.map, icon: <Map size={24} /> },
    { id: 'routes', label: text.routes, icon: <Compass size={24} /> },
    { id: 'alerts', label: text.alerts, icon: <AlertTriangle size={24} />, badge: notifications },
    { id: 'profile', label: text.profile, icon: <User size={24} /> }
  ];
  
  // Estilo para o tema
  const theme = {
    bg: darkMode ? 'bg-gray-900' : 'bg-white',
    text: darkMode ? 'text-white' : 'text-gray-800',
    border: darkMode ? 'border-gray-700' : 'border-gray-200',
    tab: {
      active: darkMode ? 'bg-blue-900 text-white' : 'bg-blue-50 text-blue-600',
      inactive: darkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-800'
    }
  };

  // Altera a rota atual
  const handleTabChange = (routeId) => {
    setTabMenuOpen(false);
    onRouteChange(routeId);
  };
  
  // Toggle do menu de tabs em telas pequenas
  const toggleTabMenu = () => {
    setTabMenuOpen(!tabMenuOpen);
  };
  
  // Renderiza o Header
  const renderHeader = () => (
    <div className={`px-4 py-2 flex items-center justify-between border-b ${theme.border} ${theme.bg}`}>
      <div className="flex items-center">
        {onBackPress ? (
          <button 
            onClick={onBackPress}
            className={`p-2 rounded-full mr-2 ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
            aria-label={text.back}
          >
            <ChevronLeft size={20} />
          </button>
        ) : (
          <button 
            onClick={onOpenMenu}
            className={`p-2 rounded-full mr-2 ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
            aria-label={text.menu}
          >
            <Menu size={20} />
          </button>
        )}
        
        <h1 className={`text-lg font-bold ${theme.text}`}>
          {currentRoute === 'map' ? 'KingRoad' : text[currentRoute]}
        </h1>
      </div>
      
      <div className="flex items-center">
        {/* Botão de notificações */}
        <button 
          className={`p-2 rounded-full relative ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
          aria-label={text.notifications}
        >
          <Bell size={20} />
          {notifications > 0 && (
            <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              {notifications > 9 ? '9+' : notifications}
            </span>
          )}
        </button>
        
        {/* Botão de configurações */}
        <button 
          className={`p-2 rounded-full ml-1 ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
          onClick={() => handleTabChange('settings')}
          aria-label={text.settings}
        >
          <Settings size={20} />
        </button>
        
        {/* Para telas pequenas - botão de menu */}
        <button 
          className={`p-2 rounded-full ml-1 md:hidden ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
          onClick={toggleTabMenu}
          aria-label={tabMenuOpen ? text.back : text.menu}
        >
          {tabMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
    </div>
  );

  // Renderiza a barra de navegação inferior
  const renderBottomNav = () => (
    <div className={`border-t ${theme.border} ${theme.bg} py-2 hidden md:block`}>
      <div className="flex justify-around max-w-3xl mx-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`flex flex-col items-center px-3 py-2 rounded-md transition-colors ${
              currentRoute === tab.id ? theme.tab.active : theme.tab.inactive
            }`}
          >
            <div className="relative">
              {tab.icon}
              {tab.badge > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {tab.badge > 9 ? '9+' : tab.badge}
                </span>
              )}
            </div>
            <span className="text-xs mt-1">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
  
  // Renderiza o menu mobile
  const renderMobileMenu = () => {
    if (!tabMenuOpen) return null;
    
    return (
      <div className={`fixed inset-0 z-50 ${theme.bg} md:hidden`}>
        <div className="flex flex-col h-full">
          {/* Cabeçalho do menu */}
          <div className={`px-4 py-4 border-b ${theme.border} flex items-center justify-between`}>
            <h2 className={`text-lg font-bold ${theme.text}`}>Menu</h2>
            <button 
              onClick={toggleTabMenu}
              className={`p-2 rounded-full ${theme.text} hover:bg-gray-100 dark:hover:bg-gray-800`}
            >
              <X size={24} />
            </button>
          </div>
          
          {/* Perfil do usuário */}
          <div className={`p-4 border-b ${theme.border}`}>
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                {userName.charAt(0).toUpperCase()}
              </div>
              <div className="ml-3">
                <div className={`font-medium ${theme.text}`}>{userName}</div>
                <button 
                  onClick={() => {
                    handleTabChange('profile');
                  }}
                  className="text-blue-500 text-sm"
                >
                  {text.myAccount}
                </button>
              </div>
            </div>
          </div>
          
          {/* Lista de abas */}
          <div className="flex-1 p-4">
            <div className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`flex items-center w-full px-4 py-3 rounded-md transition-colors ${
                    currentRoute === tab.id ? theme.tab.active : theme.tab.inactive
                  }`}
                >
                  <div className="relative">
                    {tab.icon}
                    {tab.badge > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {tab.badge > 9 ? '9+' : tab.badge}
                      </span>
                    )}
                  </div>
                  <span className="ml-3 font-medium">{tab.label}</span>
                </button>
              ))}
              
              {/* Item de configurações */}
              <button
                onClick={() => handleTabChange('settings')}
                className={`flex items-center w-full px-4 py-3 rounded-md transition-colors ${
                  currentRoute === 'settings' ? theme.tab.active : theme.tab.inactive
                }`}
              >
                <Settings size={24} />
                <span className="ml-3 font-medium">{text.settings}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      {renderHeader()}
      
      {/* Conteúdo principal (placeholder) */}
      <div className="flex-1 relative">
        {/* Aqui seria renderizado o conteúdo da rota atual */}
        <div className={`absolute inset-0 flex items-center justify-center ${theme.text}`}>
          <p className="text-lg">Conteúdo da rota: <span className="font-bold">{currentRoute}</span></p>
        </div>
      </div>
      
      {/* Barra de navegação inferior */}
      {renderBottomNav()}
      
      {/* Menu mobile */}
      {renderMobileMenu()}
    </div>
  );
};

export default AppNavigator;