// TruckStopsList.jsx
import React from 'react';
import { Star } from 'lucide-react';
import { getParkingStatusColor, renderAmenityIcon } from '../utils/uiHelpers';

const TruckStopsList = ({ stops, onSelectPOI }) => {
  return (
    <div className="space-y-2">
      {stops.map((stop) => (
        <div 
          key={stop.id} 
          className="bg-stone-800 rounded-lg p-3 cursor-pointer"
          onClick={() => onSelectPOI(stop)}
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-white font-bold text-lg">{stop.name}</h3>
              <p className="text-stone-300 text-sm">{stop.direction} • {stop.city}</p>
              <div className="flex items-center mt-1">
                <Star size={14} className="text-amber-400 mr-1" />
                <span className="text-white mr-1">{stop.rating}</span>
                <span className="text-stone-400 text-xs">({stop.reviews})</span>
                <div className="ml-3 flex space-x-1">
                  {stop.amenities.slice(0, 4).map((amenity, idx) => (
                    <div key={idx} className="text-amber-400">
                      {renderAmenityIcon(amenity)}
                    </div>
                  ))}
                  {stop.amenities.length > 4 && (
                    <span className="text-stone-400 text-xs">+{stop.amenities.length - 4}</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-amber-300 font-bold text-lg">{stop.distance}</span>
              <span className="text-stone-400 text-xs">km</span>
              <div className={`mt-2 px-2 py-1 rounded-md text-xs text-white ${getParkingStatusColor(stop.parking)}`}>
                {stop.parking === 'many' ? 'VAGAS DISPONÍVEIS' : 
                stop.parking === 'some' ? 'POUCAS VAGAS' : 'LOTADO'}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TruckStopsList;