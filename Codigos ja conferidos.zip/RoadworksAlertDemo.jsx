import React, { useState, useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';

// Componente principal de alerta de obras na pista
const RoadworksAlert = ({ 
  visible = false,
  duration = 6000 // duração da animação em milissegundos
}) => {
  const [isVisible, setIsVisible] = useState(visible);
  
  useEffect(() => {
    setIsVisible(visible);
    
    if (visible) {
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, duration);
      
      return () => clearTimeout(timer);
    }
  }, [visible, duration]);
  
  if (!isVisible) return null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
      <div className="bg-black bg-opacity-70 rounded-lg p-4 max-w-md">
        {/* Área do alerta com titulo e símbolo */}
        <div className="flex items-center justify-center mb-4">
          <AlertTriangle size={32} className="text-red-600 mr-2" />
          <h2 className="text-white text-xl font-bold">Obras na Pista</h2>
        </div>
        
        {/* Container dos chevrons animados */}
        <div className="relative h-24 w-full overflow-hidden">
          <SnakeChevrons />
        </div>
      </div>
    </div>
  );
};

// Componente que renderiza os chevrons com movimento de cobra
const SnakeChevrons = () => {
  return (
    <div className="snake-container flex flex-wrap justify-center">
      {[...Array(15)].map((_, index) => (
        <div 
          key={index} 
          className={`chevron-item delay-${index % 5} ${index % 2 === 0 ? 'fill-red-600' : 'fill-white'}`}
          style={{animationDelay: `${index * 0.1}s`}}
        >
          <svg 
            className="w-12 h-12 fill-red-600"
            viewBox="0 0 24 24" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M19 15l-1.41-1.41L13 18.17V2h-2v16.17l-4.59-4.59L5 15l7 7 7-7z" />
          </svg>
        </div>
      ))}
    </div>
  );
};

// Componente de demonstração
const RoadworksAlertDemo = () => {
  const [showAlert, setShowAlert] = useState(false);
  
  const triggerAlert = () => {
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 6000);
  };
  
  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white">
      {/* Interface simulada de navegação */}
      <div className="flex-1 flex items-center justify-center">
        <div className="relative w-full max-w-lg h-96 bg-gray-800 rounded-lg overflow-hidden">
          {/* Simulação da estrada */}
          <div className="absolute bottom-0 w-full h-40 bg-gray-700">
            <div className="absolute top-1/2 w-full flex justify-center space-x-8">
              <div className="w-16 h-2 bg-white"></div>
              <div className="w-16 h-2 bg-white"></div>
              <div className="w-16 h-2 bg-white"></div>
            </div>
          </div>
          
          {/* Simulação de um cone de obra */}
          <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2">
            <div className="w-8 h-8 bg-orange-500 rounded-t-full"></div>
            <div className="w-12 h-2 bg-white rounded-full -mt-1"></div>
          </div>
        </div>
      </div>
      
      {/* Área de controles */}
      <div className="p-4 flex justify-center">
        <button 
          onClick={triggerAlert} 
          className="bg-red-600 px-6 py-3 rounded-lg text-lg font-bold"
        >
          Mostrar Alerta de Obras
        </button>
      </div>
      
      {/* Componente de alerta */}
      <RoadworksAlert visible={showAlert} />
      
      {/* CSS para animações */}
      <style jsx>{`
        .snake-container {
          position: relative;
          width: 100%;
          height: 100%;
        }
        
        .chevron-item {
          animation: snakeMove 2s infinite ease-in-out;
          display: inline-block;
          margin: 2px;
        }
        
        .delay-0 { animation-delay: 0s; }
        .delay-1 { animation-delay: 0.2s; }
        .delay-2 { animation-delay: 0.4s; }
        .delay-3 { animation-delay: 0.6s; }
        .delay-4 { animation-delay: 0.8s; }
        
        @keyframes snakeMove {
          0% {
            transform: translateY(0) rotate(0deg);
            fill: red;
          }
          25% {
            transform: translateY(-10px) rotate(5deg);
            fill: white;
          }
          50% {
            transform: translateY(0) rotate(0deg);
            fill: red;
          }
          75% {
            transform: translateY(10px) rotate(-5deg);
            fill: white;
          }
          100% {
            transform: translateY(0) rotate(0deg);
            fill: red;
          }
        }
      `}</style>
    </div>
  );
};

export default RoadworksAlertDemo;