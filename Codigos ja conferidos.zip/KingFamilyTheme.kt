package com.kingfamily.common.theme

import android.content.Context
import android.content.res.Configuration
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Gerenciador de tema para toda a família de aplicativos King.
 * Aplica cores, estilos e configurações visuais consistentes em todos os aplicativos.
 */
class KingFamilyTheme(private val context: Context) {

    companion object {
        private const val TAG = "KingFamilyTheme"
        private const val CONFIG_FILE = "king_family_config.json"
        
        // Cores padrão caso a configuração não seja encontrada
        private const val DEFAULT_PRIMARY_COLOR = "#D4AF37"
        private const val DEFAULT_SECONDARY_COLOR = "#4B3621"
        private const val DEFAULT_BACKGROUND_COLOR = "#F5F5DC"
        
        // Singleton instance
        @Volatile
        private var instance: KingFamilyTheme? = null
        
        fun getInstance(context: Context): KingFamilyTheme {
            return instance ?: synchronized(this) {
                instance ?: KingFamilyTheme(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // Configuração carregada do JSON
    private var config: JSONObject? = null
    
    // Tema atual (claro ou escuro)
    private var isDarkMode = false
    
    init {
        loadConfig()
        checkSystemDarkMode()
    }
    
    /**
     * Carrega a configuração do tema do arquivo JSON
     */
    private fun loadConfig() {
        try {
            val inputStream = context.assets.open(CONFIG_FILE)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            reader.close()
            
            config = JSONObject(jsonString)
            
            Log.d(TAG, "Configuração do tema carregada com sucesso")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar configuração do tema", e)
            config = JSONObject()
        }
    }
    
    /**
     * Verifica se o sistema está em modo escuro
     */
    private fun checkSystemDarkMode() {
        val shouldFollowSystem = config
            ?.optJSONObject("theme")
            ?.optJSONObject("dark_mode")
            ?.optBoolean("follow_system", true) ?: true
            
        if (shouldFollowSystem) {
            val currentNightMode = context.resources.configuration.uiMode and 
                    Configuration.UI_MODE_NIGHT_MASK
                    
            isDarkMode = currentNightMode == Configuration.UI_MODE_NIGHT_YES
            
            // Aplica o modo escuro automaticamente se configurado
            val autoSwitch = config
                ?.optJSONObject("theme")
                ?.optJSONObject("dark_mode")
                ?.optBoolean("auto_switch", true) ?: true
                
            if (autoSwitch) {
                setDarkMode(isDarkMode)
            }
        }
    }
    
    /**
     * Obtém a cor primária (dourado) do tema
     */
    fun getPrimaryColor(): String {
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("colors")
            ?.optString("primary", DEFAULT_PRIMARY_COLOR) ?: DEFAULT_PRIMARY_COLOR
    }
    
    /**
     * Obtém a cor secundária (café escuro) do tema
     */
    fun getSecondaryColor(): String {
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("colors")
            ?.optString("secondary", DEFAULT_SECONDARY_COLOR) ?: DEFAULT_SECONDARY_COLOR
    }
    
    /**
     * Obtém a cor de fundo do tema
     */
    fun getBackgroundColor(): String {
        val isDark = isDarkMode()
        val colorKey = if (isDark) "background_dark" else "background"
        
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("colors")
            ?.optString(colorKey, DEFAULT_BACKGROUND_COLOR) ?: DEFAULT_BACKGROUND_COLOR
    }
    
    /**
     * Obtém uma cor específica do tema
     */
    fun getColor(colorKey: String, defaultColor: String): String {
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("colors")
            ?.optString(colorKey, defaultColor) ?: defaultColor
    }
    
    /**
     * Verifica se o modo escuro está ativado
     */
    fun isDarkMode(): Boolean {
        return isDarkMode
    }
    
    /**
     * Ativa ou desativa o modo escuro
     */
    fun setDarkMode(enable: Boolean) {
        isDarkMode = enable
        
        val mode = if (enable) {
            AppCompatDelegate.MODE_NIGHT_YES
        } else {
            AppCompatDelegate.MODE_NIGHT_NO
        }
        
        AppCompatDelegate.setDefaultNightMode(mode)
    }
    
    /**
     * Alterna entre modo claro e escuro
     */
    fun toggleDarkMode() {
        setDarkMode(!isDarkMode)
    }
    
    /**
     * Obtém a fonte primária do tema
     */
    fun getPrimaryFont(): String {
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("fonts")
            ?.optString("primary", "Roboto") ?: "Roboto"
    }
    
    /**
     * Obtém a fonte secundária do tema
     */
    fun getSecondaryFont(): String {
        return config
            ?.optJSONObject("theme")
            ?.optJSONObject("fonts")
            ?.optString("secondary", "Montserrat") ?: "Montserrat"
    }
    
    /**
     * Verifica se o aplicativo está em modo beta
     */
    fun isBetaMode(): Boolean {
        return config
            ?.optJSONObject("beta_mode")
            ?.optBoolean("enabled", false) ?: false
    }
    
    /**
     * Obtém a mensagem de beta
     */
    fun getBetaMessage(): String {
        return config
            ?.optJSONObject("beta_mode")
            ?.optString("beta_message", "Versão Beta") ?: "Versão Beta"
    }
    
    /**
     * Obtém a data de expiração do beta
     */
    fun getBetaExpirationDate(): String {
        return config
            ?.optJSONObject("beta_mode")
            ?.optString("expires_at", "") ?: ""
    }
    
    /**
     * Verifica se o indicador de beta deve ser exibido
     */
    fun shouldShowBetaIndicator(): Boolean {
        return config
            ?.optJSONObject("beta_mode")
            ?.optBoolean("show_indicator", true) ?: true
    }
    
    /**
     * Obtém informações de um aplicativo específico da família King
     */
    fun getAppInfo(appId: String): JSONObject? {
        try {
            val apps = config?.optJSONArray("applications")
            if (apps != null) {
                for (i in 0 until apps.length()) {
                    val app = apps.getJSONObject(i)
                    if (app.optString("id", "") == appId) {
                        return app
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao obter informações do aplicativo: $appId", e)
        }
        
        return null
    }
}