// PulsatingLocationMarker.jsx
import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

/**
 * Marcador pulsante para mostrar a localização atual no mapa
 * ID do componente: 8507 (seguindo o sistema de IDs numéricos)
 */
const PulsatingLocationMarker = ({ mapRef, latitude, longitude, onPositionUpdate }) => {
  const [isAnimating, setIsAnimating] = useState(true);
  const [screenPosition, setScreenPosition] = useState({ x: '50%', y: '50%' });
  const markerRef = useRef(null);
  
  // Configurações do marcador - alinhado com a versão Kotlin
  const config = {
    centerColor: '#FFFFFF',
    markerColor: 'rgb(59, 130, 246)', // Azul (tailwind blue-500)
    pulseColor: 'rgb(59, 130, 246)',
    markerSize: 40, // equivalente a 20px de raio (40px de diâmetro)
    centerSize: 16, // equivalente a 8px de raio
    pulseMaxScale: 1.8,
    animationDuration: 1500
  };
  
  // Iniciar animação quando o componente montar
  useEffect(() => {
    // Garantir que a animação seja iniciada
    setIsAnimating(true);
    
    // Opcionalmente, podemos parar a animação após algum tempo para economizar recursos
    // const timer = setTimeout(() => setIsAnimating(false), 30000);
    // return () => clearTimeout(timer);
  }, []);
  
  // Atualizar posição na tela baseado nas coordenadas geográficas
  useEffect(() => {
    if (!mapRef || !latitude || !longitude) return;
    
    // Função para atualizar a posição do marcador no mapa
    const updateScreenPosition = () => {
      if (!mapRef.current) return;
      
      try {
        // Convertemos as coordenadas geográficas para coordenadas de tela
        // Esta implementação depende da biblioteca de mapas utilizada (Google Maps, Leaflet, etc)
        // Esta é uma função hipotética que corresponderia à convertLatLngToScreenPoint do Kotlin
        const point = mapRef.current.convertLatLngToScreenPoint
          ? mapRef.current.convertLatLngToScreenPoint(latitude, longitude)
          : { x: '50%', y: '50%' }; // Fallback para o centro se não for possível converter
          
        setScreenPosition({ x: point.x, y: point.y });
        
        // Notificar sobre a atualização da posição, se necessário
        if (onPositionUpdate) {
          onPositionUpdate(point);
        }
      } catch (error) {
        console.error('Erro ao atualizar posição do marcador:', error);
      }
    };
    
    // Atualizar a posição inicialmente
    updateScreenPosition();
    
    // Se o mapa tiver eventos de movimentação, podemos registrar callback para manter o marcador sincronizado
    const mapInstance = mapRef.current;
    if (mapInstance && mapInstance.addListener) {
      // Para Google Maps
      const listener = mapInstance.addListener('bounds_changed', updateScreenPosition);
      return () => {
        if (listener && listener.remove) listener.remove();
      };
    } else if (mapInstance && mapInstance.on) {
      // Para Leaflet
      mapInstance.on('move', updateScreenPosition);
      return () => {
        mapInstance.off('move', updateScreenPosition);
      };
    }
  }, [mapRef, latitude, longitude, onPositionUpdate]);
  
  return (
    <div 
      ref={markerRef}
      className="absolute z-50 pointer-events-none"
      id="pulsating-location-marker-8507"
      style={{
        left: screenPosition.x,
        top: screenPosition.y,
        transform: 'translate(-50%, -50%)'
      }}
    >
      {/* Container do marcador pulsante */}
      <div className="relative">
        {/* Círculos de pulso animados - dois círculos como na versão Kotlin */}
        {isAnimating && (
          <>
            {/* Primeiro pulso (primário) */}
            <div 
              className="absolute top-0 left-0 rounded-full" 
              style={{
                width: config.markerSize,
                height: config.markerSize,
                backgroundColor: config.pulseColor,
                animation: `primaryPulse ${config.animationDuration}ms cubic-bezier(0, 0, 0.2, 1) infinite`,
                transform: 'translate(-50%, -50%)',
                left: '50%',
                top: '50%'
              }}
            ></div>
            
            {/* Segundo pulso (secundário com delay) */}
            <div 
              className="absolute top-0 left-0 rounded-full" 
              style={{
                width: config.markerSize,
                height: config.markerSize,
                backgroundColor: config.pulseColor,
                animation: `secondaryPulse ${config.animationDuration}ms cubic-bezier(0, 0, 0.2, 1) infinite`,
                animationDelay: `${config.animationDuration / 2}ms`,
                transform: 'translate(-50%, -50%)',
                left: '50%',
                top: '50%'
              }}
            ></div>
          </>
        )}
        
        {/* Círculo principal azul */}
        <div 
          className="rounded-full flex items-center justify-center shadow-lg"
          style={{
            width: config.markerSize,
            height: config.markerSize,
            backgroundColor: config.markerColor
          }}
        >
          {/* Círculo central branco */}
          <div 
            className="rounded-full"
            style={{
              width: config.centerSize,
              height: config.centerSize,
              backgroundColor: config.centerColor
            }}
          ></div>
        </div>
      </div>
      
      {/* Estilos personalizados para as animações - alinhados com o comportamento do Kotlin */}
      <style jsx>{`
        @keyframes primaryPulse {
          0% {
            transform: translate(-50%, -50%) scale(1);
            opacity: 0.7;
          }
          100% {
            transform: translate(-50%, -50%) scale(${config.pulseMaxScale});
            opacity: 0;
          }
        }
        
        @keyframes secondaryPulse {
          0% {
            transform: translate(-50%, -50%) scale(1);
            opacity: 0.4;
          }
          100% {
            transform: translate(-50%, -50%) scale(${config.pulseMaxScale * 0.9});
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};

// Definição de PropTypes para validação
PulsatingLocationMarker.propTypes = {
  mapRef: PropTypes.shape({ current: PropTypes.any }),
  latitude: PropTypes.number,
  longitude: PropTypes.number,
  onPositionUpdate: PropTypes.func
};

// Valores padrão
PulsatingLocationMarker.defaultProps = {
  latitude: null,
  longitude: null,
  onPositionUpdate: null
};

export default PulsatingLocationMarker;