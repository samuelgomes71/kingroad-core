// poi/CarpoolPOIHandler.ts
import { POIBase, POIConfig, RegionalSettings, NavigationSettings } from '../types/POITypes';
import { TranslationsService } from '../services/TranslationsService';
import { NavigationService } from '../services/NavigationService';
import { MapService } from '../services/MapService';
import { UserPreferencesService } from '../services/UserPreferencesService';
import { GeoLocationService } from '../services/GeoLocationService';
import { LogService } from '../services/LogService';

export class CarpoolPOIHandler extends POIBase {
  private config: POIConfig;
  private translations: TranslationsService;
  private regionalSettings: RegionalSettings;
  private navigationSettings: NavigationSettings;
  
  constructor() {
    super('carpool');
    this.translations = new TranslationsService();
    this.loadConfiguration();
  }
  
  /**
   * Carrega a configuração do POI de Carpool
   */
  private async loadConfiguration(): Promise<void> {
    try {
      // Carregar a configuração do repositório
      const response = await fetch('/assets/poi/carpool/config.json');
      this.config = await response.json();
      
      // Determinar configurações regionais baseadas na localização do usuário
      const userRegion = await GeoLocationService.getUserRegion();
      this.applyRegionalSettings(userRegion);
      
      LogService.log('CarpoolPOIHandler', 'Configuration loaded successfully');
    } catch (error) {
      LogService.error('CarpoolPOIHandler', 'Failed to load configuration', error);
      // Fallback para configuração padrão
      this.loadDefaultConfiguration();
    }
  }
  
  /**
   * Aplica configurações regionais específicas
   */
  private applyRegionalSettings(region: string): void {
    // Definir ícone regional
    if (this.config.global_settings.icon.regional[region]) {
      this.config.global_settings.icon.current = this.config.global_settings.icon.regional[region];
    } else {
      this.config.global_settings.icon.current = this.config.global_settings.icon.default;
    }
    
    // Aplicar atributos regionais
    this.regionalSettings = {
      region,
      attributes: this.config.attributes.regional[region] || []
    };
    
    // Ajustar traduções baseadas na região
    const userLanguage = UserPreferencesService.getPreferredLanguage();
    this.translations.setLanguage(userLanguage);
  }
  
  /**
   * Carrega configuração padrão em caso de falha
   */
  private loadDefaultConfiguration(): void {
    this.config = {
      poi_type: 'carpool',
      global_id: 'global_carpool_v1',
      version: '1.0.0',
      global_settings: {
        display_name: {
          default: 'Carpool',
          translations: {}
        },
        description: {
          default: 'Locations for shared rides and carpooling',
          translations: {}
        },
        icon: {
          default: 'poi/carpool/carpool_icon.svg',
          regional: {},
          current: 'poi/carpool/carpool_icon.svg'
        },
        categories: ['transport'],
        display_priority: 85,
        search_tags: ['carpool', 'rideshare'],
        pin_color: '#4285F4',
        offline_availability: true,
        beta_feature: false
      },
      search_weights: {
        truck: 70,
        car: 90,
        motorcycle: 60,
        bicycle: 50,
        pedestrian: 80
      },
      attributes: {
        common: [],
        regional: {}
      }
    };
  }
  
  /**
   * Registra o POI no sistema
   */
  public register(): void {
    MapService.registerPOIType({
      type: this.config.poi_type,
      displayName: this.getLocalizedName(),
      icon: this.config.global_settings.icon.current,
      color: this.config.global_settings.pin_color,
      priority: this.config.global_settings.display_priority,
      handler: this
    });
    
    // Registrar comandos de voz se disponíveis
    if (this.config.voice_commands) {
      this.registerVoiceCommands();
    }
    
    LogService.log('CarpoolPOIHandler', 'Registered successfully');
  }
  
  /**
   * Registra comandos de voz
   */
  private registerVoiceCommands(): void {
    const voiceCommandService = NavigationService.getVoiceCommandService();
    
    if (this.config.voice_commands.find) {
      voiceCommandService.registerCommands(
        this.config.voice_commands.find,
        () => this.handleFindCommand()
      );
    }
    
    if (this.config.voice_commands.navigate) {
      voiceCommandService.registerCommands(
        this.config.voice_commands.navigate,
        () => this.handleNavigateCommand()
      );
    }
  }
  
  /**
   * Manipula comando de voz para encontrar carpool
   */
  private handleFindCommand(): void {
    // Implementação do comando para encontrar carpool próximo
    const userLocation = GeoLocationService.getCurrentLocation();
    this.findNearby(userLocation, 10000); // 10km de raio
  }
  
  /**
   * Manipula comando de voz para navegar até carpool
   */
  private handleNavigateCommand(): void {
    // Implementação do comando para navegar até o carpool mais próximo
    const userLocation = GeoLocationService.getCurrentLocation();
    this.findNearby(userLocation, 10000, 1)
      .then(carpools => {
        if (carpools.length > 0) {
          NavigationService.startNavigation(carpools[0].location);
        } else {
          // Informar que não há carpools próximos
          NavigationService.announceMessage(
            this.translations.get('carpool.not_found_nearby')
          );
        }
      });
  }
  
  /**
   * Encontra pontos de carpool próximos
   */
  public async findNearby(location, radiusMeters, limit = 10): Promise<Array<any>> {
    try {
      const vehicleType = UserPreferencesService.getVehicleType() || 'car';
      const searchWeight = this.config.search_weights[vehicleType] || 70;
      
      const response = await fetch(
        `${this.config.api_endpoints.search}&lat=${location.latitude}&lon=${location.longitude}&radius=${radiusMeters}&limit=${limit}&weight=${searchWeight}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch nearby carpool points');
      }
      
      return await response.json();
    } catch (error) {
      LogService.error('CarpoolPOIHandler', 'Error finding nearby carpool points', error);
      
      // Tentar usar dados offline se disponíveis
      if (this.config.offline_behavior.cacheable) {
        return this.findNearbyOffline(location, radiusMeters, limit);
      }
      
      return [];
    }
  }
  
  /**
   * Busca carpools em modo offline
   */
  private async findNearbyOffline(location, radiusMeters, limit): Promise<Array<any>> {
    try {
      return await MapService.queryOfflinePOIs({
        type: this.config.poi_type,
        location,
        radius: radiusMeters,
        limit
      });
    } catch (error) {
      LogService.error('CarpoolPOIHandler', 'Error finding offline carpool points', error);
      return [];
    }
  }
  
  /**
   * Retorna o nome localizado do POI
   */
  public getLocalizedName(): string {
    const userLanguage = UserPreferencesService.getPreferredLanguage();
    
    if (
      this.config.global_settings.display_name.translations && 
      this.config.global_settings.display_name.translations[userLanguage]
    ) {
      return this.config.global_settings.display_name.translations[userLanguage];
    }
    
    return this.config.global_settings.display_name.default;
  }
  
  /**
   * Retorna a descrição localizada do POI
   */
  public getLocalizedDescription(): string {
    const userLanguage = UserPreferencesService.getPreferredLanguage();
    
    if (
      this.config.global_settings.description.translations && 
      this.config.global_settings.description.translations[userLanguage]
    ) {
      return this.config.global_settings.description.translations[userLanguage];
    }
    
    return this.config.global_settings.description.default;
  }
  
  /**
   * Método para renderizar o POI no mapa
   */
  public render(context, poi, isSelected): void {
    const icon = this.config.global_settings.icon.current;
    const color = this.config.global_settings.pin_color;
    
    MapService.renderPOI({
      context,
      poi,
      icon,
      color,
      isSelected,
      animation: isSelected ? this.config.interaction.tap.animation : null
    });
  }
  
  /**
   * Manipula toque no POI
   */
  public onTap(poi): void {
    if (this.config.interaction.tap.action === 'show_details') {
      this.showDetails(poi);
    }
  }
  
  /**
   * Manipula toque longo no POI
   */
  public onLongPress(poi): void {
    if (this.config.interaction.long_press.action === 'show_context_menu') {
      MapService.showContextMenu({
        poi,
        options: this.config.interaction.long_press.options,
        handler: (option) => this.handleContextMenuOption(option, poi)
      });
    }
  }
  
  /**
   * Manipula opção do menu de contexto
   */
  private handleContextMenuOption(option: string, poi): void {
    switch (option) {
      case 'navigate':
        NavigationService.startNavigation(poi.location);
        break;
      case 'save':
        UserPreferencesService.saveFavoritePOI(poi);
        break;
      case 'share':
        this.sharePOI(poi);
        break;
      case 'report_issue':
        this.showReportIssueDialog(poi);
        break;
    }
  }
  
  /**
   * Exibe detalhes do POI
   */
  private showDetails(poi): void {
    MapService.showPOIDetails({
      poi,
      title: poi.name || this.getLocalizedName(),
      description: poi.description || this.getLocalizedDescription(),
      icon: this.config.global_settings.icon.current,
      color: this.config.global_settings.pin_color,
      attributes: this.getAttributesForDisplay(poi),
      actions: [
        {
          label: this.translations.get('common.navigate'),
          icon: 'navigation',
          handler: () => NavigationService.startNavigation(poi.location)
        },
        {
          label: this.translations.get('common.share'),
          icon: 'share',
          handler: () => this.sharePOI(poi)
        }
      ]
    });
  }
  
  /**
   * Prepara atributos para exibição
   */
  private getAttributesForDisplay(poi): Array<any> {
    const attributes = [];
    
    // Adicionar atributos comuns
    this.config.attributes.common.forEach(attr => {
      if (poi[attr.name] !== undefined) {
        attributes.push({
          name: attr.name,
          label: this.translations.get(`carpool.attributes.${attr.name}`),
          value: poi[attr.name],
          icon: attr.icon,
          type: attr.type,
          display_format: attr.display_format
        });
      }
    });
    
    // Adicionar atributos regionais se disponíveis
    if (
      this.regionalSettings && 
      this.regionalSettings.attributes && 
      this.regionalSettings.attributes.length > 0
    ) {
      this.regionalSettings.attributes.forEach(attr => {
        if (poi[attr.name] !== undefined) {
          attributes.push({
            name: attr.name,
            label: this.translations.get(`carpool.attributes.${attr.name}`),
            value: poi[attr.name],
            icon: attr.icon,
            type: attr.type,
            display_format: attr.display_format
          });
        }
      });
    }
    
    return attributes;
  }
  
  /**
   * Compartilha o POI
   */
  private sharePOI(poi): void {
    const shareText = `${poi.name || this.getLocalizedName()} - ${poi.location.latitude},${poi.location.longitude}`;
    
    MapService.sharePOI({
      text: shareText,
      title: poi.name || this.getLocalizedName(),
      url: `kingroad://poi?type=carpool&id=${poi.id}&lat=${poi.location.latitude}&lon=${poi.location.longitude}`
    });
  }
  
  /**
   * Exibe diálogo para reportar problemas
   */
  private showReportIssueDialog(poi): void {
    MapService.showReportIssueDialog({
      poi,
      issues: this.config.reporting.allowed_issues,
      onSubmit: (issue, description) => {
        // Enviar o relatório para o servidor
        fetch(this.config.api_endpoints.report, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            poi_id: poi.id,
            poi_type: this.config.poi_type,
            issue_type: issue,
            description: description,
            user_location: GeoLocationService.getCurrentLocation(),
            app_version: '2.5.0', // Versão do aplicativo
            timestamp: new Date().toISOString()
          })
        }).catch(error => {
          LogService.error('CarpoolPOIHandler', 'Failed to submit issue report', error);
        });
      }
    });
  }
}

// Registrar o POI no sistema
export function registerCarpoolPOI(): void {
  const carpoolPOI = new CarpoolPOIHandler();
  carpoolPOI.register();
}