import React, { useState } from 'react';
import { Alert, AlertTitle } from '@/components/ui/alert';

const DeviceCheckInterface = () => {
  const [checkingPhase, setCheckingPhase] = useState(0);
  const [results, setResults] = useState(null);
  
  return (
    <div className="h-screen bg-gray-900 text-gray-200">
      {/* Cabeçalho */}
      <div className="bg-gray-800 p-4">
        <h1 className="text-xl font-bold">Verificação do Dispositivo</h1>
        <p className="text-gray-400 text-sm mt-1">
          Analisando compatibilidade do seu dispositivo
        </p>
      </div>

      {/* Área de checagem */}
      <div className="p-4">
        {/* Hardware */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-6 h-6 bg-blue-600 rounded-full mr-2 flex items-center justify-center text-white text-sm">
              CPU
            </div>
            <span className="font-medium">Hardware</span>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg space-y-3">
            {/* RAM */}
            <div className="flex justify-between items-center">
              <span>Memória RAM</span>
              <div className="flex items-center">
                <span className="text-green-400 mr-2">3.5 GB</span>
                <div className="text-green-400">✓</div>
              </div>
            </div>
            {/* Armazenamento */}
            <div className="flex justify-between items-center">
              <span>Armazenamento Disponível</span>
              <div className="flex items-center">
                <span className="text-yellow-400 mr-2">12.3 GB</span>
                <div className="text-yellow-400">!</div>
              </div>
            </div>
          </div>
        </div>

        {/* GPS */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-6 h-6 bg-blue-600 rounded-full mr-2 flex items-center justify-center text-white text-sm">
              GPS
            </div>
            <span className="font-medium">GPS</span>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg space-y-3">
            {/* Precisão */}
            <div className="flex justify-between items-center">
              <span>Precisão</span>
              <div className="flex items-center">
                <span className="text-green-400 mr-2">Alta (2.5m)</span>
                <div className="text-green-400">✓</div>
              </div>
            </div>
            {/* A-GPS */}
            <div className="flex justify-between items-center">
              <span>A-GPS</span>
              <div className="flex items-center">
                <span className="text-green-400 mr-2">Disponível</span>
                <div className="text-green-400">✓</div>
              </div>
            </div>
          </div>
        </div>

        {/* Rede */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-6 h-6 bg-blue-600 rounded-full mr-2 flex items-center justify-center text-white text-sm">
              NET
            </div>
            <span className="font-medium">Conectividade</span>
          </div>
          <div className="bg-gray-800 p-4 rounded-lg space-y-3">
            {/* 4G */}
            <div className="flex justify-between items-center">
              <span>4G</span>
              <div className="flex items-center">
                <span className="text-green-400 mr-2">Disponível</span>
                <div className="text-green-400">✓</div>
              </div>
            </div>
            {/* WiFi */}
            <div className="flex justify-between items-center">
              <span>Wi-Fi</span>
              <div className="flex items-center">
                <span className="text-green-400 mr-2">Disponível</span>
                <div className="text-green-400">✓</div>
              </div>
            </div>
          </div>
        </div>

        {/* Recomendações */}
        <Alert variant="default" className="bg-gray-800 border-gray-700">
          <AlertTitle>Recomendações</AlertTitle>
          <div className="space-y-2 text-sm text-gray-400 mt-2">
            <p>• Limite de mapas offline: 3 países</p>
            <p>• Qualidade gráfica: Média</p>
            <p>• Atualizações em segundo plano: Limitadas</p>
          </div>
        </Alert>
      </div>

      {/* Botão de continuar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gray-800">
        <button className="w-full bg-blue-600 text-white p-4 rounded-lg flex items-center justify-center">
          <span className="mr-2">✓</span>
          Continuar Instalação
        </button>
      </div>
    </div>
  );
};

export default DeviceCheckInterface;