import React, { useState, useEffect } from 'react';
import { Camera, MapPin, Truck } from 'lucide-react';

// Componente para Splash Screen regional que muda conforme o país do usuário
// Implementa a recomendação de "ativar splash screens com mascote regional ao cruzar fronteiras"

const RegionalSplashScreen = ({ 
  country = 'brazil', 
  onFinished = () => {}, 
  language = 'pt',
  timeout = 3000 // Tempo em ms para mostrar a splash screen
}) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  // Tradução para diferentes idiomas (a ser integrado com TranslationsService)
  const translations = {
    pt: {
      loading: 'Carregando...',
      welcome: 'Bem-vindo ao KingRoad',
      beta: 'Versão Beta'
    },
    en: {
      loading: 'Loading...',
      welcome: 'Welcome to KingRoad',
      beta: 'Beta Version'
    },
    es: {
      loading: 'Cargando...',
      welcome: 'Bienvenido a KingRoad',
      beta: 'Versión Beta'
    }
  };

  // Configurações visuais por país
  const regionalSettings = {
    brazil: {
      primaryColor: 'bg-green-600',
      secondaryColor: 'bg-yellow-400',
      icon: <Truck size={64} className="text-white" />,
      mascot: "🇧🇷", // Placeholder para mascote personalizado do Brasil
      backgroundStyle: "bg-gradient-to-br from-green-600 to-yellow-400"
    },
    usa: {
      primaryColor: 'bg-blue-800',
      secondaryColor: 'bg-red-600',
      icon: <Truck size={64} className="text-white" />,
      mascot: "🇺🇸", // Placeholder para mascote personalizado dos EUA
      backgroundStyle: "bg-gradient-to-br from-blue-800 to-red-600"
    },
    argentina: {
      primaryColor: 'bg-blue-500',
      secondaryColor: 'bg-white',
      icon: <Truck size={64} className="text-white" />,
      mascot: "🇦🇷", // Placeholder para mascote personalizado da Argentina
      backgroundStyle: "bg-gradient-to-b from-blue-500 via-white to-blue-500"
    },
    mexico: {
      primaryColor: 'bg-green-600',
      secondaryColor: 'bg-red-600',
      icon: <Truck size={64} className="text-white" />,
      mascot: "🇲🇽", // Placeholder para mascote personalizado do México
      backgroundStyle: "bg-gradient-to-tr from-green-600 via-white to-red-600"
    }
  };

  // Usa país padrão se o país selecionado não estiver disponível
  const region = regionalSettings[country] || regionalSettings.brazil;
  
  // Texto conforme o idioma, com fallback para inglês
  const text = translations[language] || translations.en;

  // Efeito para animar a barra de progresso e fechar após timeout
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (100 / (timeout / 100));
        return newProgress >= 100 ? 100 : newProgress;
      });
    }, 100);

    const timer = setTimeout(() => {
      setLoading(false);
      onFinished();
    }, timeout);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, [timeout, onFinished]);

  return (
    <div className={`fixed inset-0 ${region.backgroundStyle} flex flex-col items-center justify-center z-50`}>
      <div className="p-8 rounded-2xl bg-white bg-opacity-10 backdrop-blur-sm flex flex-col items-center justify-center w-4/5 max-w-md shadow-xl">
        {/* Logo e ícone */}
        <div className="relative mb-6">
          <div className="p-6 rounded-full bg-white shadow-lg">
            {region.icon}
          </div>
          <div className="absolute -right-2 -bottom-2 text-4xl">
            {region.mascot}
          </div>
        </div>

        {/* Texto de boas-vindas */}
        <h1 className="text-2xl font-bold text-white text-center mb-2">
          {text.welcome}
        </h1>
        
        {/* Indicador de versão Beta */}
        <div className="px-3 py-1 bg-amber-500 text-white text-xs font-medium rounded-full mb-6">
          {text.beta}
        </div>

        {/* Informações de localização */}
        <div className="flex items-center mb-6 text-white">
          <MapPin size={16} className="mr-1" />
          <span className="capitalize">{country}</span>
        </div>
        
        {/* Barra de progresso */}
        <div className="w-full h-2 bg-white bg-opacity-30 rounded-full overflow-hidden">
          <div 
            className={`h-full ${region.primaryColor} transition-all duration-100 ease-out`} 
            style={{ width: `${progress}%` }}
          />
        </div>
        
        {/* Texto de carregamento */}
        <p className="mt-3 text-white text-center">{text.loading}</p>
      </div>
    </div>
  );
};

export default RegionalSplashScreen;