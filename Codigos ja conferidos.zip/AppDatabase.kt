// AppDatabase.kt
package com.kingroad.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.kingroad.database.converters.PointListConverter

/**
 * Classe de banco de dados Room para o aplicativo King Road
 */
@Database(
    entities = [TripEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(PointListConverter::class)
abstract class AppDatabase : RoomDatabase() {
    
    /**
     * Acesso ao DAO de viagens
     */
    abstract fun tripDao(): TripDao
    
    companion object {
        private const val DATABASE_NAME = "kingroad_db"
        
        // Instância singleton volátil
        @Volatile
        private var instance: AppDatabase? = null
        
        /**
         * Obtém a instância singleton do banco de dados
         * @param context Contexto da aplicação
         * @return Instância do banco de dados
         */
        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }
        
        /**
         * Constrói a instância do banco de dados
         * @param context Contexto da aplicação
         * @return Nova instância do banco de dados
         */
        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
            .fallbackToDestructiveMigration() // Durante o desenvolvimento, podemos destruir e recriar o banco em migrações
            .build()
        }
    }
}