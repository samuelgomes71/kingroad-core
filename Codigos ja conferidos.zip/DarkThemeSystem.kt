// Sistema de Temas Escuros
// app/src/main/kotlin/com/kingroad/theme

class ThemeManager(
    private val preferenceManager: PreferenceManager,
    private val timeService: TimeService,
    private val locationService: LocationService
) {
    // Paleta de cores segura para visão noturna
    object DarkTheme {
        const val BACKGROUND_PRIMARY = "#121212"    // Fundo principal escuro
        const val BACKGROUND_SECONDARY = "#1E1E1E"  // Fundo secundário
        const val BACKGROUND_TERTIARY = "#252525"   // Fundo terciário
        
        const val TEXT_PRIMARY = "#E1E1E1"    // Texto principal
        const val TEXT_SECONDARY = "#A0A0A0"  // Texto secundário
        const val TEXT_TERTIARY = "#717171"   // Texto terciário
        
        // Cores de destaque com baixa luminosidade
        const val ACCENT_BLUE = "#1A4B81"     // Azul escuro
        const val ACCENT_GREEN = "#1B4D3E"    // Verde escuro
        const val ACCENT_RED = "#6B2D2D"      // Vermelho escuro
        const val ACCENT_YELLOW = "#5C4D1B"   // Amarelo escuro
    }
    
    // Níveis de luminosidade baseados no horário
    enum class Brightness(val value: Float) {
        DAY(1.0f),
        SUNSET(0.7f),
        NIGHT(0.4f),
        PITCH_DARK(0.2f)
    }
    
    // Modo atual
    private var currentMode = ThemeMode.AUTO
    private var currentBrightness = Brightness.DAY
    
    // Inicialização do sistema
    fun initialize() {
        // Configura observador de horário
        timeService.observe { time ->
            updateBrightness(time)
        }
        
        // Monitora condições ambientais
        locationService.observeLocation { location ->
            adjustForLocation(location)
        }
    }
    
    // Atualiza brilho baseado no horário
    private fun updateBrightness(time: LocalTime) {
        currentBrightness = when {
            time.isDay() -> Brightness.DAY
            time.isSunset() -> Brightness.SUNSET
            time.isNight() -> Brightness.NIGHT
            else -> Brightness.PITCH_DARK
        }
        
        applyBrightness()
    }
    
    // Ajusta tema baseado na localização
    private fun adjustForLocation(location: Location) {
        val sunsetTime = calculateSunset(location)
        val sunriseTime = calculateSunrise(location)
        
        updateBrightnessSchedule(sunriseTime, sunsetTime)
    }
    
    // Aplica configurações de brilho
    private fun applyBrightness() {
        val brightness = when (currentMode) {
            ThemeMode.AUTO -> currentBrightness.value
            ThemeMode.ALWAYS_DARK -> Brightness.NIGHT.value
            ThemeMode.MANUAL -> preferenceManager.getBrightness()
        }
        
        applySystemBrightness(brightness)
    }
}

// Interface do usuário com suporte a temas
interface ThemeAware {
    fun onThemeChanged(theme: Theme)
    fun getCurrentTheme(): Theme
    fun supportsDarkMode(): Boolean
}

data class Theme(
    val isDark: Boolean,
    val brightness: Float,
    val colors: ThemeColors
)

data class ThemeColors(
    val backgroundPrimary: String,
    val backgroundSecondary: String,
    val backgroundTertiary: String,
    val textPrimary: String,
    val textSecondary: String,
    val textTertiary: String,
    val accentPrimary: String,
    val accentSecondary: String
)

enum class ThemeMode {
    AUTO,
    ALWAYS_DARK,
    MANUAL
}