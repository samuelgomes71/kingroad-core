import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Platform,
  Linking
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

// Componente de Configurações do App
const SettingsScreen = () => {
  const navigation = useNavigation();
  const [isLoading, setIsLoading] = useState(true);
  
  // Estados para as configurações
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [distanceUnit, setDistanceUnit] = useState('km'); // 'km' ou 'mi'
  const [voiceGuidanceEnabled, setVoiceGuidanceEnabled] = useState(true);
  const [autoUpdateMaps, setAutoUpdateMaps] = useState(true);
  const [saveBatteryMode, setSaveBatteryMode] = useState(false);
  const [trackingPermission, setTrackingPermission] = useState(true);
  const [showSpeedLimit, setShowSpeedLimit] = useState(true);
  const [betaFeaturesEnabled, setBetaFeaturesEnabled] = useState(false);
  
  // Informações do aplicativo
  const appInfo = {
    version: '0.9.5 Beta',
    releaseDuration: '6 meses restantes',
    developer: 'Samuel',
    lastUpdate: '15/03/2025',
  };

  // Carregar configurações salvas
  useEffect(() => {
    const loadSettings = async () => {
      try {
        // Carregar cada configuração do AsyncStorage
        const notifications = await AsyncStorage.getItem('notifications_enabled');
        if (notifications !== null) {
          setNotificationsEnabled(notifications === 'true');
        }
        
        const dark = await AsyncStorage.getItem('dark_mode');
        if (dark !== null) {
          setDarkMode(dark === 'true');
        }
        
        const unit = await AsyncStorage.getItem('distance_unit');
        if (unit !== null) {
          setDistanceUnit(unit);
        }
        
        const voice = await AsyncStorage.getItem('voice_guidance');
        if (voice !== null) {
          setVoiceGuidanceEnabled(voice === 'true');
        }
        
        const autoUpdate = await AsyncStorage.getItem('auto_update_maps');
        if (autoUpdate !== null) {
          setAutoUpdateMaps(autoUpdate === 'true');
        }
        
        const battery = await AsyncStorage.getItem('save_battery_mode');
        if (battery !== null) {
          setSaveBatteryMode(battery === 'true');
        }
        
        const tracking = await AsyncStorage.getItem('tracking_permission');
        if (tracking !== null) {
          setTrackingPermission(tracking === 'true');
        }
        
        const speedLimit = await AsyncStorage.getItem('show_speed_limit');
        if (speedLimit !== null) {
          setShowSpeedLimit(speedLimit === 'true');
        }
        
        const betaFeatures = await AsyncStorage.getItem('beta_features_enabled');
        if (betaFeatures !== null) {
          setBetaFeaturesEnabled(betaFeatures === 'true');
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('Erro ao carregar configurações:', error);
        setIsLoading(false);
      }
    };
    
    loadSettings();
  }, []);
  
  // Alternar notificações
  const toggleNotifications = async (value) => {
    setNotificationsEnabled(value);
    await AsyncStorage.setItem('notifications_enabled', value.toString());
  };
  
  // Alternar modo escuro
  const toggleDarkMode = async (value) => {
    setDarkMode(value);
    await AsyncStorage.setItem('dark_mode', value.toString());
    
    // Em um app real, isso acionaria uma mudança no tema
    Alert.alert(
      'Modo Escuro',
      value ? 'Modo escuro ativado. Esta função estará disponível em breve.' : 'Modo escuro desativado.',
      [{ text: 'OK' }]
    );
  };
  
  // Alternar unidade de distância
  const toggleDistanceUnit = async () => {
    const newUnit = distanceUnit === 'km' ? 'mi' : 'km';
    setDistanceUnit(newUnit);
    await AsyncStorage.setItem('distance_unit', newUnit);
  };
  
  // Alternar guia por voz
  const toggleVoiceGuidance = async (value) => {
    setVoiceGuidanceEnabled(value);
    await AsyncStorage.setItem('voice_guidance', value.toString());
  };
  
  // Alternar atualização automática de mapas
  const toggleAutoUpdateMaps = async (value) => {
    setAutoUpdateMaps(value);
    await AsyncStorage.setItem('auto_update_maps', value.toString());
  };
  
  // Alternar modo de economia de bateria
  const toggleSaveBatteryMode = async (value) => {
    setSaveBatteryMode(value);
    await AsyncStorage.setItem('save_battery_mode', value.toString());
    
    if (value) {
      // Em um app real, isso reduziria a frequência de atualizações de GPS e outras otimizações
      Alert.alert(
        'Economia de Bateria',
        'Modo de economia de bateria ativado. A precisão do GPS e frequência de atualizações serão reduzidas para economizar energia.',
        [{ text: 'OK' }]
      );
    }
  };
  
  // Alternar permissão de rastreamento
  const toggleTrackingPermission = async (value) => {
    setTrackingPermission(value);
    await AsyncStorage.setItem('tracking_permission', value.toString());
  };
  
  // Alternar exibição de limite de velocidade
  const toggleShowSpeedLimit = async (value) => {
    setShowSpeedLimit(value);
    await AsyncStorage.setItem('show_speed_limit', value.toString());
  };
  
  // Alternar recursos beta
  const toggleBetaFeatures = async (value) => {
    setBetaFeaturesEnabled(value);
    await AsyncStorage.setItem('beta_features_enabled', value.toString());
    
    if (value) {
      Alert.alert(
        'Recursos Beta',
        'Recursos experimentais ativados. Tenha em mente que estes podem conter bugs ou comportamentos inesperados.',
        [{ text: 'Entendi' }]
      );
    }
  };
  
  // Abrir configurações de modo offline
  const openOfflineSettings = () => {
    navigation.navigate('OfflineSettings');
  };
  
  // Abrir tela de importação de dados
  const openDataImport = () => {
    navigation.navigate('DataImport');
  };
  
  // Restaurar configurações padrão
  const resetSettings = () => {
    Alert.alert(
      'Restaurar Padrões',
      'Tem certeza que deseja restaurar todas as configurações para os valores padrão?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Restaurar',
          style: 'destructive',
          onPress: async () => {
            try {
              // Definir valores padrão
              setNotificationsEnabled(true);
              setDarkMode(false);
              setDistanceUnit('km');
              setVoiceGuidanceEnabled(true);
              setAutoUpdateMaps(true);
              setSaveBatteryMode(false);
              setTrackingPermission(true);
              setShowSpeedLimit(true);
              setBetaFeaturesEnabled(false);
              
              // Salvar no AsyncStorage
              await AsyncStorage.setItem('notifications_enabled', 'true');
              await AsyncStorage.setItem('dark_mode', 'false');
              await AsyncStorage.setItem('distance_unit', 'km');
              await AsyncStorage.setItem('voice_guidance', 'true');
              await AsyncStorage.setItem('auto_update_maps', 'true');
              await AsyncStorage.setItem('save_battery_mode', 'false');
              await AsyncStorage.setItem('tracking_permission', 'true');
              await AsyncStorage.setItem('show_speed_limit', 'true');
              await AsyncStorage.setItem('beta_features_enabled', 'false');
              
              Alert.alert('Sucesso', 'Configurações restauradas para os valores padrão.');
            } catch (error) {
              console.error('Erro ao restaurar configurações:', error);
              Alert.alert('Erro', 'Não foi possível restaurar as configurações.');
            }
          }
        }
      ]
    );
  };
  
  // Abrir política de privacidade
  const openPrivacyPolicy = () => {
    Linking.openURL('https://kingroad.app/privacidade');
  };
  
  // Abrir termos de uso
  const openTermsOfService = () => {
    Linking.openURL('https://kingroad.app/termos');
  };
  
  // Deixar feedback
  const provideFeedback = () => {
    // Em um app real, isso iria abrir um formulário ou enviar um email
    Alert.alert(
      'Feedback',
      'Sua opinião é muito importante para nós. Como podemos melhorar?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Enviar Email',
          onPress: () => Linking.openURL('mailto:feedback@kingroad.app')
        }
      ]
    );
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
        <Text style={styles.loadingText}>Carregando configurações...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Cabeçalho */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Configurações</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content}>
        {/* Seção de Navegação */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Icon name="map-marker-path" size={22} color="#4A90E2" />
            <Text style={styles.sectionTitle}>Navegação</Text>
          </View>
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={openOfflineSettings}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Modo Offline</Text>
              <Text style={styles.settingDescription}>
                Gerenciar mapas e dados para uso sem internet
              </Text>
            </View>
            <Icon name="chevron-right" size={24} color="#DDD" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Guia por Voz</Text>
              <Text style={styles.settingDescription}>
                Instruções de navegação por áudio
              </Text>
            </View>
            <Switch
              value={voiceGuidanceEnabled}
              onValueChange={toggleVoiceGuidance}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : voiceGuidanceEnabled ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={toggleDistanceUnit}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Unidade de Distância</Text>
              <Text style={styles.settingDescription}>
                {distanceUnit === 'km' ? 'Quilômetros (km)' : 'Milhas (mi)'}
              </Text>
            </View>
            <View style={styles.unitToggle}>
              <Text style={[
                styles.unitText,
                distanceUnit === 'km' && styles.activeUnitText
              ]}>km</Text>
              <Text style={styles.unitSeparator}> | </Text>
              <Text style={[
                styles.unitText,
                distanceUnit === 'mi' && styles.activeUnitText
              ]}>mi</Text>
            </View>
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Exibir Limite de Velocidade</Text>
              <Text style={styles.settingDescription}>
                Mostrar velocidade permitida na via
              </Text>
            </View>
            <Switch
              value={showSpeedLimit}
              onValueChange={toggleShowSpeedLimit}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : showSpeedLimit ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
        </View>

        {/* Seção de Dados */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Icon name="database" size={22} color="#4A90E2" />
            <Text style={styles.sectionTitle}>Dados</Text>
          </View>
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={openDataImport}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Importar Dados</Text>
              <Text style={styles.settingDescription}>
                Importar arquivos GPX, KML, CSV
              </Text>
            </View>
            <Icon name="chevron-right" size={24} color="#DDD" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Atualização Automática de Mapas</Text>
              <Text style={styles.settingDescription}>
                Baixar atualizações quando disponíveis
              </Text>
            </View>
            <Switch
              value={autoUpdateMaps}
              onValueChange={toggleAutoUpdateMaps}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : autoUpdateMaps ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Dados de Utilização e Rastreamento</Text>
              <Text style={styles.settingDescription}>
                Ajude-nos a melhorar compartilhando dados de uso
              </Text>
            </View>
            <Switch
              value={trackingPermission}
              onValueChange={toggleTrackingPermission}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : trackingPermission ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
        </View>

        {/* Seção de Sistema */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Icon name="cog" size={22} color="#4A90E2" />
            <Text style={styles.sectionTitle}>Sistema</Text>
          </View>
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Notificações</Text>
              <Text style={styles.settingDescription}>
                Alertas de tráfego, acidentes e atualizações
              </Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={toggleNotifications}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : notificationsEnabled ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Modo Escuro</Text>
              <Text style={styles.settingDescription}>
                Tema escuro para uso noturno
              </Text>
            </View>
            <Switch
              value={darkMode}
              onValueChange={toggleDarkMode}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : darkMode ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Modo de Economia de Bateria</Text>
              <Text style={styles.settingDescription}>
                Reduzir consumo em troca de atualizações menos frequentes
              </Text>
            </View>
            <Switch
              value={saveBatteryMode}
              onValueChange={toggleSaveBatteryMode}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : saveBatteryMode ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Recursos Beta</Text>
              <Text style={styles.settingDescription}>
                Ativar funcionalidades experimentais
              </Text>
            </View>
            <Switch
              value={betaFeaturesEnabled}
              onValueChange={toggleBetaFeatures}
              trackColor={{ false: '#D1D1D6', true: '#4A90E2' }}
              thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : betaFeaturesEnabled ? '#FFFFFF' : '#F4F3F4'}
              ios_backgroundColor="#D1D1D6"
            />
          </View>
          
          <View style={styles.separator} />
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={resetSettings}
          >
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, { color: '#FF6B6B' }]}>Restaurar Configurações Padrão</Text>
              <Text style={styles.settingDescription}>
                Redefinir todas as configurações para os valores originais
              </Text>
            </View>
            <Icon name="restore" size={24} color="#FF6B6B" />
          </TouchableOpacity>
        </View>

        {/* Seção Sobre */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Icon name="information" size={22} color="#4A90E2" />
            <Text style={styles.sectionTitle}>Sobre</Text>
          </View>
          
          <View style={styles.infoSection}>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Versão</Text>
              <View style={styles.versionContainer}>
                <Text style={styles.infoValue}>{appInfo.version}</Text>
                <View style={styles.betaBadge}>
                  <Text style={styles.betaText}>BETA</Text>
                </View>
              </View>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Período Beta</Text>
              <Text style={styles.infoValue}>{appInfo.releaseDuration}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Desenvolvedor</Text>
              <Text style={styles.infoValue}>{appInfo.developer}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Última Atualização</Text>
              <Text style={styles.infoValue}>{appInfo.lastUpdate}</Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={openPrivacyPolicy}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Política de Privacidade</Text>
            </View>
            <Icon name="chevron-right" size={24} color="#DDD" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={openTermsOfService}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Termos de Uso</Text>
            </View>
            <Icon name="chevron-right" size={24} color="#DDD" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <TouchableOpacity 
            style={styles.settingRow}
            onPress={provideFeedback}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Enviar Feedback</Text>
            </View>
            <Icon name="chevron-right" size={24} color="#DDD" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 15,
    paddingHorizontal: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
    padding: 15,
  },
  section: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginLeft: 10,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingInfo: {
    flex: 1,
    paddingRight: 10,
  },
  settingTitle: {
    fontSize: 16,
    color: '#333',
  },
  settingDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  separator: {
    height: 1,
    backgroundColor: '#ECECEC',
  },
  unitToggle: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F5',
    borderRadius: 15,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  unitText: {
    fontSize: 14,
    color: '#999',
  },
  activeUnitText: {
    color: '#4A90E2',
    fontWeight: 'bold',
  },
  unitSeparator: {
    color: '#DDD',
  },
  infoSection: {
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
  },
  infoValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  versionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  betaBadge: {
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
    marginLeft: 8,
  },
  betaText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
});

export default SettingsScreen;