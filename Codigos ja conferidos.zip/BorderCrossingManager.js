// BorderCrossingManager.js
// Gerenciador para detecção de cruzamento de fronteiras e exibição de boas-vindas

import { Platform, AppState } from 'react-native';
import { NavigationService } from '../navigation/NavigationService';
import geolocationService from './GeolocationService';
import userPreferences from './UserPreferences';
import CountryMascotData from './CountryMascotData';
import Sound from 'react-native-sound';

class BorderCrossingManager {
  constructor() {
    this.isInitialized = false;
    this.appState = 'active';
    this.lastWelcomeTime = 0;
    this.welcomeScreenVisible = false;
    this.cooldownPeriod = 1 * 60 * 60 * 1000; // 1 hora em milissegundos
    this.greetingSounds = {};
    
    // Configurar som
    Sound.setCategory('Playback');
  }
  
  // Inicializar o gerenciador
  initialize() {
    if (this.isInitialized) return;
    
    // Registrar listener para cruzamentos de fronteira
    this.unsubscribeBorderCrossing = geolocationService.addBorderCrossingListener(
      this.handleBorderCrossing.bind(this)
    );
    
    // Monitorar estado do aplicativo
    this.appStateSubscription = AppState.addEventListener(
      'change',
      this.handleAppStateChange.bind(this)
    );
    
    this.isInitialized = true;
    console.log('BorderCrossingManager inicializado');
  }
  
  // Processar mudança de estado do aplicativo
  handleAppStateChange(nextAppState) {
    this.appState = nextAppState;
    
    // Se o app voltar ao primeiro plano, reiniciar monitoramento
    if (nextAppState === 'active' && !geolocationService.isWatching) {
      geolocationService.startWatching();
    }
    
    // Se o app for para o plano de fundo, considerar parar monitoramento
    // para economizar bateria (opcional, dependendo dos requisitos)
    if (nextAppState === 'background') {
      // Opcionalmente: geolocationService.stopWatching();
    }
  }
  
  // Processar evento de cruzamento de fronteira
  handleBorderCrossing(crossingData) {
    const { newCountry, oldCountry } = crossingData;
    const currentTime = Date.now();
    
    console.log(`Fronteira cruzada: ${oldCountry.name} -> ${newCountry.name}`);
    
    // Verificar se a funcionalidade está ativada
    if (!userPreferences.isBorderWelcomeEnabled()) {
      console.log('Boas-vindas de fronteira desativadas nas preferências');
      return;
    }
    
    // Verificar período de cooldown para não mostrar boas-vindas muito frequentemente
    if (currentTime - this.lastWelcomeTime < this.cooldownPeriod) {
      console.log('Período de cooldown ativo, pulando boas-vindas');
      return;
    }
    
    // Verificar se o país é suportado
    if (!this.isCountrySupported(newCountry.name)) {
      console.log(`País não suportado para boas-vindas: ${newCountry.name}`);
      return;
    }
    
    // Atualizar timestamp
    this.lastWelcomeTime = currentTime;
    
    // Mostrar tela de boas-vindas
    this.showWelcomeScreen(newCountry);
  }
  
  // Verificar se o país tem dados de boas-vindas disponíveis
  isCountrySupported(countryName) {
    // Tentar encontrar uma correspondência aproximada se não for exata
    const supportedCountries = Object.keys(CountryMascotData.countryData);
    
    // Verificar correspondência exata
    if (supportedCountries.includes(countryName)) {
      return true;
    }
    
    // Verificar correspondência parcial (ex: "Estados Unidos" vs "Estados Unidos da América")
    const matchingCountry = supportedCountries.find(country => 
      countryName.includes(country) || country.includes(countryName)
    );
    
    return !!matchingCountry;
  }
  
  // Obter nome normalizado do país
  getNormalizedCountryName(countryName) {
    const supportedCountries = Object.keys(CountryMascotData.countryData);
    
    // Verificar correspondência exata
    if (supportedCountries.includes(countryName)) {
      return countryName;
    }
    
    // Verificar correspondência parcial
    const matchingCountry = supportedCountries.find(country => 
      countryName.includes(country) || country.includes(countryName)
    );
    
    return matchingCountry || countryName;
  }
  
  // Mostrar tela de boas-vindas
  showWelcomeScreen(country) {
    if (this.welcomeScreenVisible) return;
    
    try {
      this.welcomeScreenVisible = true;
      
      // Normalizar nome do país
      const normalizedCountryName = this.getNormalizedCountryName(country.name);
      
      // Selecionar uma cidade aleatória ou usar a cidade atual se disponível
      let cityName = country.city;
      if (!cityName) {
        cityName = CountryMascotData.getRandomCity(normalizedCountryName);
      }
      
      // Preparar dados para a tela de boas-vindas
      const welcomeData = {
        country: normalizedCountryName,
        city: cityName,
        // Adicionar dados do país disponíveis no CountryMascotData
        ...(CountryMascotData.countryData[normalizedCountryName] || {})
      };
      
      // Reproduzir áudio de saudação se ativado
      if (userPreferences.isBorderWelcomeAudioEnabled() && welcomeData.greetingAudio) {
        this.playGreetingSound(normalizedCountryName);
      }
      
      // Navegar para a tela de boas-vindas
      NavigationService.navigate('WelcomeScreen', {
        welcomeData,
        // Passar QRA do usuário para a saudação personalizada
        userQRA: userPreferences.getUserQRA(),
        // Passar duração da exibição
        displayTime: userPreferences.getBorderWelcomeTime() * 1000,
        // Passar flag de animação ativada
        animationEnabled: userPreferences.isBorderWelcomeAnimationEnabled(),
        // Callback para quando a tela for fechada
        onClose: this.handleWelcomeScreenClosed.bind(this)
      });
      
      // Registrar impressão para analytics (opcional)
      this.logWelcomeImpression(normalizedCountryName);
      
    } catch (error) {
      console.error('Erro ao mostrar tela de boas-vindas:', error);
      this.welcomeScreenVisible = false;
    }
  }
  
  // Callback quando a tela de boas-vindas é fechada
  handleWelcomeScreenClosed() {
    this.welcomeScreenVisible = false;
  }
  
  // Reproduzir som de saudação
  playGreetingSound(countryName) {
    try {
      // Verificar se o som já foi carregado anteriormente
      if (!this.greetingSounds[countryName]) {
        const countryData = CountryMascotData.countryData[countryName];
        
        if (!countryData || !countryData.greetingAudio) return;
        
        // Carregar som
        const sound = new Sound(countryData.greetingAudio, (error) => {
          if (error) {
            console.error('Erro ao carregar áudio de saudação:', error);
            return;
          }
          
          // Reproduzir som após carregamento
          sound.play((success) => {
            if (!success) {
              console.error('Reprodução de áudio falhou');
            }
          });
        });
        
        // Armazenar referência ao som
        this.greetingSounds[countryName] = sound;
      } else {
        // Reproduzir som já carregado
        const sound = this.greetingSounds[countryName];
        sound.stop(); // Garantir que não está reproduzindo
        sound.play();
      }
    } catch (error) {
      console.error('Erro ao reproduzir áudio de saudação:', error);
    }
  }
  
  // Registrar impressão para analytics
  logWelcomeImpression(countryName) {
    // Implementação depende da solução de analytics usada
    console.log(`[Analytics] Boas-vindas exibidas para: ${countryName}`);
  }
  
  // Interromper o gerenciador
  dispose() {
    if (!this.isInitialized) return;
    
    // Remover listener de cruzamento de fronteira
    if (this.unsubscribeBorderCrossing) {
      this.unsubscribeBorderCrossing();
      this.unsubscribeBorderCrossing = null;
    }
    
    // Remover listener de estado do aplicativo
    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
      this.appStateSubscription = null;
    }
    
    // Liberar recursos de áudio
    Object.values(this.greetingSounds).forEach(sound => {
      sound.release();
    });
    this.greetingSounds = {};
    
    this.isInitialized = false;
    console.log('BorderCrossingManager desativado');
  }
  
  // Simular cruzamento de fronteira (apenas para testes)
  simulateBorderCrossing(countryName) {
    const normalizedCountryName = this.getNormalizedCountryName(countryName);
    const cityName = CountryMascotData.getRandomCity(normalizedCountryName);
    
    const countryCode = CountryMascotData.countryData[normalizedCountryName]?.code || 'XX';
    
    // Usar o serviço de geolocalização para simular o cruzamento
    return geolocationService.simulateBorderCrossing(
      normalizedCountryName,
      countryCode,
      cityName
    );
  }
}

// Criar e exportar uma instância única
const borderCrossingManager = new BorderCrossingManager();
export default borderCrossingManager;