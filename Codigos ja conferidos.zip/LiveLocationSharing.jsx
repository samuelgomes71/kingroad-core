import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Copy, CheckCircle, Clock, QrCode, Share2, Users, Shield, X } from 'lucide-react';

/**
 * Componente que permite compartilhar a localização com outro motorista
 * via código ou QR temporário.
 * 
 * @param {Object} props Propriedades do componente
 * @param {boolean} props.isSharing Se está compartilhando localização atualmente
 * @param {string} props.sharingCode Código para compartilhamento (se estiver compartilhando)
 * @param {number} props.expiresAt Timestamp de quando o compartilhamento expira
 * @param {Array} props.activeShares Lista de compartilhamentos ativos (com quem está compartilhando)
 * @param {Function} props.onStartSharing Callback quando o usuário inicia compartilhamento
 * @param {Function} props.onStopSharing Callback quando o usuário para o compartilhamento
 * @param {Function} props.onJoinShare Callback quando o usuário entra em um compartilhamento
 * @param {string} props.className Classes CSS adicionais
 */
const LiveLocationSharing = ({
  isSharing = false,
  sharingCode = '',
  expiresAt = 0,
  activeShares = [],
  onStartSharing = () => {},
  onStopSharing = () => {},
  onJoinShare = () => {},
  className = ""
}) => {
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [inputCode, setInputCode] = useState('');
  const [codeCopied, setCodeCopied] = useState(false);
  const [shareType, setShareType] = useState('temporary'); // 'temporary' or 'permanent'
  const [shareDuration, setShareDuration] = useState(30); // minutos
  const [remainingTime, setRemainingTime] = useState('');
  const [showQRCode, setShowQRCode] = useState(false);
  
  const timerRef = useRef(null);
  const codeInputRef = useRef(null);

  // Atualiza o tempo restante quando está compartilhando
  useEffect(() => {
    if (isSharing && expiresAt > 0) {
      updateRemainingTime();
      
      timerRef.current = setInterval(() => {
        updateRemainingTime();
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isSharing, expiresAt]);

  // Atualiza o tempo restante
  const updateRemainingTime = () => {
    const now = Date.now();
    const timeLeft = expiresAt - now;
    
    if (timeLeft <= 0) {
      setRemainingTime('Expirado');
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      return;
    }
    
    const minutes = Math.floor(timeLeft / 60000);
    const seconds = Math.floor((timeLeft % 60000) / 1000);
    
    setRemainingTime(`${minutes}:${seconds.toString().padStart(2, '0')}`);
  };

  // Inicia o compartilhamento
  const handleStartSharing = () => {
    onStartSharing({
      type: shareType,
      duration: shareDuration
    });
  };

  // Para o compartilhamento
  const handleStopSharing = () => {
    onStopSharing();
    setCodeCopied(false);
  };

  // Copia o código de compartilhamento para a área de transferência
  const copyCodeToClipboard = () => {
    navigator.clipboard.writeText(sharingCode).then(
      () => {
        setCodeCopied(true);
        setTimeout(() => setCodeCopied(false), 3000);
      },
      (err) => {
        console.error('Erro ao copiar código: ', err);
      }
    );
  };

  // Abre o modal para entrar em um compartilhamento
  const openJoinModal = () => {
    setShowJoinModal(true);
    setInputCode('');
    
    // Foca no input quando o modal abrir
    setTimeout(() => {
      if (codeInputRef.current) {
        codeInputRef.current.focus();
      }
    }, 100);
  };

  // Fecha o modal
  const closeJoinModal = () => {
    setShowJoinModal(false);
  };

  // Processa a entrada em um compartilhamento
  const handleJoinShare = () => {
    if (inputCode.trim().length >= 6) {
      onJoinShare(inputCode.trim());
      closeJoinModal();
    }
  };

  // Formata o tempo de duração para exibição
  const formatDuration = (minutes) => {
    if (minutes < 60) {
      return `${minutes} min`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
    }
  };

  // Renderiza o código QR (simulado)
  const renderQRCode = () => {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <div className="bg-white p-4 rounded-lg">
          {/* Simulação de QR Code */}
          <div className="w-48 h-48 bg-gray-200 flex items-center justify-center">
            <QrCode className="w-32 h-32 text-gray-800" />
          </div>
        </div>
        <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
          Código: <span className="font-medium">{sharingCode}</span>
        </p>
        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
          {remainingTime && `Expira em ${remainingTime}`}
        </p>
      </div>
    );
  };

  // Renderiza controles de compartilhamento
  const renderSharingControls = () => {
    return (
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 block">
            Tipo de compartilhamento
          </label>
          <div className="flex border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden">
            <button
              className={`flex-1 py-2 text-sm font-medium ${shareType === 'temporary' 
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-900 dark:text-blue-300' 
                : 'bg-white text-gray-500 hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'}`}
              onClick={() => setShareType('temporary')}
            >
              Temporário
            </button>
            <button
              className={`flex-1 py-2 text-sm font-medium ${shareType === 'permanent' 
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-900 dark:text-blue-300' 
                : 'bg-white text-gray-500 hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'}`}
              onClick={() => setShareType('permanent')}
            >
              Permanente
            </button>
          </div>
        </div>

        {shareType === 'temporary' && (
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 block">
              Duração: {formatDuration(shareDuration)}
            </label>
            <input
              type="range"
              min="5"
              max="240"
              step="5"
              value={shareDuration}
              onChange={(e) => setShareDuration(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>5min</span>
              <span>1h</span>
              <span>4h</span>
            </div>
          </div>
        )}

        <button
          onClick={handleStartSharing}
          className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600 flex items-center justify-center"
        >
          <Share2 className="w-5 h-5 mr-2" />
          Iniciar compartilhamento
        </button>
      </div>
    );
  };

  // Renderiza detalhes do compartilhamento ativo
  const renderActiveSharing = () => {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="h-2 w-2 bg-green-500 rounded-full mr-2"></div>
            <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
              Compartilhamento ativo
            </span>
          </div>
          {remainingTime && (
            <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
              <Clock className="w-4 h-4 mr-1" />
              {remainingTime}
            </div>
          )}
        </div>

        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
            <div className="flex items-center">
              <MapPin className="w-5 h-5 text-blue-500 dark:text-blue-400 mr-2" />
              <span className="text-sm text-gray-900 dark:text-gray-100">
                Código de compartilhamento
              </span>
            </div>
            <div className="flex items-center">
              <code className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-sm font-mono mr-2">
                {sharingCode}
              </code>
              <button
                onClick={copyCodeToClipboard}
                className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                aria-label="Copiar código"
              >
                {codeCopied ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          <button
            onClick={() => setShowQRCode(!showQRCode)}
            className="py-2 px-4 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 flex items-center justify-center"
          >
            <QrCode className="w-5 h-5 mr-2" />
            {showQRCode ? "Ocultar QR Code" : "Mostrar QR Code"}
          </button>

          {showQRCode && renderQRCode()}

          <button
            onClick={handleStopSharing}
            className="py-2 px-4 bg-red-100 text-red-700 rounded-md hover:bg-red-200 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800 flex items-center justify-center mt-2"
          >
            <X className="w-5 h-5 mr-2" />
            Parar compartilhamento
          </button>
        </div>
      </div>
    );
  };

  // Renderiza lista de compartilhamentos ativos
  const renderActiveSharesList = () => {
    if (activeShares.length === 0) {
      return null;
    }

    return (
      <div className="mt-6">
        <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2 flex items-center">
          <Users className="w-5 h-5 mr-2 text-gray-500 dark:text-gray-400" />
          Compartilhando com {activeShares.length} {activeShares.length === 1 ? 'pessoa' : 'pessoas'}
        </h4>
        <div className="space-y-2">
          {activeShares.map((share) => (
            <div 
              key={share.id} 
              className="flex items-center justify-between bg-gray-50 dark:bg-gray-800 p-3 rounded-md"
            >
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-700 dark:text-blue-300 mr-3">
                  {share.name.substring(0, 1).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{share.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {share.expiresAt ? `Expira em ${formatTimeLeft(share.expiresAt)}` : 'Compartilhamento permanente'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onStopSharing(share.id)}
                className="p-1 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                aria-label="Parar compartilhamento"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Formata o tempo restante para exibição
  const formatTimeLeft = (expiryTimestamp) => {
    const now = Date.now();
    const timeLeft = expiryTimestamp - now;
    
    if (timeLeft <= 0) {
      return 'Expirado';
    }
    
    const minutes = Math.floor(timeLeft / 60000);
    
    if (minutes < 60) {
      return `${minutes}min`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
    }
  };

  // Renderiza modal para entrar em um compartilhamento
  const renderJoinModal = () => {
    if (!showJoinModal) return null;

    return (
      <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          {/* Background overlay */}
          <div 
            className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity dark:bg-gray-900 dark:bg-opacity-75" 
            aria-hidden="true"
            onClick={closeJoinModal}
          ></div>

          {/* Modal panel */}
          <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full dark:bg-gray-800">
            <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <div className="sm:flex sm:items-start">
                <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10 dark:bg-blue-900">
                  <MapPin className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100" id="modal-title">
                    Entrar em compartilhamento
                  </h3>
                  <div className="mt-2">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Digite o código de compartilhamento fornecido pelo outro motorista.
                    </p>
                    <div className="mt-3">
                      <label htmlFor="share-code" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Código de compartilhamento
                      </label>
                      <input
                        type="text"
                        id="share-code"
                        ref={codeInputRef}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        placeholder="Digite o código"
                        value={inputCode}
                        onChange={(e) => setInputCode(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleJoinShare();
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse dark:bg-gray-700">
              <button
                type="button"
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm dark:bg-blue-700 dark:hover:bg-blue-600"
                onClick={handleJoinShare}
              >
                Entrar
              </button>
              <button
                type="button"
                className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700"
                onClick={closeJoinModal}
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={`bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700 ${className}`}>
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
            Compartilhamento de Localização
          </h3>
          <div className="flex items-center">
            <Shield className="w-4 h-4 text-green-500 mr-1" />
            <span className="text-xs text-gray-500 dark:text-gray-400">Seguro</span>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        {isSharing ? renderActiveSharing() : renderSharingControls()}
        
        {!isSharing && (
          <div className="mt-4 border-t border-gray-200 pt-4 dark:border-gray-700">
            <button
              onClick={openJoinModal}
              className="w-full py-2 px-4 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600 flex items-center justify-center"
            >
              <MapPin className="w-5 h-5 mr-2" />
              Entrar em compartilhamento
            </button>
          </div>
        )}
        
        {renderActiveSharesList()}
      </div>
      
      {renderJoinModal()}
    </div>
  );
};

export default LiveLocationSharing;