// Sistema de Alertas de Semáforo
// app/src/main/kotlin/com/kingroad/alerts/trafficlight

import android.location.Location
import android.graphics.drawable.Icon

class TrafficLightManager(
    private val locationService: LocationService,
    private val alertService: AlertService,
    private val trafficService: TrafficService
) {
    data class TrafficLight(
        val id: String,
        val location: Location,
        val status: LightStatus,
        val waitTime: Int? = null,     // tempo em segundos
        val cycleTime: Int? = null,    // tempo total do ciclo
        val type: TrafficLightType,
        val speedLimit: Int? = null    // limite de velocidade na via
    )

    enum class LightStatus {
        RED,            // Vermelho
        YELLOW,         // Amarelo
        FLASHING_YELLOW,// Amarelo piscante
        GREEN,          // Verde
        OFF            // Desligado
    }

    enum class TrafficLightType {
        STANDARD,       // Padrão
        SMART,          // Inteligente
        TIMED,          // Temporizado
        COORDINATED    // Sincronizado
    }

    // Monitorar semáforos próximos
    suspend fun startTrafficLightMonitoring() {
        locationService.startLocationUpdates { location ->
            checkNearbyTrafficLights(location)
        }
    }

    // Verificar semáforos próximos
    private suspend fun checkNearbyTrafficLights(location: Location) {
        val nearbyLights = trafficService.getNearbyTrafficLights(
            location = location,
            radius = ALERT_RADIUS
        )

        nearbyLights.forEach { light ->
            processTrafficLight(light, location)
        }
    }

    // Processar semáforo
    private suspend fun processTrafficLight(
        light: TrafficLight,
        currentLocation: Location
    ) {
        val distance = calculateDistance(currentLocation, light.location)
        
        when {
            // Alerta de semáforo vermelho
            light.status == LightStatus.RED && 
            distance <= RED_LIGHT_ALERT_DISTANCE -> {
                showRedLightAlert(light, distance)
            }
            
            // Alerta de semáforo amarelo
            light.status == LightStatus.YELLOW && 
            distance <= YELLOW_LIGHT_ALERT_DISTANCE -> {
                showYellowLightAlert(light, distance)
            }
            
            // Alerta de amarelo piscante
            light.status == LightStatus.FLASHING_YELLOW && 
            distance <= FLASHING_YELLOW_ALERT_DISTANCE -> {
                showFlashingYellowAlert(light, distance)
            }
        }
    }

    // Calcular distância entre dois pontos
    private fun calculateDistance(current: Location, target: Location): Double {
        val results = FloatArray(1)
        Location.distanceBetween(
            current.latitude, current.longitude,
            target.latitude, target.longitude,
            results
        )
        return results[0].toDouble()
    }

    // Formatar distância para exibição
    private fun formatDistance(meters: Double): String {
        return when {
            meters < 1000 -> "${meters.toInt()} metros"
            else -> String.format("%.1f km", meters / 1000)
        }
    }

    // Mostrar alerta de semáforo vermelho 
    private suspend fun showRedLightAlert(
        light: TrafficLight,
        distance: Double
    ) {
        val message = buildString {
            append("Atenção! Semáforo vermelho a ${formatDistance(distance)}. ")
            
            light.waitTime?.let { time ->
                append("Tempo estimado de espera: $time segundos. ")
            }
            
            light.speedLimit?.let { limit ->
                append("Limite de velocidade: $limit km/h. ")
            }
        }

        alertService.showAlert(
            message = message,
            type = AlertType.RED_LIGHT,
            priority = AlertPriority.HIGH,
            icon = createRedLightIcon()
        )
    }

    // Mostrar alerta de semáforo amarelo
    private suspend fun showYellowLightAlert(
        light: TrafficLight,
        distance: Double
    ) {
        val message = buildString {
            append("Atenção! Semáforo amarelo a ${formatDistance(distance)}. ")
            
            if (shouldStop(distance, light)) {
                append("Recomendado parar. ")
            }
            
            light.speedLimit?.let { limit ->
                append("Limite de velocidade: $limit km/h. ")
            }
        }

        alertService.showAlert(
            message = message,
            type = AlertType.YELLOW_LIGHT,
            priority = AlertPriority.HIGH,
            icon = createYellowLightIcon()
        )
    }

    // Mostrar alerta de amarelo piscante
    private suspend fun showFlashingYellowAlert(
        light: TrafficLight,
        distance: Double
    ) {
        val message = "Atenção! Semáforo amarelo piscante a ${formatDistance(distance)}. Prossiga com cautela."

        alertService.showAlert(
            message = message,
            type = AlertType.FLASHING_YELLOW,
            priority = AlertPriority.MEDIUM,
            icon = createFlashingYellowIcon()
        )
    }

    // Calcular se deve parar no amarelo
    private fun shouldStop(
        distance: Double,
        light: TrafficLight
    ): Boolean {
        val currentSpeed = locationService.getCurrentSpeed()
        val stoppingDistance = calculateStoppingDistance(currentSpeed)
        
        return distance <= stoppingDistance
    }

    private fun calculateStoppingDistance(speedKmh: Float): Double {
        // Fórmula simplificada de distância de frenagem
        // Considera tempo de reação (1 segundo) + distância de frenagem
        val speedMs = speedKmh / 3.6
        val reactionDistance = speedMs * 1.0  // distância percorrida em 1 segundo
        val brakingDistance = (speedMs * speedMs) / (2 * 7.0)  // considerando desaceleração de 7 m/s²
        
        return reactionDistance + brakingDistance
    }

    // Criar ícone de semáforo vermelho
    private fun createRedLightIcon(): Icon {
        return Icon.createWithResource(
            packageName = "com.kingroad",
            resId = R.drawable.ic_traffic_light_red
        )
    }

    // Criar ícone de semáforo amarelo
    private fun createYellowLightIcon(): Icon {
        return Icon.createWithResource(
            packageName = "com.kingroad",
            resId = R.drawable.ic_traffic_light_yellow
        )
    }

    // Criar ícone de semáforo amarelo piscante
    private fun createFlashingYellowIcon(): Icon {
        return Icon.createWithResource(
            packageName = "com.kingroad",
            resId = R.drawable.ic_traffic_light_flashing_yellow
        )
    }

    companion object {
        const val ALERT_RADIUS = 500.0  // metros
        const val RED_LIGHT_ALERT_DISTANCE = 300.0  // metros
        const val YELLOW_LIGHT_ALERT_DISTANCE = 200.0  // metros
        const val FLASHING_YELLOW_ALERT_DISTANCE = 150.0  // metros
    }
}

// Enums para alertas
enum class AlertType {
    RED_LIGHT,
    YELLOW_LIGHT,
    FLASHING_YELLOW,
    GREEN_LIGHT
}

enum class AlertPriority {
    LOW,
    MEDIUM,
    HIGH
}

// Interfaces de serviço necessárias
interface LocationService {
    suspend fun startLocationUpdates(callback: suspend (Location) -> Unit)
    fun getCurrentSpeed(): Float
}

interface AlertService {
    suspend fun showAlert(
        message: String,
        type: AlertType,
        priority: AlertPriority,
        icon: Icon
    )
}

interface TrafficService {
    suspend fun getNearbyTrafficLights(
        location: Location, 
        radius: Double
    ): List<TrafficLightManager.TrafficLight>
}