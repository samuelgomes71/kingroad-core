import React, { useState } from 'react';
import { Radio, Play, Star, Trash2, Music, MoreVertical, ChevronDown } from 'lucide-react';

const DropdownRadios = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [radios, setRadios] = useState([
    { id: 1, name: 'Rádio Estrada FM', country: 'Brasil', language: 'Português', isPlaying: true, isPrimary: true },
    { id: 2, name: 'Caminhoneiros Mix', country: 'Brasil', language: 'Português', isPlaying: false, isPrimary: false },
    { id: 3, name: 'Trucker Radio', country: 'EUA', language: 'Inglês', isPlaying: false, isPrimary: false },
    { id: 4, name: 'Radio Carretera', country: 'Espanha', language: 'Espanhol', isPlaying: false, isPrimary: false }
  ]);
  
  // Estilo "Família 15": borda café, fundo bege claro
  const familyStyle = {
    borderColor: '#8B4513', // café
    backgroundColor: '#F5F5DC', // bege claro
  };
  
  const handlePlay = (id) => {
    setRadios(radios.map(radio => ({
      ...radio,
      isPlaying: radio.id === id
    })));
  };
  
  const handleSetPrimary = (id) => {
    setRadios(radios.map(radio => ({
      ...radio,
      isPrimary: radio.id === id
    })));
  };
  
  const handleRemove = (id) => {
    setRadios(radios.filter(radio => radio.id !== id));
  };
  
  return (
    <div className="max-w-xs mx-auto">
      <div className="flex items-center mb-2">
        <Radio className="h-5 w-5 mr-2 text-blue-600" />
        <span className="font-medium">Minhas Rádios Favoritas</span>
        <button 
          className="ml-auto p-1 rounded-full hover:bg-gray-200"
          onClick={() => setIsOpen(!isOpen)}
        >
          <ChevronDown className={`h-5 w-5 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} />
        </button>
      </div>
      
      {isOpen && (
        <div 
          className="rounded-lg shadow-md overflow-hidden"
          style={{
            border: '2px solid',
            ...familyStyle
          }}
        >
          {radios.map((radio) => (
            <div 
              key={radio.id}
              className={`p-3 flex items-center justify-between border-b last:border-b-0 ${radio.isPlaying ? 'bg-opacity-20 bg-blue-100' : ''}`}
              style={{
                borderColor: familyStyle.borderColor
              }}
            >
              <div className="flex items-center">
                <div className="p-1 rounded-full bg-white mr-3">
                  <Music className={`h-5 w-5 ${radio.isPlaying ? 'text-blue-600' : 'text-gray-600'}`} />
                </div>
                <div>
                  <p className="font-medium text-gray-800 flex items-center">
                    {radio.name}
                    {radio.isPrimary && (
                      <Star className="h-4 w-4 ml-1 text-yellow-500 fill-current" />
                    )}
                  </p>
                  <p className="text-xs text-gray-600">{radio.country} • {radio.language}</p>
                </div>
              </div>
              
              <div className="flex space-x-1">
                <button 
                  className={`p-1.5 rounded-full ${radio.isPlaying ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-200'}`}
                  onClick={() => handlePlay(radio.id)}
                  title="Tocar"
                >
                  <Play className="h-4 w-4" />
                </button>
                <button 
                  className={`p-1.5 rounded-full ${radio.isPrimary ? 'bg-yellow-100 text-yellow-700' : 'hover:bg-gray-200'}`}
                  onClick={() => handleSetPrimary(radio.id)}
                  title="Definir como principal"
                >
                  <Star className="h-4 w-4" />
                </button>
                <button 
                  className="p-1.5 rounded-full hover:bg-gray-200 hover:text-red-600"
                  onClick={() => handleRemove(radio.id)}
                  title="Remover dos favoritos"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
          
          <div className="p-2 text-center border-t" style={{ borderColor: familyStyle.borderColor }}>
            <button className="text-sm text-blue-600 font-medium hover:underline">
              + Adicionar nova rádio
            </button>
          </div>
        </div>
      )}
      
      <div className="bg-white border border-gray-300 rounded-md p-2 mt-2 shadow-sm text-xs">
        <p><strong>Dica:</strong> Pressione longamente o atalho da rádio principal para abrir este menu ou toque no botão de seta para cima/baixo.</p>
        <p className="mt-1">Você pode tocar, definir como principal ou remover suas rádios favoritas.</p>
      </div>
    </div>
  );
};

export default DropdownRadios;