import React, { useCallback, useRef, useState } from 'react';

/**
 * Hook para evitar cliques acidentais repetidos
 * @param {Function} callback - Função a ser executada após o clique
 * @param {number} delay - Tempo em ms para ignorar cliques subsequentes (padrão: 500ms)
 * @param {boolean} showFeedback - Se deve mostrar feedback visual de desabilitação 
 * @returns {Object} - Objeto com handler de clique e estado de desabilitação
 */
export const useClickGuard = (callback, delay = 500, showFeedback = true) => {
  const [isDisabled, setIsDisabled] = useState(false);
  const lastClickTime = useRef(0);
  
  const handleClick = useCallback((...args) => {
    const now = Date.now();
    const timeSinceLastClick = now - lastClickTime.current;
    
    // Se o último clique foi muito recente, ignorar
    if (timeSinceLastClick < delay) {
      console.log('Clique ignorado - muito rápido');
      return;
    }
    
    // Atualizar o timestamp do último clique
    lastClickTime.current = now;
    
    // Desabilitar temporariamente e executar callback
    if (showFeedback) {
      setIsDisabled(true);
      setTimeout(() => setIsDisabled(false), delay);
    }
    
    callback(...args);
  }, [callback, delay, showFeedback]);
  
  return { handleClick, isDisabled };
};

/**
 * Componente botão com proteção contra cliques acidentais
 */
const GuardedButton = ({ 
  onClick, 
  children, 
  className = '', 
  delay = 500,
  showFeedback = true,
  disabledClassName = 'opacity-50 cursor-not-allowed',
  ...props 
}) => {
  const { handleClick, isDisabled } = useClickGuard(onClick, delay, showFeedback);
  
  return (
    <button
      onClick={handleClick}
      className={`${className} ${isDisabled ? disabledClassName : ''}`}
      disabled={isDisabled}
      {...props}
    >
      {children}
    </button>
  );
};

/**
 * Componente de alta ordem (HOC) para adicionar proteção contra cliques acidentais
 * em qualquer componente clicável
 */
export const withClickGuard = (Component) => {
  return ({ onClick, guardDelay = 500, showGuardFeedback = true, ...props }) => {
    const { handleClick, isDisabled } = useClickGuard(onClick, guardDelay, showGuardFeedback);
    
    return (
      <Component 
        {...props}
        onClick={handleClick}
        disabled={props.disabled || isDisabled}
      />
    );
  };
};

/**
 * Exemplo de uso:
 * 
 * // Como hook em um componente customizado
 * const MyComponent = ({ onSave }) => {
 *   const { handleClick, isDisabled } = useClickGuard(onSave, 1000);
 *   
 *   return (
 *     <button 
 *       onClick={handleClick} 
 *       disabled={isDisabled}
 *       className={isDisabled ? 'opacity-50' : ''}
 *     >
 *       Salvar
 *     </button>
 *   );
 * };
 * 
 * // Como componente pronto
 * <GuardedButton onClick={handleSave} delay={800}>
 *   Salvar Alterações
 * </GuardedButton>
 * 
 * // Como HOC para envolver componentes existentes
 * const GuardedIconButton = withClickGuard(IconButton);
 * <GuardedIconButton onClick={handleAction} guardDelay={500} />
 */

export default GuardedButton;

/**
 * Aplicação específica para o projeto King Road - integração no modo desenvolvedor
 */
export const KingRoadClickGuard = {
  /**
   * Aplica a proteção de cliques acidentais ao sistema de navegação
   * @param {Object} navigationSystem - Sistema de navegação do King Road
   */
  applyToNavigation: (navigationSystem) => {
    // Sobrescreve os handlers de eventos padrão com versões protegidas
    const originalHandlers = navigationSystem.eventHandlers || {};
    
    navigationSystem.eventHandlers = {
      ...originalHandlers,
      onRouteSelect: (...args) => {
        const { handleClick } = useClickGuard(
          originalHandlers.onRouteSelect, 
          600, // Tempo de proteção maior para seleção de rotas
          false // Não mostrar feedback visual
        );
        handleClick(...args);
      },
      onInstructionClick: (...args) => {
        const { handleClick } = useClickGuard(
          originalHandlers.onInstructionClick, 
          500
        );
        handleClick(...args);
      }
    };
    
    return navigationSystem;
  },
  
  /**
   * Aplica a proteção de cliques acidentais ao modo desenvolvedor
   * @param {Object} devMode - Objeto do modo desenvolvedor
   */
  applyToDevMode: (devMode) => {
    if (!devMode || !devMode.actions) return devMode;
    
    // Cria versões protegidas de todas as ações do modo desenvolvedor
    const protectedActions = {};
    
    Object.keys(devMode.actions).forEach(actionKey => {
      const originalAction = devMode.actions[actionKey];
      
      protectedActions[actionKey] = (...args) => {
        const { handleClick } = useClickGuard(
          originalAction, 
          700, // Tempo maior para ações do dev mode que podem ser mais pesadas
          true
        );
        handleClick(...args);
      };
    });
    
    return {
      ...devMode,
      actions: protectedActions
    };
  }
};