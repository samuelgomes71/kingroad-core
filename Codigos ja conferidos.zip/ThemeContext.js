/**
 * ThemeContext.js
 * 
 * Contexto para gerenciamento de temas (claro/escuro).
 * Implementa contexto React para prover configurações de tema, 
 * com suporte a modo claro/escuro automático baseado no sistema 
 * ou definido pelo usuário.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React, { createContext, useState, useEffect, useContext } from 'react';
import { Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Definição dos temas disponíveis
export const THEMES = {
  LIGHT: 'light',
  DARK: 'dark',
  SYSTEM: 'system' // Usa a preferência do sistema
};

// Chave para armazenamento das preferências de tema
const THEME_STORAGE_KEY = 'kingroad_theme_preference';

// Criação do contexto
const ThemeContext = createContext();

/**
 * Provedor do ThemeContext
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Componentes filhos
 * @param {string} [props.defaultTheme=THEMES.SYSTEM] - Tema padrão
 */
export const ThemeProvider = ({
  children,
  defaultTheme = THEMES.SYSTEM
}) => {
  // Estado para armazenar a preferência de tema
  const [theme, setTheme] = useState(defaultTheme);
  
  // Estado para armazenar o tema ativo (sempre light ou dark)
  const [activeTheme, setActiveTheme] = useState(THEMES.LIGHT);
  
  // Carrega preferência de tema salva
  useEffect(() => {
    const loadSavedTheme = async () => {
      try {
        const savedTheme = await AsyncStorage.getItem(THEME_STORAGE_KEY);
        if (savedTheme && Object.values(THEMES).includes(savedTheme)) {
          setTheme(savedTheme);
        }
      } catch (error) {
        console.error('[ThemeContext] Erro ao carregar tema salvo:', error);
      }
    };

    loadSavedTheme();
  }, []);

  // Monitora mudanças nas preferências do sistema
  useEffect(() => {
    const updateActiveTheme = () => {
      if (theme === THEMES.SYSTEM) {
        // Obtém preferência do sistema (claro ou escuro)
        const colorScheme = Appearance.getColorScheme();
        setActiveTheme(colorScheme === 'dark' ? THEMES.DARK : THEMES.LIGHT);
      } else {
        // Usa a preferência explícita do usuário
        setActiveTheme(theme);
      }
    };

    // Configura listener para mudanças na preferência do sistema
    const subscription = Appearance.addChangeListener(updateActiveTheme);
    
    // Inicializa o tema ativo
    updateActiveTheme();

    // Cleanup do listener quando o componente desmontar
    return () => subscription.remove();
  }, [theme]);

  // Salva preferência quando mudar
  useEffect(() => {
    const saveThemePreference = async () => {
      try {
        await AsyncStorage.setItem(THEME_STORAGE_KEY, theme);
      } catch (error) {
        console.error('[ThemeContext] Erro ao salvar tema:', error);
      }
    };

    saveThemePreference();
  }, [theme]);

  /**
   * Altera o tema da aplicação
   * @param {string} newTheme - Novo tema (LIGHT, DARK ou SYSTEM)
   */
  const changeTheme = (newTheme) => {
    if (Object.values(THEMES).includes(newTheme)) {
      setTheme(newTheme);
    } else {
      console.error(`[ThemeContext] Tema inválido: ${newTheme}`);
    }
  };

  /**
   * Alterna entre temas claro e escuro
   * Ignora o modo system e configura explicitamente
   */
  const toggleTheme = () => {
    setTheme(activeTheme === THEMES.LIGHT ? THEMES.DARK : THEMES.LIGHT);
  };

  // Cores e estilos baseados no tema ativo
  const colors = {
    // Cores primárias
    primary: activeTheme === THEMES.DARK ? '#1E88E5' : '#2196F3',
    primaryDark: activeTheme === THEMES.DARK ? '#0D47A1' : '#1565C0',
    primaryLight: activeTheme === THEMES.DARK ? '#64B5F6' : '#90CAF9',
    
    // Cores de fundo
    background: activeTheme === THEMES.DARK ? '#121212' : '#FFFFFF',
    surface: activeTheme === THEMES.DARK ? '#1E1E1E' : '#F5F5F5',
    card: activeTheme === THEMES.DARK ? '#2D2D2D' : '#FFFFFF',
    
    // Cores de texto
    text: activeTheme === THEMES.DARK ? '#FFFFFF' : '#000000',
    textSecondary: activeTheme === THEMES.DARK ? '#B0B0B0' : '#757575',
    textDisabled: activeTheme === THEMES.DARK ? '#666666' : '#BDBDBD',
    
    // Bordas e divisores
    border: activeTheme === THEMES.DARK ? '#424242' : '#E0E0E0',
    divider: activeTheme === THEMES.DARK ? '#424242' : '#E0E0E0',
    
    // Estados
    success: activeTheme === THEMES.DARK ? '#4CAF50' : '#43A047',
    warning: activeTheme === THEMES.DARK ? '#FFC107' : '#FFB300',
    error: activeTheme === THEMES.DARK ? '#F44336' : '#E53935',
    info: activeTheme === THEMES.DARK ? '#2196F3' : '#1E88E5',
    
    // Elementos de interação
    ripple: activeTheme === THEMES.DARK ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.12)',
    overlay: activeTheme === THEMES.DARK ? 'rgba(0, 0, 0, 0.5)' : 'rgba(0, 0, 0, 0.3)',
    backdrop: activeTheme === THEMES.DARK ? 'rgba(0, 0, 0, 0.7)' : 'rgba(0, 0, 0, 0.5)',
    
    // Cores de marca
    brand: '#1E88E5',
    brandSecondary: '#64B5F6'
  };

  /**
   * Valor do contexto
   */
  const contextValue = {
    // Valores de estado
    theme,           // Preferência atual (light, dark, system)
    activeTheme,     // Tema efetivamente aplicado (sempre light ou dark)
    isDark: activeTheme === THEMES.DARK,
    isLight: activeTheme === THEMES.LIGHT,
    isSystemTheme: theme === THEMES.SYSTEM,
    
    // Funções
    changeTheme,     // Função para alterar o tema
    toggleTheme,     // Função para alternar entre claro e escuro
    
    // Tema e cores
    colors,          // Objeto com cores baseadas no tema atual
    
    // Constantes
    THEMES           // Constantes para referência
  };

  return (
    <ThemeContext.Provider value={contextValue}>
      {children}
    </ThemeContext.Provider>
  );
};

/**
 * Hook para usar o ThemeContext
 * @returns {Object} Valor do contexto de tema
 */
export const useTheme = () => {
  const context = useContext(ThemeContext);
  
  if (!context) {
    throw new Error('[ThemeContext] useTheme deve ser usado dentro de um ThemeProvider');
  }
  
  return context;
};

export default ThemeContext;