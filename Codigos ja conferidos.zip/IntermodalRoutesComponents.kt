package com.kingroad.ui.navigation.intermodal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kingroad.R
import com.kingroad.navigation.intermodal.*
import com.kingroad.ui.common.MapView
import com.kingroad.ui.theme.KingRoadColors
import com.kingroad.ui.theme.KingRoadTypography
import com.kingroad.utils.formatCurrency
import com.kingroad.utils.formatDistance
import com.kingroad.utils.formatDuration

/**
 * Painel para configuração de preferências de rota
 */
@Composable
fun RoutePreferencesPanel(
    preferences: RoutePreferences,
    onPreferencesChanged: (RoutePreferences) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(KingRoadColors.Background)
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.route_preferences),
            style = KingRoadTypography.appTitle,
            color = KingRoadColors.TextColor
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Opção para evitar ferries
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = preferences.avoidFerries,
                onCheckedChange = { checked ->
                    onPreferencesChanged(preferences.copy(avoidFerries = checked))
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = KingRoadColors.Accent,
                    uncheckedColor = KingRoadColors.TextColor
                )
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.DirectionsBoat,
                    contentDescription = null,
                    tint = KingRoadColors.TextColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.avoid_ferries),
                    color = KingRoadColors.TextColor
                )
            }
        }
        
        // Opção para evitar túneis
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = preferences.avoidTunnels,
                onCheckedChange = { checked ->
                    onPreferencesChanged(preferences.copy(avoidTunnels = checked))
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = KingRoadColors.Accent,
                    uncheckedColor = KingRoadColors.TextColor
                )
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Route,
                    contentDescription = null,
                    tint = KingRoadColors.TextColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.avoid_tunnels),
                    color = KingRoadColors.TextColor
                )
            }
        }
        
        // Opção para preferir rota mais rápida
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = preferences.preferFastestRoute,
                onCheckedChange = { checked ->
                    onPreferencesChanged(preferences.copy(preferFastestRoute = checked))
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = KingRoadColors.Accent,
                    uncheckedColor = KingRoadColors.TextColor
                )
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Speed,
                    contentDescription = null,
                    tint = KingRoadColors.TextColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.prefer_fastest_route),
                    color = KingRoadColors.TextColor
                )
            }
        }
        
        // Limite de custo
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(
                text = stringResource(R.string.max_cost_for_intermodal),
                color = KingRoadColors.TextColor
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Slider para o custo máximo
            val maxValue = 500.0
            Slider(
                value = preferences.maxCostForIntermodal.coerceAtMost(maxValue).toFloat(),
                onValueChange = { newValue ->
                    onPreferencesChanged(preferences.copy(maxCostForIntermodal = newValue.toDouble()))
                },
                valueRange = 0f..maxValue.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = KingRoadColors.Accent,
                    activeTrackColor = KingRoadColors.Accent,
                    inactiveTrackColor = KingRoadColors.TextColor.copy(alpha = 0.3f)
                )
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.unlimited),
                    color = KingRoadColors.TextColor,
                    style = MaterialTheme.typography.labelSmall
                )
                
                Text(
                    text = if (preferences.maxCostForIntermodal >= maxValue) 
                        stringResource(R.string.unlimited)
                    else 
                        formatCurrency(preferences.maxCostForIntermodal, "EUR"),
                    color = KingRoadColors.TextColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Componente para o mapa com marcadores de conexões intermodais
 */
@Composable
fun MapWithIntermodalConnections(
    uiState: IntermodalRoutesUiState,
    selectedRoute: RouteInfo?,
    onConnectionSelected: (IntermodalConnection) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Na implementação real, usaria um MapView real com Google Maps, Mapbox, etc.
        // Para este exemplo, usando um placeholder
        MapView(
            modifier = Modifier.fillMaxSize(),
            isInteractive = true
        )
        
        // Indicador de rota selecionada
        if (selectedRoute != null) {
            RouteIndicator(
                route = selectedRoute,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
            )
        }
    }
}

/**
 * Indicador de rota selecionada
 */
@Composable
fun RouteIndicator(
    route: RouteInfo,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth(0.9f)
            .padding(8.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = KingRoadColors.BackgroundLight
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Origem -> Destino
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = route.startPoint.name ?: stringResource(R.string.origin),
                    style = MaterialTheme.typography.titleMedium,
                    color = KingRoadColors.TextColor
                )
                
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = KingRoadColors.TextColor,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                
                Text(
                    text = route.endPoint.name ?: stringResource(R.string.destination),
                    style = MaterialTheme.typography.titleMedium,
                    color = KingRoadColors.TextColor
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Informações da rota
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Distância
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Map,
                        contentDescription = null,
                        tint = KingRoadColors.TextColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatDistance(route.distance, LocalContext.current),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor
                    )
                }
                
                // Duração
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Timer,
                        contentDescription = null,
                        tint = KingRoadColors.TextColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatDuration(route.duration),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor
                    )
                }
                
                // Custo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Payments,
                        contentDescription = null,
                        tint = KingRoadColors.TextColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatCurrency(route.totalCost, route.currency),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor
                    )
                }
            }
            
            // Conexões na rota
            if (route.intermodalConnections.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = KingRoadColors.TextColor.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = stringResource(R.string.intermodal_connections),
                    style = MaterialTheme.typography.titleSmall,
                    color = KingRoadColors.TextColor
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                route.intermodalConnections.forEach { connection ->
                    ConnectionChip(
                        connection = connection,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * Painel com lista de rotas disponíveis
 */
@Composable
fun RoutesListPanel(
    uiState: IntermodalRoutesUiState,
    selectedRoute: RouteInfo?,
    onRouteSelected: (RouteInfo) -> Unit,
    onConnectionSelected: (IntermodalConnection) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KingRoadColors.BackgroundLight)
    ) {
        // Cabeçalho
        Text(
            text = stringResource(R.string.available_routes),
            style = KingRoadTypography.splitScreenAppTitle,
            color = KingRoadColors.TextColor,
            modifier = Modifier
                .fillMaxWidth()
                .background(KingRoadColors.Background)
                .padding(16.dp)
        )
        
        // Lista de rotas
        if (uiState.routes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.no_routes_available),
                    color = KingRoadColors.TextColor
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(uiState.routes) { route ->
                    RouteCard(
                        route = route,
                        isSelected = selectedRoute?.id == route.id,
                        onClick = { onRouteSelected(route) },
                        onConnectionClick = onConnectionSelected
                    )
                }
            }
        }
    }
}

/**
 * Cartão que exibe informações de uma rota
 */
@Composable
fun RouteCard(
    route: RouteInfo,
    isSelected: Boolean,
    onClick: () -> Unit,
    onConnectionClick: (IntermodalConnection) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = if (isSelected) {
            BorderStroke(2.dp, KingRoadColors.Accent)
        } else {
            null
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Origem -> Destino
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = route.startPoint.name ?: stringResource(R.string.origin),
                    style = MaterialTheme.typography.titleMedium,
                    color = KingRoadColors.TextColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = KingRoadColors.TextColor,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                
                Text(
                    text = route.endPoint.name ?: stringResource(R.string.destination),
                    style = MaterialTheme.typography.titleMedium,
                    color = KingRoadColors.TextColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Informações da rota
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Distância
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = stringResource(R.string.distance),
                        style = MaterialTheme.typography.labelSmall,
                        color = KingRoadColors.TextColor.copy(alpha = 0.7f)
                    )
                    Text(
                        text = formatDistance(route.distance, LocalContext.current),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor
                    )
                }
                
                // Duração
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = stringResource(R.string.duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = KingRoadColors.TextColor.copy(alpha = 0.7f)
                    )
                    Text(
                        text = formatDuration(route.duration),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor
                    )
                }
                
                // Custo
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = stringResource(R.string.cost),
                        style = MaterialTheme.typography.labelSmall,
                        color = KingRoadColors.TextColor.copy(alpha = 0.7f)
                    )
                    Text(
                        text = formatCurrency(route.totalCost, route.currency),
                        style = MaterialTheme.typography.bodyMedium,
                        color = KingRoadColors.TextColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            // Conexões na rota
            if (route.intermodalConnections.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = KingRoadColors.TextColor.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = stringResource(R.string.connections),
                    style = MaterialTheme.typography.labelMedium,
                    color = KingRoadColors.TextColor
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Lista de conexões
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    route.intermodalConnections.forEach { connection ->
                        ConnectionChip(
                            connection = connection,
                            onClick = { onConnectionClick(connection) }
                        )
                    }
                }
            }
        }
    }
}