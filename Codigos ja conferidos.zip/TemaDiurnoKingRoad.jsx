import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, TrendingUp, Truck, DollarSign, Compass, Menu, Coffee, Map } from 'lucide-react';

// Definição das cores do tema
const temaColors = {
  bege: {
    claro: '#F5EEE0',  // Bege claro para fundo do mapa
    medio: '#E8DCC9',  // Bege médio para elementos secundários
    escuro: '#D0C0A6'   // Bege escuro para bordas e detalhes
  },
  cafe: {
    claro: '#9C8369',   // Café claro para botões e elementos interativos
    medio: '#6E5C4A',   // Café médio para textos e ícones
    escuro: '#3F3329'   // Café escuro para barras e elementos de destaque
  },
  agua: '#B5D6D6',      // Cor para água no mapa
  estrada: '#3A3330',   // Cor para estradas
  texto: {
    claro: '#F5EEE0',   // Texto claro para fundos escuros
    escuro: '#3F3329'   // Texto escuro para fundos claros
  }
};

// Hook personalizado para detectar o tamanho da tela
const useScreenSize = () => {
  const [screenSize, setScreenSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
    isTablet: window.innerWidth >= 600,
    isLargeTablet: window.innerWidth >= 840
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      setScreenSize({
        width,
        height,
        isTablet: width >= 600,
        isLargeTablet: width >= 840
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return screenSize;
};

// Componente do Tema Diurno KingRoad
const TemaDiurnoKingRoad = () => {
  const { width, height, isTablet, isLargeTablet } = useScreenSize();
  const [velocidade, setVelocidade] = useState(33);

  // Forçar orientação horizontal para tablets grandes
  const estiloContainer = {
    width: '100%',
    height: '100%',
    backgroundColor: temaColors.bege.claro,
    position: 'relative',
    overflow: 'hidden',
    fontFamily: 'Arial, sans-serif',
    color: temaColors.cafe.medio
  };

  // Se o dispositivo for tablet grande (>7"), exibir mensagem para rotacionar
  if (isLargeTablet && height > width) {
    return (
      <div style={{
        ...estiloContainer,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
        textAlign: 'center'
      }}>
        <div style={{
          backgroundColor: temaColors.cafe.medio,
          borderRadius: '16px',
          padding: '32px',
          maxWidth: '400px'
        }}>
          <Navigation size={64} color={temaColors.bege.claro} style={{ marginBottom: '16px' }} />
          <h2 style={{ fontSize: '24px', color: temaColors.bege.claro, marginBottom: '16px' }}>
            Por favor, rotacione seu dispositivo
          </h2>
          <p style={{ fontSize: '16px', color: temaColors.bege.claro }}>
            O KingRoad funciona melhor em orientação horizontal em tablets.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={estiloContainer}>
      {/* Barra superior */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        backgroundColor: temaColors.cafe.escuro,
        padding: '8px',
        color: temaColors.texto.claro
      }}>
        <div style={{ fontWeight: 'bold', display: 'flex', alignItems: 'center' }}>
          <Navigation size={16} style={{ marginRight: '4px' }} />
          KING ROAD
        </div>
        <div style={{ display: 'flex', gap: '16px' }}>
          <span style={{ fontSize: '14px' }}>9</span>
          <span style={{ fontSize: '14px' }}>3</span>
          <Compass size={16} />
          <Coffee size={16} />
          <Map size={16} />
          <Menu size={16} />
        </div>
      </div>

      {/* Conteúdo principal (mapa) */}
      <div style={{
        backgroundColor: temaColors.bege.claro,
        height: 'calc(100% - 240px)', // Ajustado para acomodar barras superior e inferior
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Simulação do mapa 3D */}
        <div style={{
          position: 'absolute',
          width: '100%',
          height: '100%',
          backgroundImage: `linear-gradient(135deg, ${temaColors.bege.claro} 25%, ${temaColors.bege.medio} 25%, ${temaColors.bege.medio} 50%, ${temaColors.bege.claro} 50%, ${temaColors.bege.claro} 75%, ${temaColors.bege.medio} 75%, ${temaColors.bege.medio})`,
          backgroundSize: '40px 40px'
        }} />

        {/* Água */}
        <div style={{
          position: 'absolute',
          bottom: '10%',
          left: '0',
          width: '30%',
          height: '20%',
          backgroundColor: temaColors.agua,
          borderRadius: '50% 50% 0 0'
        }} />

        {/* Estradas */}
        <div style={{
          position: 'absolute',
          top: '30%',
          left: '10%',
          width: '80%',
          height: '25px',
          backgroundColor: temaColors.estrada,
          transform: 'rotate(-15deg)',
          borderRadius: '5px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
        }}>
          <div style={{
            position: 'absolute',
            top: '50%',
            width: '100%',
            height: '2px',
            backgroundColor: temaColors.bege.claro,
            backgroundImage: `linear-gradient(90deg, ${temaColors.bege.claro} 50%, transparent 50%)`,
            backgroundSize: '20px 1px'
          }} />
        </div>

        <div style={{
          position: 'absolute',
          top: '40%',
          right: '10%',
          width: '60%',
          height: '25px',
          backgroundColor: temaColors.estrada,
          transform: 'rotate(25deg)',
          borderRadius: '5px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
        }}>
          <div style={{
            position: 'absolute',
            top: '50%',
            width: '100%',
            height: '2px',
            backgroundColor: temaColors.bege.claro,
            backgroundImage: `linear-gradient(90deg, ${temaColors.bege.claro} 50%, transparent 50%)`,
            backgroundSize: '20px 1px'
          }} />
        </div>

        {/* Caminhões 3D simulados */}
        {[
          { top: '35%', left: '40%', rotation: -15 },
          { top: '45%', right: '30%', rotation: 25 },
          { top: '60%', right: '20%', rotation: 0 }
        ].map((pos, idx) => (
          <div key={idx} style={{
            position: 'absolute',
            top: pos.top,
            left: pos.left,
            right: pos.right,
            width: '30px',
            height: '15px',
            backgroundColor: temaColors.cafe.claro,
            borderRadius: '2px',
            transform: `rotate(${pos.rotation}deg)`,
            boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
          }}>
            <div style={{
              position: 'absolute',
              top: '0',
              left: '0',
              width: '10px',
              height: '10px',
              backgroundColor: temaColors.cafe.medio,
              borderRadius: '2px 0 0 0'
            }} />
          </div>
        ))}

        {/* Texto King Road no mapa */}
        <div style={{
          position: 'absolute',
          top: '15%',
          left: '45%',
          transform: 'translateX(-50%)',
          fontWeight: 'bold',
          fontSize: isTablet ? '24px' : '18px',
          color: temaColors.cafe.medio
        }}>
          KING ROAD
        </div>

        {/* Texto Rest Areas */}
        <div style={{
          position: 'absolute',
          top: '60%',
          right: '15%',
          fontSize: isTablet ? '16px' : '12px',
          color: temaColors.cafe.medio
        }}>
          REST AREAS
        </div>

        {/* Pontos de interesse */}
        {[
          { top: '30%', left: '20%' },
          { top: '50%', left: '60%' },
          { top: '65%', left: '30%' }
        ].map((pos, idx) => (
          <div key={idx} style={{
            position: 'absolute',
            top: pos.top,
            left: pos.left,
            width: '24px',
            height: '24px',
            borderRadius: '50%',
            backgroundColor: temaColors.cafe.escuro,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <MapPin size={14} color={temaColors.bege.claro} />
          </div>
        ))}
      </div>

      {/* Barra de ferramentas inferior */}
      <div style={{
        backgroundColor: temaColors.cafe.escuro,
        padding: '8px',
        display: 'flex',
        flexDirection: 'column',
        gap: '8px'
      }}>
        {/* Primeira linha de botões */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          gap: '8px'
        }}>
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '50%',
            width: '40px',
            height: '40px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <Compass size={24} color={temaColors.bege.claro} />
          </div>
          
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '8px',
            padding: '4px 8px',
            display: 'flex',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <span style={{ fontSize: '24px', fontWeight: 'bold', color: temaColors.bege.claro }}>9</span>
          </div>
          
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '8px',
            padding: '4px 8px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <MapPin size={24} color={temaColors.bege.claro} />
          </div>
          
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '8px',
            padding: '4px 8px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: temaColors.bege.claro }}>ROAD</span>
          </div>
          
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '8px',
            padding: '4px 8px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <Menu size={24} color={temaColors.bege.claro} />
          </div>
        </div>
        
        {/* Segunda linha - velocidade e opções de pedágio */}
        <div style={{
          display: 'flex',
          gap: '8px',
          justifyContent: 'space-between'
        }}>
          <div style={{
            backgroundColor: temaColors.cafe.medio,
            borderRadius: '8px',
            padding: '8px',
            width: '60px',
            height: '60px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
          }}>
            <div style={{
              backgroundColor: temaColors.cafe.escuro,
              borderRadius: '50%',
              width: '40px',
              height: '40px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              border: `2px solid ${temaColors.bege.claro}`
            }}>
              <span style={{ fontSize: '18px', fontWeight: 'bold', color: temaColors.bege.claro }}>{velocidade}</span>
            </div>
            <span style={{ fontSize: '10px', color: temaColors.bege.claro, marginTop: '4px' }}>TOLLS</span>
          </div>
          
          {[
            { icon: <Truck size={24} />, text: 'AVOIDING TOLLS' },
            { icon: <Truck size={24} />, text: 'AVOIDING TOLLS' },
            { icon: <Truck size={24} />, text: 'AVOIDING TOLLS' }
          ].map((item, idx) => (
            <div key={idx} style={{
              backgroundColor: temaColors.cafe.medio,
              borderRadius: '8px',
              padding: '8px',
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
            }}>
              <div style={{
                backgroundColor: temaColors.cafe.escuro,
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center'
              }}>
                {React.cloneElement(item.icon, { color: temaColors.bege.claro })}
              </div>
              <span style={{ fontSize: '10px', color: temaColors.bege.claro, marginTop: '4px', textAlign: 'center' }}>
                {item.text}
              </span>
            </div>
          ))}
        </div>
        
        {/* Terceira linha - botões circulares */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          marginTop: '8px'
        }}>
          {[
            <Navigation size={24} />,
            <TrendingUp size={24} />,
            <Compass size={24} />,
            <MapPin size={24} />,
            <DollarSign size={24} />
          ].map((icon, idx) => (
            <div key={idx} style={{
              backgroundColor: temaColors.cafe.medio,
              borderRadius: '50%',
              width: '44px',
              height: '44px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
            }}>
              {React.cloneElement(icon, { color: temaColors.bege.claro })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Hook para detecção de orientação
const usarOrientacaoForcada = (orientacaoDesejada = 'any') => {
  const [orientacao, setOrientacao] = useState({
    tipo: window.innerWidth > window.innerHeight ? 'landscape' : 'portrait',
    angulo: window.screen?.orientation?.angle || 0
  });
  
  useEffect(() => {
    const atualizarOrientacao = () => {
      const novaOrientacao = {
        tipo: window.innerWidth > window.innerHeight ? 'landscape' : 'portrait',
        angulo: window.screen?.orientation?.angle || 0
      };
      setOrientacao(novaOrientacao);
    };
    
    window.addEventListener('resize', atualizarOrientacao);
    window.addEventListener('orientationchange', atualizarOrientacao);
    
    // Função para travar orientação se disponível
    const travarOrientacao = async () => {
      if (window.screen?.orientation?.lock) {
        try {
          await window.screen.orientation.lock(orientacaoDesejada);
        } catch (e) {
          console.log('Não foi possível travar a orientação', e);
        }
      }
    };
    
    if (orientacaoDesejada !== 'any') {
      travarOrientacao();
    }
    
    return () => {
      window.removeEventListener('resize', atualizarOrientacao);
      window.removeEventListener('orientationchange', atualizarOrientacao);
      
      // Desbloquear ao desmontar
      if (window.screen?.orientation?.unlock) {
        window.screen.orientation.unlock();
      }
    };
  }, [orientacaoDesejada]);
  
  return orientacao;
};

// Componente para demonstração com detecção de tamanho e orientação
const TemaDemo = () => {
  const { width, isLargeTablet } = useScreenSize();
  
  // Força orientação horizontal para tablets (>7 polegadas = 600px de largura aproximadamente)
  usarOrientacaoForcada(isLargeTablet ? 'landscape' : 'any');
  
  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      overflow: 'hidden',
      backgroundColor: '#3F3329'
    }}>
      <TemaDiurnoKingRoad />
    </div>
  );
};

export default TemaDemo;