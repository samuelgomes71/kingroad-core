package com.kingroad.routing

import com.kingroad.api.CustomerIDService

fun calcularRotaPorCustomerID(customerID: String, customerIDService: CustomerIDService) {
    val destino = customerIDService.buscarDestinoPorID(customerID)

    if (destino != null) {
        println("Traçando rota para: ${destino.companyName} em ${destino.city}, ${destino.state}")
        iniciarNavegacao(destino.latitude, destino.longitude)
    } else {
        println("ID do cliente não encontrado!")
    }
}

fun iniciarNavegacao(latitude: Double, longitude: Double) {
    println("Navegando para as coordenadas: $latitude, $longitude")
    // Aqui você adicionaria a lógica para iniciar a navegação no GPS.
}
