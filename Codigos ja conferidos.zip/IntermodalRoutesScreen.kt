package com.kingroad.ui.navigation.intermodal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.kingroad.R
import com.kingroad.navigation.intermodal.*
import com.kingroad.ui.common.LoadingIndicator
import com.kingroad.ui.common.MapView
import com.kingroad.ui.theme.KingRoadColors
import com.kingroad.ui.theme.KingRoadTheme
import com.kingroad.ui.theme.KingRoadTypography
import com.kingroad.utils.formatCurrency
import com.kingroad.utils.formatDistance
import com.kingroad.utils.formatDuration
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Tela principal para exibição e gerenciamento de rotas com conexões intermodais
 * (balsas, ferries e túneis)
 */
@Composable
fun IntermodalRoutesScreen(
    viewModel: IntermodalRoutesViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onShowDetails: (IntermodalConnection) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val routePreferences by viewModel.routePreferences.collectAsState()
    val scope = rememberCoroutineScope()
    
    // Estado para controle da UI
    var showSettings by remember { mutableStateOf(false) }
    var showRouteDetails by remember { mutableStateOf(false) }
    var selectedRoute by remember { mutableStateOf<RouteInfo?>(null) }
    var showConnectionDetails by remember { mutableStateOf(false) }
    var selectedConnection by remember { mutableStateOf<IntermodalConnection?>(null) }
    
    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Barra de título
            TopAppBar(
                title = { Text(stringResource(R.string.intermodal_routes_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.settings))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KingRoadColors.Accent,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
            
            // Painel de configurações (animado)
            AnimatedVisibility(
                visible = showSettings,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                RoutePreferencesPanel(
                    preferences = routePreferences,
                    onPreferencesChanged = { newPrefs ->
                        scope.launch {
                            viewModel.updateRoutePreferences(newPrefs)
                        }
                    }
                )
            }
            
            // Conteúdo principal
            Box(modifier = Modifier.weight(1f)) {
                // Layout adaptável baseado no tamanho da tela
                BoxWithConstraints {
                    val useHorizontalLayout = maxWidth > 600.dp
                    
                    if (useHorizontalLayout) {
                        // Layout para telas grandes (divisão horizontal)
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Mapa (lado esquerdo)
                            Box(modifier = Modifier
                                .weight(0.6f)
                                .fillMaxHeight()
                            ) {
                                MapWithIntermodalConnections(
                                    uiState = uiState,
                                    selectedRoute = selectedRoute,
                                    onConnectionSelected = { connection ->
                                        selectedConnection = connection
                                        showConnectionDetails = true
                                    }
                                )
                            }
                            
                            // Lista de rotas (lado direito)
                            Box(modifier = Modifier
                                .weight(0.4f)
                                .fillMaxHeight()
                                .background(KingRoadColors.BackgroundLight)
                            ) {
                                RoutesListPanel(
                                    uiState = uiState,
                                    selectedRoute = selectedRoute,
                                    onRouteSelected = { route ->
                                        selectedRoute = route
                                    },
                                    onConnectionSelected = { connection ->
                                        selectedConnection = connection
                                        showConnectionDetails = true
                                    }
                                )
                            }
                        }
                    } else {
                        // Layout para telas pequenas (empilhado)
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Mapa em tela cheia
                            MapWithIntermodalConnections(
                                uiState = uiState,
                                selectedRoute = selectedRoute,
                                onConnectionSelected = { connection ->
                                    selectedConnection = connection
                                    showConnectionDetails = true
                                }
                            )
                            
                            // Botão para mostrar/esconder a lista de rotas
                            FloatingActionButton(
                                onClick = { showRouteDetails = !showRouteDetails },
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(16.dp),
                                containerColor = KingRoadColors.Accent,
                                contentColor = Color.White
                            ) {
                                Icon(
                                    if (showRouteDetails) Icons.Default.Close else Icons.Default.List,
                                    contentDescription = stringResource(
                                        if (showRouteDetails) R.string.hide_routes else R.string.show_routes
                                    )
                                )
                            }
                            
                            // Painel de rotas (deslizante de baixo para cima)
                            AnimatedVisibility(
                                visible = showRouteDetails,
                                enter = slideInVertically(initialOffsetY = { it }),
                                exit = slideOutVertically(targetOffsetY = { it })
                            ) {
                                Box(modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(0.6f)
                                    .align(Alignment.BottomCenter)
                                    .background(
                                        KingRoadColors.BackgroundLight,
                                        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                                    )
                                ) {
                                    RoutesListPanel(
                                        uiState = uiState,
                                        selectedRoute = selectedRoute,
                                        onRouteSelected = { route ->
                                            selectedRoute = route
                                        },
                                        onConnectionSelected = { connection ->
                                            selectedConnection = connection
                                            showConnectionDetails = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Dialog para detalhes da conexão
        if (showConnectionDetails && selectedConnection != null) {
            ConnectionDetailsDialog(
                connection = selectedConnection!!,
                onDismiss = { showConnectionDetails = false },
                onShowFullDetails = { onShowDetails(selectedConnection!!) }
            )
        }
        
        // Indicador de carregamento
        if (uiState.isLoading) {
            LoadingIndicator()
        }
    }
}