// data/poiData.js
export const truckStops = [
  { id: 1, name: 'Posto Shell Grande Parada', distance: 3.9, direction: 'I-95 N', city: 'São Paulo, SP', rating: 4.1, reviews: 87, parking: 'many', amenities: ['restaurant', 'shower', 'wifi', 'mechanic'] },
  { id: 2, name: 'Truck Stop 3 Eixos', distance: 68, direction: 'BR-116 S', city: 'Curitiba, PR', rating: 3.8, reviews: 65, parking: 'some', amenities: ['restaurant', 'shower', 'fuel'] },
  { id: 3, name: 'Parada do Caminhoneiro', distance: 152, direction: 'BR-381 N', city: 'Belo Horizonte, MG', rating: 4.5, reviews: 129, parking: 'full', amenities: ['restaurant', 'shower', 'wifi', 'atm', 'laundry'] }
];

export const weighStations = [
  { id: 1, name: 'Balança Anchieta', distance: 1.9, highway: 'BR-040', status: 'closed', lastUpdate: '10 min atrás', reports: 35 },
  { id: 2, name: 'Balança Fernão Dias', distance: 31.4, highway: 'BR-381', status: 'monitored', lastUpdate: '25 min atrás', reports: 12 },
  { id: 3, name: 'Posto Fiscal Anhanguera', distance: 62.6, highway: 'BR-050', status: 'open', lastUpdate: '5 min atrás', reports: 48 }
];

export const restAreas = [
  { id: 1, name: 'Área de Descanso Km 45', distance: 8.2, highway: 'BR-116', parking: 'many', security: 'high', reports: 15 },
  { id: 2, name: 'Área de Descanso Régis', distance: 43.7, highway: 'BR-381', parking: 'some', security: 'medium', reports: 29 },
  { id: 3, name: 'Ponto de Parada Vale do Café', distance: 97.2, highway: 'BR-040', parking: 'full', security: 'low', reports: 42 }
];

export const parkingHistory = [
  { time: '22:45', date: 'Hoje', status: 'MANY SPOTS' },
  { time: '19:30', date: 'Hoje', status: 'SOME SPOTS' },
  { time: '15:15', date: 'Hoje', status: 'LOT IS FULL' },
  { time: '10:20', date: 'Hoje', status: 'MANY SPOTS' },
  { time: '22:45', date: 'Ontem', status: 'MANY SPOTS' },
  { time: '17:30', date: 'Ontem', status: 'LOT IS FULL' }
];

export const inspectionHistory = [
  { time: '21:15', date: 'Hoje', status: 'NO INSPECTION' },
  { time: '16:30', date: 'Hoje', status: 'NO INSPECTION' },
  { time: '12:45', date: 'Hoje', status: 'OPEN INSPECTION' },
  { time: '08:20', date: 'Hoje', status: 'NO INSPECTION' },
  { time: '22:30', date: 'Ontem', status: 'NO INSPECTION' },
  { time: '18:15', date: 'Ontem', status: 'NO INSPECTION' }
];

export const reviews = [
  { id: 1, user: 'TruckDriver123', rating: 4, text: 'Bom lugar para descansar. Banheiros limpos e comida boa.', date: '3 dias atrás' },
  { id: 2, user: 'RoadKing87', rating: 5, text: 'Ótimo atendimento, estacionamento amplo e seguro.', date: '1 semana atrás' },
  { id: 3, user: 'Frete_Seguro', rating: 3, text: 'Comida cara, mas tem bom chuveiro e wifi funciona bem.', date: '2 semanas atrás' }
];