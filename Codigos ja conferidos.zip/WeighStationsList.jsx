// WeighStationsList.jsx
import React from 'react';
import { Clock, Users } from 'lucide-react';
import { getWeighStationStatusColor } from '../utils/uiHelpers';

const WeighStationsList = ({ stations, onSelectStation }) => {
  return (
    <div className="space-y-2">
      {stations.map((station) => (
        <div 
          key={station.id} 
          className="bg-stone-800 rounded-lg p-3 cursor-pointer"
          onClick={() => onSelectStation(station)}
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-white font-bold text-lg">{station.name}</h3>
              <p className="text-stone-300 text-sm">{station.highway}</p>
              <div className="flex items-center mt-1">
                <Clock size={14} className="text-stone-400 mr-1" />
                <span className="text-stone-400 text-xs">Atualizado {station.lastUpdate}</span>
                <div className="ml-3 flex items-center">
                  <Users size={14} className="text-stone-400 mr-1" />
                  <span className="text-stone-400 text-xs">{station.reports} motoristas</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-amber-300 font-bold text-lg">{station.distance}</span>
              <span className="text-stone-400 text-xs">km</span>
              <div className={`mt-2 px-3 py-1 rounded-md ${getWeighStationStatusColor(station.status)}`}>
                {station.status === 'open' ? 'ABERTA' : 
                 station.status === 'monitored' ? 'MONITORADA' : 'FECHADA'}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default WeighStationsList;