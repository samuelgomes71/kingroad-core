import React, { useState, useEffect, useContext, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { AlertContext } from './Alert';
import { PrimaryButton, SecondaryButton } from './commonButtons';

// Constantes para tipos de veículos e limites de peso
const VEHICLE_TYPES = {
  TRUCK_NORMAL: 'truckNormal',
  TRUCK_ARTICULATED: 'truckArticulated',
  TRUCK_BITRAINR9: 'truckBitrainR9',
  TRUCK_ROADTRAIN: 'truckRoadtrain',
  VAN: 'van'
};

const AXLE_DEFAULTS = {
  [VEHICLE_TYPES.TRUCK_NORMAL]: 2,
  [VEHICLE_TYPES.TRUCK_ARTICULATED]: 5,
  [VEHICLE_TYPES.TRUCK_BITRAINR9]: 9,
  [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 7,
  [VEHICLE_TYPES.VAN]: 2
};

// Limites de peso por país (em toneladas)
const WEIGHT_LIMITS = {
  BR: {
    singleAxle: 10,
    doubleAxle: 17,
    tripleAxle: 25.5,
    totalWeight: {
      [VEHICLE_TYPES.TRUCK_NORMAL]: 29,
      [VEHICLE_TYPES.TRUCK_ARTICULATED]: 48.5,
      [VEHICLE_TYPES.TRUCK_BITRAINR9]: 74,
      [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 57,
      [VEHICLE_TYPES.VAN]: 3.5
    }
  },
  US: {
    singleAxle: 9,
    doubleAxle: 15.4,
    tripleAxle: 23.6,
    totalWeight: {
      [VEHICLE_TYPES.TRUCK_NORMAL]: 36.3,
      [VEHICLE_TYPES.TRUCK_ARTICULATED]: 36.3,
      [VEHICLE_TYPES.TRUCK_BITRAINR9]: 36.3,
      [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 36.3,
      [VEHICLE_TYPES.VAN]: 4.5
    }
  },
  // Adicionar mais países conforme necessário
  DEFAULT: {
    singleAxle: 10,
    doubleAxle: 16,
    tripleAxle: 24,
    totalWeight: {
      [VEHICLE_TYPES.TRUCK_NORMAL]: 30,
      [VEHICLE_TYPES.TRUCK_ARTICULATED]: 45,
      [VEHICLE_TYPES.TRUCK_BITRAINR9]: 65,
      [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 55,
      [VEHICLE_TYPES.VAN]: 3.5
    }
  }
};

/**
 * Componente principal do sistema de pesagem
 */
const WeighingSystem = ({ 
  vehicleType = VEHICLE_TYPES.TRUCK_NORMAL,
  countryCode = 'BR',
  hasBluetoothScale = false,
  onWeighingComplete = () => {},
  isDemo = false
}) => {
  const { t } = useTranslation();
  const { showAlert } = useContext(AlertContext);
  
  // Estados para o sistema de pesagem
  const [weightData, setWeightData] = useState({
    vehicleEmptyWeight: 0,
    currentWeight: 0,
    cargoWeight: 0,
    axleWeights: [],
    totalWeight: 0,
    lastWeighingDate: null,
    weighingHistory: [],
    isOverweight: false,
    overweightDetails: null
  });
  
  const [isConnected, setIsConnected] = useState(false);
  const [isWeighing, setIsWeighing] = useState(false);
  const [axleCount, setAxleCount] = useState(AXLE_DEFAULTS[vehicleType] || 2);
  const [calculatedWeight, setCalculatedWeight] = useState(null);
  const [preWeighingEstimate, setPreWeighingEstimate] = useState(null);
  const [scaleDevices, setScaleDevices] = useState([]);
  const [selectedScale, setSelectedScale] = useState(null);
  const [manualEntry, setManualEntry] = useState(false);
  
  // Obter limites de peso com base no país
  const weightLimits = WEIGHT_LIMITS[countryCode] || WEIGHT_LIMITS.DEFAULT;
  
  // Verificar se o peso está acima do limite
  const checkOverweight = useCallback((totalWeight, axleWeights = []) => {
    const vehicleLimit = weightLimits.totalWeight[vehicleType] || weightLimits.totalWeight.DEFAULT;
    let isOver = totalWeight > vehicleLimit;
    let details = null;
    
    if (isOver) {
      details = {
        totalOverage: totalWeight - vehicleLimit,
        axleOverages: []
      };
    }
    
    // Verificar sobrepeso em cada eixo
    if (axleWeights.length > 0) {
      axleWeights.forEach((weight, index) => {
        let axleType = 'singleAxle';
        if (index % 3 === 0 && index > 0) axleType = 'tripleAxle';
        else if (index % 2 === 0 && index > 0) axleType = 'doubleAxle';
        
        const axleLimit = weightLimits[axleType];
        if (weight > axleLimit) {
          isOver = true;
          if (!details) details = { totalOverage: 0, axleOverages: [] };
          details.axleOverages.push({
            axle: index + 1,
            weight,
            limit: axleLimit,
            overage: weight - axleLimit
          });
        }
      });
    }
    
    return { isOverweight: isOver, details };
  }, [vehicleType, weightLimits]);
  
  // Efeito para configurar o número de eixos com base no tipo de veículo
  useEffect(() => {
    setAxleCount(AXLE_DEFAULTS[vehicleType] || 2);
  }, [vehicleType]);
  
  // Recuperar histórico de pesagem do armazenamento local
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('kingroad_weighing_history');
      if (savedHistory) {
        const parsedHistory = JSON.parse(savedHistory);
        setWeightData(prev => ({
          ...prev,
          weighingHistory: parsedHistory
        }));
      }
    } catch (error) {
      console.error('Erro ao carregar histórico de pesagem:', error);
    }
  }, []);
  
  // Conectar à balança via Bluetooth
  const connectToScale = async () => {
    if (!hasBluetoothScale) {
      setManualEntry(true);
      return;
    }
    
    try {
      // Verificar se o navegador suporta Bluetooth
      if (!navigator.bluetooth) {
        throw new Error(t('weighing.bluetoothNotSupported'));
      }
      
      // Solicitar dispositivo Bluetooth
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: ['weight_scale'] },
          { namePrefix: 'Scale' }
        ],
        optionalServices: ['battery_service', 'device_information']
      });
      
      // Conectar ao GATT Server
      const server = await device.gatt.connect();
      
      // Obter serviço de pesagem
      const service = await server.getPrimaryService('weight_scale');
      
      // Obter características
      const weightCharacteristic = await service.getCharacteristic('weight_measurement');
      
      // Configurar notificações de peso
      await weightCharacteristic.startNotifications();
      weightCharacteristic.addEventListener('characteristicvaluechanged', handleWeightChange);
      
      setIsConnected(true);
      setSelectedScale(device);
      
      showAlert({
        type: 'success',
        message: t('weighing.connectedToScale', { name: device.name }),
        duration: 3000
      });
    } catch (error) {
      console.error('Erro ao conectar à balança:', error);
      
      showAlert({
        type: 'error',
        message: t('weighing.connectionError', { error: error.message }),
        duration: 5000
      });
      
      // Fallback para entrada manual
      setManualEntry(true);
    }
  };
  
  // Desconectar da balança
  const disconnectFromScale = async () => {
    if (selectedScale && selectedScale.gatt.connected) {
      try {
        // Desconectar
        await selectedScale.gatt.disconnect();
        
        setIsConnected(false);
        setSelectedScale(null);
        
        showAlert({
          type: 'info',
          message: t('weighing.disconnectedFromScale'),
          duration: 3000
        });
      } catch (error) {
        console.error('Erro ao desconectar da balança:', error);
      }
    }
  };
  
  // Manipular mudanças de peso da balança
  const handleWeightChange = (event) => {
    const value = event.target.value;
    const weight = value.getFloat32(0, true); // Obter valor de peso (assumindo formato float32)
    
    setWeightData(prev => ({
      ...prev,
      currentWeight: weight
    }));
  };
  
  // Iniciar processo de pesagem
  const startWeighing = () => {
    setIsWeighing(true);
    
    if (isDemo || manualEntry) {
      // Para demonstração ou entrada manual, simular leituras de peso
      const demoAxleWeights = Array(axleCount).fill(0).map(() => 
        Math.floor(Math.random() * 10) + 5 // 5-15 toneladas por eixo
      );
      
      const demoTotalWeight = demoAxleWeights.reduce((sum, weight) => sum + weight, 0);
      const { isOverweight, details } = checkOverweight(demoTotalWeight, demoAxleWeights);
      
      setWeightData(prev => ({
        ...prev,
        axleWeights: demoAxleWeights,
        totalWeight: demoTotalWeight,
        isOverweight,
        overweightDetails: details,
        lastWeighingDate: new Date().toISOString()
      }));
      
      // Simular finalização da pesagem após um tempo
      setTimeout(() => {
        setIsWeighing(false);
        showAlert({
          type: 'success',
          message: t('weighing.weighingComplete'),
          duration: 3000
        });
      }, 3000);
    } else if (isConnected) {
      // Se conectado à balança, iniciar leituras de eixos
      showAlert({
        type: 'info',
        message: t('weighing.positionFirstAxle'),
        duration: 5000
      });
    }
  };
  
  // Calcular peso (para entrada manual)
  const calculateManualWeight = (axleWeights) => {
    const totalWeight = axleWeights.reduce((sum, weight) => sum + parseFloat(weight || 0), 0);
    const { isOverweight, details } = checkOverweight(totalWeight, axleWeights);
    
    setWeightData(prev => ({
      ...prev,
      axleWeights,
      totalWeight,
      isOverweight,
      overweightDetails: details,
      lastWeighingDate: new Date().toISOString()
    }));
    
    setCalculatedWeight(totalWeight);
    
    // Atualizar histórico de pesagem
    const newWeighingRecord = {
      date: new Date().toISOString(),
      vehicleType,
      totalWeight,
      axleWeights,
      isOverweight,
      overweightDetails: details
    };
    
    const updatedHistory = [newWeighingRecord, ...weightData.weighingHistory].slice(0, 50); // Limitar a 50 registros
    
    setWeightData(prev => ({
      ...prev,
      weighingHistory: updatedHistory
    }));
    
    // Salvar no armazenamento local
    try {
      localStorage.setItem('kingroad_weighing_history', JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Erro ao salvar histórico de pesagem:', error);
    }
    
    // Chamar callback quando a pesagem estiver completa
    onWeighingComplete({
      totalWeight,
      axleWeights,
      isOverweight,
      date: new Date().toISOString()
    });
  };
  
  // Realizar pré-pesagem para estimar carga
  const performPreWeighing = () => {
    // Algoritmo de pré-pesagem baseado em histórico e tipo de veículo
    // Aqui estamos apenas usando uma simulação simples
    const vehicleEmptyWeight = {
      [VEHICLE_TYPES.TRUCK_NORMAL]: 8.5,
      [VEHICLE_TYPES.TRUCK_ARTICULATED]: 15.3,
      [VEHICLE_TYPES.TRUCK_BITRAINR9]: 23.7,
      [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 19.8,
      [VEHICLE_TYPES.VAN]: 2.1
    }[vehicleType] || 10;
    
    // Simular estimativa de carga usando histórico de pesagem ou padrões da indústria
    let estimatedLoad = 0;
    
    if (weightData.weighingHistory.length > 0) {
      // Usar média do histórico para este tipo de veículo
      const relevantHistory = weightData.weighingHistory
        .filter(record => record.vehicleType === vehicleType)
        .slice(0, 5); // Últimos 5 registros
        
      if (relevantHistory.length > 0) {
        estimatedLoad = relevantHistory.reduce((sum, record) => 
          sum + (record.totalWeight - vehicleEmptyWeight), 0) / relevantHistory.length;
      } else {
        // Estimativa padrão baseada no tipo de veículo
        estimatedLoad = {
          [VEHICLE_TYPES.TRUCK_NORMAL]: 15,
          [VEHICLE_TYPES.TRUCK_ARTICULATED]: 25,
          [VEHICLE_TYPES.TRUCK_BITRAINR9]: 40,
          [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 30,
          [VEHICLE_TYPES.VAN]: 1
        }[vehicleType] || 15;
      }
    } else {
      // Estimativa padrão baseada no tipo de veículo
      estimatedLoad = {
        [VEHICLE_TYPES.TRUCK_NORMAL]: 15,
        [VEHICLE_TYPES.TRUCK_ARTICULATED]: 25,
        [VEHICLE_TYPES.TRUCK_BITRAINR9]: 40,
        [VEHICLE_TYPES.TRUCK_ROADTRAIN]: 30,
        [VEHICLE_TYPES.VAN]: 1
      }[vehicleType] || 15;
    }
    
    const estimatedTotal = vehicleEmptyWeight + estimatedLoad;
    const { isOverweight, details } = checkOverweight(estimatedTotal);
    
    setPreWeighingEstimate({
      vehicleEmptyWeight,
      estimatedLoad,
      estimatedTotal,
      isOverweight,
      overweightDetails: details
    });
    
    showAlert({
      type: isOverweight ? 'warning' : 'info',
      message: isOverweight 
        ? t('weighing.estimateOverweight', { weight: estimatedTotal.toFixed(1) }) 
        : t('weighing.estimateNormal', { weight: estimatedTotal.toFixed(1) }),
      duration: 5000
    });
  };
  
  // Resetar dados da pesagem
  const resetWeighingData = () => {
    setWeightData(prev => ({
      ...prev,
      currentWeight: 0,
      axleWeights: [],
      totalWeight: 0,
      isOverweight: false,
      overweightDetails: null
    }));
    
    setCalculatedWeight(null);
    setPreWeighingEstimate(null);
    setIsWeighing(false);
  };
  
  // Procurar dispositivos de balança disponíveis
  const scanForScales = async () => {
    if (!hasBluetoothScale) {
      setManualEntry(true);
      return;
    }
    
    try {
      // Verificar se o navegador suporta Bluetooth
      if (!navigator.bluetooth) {
        throw new Error(t('weighing.bluetoothNotSupported'));
      }
      
      showAlert({
        type: 'info',
        message: t('weighing.scanningForScales'),
        duration: 3000
      });
      
      // Procurar dispositivos Bluetooth
      const devices = await navigator.bluetooth.getDevices();
      
      // Filtrar dispositivos que parecem ser balanças
      const potentialScales = devices.filter(device => 
        device.name.toLowerCase().includes('scale') || 
        device.name.toLowerCase().includes('weight') ||
        device.name.toLowerCase().includes('balança') ||
        device.name.toLowerCase().includes('pesagem')
      );
      
      setScaleDevices(potentialScales);
      
      if (potentialScales.length === 0) {
        showAlert({
          type: 'warning',
          message: t('weighing.noScalesFound'),
          duration: 3000
        });
      } else {
        showAlert({
          type: 'success',
          message: t('weighing.scalesFound', { count: potentialScales.length }),
          duration: 3000
        });
      }
    } catch (error) {
      console.error('Erro ao procurar balanças:', error);
      
      showAlert({
        type: 'error',
        message: t('weighing.scanError', { error: error.message }),
        duration: 5000
      });
      
      // Fallback para entrada manual
      setManualEntry(true);
    }
  };
  
  // Componente de entrada manual de peso
  const ManualWeightEntry = () => {
    const [manualAxleWeights, setManualAxleWeights] = useState(Array(axleCount).fill(''));
    
    const handleAxleWeightChange = (index, value) => {
      const newAxleWeights = [...manualAxleWeights];
      newAxleWeights[index] = value;
      setManualAxleWeights(newAxleWeights);
    };
    
    const handleCalculate = () => {
      // Validar entradas
      if (manualAxleWeights.some(weight => weight === '')) {
        showAlert({
          type: 'warning',
          message: t('weighing.fillAllAxles'),
          duration: 3000
        });
        return;
      }
      
      // Converter para números
      const numericalWeights = manualAxleWeights.map(w => parseFloat(w));
      calculateManualWeight(numericalWeights);
    };
    
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-md">
        <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
          {t('weighing.manualWeightEntry')}
        </h3>
        
        <div className="space-y-4">
          {manualAxleWeights.map((weight, index) => (
            <div key={index} className="flex items-center space-x-3">
              <label className="w-24 text-gray-700 dark:text-gray-300">
                {t('weighing.axle')} {index + 1}:
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => handleAxleWeightChange(index, e.target.value)}
                className="flex-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder={t('weighing.weightInTons')}
                min="0"
                step="0.1"
              />
              <span className="text-gray-500 dark:text-gray-400">t</span>
            </div>
          ))}
          
          <PrimaryButton 
            onClick={handleCalculate}
            fullWidth
            icon="calculator"
          >
            {t('weighing.calculate')}
          </PrimaryButton>
        </div>
        
        {calculatedWeight !== null && (
          <div className="mt-5 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <h4 className="font-semibold text-gray-800 dark:text-white">
              {t('weighing.results')}
            </h4>
            
            <p className="mt-2 text-lg">
              <span className="text-gray-600 dark:text-gray-300">{t('weighing.totalWeight')}:</span>{' '}
              <span className="font-bold text-gray-800 dark:text-white">{calculatedWeight.toFixed(1)}t</span>
            </p>
            
            <p className={`mt-1 font-medium ${weightData.isOverweight ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
              {weightData.isOverweight 
                ? t('weighing.overweightAlert') 
                : t('weighing.withinLimits')}
            </p>
            
            {weightData.isOverweight && weightData.overweightDetails && (
              <div className="mt-3 text-red-600 dark:text-red-400">
                <p>{t('weighing.overBy', { weight: weightData.overweightDetails.totalOverage.toFixed(1) })}</p>
                
                {weightData.overweightDetails.axleOverages.length > 0 && (
                  <div className="mt-2">
                    <p>{t('weighing.axleOverages')}:</p>
                    <ul className="list-disc pl-5 mt-1">
                      {weightData.overweightDetails.axleOverages.map((overage, index) => (
                        <li key={index}>
                          {t('weighing.axleOverweight', {
                            axle: overage.axle,
                            weight: overage.weight.toFixed(1),
                            limit: overage.limit.toFixed(1),
                            overage: overage.overage.toFixed(1)
                          })}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };
  
  // Componente de lista de dispositivos de balança
  const ScaleDevicesList = () => (
    <div className="mt-4">
      <h3 className="text-lg font-bold mb-2 text-gray-800 dark:text-white">
        {t('weighing.availableScales')}
      </h3>
      
      {scaleDevices.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">
          {t('weighing.noScalesFound')}
        </p>
      ) : (
        <ul className="space-y-2">
          {scaleDevices.map((device, index) => (
            <li key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div>
                <p className="font-medium text-gray-800 dark:text-white">{device.name}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{device.id}</p>
              </div>
              <PrimaryButton 
                onClick={() => {
                  setSelectedScale(device);
                  connectToScale();
                }}
                size="sm"
              >
                {t('weighing.connect')}
              </PrimaryButton>
            </li>
          ))}
        </ul>
      )}
      
      <div className="mt-4 flex space-x-2">
        <PrimaryButton 
          onClick={scanForScales}
          icon="refresh"
        >
          {t('weighing.scanAgain')}
        </PrimaryButton>
        <SecondaryButton 
          onClick={() => setManualEntry(true)}
        >
          {t('weighing.enterManually')}
        </SecondaryButton>
      </div>
    </div>
  );
  
  // Componente de resultados da pesagem
  const WeighingResults = () => (
    <div className="mt-4 p-5 bg-white dark:bg-gray-800 rounded-lg shadow-md">
      <h3 className="text-lg font-bold mb-3 text-gray-800 dark:text-white">
        {t('weighing.weighingResults')}
      </h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{t('weighing.totalWeight')}</p>
          <p className="text-2xl font-bold text-gray-800 dark:text-white">
            {weightData.totalWeight.toFixed(1)}t
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{t('weighing.weightLimit')}</p>
          <p className="text-2xl font-bold text-gray-800 dark:text-white">
            {weightLimits.totalWeight[vehicleType].toFixed(1)}t
          </p>
        </div>
      </div>
      
      <div className="mb-5">
        <h4 className="font-semibold mb-2 text-gray-700 dark:text-gray-300">
          {t('weighing.axleWeights')}
        </h4>
        
        <div className="grid grid-cols-3 gap-2">
          {weightData.axleWeights.map((weight, index) => (
            <div 
              key={index} 
              className={`p-2 rounded text-center ${
                weight > weightLimits.singleAxle 
                  ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
            >
              <p className="text-xs">{t('weighing.axle')} {index + 1}</p>
              <p className="text-lg font-semibold">{weight.toFixed(1)}t</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className={`p-3 rounded-lg ${
        weightData.isOverweight 
          ? 'bg-red-50 dark:bg-red-900 border-l-4 border-red-500 text-red-700 dark:text-red-200' 
          : 'bg-green-50 dark:bg-green-900 border-l-4 border-green-500 text-green-700 dark:text-green-200'
      }`}>
        <p className="font-bold">
          {weightData.isOverweight 
            ? t('weighing.overweightAlert') 
            : t('weighing.withinLimits')}
        </p>
        
        {weightData.isOverweight && weightData.overweightDetails && (
          <div className="mt-2 text-sm">
            <p>{t('weighing.overBy', { weight: weightData.overweightDetails.totalOverage.toFixed(1) })}</p>
            
            {weightData.overweightDetails.axleOverages.length > 0 && (
              <div className="mt-1">
                <p>{t('weighing.axleProblems')}:</p>
                <ul className="list-disc pl-5 mt-1">
                  {weightData.overweightDetails.axleOverages.map((overage, index) => (
                    <li key={index}>
                      {t('weighing.axleOverweight', {
                        axle: overage.axle,
                        weight: overage.weight.toFixed(1),
                        limit: overage.limit.toFixed(1),
                        overage: overage.overage.toFixed(1)
                      })}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <p className="mt-2">
              {t('weighing.weightRedistributionAdvice')}
            </p>
          </div>
        )}
      </div>
      
      <div className="mt-4 flex space-x-2">
        <PrimaryButton 
          onClick={resetWeighingData}
          icon="refresh"
        >
          {t('weighing.newWeighing')}
        </PrimaryButton>
        
        <SecondaryButton 
          onClick={() => {
            // Compartilhar ou exportar resultados
            const weighingData = {
              date: new Date().toISOString(),
              vehicle: vehicleType,
              total: weightData.totalWeight,
              axles: weightData.axleWeights,
              isCompliant: !weightData.isOverweight,
              country: countryCode
            };
            
            // Criar arquivo para download
            const dataStr = JSON.stringify(weighingData, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
            
            const exportName = `weight-report-${new Date().toISOString().slice(0, 10)}.json`;
            
            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', exportName);
            linkElement.click();
            
            showAlert({
              type: 'success',
              message: t('weighing.reportExported'),
              duration: 3000
            });
          }}
          icon="download"
        >
          {t('weighing.exportReport')}
        </SecondaryButton>
      </div>
    </div>
  );
  
  // Histórico de pesagens
  const WeighingHistory = () => (
    <div className="mt-6 p-5 bg-white dark:bg-gray-800 rounded-lg shadow-md">
      <h3 className="text-lg font-bold mb-3 text-gray-800 dark:text-white">
        {t('weighing.recentWeighings')}
      </h3>
      
      {weightData.weighingHistory.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">
          {t('weighing.noWeighingHistory')}
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {t('weighing.date')}
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {t('weighing.vehicleType')}
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {t('weighing.totalWeight')}
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  {t('weighing.status')}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {weightData.weighingHistory.slice(0, 5).map((record, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {new Date(record.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {t(`vehicleTypes.${record.vehicleType}`)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {record.totalWeight.toFixed(1)}t
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      record.isOverweight
                        ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    }`}>
                      {record.isOverweight
                        ? t('weighing.overweight')
                        : t('weighing.compliant')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
  
  // Componente principal
  return (
    <div className="max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
        {t('weighing.systemTitle')}
      </h2>
      
      {/* Informações do veículo */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-md mb-6">
        <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
          {t('weighing.vehicleInformation')}
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('weighing.vehicleType')}
            </label>
            <p className="text-lg font-medium text-gray-900 dark:text-white">
              {t(`vehicleTypes.${vehicleType}`)}
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('weighing.axleCount')}
            </label>
            <p className="text-lg font-medium text-gray-900 dark:text-white">
              {axleCount}
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('weighing.weightLimit')}
            </label>
            <p className="text-lg font-medium text-gray-900 dark:text-white">
              {weightLimits.totalWeight[vehicleType].toFixed(1)}t
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('weighing.country')}
            </label>
            <p className="text-lg font-medium text-gray-900 dark:text-white">
              {countryCode}
            </p>
          </div>
        </div>
        
        <div className="mt-4">
          <PrimaryButton
            onClick={performPreWeighing}
            icon="calculator"
          >
            {t('weighing.estimateWeight')}
          </PrimaryButton>
          
          {preWeighingEstimate && (
            <div className={`mt-4 p-3 rounded-lg ${
              preWeighingEstimate.isOverweight
                ? 'bg-red-50 dark:bg-red-900 border-l-4 border-red-500 text-red-700 dark:text-red-200'
                : 'bg-blue-50 dark:bg-blue-900 border-l-4 border-blue-500 text-blue-700 dark:text-blue-200'
            }`}>
              <h4 className="font-bold">{t('weighing.weightEstimate')}</h4>
              
              <div className="grid grid-cols-2 gap-2 mt-2">
                <div>
                  <p className="text-sm font-medium">{t('weighing.emptyWeight')}:</p>
                  <p>{preWeighingEstimate.vehicleEmptyWeight.toFixed(1)}t</p>
                </div>
                <div>
                  <p className="text-sm font-medium">{t('weighing.estimatedLoad')}:</p>
                  <p>{preWeighingEstimate.estimatedLoad.toFixed(1)}t</p>
                </div>
                <div>
                  <p className="text-sm font-medium">{t('weighing.estimatedTotal')}:</p>
                  <p className="font-bold">{preWeighingEstimate.estimatedTotal.toFixed(1)}t</p>
                </div>
                <div>
                  <p className="text-sm font-medium">{t('weighing.weightLimit')}:</p>
                  <p>{weightLimits.totalWeight[vehicleType].toFixed(1)}t</p>
                </div>
              </div>
              
              {preWeighingEstimate.isOverweight && (
                <p className="mt-2 text-sm font-medium">
                  {t('weighing.estimatedOverBy', {
                    weight: (preWeighingEstimate.estimatedTotal - weightLimits.totalWeight[vehicleType]).toFixed(1)
                  })}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Ações de pesagem */}
      <div className="mb-6">
        {!isConnected && !manualEntry && !isWeighing ? (
          <>
            <div className="flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-3">
              <PrimaryButton 
                onClick={connectToScale}
                icon="bluetooth"
                fullWidth
              >
                {t('weighing.connectToScale')}
              </PrimaryButton>
              
              <SecondaryButton 
                onClick={() => setManualEntry(true)}
                icon="edit"
                fullWidth
              >
                {t('weighing.manualEntry')}
              </SecondaryButton>
            </div>
            
            {hasBluetoothScale && scaleDevices.length > 0 && (
              <ScaleDevicesList />
            )}
          </>
        ) : (
          <>
            {isConnected && !isWeighing && (
              <div className="bg-green-50 dark:bg-green-900 p-4 rounded-lg mb-4 flex justify-between items-center">
                <div>
                  <p className="text-green-800 dark:text-green-200 font-medium">
                    {t('weighing.connectedTo', { device: selectedScale?.name })}
                  </p>
                  <p className="text-sm text-green-600 dark:text-green-300">
                    {t('weighing.readyToWeigh')}
                  </p>
                </div>
                <div>
                  <SecondaryButton 
                    onClick={disconnectFromScale}
                    size="sm"
                  >
                    {t('weighing.disconnect')}
                  </SecondaryButton>
                </div>
              </div>
            )}
            
            {!isWeighing ? (
              <>
                {manualEntry ? (
                  <ManualWeightEntry />
                ) : (
                  <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-md">
                    <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
                      {t('weighing.startWeighing')}
                    </h3>
                    
                    <p className="mb-4 text-gray-700 dark:text-gray-300">
                      {t('weighing.instructions')}
                    </p>
                    
                    <PrimaryButton 
                      onClick={startWeighing}
                      icon="play"
                      fullWidth
                    >
                      {t('weighing.startProcess')}
                    </PrimaryButton>
                  </div>
                )}
              </>
            ) : (
              // Processo de pesagem em andamento
              <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-md">
                <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
                  {t('weighing.weighingInProgress')}
                </h3>
                
                <div className="flex justify-center mb-4">
                  <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
                </div>
                
                <p className="text-center text-gray-700 dark:text-gray-300">
                  {t('weighing.weighingProgress')}
                </p>
              </div>
            )}
          </>
        )}
      </div>
      
      {/* Resultados e histórico */}
      {weightData.totalWeight > 0 && (
        <WeighingResults />
      )}
      
      {weightData.weighingHistory.length > 0 && (
        <WeighingHistory />
      )}
    </div>
  );
};

export default WeighingSystem;