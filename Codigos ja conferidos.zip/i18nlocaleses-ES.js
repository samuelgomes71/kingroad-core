/**
 * i18n/locales/es-ES.js
 * 
 * Recursos de traducción para Español (España).
 * Este es uno de los idiomas principales de la aplicación con traducciones completas.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

const esES = {
  translation: {
    // Información de la aplicación
    app: {
      name: 'KingRoad',
      welcome: 'Bienvenido a KingRoad',
      tagline: 'Tu asistente personal de viaje',
      version: 'Versión {{version}}',
      copyright: '© 2025 KingRoad. Todos los derechos reservados.'
    },
    
    // Autenticación
    auth: {
      login: 'Iniciar sesión',
      logout: 'Cerrar sesión',
      register: 'Registrarse',
      forgotPassword: '¿Olvidaste tu contraseña?',
      resetPassword: 'Restablecer contraseña',
      emailPlaceholder: 'Correo electrónico',
      passwordPlaceholder: 'Contraseña',
      confirmPasswordPlaceholder: 'Confirmar contraseña',
      loginSuccess: '¡Inicio de sesión exitoso!',
      loginError: 'Error al iniciar sesión. Por favor, verifica tus credenciales.',
      logoutSuccess: 'Has cerrado sesión.',
      passwordResetSent: 'Se han enviado instrucciones para restablecer tu contraseña.',
      passwordsDontMatch: 'Las contraseñas no coinciden.',
      passwordRequirements: 'La contraseña debe tener al menos 8 caracteres, incluyendo mayúsculas, minúsculas y números.'
    },
    
    // Navegación
    nav: {
      home: 'Inicio',
      profile: 'Perfil',
      settings: 'Configuración',
      trips: 'Viajes',
      explore: 'Explorar',
      help: 'Ayuda',
      about: 'Acerca de'
    },
    
    // Perfil de usuario
    profile: {
      title: 'Mi Perfil',
      edit: 'Editar Perfil',
      save: 'Guardar Cambios',
      cancel: 'Cancelar',
      name: 'Nombre',
      email: 'Correo electrónico',
      phone: 'Teléfono',
      address: 'Dirección',
      preferences: 'Preferencias',
      changePassword: 'Cambiar Contraseña',
      language: 'Idioma',
      theme: 'Tema',
      notifications: 'Notificaciones',
      deleteAccount: 'Eliminar Cuenta',
      deleteAccountConfirm: '¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.',
      profileUpdated: '¡Perfil actualizado con éxito!',
      profileUpdateError: 'Error al actualizar el perfil.'
    },
    
    // Configuración
    settings: {
      title: 'Configuración',
      general: 'General',
      account: 'Cuenta',
      privacy: 'Privacidad',
      notifications: 'Notificaciones',
      appearance: 'Apariencia',
      language: 'Idioma',
      region: 'Región',
      theme: {
        title: 'Tema',
        light: 'Claro',
        dark: 'Oscuro',
        system: 'Sistema'
      },
      dataCurrency: 'Moneda',
      dataUsage: 'Uso de datos',
      wifiOnly: 'Solo Wi-Fi',
      locationServices: 'Servicios de ubicación',
      resetSettings: 'Restablecer configuración',
      resetSettingsConfirm: '¿Estás seguro de que quieres restablecer toda la configuración?',
      settingsSaved: '¡Configuración guardada!',
      settingsError: 'Error al guardar la configuración.'
    },
    
    // Componentes comunes
    common: {
      ok: 'Aceptar',
      cancel: 'Cancelar',
      save: 'Guardar',
      delete: 'Eliminar',
      edit: 'Editar',
      add: 'Añadir',
      remove: 'Eliminar',
      search: 'Buscar',
      filter: 'Filtrar',
      sort: 'Ordenar',
      loading: 'Cargando...',
      retry: 'Reintentar',
      error: 'Error',
      success: 'Éxito',
      warning: 'Advertencia',
      info: 'Información',
      yes: 'Sí',
      no: 'No',
      back: 'Atrás',
      next: 'Siguiente',
      finish: 'Finalizar',
      continue: 'Continuar',
      skip: 'Omitir',
      done: 'Hecho',
      select: 'Seleccionar',
      today: 'Hoy',
      yesterday: 'Ayer',
      tomorrow: 'Mañana',
      confirm: 'Confirmar',
      apply: 'Aplicar',
      reset: 'Restablecer',
      close: 'Cerrar',
      open: 'Abrir',
      show: 'Mostrar',
      hide: 'Ocultar',
      all: 'Todo',
      none: 'Ninguno',
      required: 'Obligatorio',
      optional: 'Opcional',
      more: 'Más',
      less: 'Menos',
      details: 'Detalles',
      upload: 'Subir',
      download: 'Descargar',
      noResults: 'No se encontraron resultados',
      noData: 'No hay datos disponibles',
      emptyState: 'No hay nada aquí todavía',
      offline: 'Estás sin conexión',
      online: 'Estás en línea',
      day: 'Día',
      week: 'Semana',
      month: 'Mes',
      year: 'Año'
    },
    
    // Mensajes de error
    errors: {
      generic: 'Ha ocurrido un error. Por favor, inténtalo de nuevo.',
      connection: 'Error de conexión. Por favor, comprueba tu internet.',
      timeout: 'La solicitud ha caducado. Por favor, inténtalo de nuevo.',
      unauthorized: 'No autorizado. Por favor, inicia sesión de nuevo.',
      notFound: 'Recurso no encontrado.',
      serverError: 'Error del servidor. Por favor, inténtalo más tarde.',
      validation: 'Por favor, comprueba tus datos.',
      requiredField: 'Campo obligatorio',
      invalidEmail: 'Correo electrónico inválido',
      weakPassword: 'La contraseña es demasiado débil',
      accountExists: 'Esta cuenta ya existe',
      uploadFailed: 'Falló la subida del archivo',
      downloadFailed: 'Falló la descarga del archivo',
      locationPermissionDenied: 'Permiso de ubicación denegado',
      cameraPermissionDenied: 'Permiso de cámara denegado',
      microphonePermissionDenied: 'Permiso de micrófono denegado',
      storagePermissionDenied: 'Permiso de almacenamiento denegado',
      networkError: 'Error de red',
      sessionExpired: 'Sesión expirada. Por favor, inicia sesión de nuevo.'
    },
    
    // Metadata del idioma
    metadata: {
      name: 'Español (España)',
      nameEnglish: 'Spanish (Spain)',
      isRTL: false,
      momentLocale: 'es',
      dateFormat: {
        short: 'DD/MM/YYYY',
        medium: 'D [de] MMM [de] YYYY',
        long: 'D [de] MMMM [de] YYYY',
        full: 'dddd, D [de] MMMM [de] YYYY'
      },
      timeFormat: {
        short: 'H:mm',
        medium: 'H:mm:ss',
        long: 'H:mm:ss z',
        full: 'H:mm:ss zzzz'
      },
      currency: {
        code: 'EUR',
        symbol: '€',
        format: '{amount} {symbol}',
        decimal: ',',
        thousand: '.'
      },
      country: 'ES',
      numberFormat: {
        decimal: ',',
        thousand: '.',
        precision: 2
      },
      units: {
        system: 'metric',
        temperature: 'celsius',
        distance: {
          short: 'm',
          long: 'metro',
          plural: 'metros'
        },
        speed: 'km/h',
        weight: 'kg'
      }
    }
  }
};

export default esES;