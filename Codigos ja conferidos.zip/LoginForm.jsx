// web/src/components/auth/LoginForm.jsx

import React, { useState } from 'react';
import { useTranslation } from '../../hooks/useTranslation';
import { useAuth } from '../../contexts/AuthContext';
import { useNotification } from '../../hooks/useNotification';
import { useDeviceInfo } from '../../hooks/useDeviceInfo';
import { LogoIcon, EmailIcon, LockIcon } from '../icons/AuthIcons';

/**
 * Formulário de login para o KingRoad
 * Inclui verificação de dispositivo e status do período de avaliação
 */
const LoginForm = ({ onSuccess, onRegister }) => {
  const { t } = useTranslation('auth');
  const { login } = useAuth();
  const { showSuccess, showError } = useNotification();
  const { getDeviceInfo } = useDeviceInfo();
  
  // Estados do formulário
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  
  // Valida o formulário
  const validateForm = () => {
    const newErrors = {};
    
    if (!email.trim()) newErrors.email = t('requiredField');
    if (!password) newErrors.password = t('requiredField');
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Manipula o envio do formulário
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      // Obtém informações do dispositivo
      const deviceInfo = await getDeviceInfo();
      
      // Tenta fazer login
      const result = await login(email, password, deviceInfo);
      
      // Processa o resultado
      if (result.success) {
        showSuccess(t('loginSuccess'));
        onSuccess();
      } else {
        // Exibe mensagens de erro específicas
        if (result.invalidCredentials) {
          showError(t('invalidCredentials'));
        } else if (result.deviceNotAuthorized) {
          showError(t('deviceNotAuthorized'));
        } else if (result