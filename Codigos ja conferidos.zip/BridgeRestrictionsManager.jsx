import React, { useState } from 'react';
import { Anchor, X, Info, Check, AlertTriangle, Camera } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const BridgeRestrictionsManager = () => {
  // Estados
  const [bridgeExceptions, setBridgeExceptions] = useState([]);
  const [showBridgesMenu, setShowBridgesMenu] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedBridge, setSelectedBridge] = useState(null);

  // Estrutura de dados para exceção de ponte
  const BridgeExceptionData = {
    id: '',
    location: {
      name: '',
      coordinates: '',
      nearestTown: '',
      accessRoute: ''
    },
    restrictions: {
      systemWeight: '',
      realWeight: '',
      width: '',
      height: ''
    },
    verification: {
      verifiedBy: [],
      lastVerified: null,
      photos: [],
      proofType: ''
    },
    details: {
      bridgeType: '',
      condition: '',
      notes: '',
      alternativeRoutes: []
    },
    dateAdded: null,
    reportStatus: 'pending',
    communityNotes: []
  };

  // Componente do menu principal
  const BridgesMenu = () => (
    <div className="absolute right-0 top-0 h-screen w-80 bg-gray-900 p-4 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold text-white">Pontes Verificadas</h2>
          <p className="text-sm text-gray-400">Restrições atualizadas pela comunidade</p>
        </div>
        <button onClick={() => setShowBridgesMenu(false)} className="text-gray-400">
          <X size={20} />
        </button>
      </div>

      <div className="space-y-4 overflow-y-auto max-h-[calc(100vh-100px)]">
        {bridgeExceptions.map((bridge) => (
          <div key={bridge.id} className="bg-gray-800 p-4 rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <Anchor className="text-blue-500" size={16} />
                  <h3 className="text-white font-medium">{bridge.location.name}</h3>
                </div>
                
                <div className="mt-2 text-sm">
                  <p className="text-gray-300">
                    Próximo a: {bridge.location.nearestTown}
                  </p>
                  
                  <div className="mt-2 grid grid-cols-2 gap-2 bg-gray-700 p-2 rounded">
                    <div>
                      <p className="text-red-400">Sistema: {bridge.restrictions.systemWeight}</p>
                      <p className="text-gray-400 text-xs">Restrição oficial</p>
                    </div>
                    <div>
                      <p className="text-green-400">Real: {bridge.restrictions.realWeight}</p>
                      <p className="text-gray-400 text-xs">Verificado</p>
                    </div>
                  </div>

                  {bridge.details.notes && (
                    <div className="mt-2 bg-gray-700 p-2 rounded">
                      <p className="text-gray-300 text-sm">{bridge.details.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              <button 
                onClick={() => removeBridgeException(bridge.id)}
                className="text-gray-400 hover:text-gray-300 ml-2"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Diálogo de adição de ponte
  const AddBridgeDialog = () => (
    <Alert className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-gray-900 border-blue-600">
      <Anchor className="text-blue-600" />
      <AlertTitle className="text-white">Adicionar Ponte Verificada</AlertTitle>
      <AlertDescription>
        <div className="space-y-4 mt-4">
          <div>
            <label className="text-gray-300 text-sm">Nome/Localização da Ponte</label>
            <input 
              type="text"
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              placeholder="Ex: Ponte do Riacho Santo António"
              value={selectedBridge?.location.name || ''}
              onChange={(e) => setSelectedBridge({
                ...selectedBridge,
                location: {...selectedBridge?.location, name: e.target.value}
              })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-300 text-sm">Peso Sistema</label>
              <input 
                type="text"
                className="w-full mt-1 bg-gray-800 text-white rounded p-2"
                placeholder="Ex: 20T"
                value={selectedBridge?.restrictions?.systemWeight || ''}
                onChange={(e) => setSelectedBridge({
                  ...selectedBridge,
                  restrictions: {...selectedBridge?.restrictions, systemWeight: e.target.value}
                })}
              />
            </div>
            <div>
              <label className="text-gray-300 text-sm">Peso Real</label>
              <input 
                type="text"
                className="w-full mt-1 bg-gray-800 text-white rounded p-2"
                placeholder="Ex: 40T"
                value={selectedBridge?.restrictions?.realWeight || ''}
                onChange={(e) => setSelectedBridge({
                  ...selectedBridge,
                  restrictions: {...selectedBridge?.restrictions, realWeight: e.target.value}
                })}
              />
            </div>
          </div>

          <div>
            <label className="text-gray-300 text-sm">Observações</label>
            <textarea 
              className="w-full mt-1 bg-gray-800 text-white rounded p-2"
              rows="3"
              placeholder="Descreva detalhes importantes..."
              value={selectedBridge?.details?.notes || ''}
              onChange={(e) => setSelectedBridge({
                ...selectedBridge,
                details: {...selectedBridge?.details, notes: e.target.value}
              })}
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <button 
            onClick={() => setShowAddDialog(false)}
            className="px-4 py-2 bg-gray-700 rounded text-white"
          >
            Cancelar
          </button>
          <button 
            onClick={confirmAddBridge}
            className="px-4 py-2 bg-blue-600 rounded text-white flex items-center space-x-2"
          >
            <Check size={16} />
            <span>Confirmar</span>
          </button>
        </div>
      </AlertDescription>
    </Alert>
  );

  // Funções de gerenciamento
  const confirmAddBridge = () => {
    if (!selectedBridge?.location?.name) return;

    const newBridge = {
      ...BridgeExceptionData,
      ...selectedBridge,
      id: Date.now().toString(),
      dateAdded: new Date(),
      verification: {
        verifiedBy: [1],
        lastVerified: new Date()
      }
    };

    setBridgeExceptions([...bridgeExceptions, newBridge]);
    setShowAddDialog(false);
    setSelectedBridge(null);
  };

  const removeBridgeException = (bridgeId) => {
    setBridgeExceptions(bridgeExceptions.filter(bridge => bridge.id !== bridgeId));
  };

  // Botão de adicionar
  const AddBridgeButton = () => (
    <button 
      onClick={() => {
        setSelectedBridge({...BridgeExceptionData});
        setShowAddDialog(true);
      }}
      className="fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
    >
      <Info size={16} />
      <span>Adicionar Ponte</span>
    </button>
  );

  // Botão do menu
  const MenuButton = () => (
    <button 
      onClick={() => setShowBridgesMenu(true)}
      className="fixed bottom-68 right-4 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center shadow-lg"
    >
      <Anchor className="text-white" />
    </button>
  );

  return (
    <div className="relative">
      {/* Menu principal */}
      {showBridgesMenu && <BridgesMenu />}
      
      {/* Diálogo de adição */}
      {showAddDialog && <AddBridgeDialog />}
      
      {/* Botões */}
      <MenuButton />
      {showBridgesMenu && <AddBridgeButton />}
    </div>
  );
};

export default BridgeRestrictionsManager;