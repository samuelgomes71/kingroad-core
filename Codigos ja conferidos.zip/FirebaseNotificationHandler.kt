package com.kingroad.cache

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.TaskStackBuilder
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.kingroad.database.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.*
import java.util.concurrent.atomic.AtomicInteger

/**
 * Integra com o Firebase Cloud Messaging (FCM) para receber alertas em tempo real e 
 * notificações entre motoristas.
 */
class FirebaseNotificationHandler(
    private val context: Context,
    private val alertDao: AlertDao,
    private val poiDao: POIDao,
    private val userDao: UserDao,
    private val messageDao: MessageDao? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "FirebaseNotificationHandler"
        
        // IDs dos canais de notificação
        private const val CHANNEL_ALERTS = "channel_alerts"
        private const val CHANNEL_POIS = "channel_pois"
        private const val CHANNEL_MESSAGES = "channel_messages"
        private const val CHANNEL_GENERAL = "channel_general"
        private const val CHANNEL_EMERGENCY = "channel_emergency"
        
        // Tipos de notificação
        enum class NotificationType(val id: String) {
            ALERT("alert"),
            POI("poi"),
            MESSAGE("message"),
            SYSTEM("system"),
            EMERGENCY("emergency"),
            LOCATION_SHARE("location_share"),
            FRIEND_REQUEST("friend_request"),
            POI_FEEDBACK("poi_feedback"),
            ROUTE_SHARE("route_share"),
            CUSTOM("custom")
        }
        
        // ID de notificação inicial, incrementado para cada notificação
        private val notificationId = AtomicInteger(100)
        
        // Mapa de tops de mensagem para tipos de notificação
        private val MESSAGE_TYPE_MAP = mapOf(
            "alert" to NotificationType.ALERT,
            "poi" to NotificationType.POI,
            "message" to NotificationType.MESSAGE,
            "system" to NotificationType.SYSTEM,
            "emergency" to NotificationType.EMERGENCY,
            "location_share" to NotificationType.LOCATION_SHARE,
            "friend_request" to NotificationType.FRIEND_REQUEST,
            "poi_feedback" to NotificationType.POI_FEEDBACK,
            "route_share" to NotificationType.ROUTE_SHARE,
            "custom" to NotificationType.CUSTOM
        )
    }

    // Estado da conexão com o FCM
    private val _firebaseStatus = MutableStateFlow<FirebaseStatus>(FirebaseStatus.Initializing)
    val firebaseStatus: StateFlow<FirebaseStatus> = _firebaseStatus.asStateFlow()
    
    // Token do FCM
    private val _fcmToken = MutableLiveData<String?>(null)
    val fcmToken: LiveData<String?> = _fcmToken
    
    // Histórico de notificações recebidas
    private val _notificationHistory = MutableLiveData<List<NotificationHistoryItem>>(emptyList())
    val notificationHistory: LiveData<List<NotificationHistoryItem>> = _notificationHistory
    
    // Tópicos inscritos
    private val subscribedTopics = mutableSetOf<String>()
    
    // Sons de notificação personalizados
    private var customSounds = mutableMapOf<NotificationType, Uri>()

    init {
        // Inicializa canais de notificação
        createNotificationChannels()
        
        // Inicializa conexão com Firebase
        initializeFirebase()
    }

    /**
     * Configura os canais de notificação (somente para Android 8.0+)
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Canal para alertas (alta prioridade)
            val alertChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Alertas de Segurança",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas de segurança e emergências na rota"
                enableLights(true)
                lightColor = Color.RED
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            
            // Canal para POIs (prioridade média)
            val poiChannel = NotificationChannel(
                CHANNEL_POIS,
                "Pontos de Interesse",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Avisos sobre pontos de interesse próximos"
                enableLights(true)
                lightColor = Color.BLUE
            }
            
            // Canal para mensagens (prioridade média)
            val messageChannel = NotificationChannel(
                CHANNEL_MESSAGES,
                "Mensagens de Motoristas",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Mensagens de outros motoristas"
                enableLights(true)
                lightColor = Color.GREEN
            }
            
            // Canal para notificações gerais (prioridade baixa)
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "Notificações Gerais",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificações gerais do sistema"
            }
            
            // Canal para emergências (prioridade máxima)
            val emergencyChannel = NotificationChannel(
                CHANNEL_EMERGENCY,
                "Emergências",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas de emergência críticos"
                enableLights(true)
                lightColor = Color.RED
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setBypassDnd(true) // Bypassa o modo Não Perturbe
            }
            
            // Registra todos os canais
            notificationManager.createNotificationChannels(
                listOf(alertChannel, poiChannel, messageChannel, generalChannel, emergencyChannel)
            )
        }
    }
    
    /**
     * Inicializa a conexão com o Firebase
     */
    private fun initializeFirebase() {
        scope.launch {
            try {
                _firebaseStatus.value = FirebaseStatus.Connecting
                
                // Obtém o token do FCM
                val token = getFirebaseToken()
                _fcmToken.postValue(token)
                
                // Se obteve token com sucesso, considera conectado
                if (token != null) {
                    _firebaseStatus.value = FirebaseStatus.Connected(token)
                    
                    // Inscreve nos tópicos padrão
                    subscribeToDefaultTopics()
                } else {
                    _firebaseStatus.value = FirebaseStatus.Error("Não foi possível obter o token FCM")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao inicializar Firebase: ${e.message}", e)
                _firebaseStatus.value = FirebaseStatus.Error(e.message ?: "Erro desconhecido")
            }
        }
    }
    
    /**
     * Obtém o token do FCM de forma assíncrona
     */
    private suspend fun getFirebaseToken(): String? = suspendCancellableCoroutine { continuation ->
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    Log.d(TAG, "Token FCM: $token")
                    continuation.resume(token, null)
                } else {
                    Log.e(TAG, "Erro ao obter token FCM: ${task.exception?.message}")
                    continuation.resume(null, null)
                }
            }
    }
    
    /**
     * Inscreve o dispositivo nos tópicos padrão
     */
    private fun subscribeToDefaultTopics() {
        subscribeToTopic("alerts") // Todos os alertas
        subscribeToTopic("system") // Mensagens do sistema
        
        // Inscreve em tópicos baseados na localização do usuário
        scope.launch {
            try {
                val userLocation = userDao.getUserLocation()
                if (userLocation != null) {
                    // Obtém a região aproximada (estado/província)
                    val region = getRegionFromCoordinates(userLocation.latitude, userLocation.longitude)
                    if (region != null) {
                        subscribeToTopic("region_$region")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao inscrever em tópicos de região: ${e.message}", e)
            }
        }
    }
    
    /**
     * Inscreve o dispositivo em um tópico específico
     * 
     * @param topic Nome do tópico
     * @return true se a inscrição foi iniciada com sucesso
     */
    fun subscribeToTopic(topic: String): Boolean {
        return try {
            FirebaseMessaging.getInstance().subscribeToTopic(topic)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "Inscrito no tópico: $topic")
                        subscribedTopics.add(topic)
                    } else {
                        Log.e(TAG, "Erro ao inscrever no tópico $topic: ${task.exception?.message}")
                    }
                }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao inscrever no tópico $topic: ${e.message}", e)
            false
        }
    }
    
    /**
     * Cancela a inscrição do dispositivo em um tópico específico
     * 
     * @param topic Nome do tópico
     * @return true se o cancelamento foi iniciado com sucesso
     */
    fun unsubscribeFromTopic(topic: String): Boolean {
        return try {
            FirebaseMessaging.getInstance().unsubscribeFromTopic(topic)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "Cancelada inscrição no tópico: $topic")
                        subscribedTopics.remove(topic)
                    } else {
                        Log.e(TAG, "Erro ao cancelar inscrição no tópico $topic: ${task.exception?.message}")
                    }
                }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao cancelar inscrição no tópico $topic: ${e.message}", e)
            false
        }
    }
    
    /**
     * Define um som personalizado para um tipo específico de notificação
     * 
     * @param type Tipo de notificação
     * @param soundUri URI do som
     */
    fun setCustomSound(type: NotificationType, soundUri: Uri) {
        customSounds[type] = soundUri
        
        // Atualiza o canal de notificação se estiver no Android 8.0+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            val channelId = when (type) {
                NotificationType.ALERT -> CHANNEL_ALERTS
                NotificationType.POI -> CHANNEL_POIS
                NotificationType.MESSAGE -> CHANNEL_MESSAGES
                NotificationType.EMERGENCY -> CHANNEL_EMERGENCY
                else -> CHANNEL_GENERAL
            }
            
            val channel = notificationManager.getNotificationChannel(channelId)
            channel?.setSound(
                soundUri,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            
            if (channel != null) {
                notificationManager.createNotificationChannel(channel)
            }
        }
    }
    
    /**
     * Processa uma mensagem recebida do FCM
     * Esta função é chamada pelo FirebaseMessagingService
     * 
     * @param remoteMessage Mensagem recebida do FCM
     */
    fun handleRemoteMessage(remoteMessage: RemoteMessage) {
        // Extrai dados da mensagem
        val messageData = remoteMessage.data
        if (messageData.isEmpty()) {
            Log.w(TAG, "Mensagem FCM recebida sem dados")
            return
        }
        
        // Determina o tipo de notificação
        val messageType = messageData["type"] ?: "custom"
        val notificationType = MESSAGE_TYPE_MAP[messageType] ?: NotificationType.CUSTOM
        
        // Cria um item de histórico para esta notificação
        val historyItem = NotificationHistoryItem(
            id = UUID.randomUUID().toString(),
            type = notificationType.id,
            title = remoteMessage.notification?.title ?: messageData["title"] ?: "Nova notificação",
            message = remoteMessage.notification?.body ?: messageData["message"] ?: "",
            timestamp = System.currentTimeMillis(),
            data = JSONObject(messageData as Map<*, *>).toString()
        )
        
        // Adiciona ao histórico
        addToNotificationHistory(historyItem)
        
        // Processa com base no tipo
        scope.launch {
            processNotificationByType(notificationType, messageData, historyItem)
        }
    }
    
    /**
     * Processa a notificação com base no seu tipo
     */
    private suspend fun processNotificationByType(
        type: NotificationType,
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        when (type) {
            NotificationType.ALERT -> processAlertNotification(data, historyItem)
            NotificationType.POI -> processPoiNotification(data, historyItem)
            NotificationType.MESSAGE -> processMessageNotification(data, historyItem)
            NotificationType.EMERGENCY -> processEmergencyNotification(data, historyItem)
            NotificationType.LOCATION_SHARE -> processLocationShareNotification(data, historyItem)
            else -> processGenericNotification(data, historyItem)
        }
    }
    
    /**
     * Processa uma notificação de alerta
     */
    private suspend fun processAlertNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        try {
            // Extrai dados do alerta
            val alertId = data["alertId"] ?: UUID.randomUUID().toString()
            val alertType = data["alertType"] ?: "unknown"
            val title = data["title"] ?: "Alerta de segurança"
            val message = data["message"] ?: "Novo alerta na sua rota"
            val latitude = data["latitude"]?.toDoubleOrNull()
            val longitude = data["longitude"]?.toDoubleOrNull()
            val severity = data["severity"]?.toIntOrNull() ?: 3 // 1-5, default médio
            
            // Verifica se é necessário salvar o alerta no banco
            val shouldSaveAlert = data["saveToLocal"]?.toBoolean() ?: true
            
            if (shouldSaveAlert && latitude != null && longitude != null) {
                // Cria objeto de alerta
                val alert = Alert(
                    id = alertId,
                    type = alertType,
                    latitude = latitude,
                    longitude = longitude,
                    description = message,
                    createdAt = System.currentTimeMillis(),
                    expiresAt = data["expiresAt"]?.toLongOrNull(),
                    severity = severity,
                    direction = data["direction"]?.toIntOrNull(),
                    createdBy = data["createdBy"],
                    metadata = data["metadata"],
                    synced = true, // Já vem do servidor, então já está sincronizado
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = alertId
                )
                
                // Salva no banco de dados
                alertDao.insert(alert)
            }
            
            // Exibe a notificação
            showNotification(
                title = title,
                message = message,
                type = NotificationType.ALERT,
                data = data,
                historyItem = historyItem
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar notificação de alerta: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma notificação de POI
     */
    private suspend fun processPoiNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        try {
            // Extrai dados do POI
            val poiId = data["poiId"] ?: UUID.randomUUID().toString()
            val poiType = data["poiType"] ?: "unknown"
            val title = data["title"] ?: "Ponto de interesse"
            val message = data["message"] ?: "Novo ponto de interesse próximo"
            val latitude = data["latitude"]?.toDoubleOrNull()
            val longitude = data["longitude"]?.toDoubleOrNull()
            
            // Verifica se é necessário salvar o POI no banco
            val shouldSavePoi = data["saveToLocal"]?.toBoolean() ?: true
            
            if (shouldSavePoi && latitude != null && longitude != null) {
                // Cria objeto de POI
                val poi = POI(
                    id = poiId,
                    name = title,
                    type = poiType,
                    latitude = latitude,
                    longitude = longitude,
                    description = message,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    createdBy = data["createdBy"],
                    isVerified = data["isVerified"]?.toBoolean() ?: false,
                    metadata = data["metadata"],
                    synced = true, // Já vem do servidor, então já está sincronizado
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = poiId
                )
                
                // Salva no banco de dados
                poiDao.insert(poi)
            }
            
            // Exibe a notificação
            showNotification(
                title = title,
                message = message,
                type = NotificationType.POI,
                data = data,
                historyItem = historyItem
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar notificação de POI: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma notificação de mensagem
     */
    private suspend fun processMessageNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        try {
            // Extrai dados da mensagem
            val messageId = data["messageId"] ?: UUID.randomUUID().toString()
            val senderId = data["senderId"] ?: "unknown"
            val senderName = data["senderName"] ?: "Motorista"
            val title = data["title"] ?: "Nova mensagem de $senderName"
            val message = data["message"] ?: "Você recebeu uma nova mensagem"
            
            // Verifica se é necessário salvar a mensagem no banco
            val shouldSaveMessage = data["saveToLocal"]?.toBoolean() ?: true
            
            if (shouldSaveMessage && messageDao != null) {
                // Cria objeto de mensagem
                val msg = Message(
                    id = messageId,
                    senderId = senderId,
                    senderName = senderName,
                    content = message,
                    timestamp = System.currentTimeMillis(),
                    read = false,
                    metadata = data["metadata"]
                )
                
                // Salva no banco de dados
                messageDao.insert(msg)
            }
            
            // Exibe a notificação
            showNotification(
                title = title,
                message = message,
                type = NotificationType.MESSAGE,
                data = data,
                historyItem = historyItem
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar notificação de mensagem: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma notificação de emergência
     */
    private suspend fun processEmergencyNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        try {
            // Extrai dados da emergência
            val emergencyId = data["emergencyId"] ?: UUID.randomUUID().toString()
            val emergencyType = data["emergencyType"] ?: "unknown"
            val title = data["title"] ?: "ALERTA DE EMERGÊNCIA"
            val message = data["message"] ?: "Emergência reportada próxima à sua localização"
            
            // Exibe a notificação com alta prioridade
            showEmergencyNotification(
                title = title,
                message = message,
                data = data,
                historyItem = historyItem
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar notificação de emergência: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma notificação de compartilhamento de localização
     */
    private suspend fun processLocationShareNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) = withContext(dispatcher) {
        try {
            val userId = data["userId"] ?: "unknown"
            val userName = data["userName"] ?: "Motorista"
            val title = data["title"] ?: "$userName compartilhou localização"
            val message = data["message"] ?: "$userName está compartilhando sua localização com você"
            
            // Exibe a notificação
            showNotification(
                title = title,
                message = message,
                type = NotificationType.LOCATION_SHARE,
                data = data,
                historyItem = historyItem
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao processar notificação de compartilhamento de localização: ${e.message}", e)
        }
    }
    
    /**
     * Processa uma notificação genérica
     */
    private fun processGenericNotification(
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) {
        val title = data["title"] ?: "Nova notificação"
        val message = data["message"] ?: "Você recebeu uma nova notificação"
        
        // Determina o tipo com base nos dados disponíveis
        val type = when {
            data.containsKey("alertId") -> NotificationType.ALERT
            data.containsKey("poiId") -> NotificationType.POI
            data.containsKey("messageId") -> NotificationType.MESSAGE
            data.containsKey("emergencyId") -> NotificationType.EMERGENCY
            data.containsKey("locationShareId") -> NotificationType.LOCATION_SHARE
            data.containsKey("friendRequestId") -> NotificationType.FRIEND_REQUEST
            data.containsKey("routeShareId") -> NotificationType.ROUTE_SHARE
            else -> NotificationType.CUSTOM
        }
        
        // Exibe a notificação
        showNotification(
            title = title,
            message = message,
            type = type,
            data = data,
            historyItem = historyItem
        )
    }
    
    /**
     * Exibe uma notificação para o usuário
     */
    private fun showNotification(
        title: String,
        message: String,
        type: NotificationType,
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) {
        // Determina o canal com base no tipo
        val channelId = when (type) {
            NotificationType.ALERT -> CHANNEL_ALERTS
            NotificationType.POI -> CHANNEL_POIS
            NotificationType.MESSAGE -> CHANNEL_MESSAGES
            NotificationType.EMERGENCY -> CHANNEL_EMERGENCY
            else -> CHANNEL_GENERAL
        }
        
        // Determina a prioridade
        val priority = when (type) {
            NotificationType.ALERT -> NotificationCompat.PRIORITY_HIGH
            NotificationType.EMERGENCY -> NotificationCompat.PRIORITY_MAX
            NotificationType.MESSAGE -> NotificationCompat.PRIORITY_DEFAULT
            else -> NotificationCompat.PRIORITY_DEFAULT
        }
        
        // Determina o som
        val sound = customSounds[type] ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        // Cria intent para quando o usuário clicar na notificação
        val intent = createNotificationIntent(type, data, historyItem.id)
        val pendingIntent = TaskStackBuilder.create(context).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        
        // Constrói a notificação
        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(getNotificationIcon(type))
            .setContentIntent(pendingIntent)
            .setSound(sound)
            .setPriority(priority)
            .setAutoCancel(true)
            .build()
        
        // Exibe a notificação
        showNotificationWithPermissionCheck(notification, notificationId.incrementAndGet())
    }
    
    /**
     * Exibe uma notificação de emergência (com tratamento especial)
     */
    private fun showEmergencyNotification(
        title: String,
        message: String,
        data: Map<String, String>,
        historyItem: NotificationHistoryItem
    ) {
        // Cria intent para quando o usuário clicar na notificação
        val intent = createNotificationIntent(NotificationType.EMERGENCY, data, historyItem.id)
        val pendingIntent = TaskStackBuilder.create(context).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        
        // Som personalizado para emergência ou alarme padrão
        val sound = customSounds[NotificationType.EMERGENCY] 
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        
        // Constrói a notificação de emergência (alta prioridade, luzes, etc)
        val notification = NotificationCompat.Builder(context, CHANNEL_EMERGENCY)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(getNotificationIcon(NotificationType.EMERGENCY))
            .setContentIntent(pendingIntent)
            .setSound(sound)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setLights(Color.RED, 500, 500)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))
            .setAutoCancel(true)
            .setFullScreenIntent(pendingIntent, true) // Popup em tela cheia mesmo com tela bloqueada
            .build()
        
        // Exibe a notificação com ID único para emergências
        showNotificationWithPermissionCheck(notification, 911)
    }
    
    /**
     * Exibe uma notificação verificando permissões
     */
    private fun showNotificationWithPermissionCheck(notification: Notification, id: Int) {
        try {
            // Verifica permissão para mostrar notificações no Android 13+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != 
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    Log.w(TAG, "Sem permissão para exibir notificações")
                    return
                }
            }
            
            // Exibe a notificação
            NotificationManagerCompat.from(context).notify(id, notification)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao exibir notificação: ${e.message}", e)
        }
    }
    
    /**
     * Cria o intent correto para o tipo de notificação
     */
    private fun createNotificationIntent(
        type: NotificationType,
        data: Map<String, String>,
        historyItemId: String
    ): Intent {
        // Usando uma classe fictícia MainActivity como exemplo
        // Em um app real, você usaria a Activity correta para cada tipo de notificação
        val intent = Intent(context, Class.forName("com.kingroad.MainActivity"))
        
        // Adiciona dados extras ao intent
        intent.putExtra("notification_id", historyItemId)
        intent.putExtra("notification_type", type.id)
        
        // Adiciona dados específicos com base no tipo
        when (type) {
            NotificationType.ALERT -> {
                val alertId = data["alertId"]
                if (alertId != null) {
                    intent.putExtra("alert_id", alertId)
                    intent.action = "com.kingroad.action.OPEN_ALERT"
                }
            }
            NotificationType.POI -> {
                val poiId = data["poiId"]
                if (poiId != null) {
                    intent.putExtra("poi_id", poiId)
                    intent.action = "com.kingroad.action.OPEN_POI"
                }
            }
            NotificationType.MESSAGE -> {
                val messageId = data["messageId"]
                val senderId = data["senderId"]
                if (messageId != null) {
                    intent.putExtra("message_id", messageId)
                    intent.action = "com.kingroad.action.OPEN_MESSAGE"
                }
                if (senderId != null) {
                    intent.putExtra("sender_id", senderId)
                }
            }
            NotificationType.EMERGENCY -> {
                val emergencyId = data["emergencyId"]
                if (emergencyId != null) {
                    intent.putExtra("emergency_id", emergencyId)
                    intent.action = "com.kingroad.action.OPEN_EMERGENCY"
                }
            }
            NotificationType.LOCATION_SHARE -> {
                val userId = data["userId"]
                if (userId != null) {
                    intent.putExtra("user_id", userId)
                    intent.action = "com.kingroad.action.OPEN_LOCATION_SHARE"
                }
            }
            else -> {
                intent.action = "com.kingroad.action.OPEN_NOTIFICATION"
            }
        }
        
        // Torna o intent único para evitar sobrescrever notificações pendentes
        intent.data = Uri.parse("kingroad://notification/$historyItemId")
        
        return intent
    }
    
    /**
     * Adiciona um item ao histórico de notificações
     */
    private fun addToNotificationHistory(item: NotificationHistoryItem) {
        val currentList = _notificationHistory.value ?: emptyList()
        val newList = currentList.toMutableList().apply {
            add(0, item) // Adiciona no topo da lista
            
            // Mantém o limite máximo de 100 itens
            if (size > 100) {
                removeRange(100, size)
            }
        }
        _notificationHistory.postValue(newList)
    }
    
    /**
     * Obtém um item do histórico de notificações por ID
     */
    fun getHistoryItemById(id: String): NotificationHistoryItem? {
        return _notificationHistory.value?.find { it.id == id }
    }
    
    /**
     * Limpa o histórico de notificações
     */
    fun clearNotificationHistory() {
        _notificationHistory.postValue(emptyList())
    }
    
    /**
     * Obtém um ícone apropriado para o tipo de notificação
     */
    private fun getNotificationIcon(type: NotificationType): Int {
        // Aqui você usaria R.drawable.* correspondente a cada tipo
        // Para simplicidade, estamos retornando 0, o que usará o ícone do app
        return 0
    }
    
    /**
     * Obtém a região a partir de coordenadas geográficas
     * Em uma implementação real, usaria geocoding ou serviços de localização reversa
     */
    private fun getRegionFromCoordinates(latitude: Double, longitude: Double): String? {
        // Implementação simulada - em um app real, usaria serviços de geocoding
        // Retorna null nesta simulação
        return null
    }
    
    /**
     * Envia uma mensagem para o Firebase Cloud Messaging
     * Em uma implementação real, isto seria feito por um servidor backend
     */
    fun sendFcmMessage(
        recipientToken: String,
        title: String,
        message: String,
        type: NotificationType,
        data: Map<String, String> = emptyMap()
    ): Boolean {
        // Em uma implementação real, isso seria feito por um servidor backend
        // FCM não permite envio direto de dispositivo para dispositivo
        Log.d(TAG, "Simulando envio de mensagem FCM: $title para token $recipientToken")
        
        // Simula sucesso
        return true
    }
    
    /**
     * Envia uma mensagem para um tópico no Firebase Cloud Messaging
     * Em uma implementação real, isto seria feito por um servidor backend
     */
    fun sendFcmMessageToTopic(
        topic: String,
        title: String,
        message: String,
        type: NotificationType,
        data: Map<String, String> = emptyMap()
    ): Boolean {
        // Em uma implementação real, isso seria feito por um servidor backend
        Log.d(TAG, "Simulando envio de mensagem FCM para tópico $topic: $title")
        
        // Simula sucesso
        return true
    }
    
    /**
     * Recicla recursos quando o componente é destruído
     */
    fun shutdown() {
        scope.cancel()
    }
    
    /**
     * Classe que representa um item no histórico de notificações
     */
    data class NotificationHistoryItem(
        val id: String,
        val type: String,
        val title: String,
        val message: String,
        val timestamp: Long,
        val data: String
    )
    
    /**
     * Estados possíveis da conexão com o Firebase
     */
    sealed class FirebaseStatus {
        object Initializing : FirebaseStatus()
        object Connecting : FirebaseStatus()
        data class Connected(val token: String) : FirebaseStatus()
        data class Error(val message: String) : FirebaseStatus()
    }
}

/**
 * Serviço para receber mensagens do Firebase Cloud Messaging
 * Esta classe deve ser registrada no manifesto do aplicativo
 */
class FirebaseNotificationService : FirebaseMessagingService() {
    
    private var notificationHandler: FirebaseNotificationHandler? = null
    
    override fun onCreate() {
        super.onCreate()
        
        // Em uma implementação real, você obteria o handler através de injeção de dependência
        // ou de um singleton. Aqui estamos apenas simulando.
        Log.d("FirebaseNotificationService", "Service onCreate()")
    }
    
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        // Encaminha a mensagem para o handler
        Log.d("FirebaseNotificationService", "onMessageReceived: ${remoteMessage.data}")
        
        // Em uma implementação real, você obteria o handler através de injeção de dependência
        // ou de um singleton. Aqui, assumimos que o handler já foi inicializado em outro lugar.
        notificationHandler?.handleRemoteMessage(remoteMessage)
    }
    
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        
        // Notifica o handler sobre o novo token
        Log.d("FirebaseNotificationService", "Novo token FCM: $token")
        
        // Em uma aplicação real, você atualizaria o token no servidor backend
        // e notificaria o handler
    }
}