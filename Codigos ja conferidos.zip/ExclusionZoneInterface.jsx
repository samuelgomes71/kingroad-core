import React, { useState } from 'react';
import { AlertTriangle, Shield, Map, CheckCircle, X, Info } from 'lucide-react';

const ExclusionZoneInterface = () => {
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  return (
    <div className="h-screen bg-[#121212]">
      {/* Alerta de Zona de Risco */}
      <div className="bg-[#6B2D2D] p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <AlertTriangle size={24} className="text-red-300" />
            <div>
              <h2 className="text-lg font-bold text-red-100">ATENÇÃO: Zona de Alto Risco</h2>
              <p className="text-red-200">Seu destino está em uma área controlada</p>
            </div>
          </div>
        </div>
      </div>

      {/* Instruções de Segurança */}
      <div className="p-4 bg-[#1E1E1E]">
        <div className="bg-[#252525] p-4 rounded-lg">
          <h3 className="text-lg font-bold text-red-400 mb-3">
            Protocolos de Segurança
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-start space-x-2">
              <Shield size={20} className="text-red-400 mt-1" />
              <div>
                <p className="text-gray-200">Mantenha a calma</p>
                <p className="text-sm text-gray-400">
                  Não faça movimentos bruscos ou inesperados
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <Shield size={20} className="text-red-400 mt-1" />
              <div>
                <p className="text-gray-200">Acenda a luz interna</p>
                <p className="text-sm text-gray-400">
                  Mantenha o interior do veículo visível
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <Shield size={20} className="text-red-400 mt-1" />
              <div>
                <p className="text-gray-200">Baixe os vidros</p>
                <p className="text-sm text-gray-400">
                  Principalmente se for abordado à noite
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mapa da Área */}
      <div className="p-4">
        <div className="bg-[#1A4B81] rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-bold text-blue-100">Pontos de Acesso</h3>
            <Map size={20} className="text-blue-300" />
          </div>
          
          <div className="bg-[#1E5A9A] p-3 rounded-lg mb-2">
            <div className="text-blue-100">Entrada Principal</div>
            <div className="text-sm text-blue-200">
              Acesso controlado 24h - Aguarde orientações
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Confirmação */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-[#1E1E1E] rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-red-400 mb-4">
              Confirmação de Risco
            </h3>
            
            <p className="text-gray-300 mb-4">
              Você está prestes a entrar em uma área de alto risco. 
              Confirma que está ciente dos protocolos de segurança?
            </p>

            <div className="space-y-4">
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="form-checkbox" />
                <span className="text-gray-300">
                  Li e entendi os protocolos de segurança
                </span>
              </label>

              <label className="flex items-center space-x-2">
                <input type="checkbox" className="form-checkbox" />
                <span className="text-gray-300">
                  Confirmo que preciso acessar esta área
                </span>
              </label>

              <div className="flex space-x-4 mt-6">
                <button 
                  onClick={() => setShowConfirmation(false)}
                  className="flex-1 bg-red-600 text-white p-4 rounded-lg font-medium"
                >
                  Continuar
                </button>
                
                <button 
                  onClick={() => setShowConfirmation(false)}
                  className="flex-1 bg-[#252525] text-gray-300 p-4 rounded-lg font-medium"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Botões de Ação */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#1E1E1E]">
        <div className="flex space-x-4">
          <button 
            onClick={() => setShowConfirmation(true)}
            className="flex-1 bg-red-600 text-white p-4 rounded-lg font-medium"
          >
            Prosseguir com Cautela
          </button>
          
          <button className="flex-1 bg-[#252525] text-gray-300 p-4 rounded-lg font-medium">
            Buscar Rota Alternativa
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExclusionZoneInterface;