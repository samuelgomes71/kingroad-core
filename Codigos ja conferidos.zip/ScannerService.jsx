/**
 * ScannerService.js
 * 
 * Service that manages the scanner functionality of the KingRoad app.
 * Handles QR code and barcode scanning, processing and uploading scanned data,
 * and integrating with other services.
 * 
 * @author KingRoad Development Team
 * @version 1.0.0
 */

import { Platform } from 'react-native';
import { BarcodeFormat } from 'react-native-camera';
import OfflineCacheManager from './OfflineCacheManager';
import ApiService from './ApiService';
import LogService from './LogService';
import { TranslationsService } from './TranslationsService';

// Singleton instance
let instance = null;

class ScannerService {
  constructor() {
    if (instance) {
      return instance;
    }
    
    // Scanner configuration
    this.config = {
      enabledFormats: [
        BarcodeFormat.QR_CODE,
        BarcodeFormat.CODE_39,
        BarcodeFormat.CODE_128,
        BarcodeFormat.EAN_13,
        BarcodeFormat.EAN_8,
      ],
      scanInterval: 2000, // ms between scans
      vibrationEnabled: true,
      soundEnabled: true,
      flashlightAvailable: Platform.OS === 'ios' || Platform.Version >= 23,
      history: [], // recently scanned codes
      maxHistoryItems: 50,
    };
    
    // Scanner state
    this.state = {
      isScanning: false,
      lastScannedAt: null,
      pendingUploads: [], // scanned items waiting to be uploaded
    };
    
    // Load saved configuration and history
    this.init();
    
    instance = this;
  }
  
  /**
   * Initialize the service by loading saved configuration and scan history
   */
  async init() {
    try {
      // Load saved configuration
      const savedConfig = await OfflineCacheManager.getItem('scanner_config');
      if (savedConfig) {
        this.config = { ...this.config, ...JSON.parse(savedConfig) };
      }
      
      // Load scan history
      const savedHistory = await OfflineCacheManager.getItem('scanner_history');
      if (savedHistory) {
        this.config.history = JSON.parse(savedHistory);
      }
      
      // Load pending uploads
      const pendingUploads = await OfflineCacheManager.getItem('scanner_pending_uploads');
      if (pendingUploads) {
        this.state.pendingUploads = JSON.parse(pendingUploads);
        
        // Try to upload pending items if we're online
        if (await OfflineCacheManager.isConnected()) {
          this.uploadPendingItems();
        }
      }
      
      LogService.debug('ScannerService initialized');
    } catch (error) {
      LogService.error('Error initializing ScannerService:', error);
    }
  }
  
  /**
   * Save the current configuration to storage
   */
  async saveConfig() {
    try {
      await OfflineCacheManager.setItem(
        'scanner_config',
        JSON.stringify({
          enabledFormats: this.config.enabledFormats,
          scanInterval: this.config.scanInterval,
          vibrationEnabled: this.config.vibrationEnabled,
          soundEnabled: this.config.soundEnabled,
          maxHistoryItems: this.config.maxHistoryItems,
        })
      );
    } catch (error) {
      LogService.error('Error saving scanner config:', error);
    }
  }
  
  /**
   * Save the scan history to storage
   */
  async saveHistory() {
    try {
      await OfflineCacheManager.setItem(
        'scanner_history',
        JSON.stringify(this.config.history)
      );
    } catch (error) {
      LogService.error('Error saving scanner history:', error);
    }
  }
  
  /**
   * Save pending uploads to storage
   */
  async savePendingUploads() {
    try {
      await OfflineCacheManager.setItem(
        'scanner_pending_uploads',
        JSON.stringify(this.state.pendingUploads)
      );
    } catch (error) {
      LogService.error('Error saving pending uploads:', error);
    }
  }
  
  /**
   * Get the scanner configuration
   * @returns {Object} The current scanner configuration
   */
  getConfig() {
    return { ...this.config };
  }
  
  /**
   * Update scanner configuration
   * @param {Object} newConfig - New configuration properties to set
   */
  async updateConfig(newConfig) {
    this.config = {
      ...this.config,
      ...newConfig,
    };
    
    await this.saveConfig();
    return this.config;
  }
  
  /**
   * Process a scanned barcode/QR code
   * @param {Object} scanResult - The scan result from the camera
   * @returns {Object} Processed scan data
   */
  async processScan(scanResult) {
    try {
      // Check if we're scanning too quickly
      const now = Date.now();
      if (
        this.state.lastScannedAt &&
        now - this.state.lastScannedAt < this.config.scanInterval
      ) {
        return null;
      }
      
      this.state.lastScannedAt = now;
      this.state.isScanning = true;
      
      // Basic scan data
      const scanData = {
        type: scanResult.type,
        data: scanResult.data,
        timestamp: now,
        processed: false,
        id: `scan_${now}`,
      };
      
      // Process the data based on content
      let processedData = await this.identifyScanContent(scanData);
      
      // Add to history
      this.addToHistory(processedData);
      
      // Try to upload if we're online, otherwise add to pending
      if (await OfflineCacheManager.isConnected()) {
        await this.uploadScanData(processedData);
      } else {
        this.addToPendingUploads(processedData);
      }
      
      this.state.isScanning = false;
      return processedData;
    } catch (error) {
      LogService.error('Error processing scan:', error);
      this.state.isScanning = false;
      throw error;
    }
  }
  
  /**
   * Identify the type of content in the scan
   * @param {Object} scanData - Basic scan data
   * @returns {Object} Processed scan data with content type
   */
  async identifyScanContent(scanData) {
    const data = scanData.data;
    let contentType = 'unknown';
    let processed = false;
    
    // Check if it's a URL
    if (data.startsWith('http://') || data.startsWith('https://')) {
      contentType = 'url';
      processed = true;
    }
    // Check if it's a KingRoad POI
    else if (data.startsWith('kr://poi/')) {
      contentType = 'poi';
      processed = true;
    }
    // Check if it's a KingRoad route
    else if (data.startsWith('kr://route/')) {
      contentType = 'route';
      processed = true;
    }
    // Check if it's a vCard contact
    else if (data.startsWith('BEGIN:VCARD')) {
      contentType = 'contact';
      processed = true;
    }
    // Check if it's a geolocation
    else if (data.startsWith('geo:')) {
      contentType = 'location';
      processed = true;
    }
    // Check if it's a coupon or promo code (custom format for KingRoad)
    else if (data.startsWith('KRCOUPON:')) {
      contentType = 'coupon';
      processed = true;
    }
    // Check if it's plain text (likely a product code)
    else if (/^[A-Z0-9-]+$/.test(data)) {
      contentType = 'product';
      processed = true;
    }
    
    return {
      ...scanData,
      contentType,
      processed,
    };
  }
  
  /**
   * Add a scan to the history
   * @param {Object} scanData - The processed scan data
   */
  addToHistory(scanData) {
    // Add to the beginning of the array
    this.config.history.unshift(scanData);
    
    // Limit the size of history
    if (this.config.history.length > this.config.maxHistoryItems) {
      this.config.history = this.config.history.slice(0, this.config.maxHistoryItems);
    }
    
    // Save history
    this.saveHistory();
  }
  
  /**
   * Get the scan history
   * @returns {Array} The scan history
   */
  getHistory() {
    return [...this.config.history];
  }
  
  /**
   * Clear the scan history
   */
  async clearHistory() {
    this.config.history = [];
    await this.saveHistory();
  }
  
  /**
   * Add a scan to pending uploads
   * @param {Object} scanData - The processed scan data
   */
  addToPendingUploads(scanData) {
    this.state.pendingUploads.push(scanData);
    this.savePendingUploads();
  }
  
  /**
   * Upload scan data to the server
   * @param {Object} scanData - The processed scan data
   * @returns {Object} Server response
   */
  async uploadScanData(scanData) {
    try {
      const response = await ApiService.post('/scans', scanData);
      
      // Update the scan data with the upload status
      const updatedScanData = {
        ...scanData,
        uploaded: true,
        uploadedAt: Date.now(),
        serverId: response.id,
      };
      
      // Update in history
      const index = this.config.history.findIndex(item => item.id === scanData.id);
      if (index !== -1) {
        this.config.history[index] = updatedScanData;
        this.saveHistory();
      }
      
      return response;
    } catch (error) {
      LogService.error('Error uploading scan data:', error);
      // Add to pending uploads if it was a network error
      if (error.isNetworkError) {
        this.addToPendingUploads(scanData);
      }
      throw error;
    }
  }
  
  /**
   * Upload all pending items
   * @returns {Array} Results of uploads
   */
  async uploadPendingItems() {
    if (this.state.pendingUploads.length === 0) {
      return [];
    }
    
    const results = [];
    const newPendingUploads = [];
    
    for (const item of this.state.pendingUploads) {
      try {
        const result = await this.uploadScanData(item);
        results.push({ success: true, item, result });
      } catch (error) {
        results.push({ success: false, item, error });
        // Keep in pending uploads if it was a network error
        if (error.isNetworkError) {
          newPendingUploads.push(item);
        }
      }
    }
    
    this.state.pendingUploads = newPendingUploads;
    await this.savePendingUploads();
    
    return results;
  }
  
  /**
   * Get pending uploads
   * @returns {Array} Pending uploads
   */
  getPendingUploads() {
    return [...this.state.pendingUploads];
  }
  
  /**
   * Handle a scan result based on its content type
   * @param {Object} scanData - The processed scan data
   * @returns {Object} Result of the handler
   */
  async handleScanResult(scanData) {
    const t = TranslationsService.getTranslation;
    
    switch (scanData.contentType) {
      case 'poi':
        // Extract POI ID from kr://poi/123
        const poiId = scanData.data.replace('kr://poi/', '');
        return {
          type: 'navigate',
          title: t('scanner.navigate_to_poi'),
          poiId,
        };
        
      case 'route':
        // Extract route ID from kr://route/123
        const routeId = scanData.data.replace('kr://route/', '');
        return {
          type: 'route',
          title: t('scanner.load_route'),
          routeId,
        };
        
      case 'location':
        // Parse geo:latitude,longitude
        const coords = scanData.data.replace('geo:', '').split(',');
        return {
          type: 'location',
          title: t('scanner.navigate_to_location'),
          latitude: parseFloat(coords[0]),
          longitude: parseFloat(coords[1]),
        };
        
      case 'url':
        return {
          type: 'url',
          title: t('scanner.open_url'),
          url: scanData.data,
        };
        
      case 'coupon':
        // Extract coupon code from KRCOUPON:CODE
        const couponCode = scanData.data.replace('KRCOUPON:', '');
        return {
          type: 'coupon',
          title: t('scanner.apply_coupon'),
          couponCode,
        };
        
      case 'product':
        return {
          type: 'product',
          title: t('scanner.product_info'),
          productCode: scanData.data,
        };
        
      case 'contact':
        // TODO: Parse vCard
        return {
          type: 'contact',
          title: t('scanner.add_contact'),
          vcard: scanData.data,
        };
        
      default:
        return {
          type: 'text',
          title: t('scanner.scanned_text'),
          text: scanData.data,
        };
    }
  }
}

export default new ScannerService();