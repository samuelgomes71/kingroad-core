package com.kingroad.cache

import android.content.Context
import android.location.Location
import android.util.Log
import com.kingroad.database.POI
import com.kingroad.database.POIDao
import com.kingroad.database.RouteDao
import com.kingroad.database.SavedRoute
import com.kingroad.utils.DistanceUtils
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.osmdroid.util.GeoPoint
import java.util.*
import kotlin.math.max
import kotlin.math.min

/**
 * Cria sugestões de rota baseadas em POIs locais, caso a rota online falhe.
 * Usa posição e tipo de destino.
 */
class POIFallbackRerouting(
    private val context: Context,
    private val poiDao: POIDao,
    private val routeDao: RouteDao,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher)
) {
    companion object {
        private const val TAG = "POIFallbackRerouting"
        
        // Distância máxima para considerar POIs como waypoints alternativos (em metros)
        private const val MAX_WAYPOINT_DISTANCE = 10000.0
        
        // Número máximo de waypoints para considerar em uma rota alternativa
        private const val MAX_WAYPOINTS = 5
        
        // Número máximo de rotas alternativas a gerar
        private const val MAX_ALTERNATIVE_ROUTES = 3
        
        // Tempo máximo para calcular rotas alternativas (em milissegundos)
        private const val MAX_CALCULATION_TIME = 3000L
        
        // Lista de tipos de POI considerados úteis como waypoints
        private val USEFUL_POI_TYPES = listOf(
            "gas_station", 
            "rest_area", 
            "truck_stop", 
            "restaurant", 
            "hotel", 
            "parking",
            "weighing_station",
            "toll_booth",
            "service_area"
        )
        
        // Prioridade de POIs (mais alto = maior prioridade)
        private val POI_TYPE_PRIORITY = mapOf(
            "gas_station" to 5,
            "rest_area" to 4,
            "truck_stop" to 5,
            "weighing_station" to 3,
            "toll_booth" to 2,
            "service_area" to 4,
            "restaurant" to 3,
            "hotel" to 2,
            "parking" to 2
        )
    }

    // Estado atual da geração de rota alternativa
    private val _reroutingState = MutableStateFlow<ReroutingState>(ReroutingState.Idle)
    val reroutingState: StateFlow<ReroutingState> = _reroutingState.asStateFlow()
    
    // Job atual de cálculo de rota alternativa
    private var currentReroutingJob: Job? = null

    /**
     * Tenta criar uma rota alternativa baseada em POIs locais salvos
     * 
     * @param startPoint Ponto de início da rota
     * @param destinationPoint Ponto de destino da rota
     * @param destinationType Tipo de destino (usado para encontrar POIs similares)
     * @param preferredPoiTypes Tipos de POI preferidos para incluir na rota
     * @param maxDetourPercent Porcentagem máxima de desvio em relação à rota direta
     * @return Job que pode ser aguardado para obter o resultado
     */
    fun createAlternativeRoute(
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        destinationType: String = "",
        preferredPoiTypes: List<String> = emptyList(),
        maxDetourPercent: Double = 20.0
    ): Job {
        // Cancela job anterior se existir
        currentReroutingJob?.cancel()
        
        // Verifica conexão - se estiver online não precisa criar rota alternativa
        if (NetworkUtils.isConnected(context)) {
            _reroutingState.value = ReroutingState.Error("Conexão de rede disponível, use rota online")
            return scope.launch { }
        }
        
        _reroutingState.value = ReroutingState.Started
        
        val job = scope.launch {
            try {
                val alternativeRoutes = findAlternativeRoutes(
                    startPoint, 
                    destinationPoint,
                    destinationType,
                    preferredPoiTypes,
                    maxDetourPercent
                )
                
                if (alternativeRoutes.isEmpty()) {
                    _reroutingState.value = ReroutingState.NoRoutesFound
                } else {
                    _reroutingState.value = ReroutingState.Success(alternativeRoutes)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao criar rota alternativa: ${e.message}", e)
                _reroutingState.value = ReroutingState.Error(e.message ?: "Erro desconhecido")
            }
        }
        
        currentReroutingJob = job
        return job
    }
    
    /**
     * Encontra rotas alternativas usando POIs locais
     */
    private suspend fun findAlternativeRoutes(
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        destinationType: String,
        preferredPoiTypes: List<String>,
        maxDetourPercent: Double
    ): List<AlternativeRoute> = withContext(dispatcher) {
        val startTime = System.currentTimeMillis()
        
        // Calcula a distância em linha reta entre origem e destino
        val directDistance = DistanceUtils.haversineDistance(
            startPoint.latitude, startPoint.longitude,
            destinationPoint.latitude, destinationPoint.longitude
        )
        
        // Calcula a distância máxima permitida para a rota alternativa
        val maxRouteDistance = directDistance * (1 + maxDetourPercent / 100.0)
        
        // Define a região de busca para POIs (cria um retângulo envolvendo origem e destino)
        val boundingBox = createSearchBoundingBox(startPoint, destinationPoint, maxDetourPercent)
        
        // Busca POIs na região
        val poisInRegion = poiDao.getPOIsInRegion(
            boundingBox.minLat,
            boundingBox.minLng,
            boundingBox.maxLat,
            boundingBox.maxLng
        )
        
        // Busca rotas salvas que podem ser úteis
        val savedRoutes = routeDao.getRoutesNearPoints(
            startPoint.latitude, startPoint.longitude,
            destinationPoint.latitude, destinationPoint.longitude,
            MAX_WAYPOINT_DISTANCE
        )
        
        Log.d(TAG, "Encontrados ${poisInRegion.size} POIs e ${savedRoutes.size} rotas salvas na região")
        
        // Filtra POIs úteis como waypoints
        val usefulPOIs = filterUsefulPOIs(
            poisInRegion,
            startPoint,
            destinationPoint,
            directDistance,
            preferredPoiTypes,
            destinationType
        )
        
        // Gera candidatos a waypoints (combinações de POIs)
        val waypointCandidates = generateWaypointCandidates(
            usefulPOIs,
            startPoint,
            destinationPoint,
            maxRouteDistance
        )
        
        Log.d(TAG, "Gerados ${waypointCandidates.size} candidatos a waypoints")
        
        // Gera rotas alternativas usando os waypoints candidatos
        val alternativeRoutes = mutableListOf<AlternativeRoute>()
        
        // Adiciona rotas baseadas em waypoints, até o limite
        for (candidate in waypointCandidates) {
            // Verifica tempo limite
            if (System.currentTimeMillis() - startTime > MAX_CALCULATION_TIME) {
                Log.d(TAG, "Tempo limite excedido para cálculo de rotas alternativas")
                break
            }
            
            // Calcula e adiciona a rota alternativa
            val route = calculateAlternativeRoute(
                startPoint,
                destinationPoint,
                candidate
            )
            
            if (route != null) {
                alternativeRoutes.add(route)
                
                // Limita o número de rotas alternativas
                if (alternativeRoutes.size >= MAX_ALTERNATIVE_ROUTES) {
                    break
                }
            }
        }
        
        // Adiciona rotas salvas como alternativas, se existirem
        for (savedRoute in savedRoutes) {
            // Verifica tempo limite
            if (System.currentTimeMillis() - startTime > MAX_CALCULATION_TIME) {
                break
            }
            
            // Verifica se a rota salva é apropriada como alternativa
            val route = createRouteFromSaved(
                savedRoute,
                startPoint,
                destinationPoint,
                maxRouteDistance
            )
            
            if (route != null) {
                alternativeRoutes.add(route)
                
                // Limita o número de rotas alternativas
                if (alternativeRoutes.size >= MAX_ALTERNATIVE_ROUTES) {
                    break
                }
            }
        }
        
        // Ordena por qualidade (menor score é melhor)
        val sortedRoutes = alternativeRoutes.sortedBy { it.qualityScore }
        
        Log.d(TAG, "Geradas ${sortedRoutes.size} rotas alternativas")
        
        return@withContext sortedRoutes
    }
    
    /**
     * Filtra POIs úteis para serem usados como waypoints
     */
    private fun filterUsefulPOIs(
        pois: List<POI>,
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        directDistance: Double,
        preferredPoiTypes: List<String>,
        destinationType: String
    ): List<POI> {
        // Define os tipos de POI a considerar
        val poiTypesToConsider = if (preferredPoiTypes.isNotEmpty()) {
            preferredPoiTypes
        } else {
            USEFUL_POI_TYPES
        }
        
        // Filtra POIs por tipo e proximidade da linha direta
        return pois.filter { poi ->
            // Filtra por tipo
            val poiType = poi.type ?: return@filter false
            val isUsefulType = poiTypesToConsider.contains(poiType) || poiType == destinationType
            
            if (!isUsefulType) return@filter false
            
            // Calcula a proximidade da linha direta (origem-destino)
            val distanceToPath = DistanceUtils.distanceToLine(
                startPoint.latitude, startPoint.longitude,
                destinationPoint.latitude, destinationPoint.longitude,
                poi.latitude, poi.longitude
            )
            
            // Aceita se estiver a menos de 20% da distância direta
            return@filter distanceToPath <= (directDistance * 0.2)
        }
    }
    
    /**
     * Gera combinações de waypoints candidatos para rotas alternativas
     */
    private fun generateWaypointCandidates(
        pois: List<POI>,
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        maxRouteDistance: Double
    ): List<List<POI>> {
        // Se não houver POIs suficientes, retorna uma lista vazia
        if (pois.size < 2) {
            return emptyList()
        }
        
        val candidates = mutableListOf<List<POI>>()
        
        // Primeiro tenta criar caminhos com 1-3 waypoints
        for (numWaypoints in 1..min(3, pois.size)) {
            // Gera todas as combinações possíveis de numWaypoints
            generateCombinations(pois, numWaypoints).forEach { combination ->
                // Verifica se a combinação forma um caminho viável
                if (isViablePath(combination, startPoint, destinationPoint, maxRouteDistance)) {
                    candidates.add(combination)
                }
                
                // Limita o número de candidatos para evitar processamento excessivo
                if (candidates.size >= 20) return candidates
            }
        }
        
        return candidates
    }
    
    /**
     * Verifica se uma combinação de POIs forma um caminho viável
     */
    private fun isViablePath(
        waypoints: List<POI>,
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        maxRouteDistance: Double
    ): Boolean {
        var totalDistance = 0.0
        var lastPoint = startPoint
        
        // Calcula a distância total passando por todos os waypoints
        for (poi in waypoints) {
            val poiPoint = GeoPoint(poi.latitude, poi.longitude)
            
            totalDistance += DistanceUtils.haversineDistance(
                lastPoint.latitude, lastPoint.longitude,
                poiPoint.latitude, poiPoint.longitude
            )
            
            // Se já excedeu a distância máxima, não é um caminho viável
            if (totalDistance > maxRouteDistance) {
                return false
            }
            
            lastPoint = poiPoint
        }
        
        // Adiciona a distância do último waypoint ao destino
        totalDistance += DistanceUtils.haversineDistance(
            lastPoint.latitude, lastPoint.longitude,
            destinationPoint.latitude, destinationPoint.longitude
        )
        
        // Retorna true se a distância total for menor que a máxima permitida
        return totalDistance <= maxRouteDistance
    }
    
    /**
     * Gera todas as combinações possíveis de k elementos a partir de uma lista
     */
    private fun <T> generateCombinations(list: List<T>, k: Int): List<List<T>> {
        val result = mutableListOf<List<T>>()
        
        // Função recursiva auxiliar
        fun combine(start: Int, current: List<T>) {
            if (current.size == k) {
                result.add(current)
                return
            }
            
            for (i in start until list.size) {
                combine(i + 1, current + list[i])
            }
        }
        
        combine(0, emptyList())
        return result
    }
    
    /**
     * Calcula uma rota alternativa passando pelos waypoints dados
     */
    private fun calculateAlternativeRoute(
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        waypoints: List<POI>
    ): AlternativeRoute? {
        try {
            // Pontos da rota (origem, waypoints, destino)
            val routePoints = mutableListOf<GeoPoint>()
            routePoints.add(startPoint)
            
            // Adiciona os waypoints
            waypoints.forEach {
                routePoints.add(GeoPoint(it.latitude, it.longitude))
            }
            
            routePoints.add(destinationPoint)
            
            // Calcula a distância total
            var totalDistance = 0.0
            for (i in 0 until routePoints.size - 1) {
                val p1 = routePoints[i]
                val p2 = routePoints[i + 1]
                
                totalDistance += DistanceUtils.haversineDistance(
                    p1.latitude, p1.longitude,
                    p2.latitude, p2.longitude
                )
            }
            
            // Calcula o tempo estimado (assumindo velocidade média de 60 km/h)
            val estimatedTimeMinutes = (totalDistance / 1000.0) / 60.0 * 60.0
            
            // Calcula o score de qualidade (menor é melhor)
            val qualityScore = calculateQualityScore(waypoints, totalDistance, estimatedTimeMinutes)
            
            // Gera nome para a rota
            val routeName = generateRouteName(waypoints)
            
            return AlternativeRoute(
                id = UUID.randomUUID().toString(),
                name = routeName,
                points = routePoints,
                waypoints = waypoints,
                distanceMeters = totalDistance,
                estimatedTimeMinutes = estimatedTimeMinutes,
                qualityScore = qualityScore
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao calcular rota alternativa: ${e.message}", e)
            return null
        }
    }
    
    /**
     * Cria uma rota a partir de uma rota salva, adaptando para os pontos de início e fim atuais
     */
    private fun createRouteFromSaved(
        savedRoute: SavedRoute,
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        maxRouteDistance: Double
    ): AlternativeRoute? {
        try {
            // Decodifica os pontos da rota salva
            val savedRoutePoints = decodePolyline(savedRoute.encodedPolyline)
            
            // Se a rota não tiver pontos suficientes, ignora
            if (savedRoutePoints.size < 3) return null
            
            // Verifica se a rota salva está próxima o suficiente dos pontos atuais
            val startDistance = DistanceUtils.haversineDistance(
                startPoint.latitude, startPoint.longitude,
                savedRoutePoints.first().latitude, savedRoutePoints.first().longitude
            )
            
            val endDistance = DistanceUtils.haversineDistance(
                destinationPoint.latitude, destinationPoint.longitude,
                savedRoutePoints.last().latitude, savedRoutePoints.last().longitude
            )
            
            // Se os pontos de início ou fim estiverem muito longe, ignora
            if (startDistance > MAX_WAYPOINT_DISTANCE || endDistance > MAX_WAYPOINT_DISTANCE) {
                return null
            }
            
            // Cria uma nova lista de pontos, substituindo o início e fim pelos pontos atuais
            val routePoints = mutableListOf<GeoPoint>()
            routePoints.add(startPoint)
            
            // Adiciona pontos intermediários da rota salva (até 10 pontos principais)
            val step = max(1, savedRoutePoints.size / 10)
            for (i in step until savedRoutePoints.size - step step step) {
                routePoints.add(savedRoutePoints[i])
            }
            
            routePoints.add(destinationPoint)
            
            // Calcula a distância total
            var totalDistance = 0.0
            for (i in 0 until routePoints.size - 1) {
                val p1 = routePoints[i]
                val p2 = routePoints[i + 1]
                
                totalDistance += DistanceUtils.haversineDistance(
                    p1.latitude, p1.longitude,
                    p2.latitude, p2.longitude
                )
            }
            
            // Verifica se a distância excede o máximo permitido
            if (totalDistance > maxRouteDistance) {
                return null
            }
            
            // Calcula o tempo estimado
            val estimatedTimeMinutes = (totalDistance / 1000.0) / 60.0 * 60.0
            
            // Cria waypoints virtuais a partir dos pontos da rota salva
            val virtualWaypoints = mutableListOf<POI>()
            for (i in step until savedRoutePoints.size - step step step) {
                val point = savedRoutePoints[i]
                virtualWaypoints.add(
                    POI(
                        id = "virtual_${i}",
                        name = "Ponto ${i / step}",
                        type = "virtual_waypoint",
                        latitude = point.latitude,
                        longitude = point.longitude
                    )
                )
            }
            
            // Calcula o score de qualidade
            val qualityScore = 80.0 // Score base para rotas salvas
            
            // Gera nome para a rota
            val routeName = "Rota salva: ${savedRoute.name}"
            
            return AlternativeRoute(
                id = UUID.randomUUID().toString(),
                name = routeName,
                points = routePoints,
                waypoints = virtualWaypoints,
                distanceMeters = totalDistance,
                estimatedTimeMinutes = estimatedTimeMinutes,
                qualityScore = qualityScore
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar rota a partir de rota salva: ${e.message}", e)
            return null
        }
    }
    
    /**
     * Decodifica uma polyline codificada em uma lista de pontos
     */
    private fun decodePolyline(encoded: String): List<GeoPoint> {
        val points = mutableListOf<GeoPoint>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0
        
        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dlat
            
            shift = 0
            result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dlng
            
            val p = GeoPoint(lat.toDouble() / 1E5, lng.toDouble() / 1E5)
            points.add(p)
        }
        return points
    }
    
    /**
     * Calcula o score de qualidade para uma rota (menor é melhor)
     */
    private fun calculateQualityScore(
        waypoints: List<POI>,
        distanceMeters: Double,
        estimatedTimeMinutes: Double
    ): Double {
        // Base score - começa com 100
        var score = 100.0
        
        // Subtrai pontos para cada waypoint útil (POIs importantes melhoram a qualidade)
        waypoints.forEach { poi ->
            val poiType = poi.type ?: return@forEach
            val priority = POI_TYPE_PRIORITY[poiType] ?: 1
            score -= priority * 5.0
        }
        
        // Adiciona pontos para rotas muito longas
        val distancePenalty = (distanceMeters / 1000.0) * 0.5
        score += distancePenalty
        
        // Limita o score entre 0 e 100
        return score.coerceIn(0.0, 100.0)
    }
    
    /**
     * Gera um nome descritivo para a rota com base nos waypoints
     */
    private fun generateRouteName(waypoints: List<POI>): String {
        if (waypoints.isEmpty()) {
            return "Rota direta (offline)"
        }
        
        // Conta os tipos de POI na rota
        val typeCounts = mutableMapOf<String, Int>()
        waypoints.forEach { poi ->
            val type = poi.type ?: "desconhecido"
            typeCounts[type] = (typeCounts[type] ?: 0) + 1
        }
        
        // Cria descrição baseada nos tipos mais comuns
        val description = typeCounts.entries
            .sortedByDescending { it.value }
            .take(2)
            .joinToString(" e ") { (type, count) ->
                val typeName = translatePoiType(type)
                if (count > 1) "$count ${typeName}s" else "1 $typeName"
            }
        
        return "Via $description"
    }
    
    /**
     * Traduz o tipo de POI para um nome amigável
     */
    private fun translatePoiType(type: String): String {
        return when (type) {
            "gas_station" -> "posto"
            "rest_area" -> "área de descanso"
            "truck_stop" -> "parada de caminhão"
            "restaurant" -> "restaurante"
            "hotel" -> "hotel"
            "parking" -> "estacionamento"
            "weighing_station" -> "balança"
            "toll_booth" -> "pedágio"
            "service_area" -> "área de serviço"
            else -> type
        }
    }
    
    /**
     * Cria um bounding box para busca de POIs
     */
    private fun createSearchBoundingBox(
        startPoint: GeoPoint,
        destinationPoint: GeoPoint,
        maxDetourPercent: Double
    ): BoundingBox {
        // Calcula os limites mínimos e máximos
        val minLat = min(startPoint.latitude, destinationPoint.latitude)
        val maxLat = max(startPoint.latitude, destinationPoint.latitude)
        val minLng = min(startPoint.longitude, destinationPoint.longitude)
        val maxLng = max(startPoint.longitude, destinationPoint.longitude)
        
        // Amplia a caixa com base na porcentagem de desvio permitida
        val latDiff = maxLat - minLat
        val lngDiff = maxLng - minLng
        
        // A ampliação é proporcional à porcentagem de desvio
        val expansion = maxDetourPercent / 100.0 * 0.5
        
        return BoundingBox(
            minLat = minLat - latDiff * expansion,
            minLng = minLng - lngDiff * expansion,
            maxLat = maxLat + latDiff * expansion,
            maxLng = maxLng + lngDiff * expansion
        )
    }
    
    /**
     * Cancela o cálculo de rota alternativa atual
     */
    fun cancelRerouting() {
        currentReroutingJob?.cancel()
        currentReroutingJob = null
        _reroutingState.value = ReroutingState.Idle
    }
    
    /**
     * Libera recursos
     */
    fun shutdown() {
        currentReroutingJob?.cancel()
        currentReroutingJob = null
    }
    
    /**
     * Data class que representa um bounding box geográfico
     */
    data class BoundingBox(
        val minLat: Double,
        val minLng: Double,
        val maxLat: Double,
        val maxLng: Double
    )
    
    /**
     * Data class que representa uma rota alternativa
     */
    data class AlternativeRoute(
        val id: String,
        val name: String,
        val points: List<GeoPoint>,
        val waypoints: List<POI>,
        val distanceMeters: Double,
        val estimatedTimeMinutes: Double,
        val qualityScore: Double
    )
    
    /**
     * Sealed class que representa o estado do processo de rerouting
     */
    sealed class ReroutingState {
        object Idle : ReroutingState()
        object Started : ReroutingState()
        data class Success(val routes: List<AlternativeRoute>) : ReroutingState()
        object NoRoutesFound : ReroutingState()
        data class Error(val message: String) : ReroutingState()
    }
}