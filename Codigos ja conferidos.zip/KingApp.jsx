import React, { useState, useEffect, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Helmet } from 'react-helmet';

// Contexts
import { AuthProvider } from './contexts/AuthContext';
import { AlertProvider } from './contexts/AlertContext';
import { ThemeProvider } from './contexts/ThemeContext';
import I18nProvider from './I18nProvider';

// Componentes principais
import NavigationLayout from './layouts/NavigationLayout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import LoadingScreen from './components/common/LoadingScreen';
import Alert from './components/Alert';

// Importação dinâmica de componentes para code splitting
const Login = React.lazy(() => import('./pages/Login'));
const Register = React.lazy(() => import('./pages/Register'));
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const NavigationModule = React.lazy(() => import('./components/NavigationModule'));
const ReportesComponent = React.lazy(() => import('./components/ReportesComponent'));
const DriverProfile = React.lazy(() => import('./components/DriverProfile'));
const Settings = React.lazy(() => import('./pages/Settings'));
const PoiManager = React.lazy(() => import('./components/PoiManager'));
const WeighingSystem = React.lazy(() => import('./components/WeighingSystem'));
const NotFound = React.lazy(() => import('./pages/NotFound'));
const Offline = React.lazy(() => import('./pages/Offline'));

// Cliente de consulta para React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutos
    },
  },
});

const KingApp = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [appReady, setAppReady] = useState(false);

  // Monitorar status de conexão
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Inicialização do aplicativo
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Carregar configurações essenciais
        // await loadEssentialConfigurations();
        
        // Verificar atualizações disponíveis
        // await checkForUpdates();
        
        // Carregar dados em cache
        // await loadCachedData();
      } catch (error) {
        console.error('Erro ao inicializar o aplicativo:', error);
      } finally {
        setAppReady(true);
      }
    };

    initializeApp();
  }, []);

  // Renderizar página offline quando não há conexão
  if (!isOnline) {
    return (
      <Suspense fallback={<LoadingScreen />}>
        <Offline />
      </Suspense>
    );
  }

  // Tela de carregamento enquanto o aplicativo está inicializando
  if (!appReady) {
    return <LoadingScreen initializing={true} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <I18nProvider>
          <AlertProvider>
            <AuthProvider>
              <Router>
                <Helmet>
                  <title>KingRoad - GPS para Caminhoneiros</title>
                  <meta name="description" content="Sistema GPS especializado para caminhoneiros com rotas otimizadas para veículos pesados" />
                </Helmet>
                
                {/* Componente de alertas global */}
                <Alert />
                
                <Suspense fallback={<LoadingScreen />}>
                  <Routes>
                    {/* Rotas públicas */}
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    
                    {/* Rotas protegidas - requer autenticação */}
                    <Route element={<NavigationLayout />}>
                      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                      
                      <Route path="/navigation" element={
                        <ProtectedRoute>
                          <NavigationModule />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/reports" element={
                        <ProtectedRoute>
                          <ReportesComponent />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/profile" element={
                        <ProtectedRoute>
                          <DriverProfile />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/poi" element={
                        <ProtectedRoute>
                          <PoiManager />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/weighing" element={
                        <ProtectedRoute>
                          <WeighingSystem />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/settings" element={
                        <ProtectedRoute>
                          <Settings />
                        </ProtectedRoute>
                      } />
                    </Route>
                    
                    {/* Rota de fallback para 404 */}
                    <Route path="/404" element={<NotFound />} />
                    <Route path="*" element={<Navigate to="/404" replace />} />
                  </Routes>
                </Suspense>
              </Router>
            </AuthProvider>
          </AlertProvider>
        </I18nProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
};

export default KingApp;