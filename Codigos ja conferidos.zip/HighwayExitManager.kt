// Sistema de Alerta de Saídas de Autoestrada
// app/src/main/kotlin/com/kingroad/alerts/highway

import android.location.Location

class HighwayExitManager(
    private val locationService: LocationService,
    private val routeService: RouteService,
    private val alertService: AlertService
) {
    data class ExitInfo(
        val id: String,
        val location: Location,
        val exitNumber: String,
        val name: String,
        val type: ExitType,
        val nextServices: List<Service>? = null,
        val isDestinationExit: Boolean = false
    )

    enum class ExitType {
        REGULAR,       // Saída normal
        INTERCHANGE,   // Entroncamento
        SERVICE_AREA,  // Área de serviço
        DESTINATION   // Saída do destino
    }

    enum class Service {
        FUEL,
        FOOD,
        REST_AREA,
        TRUCK_STOP,
        CITY_ACCESS
    }

    // Monitorar saídas próximas
    suspend fun startExitMonitoring() {
        locationService.startLocationUpdates { location ->
            val speed = location.getSpeedKmh()
            if (speed >= MIN_SPEED_KMH) {
                checkNearbyExits(location, speed)
            }
        }
    }

    // Verificar saídas próximas
    private suspend fun checkNearbyExits(
        location: Location,
        speedKmh: Float
    ) {
        val nextExits = routeService.getNextExits(
            location = location,
            maxDistance = ALERT_RADIUS
        )

        nextExits.forEach { exit ->
            processExit(exit, location, speedKmh)
        }
    }

    // Processar saída
    private suspend fun processExit(
        exit: ExitInfo,
        currentLocation: Location,
        speedKmh: Float
    ) {
        val distance = calculateDistance(currentLocation, exit.location)
        
        // Verificar se está na distância de alerta e velocidade adequada
        if (shouldAlert(distance, speedKmh, exit)) {
            showExitAlert(exit, distance, speedKmh)
        }
    }

    // Determinar se deve alertar
    private fun shouldAlert(
        distance: Double,
        speedKmh: Float,
        exit: ExitInfo
    ): Boolean {
        // Primeiro alerta a 2km se velocidade >= 80km/h
        return when {
            distance <= FIRST_ALERT_DISTANCE && speedKmh >= MIN_SPEED_KMH -> true
            else -> false
        }
    }

    // Calcular distância entre dois pontos
    private fun calculateDistance(current: Location, target: Location): Double {
        val results = FloatArray(1)
        Location.distanceBetween(
            current.latitude, current.longitude,
            target.latitude, target.longitude,
            results
        )
        return results[0].toDouble()
    }

    // Formatar distância para exibição
    private fun formatDistance(meters: Double): String {
        return when {
            meters < 1000 -> "${meters.toInt()} metros"
            else -> String.format("%.1f km", meters / 1000)
        }
    }

    // Mostrar alerta de saída
    private suspend fun showExitAlert(
        exit: ExitInfo,
        distance: Double,
        speedKmh: Float
    ) {
        val message = buildString {
            append("Atenção! ")
            
            if (exit.isDestinationExit) {
                append("Sua saída está a ${formatDistance(distance)}. ")
            } else {
                append("Próxima saída (${exit.exitNumber}) a ${formatDistance(distance)}. ")
            }
            
            // Adicionar informações sobre serviços
            exit.nextServices?.let { services ->
                if (services.isNotEmpty()) {
                    append("Serviços disponíveis: ")
                    append(formatServices(services))
                }
            }
            
            // Se for saída do destino, adicionar instruções especiais
            if (exit.isDestinationExit) {
                append("Prepare-se para sair. ")
                if (speedKmh > RECOMMENDED_EXIT_SPEED) {
                    append("Reduza a velocidade. ")
                }
            }
        }

        // Determinar prioridade do alerta
        val priority = when {
            exit.isDestinationExit -> AlertPriority.HIGH
            exit.type == ExitType.SERVICE_AREA -> AlertPriority.MEDIUM
            else -> AlertPriority.LOW
        }

        alertService.showAlert(
            message = message,
            type = AlertType.HIGHWAY_EXIT,
            priority = priority
        )
    }

    private fun formatServices(services: List<Service>): String {
        return services.joinToString(", ") { service ->
            when (service) {
                Service.FUEL -> "Combustível"
                Service.FOOD -> "Alimentação"
                Service.REST_AREA -> "Área de Descanso"
                Service.TRUCK_STOP -> "Truck Stop"
                Service.CITY_ACCESS -> "Acesso à Cidade"
            }
        }
    }

    companion object {
        const val MIN_SPEED_KMH = 80.0f        // 80 km/h
        const val ALERT_RADIUS = 5000.0         // 5km
        const val FIRST_ALERT_DISTANCE = 2000.0 // 2km
        const val RECOMMENDED_EXIT_SPEED = 60.0f // 60 km/h
    }
}

// Extensões úteis
fun Location.getSpeedKmh(): Float {
    return (this.speed * 3.6f) // Converter m/s para km/h
}

// Enums para alertas
enum class AlertType {
    HIGHWAY_EXIT,
    URBAN_EXIT
}

enum class AlertPriority {
    LOW,
    MEDIUM,
    HIGH
}

// Interfaces de serviço
interface LocationService {
    suspend fun startLocationUpdates(callback: suspend (Location) -> Unit)
}

interface RouteService {
    suspend fun getNextExits(location: Location, maxDistance: Double): List<HighwayExitManager.ExitInfo>
    suspend fun getNextUrbanExits(location: Location, maxDistance: Double): List<UrbanExitManager.UrbanExit>
}

interface AlertService {
    suspend fun showAlert(
        message: String,
        type: AlertType,
        priority: AlertPriority
    )
    
    suspend fun showVoiceAlert(
        message: String,
        type: AlertType,
        priority: AlertPriority
    )
}