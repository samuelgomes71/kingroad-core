/**
 * SavedRoutesScreen.js
 * 
 * Tela de rotas salvas
 * Permite visualizar, gerenciar e carregar rotas previamente salvas
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  TextInput,
  Modal,
  Image
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useIsFocused } from '@react-navigation/native';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import RouteService from '../services/RouteService';
import { useTheme } from '../contexts/ThemeContext';

const SavedRoutesScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const isFocused = useIsFocused();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [routes, setRoutes] = useState([]);
  const [filteredRoutes, setFilteredRoutes] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState('date');
  const [showSortOptions, setShowSortOptions] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filterOptions, setFilterOptions] = useState({
    minDistance: null,
    maxDistance: null,
    dateFrom: null,
    dateTo: null,
    includeFavorites: true,
    includeShared: true
  });
  
  useEffect(() => {
    if (isFocused) {
      loadRoutes();
    }
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma
      if (isFocused) {
        loadRoutes();
      }
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, [isFocused]);
  
  useEffect(() => {
    // Filtra rotas baseado na busca e opções de filtro
    filterRoutes();
  }, [routes, searchQuery, filterOptions]);
  
  const loadRoutes = async () => {
    setLoading(true);
    
    try {
      const savedRoutes = await RouteService.getSavedRoutes();
      setRoutes(savedRoutes);
      
      // Aplica ordenação
      sortRoutes(savedRoutes, sortOption);
      
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar rotas:', error);
      setLoading(false);
      Alert.alert(
        t('alert.error'),
        t('error.load_routes'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const filterRoutes = () => {
    let filtered = [...routes];
    
    // Aplica filtro de busca
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(route => 
        route.name.toLowerCase().includes(query) || 
        route.description?.toLowerCase().includes(query)
      );
    }
    
    // Aplica outros filtros
    filtered = filtered.filter(route => {
      // Filtro de distância
      if (filterOptions.minDistance && route.distance < filterOptions.minDistance) {
        return false;
      }
      
      if (filterOptions.maxDistance && route.distance > filterOptions.maxDistance) {
        return false;
      }
// Filtro de data
      if (filterOptions.dateFrom) {
        const routeDate = new Date(route.date);
        const fromDate = new Date(filterOptions.dateFrom);
        if (routeDate < fromDate) {
          return false;
        }
      }
      
      if (filterOptions.dateTo) {
        const routeDate = new Date(route.date);
        const toDate = new Date(filterOptions.dateTo);
        if (routeDate > toDate) {
          return false;
        }
      }
      
      // Filtro de favoritos
      if (!filterOptions.includeFavorites && route.isFavorite) {
        return false;
      }
      
      // Filtro de compartilhados
      if (!filterOptions.includeShared && route.isShared) {
        return false;
      }
      
      return true;
    });
    
    // Aplica ordenação
    sortRoutes(filtered, sortOption);
  };
  
  const sortRoutes = (routesToSort, option) => {
    let sorted = [...(routesToSort || routes)];
    
    switch (option) {
      case 'name':
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'date':
        sorted.sort((a, b) => new Date(b.date) - new Date(a.date));
        break;
      case 'distance':
        sorted.sort((a, b) => b.distance - a.distance);
        break;
      case 'duration':
        sorted.sort((a, b) => b.duration - a.duration);
        break;
    }
    
    setFilteredRoutes(sorted);
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadRoutes();
    setRefreshing(false);
  };
  
  const handleSort = (option) => {
    setSortOption(option);
    sortRoutes(filteredRoutes, option);
    setShowSortOptions(false);
  };
  
  const handleDeleteRoute = (route) => {
    Alert.alert(
      t('alert.confirm'),
      t('alert.confirm_delete_route'),
      [
        {
          text: t('button.cancel'),
          style: 'cancel'
        },
        {
          text: t('button.delete'),
          style: 'destructive',
          onPress: async () => {
            try {
              await RouteService.deleteRoute(route.id);
              loadRoutes();
            } catch (error) {
              console.error('Erro ao excluir rota:', error);
              Alert.alert(
                t('alert.error'),
                t('error.delete_failed'),
                [{ text: t('button.ok') }]
              );
            }
          }
        }
      ]
    );
  };
  
  const handleToggleFavorite = async (route) => {
    try {
      await RouteService.toggleFavorite(route.id);
      loadRoutes();
    } catch (error) {
      console.error('Erro ao alterar status de favorito:', error);
      Alert.alert(
        t('alert.error'),
        t('error.update_favorite_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleViewRoute = (route) => {
    navigation.navigate('RouteDetails', { routeId: route.id });
  };
  
  const handleNavigateRoute = (route) => {
    navigation.navigate('Navigation', { routeId: route.id });
  };
  
  const handleShareRoute = async (route) => {
    try {
      await RouteService.shareRoute(route.id);
      Alert.alert(
        t('alert.success'),
        t('success.route_shared'),
        [{ text: t('button.ok') }]
      );
      loadRoutes();
    } catch (error) {
      console.error('Erro ao compartilhar rota:', error);
      Alert.alert(
        t('alert.error'),
        t('error.share_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };
const handleExportRoute = (route) => {
    Alert.alert(
      t('screen.saved_routes.export_title'),
      t('screen.saved_routes.export_format_question'),
      [
        {
          text: 'GPX',
          onPress: () => exportRouteToFormat(route, 'gpx')
        },
        {
          text: 'KML',
          onPress: () => exportRouteToFormat(route, 'kml')
        },
        {
          text: t('button.cancel'),
          style: 'cancel'
        }
      ]
    );
  };
  
  const exportRouteToFormat = async (route, format) => {
    try {
      await RouteService.exportRoute(route.id, format);
      Alert.alert(
        t('alert.success'),
        t('success.route_exported', { format: format.toUpperCase() }),
        [{ text: t('button.ok') }]
      );
    } catch (error) {
      console.error(`Erro ao exportar rota para ${format}:`, error);
      Alert.alert(
        t('alert.error'),
        t('error.export_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const resetFilters = () => {
    setFilterOptions({
      minDistance: null,
      maxDistance: null,
      dateFrom: null,
      dateTo: null,
      includeFavorites: true,
      includeShared: true
    });
  };
  
  const applyFilters = () => {
    filterRoutes();
    setShowFilterModal(false);
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(TranslationsService.getCurrentLocale(), {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  const formatDistance = (kilometers) => {
    return RegionalSettingsService.formatDistance(kilometers);
  };
  
  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours} ${t('screen.saved_routes.hour_short')} ${minutes} ${t('screen.saved_routes.min_short')}`;
    } else {
      return `${minutes} ${t('screen.saved_routes.min_short')}`;
    }
  };
  
  const renderRoute = ({ item }) => (
    <View style={[styles.routeCard, { backgroundColor: theme.card }]}>
      <View style={styles.routeHeader}>
        <View style={styles.routeTitleContainer}>
          <Text style={[styles.routeName, { color: theme.text }]}>
            {item.name}
          </Text>
          <TouchableOpacity
            style={styles.favoriteButton}
            onPress={() => handleToggleFavorite(item)}
          >
            <Icon 
              name={item.isFavorite ? 'star' : 'star-border'} 
              size={24} 
              color={item.isFavorite ? theme.warning : theme.textSecondary} 
            />
          </TouchableOpacity>
        </View>
        
        <Text style={[styles.routeDate, { color: theme.textSecondary }]}>
          {formatDate(item.date)}
        </Text>
      </View>
      
      {item.thumbnailUrl && (
        <Image 
          source={{ uri: item.thumbnailUrl }} 
          style={styles.routeThumbnail}
          resizeMode="cover"
        />
      )}
      
      <View style={styles.routeStats}>
        <View style={styles.routeStat}>
          <Icon name="straighten" size={16} color={theme.textSecondary} />
          <Text style={[styles.routeStatValue, { color: theme.text }]}>
            {formatDistance(item.distance)}
          </Text>
        </View>
        
        <View style={styles.routeStat}>
          <Icon name="timer" size={16} color={theme.textSecondary} />
          <Text style={[styles.routeStatValue, { color: theme.text }]}>
            {formatDuration(item.duration)}
          </Text>
        </View>
        
        {item.elevationGain !== undefined && (
          <View style={styles.routeStat}>
            <Icon name="trending-up" size={16} color={theme.textSecondary} />
            <Text style={[styles.routeStatValue, { color: theme.text }]}>
              {RegionalSettingsService.formatElevation(item.elevationGain)}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.routeActions}>
        <TouchableOpacity
          style={[styles.routeAction, { backgroundColor: theme.primaryLight }]}
          onPress={() => handleViewRoute(item)}
        >
          <Icon name="visibility" size={16} color={theme.primary} />
          <Text style={[styles.routeActionText, { color: theme.primary }]}>
            {t('button.view')}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.routeAction, { backgroundColor: theme.primaryLight }]}
          onPress={() => handleNavigateRoute(item)}
        >
          <Icon name="navigation" size={16} color={theme.primary} />
          <Text style={[styles.routeActionText, { color: theme.primary }]}>
            {t('button.navigate')}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.routeAction, { backgroundColor: theme.primaryLight }]}
          onPress={() => handleShareRoute(item)}
        >
          <Icon name="share" size={16} color={theme.primary} />
          <Text style={[styles.routeActionText, { color: theme.primary }]}>
            {t('button.share')}
          </Text>
        </TouchableOpacity>
<TouchableOpacity
          style={styles.actionMenu}
          onPress={() => {
            Alert.alert(
              t('screen.saved_routes.more_options'),
              '',
              [
                {
                  text: t('button.export'),
                  onPress: () => handleExportRoute(item)
                },
                {
                  text: t('button.delete'),
                  onPress: () => handleDeleteRoute(item),
                  style: 'destructive'
                },
                {
                  text: t('button.cancel'),
                  style: 'cancel'
                }
              ]
            );
          }}
        >
          <Icon name="more-vert" size={24} color={theme.textSecondary} />
        </TouchableOpacity>
      </View>
    </View>
  );
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Barra de busca e opções */}
      <View style={[styles.header, { backgroundColor: theme.card }]}>
        <View style={styles.searchContainer}>
          <Icon name="search" size={20} color={theme.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: theme.text }]}
            placeholder={t('screen.saved_routes.search_placeholder')}
            placeholderTextColor={theme.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery !== '' && (
            <TouchableOpacity
              onPress={() => setSearchQuery('')}
            >
              <Icon name="clear" size={20} color={theme.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
        
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.headerAction}
            onPress={() => setShowFilterModal(true)}
          >
            <Icon name="filter-list" size={24} color={theme.textSecondary} />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.headerAction}
            onPress={() => setShowSortOptions(!showSortOptions)}
          >
            <Icon name="sort" size={24} color={theme.textSecondary} />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Opções de ordenação */}
      {showSortOptions && (
        <View style={[styles.sortOptions, { backgroundColor: theme.card }]}>
          <TouchableOpacity
            style={[
              styles.sortOption,
              sortOption === 'name' && styles.selectedSortOption
            ]}
            onPress={() => handleSort('name')}
          >
            <Icon 
              name="sort-by-alpha" 
              size={18} 
              color={sortOption === 'name' ? theme.primary : theme.textSecondary} 
            />
            <Text 
              style={[
                styles.sortOptionText, 
                { color: sortOption === 'name' ? theme.primary : theme.text }
              ]}
            >
              {t('screen.saved_routes.sort_by_name')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.sortOption,
              sortOption === 'date' && styles.selectedSortOption
            ]}
            onPress={() => handleSort('date')}
          >
            <Icon 
              name="access-time" 
              size={18} 
              color={sortOption === 'date' ? theme.primary : theme.textSecondary} 
            />
            <Text 
              style={[
                styles.sortOptionText, 
                { color: sortOption === 'date' ? theme.primary : theme.text }
              ]}
            >
              {t('screen.saved_routes.sort_by_date')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.sortOption,
              sortOption === 'distance' && styles.selectedSortOption
            ]}
            onPress={() => handleSort('distance')}
          >
            <Icon 
              name="straighten" 
              size={18} 
              color={sortOption === 'distance' ? theme.primary : theme.textSecondary} 
            />
            <Text 
              style={[
                styles.sortOptionText, 
                { color: sortOption === 'distance' ? theme.primary : theme.text }
              ]}
            >
              {t('screen.saved_routes.sort_by_distance')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.sortOption,
              sortOption === 'duration' && styles.selectedSortOption
            ]}
            onPress={() => handleSort('duration')}
          >
            <Icon 
              name="timer" 
              size={18} 
              color={sortOption === 'duration' ? theme.primary : theme.textSecondary} 
            />
            <Text 
              style={[
                styles.sortOptionText, 
                { color: sortOption === 'duration' ? theme.primary : theme.text }
              ]}
            >
              {t('screen.saved_routes.sort_by_duration')}
            </Text>
          </TouchableOpacity>
        </View>
      )}
      
      {/* Lista de rotas */}
      <FlatList
        data={filteredRoutes}
        renderItem={renderRoute}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.routesList}
        onRefresh={handleRefresh}
        refreshing={refreshing}
        ListEmptyComponent={() => (
          <View style={styles.emptyContainer}>
            <Icon name="route" size={48} color={theme.textSecondary} />
            <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
              {loading 
                ? t('screen.saved_routes.loading_routes')
                : t('screen.saved_routes.no_routes_found')
              }
            </Text>
            {!loading && (
              <TouchableOpacity
                style={[styles.createRouteButton, { backgroundColor: theme.primary }]}
                onPress={() => navigation.navigate('CreateRoute')}
              >
                <Text style={styles.createRouteButtonText}>
                  {t('button.create_route')}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      />
      
      {/* Botão flutuante para criar rota */}
      <TouchableOpacity
        style={[styles.fab, { backgroundColor: theme.primary }]}
        onPress={() => navigation.navigate('CreateRoute')}
      >
        <Icon name="add" size={24} color="white" />
      </TouchableOpacity>
      
      {/* Modal de filtros */}
      <Modal
        visible={showFilterModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowFilterModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.filterModal, { backgroundColor: theme.card }]}>
            <View style={styles.filterModalHeader}>
              <Text style={[styles.filterModalTitle, { color: theme.text }]}>
                {t('screen.saved_routes.filter_routes')}
              </Text>
              <TouchableOpacity onPress={() => setShowFilterModal(false)}>
                <Icon name="close" size={24} color={theme.textSecondary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.filterSection}>
              <Text style={[styles.filterSectionTitle, { color: theme.text }]}>
                {t('screen.saved_routes.distance')}
              </Text>
              <View style={styles.filterRow}>
                <View style={styles.filterInput}>
                  <TextInput
                    style={[styles.filterTextInput, { color: theme.text, borderColor: theme.border }]}
                    placeholder={t('screen.saved_routes.min')}
                    placeholderTextColor={theme.textSecondary}
                    keyboardType="numeric"
                    value={filterOptions.minDistance?.toString() || ''}
                    onChangeText={(text) => setFilterOptions(prev => ({
                      ...prev,
                      minDistance: text ? Number(text) : null
                    }))}
                  />
                </View>
                <Text style={[styles.filterRangeSeparator, { color: theme.textSecondary }]}>-</Text>
                <View style={styles.filterInput}>
                  <TextInput
                    style={[styles.filterTextInput, { color: theme.text, borderColor: theme.border }]}
                    placeholder={t('screen.saved_routes.max')}
                    placeholderTextColor={theme.textSecondary}
                    keyboardType="numeric"
                    value={filterOptions.maxDistance?.toString() || ''}
                    onChangeText={(text) => setFilterOptions(prev => ({
                      ...prev,
                      maxDistance: text ? Number(text) : null
                    }))}
                  />
                </View>
                <Text style={[styles.filterUnit, { color: theme.textSecondary }]}>
                  {RegionalSettingsService.isMetricSystem() ? 'km' : 'mi'}
                </Text>
              </View>
            </View>
            
            <View style={styles.filterSection}>
              <Text style={[styles.filterSectionTitle, { color: theme.text }]}>
                {t('screen.saved_routes.date_range')}
              </Text>
              <View style={styles.filterRow}>
                <TouchableOpacity
                  style={[styles.datePickerButton, { borderColor: theme.border }]}
                  onPress={() => {
                    // Implementação de seletor de data ficaria aqui
                    // Para simplicidade, não está implementado completamente
                  }}
                >
                  <Text style={{ color: theme.text }}>
                    {filterOptions.dateFrom
                      ? formatDate(filterOptions.dateFrom)
                      : t('screen.saved_routes.start_date')
                    }
                  </Text>
                </TouchableOpacity>
                <Text style={[styles.filterRangeSeparator, { color: theme.textSecondary }]}>-</Text>
                <TouchableOpacity
                  style={[styles.datePickerButton, { borderColor: theme.border }]}
                  onPress={() => {
                    // Implementação de seletor de data ficaria aqui
                  }}
                >
                  <Text style={{ color: theme.text }}>
                    {filterOptions.dateTo
                      ? formatDate(filterOptions.dateTo)
                      : t('screen.saved_routes.end_date')
                    }
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <View style={styles.filterSection}>
              <Text style={[styles.filterSectionTitle, { color: theme.text }]}>
                {t('screen.saved_routes.route_type')}
              </Text>
              <View style={styles.filterCheckboxRow}>
                <TouchableOpacity
                  style={styles.filterCheckbox}
                  onPress={() => setFilterOptions(prev => ({
                    ...prev,
                    includeFavorites: !prev.includeFavorites
                  }))}
                >
                  <Icon 
                    name={filterOptions.includeFavorites ? 'check-box' : 'check-box-outline-blank'} 
                    size={24} 
                    color={theme.primary} 
                  />
                  <Text style={[styles.filterCheckboxLabel, { color: theme.text }]}>
                    {t('screen.saved_routes.favorites')}
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.filterCheckbox}
                  onPress={() => setFilterOptions(prev => ({
                    ...prev,
                    includeShared: !prev.includeShared
                  }))}
                >
                  <Icon 
                    name={filterOptions.includeShared ? 'check-box' : 'check-box-outline-blank'} 
                    size={24} 
                    color={theme.primary} 
                  />
                  <Text style={[styles.filterCheckboxLabel, { color: theme.text }]}>
                    {t('screen.saved_routes.shared')}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <View style={styles.filterActions}>
              <TouchableOpacity
                style={[styles.filterButton, { borderColor: theme.border }]}
                onPress={resetFilters}
              >
                <Text style={[styles.filterButtonText, { color: theme.text }]}>
                  {t('button.reset')}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.filterButton, { backgroundColor: theme.primary }]}
                onPress={applyFilters}
              >
                <Text style={styles.filterButtonTextPrimary}>
                  {t('button.apply')}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  searchInput: {
    flex: 1,
    height: 40,
    paddingVertical: 8,
    paddingHorizontal: 8,
    fontSize: 16,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerAction: {
    padding: 8,
    marginLeft: 8,
  },
  sortOptions: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sortOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  selectedSortOption: {
    fontWeight: 'bold',
  },
  sortOptionText: {
    marginLeft: 8,
    fontSize: 14,
  },
  routesList: {
    padding: 12,
    paddingBottom: 80, // Espaço para FAB
  },
  routeCard: {
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
  },
  routeHeader: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  routeTitleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between
justifyContent: 'space-between',
    alignItems: 'center',
  },
  routeName: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  favoriteButton: {
    padding: 4,
  },
  routeDate: {
    fontSize: 12,
    marginTop: 4,
  },
  routeThumbnail: {
    width: '100%',
    height: 120,
  },
  routeStats: {
    flexDirection: 'row',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  routeStat: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  routeStatValue: {
    marginLeft: 4,
    fontSize: 14,
  },
  routeActions: {
    flexDirection: 'row',
    padding: 12,
    alignItems: 'center',
  },
  routeAction: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 8,
  },
  routeActionText: {
    marginLeft: 4,
    fontSize: 12,
    fontWeight: '500',
  },
  actionMenu: {
    marginLeft: 'auto',
    padding: 4,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    marginTop: 40,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  createRouteButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  createRouteButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  filterModal: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingBottom: 24,
  },
  filterModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  filterModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  filterSection: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  filterSectionTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 12,
  },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterInput: {
    flex: 1,
  },
  filterTextInput: {
    height: 40,
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 8,
  },
  filterRangeSeparator: {
    paddingHorizontal: 8,
    fontSize: 16,
  },
  filterUnit: {
    paddingLeft: 8,
    fontSize: 14,
  },
  datePickerButton: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderRadius: 4,
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  filterCheckboxRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  filterCheckbox: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  filterCheckboxLabel: {
    marginLeft: 8,
    fontSize: 14,
  },
  filterActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
  },
  filterButton: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
  },
  filterButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  filterButtonTextPrimary: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  }
});

export default SavedRoutesScreen;