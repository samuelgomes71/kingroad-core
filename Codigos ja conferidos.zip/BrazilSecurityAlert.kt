package com.kingroad.database.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Date

/**
 * Entidade que representa um alerta de segurança específico do Brasil no banco de dados.
 * Esta entidade estende o conceito de SecurityAlert com campos específicos para o contexto brasileiro.
 */
@Entity(
    tableName = "brazil_security_alerts",
    indices = [
        Index("id"),
        Index("type"),
        Index("expirationTime")
    ]
)
data class BrazilSecurityAlert(
    @PrimaryKey
    val id: String,
    
    /**
     * Tipo do alerta. Valores possíveis:
     * - tiroteio
     * - sequestro
     * - roubo_carga
     * - veiculo_suspeito
     * - veiculo_alta_velocidade
     */
    val type: String,
    
    /**
     * Latitude da localização do alerta
     */
    val latitude: Double,
    
    /**
     * Longitude da localização do alerta
     */
    val longitude: Double,
    
    /**
     * Descrição textual do alerta
     */
    val description: String,
    
    /**
     * Timestamp de criação do alerta
     */
    val creationTime: Long = Date().time,
    
    /**
     * Timestamp de expiração do alerta
     */
    val expirationTime: Long,
    
    /**
     * Nível de gravidade: "low", "medium", "high"
     */
    val severity: String,
    
    /**
     * Estado brasileiro onde o alerta foi reportado
     */
    val state: String? = null,
    
    /**
     * Cidade onde o alerta foi reportado
     */
    val city: String? = null,
    
    /**
     * ID do usuário que reportou o alerta
     * Pode ser "anonymous" se o usuário escolheu o anonimato
     */
    val reportedBy: String,
    
    /**
     * Quantidade de confirmações deste alerta por outros usuários
     */
    val confirmations: Int = 0,
    
    /**
     * Quantidade de reportes como falso alerta
     */
    val falseReports: Int = 0,
    
    /**
     * Indica se o alerta foi verificado por autoridades ou pela equipe KingRoad
     */
    val verified: Boolean = false,
    
    /**
     * Para alertas de veículo suspeito, placa do veículo (se disponível)
     */
    val licensePlate: String? = null,
    
    /**
     * Para alertas de veículo suspeito, modelo do veículo (se disponível)
     */
    val vehicleModel: String? = null,
    
    /**
     * Para alertas de veículo suspeito, cor do veículo (se disponível)
     */
    val vehicleColor: String? = null,
    
    /**
     * Categorias adicionais para o alerta (tags)
     * Armazenado como string separada por vírgulas
     */
    val tags: String? = null,
    
    /**
     * Timestamp da última atualização deste alerta
     */
    val lastUpdated: Long = Date().time
) {
    /**
     * Verifica se o alerta ainda é válido com base no tempo de expiração
     */
    fun isActive(): Boolean = expirationTime > Date().time
    
    /**
     * Verifica se o alerta é confiável baseado em confirmações e verificações
     */
    fun isReliable(): Boolean = verified || confirmations >= 3
    
    /**
     * Retorna o tempo restante em minutos antes da expiração do alerta
     */
    fun getRemainingTimeMinutes(): Int {
        val currentTime = Date().time
        val remainingMillis = expirationTime - currentTime
        return (remainingMillis / (1000 * 60)).toInt().coerceAtLeast(0)
    }
    
    /**
     * Verifica o nível de confiabilidade do alerta
     * @return Um valor entre 0.0 (menos confiável) e 1.0 (mais confiável)
     */
    fun getReliabilityScore(): Double {
        val baseScore = when {
            verified -> 1.0
            falseReports > 5 -> 0.0
            falseReports > 0 -> 0.5 - (falseReports.toDouble() / 10.0)
            else -> 0.5
        }
        
        val confirmationBonus = confirmations.toDouble() / 10.0
        
        return (baseScore + confirmationBonus).coerceIn(0.0, 1.0)
    }
    
    /**
     * Retorna tags como lista
     */
    fun getTagsList(): List<String> {
        return tags?.split(",")?.map { it.trim() } ?: emptyList()
    }
}