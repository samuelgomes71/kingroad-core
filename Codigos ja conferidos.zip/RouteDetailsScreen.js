import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  Platform,
  StatusBar,
  Share,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useRoute } from '@react-navigation/native';
import MapView, { Polyline, Marker } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');

const RouteDetailsScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { route: routeData } = route.params;
  
  const [mapExpanded, setMapExpanded] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [routeStats, setRouteStats] = useState(null);
  const [poiAlongRoute, setPoiAlongRoute] = useState([]);
  const [safetyScore, setSafetyScore] = useState(null);
  
  // Mapeamento de modos para cores e ícones
  const modeMap = {
    truck: { color: '#4A90E2', icon: 'truck', label: 'Caminhão' },
    hike: { color: '#4CAF50', icon: 'hiking', label: 'Trilha' },
    bike: { color: '#FF9800', icon: 'bike', label: 'Bike' },
    moto: { color: '#E91E63', icon: 'motorbike', label: 'Moto' },
    '4x4': { color: '#795548', icon: 'jeepney', label: '4x4' },
    snowmobile: { color: '#9C27B0', icon: 'snowflake', label: 'Snowmobile' }
  };

  // Informações do modo atual
  const currentMode = modeMap[routeData.mode] || { color: '#607D8B', icon: 'map-marker-path', label: 'Rota' };
  
  useEffect(() => {
    // Verificar se a rota é favorita
    checkFavoriteStatus();
    
    // Calcular estatísticas da rota
    calculateRouteStats();
    
    // Buscar pontos de interesse ao longo da rota
    fetchPOIAlongRoute();
    
    // Obter pontuação de segurança da rota
    fetchSafetyScore();
  }, []);

  // Verificar se a rota está marcada como favorita
  const checkFavoriteStatus = async () => {
    try {
      const favoritesJson = await AsyncStorage.getItem('favorite_routes');
      if (favoritesJson) {
        const favorites = JSON.parse(favoritesJson);
        setIsFavorite(favorites.some(favId => favId === routeData.id));
      }
    } catch (error) {
      console.error('Erro ao verificar status de favorito:', error);
    }
  };

  // Calcular estatísticas da rota
  const calculateRouteStats = () => {
    // Em um app real, faria cálculos mais complexos
    // baseados nos pontos reais da rota
    
    // Simulando alguns dados para demonstração
    setRouteStats({
      totalDistance: routeData.distance || 48.5,
      duration: routeData.duration || 78 * 60, // em segundos
      elevationGain: 320,
      elevationLoss: 280,
      averageSpeed: 35.2,
      estimatedFuel: routeData.mode === 'truck' ? 14.2 : (routeData.mode === 'moto' ? 3.8 : 5.6),
      startElevation: 754,
      endElevation: 802,
      highestPoint: 924,
      lowestPoint: 702
    });
  };

  // Buscar pontos de interesse ao longo da rota
  const fetchPOIAlongRoute = () => {
    // Em um app real, faria uma busca no banco de dados
    // por POIs próximos aos pontos da rota
    
    // Simulando alguns dados para demonstração
    setTimeout(() => {
      setPoiAlongRoute([
        {
          id: 'poi1',
          name: 'Posto Estrela',
          type: 'gas_station',
          icon: 'gas-station',
          distance: 12.3, // km da origem
          description: 'Posto de combustível com restaurante e loja de conveniência',
          rating: 4.2
        },
        {
          id: 'poi2',
          name: 'Mirante do Vale',
          type: 'viewpoint',
          icon: 'image-filter-hdr',
          distance: 23.7,
          description: 'Vista panorâmica de toda a região',
          rating: 4.8
        },
        {
          id: 'poi3',
          name: 'Restaurante do Caminhoneiro',
          type: 'food',
          icon: 'food-fork-drink',
          distance: 35.2,
          description: 'Comida caseira com preço justo',
          rating: 4.5
        }
      ]);
    }, 1000);
  };

  // Obter pontuação de segurança
  const fetchSafetyScore = () => {
    // Em um app real, calcularia com base em dados
    // históricos de acidentes, condições da via, etc.
    
    // Simulando dados para demonstração
    setTimeout(() => {
      setSafetyScore({
        overall: 8.5,
        roadCondition: 7.9,
        trafficSafety: 8.8,
        weatherSafety: 9.2,
        dangerousPoints: 2
      });
    }, 1500);
  };

  // Alternar status de favorito
  const toggleFavorite = async () => {
    try {
      const newStatus = !isFavorite;
      setIsFavorite(newStatus);
      
      const favoritesJson = await AsyncStorage.getItem('favorite_routes');
      let favorites = favoritesJson ? JSON.parse(favoritesJson) : [];
      
      if (newStatus) {
        // Adicionar aos favoritos se não estiver na lista
        if (!favorites.includes(routeData.id)) {
          favorites.push(routeData.id);
        }
      } else {
        // Remover dos favoritos
        favorites = favorites.filter(favId => favId !== routeData.id);
      }
      
      await AsyncStorage.setItem('favorite_routes', JSON.stringify(favorites));
    } catch (error) {
      console.error('Erro ao atualizar favoritos:', error);
      Alert.alert('Erro', 'Não foi possível atualizar os favoritos');
      // Reverter a mudança visual em caso de erro
      setIsFavorite(!isFavorite);
    }
  };

  // Compartilhar rota
  const shareRoute = async () => {
    try {
      const result = await Share.share({
        message: `Confira esta rota no KingRoad: ${routeData.title || 'Minha rota'} - ${routeStats?.totalDistance.toFixed(1)}km`,
        title: 'Compartilhar Rota'
      });
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível compartilhar a rota');
    }
  };

  // Iniciar navegação com esta rota
  const startNavigation = () => {
    navigation.navigate('NavigationScreen', {
      savedRoute: routeData,
      startNavigation: true
    });
  };

  // Exportar rota
  const exportRoute = () => {
    Alert.alert(
      'Exportar Rota',
      'Escolha o formato para exportar:',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'GPX',
          onPress: () => {
            // Em um app real, aqui converteria a rota para GPX e salvaria
            Alert.alert('Exportação', `Rota exportada como GPX: ${routeData.title || 'Rota'}.gpx`);
          }
        },
        {
          text: 'KML',
          onPress: () => {
            // Em um app real, aqui converteria a rota para KML e salvaria
            Alert.alert('Exportação', `Rota exportada como KML: ${routeData.title || 'Rota'}.kml`);
          }
        }
      ]
    );
  };

  // Renderizar um ponto de interesse
  const renderPOI = (poi, index) => (
    <TouchableOpacity 
      key={poi.id}
      style={styles.poiItem}
      onPress={() => navigation.navigate('POIDetails', { poi })}
    >
      <View style={styles.poiIconContainer}>
        <Icon name={poi.icon} size={20} color="#FFF" />
      </View>
      <View style={styles.poiInfo}>
        <Text style={styles.poiName}>{poi.name}</Text>
        <Text style={styles.poiDescription} numberOfLines={1}>
          {poi.description}
        </Text>
        <View style={styles.poiMeta}>
          <Icon name="map-marker-distance" size={14} color="#999" />
          <Text style={styles.poiMetaText}>
            {poi.distance.toFixed(1)} km da origem
          </Text>
          <Icon name="star" size={14} color="#FFD700" style={styles.poiRatingIcon} />
          <Text style={styles.poiMetaText}>{poi.rating}</Text>
        </View>
      </View>
      <Icon name="chevron-right" size={20} color="#CCC" />
    </TouchableOpacity>
  );

  // Formatar tempo em horas e minutos
  const formatDuration = (seconds) => {
    if (!seconds) return '--';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return hours > 0 
      ? `${hours}h ${minutes}min` 
      : `${minutes}min`;
  };

  // Simular coordenadas da rota para demonstração
  // Em um app real, obteria do objeto routeData.coordinates
  const simulateRouteCoordinates = () => {
    // Ponto inicial (exemplo: São Paulo)
    const startLat = -23.550520;
    const startLng = -46.633308;
    
    // Gerar pontos aleatórios em torno do ponto inicial
    const points = [];
    let currentLat = startLat;
    let currentLng = startLng;
    
    // Adicionar ponto inicial
    points.push({ latitude: currentLat, longitude: currentLng });
    
    // Adicionar pontos intermediários
    for (let i = 0; i < 20; i++) {
      // Movimento aleatório, mas tendendo a ir para nordeste
      currentLat += (Math.random() * 0.01) - 0.003;
      currentLng += (Math.random() * 0.01) - 0.002;
      points.push({ latitude: currentLat, longitude: currentLng });
    }
    
    return points;
  };
  
  const routeCoordinates = routeData.coordinates || simulateRouteCoordinates();
  const initialRegion = {
    latitude: routeCoordinates[0].latitude,
    longitude: routeCoordinates[0].longitude,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Mapa */}
      <View style={[styles.mapContainer, mapExpanded && styles.expandedMap]}>
        <MapView
          style={styles.map}
          initialRegion={initialRegion}
          zoomEnabled={true}
          scrollEnabled={true}
        >
          {/* Traçado da rota */}
          <Polyline
            coordinates={routeCoordinates}
            strokeWidth={4}
            strokeColor={currentMode.color}
          />
          
          {/* Marcadores de início e fim */}
          <Marker
            coordinate={routeCoordinates[0]}
            pinColor="green"
            title="Início"
          />
          <Marker
            coordinate={routeCoordinates[routeCoordinates.length - 1]}
            pinColor="red"
            title="Fim"
          />
          
          {/* Marcadores de pontos de interesse */}
          {poiAlongRoute.map((poi, index) => {
            // Simular posição do POI ao longo da rota
            const poiIndex = Math.floor((poi.distance / (routeStats?.totalDistance || 50)) * routeCoordinates.length);
            const safePOIIndex = Math.min(poiIndex, routeCoordinates.length - 1);
            
            return (
              <Marker
                key={poi.id}
                coordinate={routeCoordinates[safePOIIndex]}
                title={poi.name}
                description={poi.description}
              >
                <View style={styles.customMarker}>
                  <Icon name={poi.icon} size={18} color="#FFF" />
                </View>
              </Marker>
            );
          })}
        </MapView>
        
        {/* Botões de controle do mapa */}
        <View style={styles.mapControls}>
          <TouchableOpacity 
            style={styles.mapControlButton}
            onPress={() => setMapExpanded(!mapExpanded)}
          >
            <Icon 
              name={mapExpanded ? "arrow-collapse" : "arrow-expand"} 
              size={20} 
              color="#333" 
            />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Cabeçalho */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-left" size={24} color="#FFF" />
        </TouchableOpacity>
        
        <View style={styles.titleContainer}>
          <Text style={styles.title} numberOfLines={1}>
            {routeData.title || 'Detalhes da Rota'}
          </Text>
          <View style={styles.modeIndicator}>
            <Icon name={currentMode.icon} size={14} color="#FFF" />
            <Text style={styles.modeText}>{currentMode.label}</Text>
          </View>
        </View>
        
        <View style={styles.headerActions}>
          <TouchableOpacity 
            style={styles.headerButton}
            onPress={toggleFavorite}
          >
            <Icon 
              name={isFavorite ? "star" : "star-outline"} 
              size={24} 
              color={isFavorite ? "#FFD700" : "#FFF"} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.headerButton}
            onPress={shareRoute}
          >
            <Icon name="share-variant" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>
      </View>
      
      {!mapExpanded && (
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Informações básicas */}
          <View style={styles.section}>
            <View style={styles.basicInfoContainer}>
              <View style={styles.infoItem}>
                <Icon name="map-marker-distance" size={20} color={currentMode.color} />
                <Text style={styles.infoValue}>
                  {routeStats?.totalDistance.toFixed(1) || '--'} km
                </Text>
                <Text style={styles.infoLabel}>Distância</Text>
              </View>
              
              <View style={styles.infoItem}>
                <Icon name="clock-outline" size={20} color={currentMode.color} />
                <Text style={styles.infoValue}>
                  {formatDuration(routeStats?.duration)}
                </Text>
                <Text style={styles.infoLabel}>Duração</Text>
              </View>
              
              <View style={styles.infoItem}>
                <Icon name="speedometer" size={20} color={currentMode.color} />
                <Text style={styles.infoValue}>
                  {routeStats?.averageSpeed.toFixed(1) || '--'} km/h
                </Text>
                <Text style={styles.infoLabel}>Velocidade</Text>
              </View>
            </View>
          </View>
          
          {/* Botões de ação */}
          <View style={styles.actionButtonsContainer}>
            <TouchableOpacity 
              style={[styles.actionButton, { backgroundColor: currentMode.color }]}
              onPress={startNavigation}
            >
              <Icon name="navigation" size={20} color="#FFF" />
              <Text style={styles.actionButtonText}>Navegar</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={exportRoute}
            >
              <Icon name="export" size={20} color="#333" />
              <Text style={styles.actionButtonText}>Exportar</Text>
            </TouchableOpacity>
          </View>
          
          {/* Análise de segurança */}
          {safetyScore && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Análise de Segurança</Text>
              <View style={styles.safetyCard}>
                <View style={styles.safetyScoreContainer}>
                  <View 
                    style={[
                      styles.safetyScoreCircle, 
                      { 
                        borderColor: 
                          safetyScore.overall >= 8 ? '#4CAF50' : 
                          safetyScore.overall >= 6 ? '#FFC107' : '#F44336' 
                      }
                    ]}
                  >
                    <Text style={styles.safetyScoreText}>
                      {safetyScore.overall.toFixed(1)}
                    </Text>
                  </View>
                  <Text style={styles.safetyScoreLabel}>Segurança Geral</Text>
                </View>
                
                <View style={styles.safetyDetails}>
                  <View style={styles.safetyDetailItem}>
                    <Text style={styles.safetyDetailLabel}>Condições da via</Text>
                    <View style={styles.safetyBar}>
                      <View 
                        style={[
                          styles.safetyBarFill, 
                          { 
                            width: `${(safetyScore.roadCondition / 10) * 100}%`,
                            backgroundColor: 
                              safetyScore.roadCondition >= 8 ? '#4CAF50' : 
                              safetyScore.roadCondition >= 6 ? '#FFC107' : '#F44336'
                          }
                        ]} 
                      />
                    </View>
                    <Text style={styles.safetyDetailValue}>{safetyScore.roadCondition.toFixed(1)}</Text>
                  </View>
                  
                  <View style={styles.safetyDetailItem}>
                    <Text style={styles.safetyDetailLabel}>Segurança de tráfego</Text>
                    <View style={styles.safetyBar}>
                      <View 
                        style={[
                          styles.safetyBarFill, 
                          { 
                            width: `${(safetyScore.trafficSafety / 10) * 100}%`,
                            backgroundColor: 
                              safetyScore.trafficSafety >= 8 ? '#4CAF50' : 
                              safetyScore.trafficSafety >= 6 ? '#FFC107' : '#F44336'
                          }
                        ]} 
                      />
                    </View>
                    <Text style={styles.safetyDetailValue}>{safetyScore.trafficSafety.toFixed(1)}</Text>
                  </View>
                  
                  <View style={styles.safetyDetailItem}>
                    <Text style={styles.safetyDetailLabel}>Clima</Text>
                    <View style={styles.safetyBar}>
                      <View 
                        style={[
                          styles.safetyBarFill, 
                          { 
                            width: `${(safetyScore.weatherSafety / 10) * 100}%`,
                            backgroundColor: 
                              safetyScore.weatherSafety >= 8 ? '#4CAF50' : 
                              safetyScore.weatherSafety >= 6 ? '#FFC107' : '#F44336'
                          }
                        ]} 
                      />
                    </View>
                    <Text style={styles.safetyDetailValue}>{safetyScore.weatherSafety.toFixed(1)}</Text>
                  </View>
                </View>
                
                <View style={styles.dangerousPointsContainer}>
                  <Icon name="alert-circle" size={20} color="#F44336" />
                  <Text style={styles.dangerousPointsText}>
                    {safetyScore.dangerousPoints} pontos de atenção nesta rota
                  </Text>
                </View>
                
                <TouchableOpacity 
                  style={styles.viewSafetyButton}
                  onPress={() => navigation.navigate('RouteSafetyScreen', { routeId: routeData.id })}
                >
                  <Text style={styles.viewSafetyButtonText}>Ver Análise Completa</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          
          {/* Dados de elevação */}
          {routeStats && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Perfil de Elevação</Text>
              <View style={styles.elevationCard}>
                <View style={styles.elevationGraph}>
                  {/* Em um app real, aqui teria um gráfico de elevação */}
                  <View style={styles.elevationGraphPlaceholder}>
                    <Text style={styles.placeholderText}>Gráfico de Elevação</Text>
                  </View>
                </View>
                
                <View style={styles.elevationDetails}>
                  <View style={styles.elevationItem}>
                    <Text style={styles.elevationValue}>{routeStats.elevationGain}m</Text>
                    <Text style={styles.elevationLabel}>Ganho</Text>
                  </View>
                  
                  <View style={styles.elevationItem}>
                    <Text style={styles.elevationValue}>{routeStats.elevationLoss}m</Text>
                    <Text style={styles.elevationLabel}>Perda</Text>
                  </View>
                  
                  <View style={styles.elevationItem}>
                    <Text style={styles.elevationValue}>{routeStats.highestPoint}m</Text>
                    <Text style={styles.elevationLabel}>Máxima</Text>
                  </View>
                  
                  <View style={styles.elevationItem}>
                    <Text style={styles.elevationValue}>{routeStats.lowestPoint}m</Text>
                    <Text style={styles.elevationLabel}>Mínima</Text>
                  </View>
                </View>
              </View>
            </View>
          )}
          
          {/* Consumo estimado, apenas para veículos motorizados */}
          {routeStats && ['truck', 'moto', '4x4'].includes(routeData.mode) && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Consumo Estimado</Text>
              <View style={styles.fuelCard}>
                <View style={styles.fuelIconContainer}>
                  <Icon name="gas-station" size={28} color="#FF9800" />
                </View>
                <View style={styles.fuelInfoContainer}>
                  <Text style={styles.fuelValue}>{routeStats.estimatedFuel.toFixed(1)} L</Text>
                  <Text style={styles.fuelLabel}>Combustível estimado</Text>
                </View>
              </View>
            </View>
          )}
          
          {/* Pontos de interesse ao longo da rota */}
          {poiAlongRoute.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Pontos de Interesse</Text>
              <View style={styles.poiContainer}>
                {poiAlongRoute.map(renderPOI)}
              </View>
            </View>
          )}
          
          {/* Metadados da rota */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Informações Adicionais</Text>
            <View style={styles.metadataCard}>
              <View style={styles.metadataItem}>
                <Text style={styles.metadataLabel}>Data de Criação</Text>
                <Text style={styles.metadataValue}>
                  {new Date(routeData.timestamp).toLocaleDateString()}
                </Text>
              </View>
              
              <View style={styles.metadataItem}>
                <Text style={styles.metadataLabel}>Criado por</Text>
                <Text style={styles.metadataValue}>
                  {routeData.creator || 'Você'}
                </Text>
              </View>
              
              <View style={styles.metadataItem}>
                <Text style={styles.metadataLabel}>ID da Rota</Text>
                <Text style={styles.metadataValue}>
                  {routeData.id.substring(0, 8)}...
                </Text>
              </View>
            </View>
          </View>
          
          {/* Espaço no final para não cortar o último item */}
          <View style={styles.bottomPadding} />
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingTop: Platform.OS === 'ios' ? 40 : StatusBar.currentHeight + 10,
    paddingBottom: 15,
    paddingHorizontal: 15,
    zIndex: 10,
  },
  backButton: {
    padding: 5,
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
  },
  modeIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    marginTop: 4,
  },
  modeText: {
    fontSize: 12,
    color: '#FFF',
    marginLeft: 4,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerButton: {
    padding: 5,
    marginLeft: 10,
  },
  mapContainer: {
    height: height * 0.3,
    width: width,
  },
  expandedMap: {
    height: height,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapControls: {
    position: 'absolute',
    right: 10,
    bottom: 10,
    flexDirection: 'row',
  },
  mapControlButton: {
    backgroundColor: '#FFF',
    borderRadius: 5,
    padding: 8,
    marginLeft: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  customMarker: {
    backgroundColor: '#FF9800',
    borderRadius: 18,
    padding: 6,
    borderWidth: 2,
    borderColor: '#FFF',
  },
  scrollView: {
    marginTop: height * 0.3,
  },
  section: {
    marginHorizontal: 16,
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  basicInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginTop: 80, // Espaço para o cabeçalho
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  infoItem: {
    alignItems: 'center',
    flex: 1,
  },
  infoValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 5,
  },
  infoLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 16,
    marginTop: 16,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flex: 1,
    marginHorizontal: 6,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginLeft: 6,
  },
  safetyCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  safetyScoreContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  safetyScoreCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 4,
    borderColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  safetyScoreText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  safetyScoreLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 6,
  },
  safetyDetails: {
    marginBottom: 16,
  },
  safetyDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  safetyDetailLabel: {
    fontSize: 13,
    color: '#666',
    width: '40%',
  },
  safetyBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 4,
    marginRight: 8,
  },
  safetyBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  safetyDetailValue: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#333',
    width: 30,
    textAlign: 'right',
  },
  dangerousPointsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  dangerousPointsText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  viewSafetyButton: {
    backgroundColor: '#F5F8FF',
    borderRadius: 4,
    paddingVertical: 8,
    alignItems: 'center',
  },
  viewSafetyButtonText: {
    fontSize: 14,
    color: '#4A90E2',
    fontWeight: '500',
  },
  elevationCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  elevationGraph: {
    height: 100,
    marginBottom: 16,
  },
  elevationGraphPlaceholder: {
    backgroundColor: '#F5F5F5',
    height: '100%',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: '#999',
    fontSize: 14,
  },
  elevationDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  elevationItem: {
    alignItems: 'center',
  },
  elevationValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  elevationLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  fuelCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  fuelIconContainer: {
    backgroundColor: '#FFF9E6',
    padding: 10,
    borderRadius: 25,
    marginRight: 16,
  },
  fuelInfoContainer: {
    flex: 1,
  },
  fuelValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  fuelLabel: {
    fontSize: 13,
    color: '#999',
  },
  poiContainer: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  poiItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  poiIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FF9800',
    justifyContent: 'center',
    alignItems: 'center',
  },
  poiInfo: {
    flex: 1,
    marginLeft: 12,
  },
  poiName: {
    fontSize: 15,
    fontWeight: '500',
    color: '#333',
  },
  poiDescription: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  poiMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  poiMetaText: {
    fontSize: 12,
    color: '#999',
    marginLeft: 4,
    marginRight: 10,
  },
  poiRatingIcon: {
    marginLeft: 4,
  },
  metadataCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  metadataItem: {
    marginBottom: 12,
  },
  metadataLabel: {
    fontSize: 12,
    color: '#999',
    marginBottom: 2,
  },
  metadataValue: {
    fontSize: 14,
    color: '#333',
  },
  bottomPadding: {
    height: 40,
  },