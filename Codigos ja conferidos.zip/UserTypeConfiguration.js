/**
 * Configuração de permissões por tipo de usuário
 * Implementa níveis de acesso para diferentes funcionalidades
 * Integração com sistema de autenticação
 * Gerenciamento de usuários VIP
 */

// Tipos de usuário suportados pelo sistema
const USER_TYPES = {
  MOTORISTA_COMUM: 'MotoristaComum',
  MOTORISTA_VIP: 'MotoristaVIP',
  ADMINISTRADOR: 'Administrador'
};

// Níveis de acesso para funcionalidades
const ACCESS_LEVELS = {
  NO_ACCESS: 0,    // Sem acesso
  READ_ONLY: 1,    // Apenas visualização
  BASIC: 2,        // Acesso básico (criar/editar próprios recursos)
  ADVANCED: 3,     // Acesso avançado (criar/editar/compartilhar)
  FULL: 4          // Acesso completo (criar/editar/apagar/aprovar)
};

// Funcionalidades e recursos do sistema
const FEATURES = {
  // Módulo de Reportes
  REPORTS: 'reports',
  REPORTS_VIEW: 'reports.view',
  REPORTS_CREATE: 'reports.create',
  REPORTS_EDIT: 'reports.edit',
  REPORTS_DELETE: 'reports.delete',
  REPORTS_APPROVE: 'reports.approve',
  
  // Módulo de Navegação
  NAVIGATION: 'navigation',
  NAVIGATION_ROUTES: 'navigation.routes',
  NAVIGATION_SAVES: 'navigation.saves',
  NAVIGATION_SHARE: 'navigation.share',
  NAVIGATION_SPECIALIZED: 'navigation.specialized',
  
  // Módulo de Pesagem
  WEIGHING: 'weighing',
  WEIGHING_BASIC: 'weighing.basic',
  WEIGHING_ADVANCED: 'weighing.advanced',
  WEIGHING_EXPORT: 'weighing.export',
  
  // Módulo de POIs
  POI: 'poi',
  POI_VIEW: 'poi.view',
  POI_VIEW_VERIFIED: 'poi.view.verified',
  POI_VIEW_COMMUNITY: 'poi.view.community',
  POI_CREATE: 'poi.create',
  POI_APPROVE: 'poi.approve',
  
  // Módulo de Perfil do Motorista
  DRIVER_PROFILE: 'driverProfile',
  DRIVER_PROFILE_VIEW: 'driverProfile.view',
  DRIVER_PROFILE_EDIT: 'driverProfile.edit',
  DRIVER_PROFILE_HISTORY: 'driverProfile.history',
  DRIVER_PROFILE_ACHIEVEMENTS: 'driverProfile.achievements',
  
  // Módulo de Configurações
  SETTINGS: 'settings',
  SETTINGS_PREFERENCES: 'settings.preferences',
  SETTINGS_ACCOUNT: 'settings.account',
  SETTINGS_ADVANCED: 'settings.advanced',
  
  // Funcionalidades administrativas
  ADMIN: 'admin',
  ADMIN_USERS: 'admin.users',
  ADMIN_CONTENT: 'admin.content',
  ADMIN_SETTINGS: 'admin.settings',
  ADMIN_ANALYTICS: 'admin.analytics',
  
  // Integrações com outros apps da família King
  INTEGRATIONS: 'integrations',
  KING_SMS: 'integrations.kingsms',
  KING_LOC: 'integrations.kingloc',
  KING_CHAT: 'integrations.kingchat',
  KING_JOB: 'integrations.kingjob',
  KING_MUSIC: 'integrations.kingmusic',
  KING_SCAN: 'integrations.kingscan',
  KING_CARGO: 'integrations.kingcargo'
};

// Configuração de permissões por tipo de usuário
const permissions = {
  // Permissões para Motorista Comum
  [USER_TYPES.MOTORISTA_COMUM]: {
    // Módulo de Reportes
    [FEATURES.REPORTS]: ACCESS_LEVELS.BASIC,
    [FEATURES.REPORTS_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_CREATE]: ACCESS_LEVELS.BASIC,
    [FEATURES.REPORTS_EDIT]: ACCESS_LEVELS.BASIC,
    [FEATURES.REPORTS_DELETE]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.REPORTS_APPROVE]: ACCESS_LEVELS.NO_ACCESS,
    
    // Módulo de Navegação
    [FEATURES.NAVIGATION]: ACCESS_LEVELS.BASIC,
    [FEATURES.NAVIGATION_ROUTES]: ACCESS_LEVELS.BASIC,
    [FEATURES.NAVIGATION_SAVES]: ACCESS_LEVELS.BASIC,
    [FEATURES.NAVIGATION_SHARE]: ACCESS_LEVELS.BASIC,
    [FEATURES.NAVIGATION_SPECIALIZED]: ACCESS_LEVELS.NO_ACCESS,
    
    // Módulo de Pesagem
    [FEATURES.WEIGHING]: ACCESS_LEVELS.BASIC,
    [FEATURES.WEIGHING_BASIC]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_ADVANCED]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.WEIGHING_EXPORT]: ACCESS_LEVELS.BASIC,
    
    // Módulo de POIs
    [FEATURES.POI]: ACCESS_LEVELS.BASIC,
    [FEATURES.POI_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_VERIFIED]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_COMMUNITY]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_CREATE]: ACCESS_LEVELS.BASIC,
    [FEATURES.POI_APPROVE]: ACCESS_LEVELS.NO_ACCESS,
    
    // Módulo de Perfil do Motorista
    [FEATURES.DRIVER_PROFILE]: ACCESS_LEVELS.BASIC,
    [FEATURES.DRIVER_PROFILE_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_EDIT]: ACCESS_LEVELS.BASIC,
    [FEATURES.DRIVER_PROFILE_HISTORY]: ACCESS_LEVELS.BASIC,
    [FEATURES.DRIVER_PROFILE_ACHIEVEMENTS]: ACCESS_LEVELS.BASIC,
    
    // Módulo de Configurações
    [FEATURES.SETTINGS]: ACCESS_LEVELS.BASIC,
    [FEATURES.SETTINGS_PREFERENCES]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_ACCOUNT]: ACCESS_LEVELS.BASIC,
    [FEATURES.SETTINGS_ADVANCED]: ACCESS_LEVELS.NO_ACCESS,
    
    // Funcionalidades administrativas
    [FEATURES.ADMIN]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_USERS]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_CONTENT]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_SETTINGS]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_ANALYTICS]: ACCESS_LEVELS.NO_ACCESS,
    
    // Integrações com outros apps da família King
    [FEATURES.INTEGRATIONS]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_SMS]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_LOC]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_CHAT]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_JOB]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_MUSIC]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_SCAN]: ACCESS_LEVELS.BASIC,
    [FEATURES.KING_CARGO]: ACCESS_LEVELS.BASIC
  },
  
  // Permissões para Motorista VIP
  [USER_TYPES.MOTORISTA_VIP]: {
    // Módulo de Reportes
    [FEATURES.REPORTS]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.REPORTS_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_CREATE]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.REPORTS_EDIT]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.REPORTS_DELETE]: ACCESS_LEVELS.BASIC,
    [FEATURES.REPORTS_APPROVE]: ACCESS_LEVELS.NO_ACCESS,
    
    // Módulo de Navegação
    [FEATURES.NAVIGATION]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.NAVIGATION_ROUTES]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SAVES]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SHARE]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SPECIALIZED]: ACCESS_LEVELS.FULL,
    
    // Módulo de Pesagem
    [FEATURES.WEIGHING]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.WEIGHING_BASIC]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_ADVANCED]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_EXPORT]: ACCESS_LEVELS.FULL,
    
    // Módulo de POIs
    [FEATURES.POI]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.POI_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_VERIFIED]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_COMMUNITY]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_CREATE]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.POI_APPROVE]: ACCESS_LEVELS.NO_ACCESS,
    
    // Módulo de Perfil do Motorista
    [FEATURES.DRIVER_PROFILE]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.DRIVER_PROFILE_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_EDIT]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_HISTORY]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_ACHIEVEMENTS]: ACCESS_LEVELS.FULL,
    
    // Módulo de Configurações
    [FEATURES.SETTINGS]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.SETTINGS_PREFERENCES]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_ACCOUNT]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_ADVANCED]: ACCESS_LEVELS.BASIC,
    
    // Funcionalidades administrativas
    [FEATURES.ADMIN]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_USERS]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_CONTENT]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_SETTINGS]: ACCESS_LEVELS.NO_ACCESS,
    [FEATURES.ADMIN_ANALYTICS]: ACCESS_LEVELS.NO_ACCESS,
    
    // Integrações com outros apps da família King
    [FEATURES.INTEGRATIONS]: ACCESS_LEVELS.ADVANCED,
    [FEATURES.KING_SMS]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_LOC]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_CHAT]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_JOB]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_MUSIC]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_SCAN]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_CARGO]: ACCESS_LEVELS.FULL
  },
  
  // Permissões para Administrador
  [USER_TYPES.ADMINISTRADOR]: {
    // Módulo de Reportes
    [FEATURES.REPORTS]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_CREATE]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_EDIT]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_DELETE]: ACCESS_LEVELS.FULL,
    [FEATURES.REPORTS_APPROVE]: ACCESS_LEVELS.FULL,
    
    // Módulo de Navegação
    [FEATURES.NAVIGATION]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_ROUTES]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SAVES]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SHARE]: ACCESS_LEVELS.FULL,
    [FEATURES.NAVIGATION_SPECIALIZED]: ACCESS_LEVELS.FULL,
    
    // Módulo de Pesagem
    [FEATURES.WEIGHING]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_BASIC]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_ADVANCED]: ACCESS_LEVELS.FULL,
    [FEATURES.WEIGHING_EXPORT]: ACCESS_LEVELS.FULL,
    
    // Módulo de POIs
    [FEATURES.POI]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_VERIFIED]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_VIEW_COMMUNITY]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_CREATE]: ACCESS_LEVELS.FULL,
    [FEATURES.POI_APPROVE]: ACCESS_LEVELS.FULL,
    
    // Módulo de Perfil do Motorista
    [FEATURES.DRIVER_PROFILE]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_VIEW]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_EDIT]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_HISTORY]: ACCESS_LEVELS.FULL,
    [FEATURES.DRIVER_PROFILE_ACHIEVEMENTS]: ACCESS_LEVELS.FULL,
    
    // Módulo de Configurações
    [FEATURES.SETTINGS]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_PREFERENCES]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_ACCOUNT]: ACCESS_LEVELS.FULL,
    [FEATURES.SETTINGS_ADVANCED]: ACCESS_LEVELS.FULL,
    
    // Funcionalidades administrativas
    [FEATURES.ADMIN]: ACCESS_LEVELS.FULL,
    [FEATURES.ADMIN_USERS]: ACCESS_LEVELS.FULL,
    [FEATURES.ADMIN_CONTENT]: ACCESS_LEVELS.FULL,
    [FEATURES.ADMIN_SETTINGS]: ACCESS_LEVELS.FULL,
    [FEATURES.ADMIN_ANALYTICS]: ACCESS_LEVELS.FULL,
    
    // Integrações com outros apps da família King
    [FEATURES.INTEGRATIONS]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_SMS]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_LOC]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_CHAT]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_JOB]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_MUSIC]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_SCAN]: ACCESS_LEVELS.FULL,
    [FEATURES.KING_CARGO]: ACCESS_LEVELS.FULL
  }
};

// Descrição de recursos para exibição na interface
const featureDescriptions = {
  [FEATURES.REPORTS]: 'Gerenciamento de reportes e ocorrências',
  [FEATURES.NAVIGATION]: 'Sistema de navegação e rotas',
  [FEATURES.WEIGHING]: 'Sistema de pesagem inteligente',
  [FEATURES.POI]: 'Gerenciamento de pontos de interesse',
  [FEATURES.DRIVER_PROFILE]: 'Perfil e histórico do motorista',
  [FEATURES.SETTINGS]: 'Configurações do aplicativo',
  [FEATURES.ADMIN]: 'Ferramentas administrativas',
  [FEATURES.INTEGRATIONS]: 'Integrações com a família King'
};

// Descrição de níveis de acesso para exibição na interface
const accessLevelDescriptions = {
  [ACCESS_LEVELS.NO_ACCESS]: 'Sem acesso',
  [ACCESS_LEVELS.READ_ONLY]: 'Somente leitura',
  [ACCESS_LEVELS.BASIC]: 'Acesso básico',
  [ACCESS_LEVELS.ADVANCED]: 'Acesso avançado',
  [ACCESS_LEVELS.FULL]: 'Acesso completo'
};

// Benefícios de cada tipo de usuário
const userTypeBenefits = {
  [USER_TYPES.MOTORISTA_COMUM]: [
    'Acesso às funcionalidades básicas de navegação',
    'Consulta a pontos de interesse verificados',
    'Sistema básico de pesagem',
    'Compartilhamento limitado de informações',
    'Integração com todos os aplicativos da família King'
  ],
  [USER_TYPES.MOTORISTA_VIP]: [
    'Todas as funcionalidades do Motorista Comum',
    'Acesso a rotas especializadas para veículos pesados',
    'Pontos de interesse exclusivos para VIP',
    'Sistema avançado de pesagem com alertas inteligentes',
    'Exportação de relatórios detalhados',
    'Acesso prioritário aos recursos de todos os aplicativos da família King',
    'Suporte prioritário 24/7'
  ],
  [USER_TYPES.ADMINISTRADOR]: [
    'Acesso completo a todas as funcionalidades',
    'Gerenciamento de usuários',
    'Aprovação de conteúdo gerado pela comunidade',
    'Ferramentas avançadas de análise e relatórios',
    'Configuração do sistema',
    'Acesso administrativo a todos os aplicativos da família King'
  ]
};

/**
 * Verifica se um usuário tem permissão para acessar um recurso específico
 * @param {string} userType - Tipo de usuário
 * @param {string} feature - Recurso a ser verificado
 * @param {number} requiredLevel - Nível de acesso necessário (opcional)
 * @returns {boolean} - Verdadeiro se tiver permissão, falso caso contrário
 */
function hasPermission(userType, feature, requiredLevel = ACCESS_LEVELS.BASIC) {
  // Se o tipo de usuário não existir, negar acesso
  if (!permissions[userType]) {
    return false;
  }
  
  // Se o recurso específico não estiver definido, verificar o recurso pai
  if (!permissions[userType][feature]) {
    // Extrair o recurso pai (ex: 'reports.view' -> 'reports')
    const parentFeature = feature.split('.')[0];
    
    // Se o recurso pai não estiver definido, negar acesso
    if (!permissions[userType][parentFeature]) {
      return false;
    }
    
    // Verificar se o nível de acesso ao recurso pai é suficiente
    return permissions[userType][parentFeature] >= requiredLevel;
  }
  
  // Verificar se o nível de acesso ao recurso específico é suficiente
  return permissions[userType][feature] >= requiredLevel;
}

/**
 * Obtém todas as permissões para um tipo de usuário específico
 * @param {string} userType - Tipo de usuário
 * @returns {Object} - Objeto com todas as permissões do usuário
 */
function getUserPermissions(userType) {
  return permissions[userType] || {};
}

/**
 * Verifica se o usuário é VIP
 * @param {string} userType - Tipo de usuário
 * @returns {boolean} - Verdadeiro se for VIP, falso caso contrário
 */
function isVipUser(userType) {
  return userType === USER_TYPES.MOTORISTA_VIP;
}

/**
 * Verifica se o usuário é administrador
 * @param {string} userType - Tipo de usuário
 * @returns {boolean} - Verdadeiro se for administrador, falso caso contrário
 */
function isAdminUser(userType) {
  return userType === USER_TYPES.ADMINISTRADOR;
}

/**
 * Obtém os benefícios de um tipo de usuário específico
 * @param {string} userType - Tipo de usuário
 * @returns {Array} - Lista de benefícios do tipo de usuário
 */
function getUserBenefits(userType) {
  return userTypeBenefits[userType] || [];
}

/**
 * Obtém a descrição de um recurso
 * @param {string} feature - Recurso
 * @returns {string} - Descrição do recurso
 */
function getFeatureDescription(feature) {
  return featureDescriptions[feature] || feature;
}

/**
 * Obtém a descrição de um nível de acesso
 * @param {number} accessLevel - Nível de acesso
 * @returns {string} - Descrição do nível de acesso
 */
function getAccessLevelDescription(accessLevel) {
  return accessLevelDescriptions[accessLevel] || `Nível ${accessLevel}`;
}

/**
 * Obtém todos os tipos de usuário disponíveis
 * @returns {Object} - Objeto com todos os tipos de usuário
 */
function getAllUserTypes() {
  return USER_TYPES;
}

/**
 * Obtém todos os níveis de acesso disponíveis
 * @returns {Object} - Objeto com todos os níveis de acesso
 */
function getAllAccessLevels() {
  return ACCESS_LEVELS;
}

/**
 * Obtém todos os recursos disponíveis
 * @returns {Object} - Objeto com todos os recursos
 */
function getAllFeatures() {
  return FEATURES;
}

// Exportar constantes e funções
export {
  USER_TYPES,
  ACCESS_LEVELS,
  FEATURES,
  hasPermission,
  getUserPermissions,
  isVipUser,
  isAdminUser,
  getUserBenefits,
  getFeatureDescription,
  getAccessLevelDescription,
  getAllUserTypes,
  getAllAccessLevels,
  getAllFeatures
};