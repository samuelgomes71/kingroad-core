package com.kingroad.cache

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.util.LruCache
import androidx.annotation.WorkerThread
import com.kingroad.database.CachedImage
import com.kingroad.database.CachedImageDao
import com.kingroad.utils.FileUtils
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection

/**
 * Gerencia o download e armazenamento de imagens de satélite (por rota ou POI).
 * Inclui TTL (tempo de expiração) e identificador local.
 */
class ImageCacheManager(
    private val context: Context,
    private val cachedImageDao: CachedImageDao,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher)
) {
    companion object {
        private const val TAG = "ImageCacheManager"
        private const val IMAGE_CACHE_DIR = "image_cache"
        
        // Tamanho padrão para o cache de memória (25% da memória disponível para o app)
        private val DEFAULT_MEMORY_CACHE_SIZE = (Runtime.getRuntime().maxMemory() / 4).toInt()
        
        // TTL padrão para imagens (7 dias)
        private val DEFAULT_TTL_MILLIS = TimeUnit.DAYS.toMillis(7)
        
        // Tamanho máximo do cache em disco (100 MB)
        private const val MAX_DISK_CACHE_SIZE_BYTES = 100 * 1024 * 1024L
        
        // Tipos de imagens suportados
        enum class ImageType(val extension: String) {
            SATELLITE("sat"),      // Imagens de satélite
            POI("poi"),           // Pontos de interesse
            ROUTE("route"),       // Rotas
            THUMBNAIL("thumb"),   // Miniaturas
            TERRAIN("terrain"),   // Terreno
            TRAFFIC("traffic")    // Tráfego
        }
    }

    // Cache para armazenar imagens em memória
    private val memoryCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(DEFAULT_MEMORY_CACHE_SIZE) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            // Retorna o tamanho do bitmap em KB
            return bitmap.byteCount / 1024
        }
    }
    
    // Diretório principal para armazenamento de imagens
    private val imageCacheDir: File by lazy {
        File(context.filesDir, IMAGE_CACHE_DIR).apply {
            if (!exists()) mkdirs()
        }
    }
    
    // Mapa para controlar downloads em andamento
    private val ongoingDownloads = ConcurrentHashMap<String, Job>()
    
    // Controla o estado de download atual
    private val _downloadProgress = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadProgress: StateFlow<DownloadState> = _downloadProgress.asStateFlow()

    init {
        // Inicialização: criar diretórios para cada tipo de imagem
        scope.launch {
            // Cria diretórios para cada tipo
            ImageType.values().forEach { type ->
                val typeDir = File(imageCacheDir, type.name.lowercase())
                if (!typeDir.exists()) {
                    typeDir.mkdirs()
                }
            }
            
            // Limpa imagens expiradas no startup
            cleanExpiredImages()
        }
    }

    /**
     * Obtém uma imagem do cache ou baixa se necessário
     * @param url URL da imagem
     * @param imageType Tipo da imagem
     * @param ttlMillis Tempo de vida da imagem em cache (milissegundos)
     * @param forceRefresh Se true, ignora o cache e baixa novamente
     * @return Job que pode ser aguardado para obter o caminho da imagem
     */
    fun getImage(
        url: String,
        imageType: ImageType = ImageType.SATELLITE,
        ttlMillis: Long = DEFAULT_TTL_MILLIS,
        forceRefresh: Boolean = false
    ): Job {
        val imageId = generateImageId(url)
        
        // Se já existe um download em andamento para esta imagem, retorna o job existente
        ongoingDownloads[imageId]?.let { existingJob ->
            if (existingJob.isActive) {
                return existingJob
            }
        }
        
        val job = scope.launch {
            try {
                // Verifica se a imagem já está em cache de memória
                val cachedBitmap = if (!forceRefresh) memoryCache.get(imageId) else null
                
                if (cachedBitmap != null) {
                    _downloadProgress.value = DownloadState.Completed(
                        id = imageId,
                        imageUrl = url,
                        localPath = getCacheFilePath(imageId, imageType)
                    )
                    return@launch
                }
                
                // Verifica se a imagem já está em cache de disco e não expirou
                val cachedImage = if (!forceRefresh) cachedImageDao.getByUrl(url) else null
                
                if (cachedImage != null && !isExpired(cachedImage, ttlMillis)) {
                    // Verifica se o arquivo existe
                    val file = File(cachedImage.localPath)
                    if (file.exists()) {
                        // Carrega a imagem do disco para a memória
                        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                        if (bitmap != null) {
                            memoryCache.put(imageId, bitmap)
                            _downloadProgress.value = DownloadState.Completed(
                                id = imageId,
                                imageUrl = url,
                                localPath = cachedImage.localPath
                            )
                            return@launch
                        }
                    }
                }
                
                // Precisa baixar a imagem
                downloadImage(url, imageId, imageType, ttlMillis)
            } finally {
                ongoingDownloads.remove(imageId)
            }
        }
        
        ongoingDownloads[imageId] = job
        return job
    }
    
    /**
     * Baixa uma imagem da URL fornecida
     */
    private suspend fun downloadImage(
        url: String,
        imageId: String,
        imageType: ImageType,
        ttlMillis: Long
    ) {
        if (!NetworkUtils.isConnected(context)) {
            _downloadProgress.value = DownloadState.Failed(
                id = imageId,
                imageUrl = url,
                error = "Sem conexão com a internet"
            )
            return
        }
        
        _downloadProgress.value = DownloadState.Started(
            id = imageId,
            imageUrl = url
        )
        
        // Caminho do arquivo para salvar a imagem
        val filePath = getCacheFilePath(imageId, imageType)
        val imageFile = File(filePath)
        
        // Garante que o diretório existe
        imageFile.parentFile?.mkdirs()
        
        try {
            withContext(dispatcher) {
                // Abre conexão com a URL
                val connection = URL(url).openConnection() as HttpsURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.doInput = true
                connection.connect()
                
                val responseCode = connection.responseCode
                if (responseCode != HttpsURLConnection.HTTP_OK) {
                    throw IOException("HTTP error code: $responseCode")
                }
                
                // Obtém o tamanho total do arquivo, se disponível
                val fileLength = connection.contentLength.toLong()
                
                // Inicia o download
                connection.inputStream.use { input ->
                    FileOutputStream(imageFile).use { output ->
                        val buffer = ByteArray(4 * 1024) // 4K buffer
                        var bytesRead: Int
                        var totalBytesRead: Long = 0
                        
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            totalBytesRead += bytesRead
                            
                            // Atualiza o progresso
                            if (fileLength > 0) {
                                val progress = (totalBytesRead * 100 / fileLength).toInt()
                                _downloadProgress.value = DownloadState.Progress(
                                    id = imageId,
                                    imageUrl = url,
                                    progress = progress
                                )
                            }
                        }
                        
                        output.flush()
                    }
                }
                
                // Carrega a imagem na memória cache
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
                if (bitmap != null) {
                    memoryCache.put(imageId, bitmap)
                }
                
                // Salva as informações da imagem no banco de dados
                val cachedImage = CachedImage(
                    url = url,
                    localPath = filePath,
                    imageType = imageType.name,
                    timestamp = System.currentTimeMillis(),
                    fileSize = imageFile.length(),
                    ttl = ttlMillis
                )
                
                cachedImageDao.insert(cachedImage)
                
                // Atualiza estado para concluído
                _downloadProgress.value = DownloadState.Completed(
                    id = imageId,
                    imageUrl = url,
                    localPath = filePath
                )
                
                // Verifica se precisa limpar o cache
                if (isDiskCacheFull()) {
                    scope.launch {
                        clearOldestImages()
                    }
                }
            }
        } catch (e: Exception) {
            // Em caso de falha, remove o arquivo parcial se existir
            if (imageFile.exists()) {
                imageFile.delete()
            }
            
            Log.e(TAG, "Erro ao baixar imagem: ${e.message}", e)
            _downloadProgress.value = DownloadState.Failed(
                id = imageId,
                imageUrl = url,
                error = e.message ?: "Erro desconhecido"
            )
        }
    }
    
    /**
     * Cancela o download de uma imagem
     * @param url URL da imagem
     * @return true se cancelado com sucesso
     */
    fun cancelDownload(url: String): Boolean {
        val imageId = generateImageId(url)
        val job = ongoingDownloads[imageId] ?: return false
        
        if (job.isActive) {
            job.cancel()
            ongoingDownloads.remove(imageId)
            
            _downloadProgress.value = DownloadState.Cancelled(
                id = imageId,
                imageUrl = url
            )
            
            return true
        }
        
        return false
    }
    
    /**
     * Cancela todos os downloads em andamento
     */
    fun cancelAllDownloads() {
        ongoingDownloads.forEach { (imageId, job) ->
            if (job.isActive) {
                job.cancel()
                
                _downloadProgress.value = DownloadState.Cancelled(
                    id = imageId,
                    imageUrl = "unknown" // Não temos a URL aqui, apenas o ID
                )
            }
        }
        ongoingDownloads.clear()
    }
    
    /**
     * Limpa todas as imagens do cache
     */
    suspend fun clearAllImages() {
        withContext(dispatcher) {
            // Cancela downloads em andamento
            cancelAllDownloads()
            
            // Limpa cache de memória
            memoryCache.evictAll()
            
            // Limpa cache de disco
            cachedImageDao.deleteAll()
            
            // Remove arquivos
            if (imageCacheDir.exists()) {
                imageCacheDir.deleteRecursively()
                imageCacheDir.mkdirs()
                
                // Recria diretórios
                ImageType.values().forEach { type ->
                    File(imageCacheDir, type.name.lowercase()).mkdirs()
                }
            }
        }
    }
    
    /**
     * Limpa imagens expiradas do cache
     */
    suspend fun cleanExpiredImages() {
        withContext(dispatcher) {
            val currentTime = System.currentTimeMillis()
            val expiredImages = cachedImageDao.getAllImages().filter { image ->
                isExpired(image)
            }
            
            if (expiredImages.isNotEmpty()) {
                Log.d(TAG, "Removendo ${expiredImages.size} imagens expiradas do cache")
                
                expiredImages.forEach { image ->
                    // Remove do banco de dados
                    cachedImageDao.delete(image)
                    
                    // Remove o arquivo
                    val file = File(image.localPath)
                    if (file.exists()) {
                        file.delete()
                    }
                    
                    // Remove da memória cache
                    memoryCache.remove(generateImageId(image.url))
                }
            }
        }
    }
    
    /**
     * Limpa imagens mais antigas quando o cache atinge o limite
     */
    @WorkerThread
    private suspend fun clearOldestImages() {
        withContext(dispatcher) {
            // Obtém todas as imagens ordenadas por timestamp (mais antigas primeiro)
            val images = cachedImageDao.getAllImagesSortedByTimestamp()
            var currentSize = getDiskCacheSize()
            val targetSize = MAX_DISK_CACHE_SIZE_BYTES * 0.8 // Reduz para 80% do máximo
            
            for (image in images) {
                if (currentSize <= targetSize) {
                    break
                }
                
                val file = File(image.localPath)
                if (file.exists()) {
                    val fileSize = file.length()
                    if (file.delete()) {
                        currentSize -= fileSize
                        cachedImageDao.delete(image)
                        memoryCache.remove(generateImageId(image.url))
                        
                        Log.d(TAG, "Removida imagem antiga: ${image.url}, liberados ${fileSize / 1024} KB")
                    }
                }
            }
        }
    }
    
    /**
     * Obtém todas as imagens em cache de um determinado tipo
     */
    fun getImagesByType(imageType: ImageType): Flow<List<CachedImage>> {
        return cachedImageDao.getImagesByType(imageType.name)
    }
    
    /**
     * Verifica se uma imagem está em cache
     * @param url URL da imagem
     * @return true se a imagem estiver em cache e não expirada
     */
    suspend fun isImageCached(url: String, ttlMillis: Long = DEFAULT_TTL_MILLIS): Boolean {
        // Primeiro verifica o cache de memória
        val imageId = generateImageId(url)
        if (memoryCache.get(imageId) != null) {
            return true
        }
        
        // Depois verifica o cache de disco
        val cachedImage = cachedImageDao.getByUrl(url) ?: return false
        
        // Verifica se expirou
        if (isExpired(cachedImage, ttlMillis)) {
            return false
        }
        
        // Verifica se o arquivo existe
        val file = File(cachedImage.localPath)
        return file.exists()
    }
    
    /**
     * Precarrega um conjunto de imagens para uso offline
     * @param urls Lista de URLs para precarregar
     * @param imageType Tipo das imagens
     * @param ttlMillis Tempo de vida das imagens
     * @return Job que pode ser aguardado para saber quando todas as imagens foram baixadas
     */
    fun preloadImages(
        urls: List<String>,
        imageType: ImageType = ImageType.SATELLITE,
        ttlMillis: Long = DEFAULT_TTL_MILLIS
    ): Job {
        return scope.launch {
            val jobs = urls.map { url ->
                getImage(url, imageType, ttlMillis)
            }
            
            jobs.forEach { it.join() }
        }
    }
    
    /**
     * Gera um ID único para a imagem baseado na URL
     */
    private fun generateImageId(url: String): String {
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(url.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
    
    /**
     * Gera o caminho do arquivo para armazenar a imagem em cache
     */
    private fun getCacheFilePath(imageId: String, imageType: ImageType): String {
        val typeDir = File(imageCacheDir, imageType.name.lowercase())
        if (!typeDir.exists()) {
            typeDir.mkdirs()
        }
        
        return File(typeDir, "$imageId.${imageType.extension}").absolutePath
    }
    
    /**
     * Verifica se uma imagem em cache expirou
     */
    private fun isExpired(cachedImage: CachedImage, ttlMillis: Long = cachedImage.ttl): Boolean {
        val currentTime = System.currentTimeMillis()
        return currentTime - cachedImage.timestamp > ttlMillis
    }
    
    /**
     * Verifica se o cache em disco está cheio
     */
    private fun isDiskCacheFull(): Boolean {
        val cacheSize = getDiskCacheSize()
        return cacheSize > MAX_DISK_CACHE_SIZE_BYTES
    }
    
    /**
     * Obtém o tamanho atual do cache em disco
     */
    private fun getDiskCacheSize(): Long {
        return FileUtils.getFolderSizeInBytes(imageCacheDir)
    }
    
    /**
     * Classe que representa estados de download
     */
    sealed class DownloadState {
        object Idle : DownloadState()
        
        data class Started(
            val id: String,
            val imageUrl: String
        ) : DownloadState()
        
        data class Progress(
            val id: String,
            val imageUrl: String,
            val progress: Int
        ) : DownloadState()
        
        data class Completed(
            val id: String,
            val imageUrl: String,
            val localPath: String
        ) : DownloadState()
        
        data class Failed(
            val id: String,
            val imageUrl: String,
            val error: String
        ) : DownloadState()
        
        data class Cancelled(
            val id: String,
            val imageUrl: String
        ) : DownloadState()
    }
    
    /**
     * Libera recursos quando o gerenciador não é mais necessário
     */
    fun shutdown() {
        cancelAllDownloads()
        scope.cancel()
        memoryCache.evictAll()
    }
}