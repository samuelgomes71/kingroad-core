package com.kingroad.security.alerts.brazil

import com.kingroad.security.alerts.SecurityAlertService
import com.kingroad.security.location.LocationService
import com.kingroad.security.reputation.ReputationService
import com.kingroad.security.users.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.time.Duration.Companion.minutes

/**
 * Serviço que gerencia alertas de segurança específicos para o Brasil
 */
class BrazilSecurityAlertService(
    private val repository: BrazilSecurityAlertRepository,
    private val locationService: LocationService,
    private val reputationService: ReputationService,
    private val configuration: BrazilAlertConfiguration = BrazilAlertConfiguration.DEFAULT,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    // Flow para emitir alertas em tempo real
    private val _realTimeAlerts = MutableSharedFlow<BrazilSecurityAlert>()
    val realTimeAlerts: Flow<BrazilSecurityAlert> = _realTimeAlerts
    
    /**
     * Cria um novo alerta de segurança
     */
    suspend fun createAlert(alert: BrazilSecurityAlert): BrazilSecurityAlert {
        val savedAlert = repository.saveAlert(alert)
        
        // Emitir alerta em tempo real para outros usuários
        coroutineScope.launch {
            _realTimeAlerts.emit(savedAlert)
        }
        
        return savedAlert
    }
    
    /**
     * Obtém alertas por tipo
     */
    suspend fun getAlertsByType(type: BrazilAlertType): List<BrazilSecurityAlert> {
        return repository.getAlertsByType(type)
    }
    
    /**
     * Obtém alertas recentes (não expirados) em uma determinada área
     */
    suspend fun getActiveAlertsInArea(
        latitude: Double,
        longitude: Double,
        radiusInMeters: Double
    ): List<BrazilSecurityAlert> {
        val allAlerts = repository.getAllAlerts()
        val now = Clock.System.now()
        
        return allAlerts.filter { alert ->
            // Verificar se o alerta está dentro do raio especificado
            val distance = calculateDistance(
                latitude, longitude,
                alert.latitude, alert.longitude
            )
            
            // Verificar se o alerta ainda não expirou
            val expirationTime = configuration.alertExpirationTime[alert.type] ?: 60L
            val expirationInstant = alert.timestamp.plus(expirationTime.minutes)
            
            distance <= radiusInMeters && now < expirationInstant
        }
    }
    
    /**
     * Obtém alertas relevantes para um usuário com base em sua localização
     */
    suspend fun getRelevantAlertsForUser(userId: String): Flow<BrazilSecurityAlert> {
        return locationService.getUserLocationUpdates(userId)
            .map { location ->
                // Para cada atualização de localização, encontrar alertas relevantes
                val relevantAlerts = mutableListOf<BrazilSecurityAlert>()
                
                for (type in BrazilAlertType.values()) {
                    val radius = configuration.notificationRadius[type] ?: 5000.0
                    val alertsOfType = getActiveAlertsInArea(location.latitude, location.longitude, radius)
                    relevantAlerts.addAll(alertsOfType)
                }
                
                relevantAlerts
            }
            .filter { it.isNotEmpty() }
            .map { it.sortedBy { alert -> configuration.alertPriority[alert.type] ?: 999 }.first() }
    }
    
    /**
     * Atualiza um alerta existente
     */
    suspend fun updateAlert(alert: BrazilSecurityAlert): BrazilSecurityAlert {
        return repository.updateAlert(alert)
    }
    
    /**
     * Verifica um alerta (confirma ou contradiz)
     */
    suspend fun verifyAlert(alertId: String, userId: String, isConfirmed: Boolean): BrazilSecurityAlert {
        val alert = repository.getAlertById(alertId)
            ?: throw IllegalArgumentException("Alerta não encontrado: $alertId")
        
        // Atualizar contadores de verificação
        val updatedAlert = alert.copy(
            verificationCount = alert.verificationCount + 1,
            confirmationCount = alert.confirmationCount + (if (isConfirmed) 1 else 0),
            isVerified = alert.verificationCount >= 2 && 
                (alert.confirmationCount.toDouble() / alert.verificationCount.toDouble() >= 0.7)
        )
        
        return repository.updateAlert(updatedAlert)
    }
    
    /**
     * Resolve um alerta (marca como resolvido/finalizado)
     */
    suspend fun resolveAlert(alertId: String, resolution: String? = null): BrazilSecurityAlert {
        val alert = repository.getAlertById(alertId)
            ?: throw IllegalArgumentException("Alerta não encontrado: $alertId")
        
        // Dependendo do tipo de alerta, atualizar os campos específicos
        val updatedAlert = when (alert.type) {
            BrazilAlertType.SHOOTING -> alert.copy(
                shootingInfo = alert.shootingInfo?.copy(isOngoing = false)
            )
            BrazilAlertType.KIDNAPPING -> alert.copy(
                kidnappingInfo = alert.kidnappingInfo?.copy(isOngoing = false)
            )
            else -> alert
        }
        
        return repository.updateAlert(updatedAlert)
    }
    
    /**
     * Calcula a distância entre dois pontos geográficos usando a fórmula de Haversine
     */
    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val earthRadius = 6371000.0 // Em metros
        
        val lat1Rad = lat1 * PI / 180
        val lat2Rad = lat2 * PI / 180
        val deltaLat = (lat2 - lat1) * PI / 180
        val deltaLon = (lon2 - lon1) * PI / 180
        
        val a = sin(deltaLat / 2) * sin(deltaLat / 2) +
                cos(lat1Rad) * cos(lat2Rad) *
                sin(deltaLon / 2) * sin(deltaLon / 2)
        val c = 2 * kotlin.math.atan2(sqrt(a), sqrt(1 - a))
        
        return earthRadius * c
    }
}

/**
 * Interface para o repositório de alertas brasileiros
 */
interface BrazilSecurityAlertRepository {
    suspend fun getAllAlerts(): List<BrazilSecurityAlert>
    suspend fun getAlertById(id: String): BrazilSecurityAlert?
    suspend fun getAlertsByType(type: BrazilAlertType): List<BrazilSecurityAlert>
    suspend fun saveAlert(alert: BrazilSecurityAlert): BrazilSecurityAlert
    suspend fun updateAlert(alert: BrazilSecurityAlert): BrazilSecurityAlert
    suspend fun deleteAlert(id: String)
    suspend fun getAlertsByUserId(userId: String): List<BrazilSecurityAlert>
}