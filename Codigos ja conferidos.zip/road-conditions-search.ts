// Parte 2: Rotas para buscar e votar nas condições de estrada reportadas
import express from 'express';
import { body, param, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { RoadConditionRepository } from '../repositories/roadConditionRepository';

const router = express.Router();
const roadConditionRepo = new RoadConditionRepository();

/**
 * @route   GET /api/road-conditions/nearby
 * @desc    Obter condições de estrada próximas às coordenadas fornecidas
 * @access  Private (requer autenticação)
 */
router.get(
  '/nearby',
  authenticate,
  [
    body('latitude').isFloat({ min: -90, max: 90 }).withMessage('Latitude inválida'),
    body('longitude').isFloat({ min: -180, max: 180 }).withMessage('Longitude inválida'),
    body('radius').optional().isNumeric({ min: 1, max: 100 }).withMessage('Raio inválido (1-100km)'),
    body('types').optional().isArray().withMessage('Tipos deve ser um array')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { latitude, longitude, radius = 10, types } = req.body;

      // Obter condições próximas
      const conditions = await roadConditionRepo.findNearby(
        latitude,
        longitude,
        radius,
        types
      );

      // Filtrar condições expiradas
      const validConditions = conditions.filter(condition => {
        if (!condition.expectedDuration) return true;
        const expiryTime = new Date(condition.createdAt);
        expiryTime.setHours(expiryTime.getHours() + condition.expectedDuration);
        return expiryTime > new Date();
      });

      res.json(validConditions);
    } catch (error) {
      console.error('Erro ao buscar condições próximas:', error);
      res.status(500).json({ message: 'Erro ao buscar condições próximas' });
    }
  }
);

/**
 * @route   GET /api/road-conditions/route
 * @desc    Obter condições ao longo de uma rota específica
 * @access  Private (requer autenticação)
 */
router.post(
  '/route',
  authenticate,
  [
    body('route').isArray().withMessage('Rota deve ser um array de coordenadas'),
    body('route.*.latitude').isFloat({ min: -90, max: 90 }).withMessage('Latitude inválida'),
    body('route.*.longitude').isFloat({ min: -180, max: 180 }).withMessage('Longitude inválida'),
    body('bufferDistance').optional().isNumeric({ min: 0.1, max: 5 }).withMessage('Distância de buffer inválida (0.1-5km)')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { route, bufferDistance = 1 } = req.body;
      
      // Obter condições ao longo da rota
      const conditions = await roadConditionRepo.findAlongRoute(route, bufferDistance);
      
      res.json(conditions);
    } catch (error) {
      console.error('Erro ao buscar condições na rota:', error);
      res.status(500).json({ message: 'Erro ao buscar condições na rota' });
    }
  }
);

/**
 * @route   PUT /api/road-conditions/:id/vote
 * @desc    Votar em uma condição de estrada (confirmar ou refutar)
 * @access  Private (requer autenticação)
 */
router.put(
  '/:id/vote',
  authenticate,
  [
    param('id').isMongoId().withMessage('ID de condição inválido'),
    body('vote').isIn(['up', 'down']).withMessage('Voto deve ser "up" ou "down"')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { id } = req.params;
      const { vote } = req.body;
      const userId = req.user.id;

      // Verificar se o usuário já votou
      const condition = await roadConditionRepo.findById(id);
      if (!condition) {
        return res.status(404).json({ message: 'Condição não encontrada' });
      }

      // Verificar se usuário já votou 
      if (condition.votes && condition.votes.some(v => v.userId === userId)) {
        return res.status(400).json({ message: 'Você já votou nesta condição' });
      }

      // Registrar voto
      const updatedCondition = await roadConditionRepo.addVote(id, userId, vote);
      
      // Se condição recebeu muitos downvotes, remover
      if (updatedCondition.downvotes >= 5 && updatedCondition.upvotes / updatedCondition.downvotes < 0.3) {
        await roadConditionRepo.markAsRemoved(id);
        return res.json({ message: 'Condição removida por baixa confiabilidade' });
      }

      res.json(updatedCondition);
    } catch (error) {
      console.error('Erro ao votar em condição:', error);
      res.status(500).json({ message: 'Erro ao processar voto' });
    }
  }
);

export default router;