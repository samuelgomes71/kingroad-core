// privacy.routes.js
// Rotas para gerenciamento de configurações de privacidade no KingChat

const express = require('express');
const router = express.Router();
const privacyController = require('../controllers/privacy.controller');
const authMiddleware = require('../middleware/auth');

// Aplicar middleware de autenticação a todas as rotas de privacidade
router.use(authMiddleware);

// Obter configurações de privacidade do usuário
router.get('/settings', privacyController.getPrivacySettings);

// Atualizar configurações de privacidade do usuário (configuração geral)
router.put('/settings', privacyController.updatePrivacySettings);

// Atualizar configurações específicas de confirmação de leitura
router.put('/settings/read-receipts', privacyController.updateReadReceiptPrivacy);

module.exports = router;