import React, { useState } from 'react';
import { RotateCcw, ArrowRightCircle, Clock, Fuel, Shield, Navigation, Menu, Layers, AlertCircle } from 'lucide-react';

const ReroutePreview = () => {
  const [selectedView, setSelectedView] = useState('main');
  
  // Dados simulados para as rotas alternativas
  const mockAlternativeRoutes = [
    { 
      id: 1, 
      name: 'Via BR-101', 
      distance: '423 km', 
      time: '4h 35min', 
      fuel: '52L',
      securityScore: 4.2,
      isRecommended: true
    },
    { 
      id: 2, 
      name: 'Via SP-330', 
      distance: '455 km', 
      time: '5h 10min', 
      fuel: '58L',
      securityScore: 4.8,
      isRecommended: false
    },
    { 
      id: 3, 
      name: 'Via BR-381', 
      distance: '490 km', 
      time: '5h 45min', 
      fuel: '60L',
      securityScore: 3.5,
      isRecommended: false
    }
  ];

  // Componente para o botão padrão (fechado)
  const DefaultButton = () => (
    <div className="bg-gray-900 p-5 rounded-lg w-full h-32 relative">
      <button className="absolute bottom-5 right-5 w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
        <RotateCcw className="w-6 h-6 text-yellow-500" />
      </button>
    </div>
  );

  // Componente para o botão com painel aberto
  const OpenPanel = () => (
    <div className="bg-gray-900 p-5 rounded-lg w-full h-[500px] relative">
      <button className="absolute bottom-5 right-5 w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
        <RotateCcw className="w-6 h-6 text-yellow-500" />
      </button>
      
      <div className="absolute bottom-20 right-5 w-72 bg-gray-900 border-2 border-yellow-500 rounded-lg overflow-hidden">
        <div className="flex justify-between items-center p-3 bg-black border-b border-yellow-500">
          <h3 className="text-yellow-500 font-bold">Rotas Alternativas</h3>
          <button className="text-gray-400 hover:text-white">×</button>
        </div>
        
        <div className="max-h-96 overflow-y-auto">
          {mockAlternativeRoutes.map((route) => (
            <div 
              key={route.id} 
              className={`p-3 border-b border-gray-800 hover:bg-gray-800 cursor-pointer ${
                route.isRecommended ? 'bg-gray-800' : ''
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="text-white font-medium">{route.name}</span>
                {route.isRecommended && (
                  <span className="bg-yellow-500 text-black text-xs px-2 py-0.5 rounded-full">Recomendada</span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-1 text-sm">
                <div className="flex items-center text-gray-300">
                  <ArrowRightCircle className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.distance}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Clock className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.time}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Fuel className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.fuel}</span>
                </div>
              </div>
              <div className="flex items-center mt-1">
                <Shield className="w-4 h-4 mr-1 text-gray-400" />
                <div className="w-full bg-gray-700 h-2 rounded-full">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full" 
                    style={{ width: `${(route.securityScore / 5) * 100}%` }}
                  />
                </div>
                <span className="ml-2 text-xs text-gray-300">{route.securityScore}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Componente para a tela principal
  const MainScreen = () => (
    <div className="bg-gray-800 p-0 rounded-lg w-full h-[600px] relative overflow-hidden">
      {/* Fundo do mapa simulado */}
      <div className="absolute inset-0 bg-gray-700 grid grid-cols-12 grid-rows-12 gap-px">
        {Array.from({ length: 144 }).map((_, i) => (
          <div key={i} className={`bg-gray-800 ${i % 5 === 0 ? 'bg-opacity-80' : 'bg-opacity-100'}`}></div>
        ))}
      </div>
      
      {/* Controles esquerda */}
      <div className="absolute top-5 left-5 z-10 flex flex-col space-y-2">
        <button className="w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
          <Menu className="w-6 h-6 text-yellow-500" />
        </button>
        <button className="w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
          <Layers className="w-6 h-6 text-yellow-500" />
        </button>
        <button className="w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
          <AlertCircle className="w-6 h-6 text-yellow-500" />
        </button>
      </div>
      
      {/* Controles direita */}
      <div className="absolute bottom-8 right-5 z-10 flex flex-col space-y-2">
        <button className="w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
          <RotateCcw className="w-6 h-6 text-yellow-500" />
        </button>
        <button className="w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
          <Navigation className="w-6 h-6 text-yellow-500" />
        </button>
      </div>
      
      {/* Painel de rotas alternativas (aberto) */}
      <div className="absolute bottom-24 right-5 w-72 bg-gray-900 border-2 border-yellow-500 rounded-lg overflow-hidden z-20">
        <div className="flex justify-between items-center p-3 bg-black border-b border-yellow-500">
          <h3 className="text-yellow-500 font-bold">Rotas Alternativas</h3>
          <button className="text-gray-400 hover:text-white">×</button>
        </div>
        
        <div className="max-h-64 overflow-y-auto">
          {mockAlternativeRoutes.map((route) => (
            <div 
              key={route.id} 
              className={`p-3 border-b border-gray-800 hover:bg-gray-800 cursor-pointer ${
                route.isRecommended ? 'bg-gray-800' : ''
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="text-white font-medium">{route.name}</span>
                {route.isRecommended && (
                  <span className="bg-yellow-500 text-black text-xs px-2 py-0.5 rounded-full">Recomendada</span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-1 text-sm">
                <div className="flex items-center text-gray-300">
                  <ArrowRightCircle className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.distance}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Clock className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.time}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Fuel className="w-4 h-4 mr-1 text-gray-400" />
                  <span>{route.fuel}</span>
                </div>
              </div>
              <div className="flex items-center mt-1">
                <Shield className="w-4 h-4 mr-1 text-gray-400" />
                <div className="w-full bg-gray-700 h-2 rounded-full">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full" 
                    style={{ width: `${(route.securityScore / 5) * 100}%` }}
                  />
                </div>
                <span className="ml-2 text-xs text-gray-300">{route.securityScore}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Componente para o estado de carregamento
  const LoadingState = () => (
    <div className="bg-gray-900 p-5 rounded-lg w-full h-[350px] relative">
      <button className="absolute bottom-5 right-5 w-12 h-12 bg-black border-2 border-yellow-500 rounded-full flex items-center justify-center hover:bg-gray-800">
        <RotateCcw className="w-6 h-6 text-yellow-500 animate-spin" />
      </button>
      
      <div className="absolute bottom-20 right-5 w-72 bg-gray-900 border-2 border-yellow-500 rounded-lg overflow-hidden">
        <div className="flex justify-between items-center p-3 bg-black border-b border-yellow-500">
          <h3 className="text-yellow-500 font-bold">Rotas Alternativas</h3>
          <button className="text-gray-400 hover:text-white">×</button>
        </div>
        
        <div className="h-40 flex flex-col items-center justify-center p-5">
          <div className="mb-2">
            <RotateCcw className="w-6 h-6 text-yellow-500 animate-spin" />
          </div>
          <p className="text-gray-400 text-center m-0">Buscando melhores rotas...</p>
        </div>
      </div>
    </div>
  );

  // Renderizar o preview selecionado
  const renderPreview = () => {
    switch (selectedView) {
      case 'default':
        return <DefaultButton />;
      case 'open':
        return <OpenPanel />;
      case 'main':
        return <MainScreen />;
      case 'loading':
        return <LoadingState />;
      default:
        return <MainScreen />;
    }
  };

  return (
    <div className="flex flex-col space-y-6">
      <div className="flex space-x-4 mb-4">
        <button 
          onClick={() => setSelectedView('default')}
          className={`px-4 py-2 rounded-md ${selectedView === 'default' ? 'bg-yellow-500 text-black' : 'bg-gray-800 text-white'}`}
        >
          Botão Padrão
        </button>
        <button 
          onClick={() => setSelectedView('open')}
          className={`px-4 py-2 rounded-md ${selectedView === 'open' ? 'bg-yellow-500 text-black' : 'bg-gray-800 text-white'}`}
        >
          Alternativas Abertas
        </button>
        <button 
          onClick={() => setSelectedView('main')}
          className={`px-4 py-2 rounded-md ${selectedView === 'main' ? 'bg-yellow-500 text-black' : 'bg-gray-800 text-white'}`}
        >
          Tela Principal
        </button>
        <button 
          onClick={() => setSelectedView('loading')}
          className={`px-4 py-2 rounded-md ${selectedView === 'loading' ? 'bg-yellow-500 text-black' : 'bg-gray-800 text-white'}`}
        >
          Carregando
        </button>
      </div>
      
      <div className="w-full border-2 border-gray-700 rounded-lg overflow-hidden">
        {renderPreview()}
      </div>
      
      <div className="p-4 bg-gray-900 rounded-lg">
        <h3 className="text-white font-bold mb-2">Sobre este componente:</h3>
        <p className="text-gray-300 mb-2">
          O botão de Reroute permite que o usuário solicite rotas alternativas a qualquer momento durante a navegação.
          Quando clicado, ele exibe um painel com até 3 opções de rota, mostrando informações como distância, tempo estimado, 
          consumo de combustível e pontuação de segurança.
        </p>
        <p className="text-gray-300">
          O design segue o tema escuro do KingRoad com bordas douradas, mantendo a consistência visual do aplicativo.
          A rota recomendada é destacada para facilitar a escolha rápida pelo usuário.
        </p>
      </div>
    </div>
  );
};

export default ReroutePreview;