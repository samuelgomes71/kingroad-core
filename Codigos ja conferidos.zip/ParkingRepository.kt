package com.kingroad.repositories

import com.kingroad.models.ParkingSpot
import com.kingroad.models.ParkingSpotType
import com.kingroad.models.FacilityFeature
import com.kingroad.db.AppDatabase
import com.kingroad.api.ParkingApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repositório responsável pelo gerenciamento e consulta de dados de estacionamentos para caminhões
 */
@Singleton
class ParkingRepository @Inject constructor(
    private val database: AppDatabase,
    private val apiService: ParkingApiService
) {

    /**
     * Busca estacionamentos para caminhões dentro de um raio específico
     * considerando as especificações do caminhão
     */
    suspend fun findParkingInRadius(
        latitude: Double,
        longitude: Double,
        radiusMeters: Int,
        truckHeight: Double,
        truckWeight: Double,
        truckLength: Double
    ): List<ParkingSpot> = withContext(Dispatchers.IO) {
        // Primeiro tenta buscar do banco de dados local
        val localParkingSpots = database.parkingSpotDao().findInRadius(
            latitude = latitude,
            longitude = longitude,
            radiusMeters = radiusMeters.toDouble()
        )
        
        // Se tiver conexão, atualiza com dados da API
        try {
            val remoteParkingSpots = apiService.findTruckParkingNearby(
                latitude = latitude,
                longitude = longitude,
                radiusMeters = radiusMeters,
                truckHeight = truckHeight,
                truckWeight = truckWeight,
                truckLength = truckLength
            )
            
            // Salva os dados remotos no banco local para uso offline
            database.parkingSpotDao().insertAll(remoteParkingSpots)
            
            // Retorna os dados da API
            remoteParkingSpots
        } catch (e: Exception) {
            // Em caso de falha na API, usa os dados locais
            localParkingSpots
        }.filter { spot ->
            // Filtra por estacionamentos compatíveis com as dimensões do caminhão
            spot.maxHeight >= truckHeight &&
            spot.maxWeight >= truckWeight &&
            spot.maxLength >= truckLength
        }
    }
    
    /**
     * Obtém detalhes completos de um estacionamento específico
     */
    suspend fun getParkingSpotDetails(spotId: String): ParkingSpot? = withContext(Dispatchers.IO) {
        // Primeiro tenta buscar do banco de dados local
        val localSpot = database.parkingSpotDao().getById(spotId)
        
        if (localSpot != null) {
            localSpot
        } else {
            try {
                // Se não encontrou localmente, busca da API
                val remoteSpot = apiService.getParkingSpotDetails(spotId)
                
                // Salva no banco local para uso futuro
                remoteSpot?.let { database.parkingSpotDao().insert(it) }
                
                remoteSpot
            } catch (e: Exception) {
                null
            }
        }
    }
    
    /**
     * Salva uma avaliação de um estacionamento feita por um motorista
     */
    suspend fun saveParkingSpotReview(
        spotId: String, 
        rating: Int, 
        comment: String,
        safetyScore: Int
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            // Envia a avaliação para a API
            val success = apiService.submitParkingReview(
                spotId = spotId,
                rating = rating,
                comment = comment,
                safetyScore = safetyScore
            )
            
            // Se salvou com sucesso, atualiza o rating médio no banco local
            if (success) {
                val spot = database.parkingSpotDao().getById(spotId)
                spot?.let {
                    val updatedSpot = it.copy(
                        rating = (it.rating * it.reviewCount + rating) / (it.reviewCount + 1),
                        reviewCount = it.reviewCount + 1,
                        safetyRating = (it.safetyRating * it.reviewCount + safetyScore) / (it.reviewCount + 1)
                    )
                    database.parkingSpotDao().update(updatedSpot)
                }
            }
            
            success
        } catch (e: Exception) {
            // Em caso de erro, salva localmente para sincronização posterior
            database.reviewQueueDao().insert(
                ReviewQueueItem(
                    spotId = spotId,
                    rating = rating,
                    comment = comment,
                    safetyScore = safetyScore,
                    timestamp = System.currentTimeMillis()
                )
            )
            true // Retorna true mesmo salvando apenas localmente
        }
    }
    
    /**
     * Reporta um estacionamento como fechado ou com informações incorretas
     */
    suspend fun reportParkingIssue(
        spotId: String,
        issueType: ParkingIssueType,
        description: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            apiService.reportParkingIssue(
                spotId = spotId,
                issueType = issueType.name,
                description = description
            )
        } catch (e: Exception) {
            // Em caso de erro, salva localmente para sincronização posterior
            database.parkingIssueQueueDao().insert(
                ParkingIssueQueueItem(
                    spotId = spotId,
                    issueType = issueType.name,
                    description = description,
                    timestamp = System.currentTimeMillis()
                )
            )
            true // Retorna true mesmo salvando apenas localmente
        }
    }
    
    /**
     * Adiciona um novo estacionamento que não está no sistema
     */
    suspend fun addNewParkingSpot(newSpot: ParkingSpot): String? = withContext(Dispatchers.IO) {
        try {
            // Tenta adicionar via API
            val spotId = apiService.addNewParkingSpot(newSpot)
            
            // Se conseguiu adicionar, salva localmente
            if (spotId != null) {
                database.parkingSpotDao().insert(newSpot.copy(id = spotId))
            }
            
            spotId
        } catch (e: Exception) {
            // Em caso de erro, salva localmente para sincronização posterior
            val tempId = "temp_" + System.currentTimeMillis()
            database.parkingSpotDao().insert(newSpot.copy(id = tempId))
            database.newParkingQueueDao().insert(
                NewParkingQueueItem(
                    tempId = tempId,
                    parkingSpot = newSpot,
                    timestamp = System.currentTimeMillis()
                )
            )
            tempId
        }
    }
    
    /**
     * Tipos de problemas que podem ser reportados em estacionamentos
     */
    enum class ParkingIssueType {
        CLOSED_PERMANENTLY,
        TEMPORARILY_UNAVAILABLE,
        INCORRECT_INFO,
        ACCESS_RESTRICTED,
        SAFETY_CONCERN,
        OTHER
    }
    
    /**
     * Classe para armazenar reviews para sincronização posterior
     */
    data class ReviewQueueItem(
        val id: Long = 0,
        val spotId: String,
        val rating: Int,
        val comment: String,
        val safetyScore: Int,
        val timestamp: Long
    )
    
    /**
     * Classe para armazenar problemas reportados para sincronização posterior
     */
    data class ParkingIssueQueueItem(
        val id: Long = 0,
        val spotId: String,
        val issueType: String,
        val description: String,
        val timestamp: Long
    )
    
    /**
     * Classe para armazenar novos estacionamentos para sincronização posterior
     */
    data class NewParkingQueueItem(
        val id: Long = 0,
        val tempId: String,
        val parkingSpot: ParkingSpot,
        val timestamp: Long
    )
}