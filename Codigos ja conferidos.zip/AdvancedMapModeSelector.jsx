import React, { useState } from 'react';
import { Map, Satellite, Mountain } from 'lucide-react';

const AdvancedMapModeSelector = ({ onModeChange }) => {
  const [currentMode, setCurrentMode] = useState('standard');
  
  const modes = [
    { id: 'standard', icon: Map, label: 'Normal', color: 'bg-blue-500', description: 'Visualização de ruas e estradas' },
    { id: 'satellite', icon: Satellite, label: 'Satélite', color: 'bg-green-600', description: 'Visualização de imagens de satélite' },
    { id: 'terrain', icon: Mountain, label: 'Relevo', color: 'bg-amber-700', description: 'Visualização com topografia e elevação' },
    { id: 'hybrid', icon: Map, label: 'Híbrido', color: 'bg-purple-600', description: 'Satélite com nomes de ruas' }
  ];
  
  const handleModeSelect = (modeId) => {
    setCurrentMode(modeId);
    onModeChange(modeId);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-2 mb-4">
      <div className="grid grid-cols-4 gap-2">
        {modes.map(mode => (
          <button
            key={mode.id}
            onClick={() => handleModeSelect(mode.id)}
            className={`p-2 rounded-lg flex flex-col items-center ${
              currentMode === mode.id 
                ? `${mode.color} text-white` 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {React.createElement(mode.icon, { size: 20 })}
            <span className="text-xs mt-1 font-medium">{mode.label}</span>
          </button>
        ))}
      </div>
      
      <div className="mt-2 text-xs text-gray-600 px-2">
        {modes.find(m => m.id === currentMode)?.description}
      </div>
    </div>
  );
};

export default AdvancedMapModeSelector;