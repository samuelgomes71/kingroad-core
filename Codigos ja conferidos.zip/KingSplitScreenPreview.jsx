import React, { useState, useEffect } from 'react';
import { X, MessageSquare, Map, MessageCircle, Settings } from 'lucide-react';

const KingSplitScreenPreview = () => {
  const [screenWidth, setScreenWidth] = useState(1000);
  const [selectedApp, setSelectedApp] = useState(null);
  const [isPinned, setIsPinned] = useState(false);
  const [showSelector, setShowSelector] = useState(false);
  
  // Simulate responsive behavior
  const isLargeScreen = screenWidth > 900;
  
  // Available apps
  const apps = [
    { id: 'KingChat', label: 'KingChat', icon: <MessageSquare size={24} /> },
    { id: 'KingSMS', label: 'KingSMS', icon: <MessageCircle size={24} /> },
    { id: 'KingLoc', label: 'KingLoc', icon: <Map size={24} /> },
    { id: 'AdminPortal', label: 'AdminPortal', icon: <Settings size={24} /> }
  ];

  const handleAppSelect = (app) => {
    setSelectedApp(app);
    setShowSelector(false);
  };
  
  const togglePin = () => {
    setIsPinned(!isPinned);
  };
  
  const toggleSelector = () => {
    setShowSelector(!showSelector);
  };
  
  const changeScreenSize = (size) => {
    setScreenWidth(size);
  };
  
  // Colors from the design specs
  const colors = {
    background: '#E0D3C0',
    textColor: '#5E3C2B',
    accent: '#6B4B3E',
    voiceButtonColor: '#5E3C2B'
  };
  
  return (
    <div className="flex flex-col gap-6 w-full">
      {/* Device simulator controls */}
      <div className="flex gap-4 justify-start items-center mb-4">
        <button 
          onClick={() => changeScreenSize(700)} 
          className={`px-3 py-1 rounded ${screenWidth < 900 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          Mobile View
        </button>
        <button 
          onClick={() => changeScreenSize(1200)} 
          className={`px-3 py-1 rounded ${screenWidth >= 900 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          Desktop View
        </button>
        <span className="text-sm text-gray-500">Current width: {screenWidth}px</span>
      </div>
      
      {/* Device frame */}
      <div 
        className="border-2 border-gray-400 rounded-lg overflow-hidden mx-auto"
        style={{ 
          width: `${Math.min(screenWidth, 1200)}px`, 
          height: '600px', 
          background: colors.background 
        }}
      >
        {/* Main content */}
        <div className="h-full w-full flex relative">
          {/* KingRoad main app */}
          <div 
            className={`flex flex-col ${isLargeScreen && selectedApp ? 'w-1/2' : 'w-full'} h-full border-r border-gray-300`}
            style={{ 
              backgroundColor: colors.background,
              color: colors.textColor
            }}
          >
            <div className="p-4 border-b border-gray-300 font-bold text-xl flex justify-between items-center">
              <span>KingRoad</span>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <Map size={20} color={colors.accent} />
              </div>
            </div>
            <div className="flex-1 p-4 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">🚚</div>
                <p className="text-lg">KingRoad Map View</p>
                <p className="text-sm mt-4 text-gray-600">Main navigation app content would display here</p>
              </div>
            </div>
          </div>
          
          {/* Secondary app (visible on large screens or when selected) */}
          {(isLargeScreen && selectedApp) && (
            <div className="w-1/2 h-full relative">
              <div className="p-4 border-b border-gray-300 font-bold text-xl flex justify-between items-center">
                <span>{selectedApp.label}</span>
                <button 
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-red-100"
                  onClick={() => setSelectedApp(null)}
                >
                  <X size={20} color={colors.accent} />
                </button>
              </div>
              <div className="flex-1 p-4 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl mb-4">
                    {selectedApp.icon}
                  </div>
                  <p className="text-lg">{selectedApp.label} Content</p>
                  <div className="mt-4 flex gap-2 justify-center">
                    <button 
                      className="px-3 py-1 rounded text-sm"
                      style={{ backgroundColor: colors.accent, color: 'white' }}
                      onClick={togglePin}
                    >
                      {isPinned ? 'Unpin App' : 'Pin App'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* App selector modal */}
          {showSelector && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-10">
              <div 
                className="rounded-lg p-6 w-80"
                style={{ backgroundColor: colors.background }}
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold" style={{ color: colors.textColor }}>Select App</h3>
                  <button
                    className="rounded-full p-1 hover:bg-gray-200"
                    onClick={() => setShowSelector(false)}
                  >
                    <X size={20} color={colors.accent} />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {apps.map(app => (
                    <button
                      key={app.id}
                      className="flex flex-col items-center justify-center p-3 rounded-lg hover:bg-gray-200"
                      onClick={() => handleAppSelect(app)}
                    >
                      <div className="text-3xl mb-2">{app.icon}</div>
                      <span className="text-sm" style={{ color: colors.textColor }}>{app.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Floating button for small screens */}
          {!isLargeScreen && (
            <button
              className="absolute right-4 bottom-4 w-14 h-14 rounded-full flex items-center justify-center shadow-lg" 
              style={{ backgroundColor: colors.accent }}
              onClick={toggleSelector}
            >
              <div className="text-white">+</div>
            </button>
          )}
        </div>
      </div>
      
      {/* Explanatory text */}
      <div className="mt-4 text-sm text-gray-600 max-w-3xl">
        <p><strong>Comportamento Responsivo:</strong> Em telas grandes (>900px), o layout divide em duas colunas. Em telas menores, exibe apenas o KingRoad com um botão flutuante.</p>
        <p><strong>Interações:</strong> Clique no botão flutuante para abrir o seletor de apps. Escolha um app para exibi-lo na tela dividida (desktop) ou alternar para ele (mobile).</p>
        <p><strong>Funcionalidade de Pin:</strong> Permite fixar o app secundário para que ele persista entre sessões.</p>
      </div>
    </div>
  );
};

export default KingSplitScreenPreview;