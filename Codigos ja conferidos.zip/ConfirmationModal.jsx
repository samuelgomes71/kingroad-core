// ConfirmationModal.jsx
import React from 'react';
import { ThumbsUp } from 'lucide-react';

const ConfirmationModal = ({ message }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/70 z-50">
      <div className="bg-stone-800 rounded-lg p-5 text-center w-72">
        <div className="mx-auto mb-3 w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center">
          <ThumbsUp size={32} className="text-white" />
        </div>
        <h3 className="text-white text-lg font-bold mb-1">Obrigado!</h3>
        <p className="text-stone-300 text-sm mb-3">{message}</p>
      </div>
    </div>
  );
};

export default ConfirmationModal;