// Serviço de armazenamento local
const StorageService = {
  /**
   * Salva dados no armazenamento local
   * @param {string} key - Chave de identificação dos dados
   * @param {any} data - Dados a serem armazenados
   * @returns {Promise<void>}
   */
  async saveData(key, data) {
    try {
      await window.localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
      return false;
    }
  },

  /**
   * Recupera dados do armazenamento local
   * @param {string} key - Chave de identificação dos dados
   * @returns {Promise<any>} Os dados armazenados ou null se não existirem
   */
  async getData(key) {
    try {
      const data = await window.localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Erro ao ler dados:', error);
      return null;
    }
  },
  
  /**
   * Remove dados do armazenamento local
   * @param {string} key - Chave de identificação dos dados
   * @returns {Promise<boolean>} True se removido com sucesso
   */
  async removeData(key) {
    try {
      await window.localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Erro ao remover dados:', error);
      return false;
    }
  },
  
  /**
   * Verifica se existe uma chave no armazenamento local
   * @param {string} key - Chave de identificação dos dados
   * @returns {Promise<boolean>} True se a chave existir
   */
  async hasKey(key) {
    try {
      return window.localStorage.getItem(key) !== null;
    } catch (error) {
      console.error('Erro ao verificar chave:', error);
      return false;
    }
  },
  
  /**
   * Limpa todo o armazenamento local
   * @returns {Promise<boolean>} True se limpo com sucesso
   */
  async clearAll() {
    try {
      await window.localStorage.clear();
      return true;
    } catch (error) {
      console.error('Erro ao limpar armazenamento:', error);
      return false;
    }
  }
};

export default StorageService;