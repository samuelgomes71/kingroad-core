// Sistema de Cálculo de Alcance por Tempo de Direção
// app/src/main/kotlin/com/kingroad/drivingtime

class DrivingTimeRangeCalculator(
    private val routeService: RouteService,
    private val poiManager: POIManager,
    private val trafficService: TrafficService
) {
    data class DrivingTimeRange(
        val remainingTime: Duration,
        val safetyMargin: Duration = Duration.ofMinutes(15),
        val effectiveTime: Duration,
        val reachablePoints: List<StopPoint>,
        val recommendedStop: StopPoint,
        val alternativeStops: List<StopPoint>,
        val warningLevel: WarningLevel
    )

    data class StopPoint(
        val location: Location,
        val type: StopType,
        val timeToReach: Duration,
        val facilities: List<Facility>,
        val parkingSpots: ParkingAvailability,
        val routeDeviation: Double = 0.0,  // metros fora da rota
        val safetyScore: Double           // 0.0 a 1.0
    )

    enum class StopType {
        TRUCK_STOP,
        REST_AREA,
        SECURED_PARKING,
        SERVICE_AREA,
        EMERGENCY_STOP
    }

    enum class WarningLevel {
        SAFE,            // Tempo suficiente, várias opções
        CAUTION,         // Tempo justo, opções limitadas
        CRITICAL,        // Tempo muito limitado
        UNSAFE          // Tempo insuficiente
    }

    // Calcular pontos alcançáveis
    suspend fun calculateReachablePoints(
        currentLocation: Location,
        remainingDrivingTime: Duration,
        route: Route
    ): DrivingTimeRange {
        // Subtrair margem de segurança
        val effectiveTime = remainingDrivingTime.minus(SAFETY_MARGIN)
        
        // Calcular distância máxima possível
        val maxDistance = calculateMaxDistance(
            effectiveTime = effectiveTime,
            currentLocation = currentLocation,
            route = route
        )

        // Encontrar pontos de parada dentro do alcance
        val stopPoints = findStopPointsWithinRange(
            currentLocation = currentLocation,
            maxDistance = maxDistance,
            route = route
        )

        // Filtrar e ordenar pontos por adequação
        val suitablePoints = filterAndRankStopPoints(stopPoints)

        // Determinar nível de alerta
        val warningLevel = determineWarningLevel(
            effectiveTime = effectiveTime,
            stopPoints = suitablePoints
        )

        return DrivingTimeRange(
            remainingTime = remainingDrivingTime,
            safetyMargin = SAFETY_MARGIN,
            effectiveTime = effectiveTime,
            reachablePoints = suitablePoints,
            recommendedStop = selectBestStop(suitablePoints),
            alternativeStops = selectAlternatives(suitablePoints),
            warningLevel = warningLevel
        )
    }

    // Calcular distância máxima possível
    private suspend fun calculateMaxDistance(
        effectiveTime: Duration,
        currentLocation: Location,
        route: Route
    ): Double {
        val averageSpeed = calculateAverageSpeed(
            route = route,
            startLocation = currentLocation
        )
        
        return (effectiveTime.seconds * averageSpeed) / 3600.0
    }

    // Encontrar pontos de parada no alcance
    private suspend fun findStopPointsWithinRange(
        currentLocation: Location,
        maxDistance: Double,
        route: Route
    ): List<StopPoint> {
        // Buscar todos os pontos possíveis
        val allStops = poiManager.findStopsAlong(
            route = route,
            startLocation = currentLocation,
            maxDistance = maxDistance
        )

        return allStops.mapNotNull { stop ->
            val timeToReach = calculateTimeToReach(
                currentLocation = currentLocation,
                destination = stop.location,
                route = route
            )

            if (timeToReach <= EFFECTIVE_TIME) {
                StopPoint(
                    location = stop.location,
                    type = stop.type,
                    timeToReach = timeToReach,
                    facilities = stop.facilities,
                    parkingSpots = stop.parkingAvailability,
                    routeDeviation = calculateRouteDeviation(stop.location, route),
                    safetyScore = calculateSafetyScore(stop)
                )
            } else null
        }
    }

    // Calcular média de velocidade considerando condições
    private suspend fun calculateAverageSpeed(
        route: Route,
        startLocation: Location
    ): Double {
        val trafficConditions = trafficService.getTrafficConditions(route)
        val baseSpeed = route.getSpeedLimit() ?: DEFAULT_SPEED_KMH
        
        return when (trafficConditions) {
            TrafficCondition.LIGHT -> baseSpeed * 0.95
            TrafficCondition.MODERATE -> baseSpeed * 0.85
            TrafficCondition.HEAVY -> baseSpeed * 0.70
            TrafficCondition.SEVERE -> baseSpeed * 0.50
        }
    }

    // Selecionar melhor ponto de parada
    private fun selectBestStop(stops: List<StopPoint>): StopPoint {
        return stops.maxByOrNull { stop ->
            // Pontuação baseada em múltiplos fatores
            val score = calculateStopScore(stop)
            score
        } ?: stops.first()
    }

    // Calcular pontuação do ponto de parada
    private fun calculateStopScore(stop: StopPoint): Double {
        return listOf(
            stop.safetyScore * 0.3,
            (1.0 - (stop.routeDeviation / MAX_DEVIATION)) * 0.2,
            stop.parkingSpots.availabilityScore * 0.3,
            stop.facilities.size.toDouble() / MAX_FACILITIES * 0.2
        ).sum()
    }

    // Determinar nível de alerta
    private fun determineWarningLevel(
        effectiveTime: Duration,
        stopPoints: List<StopPoint>
    ): WarningLevel {
        return when {
            effectiveTime.toMinutes() > 120 && stopPoints.size > 5 -> 
                WarningLevel.SAFE
            effectiveTime.toMinutes() > 60 && stopPoints.isNotEmpty() -> 
                WarningLevel.CAUTION
            effectiveTime.toMinutes() > 30 && stopPoints.isNotEmpty() -> 
                WarningLevel.CRITICAL
            else -> 
                WarningLevel.UNSAFE
        }
    }

    companion object {
        private val SAFETY_MARGIN = Duration.ofMinutes(15)
        private val DEFAULT_SPEED_KMH = 80.0
        private const val MAX_DEVIATION = 2000.0  // 2km
        private const val MAX_FACILITIES = 10.0
    }
}

// Extensões úteis
fun Route.getSpeedLimit(): Double? {
    // Implementar lógica para obter limite de velocidade da rota
    return null
}

data class ParkingAvailability(
    val total: Int,
    val available: Int,
    val lastUpdate: Long
) {
    val availabilityScore: Double
        get() = if (total > 0) available.toDouble() / total else 0.0
}