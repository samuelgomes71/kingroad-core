import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Componentes principais
import Header from './components/Header';
import Navigation from './components/Navigation';
import MapView from './components/MapView';
import Settings from './components/Settings';
import Profile from './components/Profile';
import KingFamilyIntegration from './components/KingFamilyIntegration';

// Utilitários
import { ThemeProvider } from './utils/ThemeContext';
import { UserProvider } from './utils/UserContext';
import DevModeDetector from './utils/DevModeDetector';

// Estilos
import './assets/styles/main.css';

/**
 * Componente principal do aplicativo KingRoad
 * Salvar em: web/src/App.jsx
 */
function App() {
  const [isDevMode, setIsDevMode] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Detector de modo offline
  useEffect(() => {
    const handleOnlineStatus = () => {
      setIsOffline(!navigator.onLine);
    };

    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);

    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);

  return (
    <ThemeProvider>
      <UserProvider>
        <Router>
          <DevModeDetector onDevModeChange={setIsDevMode} />
          <div className="app-container">
            {isOffline && (
              <div className="offline-banner">
                Modo Offline Ativado - Alguns recursos podem estar indisponíveis
              </div>
            )}
            
            <Header isDevMode={isDevMode} />
            
            <main className="main-content">
              <Routes>
                <Route path="/" element={<MapView />} />
                <Route path="/navigation" element={<Navigation />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/family" element={<KingFamilyIntegration />} />
              </Routes>
            </main>
            
            {isDevMode && (
              <div className="dev-mode-indicator">
                Modo Desenvolvedor Ativado - ID: {process.env.REACT_APP_BUILD_ID || 'local'}
              </div>
            )}
          </div>
        </Router>
      </UserProvider>
    </ThemeProvider>
  );
}

export default App;