// RouteCalculator.kt
object RouteCalculator {
    data class RouteOptions(
        val avoidTolls: Boolean = false,
        val avoidHighways: Boolean = false,
        val avoidUrbanAreas: Boolean = false,
        val preferTruckStops: Boolean = true,
        val maxDetour: Double = 0.3 // 30% extra da distância total
    )

    data class RouteSegment(
        val points: List<Location>,
        val distance: Double,
        val duration: Double,
        val type: RoadType,
        val restrictions: List<Restriction>,
        val instructions: NavigationInstruction
    )

    // Calcular rota considerando restrições do veículo
    suspend fun calculateRoute(
        start: Location,
        end: Location,
        roadNetwork: RoadNetwork,
        restrictions: VehicleRestrictions,
        vehicleProfile: VehicleProfile,
        options: RouteOptions = RouteOptions()
    ): Route {
        // 1. Construir grafo da rede viária
        val graph = buildRoadGraph(roadNetwork, restrictions, vehicleProfile)

        // 2. Encontrar pontos de acesso mais próximos
        val startNode = graph.findNearestNode(start)
        val endNode = graph.findNearestNode(end)

        // 3. Calcular rota usando A*
        val path = findPath(
            graph = graph,
            start = startNode,
            end = endNode,
            vehicleProfile = vehicleProfile,
            options = options
        )

        // 4. Refinar rota
        val refinedPath = refinePath(path, vehicleProfile)

        // 5. Gerar instruções
        val instructions = generateInstructions(refinedPath)

        // 6. Calcular alertas e restrições
        val alerts = calculateAlerts(refinedPath, vehicleProfile)

        return Route(
            segments = refinedPath,
            distance = calculateTotalDistance(refinedPath),
            duration = calculateEstimatedDuration(refinedPath, vehicleProfile),
            alerts = alerts,
            instructions = instructions
        )
    }

    // Calcular rota alternativa
    suspend fun calculateAlternativeRoute(
        mainRoute: Route,
        roadNetwork: RoadNetwork,
        vehicleProfile: VehicleProfile,
        options: RouteOptions
    ): Route? {
        // Adicionar penalidade aos segmentos da rota principal
        val modifiedGraph = penalizeUsedSegments(
            roadNetwork = roadNetwork,
            usedSegments = mainRoute.segments
        )

        // Calcular nova rota com grafo modificado
        return calculateRoute(
            start = mainRoute.segments.first().points.first(),
            end = mainRoute.segments.last().points.last(),
            roadNetwork = modifiedGraph,
            restrictions = mainRoute.restrictions,
            vehicleProfile = vehicleProfile,
            options = options.copy(
                maxDetour = 0.5 // Permitir desvio maior para rota alternativa
            )
        )
    }

    // Recalcular rota a partir de desvio
    suspend fun recalculateFromDeviation(
        originalRoute: Route,
        currentLocation: Location,
        roadNetwork: RoadNetwork,
        vehicleProfile: VehicleProfile
    ): Route {
        // Encontrar melhor ponto de retorno à rota
        val returnPoint = findBestReturnPoint(
            currentLocation = currentLocation,
            remainingSegments = originalRoute.remainingSegments,
            roadNetwork = roadNetwork
        )

        // Calcular nova rota até o ponto de retorno
        val routeToReturn = calculateRoute(
            start = currentLocation,
            end = returnPoint,
            roadNetwork = roadNetwork,
            restrictions = originalRoute.restrictions,
            vehicleProfile = vehicleProfile
        )

        // Combinar com resto da rota original
        return combineRoutes(
            routeToReturn,
            originalRoute.segmentsAfter(returnPoint)
        )
    }

    private fun buildRoadGraph(
        roadNetwork: RoadNetwork,
        restrictions: VehicleRestrictions,
        vehicleProfile: VehicleProfile
    ): Graph {
        return Graph().apply {
            roadNetwork.segments.forEach { segment ->
                // Verificar se o segmento é permitido para o veículo
                if (isSegmentAllowed(segment, restrictions, vehicleProfile)) {
                    addSegment(
                        segment,
                        calculateSegmentWeight(segment, vehicleProfile)
                    )
                }
            }
        }
    }

    private fun findPath(
        graph: Graph,
        start: Node,
        end: Node,
        vehicleProfile: VehicleProfile,
        options: RouteOptions
    ): List<RouteSegment> {
        val algorithm = AStarAlgorithm(
            graph = graph,
            heuristic = { node -> calculateHeuristic(node, end) },
            weightFunction = { segment -> 
                calculateSegmentWeight(segment, vehicleProfile, options)
            }
        )

        return algorithm.findPath(start, end)
    }

    private fun calculateSegmentWeight(
        segment: RouteSegment,
        vehicleProfile: VehicleProfile,
        options: RouteOptions = RouteOptions()
    ): Double {
        var weight = segment.distance

        // Ajustes baseados no tipo de via
        weight *= when (segment.type) {
            RoadType.HIGHWAY -> if (options.avoidHighways) 2.0 else 0.8
            RoadType.TOLL -> if (options.avoidTolls) 3.0 else 1.0
            RoadType.URBAN -> if (options.avoidUrbanAreas) 1.5 else 1.0
            else -> 1.0
        }

        // Ajustes baseados nas restrições
        segment.restrictions.forEach { restriction ->
            when (restriction) {
                is WeightRestriction -> 
                    if (vehicleProfile.weight > restriction.maxWeight) weight = Double.POSITIVE_INFINITY
                is HeightRestriction ->
                    if (vehicleProfile.height > restriction.maxHeight) weight = Double.POSITIVE_INFINITY
                is WidthRestriction ->
                    if (vehicleProfile.width > restriction.maxWidth) weight = Double.POSITIVE_INFINITY
            }
        }

        return weight
    }

    private fun generateInstructions(path: List<RouteSegment>): List<NavigationInstruction> {
        return path.mapIndexed { index, segment ->
            NavigationInstruction(
                type = determineInstructionType(
                    current = segment,
                    next = path.getOrNull(index + 1)
                ),
                distance = segment.distance,
                description = generateDescription(segment),
                alerts = segment.restrictions.map { restriction ->
                    AlertType.fromRestriction(restriction)
                }
            )
        }
    }
}