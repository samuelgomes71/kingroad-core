import React, { useState, useEffect } from 'react';
import { 
  Modal, 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import Icon from '../components/common/Icon';
import Button from '../components/common/Button';
import reportTypesConfig from '../config/reportTypesConfig';
import PhotoCapture from '../components/PhotoCapture';
import AudioRecorder from '../components/AudioRecorder';
import LocationPicker from '../components/LocationPicker';

/**
 * Modal para criação e submissão de reportes rápidos
 * Suporta entrada de texto, fotos, áudio e escolha de localização
 */
const ReportModal = ({ 
  visible, 
  reportType, 
  onClose, 
  onSubmit,
  isOffline = false 
}) => {
  const { t } = useTranslation();
  const { theme, isDark } = useTheme();
  
  const [reportData, setReportData] = useState({
    description: '',
    photos: [],
    audioNote: null,
    verifiedLocation: null,
    severity: 'medium',
  });
  
  const [reportConfig, setReportConfig] = useState(null);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  // Buscar configuração do tipo de reporte selecionado
  useEffect(() => {
    if (reportType) {
      const config = reportTypesConfig.find(config => config.id === reportType);
      setReportConfig(config);
      
      // Resetar dados ao abrir novo reporte
      setReportData({
        description: '',
        photos: [],
        audioNote: null,
        verifiedLocation: null,
        severity: 'medium',
      });
      
      setStep(1);
    }
  }, [reportType, visible]);

  // Se não há configuração, não renderizar nada
  if (!reportConfig) return null;

  const handleAddPhoto = (photoUri) => {
    setReportData(prev => ({
      ...prev,
      photos: [...prev.photos, photoUri]
    }));
  };

  const handleRemovePhoto = (index) => {
    setReportData(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };

  const handleAudioRecorded = (audioUri) => {
    setReportData(prev => ({
      ...prev,
      audioNote: audioUri
    }));
  };

  const handleLocationSelected = (location) => {
    setReportData(prev => ({
      ...prev,
      verifiedLocation: location
    }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await onSubmit(reportData);
      // Limpar o formulário após envio bem-sucedido
      setReportData({
        description: '',
        photos: [],
        audioNote: null,
        verifiedLocation: null,
        severity: 'medium',
      });
      setStep(1);
    } catch (error) {
      console.error('Erro ao enviar reporte:', error);
      // Exibir mensagem de erro
    } finally {
      setLoading(false);
    }
  };

  const navigateToNextStep = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      handleSubmit();
    }
  };

  const navigateToPrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onClose();
    }
  };

  // Determinar quais recursos o reporte atual utiliza
  const hasDescription = reportConfig.features.includes('description');
  const hasPhotos = reportConfig.features.includes('photos');
  const hasAudio = reportConfig.features.includes('audio');
  const hasLocation = reportConfig.features.includes('verifyLocation');
  const hasSeverity = reportConfig.features.includes('severity');

  // Calcular total de etapas com base nos recursos ativos
  const totalSteps = [
    hasDescription, 
    hasPhotos, 
    hasAudio, 
    hasLocation,
    hasSeverity
  ].filter(Boolean).length;

  // Renderizar o conteúdo atual conforme a etapa
  const renderStepContent = () => {
    // Lista de passos possíveis
    const steps = [
      hasDescription && (
        <View key="description" style={styles.stepContainer}>
          <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
            {t('reports.form.descriptionTitle')}
          </Text>
          <TextInput
            style={[
              styles.textInput,
              { 
                backgroundColor: isDark ? theme.colors.cardDark : theme.colors.cardLight,
                color: theme.colors.text,
                borderColor: theme.colors.border
              }
            ]}
            placeholder={t('reports.form.descriptionPlaceholder')}
            placeholderTextColor={theme.colors.textSecondary}
            value={reportData.description}
            onChangeText={(text) => setReportData(prev => ({ ...prev, description: text }))}
            multiline
            maxLength={500}
          />
        </View>
      ),
      hasPhotos && (
        <View key="photos" style={styles.stepContainer}>
          <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
            {t('reports.form.photosTitle')}
          </Text>
          <PhotoCapture
            onPhotoCapture={handleAddPhoto}
            existingPhotos={reportData.photos}
            onRemovePhoto={handleRemovePhoto}
            maxPhotos={3}
            disabled={isOffline && !reportConfig.offlineFeatures.includes('photos')}
          />
          {isOffline && !reportConfig.offlineFeatures.includes('photos') && (
            <Text style={[styles.offlineWarning, { color: theme.colors.warning }]}>
              {t('reports.offlinePhotoWarning')}
            </Text>
          )}
        </View>
      ),
      hasAudio && (
        <View key="audio" style={styles.stepContainer}>
          <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
            {t('reports.form.audioTitle')}
          </Text>
          <AudioRecorder
            onRecordComplete={handleAudioRecorded}
            existingAudio={reportData.audioNote}
            maxDuration={60} // 60 segundos
            disabled={isOffline && !reportConfig.offlineFeatures.includes('audio')}
          />
          {isOffline && !reportConfig.offlineFeatures.includes('audio') && (
            <Text style={[styles.offlineWarning, { color: theme.colors.warning }]}>
              {t('reports.offlineAudioWarning')}
            </Text>
          )}
        </View>
      ),
      hasLocation && (
        <View key="location" style={styles.stepContainer}>
          <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
            {t('reports.form.locationTitle')}
          </Text>
          <LocationPicker
            onLocationSelected={handleLocationSelected}
            initialLocation={reportData.verifiedLocation}
            allowAdjustment={true}
          />
        </View>
      ),
      hasSeverity && (
        <View key="severity" style={styles.stepContainer}>
          <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
            {t('reports.form.severityTitle')}
          </Text>
          <View style={styles.severityContainer}>
            {['low', 'medium', 'high'].map((severity) => (
              <TouchableOpacity
                key={severity}
                style={[
                  styles.severityButton,
                  reportData.severity === severity && {
                    backgroundColor: 
                      severity === 'low' ? theme.colors.success :
                      severity === 'medium' ? theme.colors.warning :
                      theme.colors.danger
                  }
                ]}
                onPress={() => setReportData(prev => ({ ...prev, severity }))}
              >
                <Text style={[
                  styles.severityText,
                  reportData.severity === severity && styles.severityTextSelected
                ]}>
                  {t(`reports.severity.${severity}`)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )
    ].filter(Boolean);

    // Retornar o conteúdo da etapa atual (ajustando índice pois arrays começam em 0)
    return steps[step - 1] || null;
  };

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.modalContainer}
      >
        <View style={[
          styles.modalContent,
          { 
            backgroundColor: isDark ? theme.colors.backgroundDark : theme.colors.backgroundLight,
            borderColor: theme.colors.border
          }
        ]}>
          <View style={styles.header}>
            <TouchableOpacity 
              onPress={navigateToPrevStep}
              style={styles.closeButton}
            >
              <Icon name="arrow-left" size={24} color={theme.colors.text} />
            </TouchableOpacity>
            
            <Text style={[styles.title, { color: theme.colors.text }]}>
              {t(`reports.types.${reportConfig.id}`)}
            </Text>
            
            <View style={styles.progressIndicator}>
              <Text style={[styles.progressText, { color: theme.colors.text }]}>
                {step}/{totalSteps}
              </Text>
            </View>
          </View>
          
          {isOffline && (
            <View style={[styles.offlineBar, { backgroundColor: theme.colors.warning }]}>
              <Icon name="wifi-off" size={16} color="#fff" />
              <Text style={styles.offlineText}>
                {t('reports.offlineMode')}
              </Text>
            </View>
          )}
          
          <ScrollView contentContainerStyle={styles.scrollContent}>
            {renderStepContent()}
          </ScrollView>
          
          <View style={styles.footer}>
            <Button
              title={step === totalSteps ? 
                (isOffline ? t('reports.saveForLater') : t('reports.submit')) : 
                t('common.next')
              }
              onPress={navigateToNextStep}
              loading={loading}
              style={{ backgroundColor: theme.colors.primary }}
              disabled={loading}
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    maxHeight: '80%',
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  closeButton: {
    padding: 5,
  },
  title: {
    flex: 1,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  progressIndicator: {
    width: 40,
    alignItems: 'center',
  },
  progressText: {
    fontSize: 14,
  },
  offlineBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  offlineText: {
    color: '#fff',
    marginLeft: 5,
    fontSize: 12,
    fontWeight: 'bold',
  },
  scrollContent: {
    padding: 20,
  },
  stepContainer: {
    marginBottom: 20,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  textInput: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  severityContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  severityButton: {
    flex: 1,
    padding: 12,
    alignItems: 'center',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    marginHorizontal: 5,
  },
  severityText: {
    fontSize: 14,
  },
  severityTextSelected: {
    color: '#fff',
    fontWeight: 'bold',
  },
  footer: {
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  offlineWarning: {
    marginTop: 5,
    fontSize: 12,
    fontStyle: 'italic',
  },
});

export default ReportModal;