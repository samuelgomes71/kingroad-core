import React, { useState, useEffect } from 'react';
import { Building2, Users, Search, PlusCircle, Download, Upload, Edit, Trash2, Save, Check, X, Info, Filter, List, Grid } from 'lucide-react';

const CompanyPortal = () => {
  // Estado da empresa
  const [company, setCompany] = useState({
    id: 'TR123456',
    name: 'Transportadora KingRoad',
    email: 'admin@kingroad.com',
    city: 'São Paulo',
    country: 'Brasil'
  });
  
  // Estado para gerenciamento de Customer IDs
  const [customerIDs, setCustomerIDs] = useState([]);
  const [filteredIDs, setFilteredIDs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('table');
  const [showSharedOnly, setShowSharedOnly] = useState(false);
  
  // Estados para criação/edição
  const [isCreatingID, setIsCreatingID] = useState(false);
  const [isEditingID, setIsEditingID] = useState(null);
  const [isImporting, setIsImporting] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    cityName: '',
    address: '',
    entranceNotes: '',
    isShared: true
  });
  
  // Dados de exemplo
  useEffect(() => {
    const demoIDs = [
      { id: 'KINSPX', name: 'KingRoad', city: 'São Paulo', address: 'Av. Paulista, 1000', entranceNotes: 'Entrada pela lateral', isShared: true, createdAt: '2024-01-15' },
      { id: 'TRARJX', name: 'Transportes Rápidos', city: 'Rio de Janeiro', address: 'Rua Copacabana, 500', entranceNotes: 'Dock nos fundos', isShared: false, createdAt: '2024-02-10' },
      { id: 'LOGFOR', name: 'Logística Forte', city: 'Fortaleza', address: 'Av. Beira Mar, 1200', entranceNotes: 'Entrada principal', isShared: true, createdAt: '2024-02-22' },
      { id: 'FBGCAM', name: 'FB Transportes', city: 'Campinas', address: 'Rodovia Anhanguera, Km 95', entranceNotes: 'Acesso pelo portão 3', isShared: true, createdAt: '2024-03-05' },
      { id: 'EXPSUL', name: 'Express Sul', city: 'Porto Alegre', address: 'Av. dos Estados, 750', entranceNotes: 'Rampa lateral', isShared: false, createdAt: '2024-03-08' }
    ];
    
    setCustomerIDs(demoIDs);
    setFilteredIDs(demoIDs);
  }, []);
  
  // Filtrar IDs baseado na busca
  useEffect(() => {
    let filtered = [...customerIDs];
    
    if (searchQuery) {
      filtered = filtered.filter(item => 
        item.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.address.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (showSharedOnly) {
      filtered = filtered.filter(item => item.isShared);
    }
    
    setFilteredIDs(filtered);
  }, [searchQuery, customerIDs, showSharedOnly]);
  
  // Funções para gerenciamento de IDs
  const generateCustomerID = () => {
    if (!formData.companyName || !formData.cityName) return '';
    
    // Lógica para nomes compostos
    const companyWords = formData.companyName.trim().split(/\s+/);
    const cityWords = formData.cityName.trim().split(/\s+/);
    
    let companyPrefix = '';
    let cityPrefix = '';
    
    // Regra para nome da empresa
    if (companyWords.length === 1) {
      // Nome simples: usar as três primeiras letras
      companyPrefix = companyWords[0].substring(0, 3).toUpperCase();
    } else {
      // Nome composto: primeira letra da primeira palavra + duas primeiras letras da segunda
      companyPrefix = (
        companyWords[0].substring(0, 1) + 
        companyWords[1].substring(0, 2)
      ).toUpperCase();
    }
    
    // Regra para nome da cidade
    if (cityWords.length === 1) {
      // Nome simples: usar as três primeiras letras
      cityPrefix = cityWords[0].substring(0, 3).toUpperCase();
    } else {
      // Nome composto: primeira letra da primeira palavra + duas primeiras letras da segunda
      cityPrefix = (
        cityWords[0].substring(0, 1) + 
        cityWords[1].substring(0, 2)
      ).toUpperCase();
    }
    
    // Verificar duplicidade
    const baseID = companyPrefix + cityPrefix;
    const similarIDs = customerIDs.filter(item => item.id.startsWith(baseID));
    
    // Adicionar número sequencial se necessário
    if (similarIDs.length > 0) {
      return `${baseID}${String(similarIDs.length + 1).padStart(2, '0')}`;
    }
    
    return baseID;
  };
  
  const handleCreateID = () => {
    if (!formData.companyName || !formData.cityName || !formData.address) return;
    
    const newID = {
      id: generateCustomerID(),
      name: formData.companyName,
      city: formData.cityName,
      address: formData.address,
      entranceNotes: formData.entranceNotes,
      isShared: formData.isShared,
      createdAt: new Date().toISOString().split('T')[0]
    };
    
    setCustomerIDs([newID, ...customerIDs]);
    resetForm();
  };
  
  const handleUpdateID = () => {
    if (!isEditingID) return;
    
    const updatedIDs = customerIDs.map(item => {
      if (item.id === isEditingID) {
        return {
          ...item,
          name: formData.companyName,
          city: formData.cityName,
          address: formData.address,
          entranceNotes: formData.entranceNotes,
          isShared: formData.isShared
        };
      }
      return item;
    });
    
    setCustomerIDs(updatedIDs);
    resetForm();
  };
  
  const handleDeleteID = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este Customer ID?')) {
      setCustomerIDs(customerIDs.filter(item => item.id !== id));
    }
  };
  
  const handleEditID = (id) => {
    const customer = customerIDs.find(item => item.id === id);
    if (customer) {
      setFormData({
        companyName: customer.name,
        cityName: customer.city,
        address: customer.address,
        entranceNotes: customer.entranceNotes || '',
        isShared: customer.isShared
      });
      setIsEditingID(id);
      setIsCreatingID(true);
      setIsImporting(false);
    }
  };
  
  const resetForm = () => {
    setFormData({
      companyName: '',
      cityName: '',
      address: '',
      entranceNotes: '',
      isShared: true
    });
    setIsCreatingID(false);
    setIsEditingID(null);
  };
  
  // Componente: Formulário de criação/edição
  const CustomerIDForm = () => (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">
          {isEditingID ? 'Editar Customer ID' : 'Criar Novo Customer ID'}
        </h2>
        <button 
          onClick={resetForm}
          className="text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-gray-700 text-sm font-medium mb-2">
            Nome da Empresa*
          </label>
          <input
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="Ex: Transportadora KingRoad"
            value={formData.companyName}
            onChange={(e) => setFormData({...formData, companyName: e.target.value})}
          />
        </div>
        
        <div>
          <label className="block text-gray-700 text-sm font-medium mb-2">
            Cidade*
          </label>
          <input
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="Ex: São Paulo"
            value={formData.cityName}
            onChange={(e) => setFormData({...formData, cityName: e.target.value})}
          />
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-medium mb-2">
          Endereço Completo*
        </label>
        <input
          type="text"
          className="w-full px-3 py-2 border border-gray-300 rounded-md"
          placeholder="Ex: Av. Paulista, 1000 - Bela Vista"
          value={formData.address}
          onChange={(e) => setFormData({...formData, address: e.target.value})}
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-medium mb-2">
          Instruções para Entrada (Observações)
        </label>
        <textarea
          className="w-full px-3 py-2 border border-gray-300 rounded-md"
          placeholder="Ex: Entrada pela lateral, seguir para o dock 3"
          value={formData.entranceNotes}
          onChange={(e) => setFormData({...formData, entranceNotes: e.target.value})}
          rows={3}
        />
      </div>
      
      <div className="mb-6">
        <label className="inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            className="form-checkbox h-5 w-5 text-yellow-600"
            checked={formData.isShared}
            onChange={(e) => setFormData({...formData, isShared: e.target.checked})}
          />
          <span className="ml-2 text-gray-700">Compartilhar com outros motoristas</span>
        </label>
      </div>
      
      {!isEditingID && (
        <div className="mb-4 p-4 bg-gray-100 rounded-md">
          <h3 className="font-medium text-gray-800 mb-2">Customer ID Gerado</h3>
          <div className="flex items-center">
            <span className="text-2xl font-bold text-yellow-600">
              {formData.companyName && formData.cityName 
                ? generateCustomerID() 
                : 'Preencha os campos obrigatórios'}
            </span>
            <Info size={16} className="ml-2 text-gray-500" />
          </div>
          <p className="text-sm text-gray-600 mt-1">
            ID gerado automaticamente baseado no nome da empresa e cidade
          </p>
        </div>
      )}
      
      <div className="flex justify-end space-x-3">
        <button 
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md"
          onClick={resetForm}
        >
          Cancelar
        </button>
        <button 
          className="px-4 py-2 bg-yellow-600 text-white rounded-md flex items-center"
          onClick={isEditingID ? handleUpdateID : handleCreateID}
          disabled={!formData.companyName || !formData.cityName || !formData.address}
        >
          <Save size={18} className="mr-2" />
          {isEditingID ? 'Atualizar' : 'Criar Customer ID'}
        </button>
      </div>
    </div>
  );
  
  // Componente: Formulário de importação
  const ImportForm = () => (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">
          Importar Customer IDs
        </h2>
        <button 
          onClick={() => setIsImporting(false)}
          className="text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>
      </div>
      
      <div className="border-2 border-dashed rounded-lg p-8 text-center mb-6 border-gray-300">
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-800 mb-2">
          Arraste um arquivo ou clique para importar
        </h3>
        <p className="text-gray-500 mb-4">
          Formatos suportados: CSV, Excel (XLSX) ou JSON
        </p>
        <button className="px-4 py-2 bg-yellow-600 text-white rounded-md">
          Selecionar Arquivo
        </button>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-md mb-6">
        <h3 className="font-medium text-gray-800 mb-2">Modelo para Importação</h3>
        <p className="text-gray-600 text-sm mb-3">
          Faça o download do modelo para garantir que todos os campos necessários estejam incluídos.
        </p>
        <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md flex items-center inline-flex">
          <Download size={18} className="mr-2" />
          Download do Template
        </button>
      </div>
    </div>
  );
  
  // Componente: Tabela de Customer IDs
  const CustomerIDsTable = () => (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <table className="min-w-full">
        <thead className="bg-gray-100">
          <tr>
            <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Customer ID</th>
            <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Empresa</th>
            <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Cidade</th>
            <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Compartilhado</th>
            <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase">Data de Criação</th>
            <th className="py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {filteredIDs.length > 0 ? (
            filteredIDs.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="py-4 px-4 whitespace-nowrap">
                  <div className="font-bold text-yellow-600">{item.id}</div>
                </td>
                <td className="py-4 px-4 whitespace-nowrap">
                  <div className="text-gray-900">{item.name}</div>
                </td>
                <td className="py-4 px-4 whitespace-nowrap">
                  <div className="text-gray-500">{item.city}</div>
                </td>
                <td className="py-4 px-4 whitespace-nowrap">
                  {item.isShared ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Sim
                    </span>
                  ) : (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                      Não
                    </span>
                  )}
                </td>
                <td className="py-4 px-4 whitespace-nowrap text-gray-500">
                  {item.createdAt}
                </td>
                <td className="py-4 px-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex justify-end space-x-2">
                    <button 
                      onClick={() => handleEditID(item.id)}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit size={18} />
                    </button>
                    <button 
                      onClick={() => handleDeleteID(item.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={6} className="py-8 text-center text-gray-500">
                Nenhum Customer ID encontrado. Crie um novo ou ajuste seus filtros.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
  
  // Componente: Grid de Customer IDs
  const CustomerIDsGrid = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredIDs.length > 0 ? (
        filteredIDs.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-5 border-b">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold text-yellow-600">{item.id}</h3>
                  <p className="text-gray-900 font-medium">{item.name}</p>
                  <p className="text-gray-500">{item.city}</p>
                </div>
                <div>
                  {item.isShared ? (
                    <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Compartilhado
                    </span>
                  ) : (
                    <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                      Privado
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="p-5">
              <p className="text-gray-600 text-sm mb-3">
                <span className="font-medium">Endereço:</span> {item.address}
              </p>
              
              {item.entranceNotes && (
                <p className="text-gray-600 text-sm mb-3">
                  <span className="font-medium">Instruções de entrada:</span> {item.entranceNotes}
                </p>
              )}
              
              <p className="text-gray-500 text-xs">
                Criado em {item.createdAt}
              </p>
            </div>
            
            <div className="px-5 py-3 bg-gray-50 flex justify-end space-x-2">
              <button 
                onClick={() => handleEditID(item.id)}
                className="p-2 text-indigo-600 hover:text-indigo-900 hover:bg-indigo-50 rounded"
              >
                <Edit size={18} />
              </button>
              <button 
                onClick={() => handleDeleteID(item.id)}
                className="p-2 text-red-600 hover:text-red-900 hover:bg-red-50 rounded"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))
      ) : (
        <div className="col-span-full py-8 text-center text-gray-500">
          Nenhum Customer ID encontrado. Crie um novo ou ajuste seus filtros.
        </div>
      )}
    </div>
  );
  
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Cabeçalho */}
      <header className="bg-yellow-600 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-white">
                KingRoad
              </h1>
              <span className="ml-4 bg-yellow-500 text-white text-sm font-medium px-3 py-1 rounded-full">
                Portal de Empresas
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center bg-yellow-500 text-white rounded-full px-3 py-1">
                <Building2 size={16} className="mr-2" />
                <span className="font-medium">{company.name}</span>
              </div>
              
              <button className="bg-white text-yellow-600 px-4 py-2 rounded-md font-medium">
                Minha Conta
              </button>
            </div>
          </div>
        </div>
      </header>
      
      {/* Conteúdo principal */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Gerenciamento de Customer IDs</h2>
            <p className="text-gray-600 mt-1">
              Crie e gerencie Customer IDs para seus clientes e pontos de entrega
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => {
                setIsImporting(true);
                setIsCreatingID(false);
                setIsEditingID(null);
              }}
              className="px-4 py-2 bg-white text-gray-700 rounded-md shadow hover:bg-gray-50"
            >
              <Upload size={18} className="mr-2 inline-block" />
              Importar
            </button>
            
            <button 
              onClick={() => {
                setIsCreatingID(true);
                setIsImporting(false);
                setIsEditingID(null);
              }}
              className="px-4 py-2 bg-yellow-600 text-white rounded-md shadow hover:bg-yellow-700"
            >
              <PlusCircle size={18} className="mr-2 inline-block" />
              Novo Customer ID
            </button>
          </div>
        </div>
        
        {/* Formulários */}
        {isCreatingID && <CustomerIDForm />}
        {isImporting && <ImportForm />}
        
        {/* Barra de ferramentas */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 bg-white p-4 rounded-lg shadow">
          <div className="w-full md:w-auto mb-4 md:mb-0 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Buscar por ID, empresa, cidade ou endereço..."
              className="pl-10 w-full md:w-80 px-4 py-2 border border-gray-300 rounded-md"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center space-x-4">
            <label className="inline-flex items-center">
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-yellow-600"
                checked={showSharedOnly}
                onChange={(e) => setShowSharedOnly(e.target.checked)}
              />
              <span className="ml-2 text-gray-700">Apenas compartilhados</span>
            </label>
            
            <div className="border-l border-gray-300 h-6 mx-2"></div>
            
            <div className="flex border border-gray-300 rounded-md overflow-hidden">
              <button 
                className={`p-2 ${viewMode === 'table' ? 'bg-gray-200' : 'bg-white'}`}
                onClick={() => setViewMode('table')}
              >
                <List size={18} className="text-gray-700" />
              </button>
              <button 
                className={`p-2 ${viewMode === 'grid' ? 'bg-gray-200' : 'bg-white'}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid size={18} className="text-gray-700" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Lista de Customer IDs */}
        <div className="mt-4">
          {viewMode === 'table' ? <CustomerIDsTable /> : <CustomerIDsGrid />}
        </div>
      </main>
    </div>
  );
};

export default CompanyPortal;