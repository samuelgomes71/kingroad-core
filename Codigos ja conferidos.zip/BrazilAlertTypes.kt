package com.kingroad.security.alerts.brazil

import kotlinx.serialization.Serializable
import kotlinx.datetime.Instant
import kotlinx.datetime.Clock

/**
 * Enumeração com os tipos de alertas específicos para o Brasil
 */
enum class BrazilAlertType {
    SHOOTING,           // Tiroteio
    KIDNAPPING,         // Sequestro/Arrastão
    CARGO_THEFT,        // Roubo de Carga (versão brasileira)
    SUSPICIOUS_VEHICLE, // Veículo Suspeito
    SPEEDING_VEHICLE    // Veículo em Alta Velocidade
}

/**
 * Extensão da entidade SecurityAlert para alertas específicos do Brasil
 */
@Serializable
data class BrazilSecurityAlert(
    val id: String,
    val type: BrazilAlertType,
    val userId: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Instant = Clock.System.now(),
    val description: String? = null,
    // Campos específicos por tipo de alerta
    val shootingInfo: ShootingInfo? = null,
    val kidnappingInfo: KidnappingInfo? = null,
    val cargoTheftInfo: CargoTheftInfo? = null,
    val suspiciousVehicleInfo: SuspiciousVehicleInfo? = null,
    val speedingVehicleInfo: SpeedingVehicleInfo? = null,
    // Campos para integração com sistema de reputação
    val verificationCount: Int = 0,
    val confirmationCount: Int = 0,
    val isVerified: Boolean = false
)

/**
 * Informações específicas para alertas de tiroteio
 */
@Serializable
data class ShootingInfo(
    val intensity: ShootingIntensity,
    val isOngoing: Boolean = true,
    val involvedGroups: List<String>? = null,
    val estimatedDuration: Int? = null // Duração estimada em minutos
)

/**
 * Intensidade do tiroteio
 */
enum class ShootingIntensity {
    LOW,    // Poucos disparos, situação contida
    MEDIUM, // Troca de tiros intensa, mas localizada
    HIGH    // Confronto generalizado com múltiplas armas
}

/**
 * Informações específicas para alertas de sequestro/arrastão
 */
@Serializable
data class KidnappingInfo(
    val kidnapType: KidnapType,
    val vehiclesCount: Int? = null,
    val isOngoing: Boolean = true,
    val victimsCount: Int? = null
)

/**
 * Tipos de sequestro/arrastão
 */
enum class KidnapType {
    KIDNAPPING,    // Sequestro tradicional
    FLASH_KIDNAP,  // Sequestro relâmpago
    MASS_ROBBERY   // Arrastão
}

/**
 * Informações específicas para alertas de roubo de carga (versão brasileira)
 */
@Serializable
data class CargoTheftInfo(
    val isBlockingRoad: Boolean = false,
    val weaponsPresent: Boolean = false,
    val vehiclesCount: Int? = null,
    val isTargetingSpecificCargo: Boolean = false,
    val targetedCargoType: String? = null
)

/**
 * Informações específicas para alertas de veículo suspeito
 */
@Serializable
data class SuspiciousVehicleInfo(
    val vehicleModel: String? = null,
    val vehicleColor: String? = null,
    val licensePlate: String? = null,
    val suspiciousActivity: SuspiciousActivity,
    val occupantsCount: Int? = null,
    val direction: String? = null
)

/**
 * Tipos de atividades suspeitas
 */
enum class SuspiciousActivity {
    FOLLOWING_TRUCKS,          // Seguindo caminhões
    MONITORING_ROAD,           // Monitorando a estrada
    SUSPICIOUS_STOPS,          // Paradas suspeitas
    FAKE_POLICE,               // Falsa blitz/polícia
    SUSPICIOUS_COMMUNICATION   // Comunicações suspeitas via rádio ou sinalizações
}

/**
 * Informações específicas para alertas de veículo em alta velocidade
 */
@Serializable
data class SpeedingVehicleInfo(
    val vehicleModel: String? = null,
    val vehicleColor: String? = null,
    val licensePlate: String? = null,
    val estimatedSpeed: Int? = null,
    val isDrivingDangerously: Boolean = false,
    val direction: String? = null,
    val dangerousManeuvers: List<DangerousManeuver>? = null
)

/**
 * Tipos de manobras perigosas
 */
enum class DangerousManeuver {
    ZIGZAGGING,       // Zigue-zague entre veículos
    TAILGATING,       // Cola na traseira
    HARD_BRAKING,     // Freadas bruscas
    WRONG_WAY,        // Contramão
    SHOULDER_DRIVING, // Dirigindo pelo acostamento
    RACING            // Aparentemente em corrida com outro veículo
}

/**
 * Interface para configurações específicas de alertas brasileiros
 */
interface BrazilAlertConfiguration {
    val notificationRadius: Map<BrazilAlertType, Double>
    val alertPriority: Map<BrazilAlertType, Int>
    val alertExpirationTime: Map<BrazilAlertType, Long> // Em minutos
    
    companion object {
        // Implementação padrão
        val DEFAULT = object : BrazilAlertConfiguration {
            override val notificationRadius = mapOf(
                BrazilAlertType.SHOOTING to 5000.0,          // 5km
                BrazilAlertType.KIDNAPPING to 10000.0,       // 10km
                BrazilAlertType.CARGO_THEFT to 20000.0,      // 20km
                BrazilAlertType.SUSPICIOUS_VEHICLE to 5000.0,// 5km
                BrazilAlertType.SPEEDING_VEHICLE to 3000.0   // 3km
            )
            
            override val alertPriority = mapOf(
                BrazilAlertType.SHOOTING to 1,           // Prioridade máxima
                BrazilAlertType.KIDNAPPING to 2,
                BrazilAlertType.CARGO_THEFT to 3,
                BrazilAlertType.SUSPICIOUS_VEHICLE to 4,
                BrazilAlertType.SPEEDING_VEHICLE to 5
            )
            
            override val alertExpirationTime = mapOf(
                BrazilAlertType.SHOOTING to 60L,         // 1 hora
                BrazilAlertType.KIDNAPPING to 120L,      // 2 horas
                BrazilAlertType.CARGO_THEFT to 180L,     // 3 horas
                BrazilAlertType.SUSPICIOUS_VEHICLE to 60L,// 1 hora
                BrazilAlertType.SPEEDING_VEHICLE to 30L  // 30 minutos
            )
        }
    }
}