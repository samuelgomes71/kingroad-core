import React, { useState } from 'react';
import { Map, Satellite, Mountain } from 'lucide-react';

const MapModeToggleButton = ({ onModeChange }) => {
  const [currentMode, setCurrentMode] = useState('standard');
  
  const modes = [
    { id: 'standard', icon: Map, label: 'Normal', color: 'bg-blue-500' },
    { id: 'satellite', icon: Satellite, label: 'Satélite', color: 'bg-green-600' },
    { id: 'terrain', icon: Mountain, label: 'Relevo', color: 'bg-amber-700' }
  ];
  
  const handleModeChange = () => {
    const currentIndex = modes.findIndex(mode => mode.id === currentMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    const nextMode = modes[nextIndex].id;
    
    setCurrentMode(nextMode);
    onModeChange(nextMode);
  };
  
  const currentModeObj = modes.find(mode => mode.id === currentMode);
  
  return (
    <div className="absolute right-4 top-24 z-10">
      <div className="flex flex-col items-center">
        <button
          onClick={handleModeChange}
          className={`${currentModeObj.color} hover:opacity-90 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center relative`}
          aria-label={`Alternar para modo ${currentModeObj.label}`}
        >
          {React.createElement(currentModeObj.icon, { size: 24 })}
        </button>
        <span className="mt-1 text-xs font-medium bg-white px-2 py-1 rounded-full shadow text-gray-700">
          {currentModeObj.label}
        </span>
      </div>
    </div>
  );
};

export default MapModeToggleButton;