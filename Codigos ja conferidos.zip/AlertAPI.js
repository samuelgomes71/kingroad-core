import { useContext } from 'react';
import { AlertContext } from './AlertContext';

/**
 * API global para usar fora de componentes React
 */
export const AlertAPI = {
  success: (message, options = {}) => {
    const context = useContext(AlertContext);
    if (context) {
      return context.success(message, options);
    }
    console.error('Alert.success chamado fora do AlertProvider');
    return null;
  },
  
  error: (message, options = {}) => {
    const context = useContext(AlertContext);
    if (context) {
      return context.error(message, options);
    }
    console.error('Alert.error chamado fora do AlertProvider');
    return null;
  },
  
  warning: (message, options = {}) => {
    const context = useContext(AlertContext);
    if (context) {
      return context.warning(message, options);
    }
    console.error('Alert.warning chamado fora do AlertProvider');
    return null;
  },
  
  info: (message, options = {}) => {
    const context = useContext(AlertContext);
    if (context) {
      return context.info(message, options);
    }
    console.error('Alert.info chamado fora do AlertProvider');
    return null;
  }
};