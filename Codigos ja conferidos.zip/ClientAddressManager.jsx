import React, { useState, useEffect } from 'react';
import { Upload, FileText, Search, MapPin, Database, RefreshCw, CheckCircle, AlertCircle, Download } from 'lucide-react';
import Papa from 'papaparse';

const ClientAddressManager = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [clientLists, setClientLists] = useState([]);
  const [currentList, setCurrentList] = useState(null);
  const [processedClients, setProcessedClients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [processingStatus, setProcessingStatus] = useState('idle'); // 'idle', 'processing', 'success', 'error'
  const [statusMessage, setStatusMessage] = useState('');
  const [selectedFolder, setSelectedFolder] = useState('');
  const [showClientDetails, setShowClientDetails] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  
  // Simula a estrutura de pastas do cliente
  const clientFolders = [
    { id: 1, name: 'PRIMAFRIO', lastUpdate: '12/02/2024', count: 2872 },
    { id: 2, name: 'ACME Transportes', lastUpdate: '05/02/2024', count: 543 },
    { id: 3, name: 'LogTech', lastUpdate: '20/01/2024', count: 1254 }
  ];
  
  // Exemplo de dados processados (para simulação)
  const sampleProcessedData = [
    {
      id: 1,
      name: "Central de Distribuição Madrid",
      address: "Calle de la Industria, 45",
      postalCode: "28108",
      city: "Alcobendas",
      state: "Madrid",
      country: "Espanha",
      coordinates: { lat: 40.5487, lng: -3.6430 },
      lastVisit: "10/01/2024",
      notes: "Entrada para caminhões pela lateral, rampa de carga automática"
    },
    {
      id: 2,
      name: "Mercadona Central",
      address: "Polígono Industrial El Mazo, 14",
      postalCode: "39311",
      city: "Cartes",
      state: "Cantabria",
      country: "Espanha",
      coordinates: { lat: 43.3202, lng: -4.0657 },
      lastVisit: "22/01/2024",
      notes: "Horário de recebimento: 6h-11h"
    },
    {
      id: 3,
      name: "Lidl Centro Logístico",
      address: "Carretera de Villaverde a Vallecas, 265",
      postalCode: "28031",
      city: "Madrid",
      state: "Madrid",
      country: "Espanha",
      coordinates: { lat: 40.3491, lng: -3.6011 },
      lastVisit: "05/02/2024",
      notes: "Requer agendamento prévio"
    },
    {
      id: 4,
      name: "Central Frutas Santos",
      address: "Calle Río Segura, 10",
      postalCode: "30565",
      city: "Las Torres de Cotillas",
      state: "Murcia",
      country: "Espanha",
      coordinates: { lat: 38.0322, lng: -1.2418 },
      lastVisit: "18/01/2024",
      notes: "Docas de descarga específicas para produtos refrigerados"
    },
    {
      id: 5,
      name: "ALDI Plataforma Logística",
      address: "Av. de Castilla-La Mancha, 95",
      postalCode: "45200",
      city: "Illescas",
      state: "Toledo",
      country: "Espanha",
      coordinates: { lat: 40.1250, lng: -3.8465 },
      lastVisit: "29/01/2024",
      notes: "Centro automatizado, seguir procedimentos específicos"
    }
  ];
  
  // Simula o processamento de arquivos
  const processClientFiles = () => {
    if (!selectedFolder) {
      setStatusMessage('Por favor, selecione uma pasta para processar');
      setProcessingStatus('error');
      return;
    }
    
    setProcessingStatus('processing');
    setStatusMessage('Processando arquivos, aguarde...');
    
    // Simulação de processamento
    setTimeout(() => {
      // Simular o sucesso do processamento
      setProcessedClients(sampleProcessedData);
      setCurrentList(clientFolders.find(f => f.name === selectedFolder));
      setProcessingStatus('success');
      setStatusMessage(`${sampleProcessedData.length} endereços processados e convertidos com sucesso.`);
    }, 2500);
  };
  
  // Filtra clientes baseado no termo de busca
  const filteredClients = processedClients.filter(client => {
    const searchTermLower = searchTerm.toLowerCase();
    return (
      client.name.toLowerCase().includes(searchTermLower) ||
      client.address.toLowerCase().includes(searchTermLower) ||
      client.city.toLowerCase().includes(searchTermLower)
    );
  });
  
  // Função para converter dados de diferentes formatos
  const convertFileToStandardFormat = (fileContent, fileType) => {
    // Na implementação real, aqui seriam processados diferentes tipos de arquivo
    // Esta é uma versão simplificada para demonstração
    let parsedData = [];
    
    try {
      if (fileType === 'csv') {
        parsedData = Papa.parse(fileContent, { header: true, skipEmptyLines: true }).data;
      } else if (fileType === 'xlsx' || fileType === 'xls') {
        // Na implementação real, usaria outra abordagem ou biblioteca para Excel
        // Esta é apenas uma simulação para demonstração
        console.log("Processando arquivo Excel");
        
        // Simulando dados estruturados que viriam do Excel
        // Na versão real, usaria a biblioteca adequada para processar o binário do Excel
        parsedData = [
          { cliente: "Cliente 1", endereco: "Endereço 1", cidade: "Cidade 1" },
          { cliente: "Cliente 2", endereco: "Endereço 2", cidade: "Cidade 2" }
        ];
      } else {
        // Formato de texto ou outro
        // Implementação simplificada para texto e outros formatos
        const lines = fileContent.split('\n\n');
        
        parsedData = lines.map((block, idx) => {
          const blockLines = block.split('\n');
          return {
            cliente: blockLines[0] || `Cliente ${idx+1}`,
            endereco: blockLines[1] || "",
            cidade: blockLines[2] || "",
          };
        });
      }
      
      // Processo de normalização de dados
      return parsedData.map(row => {
        // Normalização e enriquecimento de dados
        // Aqui seria feita a conversão para o formato padrão do King Road
        // Geocodificação de endereços para obter coordenadas
        return {
          id: Math.floor(Math.random() * 10000),
          name: row.name || row.Nome || row.empresa || row.cliente || "",
          address: row.address || row.endereco || row.direccion || "",
          postalCode: row.postalCode || row.cep || row.codigoPostal || "",
          city: row.city || row.cidade || row.ciudad || "",
          state: row.state || row.estado || row.provincia || "",
          country: row.country || row.pais || "Espanha",
          coordinates: { lat: parseFloat(row.latitude || 0), lng: parseFloat(row.longitude || 0) },
          notes: row.notes || row.observacoes || row.notas || ""
        };
      });
    } catch (error) {
      console.error("Erro na conversão de dados:", error);
      return [];
    }
  };

  // Visualizar detalhes do cliente
  const viewClientDetails = (client) => {
    setSelectedClient(client);
    setShowClientDetails(true);
  };
  
  // Componente para exibição de detalhes do cliente
  const ClientDetailsView = () => {
    if (!selectedClient) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
        <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg max-w-md w-full p-6`}>
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold">{selectedClient.name}</h2>
            <button 
              onClick={() => setShowClientDetails(false)}
              className="text-gray-400 hover:text-gray-200"
            >
              ✕
            </button>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-4 mb-4">
            <div className="flex items-start">
              <MapPin className="w-5 h-5 text-blue-400 mr-2 mt-1 flex-shrink-0" />
              <div>
                <p>{selectedClient.address}</p>
                <p>{selectedClient.postalCode}, {selectedClient.city}</p>
                <p>{selectedClient.state}, {selectedClient.country}</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-gray-700 p-3 rounded-lg">
              <div className="text-xs text-gray-400 mb-1">Latitude</div>
              <div className="font-mono">{selectedClient.coordinates.lat.toFixed(6)}</div>
            </div>
            
            <div className="bg-gray-700 p-3 rounded-lg">
              <div className="text-xs text-gray-400 mb-1">Longitude</div>
              <div className="font-mono">{selectedClient.coordinates.lng.toFixed(6)}</div>
            </div>
          </div>
          
          {selectedClient.notes && (
            <div className="bg-gray-700 p-3 rounded-lg mb-4">
              <div className="text-xs text-gray-400 mb-1">Observações</div>
              <div className="text-sm">{selectedClient.notes}</div>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-3">
            <button 
              className="py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center justify-center"
              onClick={() => setShowClientDetails(false)}
            >
              <MapPin className="w-4 h-4 mr-1" />
              Navegar até aqui
            </button>
            
            <button 
              className="py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
              onClick={() => setShowClientDetails(false)}
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className={`${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'} min-h-screen p-4`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-6 border-b border-gray-700 pb-3">
        <div className="flex items-center">
          <Database className="w-6 h-6 mr-2 text-blue-500" />
          <h1 className="text-xl font-bold">King Road - Gerenciador de Endereços de Clientes</h1>
        </div>
      </div>
      
      {/* Seleção de pasta e processamento */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-6`}>
        <h2 className="text-lg font-medium mb-4 flex items-center">
          <FileText className="w-5 h-5 mr-2 text-blue-500" />
          Importar Lista de Clientes
        </h2>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Selecione a Pasta com Arquivos de Clientes:</label>
          <div className="flex">
            <select
              className={`flex-grow p-2 rounded-l-lg ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'} border`}
              value={selectedFolder}
              onChange={(e) => setSelectedFolder(e.target.value)}
            >
              <option value="">Selecione uma pasta...</option>
              {clientFolders.map(folder => (
                <option key={folder.id} value={folder.name}>
                  {folder.name} ({folder.count} clientes)
                </option>
              ))}
            </select>
            <button
              className="px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-r-lg"
              onClick={processClientFiles}
              disabled={processingStatus === 'processing'}
            >
              {processingStatus === 'processing' ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <Upload className="w-5 h-5" />
              )}
            </button>
          </div>
          <p className="mt-1 text-xs text-gray-400">
            Arquivos suportados: Excel (.xlsx, .xls), CSV, texto (.txt) e PDFs com tabelas
          </p>
        </div>
        
        {/* Mensagem de status */}
        {processingStatus !== 'idle' && (
          <div className={`p-3 rounded-lg mb-4 ${
            processingStatus === 'processing' ? 'bg-blue-900/30 text-blue-300' :
            processingStatus === 'success' ? 'bg-green-900/30 text-green-300' :
            'bg-red-900/30 text-red-300'
          }`}>
            <div className="flex items-center">
              {processingStatus === 'processing' && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
              {processingStatus === 'success' && <CheckCircle className="w-4 h-4 mr-2" />}
              {processingStatus === 'error' && <AlertCircle className="w-4 h-4 mr-2" />}
              <span>{statusMessage}</span>
            </div>
          </div>
        )}
        
        <div className="border-t border-gray-700 pt-4 mt-4">
          <h3 className="text-sm font-medium mb-2">Recursos do Gerenciador de Endereços:</h3>
          <ul className="text-sm space-y-1 list-disc pl-5">
            <li>Reconhecimento automático de formatos diversos (Excel, CSV, PDF, texto)</li>
            <li>Normalização de endereços para o formato padrão do King Road</li>
            <li>Conversão automática para coordenadas GPS (geocodificação)</li>
            <li>Catálogo com busca e navegação rápida para destinos frequentes</li>
            <li>Organização por pastas para diferentes clientes ou regiões</li>
          </ul>
        </div>
      </div>
      
      {/* Lista de clientes processados */}
      {processedClients.length > 0 && (
        <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-6`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium flex items-center">
              <Database className="w-5 h-5 mr-2 text-blue-500" />
              Lista de Clientes: {currentList?.name}
            </h2>
            <div className="text-sm text-gray-400">
              {processedClients.length} endereços
            </div>
          </div>
          
          {/* Busca */}
          <div className="relative mb-4">
            <input
              type="text"
              className={`w-full pl-10 pr-4 py-2 rounded-lg ${isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-900'}`}
              placeholder="Buscar por nome, endereço ou cidade..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
          </div>
          
          {/* Lista de clientes */}
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {filteredClients.length > 0 ? (
              filteredClients.map(client => (
                <div
                  key={client.id}
                  className={`p-3 rounded-lg ${isDarkMode ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} cursor-pointer transition-colors`}
                  onClick={() => viewClientDetails(client)}
                >
                  <div className="flex justify-between">
                    <div className="font-medium">{client.name}</div>
                    <div className="text-xs text-gray-400">
                      {client.lastVisit ? `Última visita: ${client.lastVisit}` : ''}
                    </div>
                  </div>
                  <div className="text-sm text-gray-400 flex items-start mt-1">
                    <MapPin className="w-4 h-4 mr-1 flex-shrink-0 mt-0.5" />
                    <div>{client.address}, {client.city}</div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-gray-500">
                Nenhum cliente encontrado com o termo "{searchTerm}"
              </div>
            )}
          </div>
          
          {/* Ações para a lista */}
          <div className="flex justify-between mt-4 pt-3 border-t border-gray-700">
            <button
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm flex items-center"
              onClick={() => {
                setProcessedClients([]);
                setCurrentList(null);
                setSearchTerm('');
                setProcessingStatus('idle');
              }}
            >
              <RefreshCw className="w-4 h-4 mr-1" />
              Nova Importação
            </button>
            
            <button
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm flex items-center"
              onClick={() => {}}
            >
              <Download className="w-4 h-4 mr-1" />
              Exportar Lista
            </button>
          </div>
        </div>
      )}
      
      {/* Modal de detalhes */}
      {showClientDetails && <ClientDetailsView />}
      
      {/* Instruções para uso */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4`}>
        <h2 className="text-lg font-medium mb-4">Como Usar o Gerenciador de Endereços</h2>
        
        <div className="space-y-4 text-sm">
          <div>
            <h3 className="font-medium text-blue-400 mb-1">1. Preparação dos Arquivos</h3>
            <p>Coloque todos os arquivos de clientes em uma pasta com o nome da empresa ou categoria.</p>
            <p className="text-gray-400 mt-1">Exemplo: Criar uma pasta "PRIMAFRIO" e colocar dentro os arquivos com listas de clientes.</p>
          </div>
          
          <div>
            <h3 className="font-medium text-blue-400 mb-1">2. Importação Automática</h3>
            <p>O King Road detectará automaticamente as colunas com dados de endereço, mesmo que estejam em formatos diferentes.</p>
            <p className="text-gray-400 mt-1">O sistema utiliza inteligência artificial para reconhecer endereços em vários formatos e idiomas.</p>
          </div>
          
          <div>
            <h3 className="font-medium text-blue-400 mb-1">3. Normalização e Geocodificação</h3>
            <p>Todos os endereços são convertidos para o formato padrão do King Road e enriquecidos com coordenadas GPS.</p>
            <p className="text-gray-400 mt-1">Endereços sem coordenadas são automaticamente geocodificados para garantir navegação precisa.</p>
          </div>
          
          <div>
            <h3 className="font-medium text-blue-400 mb-1">4. Navegação Rápida</h3>
            <p>Após processados, os endereços ficam disponíveis para busca rápida e navegação direta.</p>
            <p className="text-gray-400 mt-1">Basta buscar pelo nome do cliente ou endereço e iniciar a navegação com um clique.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientAddressManager;