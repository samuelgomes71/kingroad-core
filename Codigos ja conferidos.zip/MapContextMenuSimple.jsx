import React, { useState, useEffect, useRef } from 'react';
import { Truck, Car, Star, Ban, MapPin, Navigation, Flag, AlertTriangle, X } from 'lucide-react';

// Componente de menu de contexto simples
const MapContextMenuSimple = () => {
  // Estados
  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [routeStatus, setRouteStatus] = useState('idle'); // 'idle', 'planned', 'active'
  const [vehicleMode, setVehicleMode] = useState('truck');
  const [actions, setActions] = useState([]);
  const mapRef = useRef(null);
  
  // Simulação de pressionar e segurar
  useEffect(() => {
    const handleMouseDown = (e) => {
      // Simula "pressionar e segurar" com um clique regular para demonstração
      const x = e.clientX;
      const y = e.clientY;
      setPosition({ x, y });
      setIsOpen(true);
    };
    
    const element = mapRef.current;
    if (element) {
      element.addEventListener('mousedown', handleMouseDown);
    }
    
    return () => {
      if (element) {
        element.removeEventListener('mousedown', handleMouseDown);
      }
    };
  }, []);
  
  // Registra uma ação
  const logAction = (actionType, actionText) => {
    setActions(prev => [
      { type: actionType, text: actionText, time: new Date().toLocaleTimeString() },
      ...prev.slice(0, 4) // Mantém apenas as 5 ações mais recentes
    ]);
    setIsOpen(false);
  };
  
  // Alterna entre os estados de navegação
  const cycleRouteStatus = () => {
    setRouteStatus(prev => {
      if (prev === 'idle') return 'planned';
      if (prev === 'planned') return 'active';
      return 'idle';
    });
  };
  
  // Alterna o modo de veículo
  const toggleVehicleMode = () => {
    setVehicleMode(prev => prev === 'truck' ? 'car' : 'truck');
  };
  
  return (
    <div className="bg-gray-950 min-h-screen p-4">
      {/* Cabeçalho */}
      <div className="bg-gray-900 p-4 rounded-lg shadow-lg mb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-amber-400">KingRoad - Menu de Contexto</h1>
          <div className="flex space-x-2">
            <button 
              className="bg-gray-800 p-2 rounded text-white text-sm"
              onClick={toggleVehicleMode}
            >
              {vehicleMode === 'truck' ? 'Mudar para Carro' : 'Mudar para Caminhão'}
            </button>
            <button 
              className="bg-gray-800 p-2 rounded text-white text-sm"
              onClick={cycleRouteStatus}
            >
              Rota: {routeStatus === 'idle' ? 'Sem rota' : 
                    routeStatus === 'planned' ? 'Planejada' : 'Navegando'}
            </button>
          </div>
        </div>
      </div>
      
      {/* Instruções */}
      <div className="bg-gray-900 p-4 rounded-lg mb-4">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Instruções</h2>
        <p className="text-gray-300">
          Clique em qualquer lugar da área do mapa abaixo para simular 
          a funcionalidade de pressionar e segurar por 2 segundos.
        </p>
      </div>
      
      {/* Área do mapa simulada */}
      <div 
        ref={mapRef}
        className="bg-gray-800 rounded-lg h-64 mb-4 relative cursor-pointer"
        style={{
          backgroundImage: 'linear-gradient(to right, #444 1px, transparent 1px), linear-gradient(to bottom, #444 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-black bg-opacity-60 p-3 rounded text-white text-center">
            <p>Clique em qualquer lugar para abrir o menu</p>
          </div>
        </div>
        
        {/* Ícone de veículo atual */}
        <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="w-10 h-10 bg-blue-500 rounded-full border-2 border-white flex items-center justify-center">
            {vehicleMode === 'truck' ? 
              <Truck className="text-white" size={20} /> : 
              <Car className="text-white" size={20} />
            }
          </div>
        </div>
      </div>
      
      {/* Histórico de ações */}
      <div className="bg-gray-900 p-4 rounded-lg">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Ações Recentes</h2>
        {actions.length === 0 ? (
          <p className="text-gray-400 text-center p-4">Nenhuma ação realizada ainda</p>
        ) : (
          <div className="space-y-2">
            {actions.map((action, index) => (
              <div key={index} className="bg-gray-800 p-2 rounded flex items-center">
                <ActionIcon type={action.type} />
                <div className="ml-2 flex-1">
                  <div className="text-white">{action.text}</div>
                  <div className="text-xs text-gray-400">{action.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Menu de contexto */}
      {isOpen && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          <div 
            className="absolute inset-0 bg-black bg-opacity-50 pointer-events-auto"
            onClick={() => setIsOpen(false)}
          />
          
          <div 
            className="absolute bg-gray-900 rounded-lg shadow-xl pointer-events-auto w-72"
            style={{
              left: Math.min(position.x, window.innerWidth - 290),
              top: Math.min(position.y, window.innerHeight - 300)
            }}
          >
            {/* Cabeçalho do menu */}
            <div className="flex items-center justify-between p-3 border-b border-gray-800">
              <div className="flex items-center">
                <MapPin className="text-amber-400 mr-2" size={20} />
                <div>
                  <h3 className="font-bold text-white">Local selecionado</h3>
                  <p className="text-xs text-gray-400">Av. Paulista, 1578</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-gray-500 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>
            
            {/* Opções de menu */}
            <div className="p-3">
              <div className="space-y-2">
                {/* Menu quando não há rota */}
                {routeStatus === 'idle' && (
                  <>
                    <button
                      className="w-full bg-amber-500 hover:bg-amber-600 p-3 rounded-lg flex items-start transition-colors text-left text-black"
                      onClick={() => logAction('navigate', 'Navegação iniciada')}
                    >
                      <Navigation size={18} className="mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium">Navegar para este ponto</div>
                        <div className="text-xs text-black text-opacity-70">Iniciar navegação</div>
                      </div>
                    </button>
                    
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => logAction('start', 'Definido como ponto de partida')}
                    >
                      <Flag size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Definir como ponto de partida</div>
                        <div className="text-xs text-gray-400">Ponto A</div>
                      </div>
                    </button>
                    
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => logAction('end', 'Definido como destino')}
                    >
                      <MapPin size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Definir como destino</div>
                        <div className="text-xs text-gray-400">Ponto B</div>
                      </div>
                    </button>
                  </>
                )}
                
                {/* Menu quando há uma rota planejada ou ativa */}
                {(routeStatus === 'planned' || routeStatus === 'active') && (
                  <>
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => logAction('waypoint', 'Ponto de passagem adicionado')}
                    >
                      <MapPin size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Adicionar ponto de passagem</div>
                        <div className="text-xs text-gray-400">Passar por este ponto</div>
                      </div>
                    </button>
                    
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => logAction('favorite', 'Adicionado às rotas favoritas')}
                    >
                      <Star size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Adicionar às rotas favoritas</div>
                        <div className="text-xs text-gray-400">Preferencial para navegação</div>
                      </div>
                    </button>
                    
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => logAction('prohibited', 'Adicionado às rotas proibidas')}
                    >
                      <Ban size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Adicionar às rotas proibidas</div>
                        <div className="text-xs text-gray-400">Evitar esta rota</div>
                      </div>
                    </button>
                    
                    {vehicleMode === 'truck' && (
                      <button
                        className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                        onClick={() => logAction('articulated', 'Marcado como rota possível para caminhões articulados')}
                      >
                        <Truck size={18} className="text-amber-400 mr-3 mt-0.5" />
                        <div>
                          <div className="font-medium text-white">Rota para caminhões articulados</div>
                          <div className="text-xs text-gray-400">Apenas para destinos nesta área</div>
                        </div>
                      </button>
                    )}
                  </>
                )}
                
                {/* Opção comum para todos os estados */}
                <button
                  className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                  onClick={() => logAction('report', 'Problema reportado na via')}
                >
                  <AlertTriangle size={18} className="text-amber-400 mr-3 mt-0.5" />
                  <div>
                    <div className="font-medium text-white">Reportar problema na via</div>
                    <div className="text-xs text-gray-400">Buracos, bloqueios, etc.</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Componente auxiliar para ícones de ação
const ActionIcon = ({ type }) => {
  switch (type) {
    case 'navigate': return <Navigation size={16} className="text-amber-400" />;
    case 'start': return <Flag size={16} className="text-green-400" />;
    case 'end': return <MapPin size={16} className="text-red-400" />;
    case 'waypoint': return <MapPin size={16} className="text-blue-400" />;
    case 'favorite': return <Star size={16} className="text-amber-400" />;
    case 'prohibited': return <Ban size={16} className="text-red-400" />;
    case 'articulated': return <Truck size={16} className="text-green-400" />;
    case 'report': return <AlertTriangle size={16} className="text-amber-400" />;
    default: return <MapPin size={16} className="text-gray-400" />;
  }
};

export default MapContextMenuSimple;