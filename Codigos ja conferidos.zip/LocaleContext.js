/**
 * LocaleContext.js
 * 
 * Contexto para informações de idioma e localização.
 * Implementa contexto React para prover informações de localização e idioma 
 * para componentes, integrando com o LocaleService.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React, { createContext, useState, useEffect, useContext } from 'react';
import { NativeModules, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LocaleService from './LocaleService';

// Chave para armazenamento das preferências de idioma
const LOCALE_STORAGE_KEY = 'kingroad_locale_preference';

// Lista de locales suportados pela aplicação
export const SUPPORTED_LOCALES = [
  'pt-BR', // Português (Brasil) - idioma padrão
  'en-US', // Inglês (EUA)
  'es-ES', // Espanhol (Espanha)
  'fr-FR', // Francês (França)
  'de-DE', // Alemão (Alemanha)
  'it-IT', // Italiano (Itália)
  'ja-JP', // Japonês (Japão)
  'ko-KR', // Coreano (Coreia do Sul)
  'zh-CN', // Chinês Simplificado (China)
  'zh-TW', // Chinês Tradicional (Taiwan)
  'ru-RU', // Russo (Rússia)
  'ar-SA', // Árabe (Arábia Saudita)
  'hi-IN', // Hindi (Índia)
  'tr-TR', // Turco (Turquia)
  'nl-NL', // Holandês (Países Baixos)
  'pl-PL', // Polonês (Polônia)
  'sv-SE', // Sueco (Suécia)
  'fi-FI', // Finlandês (Finlândia)
  'da-DK', // Dinamarquês (Dinamarca)
  'no-NO', // Norueguês (Noruega)
  'cs-CZ', // Tcheco (República Tcheca)
  'hu-HU', // Húngaro (Hungria)
  'ro-RO', // Romeno (Romênia)
  'bg-BG', // Búlgaro (Bulgária)
  'el-GR', // Grego (Grécia)
  'he-IL', // Hebraico (Israel)
  'th-TH', // Tailandês (Tailândia)
  'id-ID', // Indonésio (Indonésia)
  'ms-MY', // Malaio (Malásia)
  'vi-VN', // Vietnamita (Vietnã)
  'fil-PH', // Filipino (Filipinas)
  'uk-UA', // Ucraniano (Ucrânia)
  'fa-IR', // Persa (Irã)
  'bn-BD'  // Bengali (Bangladesh)
];

// Criação do contexto
const LocaleContext = createContext();

/**
 * Provedor do LocaleContext
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Componentes filhos
 * @param {string} [props.defaultLocale='pt-BR'] - Locale padrão
 * @param {boolean} [props.useDeviceLocale=true] - Se deve tentar usar o locale do dispositivo
 * @param {Array<string>} [props.supportedLocales=SUPPORTED_LOCALES] - Lista de locales suportados
 */
export const LocaleProvider = ({
  children,
  defaultLocale = 'pt-BR',
  useDeviceLocale = true,
  supportedLocales = SUPPORTED_LOCALES
}) => {
  // Instancia o serviço de localização
  const [localeService] = useState(() => new LocaleService());
  
  // Estado para armazenar o locale atual
  const [locale, setLocale] = useState(defaultLocale);
  
  // Estado para armazenar informações de localização
  const [localeInfo, setLocaleInfo] = useState(null);
  
  // Estado para controlar carregamento
  const [loading, setLoading] = useState(true);
  
  /**
   * Obtém o locale do dispositivo
   * @returns {string} Locale do dispositivo ou defaultLocale se não encontrado
   */
  const getDeviceLocale = () => {
    try {
      // Tenta obter o locale do dispositivo
      let deviceLocale;
      
      if (Platform.OS === 'ios') {
        deviceLocale = NativeModules.SettingsManager.settings.AppleLocale ||
                       NativeModules.SettingsManager.settings.AppleLanguages[0];
      } else {
        deviceLocale = NativeModules.I18nManager.localeIdentifier;
      }
      
      // Formata o locale para garantir padrão xx-XX
      if (deviceLocale) {
        const parts = deviceLocale.split(/[-_]/);
        if (parts.length === 2) {
          deviceLocale = `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}`;
        }
      }
      
      // Verifica se o locale do dispositivo é suportado
      if (deviceLocale && supportedLocales.includes(deviceLocale)) {
        return deviceLocale;
      }
      
      // Tenta achar correspondência para o idioma base
      if (deviceLocale) {
        const baseLanguage = deviceLocale.split('-')[0].toLowerCase();
        const matchingLocale = supportedLocales.find(
          supportedLocale => supportedLocale.toLowerCase().startsWith(baseLanguage + '-')
        );
        
        if (matchingLocale) {
          return matchingLocale;
        }
      }
      
      // Retorna o locale padrão se não encontrar correspondência
      return defaultLocale;
    } catch (error) {
      console.error('[LocaleContext] Erro ao obter locale do dispositivo:', error);
      return defaultLocale;
    }
  };
  
  /**
   * Carrega informações de localização para um locale específico
   * @param {string} localeValue - Locale para carregar
   */
  const loadLocaleInfo = async (localeValue) => {
    try {
      const info = await localeService.getLocaleInfo(localeValue);
      setLocaleInfo(info);
    } catch (error) {
      console.error(`[LocaleContext] Erro ao carregar informações do locale ${localeValue}:`, error);
      // Tenta carregar o locale padrão em caso de erro
      if (localeValue !== defaultLocale) {
        await loadLocaleInfo(defaultLocale);
      }
    }
  };
  
  // Inicializa o contexto
  useEffect(() => {
    const initializeLocale = async () => {
      try {
        setLoading(true);
        
        // Tenta carregar preferência de idioma salva
        let savedLocale = await AsyncStorage.getItem(LOCALE_STORAGE_KEY);
        
        // Se não houver preferência salva e useDeviceLocale for true, usa o locale do dispositivo
        if (!savedLocale && useDeviceLocale) {
          savedLocale = getDeviceLocale();
        }
        
        // Verifica se o locale é suportado
        const finalLocale = savedLocale && supportedLocales.includes(savedLocale)
          ? savedLocale
          : defaultLocale;
        
        // Define o locale e carrega informações
        setLocale(finalLocale);
        await loadLocaleInfo(finalLocale);
      } catch (error) {
        console.error('[LocaleContext] Erro ao inicializar locale:', error);
        // Em caso de erro, usa o locale padrão
        setLocale(defaultLocale);
        await loadLocaleInfo(defaultLocale);
      } finally {
        setLoading(false);
      }
    };
    
    initializeLocale();
  }, []);
  
  /**
   * Altera o locale da aplicação
   * @param {string} newLocale - Novo locale
   */
  const changeLocale = async (newLocale) => {
    try {
      // Verifica se o locale é suportado
      if (!supportedLocales.includes(newLocale)) {
        console.error(`[LocaleContext] Locale não suportado: ${newLocale}`);
        return false;
      }
      
      setLoading(true);
      
      // Salva a preferência
      await AsyncStorage.setItem(LOCALE_STORAGE_KEY, newLocale);
      
      // Atualiza o estado
      setLocale(newLocale);
      
      // Carrega informações do novo locale
      await loadLocaleInfo(newLocale);
      
      setLoading(false);
      return true;
    } catch (error) {
      console.error(`[LocaleContext] Erro ao alterar locale para ${newLocale}:`, error);
      setLoading(false);
      return false;
    }
  };
  
  /**
   * Formata uma data de acordo com o locale atual
   * @param {Date|number|string} date - Data para formatar
   * @param {Object} [options] - Opções de formatação
   * @returns {string} Data formatada
   */
  const formatDate = (date, options = {}) => {
    try {
      return localeService.formatDate(date, locale, options);
    } catch (error) {
      console.error('[LocaleContext] Erro ao formatar data:', error);
      return String(date);
    }
  };
  
  /**
   * Formata um número de acordo com o locale atual
   * @param {number} value - Número para formatar
   * @param {Object} [options] - Opções de formatação
   * @returns {string} Número formatado
   */
  const formatNumber = (value, options = {}) => {
    try {
      return localeService.formatNumber(value, locale, options);
    } catch (error) {
      console.error('[LocaleContext] Erro ao formatar número:', error);
      return String(value);
    }
  };
  
  /**
   * Formata uma moeda de acordo com o locale atual
   * @param {number} value - Valor para formatar
   * @param {string} [currency] - Código da moeda (padrão: moeda do locale)
   * @param {Object} [options] - Opções de formatação
   * @returns {string} Valor monetário formatado
   */
  const formatCurrency = (value, currency, options = {}) => {
    try {
      return localeService.formatCurrency(value, locale, currency, options);
    } catch (error) {
      console.error('[LocaleContext] Erro ao formatar moeda:', error);
      return String(value);
    }
  };
  
  /**
   * Valor do contexto
   */
  const contextValue = {
    // Estado
    locale,              // Código do locale atual (ex: pt-BR)
    localeInfo,          // Informações detalhadas do locale
    loading,             // Indica se está carregando
    supportedLocales,    // Lista de locales suportados
    
    // Acesso ao serviço
    localeService,       // Instância do serviço de localização
    
    // Funções principais
    changeLocale,        // Altera o locale da aplicação
    
    // Funções de formatação
    formatDate,          // Formata data de acordo com o locale
    formatNumber,        // Formata número de acordo com o locale
    formatCurrency,      // Formata moeda de acordo com o locale
    
    // Informações derivadas
    isRTL: localeInfo ? localeInfo.isRTL : false,  // Se o idioma é da direita para a esquerda
    country: localeInfo ? localeInfo.country : '',  // País do locale
    language: localeInfo ? localeInfo.language : '' // Idioma do locale
  };
  
  return (
    <LocaleContext.Provider value={contextValue}>
      {children}
    </LocaleContext.Provider>
  );
};

/**
 * Hook para usar o LocaleContext
 * @returns {Object} Valor do contexto de localização
 */
export const useLocale = () => {
  const context = useContext(LocaleContext);
  
  if (!context) {
    throw new Error('[LocaleContext] useLocale deve ser usado dentro de um LocaleProvider');
  }
  
  return context;
};

export default LocaleContext;