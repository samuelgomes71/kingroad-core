currency = "SGD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Manila-Caticlan Ferry (Filipinas)
        IntermodalConnection(
            id = "manila_caticlan",
            name = "Manila-Caticlan Ferry",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(14.5906, 120.9812, "Manila, Filipinas"),
            endLocation = GeoPoint(11.9214, 121.9553, "Caticlan, Filipinas"),
            distance = 365.0,
            averageDuration = 10 * 60, // 10h
            baseFee = 1500.0,
            currency = "PHP",
            hasSchedule = true,
            operatesAllYear = true
        )
    )
    
    /**
     * OCEANIA - Principais ferries
     */
    val oceaniaFerries = listOf(
        // Interislander (Nova Zelândia)
        IntermodalConnection(
            id = "interislander",
            name = "Interislander",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(-41.2855, 174.7842, "Wellington, Nova Zelândia"),
            endLocation = GeoPoint(-41.2676, 173.9839, "Picton, Nova Zelândia"),
            distance = 92.0,
            averageDuration = 3 * 60 + 20, // 3h 20min
            baseFee = 65.0,
            currency = "NZD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Spirit of Tasmania (Austrália)
        IntermodalConnection(
            id = "spirit_tasmania",
            name = "Spirit of Tasmania",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(-37.8570, 144.9425, "Melbourne, Austrália"),
            endLocation = GeoPoint(-41.1809, 146.8120, "Devonport, Tasmânia"),
            distance = 429.0,
            averageDuration = 9 * 60, // 9h
            baseFee = 120.0,
            currency = "AUD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Sealink (Austrália)
        IntermodalConnection(
            id = "sealink",
            name = "SeaLink Ferry",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(-35.5478, 138.6160, "Cape Jervis, Austrália"),
            endLocation = GeoPoint(-35.7516, 137.9386, "Penneshaw, Kangaroo Island"),
            distance = 18.0,
            averageDuration = 45, // 45min
            baseFee = 49.0,
            currency = "AUD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Fullers Ferry (Nova Zelândia)
        IntermodalConnection(
            id = "fullers_ferry",
            name = "Fullers Ferry",
            type = ConnectionType.PASSENGER_FERRY,
            startLocation = GeoPoint(-36.8415, 174.7674, "Auckland, Nova Zelândia"),
            endLocation = GeoPoint(-36.7862, 175.0394, "Waiheke Island, Nova Zelândia"),
            distance = 21.5,
            averageDuration = 40, // 40min
            baseFee = 27.0,
            currency = "NZD",
            hasSchedule = true,
            operatesAllYear = true
        )
    )
    
    /**
     * ÁFRICA - Principais ferries
     */
    val africanFerries = listOf(
        // Tanger Med-Algeciras (Marrocos-Espanha)
        IntermodalConnection(
            id = "tanger_algeciras",
            name = "Tanger Med-Algeciras Ferry",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(35.8884, -5.5050, "Tanger Med, Marrocos"),
            endLocation = GeoPoint(36.1332, -5.4339, "Algeciras, Espanha"),
            distance = 35.0,
            averageDuration = 70, // 1h 10min
            baseFee = 35.0,
            currency = "EUR",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Zanzibar Ferry (Tanzânia)
        IntermodalConnection(
            id = "zanzibar_ferry",
            name = "Zanzibar Ferry",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(-6.8235, 39.2695, "Dar es Salaam, Tanzânia"),
            endLocation = GeoPoint(-6.1659, 39.1888, "Zanzibar, Tanzânia"),
            distance = 80.0,
            averageDuration = 2 * 60, // 2h
            baseFee = 35.0,
            currency = "USD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Dakar-Gorée (Senegal)
        IntermodalConnection(
            id = "dakar_goree",
            name = "Dakar-Gorée Ferry",
            type = ConnectionType.PASSENGER_FERRY,
            startLocation = GeoPoint(14.6937, -17.4441, "Dakar, Senegal"),
            endLocation = GeoPoint(14.6686, -17.3995, "Gorée, Senegal"),
            distance = 3.8,
            averageDuration = 20, // 20min
            baseFee = 5.0,
            currency = "USD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Cairo-Luxor Ferry (Egito)
        IntermodalConnection(
            id = "cairo_luxor",
            name = "Cairo-Luxor Nile Ferry",
            type = ConnectionType.PASSENGER_FERRY,
            startLocation = GeoPoint(30.0444, 31.2357, "Cairo, Egito"),
            endLocation = GeoPoint(25.6872, 32.6396, "Luxor, Egito"),
            distance = 640.0,
            averageDuration = 3 * 24 * 60, // 3 dias
            baseFee = 110.0,
            currency = "USD",
            hasSchedule = true,
            operatesAllYear = true
        )
    )
    
    /**
     * ORIENTE MÉDIO - Principais ferries
     */
    val middleEastFerries = listOf(
        // Aqaba-Nuweiba Ferry (Jordânia-Egito)
        IntermodalConnection(
            id = "aqaba_nuweiba",
            name = "Aqaba-Nuweiba Ferry",
            type = ConnectionType.FERRY,
            startLocation = GeoPoint(29.5267, 35.0076, "Aqaba, Jordânia"),
            endLocation = GeoPoint(29.0336, 34.6641, "Nuweiba, Egito"),
            distance = 70.0,
            averageDuration = 3 * 60, // 3h
            baseFee = 90.0,
            currency = "USD",
            hasSchedule = true,
            operatesAllYear = true
        ),
        
        // Dubai-Sharjah Ferry (Emirados Árabes Unidos)
        IntermodalConnection(
            id = "dubai_sharjah",
            name = "Dubai-Sharjah Ferry",
            type = ConnectionType.PASSENGER_FERRY,
            startLocation = GeoPoint(25.2697, 55.3094, "Dubai, EAU"),
            endLocation = GeoPoint(25.3463, 55.3855, "Sharjah, EAU"),
            distance = 15.0,
            averageDuration = 35, // 35min
            baseFee = 15.0,
            currency = "AED",
            hasSchedule = true,
            operatesAllYear = true
        )
    )
    
    /**
     * AMÉRICA DO NORTE - Principais túneis
     */
    val northAmericanTunnels = listOf(
        // Chesapeake Bay Bridge-Tunnel (EUA)
        IntermodalConnection(
            id = "chesapeake",
            name = "Chesapeake Bay Bridge-Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(37.0320, -76.0788, "Virginia Beach, EUA"),
            endLocation = GeoPoint(37.1645, -75.9880, "Eastern Shore, EUA"),
            distance = 37.0,
            averageDuration = 30,
            baseFee = 15.0,
            currency = "USD",
            hasSchedule = false,
            operatesAllYear = true
        ),
        
        // Holland Tunnel (EUA)
        IntermodalConnection(
            id = "holland_tunnel",
            name = "Holland Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(40.7274, -74.0208, "Manhattan, NY, EUA"),
            endLocation = GeoPoint(40.7306, -74.0382, "Jersey City, NJ, EUA"),
            distance = 2.6,
            averageDuration = 10,
            baseFee = 16.0,
            currency = "USD",
            hasSchedule = false,
            operatesAllYear = true
        ),
        
        // Ted Williams Tunnel (EUA)
        IntermodalConnection(
            id = "ted_williams",
            name = "Ted Williams Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(42.3546, -71.0438, "Boston, MA, EUA"),
            endLocation = GeoPoint(42.3705, -71.0214, "East Boston, MA, EUA"),
            distance = 2.6,
            averageDuration = 5,
            baseFee = 2.50,
            currency = "USD",
            hasSchedule = false,
            operatesAllYear = true
        ),
        
        // Detroit-Windsor Tunnel (EUA-Canadá)
        IntermodalConnection(
            id = "detroit_windsor",
            name = "Detroit-Windsor Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(42.3256, -83.0413, "Detroit, MI, EUA"),
            endLocation = GeoPoint(42.3148, -83.0390, "Windsor, ON, Canadá"),
            distance = 1.6,
            averageDuration = 10,
            baseFee = 5.0,
            currency = "USD",
            hasSchedule = false,
            operatesAllYear = true
        )
    )
    
    /**
     * AMÉRICA DO SUL - Principais túneis
     */
    val southAmericanTunnels = listOf(
        // Túnel Cristo Redentor (Argentina-Chile)
        IntermodalConnection(
            id = "cristo_redentor",
            name = "Túnel Cristo Redentor",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(-32.8266, -70.0772, "Las Cuevas, Argentina"),
            endLocation = GeoPoint(-32.8312, -70.0464, "Caracoles, Chile"),
            distance = 3.08,
            averageDuration = 10,
            baseFee = null, // Sem tarifa
            currency = "USD",
            hasSchedule = false,
            operatesAllYear = false // Fechado em condições de neve intensa
        ),
        
        // Túnel Subfluvial Raúl Uranga – Carlos Sylvestre Begnis (Argentina)
        IntermodalConnection(
            id = "parana_tunnel",
            name = "Túnel Subfluvial Raúl Uranga",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(-31.7099, -60.5281, "Santa Fe, Argentina"),
            endLocation = GeoPoint(-31.7323, -60.5115, "Paraná, Argentina"),
            distance = 4.2,
            averageDuration = 15,
            baseFee = 60.0,
            currency = "ARS",
            hasSchedule = false,
            operatesAllYear = true
        )
    )
    
    /**
     * OCEANIA - Principais túneis
     */
    val oceaniaTunnels = listOf(
        // Sydney Harbour Tunnel (Austrália)
        IntermodalConnection(
            id = "sydney_harbour",
            name = "Sydney Harbour Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(-33.8622, 151.2156, "Sydney Norte, Austrália"),
            endLocation = GeoPoint(-33.8523, 151.2119, "Sydney CBD, Austrália"),
            distance = 2.3,
            averageDuration = 5,
            baseFee = 4.0,
            currency = "AUD",
            hasSchedule = false,
            operatesAllYear = true
        ),
        
        // Lyttelton Road Tunnel (Nova Zelândia)
        IntermodalConnection(
            id = "lyttelton",
            name = "Lyttelton Road Tunnel",
            type = ConnectionType.CAR_TUNNEL,
            startLocation = GeoPoint(-43.6013, 172.6546, "Christchurch, Nova Zelândia"),
            endLocation = GeoPoint(-43.6042, 172.7171, "Lyttelton, Nova Zelândia"),
            distance = 1.9,
            averageDuration = 5,
            baseFee = null, // Sem tarifa
            currency = "NZD",
            hasSchedule = false,
            operatesAllYear = true
        )
    )
    
    /**
     * Métodos para acessar as conexões
     */
    
    /**
     * Obtém todos os túneis
     */
    fun getAllTunnels(): List<IntermodalConnection> {
        return europeanTunnels + 
               asianTunnels + 
               northAmericanTunnels + 
               southAmericanTunnels + 
               oceaniaTunnels
    }
    
    /**
     * Obtém todos os ferries
     */
    fun getAllFerries(): List<IntermodalConnection> {
        return europeanFerries + 
               northAmericanFerries + 
               southAmericanFerries + 
               asianFerries + 
               oceaniaFerries + 
               africanFerries + 
               middleEastFerries
    }
    
    /**
     * Obtém todas as conexões intermodais
     */
    fun getAllConnections(): List<IntermodalConnection> {
        return getAllTunnels() + getAllFerries()
    }
    
    /**
     * Obtém conexões por continente
     */
    fun getConnectionsByContinent(continent: String): List<IntermodalConnection> {
        return when (continent.lowercase()) {
            "europe", "europa" -> europeanTunnels + europeanFerries
            "asia", "ásia" -> asianTunnels + asianFerries
            "north america", "américa do norte" -> northAmericanTunnels + northAmericanFerries
            "south america", "américa do sul" -> southAmericanTunnels + southAmericanFerries
            "oceania" -> oceaniaTunnels + oceaniaFerries
            "africa", "áfrica" -> africanFerries
            "middle east", "oriente médio" -> middleEastFerries
            else -> emptyList()
        }
    }
    
    /**
     * Obtém conexões por tipo
     */
    fun getConnectionsByType(type: ConnectionType): List<IntermodalConnection> {
        return when (type) {
            ConnectionType.FERRY, ConnectionType.PASSENGER_FERRY -> getAllFerries()
            ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL, ConnectionType.TRAIN_TUNNEL -> getAllTunnels()
            else -> emptyList()
        }
    }
    
    /**
     * Obtém conexões por país
     */
    fun getConnectionsByCountry(country: String): List<IntermodalConnection> {
        val allConnections = getAllConnections()
        val normalizedCountry = country.lowercase().trim()
        
        return allConnections.filter { connection ->
            val startLocation = connection.startLocation.name?.lowercase() ?: ""
            val endLocation = connection.endLocation.name?.lowercase() ?: ""
            
            startLocation.contains(normalizedCountry) || endLocation.contains(normalizedCountry)
        }
    }
    
    /**
     * Obtém detalhes de uma conexão específica
     * @param connectionId ID da conexão
     */
    fun getConnectionDetails(connectionId: String): ConnectionDetails? {
        val connection = getAllConnections().find { it.id == connectionId } ?: return null
        
        // Informações específicas para conexões importantes
        val specialDescriptions = mapOf(
            // Europa
            "eurotunnel" to "O Eurotúnel é uma ferrovia subterrânea de 50 km que passa sob o Canal da Mancha entre a Inglaterra e a França. O serviço transporta veículos (carros, caminhões, ônibus) e seus passageiros através do túnel em vagões especiais.",
            "oresund" to "A conexão Øresund é uma notável ligação entre a Suécia e a Dinamarca, composta por uma ponte de 8 km, uma ilha artificial de 4 km e um túnel submarino de 4 km. É utilizada tanto para tráfego ferroviário quanto rodoviário.",
            "gotthard" to "O Túnel de Base de São Gotardo é o túnel ferroviário mais longo e profundo do mundo, atravessando os Alpes Suíços. Foi inaugurado em 2016 após 17 anos de construção e revolucionou o transporte através dos Alpes.",
            "po_ferries_calais_dover" to "A rota de ferry mais movimentada do Canal da Mancha, conectando a França ao Reino Unido em apenas 90 minutos. Transporta milhões de passageiros e veículos anualmente.",
            "brittany_ferries_portsmouth_bilbao" to "Esta rota de longa distância conecta o Reino Unido diretamente à costa norte da Espanha, oferecendo uma alternativa à longa viagem terrestre através da França.",
            "grimaldi_barcelona_civitavecchia" to "Uma importante ligação marítima no Mediterrâneo que conecta a Espanha à Itália, com serviços de ferry que funcionam como 'hotéis flutuantes', permitindo que passageiros durmam durante a travessia noturna.",
            
            // América do Norte
            "marine_atlantic" to "Esta conexão é a principal rota para veículos entrarem em Newfoundland, uma vez que a ilha não possui ligação rodoviária com o continente canadense. O ferry transporta tanto passageiros quanto veículos, incluindo caminhões comerciais importantes para o abastecimento da ilha.",
            "bc_ferries" to "Um dos maiores sistemas de ferry da América do Norte, conectando Vancouver Island ao continente e servindo mais de 47 terminais em 25 rotas diferentes na província da Columbia Britânica.",
            "chesapeake" to "Uma impressionante combinação de pontes e túneis que cruza a entrada da Baía de Chesapeake, conectando o sudeste da Virgínia à Península Delmarva. Inclui dois túneis submarinos e quatro seções de pontes elevadas.",
            
            // Ásia
            "seikan" to "O Túnel Seikan conecta as ilhas japonesas de Honshu e Hokkaido, passando sob o estreito de Tsugaru. Foi o túnel submarino mais longo do mundo até a conclusão do Eurotúnel em 1994.",
            "hzmb" to "A Ponte-Túnel Hong Kong-Zhuhai-Macau é uma das mais longas travessias marítimas do mundo, conectando três importantes cidades na região do Delta do Rio das Pérolas. Inclui um túnel submarino de 6,7 km e ilhas artificiais.",
            "busan_fukuoka" to "Este ferry de alta velocidade conecta a Coreia do Sul ao Japão através do Estreito da Coreia, sendo uma importante rota comercial e turística entre os dois países."
        )
        
        val description = specialDescriptions[connectionId] ?: 
                          "Conexão intermodal importante ligando ${connection.startLocation.name} a ${connection.endLocation.name}, cobrindo uma distância de ${connection.distance} km."
        
        return ConnectionDetails(
            connection = connection,
            description = description,
            paymentMethods = getDefaultPaymentMethods(connection.currency),
            facilityFeatures = getDefaultFeatures(connection.type),
            restrictions = getDefaultRestrictions(connection.type),
            contactInfo = "",  // Seria preenchido com dados reais
            websiteUrl = "",   // Seria preenchido com dados reais
            imageUrl = ""      // Seria preenchido com dados reais
        )
    }
    
    /**
     * Métodos auxiliares para gerar informações padrão
     */
    
    private fun getDefaultPaymentMethods(currency: String): List<String> {
        val commonMethods = listOf("Cartão de crédito", "Débito")
        
        return when (currency) {
            "EUR" -> commonMethods + listOf("Apple Pay", "Google Pay", "SEPA")
            "USD", "CAD" -> commonMethods + listOf("Apple Pay", "Google Pay", "PayPal")
            "GBP" -> commonMethods + listOf("Apple Pay", "Google Pay", "PayPal", "Contactless")
            "JPY" -> commonMethods + listOf("Suica", "PASMO", "IC Card")
            "AUD", "NZD" -> commonMethods + listOf("EFTPOS", "PayPal")
            "CNY" -> commonMethods + listOf("UnionPay", "Alipay", "WeChat Pay")
            "BRL" -> commonMethods + listOf("PIX", "Boleto")
            "INR" -> commonMethods + listOf("UPI", "PayTM", "PhonePe")
            else -> commonMethods
        }
    }
    
    private fun getDefaultFeatures(type: ConnectionType): List<String> {
        val commonFeatures = listOf("Wi-Fi", "Toaletes")
        
        return when (type) {
            ConnectionType.FERRY -> commonFeatures + listOf(
                "Restaurante", "Lojas", "Áreas de descanso", 
                "Cabines (em rotas longas)", "Entretenimento"
            )
            ConnectionType.PASSENGER_FERRY -> commonFeatures + listOf(
                "Cafeteria", "Área para bagagens", "Assentos cobertos"
            )
            ConnectionType.TRAIN_TUNNEL -> commonFeatures + listOf(
                "Sistema de ventilação avançado", "Iluminação de emergência", 
                "Telefones de emergência", "Sistemas de extinção de incêndio"
            )
            ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL -> commonFeatures + listOf(
                "Sistemas de ventilação", "Monitoramento 24h", 
                "Iluminação de emergência", "Áreas de refúgio"
            )
            else -> commonFeatures
        }
    }
    
    private fun getDefaultRestrictions(type: ConnectionType): List<String> {
        return when (type) {
            ConnectionType.FERRY, ConnectionType.PASSENGER_FERRY -> listOf(
                "Passaportes ou documentos de identidade podem ser necessários para rotas internacionais",
                "Restrições de bagagem podem se aplicar",
                "Animais de estimação podem requerer documentação especial"
            )
            ConnectionType.TRAIN_TUNNEL -> listOf(
                "Passageiros devem permanecer nos vagões",
                "Restrições de bagagem perigosa",
                "Acessível apenas via trem"
            )
            ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL -> listOf(
                "Limitações de altura para veículos",
                "Restrições para cargas perigosas",
                "Limites de velocidade rigorosamente aplicados"
            )
            else -> emptyList()
        }
    }
}