import React, { useState } from 'react';

const AddParkingSpotScreen = () => {
  // Estados para o formulário
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [spotType, setSpotType] = useState('TRUCK_STOP');
  const [totalSpaces, setTotalSpaces] = useState('');
  const [isFree, setIsFree] = useState(true);
  const [pricePerHour, setPricePerHour] = useState('');
  const [selectedFeatures, setSelectedFeatures] = useState(['RESTROOMS', 'FUEL']);
  
  // Opções de tipo de estacionamento
  const parkingTypes = [
    { value: 'TRUCK_STOP', label: 'Truck Stop', icon: '🚚' },
    { value: 'REST_AREA', label: 'Área de Descanso', icon: '🛏️' },
    { value: 'GAS_STATION', label: 'Posto de Combustível', icon: '⛽' },
    { value: 'DEDICATED_PARKING', label: 'Estacionamento Dedicado', icon: '🅿️' },
    { value: 'OTHER', label: 'Outro', icon: '📍' }
  ];
  
  // Recursos disponíveis
  const availableFeatures = [
    { value: 'RESTROOMS', label: 'Banheiros', icon: '🚻' },
    { value: 'SHOWERS', label: 'Chuveiros', icon: '🚿' },
    { value: 'FUEL', label: 'Combustível', icon: '⛽' },
    { value: 'RESTAURANT', label: 'Restaurante', icon: '🍽️' },
    { value: 'CONVENIENCE_STORE', label: 'Loja de Conveniência', icon: '🏪' },
    { value: 'SECURITY_SURVEILLANCE', label: 'Vigilância', icon: '📹' },
    { value: 'LIGHTED_AREA', label: 'Área Iluminada', icon: '💡' },
    { value: 'FENCED_AREA', label: 'Área Cercada', icon: '🔒' }
  ];
  
  // Alternar seleção de recurso
  const toggleFeature = (feature) => {
    if (selectedFeatures.includes(feature)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== feature));
    } else {
      setSelectedFeatures([...selectedFeatures, feature]);
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto bg-gray-50">
      {/* Cabeçalho */}
      <div className="mb-4">
        <div className="flex items-center">
          <button className="mr-2 text-blue-600">← Voltar</button>
          <h1 className="text-xl font-bold">Adicionar Estacionamento</h1>
        </div>
        <p className="text-gray-600 mt-1">
          Perto de: Tim Hortons
        </p>
      </div>
      
      {/* Mapa (simulado) */}
      <div className="mb-6">
        <label className="block text-gray-700 font-medium mb-2">
          Localização
        </label>
        <div className="bg-blue-100 rounded-lg h-48 flex items-center justify-center relative">
          <div className="text-center text-blue-800">
            Mapa para seleção de localização
            <div className="mt-2">Toque no mapa para posicionar o marcador</div>
          </div>
          <button className="absolute bottom-2 right-2 bg-white p-2 rounded-full shadow-md">
            📍
          </button>
        </div>
      </div>
      
      {/* Informações básicas */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">Informações Básicas</h2>
        
        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-2">
            Nome *
          </label>
          <input
            type="text"
            className="w-full p-2 border border-gray-300 rounded-md"
            placeholder="Ex: Posto Shell Caminhoneiros"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-2">
            Descrição
          </label>
          <textarea
            className="w-full p-2 border border-gray-300 rounded-md"
            placeholder="Informações adicionais sobre o local..."
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-2">
            Tipo de Estacionamento *
          </label>
          <div className="flex overflow-x-auto pb-2">
            {parkingTypes.map(type => (
              <button
                key={type.value}
                className={`flex flex-col items-center justify-center p-3 mr-3 rounded-lg ${
                  spotType === type.value 
                    ? 'bg-blue-100 border-2 border-blue-500' 
                    : 'bg-white border border-gray-200'
                }`}
                onClick={() => setSpotType(type.value)}
                style={{ minWidth: '80px' }}
              >
                <span className="text-2xl mb-1">{type.icon}</span>
                <span className="text-xs text-center">{type.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Detalhes do estacionamento */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">Detalhes do Estacionamento</h2>
        
        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-2">
            Número de Vagas
          </label>
          <input
            type="number"
            className="w-full p-2 border border-gray-300 rounded-md"
            placeholder="Ex: 15"
            value={totalSpaces}
            onChange={(e) => setTotalSpaces(e.target.value)}
          />
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between items-center">
            <label className="text-gray-700 font-medium">
              Estacionamento Gratuito
            </label>
            <div className="relative inline-block w-12 align-middle select-none">
              <input 
                type="checkbox" 
                className="sr-only"
                checked={isFree}
                onChange={() => setIsFree(!isFree)}
                id="toggle"
              />
              <label
                htmlFor="toggle"
                className={`block overflow-hidden h-6 rounded-full cursor-pointer ${
                  isFree ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              >
                <span 
                  className={`block h-6 w-6 rounded-full bg-white transform transition-transform ${
                    isFree ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </label>
            </div>
          </div>
        </div>
        
        {!isFree && (
          <div className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">
              Preço por Hora (R$) *
            </label>
            <input
              type="number"
              step="0.01"
              className="w-full p-2 border border-gray-300 rounded-md"
              placeholder="Ex: 5.50"
              value={pricePerHour}
              onChange={(e) => setPricePerHour(e.target.value)}
            />
          </div>
        )}
      </div>
      
      {/* Recursos disponíveis */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">Recursos Disponíveis</h2>
        
        <div className="flex flex-wrap">
          {availableFeatures.map(feature => (
            <button
              key={feature.value}
              className={`flex items-center p-2 m-1 rounded-lg ${
                selectedFeatures.includes(feature.value)
                  ? 'bg-blue-100 border border-blue-500'
                  : 'bg-white border border-gray-200'
              }`}
              onClick={() => toggleFeature(feature.value)}
            >
              <span className="mr-2">{feature.icon}</span>
              <span className="text-sm">{feature.label}</span>
            </button>
          ))}
        </div>
      </div>
      
      {/* Botões de ação */}
      <div className="flex mt-8">
        <button className="flex-1 py-3 mr-2 border border-gray-300 rounded-lg">
          Cancelar
        </button>
        <button className="flex-2 py-3 ml-2 bg-blue-600 text-white rounded-lg font-medium">
          Salvar Estacionamento
        </button>
      </div>
    </div>
  );
};

export default AddParkingSpotScreen;