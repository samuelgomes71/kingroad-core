package com.kingroad.services

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.storage.FirebaseStorage
import com.kingroad.database.Feedback
import com.kingroad.database.FeedbackDao
import com.kingroad.utils.FileCompressor
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Serviço que envia os dados de feedback preenchidos pelo motorista,
 * incluindo texto, imagem e localização, para a nuvem.
 */
class FeedbackUploadService(
    private val context: Context,
    private val feedbackDao: FeedbackDao,
    private val apiBaseUrl: String,
    private val apiKey: String? = null,
    private val firebaseEnabled: Boolean = false,
    private val fileCompressor: FileCompressor? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "FeedbackUploadService"
        
        // Tipos de Feedback
        enum class FeedbackType {
            POI,             // Feedback sobre um POI
            ALERT,           // Feedback sobre um alerta
            APP,             // Feedback sobre o aplicativo
            ROUTE,           // Feedback sobre uma rota
            GENERAL          // Feedback geral
        }
        
        // Estados da sincronização
        enum class UploadState {
            IDLE,
            UPLOADING,
            SUCCESS,
            ERROR
        }
        
        // Tamanho máximo de imagem original (10MB)
        private const val MAX_ORIGINAL_IMAGE_SIZE = 10 * 1024 * 1024
        
        // Tamanho máximo de imagem comprimida (1MB)
        private const val MAX_COMPRESSED_IMAGE_SIZE = 1 * 1024 * 1024
        
        // Tempo máximo de upload (2 minutos)
        private const val UPLOAD_TIMEOUT = 2 * 60 * 1000L
    }

    // Estado do upload
    private val _uploadState = MutableStateFlow<UploadState>(UploadState.IDLE)
    val uploadState: StateFlow<UploadState> = _uploadState.asStateFlow()
    
    // Progresso atual do upload (0-100)
    private val _uploadProgress = MutableStateFlow(0)
    val uploadProgress: StateFlow<Int> = _uploadProgress.asStateFlow()
    
    // Estatísticas de upload
    private val _uploadStats = MutableLiveData(UploadStats())
    val uploadStats: LiveData<UploadStats> = _uploadStats
    
    // Cliente HTTP para requisições
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(UPLOAD_TIMEOUT, TimeUnit.MILLISECONDS)
        .build()
    
    /**
     * Inicializa o serviço para um novo upload
     */
    fun init() {
        _uploadProgress.value = 0
        _uploadState.value = UploadState.IDLE
    }
    
    /**
     * Cria um novo feedback a partir dos dados fornecidos
     * 
     * @param type Tipo do feedback
     * @param content Conteúdo do feedback (texto)
     * @param rating Avaliação (1-5 estrelas, opcional)
     * @param imagePath Caminho da imagem local (opcional)
     * @param latitude Latitude (opcional)
     * @param longitude Longitude (opcional)
     * @param referenceId ID de referência (POI, alerta, etc., opcional)
     * @param referenceType Tipo de referência (opcional)
     * @param userId ID do usuário (opcional)
     * @param metadata Metadados adicionais (opcional)
     * @return ID do feedback criado
     */
    suspend fun createFeedback(
        type: FeedbackType,
        content: String,
        rating: Int? = null,
        imagePath: String? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        referenceId: String? = null,
        referenceType: String? = null,
        userId: String? = null,
        metadata: String? = null
    ): String = withContext(dispatcher) {
        // Valida dados básicos
        if (content.isBlank()) {
            throw IllegalArgumentException("O conteúdo do feedback não pode estar vazio")
        }
        
        // Cria ID único para o feedback
        val feedbackId = UUID.randomUUID().toString()
        
        // Cria objeto de feedback
        val feedback = Feedback(
            id = feedbackId,
            type = type.name,
            content = content,
            rating = rating,
            latitude = latitude,
            longitude = longitude,
            imagePath = imagePath,
            createdAt = System.currentTimeMillis(),
            referenceId = referenceId,
            referenceType = referenceType,
            createdBy = userId,
            metadata = metadata,
            synced = false,
            syncTimestamp = null,
            syncAttempts = 0,
            lastSyncAttempt = null,
            serverRef = null,
            serverImageUrl = null,
            queuedForSync = false
        )
        
        // Salva no banco de dados local
        feedbackDao.insert(feedback)
        
        Log.d(TAG, "Feedback criado localmente com ID: $feedbackId")
        
        return@withContext feedbackId
    }
    
    /**
     * Cria um feedback com imagem a partir de um URI
     * 
     * @param type Tipo do feedback
     * @param content Conteúdo do feedback
     * @param imageUri URI da imagem
     * @param outros parâmetros iguais ao método createFeedback
     * @return ID do feedback criado
     */
    suspend fun createFeedbackWithImage(
        type: FeedbackType,
        content: String,
        imageUri: Uri,
        rating: Int? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        referenceId: String? = null,
        referenceType: String? = null,
        userId: String? = null,
        metadata: String? = null
    ): String = withContext(dispatcher) {
        // Salva a imagem localmente
        val localImagePath = saveImageLocally(imageUri)
        
        // Cria o feedback com o caminho da imagem
        return@withContext createFeedback(
            type = type,
            content = content,
            rating = rating,
            imagePath = localImagePath,
            latitude = latitude,
            longitude = longitude,
            referenceId = referenceId,
            referenceType = referenceType,
            userId = userId,
            metadata = metadata
        )
    }
    
    /**
     * Cria um feedback com imagem a partir de um Bitmap
     * 
     * @param type Tipo do feedback
     * @param content Conteúdo do feedback
     * @param bitmap Bitmap da imagem
     * @param outros parâmetros iguais ao método createFeedback
     * @return ID do feedback criado
     */
    suspend fun createFeedbackWithImage(
        type: FeedbackType,
        content: String,
        bitmap: Bitmap,
        rating: Int? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        referenceId: String? = null,
        referenceType: String? = null,
        userId: String? = null,
        metadata: String? = null
    ): String = withContext(dispatcher) {
        // Salva a imagem localmente
        val localImagePath = saveImageLocally(bitmap)
        
        // Cria o feedback com o caminho da imagem
        return@withContext createFeedback(
            type = type,
            content = content,
            rating = rating,
            imagePath = localImagePath,
            latitude = latitude,
            longitude = longitude,
            referenceId = referenceId,
            referenceType = referenceType,
            userId = userId,
            metadata = metadata
        )
    }
    
    /**
     * Salva uma imagem localmente a partir de URI
     */
    private suspend fun saveImageLocally(imageUri: Uri): String = withContext(dispatcher) {
        val inputStream = context.contentResolver.openInputStream(imageUri)
            ?: throw IllegalArgumentException("Não foi possível abrir o stream da imagem")
        
        // Cria diretório se não existir
        val dir = File(context.filesDir, "feedback_images")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        
        // Cria arquivo temporário
        val filename = "feedback_${System.currentTimeMillis()}.jpg"
        val outputFile = File(dir, filename)
        
        // Verifica se deve comprimir
        if (fileCompressor != null) {
            // Comprime o arquivo
            fileCompressor.compressImage(inputStream, MAX_COMPRESSED_IMAGE_SIZE).use { compressedData ->
                FileOutputStream(outputFile).use { fileOutputStream ->
                    fileOutputStream.write(compressedData)
                }
            }
        } else {
            // Copia sem compressão
            FileOutputStream(outputFile).use { fileOutputStream ->
                inputStream.use { input ->
                    input.copyTo(fileOutputStream)
                }
            }
        }
        
        Log.d(TAG, "Imagem salva localmente: ${outputFile.absolutePath}")
        return outputFile.absolutePath
    }
    
    /**
     * Salva uma imagem localmente a partir de Bitmap
     */
    private suspend fun saveImageLocally(bitmap: Bitmap): String = withContext(dispatcher) {
        // Cria diretório se não existir
        val dir = File(context.filesDir, "feedback_images")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        
        // Cria arquivo temporário
        val filename = "feedback_${System.currentTimeMillis()}.jpg"
        val outputFile = File(dir, filename)
        
        // Comprime o bitmap para JPEG
        val quality = if (fileCompressor != null) 85 else 95
        FileOutputStream(outputFile).use { outputStream ->
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, byteArrayOutputStream)
            
            // Verifica se o tamanho é aceitável ou precisa comprimir mais
            val imageData = byteArrayOutputStream.toByteArray()
            if (imageData.size > MAX_COMPRESSED_IMAGE_SIZE && fileCompressor != null) {
                // Comprime mais
                val compressedData = fileCompressor.compressBitmap(bitmap, MAX_COMPRESSED_IMAGE_SIZE)
                outputStream.write(compressedData)
            } else {
                // Usa a compressão original
                outputStream.write(imageData)
            }
        }
        
        Log.d(TAG, "Imagem salva localmente: ${outputFile.absolutePath}")
        return outputFile.absolutePath
    }
    
    /**
     * Envia um feedback para o servidor
     * 
     * @param feedbackId ID do feedback a ser enviado
     * @return true se o envio foi bem-sucedido
     */
    suspend fun uploadFeedback(feedbackId: String): Boolean = withContext(dispatcher) {
        try {
            // Busca o feedback no banco de dados
            val feedback = feedbackDao.getById(feedbackId)
                ?: throw IllegalArgumentException("Feedback não encontrado: $feedbackId")
            
            // Verifica se já está enviado
            if (feedback.synced) {
                Log.d(TAG, "Feedback $feedbackId já está sincronizado")
                return@withContext true
            }
            
            // Atualiza estado
            _uploadState.value = UploadState.UPLOADING
            _uploadProgress.value = 0
            
            // Envia de acordo com o método configurado
            val success = if (firebaseEnabled) {
                uploadFeedbackToFirebase(feedback)
            } else {
                uploadFeedbackToApi(feedback)
            }
            
            // Atualiza estatísticas
            updateUploadStats(success)
            
            // Atualiza estado
            _uploadState.value = if (success) UploadState.SUCCESS else UploadState.ERROR
            _uploadProgress.value = if (success) 100 else 0
            
            return@withContext success
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enviar feedback: ${e.message}", e)
            _uploadState.value = UploadState.ERROR
            
            // Atualiza estatísticas
            updateUploadStats(false)
            
            return@withContext false
        }
    }
    
    /**
     * Envia todos os feedbacks pendentes para o servidor
     * 
     * @return número de feedbacks enviados com sucesso
     */
    suspend fun uploadAllPendingFeedbacks(): Int = withContext(dispatcher) {
        try {
            // Busca todos os feedbacks não sincronizados
            val pendingFeedbacks = feedbackDao.getUnsyncedFeedbacks()
            Log.d(TAG, "Enviando ${pendingFeedbacks.size} feedbacks pendentes")
            
            // Atualiza estado
            _uploadState.value = UploadState.UPLOADING
            _uploadProgress.value = 0
            
            var successCount = 0
            
            // Envia cada feedback
            pendingFeedbacks.forEachIndexed { index, feedback ->
                val success = try {
                    // Atualiza progresso
                    val progress = ((index.toFloat() / pendingFeedbacks.size) * 100).toInt()
                    _uploadProgress.value = progress
                    
                    // Envia de acordo com o método configurado
                    if (firebaseEnabled) {
                        uploadFeedbackToFirebase(feedback)
                    } else {
                        uploadFeedbackToApi(feedback)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Erro ao enviar feedback ${feedback.id}: ${e.message}", e)
                    false
                }
                
                if (success) {
                    successCount++
                }
            }
            
            // Atualiza estado
            _uploadState.value = if (successCount > 0) UploadState.SUCCESS else UploadState.ERROR
            _uploadProgress.value = 100
            
            // Atualiza estatísticas
            val currentStats = _uploadStats.value ?: UploadStats()
            _uploadStats.postValue(currentStats.copy(
                totalUploaded = currentStats.totalUploaded + successCount,
                totalFailed = currentStats.totalFailed + (pendingFeedbacks.size - successCount),
                lastUploadTime = System.currentTimeMillis()
            ))
            
            return@withContext successCount
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enviar feedbacks pendentes: ${e.message}", e)
            _uploadState.value = UploadState.ERROR
            return@withContext 0
        }
    }
    
    /**
     * Envia feedback para Firebase
     */
    private suspend fun uploadFeedbackToFirebase(feedback: Feedback): Boolean {
        try {
            // Referência para o nó de feedbacks
            val database = FirebaseDatabase.getInstance()
            val feedbackRef = database.getReference("feedbacks").child(feedback.id)
            
            // Preparar dados para envio
            val feedbackData = mutableMapOf(
                "id" to feedback.id,
                "type" to feedback.type,
                "content" to feedback.content,
                "createdAt" to feedback.createdAt,
                "createdBy" to (feedback.createdBy ?: "anonymous")
            )
            
            // Adiciona campos opcionais
            feedback.rating?.let { feedbackData["rating"] = it }
            feedback.latitude?.let { feedbackData["latitude"] = it }
            feedback.longitude?.let { feedbackData["longitude"] = it }
            feedback.referenceId?.let { feedbackData["referenceId"] = it }
            feedback.referenceType?.let { feedbackData["referenceType"] = it }
            feedback.metadata?.let { feedbackData["metadata"] = it }
            
            // Atualiza progresso
            _uploadProgress.value = 20
            
            // Se tem imagem, primeiro faz upload da imagem
            var imageUrl: String? = null
            if (!feedback.imagePath.isNullOrEmpty()) {
                val imageFile = File(feedback.imagePath)
                if (imageFile.exists()) {
                    // Cria referência para o storage
                    val storageRef = FirebaseStorage.getInstance().reference
                        .child("feedback_images")
                        .child(feedback.id)
                    
                    // Faz upload da imagem
                    val uploadTask = storageRef.putFile(Uri.fromFile(imageFile))
                    
                    // Monitora progresso
                    uploadTask.addOnProgressListener { taskSnapshot ->
                        val progress = (taskSnapshot.bytesTransferred * 100 / taskSnapshot.totalByteCount).toInt()
                        // 20% base + 60% para upload de imagem = 80% max
                        _uploadProgress.value = 20 + ((progress * 60) / 100)
                    }
                    
                    // Aguarda upload completo
                    uploadTask.await()
                    
                    // Obtém URL da imagem
                    imageUrl = storageRef.downloadUrl.await().toString()
                    
                    // Adiciona URL da imagem aos dados
                    feedbackData["imageUrl"] = imageUrl
                }
            }
            
            // Atualiza progresso
            _uploadProgress.value = 80
            
            // Salva os dados do feedback
            feedbackRef.setValue(feedbackData).await()
            
            // Atualiza progresso
            _uploadProgress.value = 100
            
            // Atualiza feedback como sincronizado
            val updatedFeedback = feedback.copy(
                synced = true,
                syncTimestamp = System.currentTimeMillis(),
                serverRef = feedback.id,
                serverImageUrl = imageUrl
            )
            feedbackDao.update(updatedFeedback)
            
            Log.d(TAG, "Feedback enviado com sucesso via Firebase: ${feedback.id}")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enviar feedback via Firebase: ${e.message}", e)
            
            // Incrementa contagem de tentativas
            val updatedFeedback = feedback.copy(
                syncAttempts = feedback.syncAttempts + 1,
                lastSyncAttempt = System.currentTimeMillis()
            )
            feedbackDao.update(updatedFeedback)
            
            return false
        }
    }
    
    /**
     * Envia feedback para API REST
     */
    private suspend fun uploadFeedbackToApi(feedback: Feedback): Boolean {
        try {
            // Montagem dos dados básicos
            _uploadProgress.value = 10
            
            // Verifica se tem imagem associada
            val hasImage = !feedback.imagePath.isNullOrEmpty()
            val imageFile = if (hasImage) File(feedback.imagePath!!) else null
            
            // A estratégia depende de se tem imagem para enviar
            if (hasImage && imageFile != null && imageFile.exists()) {
                return uploadFeedbackWithImageToApi(feedback, imageFile)
            } else {
                return uploadFeedbackWithoutImageToApi(feedback)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enviar feedback via API: ${e.message}", e)
            
            // Incrementa contagem de tentativas
            val updatedFeedback = feedback.copy(
                syncAttempts = feedback.syncAttempts + 1,
                lastSyncAttempt = System.currentTimeMillis()
            )
            feedbackDao.update(updatedFeedback)
            
            return false
        }
    }
    
    /**
     * Envia feedback sem imagem para API REST
     */
    private suspend fun uploadFeedbackWithoutImageToApi(feedback: Feedback): Boolean {
        try {
            val url = URL("$apiBaseUrl/api/feedbacks")
            val connection = url.openConnection() as HttpURLConnection
            
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Criar JSON com os dados do feedback
            val feedbackJson = JSONObject().apply {
                put("id", feedback.id)
                put("type", feedback.type)
                put("content", feedback.content)
                
                // Adiciona campos opcionais
                feedback.rating?.let { put("rating", it) }
                feedback.latitude?.let { put("latitude", it) }
                feedback.longitude?.let { put("longitude", it) }
                feedback.referenceId?.let { put("referenceId", it) }
                feedback.referenceType?.let { put("referenceType", it) }
                feedback.createdBy?.let { put("createdBy", it) }
                feedback.metadata?.let { put("metadata", it) }
                
                put("createdAt", feedback.createdAt)
            }
            
            // Atualiza progresso
            _uploadProgress.value = 30
            
            // Envia dados
            connection.outputStream.use { outputStream ->
                outputStream.write(feedbackJson.toString().toByteArray(Charsets.UTF_8))
                outputStream.flush()
            }
            
            // Atualiza progresso
            _uploadProgress.value = 70
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Lê resposta
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(response)
                
                // Obtém o ID no servidor
                val serverRef = responseJson.optString("id", feedback.id)
                
                // Atualiza feedback como sincronizado
                val updatedFeedback = feedback.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef
                )
                feedbackDao.update(updatedFeedback)
                
                _uploadProgress.value = 100
                Log.d(TAG, "Feedback enviado com sucesso via API: ${feedback.id}")
                return true
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                Log.e(TAG, "Erro na API REST: $responseCode - $errorResponse")
                
                // Incrementa contagem de tentativas
                val updatedFeedback = feedback.copy(
                    syncAttempts = feedback.syncAttempts + 1,
                    lastSyncAttempt = System.currentTimeMillis()
                )
                feedbackDao.update(updatedFeedback)
                
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar feedback via API: ${e.message}", e)
            
            // Incrementa contagem de tentativas
            val updatedFeedback = feedback.copy(
                syncAttempts = feedback.syncAttempts + 1,
                lastSyncAttempt = System.currentTimeMillis()
            )
            feedbackDao.update(updatedFeedback)
            
            return false
        }
    }
    
    /**
     * Envia feedback com imagem para API REST usando multipart/form-data
     */
    private suspend fun uploadFeedbackWithImageToApi(feedback: Feedback, imageFile: File): Boolean {
        try {
            // Prepara dados do feedback como JSON
            val feedbackJson = JSONObject().apply {
                put("id", feedback.id)
                put("type", feedback.type)
                put("content", feedback.content)
                
                // Adiciona campos opcionais
                feedback.rating?.let { put("rating", it) }
                feedback.latitude?.let { put("latitude", it) }
                feedback.longitude?.let { put("longitude", it) }
                feedback.referenceId?.let { put("referenceId", it) }
                feedback.referenceType?.let { put("referenceType", it) }
                feedback.createdBy?.let { put("createdBy", it) }
                feedback.metadata?.let { put("metadata", it) }
                
                put("createdAt", feedback.createdAt)
            }
            
            // Prepara parte de dados do formulário
            val jsonPart = feedbackJson.toString()
                .toRequestBody("application/json".toMediaTypeOrNull())
            
            // Comprime imagem se necessário
            val compressedImageFile = if (fileCompressor != null && imageFile.length() > MAX_COMPRESSED_IMAGE_SIZE) {
                fileCompressor.compressImageFile(imageFile, 800, 600, 85)
            } else {
                imageFile
            }
            
            // Prepara parte da imagem
            val imagePart = compressedImageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            
            // Monta corpo da requisição multipart
            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("data", "feedback.json", jsonPart)
                .addFormDataPart("image", "feedback_image.jpg", imagePart)
                .build()
            
            // Monta requisição
            val request = Request.Builder()
                .url("$apiBaseUrl/api/feedbacks/with-image")
                .post(requestBody)
                .apply {
                    // Adiciona chave API se disponível
                    if (apiKey != null) {
                        header("Authorization", "Bearer $apiKey")
                    }
                }
                .build()
            
            // Cria listener de progresso personalizado
            class ProgressListener(
                private val requestBody: RequestBody,
                private val onProgressUpdate: (Int) -> Unit
            ) : RequestBody() {
                override fun contentType() = requestBody.contentType()
                
                override fun contentLength() = requestBody.contentLength()
                
                override fun writeTo(sink: okio.BufferedSink) {
                    val totalBytes = contentLength()
                    
                    // Cria sink para monitorar progresso
                    val progressSink = object : okio.ForwardingSink(sink) {
                        var bytesWritten = 0L
                        
                        override fun write(source: okio.Buffer, byteCount: Long) {
                            super.write(source, byteCount)
                            bytesWritten += byteCount
                            if (totalBytes > 0) {
                                val progress = ((bytesWritten * 100) / totalBytes).toInt()
                                // 30% base + 50% para upload = 80% max
                                onProgressUpdate(30 + ((progress * 50) / 100))
                            }
                        }
                    }
                    
                    // Escreve usando o sink de progresso
                    val bufferedSink = okio.buffer(progressSink)
                    requestBody.writeTo(bufferedSink)
                    bufferedSink.flush()
                }
            }
            
            // Substitui corpo da requisição por um com progresso
            val progressBody = ProgressListener(requestBody) { progress ->
                _uploadProgress.value = progress
            }
            
            // Atualiza progresso inicial
            _uploadProgress.value = 30
            
            // Executa a requisição
            val response = httpClient.newCall(request).execute()
            
            // Verifica resposta
            if (response.isSuccessful) {
                // Lê resposta
                val responseBody = response.body?.string() ?: "{}"
                val responseJson = JSONObject(responseBody)
                
                // Obtém o ID no servidor
                val serverRef = responseJson.optString("id", feedback.id)
                
                // Obtém a URL da imagem, se disponível
                val serverImageUrl = responseJson.optString("imageUrl")
                
                // Atualiza feedback como sincronizado
                val updatedFeedback = feedback.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef,
                    serverImageUrl = if (serverImageUrl.isNotEmpty()) serverImageUrl else null
                )
                feedbackDao.update(updatedFeedback)
                
                _uploadProgress.value = 100
                Log.d(TAG, "Feedback com imagem enviado com sucesso via API: ${feedback.id}")
                return true
            } else {
                // Lê mensagem de erro
                val errorResponse = response.body?.string() ?: "Erro desconhecido"
                Log.e(TAG, "Erro na API REST: ${response.code} - $errorResponse")
                
                // Incrementa contagem de tentativas
                val updatedFeedback = feedback.copy(
                    syncAttempts = feedback.syncAttempts + 1,
                    lastSyncAttempt = System.currentTimeMillis()
                )
                feedbackDao.update(updatedFeedback)
                
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar feedback com imagem via API: ${e.message}", e)
            
            // Incrementa contagem de tentativas
            val updatedFeedback = feedback.copy(
                syncAttempts = feedback.syncAttempts + 1,
                lastSyncAttempt = System.currentTimeMillis()
            )
            feedbackDao.update(updatedFeedback)
            
            return false
        }
    }
    
    /**
     * Atualiza estatísticas de upload
     */
    private fun updateUploadStats(success: Boolean) {
        val currentStats = _uploadStats.value ?: UploadStats()
        
        val updatedStats = if (success) {
            currentStats.copy(
                totalUploaded = currentStats.totalUploaded + 1,
                lastUploadTime = System.currentTimeMillis()
            )
        } else {
            currentStats.copy(
                totalFailed = currentStats.totalFailed + 1,
                lastUploadTime = System.currentTimeMillis()
            )
        }
        
        _uploadStats.postValue(updatedStats)
    }
    
    /**
     * Obtém contagem de feedbacks pendentes para envio
     */
    suspend fun getPendingFeedbacksCount(): Int = withContext(dispatcher) {
        return@withContext feedbackDao.getUnsyncedCount()
    }
    
    /**
     * Obtém o último feedback criado pelo usuário
     */
    suspend fun getLastFeedback(): Feedback? = withContext(dispatcher) {
        return@withContext feedbackDao.getLastFeedback()
    }
    
    /**
     * Obtém um feedback pelo ID
     */
    suspend fun getFeedback(feedbackId: String): Feedback? = withContext(dispatcher) {
        return@withContext feedbackDao.getById(feedbackId)
    }
    
    /**
     * Atualiza um feedback existente
     */
    suspend fun updateFeedback(feedback: Feedback): Boolean = withContext(dispatcher) {
        try {
            // Verifica se existe
            val existingFeedback = feedbackDao.getById(feedback.id)
                ?: throw IllegalArgumentException("Feedback não encontrado: ${feedback.id}")
            
            // Não permite mudar status de sincronização
            val updatedFeedback = feedback.copy(
                synced = existingFeedback.synced,
                syncTimestamp = existingFeedback.syncTimestamp,
                syncAttempts = existingFeedback.syncAttempts,
                lastSyncAttempt = existingFeedback.lastSyncAttempt,
                serverRef = existingFeedback.serverRef,
                serverImageUrl = existingFeedback.serverImageUrl,
                queuedForSync = existingFeedback.queuedForSync
            )
            
            // Atualiza no banco
            feedbackDao.update(updatedFeedback)
            
            Log.d(TAG, "Feedback atualizado com sucesso: ${feedback.id}")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao atualizar feedback: ${e.message}", e)
            return@withContext false
        }
    }
    
    /**
     * Exclui um feedback pelo ID
     */
    suspend fun deleteFeedback(feedbackId: String): Boolean = withContext(dispatcher) {
        try {
            // Busca o feedback
            val feedback = feedbackDao.getById(feedbackId)
                ?: return@withContext false
            
            // Exclui imagem associada, se houver
            if (!feedback.imagePath.isNullOrEmpty()) {
                val imageFile = File(feedback.imagePath)
                if (imageFile.exists()) {
                    imageFile.delete()
                }
            }
            
            // Exclui do banco
            feedbackDao.deleteById(feedbackId)
            
            Log.d(TAG, "Feedback excluído com sucesso: $feedbackId")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao excluir feedback: ${e.message}", e)
            return@withContext false
        }
    }
    
    /**
     * Reseta o estado de upload
     */
    fun resetUploadState() {
        _uploadState.value = UploadState.IDLE
        _uploadProgress.value = 0
    }
    
    /**
     * Estatísticas de upload de feedbacks
     */
    data class UploadStats(
        val totalUploaded: Int = 0,
        val totalFailed: Int = 0,
        val lastUploadTime: Long = 0
    )
    
    /**
     * Classe fictícia do Firebase para compatibilidade de compilação
     * Na implementação real, este código estaria disponível nas bibliotecas importadas
     */
    private class FirebaseDatabase {
        companion object {
            fun getInstance(): FirebaseDatabase = FirebaseDatabase()
        }
        
        fun getReference(path: String): DatabaseReference = DatabaseReference()
    }
    
    private class DatabaseReference {
        fun child(path: String): DatabaseReference = DatabaseReference()
        
        fun setValue(value: Any?): Task<Void> = Task()
    }
    
    private class Task<T> {
        fun addOnProgressListener(listener: (TaskSnapshot) -> Unit): Task<T> = this
        
        suspend fun await(): T = withContext(Dispatchers.IO) {
            @Suppress("UNCHECKED_CAST")
            Unit as T
        }
    }
    
    private class TaskSnapshot {
        val bytesTransferred: Long = 0
        val totalByteCount: Long = 1
    }
}