import React, { useState } from 'react';
import { DollarSign, ChevronUp, Settings } from 'lucide-react';
import EnhancedTollManager from './EnhancedTollManager';

// Componente principal QuickTollToggle
const QuickTollToggle = () => {
  const [tollsEnabled, setTollsEnabled] = useState(true);
  const [showDetails, setShowDetails] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [showQuickInfo, setShowQuickInfo] = useState(false);

  // Alternar todos os pedágios
  const toggleAllTolls = () => {
    setTollsEnabled(!tollsEnabled);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  return (
    <div className="relative w-full h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
      {/* Imagem de fundo simulando um mapa */}
      <div className="absolute inset-0 opacity-20 bg-[url('/api/placeholder/800/600')] bg-center bg-cover"></div>
      
      <div className="absolute top-4 left-4 text-white bg-black bg-opacity-50 p-2 rounded text-sm">
        Modo Preview: QuickTollToggle
      </div>
      
      {/* Botão flutuante de alternância rápida */}
      <div className="fixed left-4 bottom-24 flex flex-col items-center z-10">
        <button
          onClick={toggleAllTolls}
          className={`w-12 h-12 rounded-full shadow-lg flex items-center justify-center mb-2 ${
            tollsEnabled 
              ? 'bg-blue-600 hover:bg-blue-700' 
              : 'bg-gray-600 hover:bg-gray-700'
          }`}
        >
          <DollarSign 
            size={24} 
            className={`text-white ${!tollsEnabled && 'opacity-50'}`} 
          />
        </button>
        
        <button
          onClick={() => setShowQuickInfo(!showQuickInfo)}
          className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center shadow-lg"
        >
          <ChevronUp size={16} className="text-white" />
        </button>
      </div>

      {/* Alerta de status */}
      <div className={`fixed bottom-24 left-20 transition-opacity duration-300 ${
        showAlert ? 'opacity-100' : 'opacity-0'
      }`}>
        <div className={`${
          tollsEnabled ? 'bg-blue-600' : 'bg-gray-600'
        } text-white border-none shadow-lg p-3 rounded-md`}>
          Pedágios {tollsEnabled ? 'permitidos' : 'não permitidos'}
        </div>
      </div>

      {/* Menu flutuante com informações rápidas */}
      {showQuickInfo && (
        <div className="fixed left-20 bottom-24 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 w-48 z-10">
          <div className="text-sm dark:text-white">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">Status</span>
              <span className={tollsEnabled ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'}>
                {tollsEnabled ? 'Permitido' : 'Não Permitido'}
              </span>
            </div>
            <div className="text-gray-600 dark:text-gray-400 text-xs mb-3">
              Clique no botão para {tollsEnabled ? 'desativar' : 'ativar'} todos os pedágios
            </div>
            <button
              onClick={() => {
                setShowDetails(true);
                setShowQuickInfo(false);
              }}
              className="w-full bg-blue-600 text-white py-1 px-2 rounded text-sm flex items-center justify-center"
            >
              <Settings size={14} className="mr-1" />
              Configurações
            </button>
          </div>
        </div>
      )}

      {/* EnhancedTollManager Dialog */}
      {showDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <EnhancedTollManager 
            onClose={() => setShowDetails(false)}
          />
        </div>
      )}
    </div>
  );
};

export default QuickTollToggle;