import React, { useState, useEffect } from 'react';
import { AlertCircle, X, Copy, Share2 } from 'lucide-react';

const LocationInfoButton = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [locationInfo, setLocationInfo] = useState({
    loading: false,
    address: null,
    coordinates: null,
    error: null
  });
  
  const fetchLocationInfo = () => {
    setLocationInfo({ ...locationInfo, loading: true });
    
    // Simulando obtenção de localização real (em produção, usaria a Geolocation API)
    setTimeout(() => {
      // Dados simulados que seriam obtidos da API de geocodificação reversa
      const mockLocationData = {
        address: {
          street: "Rodovia BR-101, km 432",
          city: "Joinville",
          state: "Santa Catarina",
          stateCode: "SC",
          postalCode: "89223-005",
          country: "Brasil",
          district: "Zona Industrial Norte",
          reference: "Próximo ao posto Ipiranga"
        },
        coordinates: {
          latitude: -26.287765,
          longitude: -48.836272
        },
        additional: {
          elevation: "12m acima do nível do mar",
          speedLimit: "80 km/h",
          roadType: "Rodovia Federal",
          nearbyServices: ["Posto de combustível (0.3km)", "Borracharia (1.2km)", "Restaurante (0.5km)"]
        }
      };

      setLocationInfo({
        loading: false,
        ...mockLocationData,
        error: null
      });
    }, 1000);
  };
  
  const handleOpenLocationInfo = () => {
    setIsOpen(true);
    fetchLocationInfo();
  };
  
  const handleCopyToClipboard = () => {
    if (locationInfo.coordinates) {
      const textToCopy = `${locationInfo.coordinates.latitude} ${locationInfo.coordinates.longitude}`;
      navigator.clipboard.writeText(textToCopy)
        .then(() => alert("Coordenadas copiadas!"))
        .catch(() => alert("Não foi possível copiar as coordenadas"));
    }
  };
  
  const handleShare = () => {
    if (locationInfo.coordinates && locationInfo.address) {
      const shareText = `Minha localização atual: ${locationInfo.address.street}, ${locationInfo.address.city}, ${locationInfo.address.state} - ${locationInfo.address.postalCode}, ${locationInfo.address.country}. Coordenadas: ${locationInfo.coordinates.latitude} ${locationInfo.coordinates.longitude}`;
      
      if (navigator.share) {
        navigator.share({
          title: 'Minha localização - King Road',
          text: shareText,
          url: `https://maps.google.com/?q=${locationInfo.coordinates.latitude},${locationInfo.coordinates.longitude}`
        }).catch((error) => console.log('Erro ao compartilhar', error));
      } else {
        navigator.clipboard.writeText(shareText)
          .then(() => alert("Informações de localização copiadas para a área de transferência!"))
          .catch(() => alert("Não foi possível copiar as informações"));
      }
    }
  };
  
  // Implementação manual do diálogo em vez de usar o componente shadcn
  const LocationInfoDialog = () => {
    if (!isOpen) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div className="max-w-md w-full bg-gray-900 text-white border border-gray-700 rounded-lg shadow-xl p-6 m-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-blue-400">Onde Estou?</h2>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>
          
          {locationInfo.loading ? (
            <div className="flex flex-col items-center justify-center py-8">
              <div className="w-10 h-10 border-4 border-t-blue-500 border-blue-300 rounded-full animate-spin"></div>
              <p className="mt-4 text-gray-300">Obtendo sua localização...</p>
            </div>
          ) : locationInfo.error ? (
            <div className="text-red-400 my-4">
              {locationInfo.error}
            </div>
          ) : locationInfo.address ? (
            <div className="space-y-4 p-1">
              <div className="bg-gray-800 p-3 rounded-md">
                <h3 className="font-semibold text-blue-400 mb-1">Endereço</h3>
                <p className="text-gray-100">{locationInfo.address.street}</p>
                <p className="text-gray-100">{locationInfo.address.district}</p>
                <p className="text-gray-100">{locationInfo.address.city}, {locationInfo.address.stateCode} - {locationInfo.address.postalCode}</p>
                <p className="text-gray-100">{locationInfo.address.country}</p>
                <p className="text-gray-300 text-sm mt-1">Ref: {locationInfo.address.reference}</p>
              </div>
              
              <div className="bg-gray-800 p-3 rounded-md">
                <h3 className="font-semibold text-blue-400 mb-1">Coordenadas GPS</h3>
                <div className="flex items-center justify-between">
                  <p className="font-mono text-sm bg-gray-700 p-1 rounded">
                    {locationInfo.coordinates.latitude} {locationInfo.coordinates.longitude}
                  </p>
                  <button 
                    onClick={handleCopyToClipboard}
                    className="bg-gray-700 text-white text-xs px-2 py-1 rounded hover:bg-gray-600 flex items-center gap-1"
                  >
                    <Copy size={12} /> Copiar
                  </button>
                </div>
              </div>
              
              <div className="bg-gray-800 p-3 rounded-md">
                <h3 className="font-semibold text-blue-400 mb-1">Informações adicionais</h3>
                <p className="text-gray-100">Elevação: {locationInfo.additional.elevation}</p>
                <p className="text-gray-100">Limite de velocidade: {locationInfo.additional.speedLimit}</p>
                <p className="text-gray-100">Tipo de via: {locationInfo.additional.roadType}</p>
                
                <h4 className="font-semibold text-gray-300 mt-2 mb-1">Serviços próximos:</h4>
                <ul className="text-gray-300 text-sm">
                  {locationInfo.additional.nearbyServices.map((service, idx) => (
                    <li key={idx} className="ml-2">• {service}</li>
                  ))}
                </ul>
              </div>
              
              <div className="flex justify-between pt-2">
                <button 
                  onClick={handleShare}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors w-full flex items-center justify-center gap-2"
                >
                  <Share2 size={16} /> Compartilhar Localização
                </button>
              </div>
            </div>
          ) : null}
          
          <div className="mt-6 flex justify-end">
            <button 
              className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded"
              onClick={() => setIsOpen(false)}
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <>
      {/* Botão de interrogação flutuante */}
      <button 
        className="flex items-center justify-center w-12 h-12 bg-blue-700 text-white rounded-full shadow-lg fixed bottom-6 right-6 z-50 hover:bg-blue-800 transition-colors"
        onClick={handleOpenLocationInfo}
        aria-label="Onde estou?"
      >
        <AlertCircle size={24} />
      </button>
      
      {/* Modal de informações de localização - Implementação sem dependências externas */}
      <LocationInfoDialog />
    </>
  );
};

export default LocationInfoButton;