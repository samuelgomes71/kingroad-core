package com.kingroad.navigation.intermodal

import android.location.Location
import java.util.Calendar
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Implementação oficial do repositório de conexões intermodais com suporte global.
 */
class IntermodalConnectionRepositoryImpl : IntermodalConnectionRepository {

    override suspend fun findConnectionsBetween(
        startLocation: Location,
        endLocation: Location
    ): List<IntermodalConnection> {
        val allConnections = GlobalIntermodalConnections.getAllMajorConnections()
        return allConnections.filter { connection ->
            isConnectionPotentiallyOnRoute(
                startLat = startLocation.latitude,
                startLon = startLocation.longitude,
                endLat = endLocation.latitude,
                endLon = endLocation.longitude,
                connectionStartLat = connection.startLocation.latitude,
                connectionStartLon = connection.startLocation.longitude,
                connectionEndLat = connection.endLocation.latitude,
                connectionEndLon = connection.endLocation.longitude
            )
        }
    }

    override suspend fun findAlternativeRoutes(
        startLocation: Location,
        endLocation: Location,
        avoidedConnection: IntermodalConnection
    ): List<RouteInfo> {
        return listOf(
            RouteInfo(
                id = "alt_route1",
                startPoint = GeoPoint(
                    startLocation.latitude,
                    startLocation.longitude,
                    findNearestCity(startLocation.latitude, startLocation.longitude)
                ),
                endPoint = GeoPoint(
                    endLocation.latitude,
                    endLocation.longitude,
                    findNearestCity(endLocation.latitude, endLocation.longitude)
                ),
                distance = calculateDirectDistance(startLocation.latitude, startLocation.longitude, endLocation.latitude, endLocation.longitude) * 1.4,
                duration = (calculateApproximateTravelTime(startLocation.latitude, startLocation.longitude, endLocation.latitude, endLocation.longitude) * 1.5).toInt(),
                intermodalConnections = findAlternativeConnections(startLocation, endLocation, avoidedConnection),
                totalCost = Random.nextDouble(100.0, 300.0),
                currency = determineCurrency(endLocation.latitude, endLocation.longitude)
            ),
            RouteInfo(
                id = "alt_route2",
                startPoint = GeoPoint(
                    startLocation.latitude,
                    startLocation.longitude,
                    findNearestCity(startLocation.latitude, startLocation.longitude)
                ),
                endPoint = GeoPoint(
                    endLocation.latitude,
                    endLocation.longitude,
                    findNearestCity(endLocation.latitude, endLocation.longitude)
                ),
                distance = calculateDirectDistance(startLocation.latitude, startLocation.longitude, endLocation.latitude, endLocation.longitude) * 1.8,
                duration = (calculateApproximateTravelTime(startLocation.latitude, startLocation.longitude, endLocation.latitude, endLocation.longitude) * 1.7).toInt(),
                intermodalConnections = emptyList(),
                totalCost = Random.nextDouble(50.0, 150.0),
                currency = determineCurrency(endLocation.latitude, endLocation.longitude)
            )
        )
    }

    override suspend fun findConnectionsNear(location: Location, radiusInKm: Double): List<IntermodalConnection> {
        val allConnections = GlobalIntermodalConnections.getAllMajorConnections()
        return allConnections.filter { connection ->
            val startDistance = calculateDistance(location.latitude, location.longitude, connection.startLocation.latitude, connection.startLocation.longitude)
            val endDistance = calculateDistance(location.latitude, location.longitude, connection.endLocation.latitude, connection.endLocation.longitude)
            startDistance <= radiusInKm || endDistance <= radiusInKm
        }
    }

    override suspend fun getConnectionDetails(connectionId: String): ConnectionDetails? {
        return GlobalIntermodalConnections.getConnectionDetails(connectionId)
    }

    override suspend fun getSchedule(connectionId: String, date: Long): List<ScheduleEntry> {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = date
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val startOfDay = calendar.timeInMillis
        val connection = GlobalIntermodalConnections.getAllMajorConnections().find { it.id == connectionId } ?: return emptyList()

        return when (connection.type) {
            ConnectionType.TRAIN_TUNNEL -> {
                val interval = when (connectionId) {
                    "eurotunnel" -> 60
                    "gotthard" -> 30
                    else -> 60
                }
                generateSchedule(startOfDay, 6, 22, interval, connection.averageDuration, connection.baseFee, true)
            }

            ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL ->
                generateSchedule(startOfDay, 0, 23, 15, connection.averageDuration, connection.baseFee, true)

            ConnectionType.FERRY -> when (connectionId) {
                "vikingline" -> listOf(ScheduleEntry(
                    departureTime = startOfDay + 17 * 3600 * 1000L,
                    arrivalTime = startOfDay + 17 * 3600 * 1000L + (connection.averageDuration * 60 * 1000L),
                    availableVehicleSpots = (50..200).random(),
                    availablePassengerSpots = (100..500).random(),
                    currentFee = connection.baseFee?.let { it + Random.nextDouble(-10.0, 25.0) }
                ))
                else -> listOf(8, 12, 16, 20).map { hour ->
                    ScheduleEntry(
                        departureTime = startOfDay + hour * 3600 * 1000L,
                        arrivalTime = startOfDay + hour * 3600 * 1000L + (connection.averageDuration * 60 * 1000L),
                        availableVehicleSpots = (30..120).random(),
                        availablePassengerSpots = (50..250).random(),
                        currentFee = connection.baseFee?.let { it + Random.nextDouble(-10.0, 20.0) }
                    )
                }
            }

            ConnectionType.PASSENGER_FERRY -> generateSchedule(startOfDay, 6, 23, 30, connection.averageDuration, connection.baseFee, false)

            else -> emptyList()
        }
    }

    override suspend fun syncDatabase(): Int {
        return GlobalIntermodalConnections.getAllMajorConnections().size
    }

    // Métodos auxiliares (mesmos, sem mudanças)...
    // calculateDistance, calculateDirectDistance, calculateApproximateTravelTime,
    // findNearestCity, determineCurrency, generateSchedule, etc.

}