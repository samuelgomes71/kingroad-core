import React, { useState, useEffect } from 'react';
import { AlertTriangle, Shield, UserX, Truck, Car, Zap } from 'lucide-react';

const BrazilSecurityAlerts = ({ onAlertClick, userLocation }) => {
  // Estado para armazenar os alertas ativos
  const [activeAlerts, setActiveAlerts] = useState([]);
  // Estado para controlar o filtro de alertas
  const [filter, setFilter] = useState('all');
  // Estado para controlar a distância máxima de alertas a serem exibidos
  const [maxDistance, setMaxDistance] = useState(30); // 30km por padrão

  // Dados de exemplo para preview
  const sampleAlerts = [
    {
      id: 'a1',
      type: 'tiroteio',
      location: { lat: -23.5505, lng: -46.6333 }, // São Paulo
      timestamp: new Date().getTime() - 1000 * 60 * 5, // 5 minutos atrás
      description: 'Tiroteio em andamento na Av. Paulista',
      severity: 'high',
      reportedBy: 'KingID:75842',
      distance: 2.5, // km
      verified: true
    },
    {
      id: 'a2',
      type: 'sequestro',
      location: { lat: -23.5605, lng: -46.6433 },
      timestamp: new Date().getTime() - 1000 * 60 * 15, // 15 minutos atrás
      description: 'Tentativa de sequestro relâmpago próximo ao Shopping',
      severity: 'high',
      reportedBy: 'KingID:12935',
      distance: 5.3,
      verified: true
    },
    {
      id: 'a3',
      type: 'roubo_carga',
      location: { lat: -23.5705, lng: -46.6533 },
      timestamp: new Date().getTime() - 1000 * 60 * 35, // 35 minutos atrás
      description: 'Roubo de carga na Rodovia Anhanguera, km 15',
      severity: 'high',
      reportedBy: 'KingID:36721',
      distance: 12.8,
      verified: true
    },
    {
      id: 'a4',
      type: 'veiculo_suspeito',
      location: { lat: -23.5805, lng: -46.6633 },
      timestamp: new Date().getTime() - 1000 * 60 * 25, // 25 minutos atrás
      description: 'Carro preto modelo Corolla sem placa seguindo caminhões',
      severity: 'medium',
      reportedBy: 'KingID:98742',
      distance: 8.2,
      verified: false
    },
    {
      id: 'a5',
      type: 'veiculo_alta_velocidade',
      location: { lat: -23.5905, lng: -46.6733 },
      timestamp: new Date().getTime() - 1000 * 60 * 10, // 10 minutos atrás
      description: 'Motocicletas em alta velocidade fazendo manobras perigosas',
      severity: 'medium',
      reportedBy: 'KingID:45612',
      distance: 15.7,
      verified: false
    }
  ];

  useEffect(() => {
    // Em um cenário real, aqui buscaríamos os alertas do backend
    // Usando os dados de exemplo para preview
    setActiveAlerts(sampleAlerts);
  }, []);

  // Filtra os alertas com base no filtro selecionado e na distância máxima
  const filteredAlerts = activeAlerts.filter(alert => {
    const passesFilter = filter === 'all' || alert.type === filter;
    const passesDistance = alert.distance <= maxDistance;
    return passesFilter && passesDistance;
  });

  // Função para renderizar o ícone correto para cada tipo de alerta
  const renderAlertIcon = (type, size = 20) => {
    switch (type) {
      case 'tiroteio':
        return <Shield size={size} className="text-red-500" />;
      case 'sequestro':
        return <UserX size={size} className="text-red-500" />;
      case 'roubo_carga':
        return <Truck size={size} className="text-red-500" />;
      case 'veiculo_suspeito':
        return <Car size={size} className="text-yellow-500" />;
      case 'veiculo_alta_velocidade':
        return <Zap size={size} className="text-yellow-500" />;
      default:
        return <AlertTriangle size={size} className="text-yellow-500" />;
    }
  };

  // Formata a timestamp para exibição
  const formatTimestamp = (timestamp) => {
    const now = new Date().getTime();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (minutes < 60) {
      return `${minutes} min atrás`;
    } else {
      const hours = Math.floor(minutes / 60);
      return `${hours}h atrás`;
    }
  };

  // Traduz o tipo de alerta para português
  const translateAlertType = (type) => {
    const translations = {
      'tiroteio': 'Tiroteio',
      'sequestro': 'Sequestro',
      'roubo_carga': 'Roubo de Carga',
      'veiculo_suspeito': 'Veículo Suspeito',
      'veiculo_alta_velocidade': 'Veículo em Alta Velocidade',
    };
    return translations[type] || type;
  };

  return (
    <div className="flex flex-col h-full w-full bg-gray-900 text-white p-4 rounded-lg overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold flex items-center">
          <AlertTriangle className="mr-2 text-amber-500" size={24} />
          <span>Alertas de Segurança</span>
          <span className="ml-2 text-sm bg-amber-500 text-black px-2 py-1 rounded-full">{filteredAlerts.length}</span>
        </h2>
        
        <div className="flex space-x-2">
          <select 
            className="bg-gray-800 border border-gray-700 text-white rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">Todos os alertas</option>
            <option value="tiroteio">Tiroteio</option>
            <option value="sequestro">Sequestro</option>
            <option value="roubo_carga">Roubo de Carga</option>
            <option value="veiculo_suspeito">Veículo Suspeito</option>
            <option value="veiculo_alta_velocidade">Alta Velocidade</option>
          </select>
          
          <select 
            className="bg-gray-800 border border-gray-700 text-white rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            value={maxDistance}
            onChange={(e) => setMaxDistance(Number(e.target.value))}
          >
            <option value={5}>5 km</option>
            <option value={10}>10 km</option>
            <option value={20}>20 km</option>
            <option value={30}>30 km</option>
            <option value={50}>50 km</option>
            <option value={100}>100 km</option>
          </select>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto space-y-2">
        {filteredAlerts.length > 0 ? (
          filteredAlerts.map((alert) => (
            <div 
              key={alert.id}
              className="relative border border-gray-700 rounded-lg p-3 hover:bg-gray-800 transition-colors cursor-pointer group"
              onClick={() => onAlertClick && onAlertClick(alert)}
            >
              <div className="absolute top-0 right-0 mt-2 mr-2">
                {alert.verified ? (
                  <span className="text-xs bg-green-900 text-green-300 px-2 py-1 rounded-full">Verificado</span>
                ) : (
                  <span className="text-xs bg-gray-800 text-gray-400 px-2 py-1 rounded-full">Não verificado</span>
                )}
              </div>
              
              <div className="flex items-start mb-2">
                <div className="flex-shrink-0 mr-3 mt-1">
                  {renderAlertIcon(alert.type, 24)}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h3 className="text-lg font-semibold text-amber-500">
                      {translateAlertType(alert.type)}
                    </h3>
                    <span className="text-sm text-gray-400">
                      {formatTimestamp(alert.timestamp)}
                    </span>
                  </div>
                  <p className="text-gray-300 text-sm mb-2">{alert.description}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{alert.reportedBy}</span>
                    <span className={`
                      ${alert.distance < 5 ? 'text-red-400' : 
                       alert.distance < 15 ? 'text-yellow-400' : 'text-gray-400'}
                    `}>
                      {alert.distance.toFixed(1)} km
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="absolute bottom-0 left-0 right-0 h-1 rounded-b-lg overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity">
                <div 
                  className={`h-full ${
                    alert.severity === 'high' ? 'bg-red-500' : 
                    alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                  }`}
                />
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 py-10">
            <AlertTriangle size={48} className="mb-4 text-gray-600" />
            <p className="text-lg">Nenhum alerta nesta área</p>
            <p className="text-sm">Tente aumentar a distância ou mudar o filtro</p>
          </div>
        )}
      </div>
      
      <div className="mt-4 border-t border-gray-700 pt-3">
        <button 
          className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-4 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-amber-300"
          onClick={() => {/* Função para reportar novo alerta */}}
        >
          Reportar Novo Alerta
        </button>
      </div>
    </div>
  );
};

export default BrazilSecurityAlerts;