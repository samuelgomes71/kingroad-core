import React, { useState } from 'react';
import { Map, Eye, LayoutGrid, MapPin, X, Check } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const MapViewModes = () => {
  const [selectedMode, setSelectedMode] = useState('full'); // full, route, simplified
  const [showModeSelector, setShowModeSelector] = useState(true);

  // Componente de seleção de modo
  const ModeSelector = () => (
    <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-gray-900 rounded-lg shadow-lg p-4 w-[600px]">
      <div className="grid grid-cols-3 gap-4">
        {/* Modo Rota Completa */}
        <button
          onClick={() => setSelectedMode('route')}
          className={`p-4 rounded-lg flex flex-col items-center ${
            selectedMode === 'route' ? 'bg-blue-600' : 'bg-gray-800'
          }`}
        >
          <Map size={24} className="text-white mb-2" />
          <h3 className="text-white font-medium">Rota Detalhada</h3>
          <p className="text-sm text-gray-400 text-center mt-2">
            Visualize a rota completa com números de trechos
          </p>
        </button>

        {/* Modo Mapa Aberto */}
        <button
          onClick={() => setSelectedMode('full')}
          className={`p-4 rounded-lg flex flex-col items-center ${
            selectedMode === 'full' ? 'bg-blue-600' : 'bg-gray-800'
          }`}
        >
          <Eye size={24} className="text-white mb-2" />
          <h3 className="text-white font-medium">Mapa Completo</h3>
          <p className="text-sm text-gray-400 text-center mt-2">
            Visualize todas as vias e detalhes da região
          </p>
        </button>

        {/* Modo Simplificado */}
        <button
          onClick={() => setSelectedMode('simplified')}
          className={`p-4 rounded-lg flex flex-col items-center ${
            selectedMode === 'simplified' ? 'bg-blue-600' : 'bg-gray-800'
          }`}
        >
          <LayoutGrid size={24} className="text-white mb-2" />
          <h3 className="text-white font-medium">Mapa Simplificado</h3>
          <p className="text-sm text-gray-400 text-center mt-2">
            Apenas vias principais para caminhões
          </p>
        </button>
      </div>
    </div>
  );

  // Legenda para o modo de rota
  const RouteLegend = () => (
    <div className="absolute bottom-4 left-4 bg-gray-900 rounded-lg p-4">
      <h4 className="text-white font-medium mb-2">Legenda de Trechos</h4>
      <div className="space-y-2">
        <div className="flex items-center">
          <div className="w-4 h-4 bg-blue-500 rounded mr-2" />
          <span className="text-gray-300">Autoestradas</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-green-500 rounded mr-2" />
          <span className="text-gray-300">Estradas Nacionais</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-yellow-500 rounded mr-2" />
          <span className="text-gray-300">Estradas Departamentais</span>
        </div>
      </div>
    </div>
  );

  // Barra de filtros para modo simplificado
  const SimplifiedFilters = () => (
    <div className="absolute top-20 left-4 bg-gray-900 rounded-lg p-4">
      <h4 className="text-white font-medium mb-2">Filtros de Vias</h4>
      <div className="space-y-2">
        <label className="flex items-center">
          <input type="checkbox" className="mr-2" defaultChecked />
          <span className="text-gray-300">Autoestradas</span>
        </label>
        <label className="flex items-center">
          <input type="checkbox" className="mr-2" defaultChecked />
          <span className="text-gray-300">Estradas Nacionais</span>
        </label>
        <label className="flex items-center">
          <input type="checkbox" className="mr-2" defaultChecked />
          <span className="text-gray-300">Estradas Departamentais</span>
        </label>
      </div>
    </div>
  );

  // Informações da rota atual
  const RouteInfo = () => (
    <div className="absolute top-20 right-4 bg-gray-900 rounded-lg p-4 w-64">
      <h4 className="text-white font-medium mb-2">Informações da Rota</h4>
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-gray-400">Distância:</span>
          <span className="text-white">487 km</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Tempo Estimado:</span>
          <span className="text-white">5h 45min</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Pedágios:</span>
          <span className="text-white">4</span>
        </div>
      </div>
    </div>
  );

  // Confirmação de rota
  const RouteConfirmation = () => (
    <div className="absolute bottom-4 right-4 bg-gray-900 rounded-lg p-4">
      <div className="flex items-center space-x-4">
        <button 
          onClick={() => {/* Lógica de confirmação */}}
          className="bg-green-600 text-white px-4 py-2 rounded flex items-center"
        >
          <Check size={16} className="mr-2" />
          Confirmar Rota
        </button>
        <button 
          onClick={() => {/* Lógica de cancelamento */}}
          className="bg-red-600 text-white px-4 py-2 rounded flex items-center"
        >
          <X size={16} className="mr-2" />
          Cancelar
        </button>
      </div>
    </div>
  );

  // Indicador de modo atual
  const ModeIndicator = () => (
    <div 
      className="absolute top-4 right-4 bg-gray-900 rounded-lg p-2 flex items-center cursor-pointer"
      onClick={() => setShowModeSelector(true)}
    >
      <div className="flex items-center space-x-2">
        {selectedMode === 'route' && <Map size={16} className="text-white" />}
        {selectedMode === 'full' && <Eye size={16} className="text-white" />}
        {selectedMode === 'simplified' && <LayoutGrid size={16} className="text-white" />}
        <span className="text-white">
          {selectedMode === 'route' && 'Rota Detalhada'}
          {selectedMode === 'full' && 'Mapa Completo'}
          {selectedMode === 'simplified' && 'Mapa Simplificado'}
        </span>
      </div>
    </div>
  );

  return (
    <div className="relative h-screen bg-gray-900">
      {/* Área do Mapa (placeholder) */}
      <div className="absolute inset-0 bg-gray-800">
        {/* Aqui seria integrado o mapa real */}
      </div>

      {/* Interface do usuário */}
      {showModeSelector && <ModeSelector />}
      <ModeIndicator />

      {/* Elementos específicos de cada modo */}
      {selectedMode === 'route' && (
        <>
          <RouteLegend />
          <RouteInfo />
          <RouteConfirmation />
        </>
      )}

      {selectedMode === 'simplified' && <SimplifiedFilters />}
    </div>
  );
};

export default MapViewModes;