// HistoryManagerService.kt
package com.kingroad.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.kingroad.cache.CacheManager
import com.kingroad.database.TripRepository
import com.kingroad.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/**
 * Serviço para gerenciamento automático do histórico de navegação
 */
class HistoryManagerService : Service() {
    companion object {
        private const val TAG = "HistoryManagerService"
        private val CHECK_INTERVAL = TimeUnit.HOURS.toMillis(12) // Verificar a cada 12 horas
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default)
    private lateinit var tripRepository: TripRepository
    private lateinit var cacheManager: CacheManager

    override fun onCreate() {
        super.onCreate()
        Logger.d(TAG, "Iniciando serviço de gerenciamento de histórico")
        
        tripRepository = TripRepository(applicationContext)
        cacheManager = CacheManager(applicationContext)
        
        startPeriodicCleanup()
    }

    override fun onDestroy() {
        Logger.d(TAG, "Finalizando serviço de gerenciamento de histórico")
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Inicia verificação periódica e limpeza de histórico
     */
    private fun startPeriodicCleanup() {
        serviceScope.launch {
            while (true) {
                try {
                    // Executar limpeza de histórico
                    Logger.d(TAG, "Executando verificação periódica de histórico")
                    tripRepository.cleanupTripHistory()
                    
                    // Aguardar até o próximo ciclo
                    delay(CHECK_INTERVAL)
                } catch (e: Exception) {
                    Logger.e(TAG, "Erro na limpeza periódica: ${e.message}")
                    delay(TimeUnit.MINUTES.toMillis(30)) // Aguardar 30 minutos em caso de erro
                }
            }
        }
    }
}