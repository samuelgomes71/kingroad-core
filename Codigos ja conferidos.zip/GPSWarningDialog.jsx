import React, { useState, useEffect } from 'react';
import { AlertTriangle, Clock, X } from 'lucide-react';

const GPSWarningDialog = ({
  runningApps = [],
  timeRemaining = 180000, // 3 minutos em ms
  onCloseNow = () => {},
  onDismiss = () => {}
}) => {
  const [countdown, setCountdown] = useState(timeRemaining);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => Math.max(0, prev - 1000));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (ms) => {
    const seconds = Math.ceil(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Exemplo de apps para demonstração
  const demoApps = [
    {
      packageName: 'com.google.android.apps.maps',
      appName: 'Google Maps',
      memoryUsage: 150 * 1024 * 1024 // 150MB
    },
    {
      packageName: 'com.waze',
      appName: 'Waze',
      memoryUsage: 120 * 1024 * 1024 // 120MB
    }
  ];

  // Usar apps da prop ou demo apps se a prop estiver vazia
  const appsToShow = runningApps.length > 0 ? runningApps : demoApps;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-lg max-w-md w-full shadow-xl">
        {/* Cabeçalho */}
        <div className="bg-red-900 p-4 rounded-t-lg flex items-center">
          <AlertTriangle size={24} className="text-red-300 mr-3" />
          <div className="flex-1">
            <h3 className="font-bold text-white">
              Outros Apps GPS Detectados
            </h3>
            <p className="text-sm text-red-200">
              Para evitar conflitos, os seguintes apps serão fechados:
            </p>
          </div>
          <button 
            onClick={onDismiss}
            className="p-2 hover:bg-red-800 rounded"
          >
            <X size={20} className="text-red-300" />
          </button>
        </div>

        {/* Lista de Apps */}
        <div className="p-4">
          <div className="space-y-2 mb-4">
            {appsToShow.map(app => (
              <div 
                key={app.packageName}
                className="flex items-center bg-gray-800 p-3 rounded"
              >
                <div className="flex-1">
                  <div className="font-medium text-gray-200">
                    {app.appName}
                  </div>
                  <div className="text-sm text-gray-400">
                    {(app.memoryUsage / 1024 / 1024).toFixed(1)} MB em uso
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Contagem Regressiva */}
          <div className="bg-gray-800 p-3 rounded flex items-center justify-between mb-4">
            <div className="flex items-center text-gray-300">
              <Clock size={20} className="mr-2" />
              Tempo restante:
            </div>
            <div className="font-mono text-xl text-white">
              {formatTime(countdown)}
            </div>
          </div>

          {/* Botões */}
          <div className="flex space-x-3">
            <button
              onClick={onCloseNow}
              className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Fechar Agora
            </button>
            <button
              onClick={onDismiss}
              className="flex-1 bg-gray-700 text-gray-200 py-2 rounded-lg hover:bg-gray-600 transition-colors"
            >
              Lembrar Depois
            </button>
          </div>

          {/* Mensagem de RAM */}
          <div className="mt-4 text-sm text-gray-400 text-center">
            Nota: Este aviso aparece apenas em dispositivos com menos de 8GB de RAM
          </div>
        </div>
      </div>
    </div>
  );
};

// Componente de demonstração
const DemoContainer = () => {
  return (
    <div className="h-screen bg-gray-950 flex items-center justify-center">
      <GPSWarningDialog />
    </div>
  );
};

export default GPSWarningDialog;