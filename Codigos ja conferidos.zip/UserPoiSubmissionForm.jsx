// web/src/components/poi/UserPoiSubmissionForm.jsx

import React, { useState, useEffect } from 'react';
import { MapPinIcon, CameraIcon, DocumentTextIcon, ScaleIcon, GasStationIcon, WrenchIcon } from '../icons/MapIcons';
import { useMapContext } from '../../contexts/MapContext';
import { useUserPoiSubmission } from '../../hooks/useUserPoiSubmission';
import { useTranslation } from '../../hooks/useTranslation';
import { useNotification } from '../../hooks/useNotification';
import { useLocation } from '../../hooks/useLocation';
import { useAuth } from '../../contexts/AuthContext';

/**
 * Formulário de submissão de POIs por usuários para o KingRoad
 * Permite adicionar locais de serviços de documentos, balanças e outros manualmente
 */
const UserPoiSubmissionForm = ({ onClose, initialType = null }) => {
  const { t } = useTranslation('pois');
  const { currentLocation, map, setMapCenter } = useMapContext();
  const { submitUserPoi, submitDocumentServicePoi, submitCertifiedScalePoi, takePhoto } = useUserPoiSubmission();
  const { getCurrentLocation } = useLocation();
  const { showSuccess, showError } = useNotification();
  const { isAuthenticated } = useAuth();
  
  // Estado do formulário
  const [step, setStep] = useState(1);
  const [selectedType, setSelectedType] = useState(initialType);
  const [poiName, setPoiName] = useState('');
  const [poiAddress, setPoiAddress] = useState('');
  const [poiDescription, setPoiDescription] = useState('');
  const [poiPhone, setPoiPhone] = useState('');
  const [poiWebsite, setPoiWebsite] = useState('');
  const [operatingHours, setOperatingHours] = useState('');
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [submissionId, setSubmissionId] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Estados específicos para serviços de documentos
  const [documentServices, setDocumentServices] = useState([]);
  
  // Estados específicos para balanças
  const [scaleType, setScaleType] = useState('CERTIFIED');
  const [scalePrice, setScalePrice] = useState('');
  const [maxWeight, setMaxWeight] = useState('');
  const [isOpen24h, setIsOpen24h] = useState(false);
  const [providesOfficialCertificate, setProvidesOfficialCertificate] = useState(true);
  
  // Tipos de POIs disponíveis
  const poiTypes = [
    { id: 'DOCUMENT_SERVICE', name: t('documentService'), icon: <DocumentTextIcon className="w-6 h-6" /> },
    { id: 'CERTIFIED_SCALE', name: t('certifiedScale'), icon: <ScaleIcon className="w-6 h-6" /> },
    { id: 'FUEL_STATION', name: t('fuelStation'), icon: <GasStationIcon className="w-6 h-6" /> },
    { id: 'REPAIR_SHOP', name: t('repairShop'), icon: <WrenchIcon className="w-6 h-6" /> },
    { id: 'OTHER', name: t('otherPoi'), icon: <MapPinIcon className="w-6 h-6" /> }
  ];
  
  // Opções de serviços de documentos
  const documentServiceOptions = [
    { id: 'FAX', name: t('faxService') },
    { id: 'EMAIL', name: t('emailService') },
    { id: 'PRINTING', name: t('printingService') },
    { id: 'SCANNING', name: t('scanningService') },
    { id: 'NOTARY', name: t('notaryService') }
  ];
  
  // Opções de tipos de balança
  const scaleTypeOptions = [
    { id: 'CERTIFIED', name: t('certifiedScale') },
    { id: 'REGULATORY', name: t('regulatoryScale') },
    { id: 'SELF_WEIGH', name: t('selfWeighScale') }
  ];
  
  // Inicializa o mapa na localização atual no carregamento
  useEffect(() => {
    if (!selectedLocation && currentLocation) {
      setSelectedLocation(currentLocation);
    }
  }, [currentLocation, selectedLocation]);
  
  // Verifica se o usuário está logado
  useEffect(() => {
    if (!isAuthenticated) {
      showError(t('loginRequiredForSubmission'));
      onClose();
    }
  }, [isAuthenticated, onClose, showError, t]);
  
  // Atualiza o mapa quando a localização selecionada muda
  useEffect(() => {
    if (selectedLocation && map && step === 2) {
      setMapCenter(selectedLocation);
    }
  }, [selectedLocation, map, step, setMapCenter]);
  
  // Manipula seleção de tipo de POI
  const handleTypeSelection = (typeId) => {
    setSelectedType(typeId);
    setStep(2);
  };
  
  // Localiza usuário no mapa
  const handleLocateMe = async () => {
    const location = await getCurrentLocation();
    if (location) {
      setSelectedLocation(location);
      setMapCenter(location);
    } else {
      showError(t('locationError'));
    }
  };
  
  // Manipula clique no mapa para selecionar localização
  const handleMapClick = (location) => {
    setSelectedLocation(location);
  };
  
  // Manipula mudança nos serviços de documento
  const handleDocumentServiceChange = (serviceId) => {
    if (documentServices.includes(serviceId)) {
      setDocumentServices(documentServices.filter(id => id !== serviceId));
    } else {
      setDocumentServices([...documentServices, serviceId]);
    }
  };
  
  // Manipula captura de foto
  const handleTakePhoto = async () => {
    if (!submissionId) return;
    
    const success = await takePhoto(submissionId);
    if (success) {
      setPhotos([...photos, success]);
      showSuccess(t('photoAdded'));
    } else {
      showError(t('photoError'));
    }
  };
  
  // Inicia a submissão (Etapa 1 - informações básicas)
  const handleStartSubmission = async () => {
    if (!poiName.trim() || !selectedLocation) {
      showError(t('requiredFieldsMissing'));
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Inicia a submissão com informações básicas
      const id = await submitUserPoi(selectedType, poiName, selectedLocation);
      if (id) {
        setSubmissionId(id);
        setStep(3);
      } else {
        showError(t('submissionError'));
      }
    } catch (error) {
      showError(error.message || t('submissionError'));
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Finaliza a submissão com todas as informações
  const handleCompleteSubmission = async () => {
    if (!submissionId || !poiAddress.trim()) {
      showError(t('requiredFieldsMissing'));
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      let success = false;
      
      // Submissão específica com base no tipo
      if (selectedType === 'DOCUMENT_SERVICE') {
        if (documentServices.length === 0) {
          showError(t('selectAtLeastOneDocumentService'));
          setIsSubmitting(false);
          return;
        }
        
        success = await submitDocumentServicePoi(
          submissionId,
          poiAddress,
          poiDescription,
          poiPhone,
          documentServices,
          operatingHours
        );
      } else if (selectedType === 'CERTIFIED_SCALE') {
        success = await submitCertifiedScalePoi(
          submissionId,
          poiAddress,
          poiDescription,
          poiPhone,
          scaleType,
          operatingHours,
          scalePrice ? parseFloat(scalePrice) : null,
          maxWeight ? parseInt(maxWeight) : null,
          isOpen24h,
          providesOfficialCertificate
        );
      } else {
        // Submissão genérica para outros tipos de POI
        success = await submitUserPoi(
          selectedType,
          poiName,
          selectedLocation,
          poiAddress,
          poiDescription,
          poiPhone,
          poiWebsite
        );
      }
      
      if (success) {
        showSuccess(t('submissionSuccess'));
        setStep(4); // Sucesso
      } else {
        showError(t('submissionError'));
      }
    } catch (error) {
      showError(error.message || t('submissionError'));
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Renderiza formulário com base na etapa atual
  const renderFormByStep = () => {
    switch (step) {
      case 1:
        return renderTypeSelection();
      case 2:
        return renderLocationSelection();
      case 3:
        return renderPoiDetails();
      case 4:
        return renderSuccessScreen();
      default:
        return renderTypeSelection();
    }
  };
  
  // Renderiza etapa de seleção de tipo
  const renderTypeSelection = () => (
    <div className="poi-type-selection">
      <h2 className="text-xl font-bold mb-4 text-amber-500">{t('selectPoiType')}</h2>
      
      <div className="grid grid-cols-2 gap-4">
        {poiTypes.map(type => (
          <button
            key={type.id}
            className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 ${
              selectedType === type.id 
                ? 'border-amber-500 bg-amber-500 bg-opacity-20' 
                : 'border-gray-700 hover:border-gray-500'
            }`}
            onClick={() => handleTypeSelection(type.id)}
          >
            <div className={`text-2xl mb-2 ${selectedType === type.id ? 'text-amber-500' : 'text-white'}`}>
              {type.icon}
            </div>
            <span className={selectedType === type.id ? 'text-amber-500' : 'text-white'}>
              {type.name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
  
  // Renderiza etapa de seleção de localização
  const renderLocationSelection = () => (
    <div className="location-selection">
      <h2 className="text-xl font-bold mb-4 text-amber-500">{t('selectLocation')}</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">{t('poiName')} *</label>
        <input
          type="text"
          className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
          value={poiName}
          onChange={(e) => setPoiName(e.target.value)}
          placeholder={t('enterPoiName')}
        />
      </div>
      
      <div className="map-container relative mb-4 h-64 rounded-lg overflow-hidden">
        <div id="location-selection-map" className="absolute inset-0"></div>
        
        <button
          onClick={handleLocateMe}
          className="absolute bottom-4 right-4 bg-black bg-opacity-70 text-white p-2 rounded-full"
        >
          <MapPinIcon className="w-5 h-5" />
        </button>
      </div>
      
      <div className="flex justify-between mt-4">
        <button
          className="px-4 py-2 bg-gray-700 text-white rounded-lg"
          onClick={() => setStep(1)}
        >
          {t('back')}
        </button>
        
        <button
          className="px-4 py-2 bg-amber-500 text-black font-medium rounded-lg disabled:opacity-50"
          onClick={handleStartSubmission}
          disabled={!poiName || !selectedLocation || isSubmitting}
        >
          {isSubmitting ? t('submitting') : t('continue')}
        </button>
      </div>
    </div>
  );
  
  // Renderiza etapa de detalhes do POI
  const renderPoiDetails = () => (
    <div className="poi-details">
      <h2 className="text-xl font-bold mb-4 text-amber-500">
        {t('enterPoiDetails')} - {poiTypes.find(t => t.id === selectedType)?.name}
      </h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">{t('address')} *</label>
          <input
            type="text"
            className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
            value={poiAddress}
            onChange={(e) => setPoiAddress(e.target.value)}
            placeholder={t('enterAddress')}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">{t('description')}</label>
          <textarea
            className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
            value={poiDescription}
            onChange={(e) => setPoiDescription(e.target.value)}
            placeholder={t('enterDescription')}
            rows={3}
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">{t('phone')}</label>
            <input
              type="text"
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
              value={poiPhone}
              onChange={(e) => setPoiPhone(e.target.value)}
              placeholder={t('enterPhoneNumber')}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">{t('operatingHours')}</label>
            <input
              type="text"
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
              value={operatingHours}
              onChange={(e) => setOperatingHours(e.target.value)}
              placeholder={t('enterHours')}
            />
          </div>
        </div>
        
        {/* Campos específicos para serviços de documentos */}
        {selectedType === 'DOCUMENT_SERVICE' && (
          <div>
            <label className="block text-sm font-medium mb-1">{t('availableServices')} *</label>
            <div className="grid grid-cols-2 gap-2">
              {documentServiceOptions.map(service => (
                <label key={service.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={documentServices.includes(service.id)}
                    onChange={() => handleDocumentServiceChange(service.id)}
                    className="form-checkbox h-4 w-4 text-amber-500"
                  />
                  <span>{service.name}</span>
                </label>
              ))}
            </div>
          </div>
        )}
        
        {/* Campos específicos para balanças */}
        {selectedType === 'CERTIFIED_SCALE' && (
          <>
            <div>
              <label className="block text-sm font-medium mb-1">{t('scaleType')}</label>
              <select
                className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
                value={scaleType}
                onChange={(e) => setScaleType(e.target.value)}
              >
                {scaleTypeOptions.map(option => (
                  <option key={option.id} value={option.id}>
                    {option.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">{t('scalePrice')}</label>
                <input
                  type="number"
                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
                  value={scalePrice}
                  onChange={(e) => setScalePrice(e.target.value)}
                  placeholder={t('enterPrice')}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">{t('maxWeight')}</label>
                <input
                  type="number"
                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg"
                  value={maxWeight}
                  onChange={(e) => setMaxWeight(e.target.value)}
                  placeholder={t('enterMaxWeight')}
                />
              </div>
            </div>
            
            <div className="flex space-x-6">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={isOpen24h}
                  onChange={() => setIsOpen24h(!isOpen24h)}
                  className="form-checkbox h-4 w-4 text-amber-500"
                />
                <span>{t('open24Hours')}</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={providesOfficialCertificate}
                  onChange={() => setProvidesOfficialCertificate(!providesOfficialCertificate)}
                  className="form-checkbox h-4 w-4 text-amber-500"
                />
                <span>{t('providesOfficialCertificate')}</span>
              </label>
            </div>
          </>
        )}
        
        {/* Fotos */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-sm font-medium">{t('photos')}</label>
            <button
              type="button"
              onClick={handleTakePhoto}
              className="text-amber-500 flex items-center"
              disabled={!submissionId}
            >
              <CameraIcon className="w-5 h-5 mr-1" />
              {t('takePhoto')}
            </button>
          </div>
          
          {photos.length > 0 && (
            <div className="photo-preview-grid grid grid-cols-4 gap-2">
              {photos.map((photo, index) => (
                <div key={index} className="photo-thumbnail h-16 bg-gray-700 rounded overflow-hidden">
                  <img src={photo} alt={`POI ${index + 1}`} className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="flex justify-between mt-6">
          <button
            className="px-4 py-2 bg-gray-700 text-white rounded-lg"
            onClick={() => setStep(2)}
          >
            {t('back')}
          </button>
          
          <button
            className="px-4 py-2 bg-amber-500 text-black font-medium rounded-lg disabled:opacity-50"
            onClick={handleCompleteSubmission}
            disabled={!poiAddress || isSubmitting}
          >
            {isSubmitting ? t('submitting') : t('submit')}
          </button>
        </div>
      </div>
    </div>
  );
  
  // Renderiza tela de sucesso
  const renderSuccessScreen = () => (
    <div className="success-screen text-center">
      <div className="success-icon text-green-500 text-6xl mb-4">✓</div>
      <h2 className="text-xl font-bold mb-2 text-white">{t('thankYou')}</h2>
      <p className="mb-6 text-gray-300">{t('poiSubmissionSuccessMessage')}</p>
      
      <button
        className="px-4 py-2 bg-amber-500 text-black font-medium rounded-lg"
        onClick={onClose}
      >
        {t('done')}
      </button>
    </div>
  );
  
  return (
    <div className="user-poi-submission-form bg-black text-white p-6 rounded-lg max-w-lg mx-auto">
      {renderFormByStep()}
    </div>
  );
};

export default UserPoiSubmissionForm;