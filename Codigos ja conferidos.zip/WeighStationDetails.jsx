// WeighStationDetails.jsx
import React from 'react';
import { ChevronRight, Navigation, MessageSquare } from 'lucide-react';
import { getWeighStationStatusColor } from '../utils/uiHelpers';
import { inspectionHistory } from '../data/poiData';

const WeighStationDetails = ({ station, onBack, onStatusReport }) => {
  if (!station) return null;
  
  return (
    <div className="bg-stone-900 rounded-lg overflow-hidden h-full flex flex-col">
      <div className="bg-stone-800 px-4 py-3 flex justify-between items-center">
        <button 
          className="text-white p-1"
          onClick={onBack}
        >
          <ChevronRight className="transform rotate-180" size={24} />
        </button>
        <h2 className="text-white font-bold">{station.name}</h2>
        <div className="w-8"></div>
      </div>
      
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Status atual */}
        <div className="text-center py-2">
          <div className={`inline-block px-4 py-2 rounded-md text-lg font-bold ${getWeighStationStatusColor(station.status)}`}>
            {station.status === 'open' ? 'ABERTA' : 
             station.status === 'monitored' ? 'MONITORADA' : 'FECHADA'}
          </div>
          <div className="text-stone-400 text-sm mt-1">
            Atualizado {station.lastUpdate} • {station.reports} motoristas
          </div>
        </div>
        
        {/* Informações */}
        <div className="bg-stone-800 rounded-lg p-3">
          <h3 className="text-amber-300 font-bold mb-2">Informações</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-stone-300">Rodovia:</span>
              <span className="text-white">{station.highway}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-300">Distância:</span>
              <span className="text-white">{station.distance} km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-300">Direção:</span>
              <span className="text-white">{station.highway} Sul</span>
            </div>
          </div>
        </div>
        
        {/* Histórico de inspeção */}
        <div className="bg-stone-800 rounded-lg p-3">
          <h3 className="text-amber-300 font-bold mb-2">Histórico de Inspeção</h3>
          <div className="space-y-1">
            {inspectionHistory.slice(0, 4).map((record, idx) => (
              <div key={idx} className="flex justify-between py-1 border-b border-stone-700 text-sm">
                <div className="text-stone-300">{record.time} • {record.date}</div>
                <div className={`px-2 rounded text-xs ${
                  record.status.includes('NO') ? 'bg-emerald-900 text-emerald-300' :
                  'bg-red-900 text-red-300'
                }`}>
                  {record.status.includes('NO') ? 'SEM INSPEÇÃO' : 'INSPEÇÃO ATIVA'}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Perguntas para reportar status */}
        <div className="bg-stone-800 rounded-lg p-3">
          <h3 className="text-amber-300 font-bold mb-4">Como está a balança?</h3>
          <div className="grid grid-cols-3 gap-2">
            <button 
              onClick={() => onStatusReport('open')}
              className="bg-emerald-700/40 hover:bg-emerald-700/60 border-2 border-emerald-700 text-white py-2 rounded-lg"
            >
              Aberta
            </button>
            <button 
              onClick={() => onStatusReport('monitored')}
              className="bg-amber-700/40 hover:bg-amber-700/60 border-2 border-amber-700 text-white py-2 rounded-lg"
            >
              Monitorada
            </button>
            <button 
              onClick={() => onStatusReport('closed')}
              className="bg-red-700/40 hover:bg-red-700/60 border-2 border-red-700 text-white py-2 rounded-lg"
            >
              Fechada
            </button>
          </div>
        </div>
        
        {/* Botões de navegação */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button className="bg-stone-700 hover:bg-stone-600 text-white py-3 rounded-lg flex items-center justify-center">
            <Navigation className="mr-2" size={18} />
            Navegar
          </button>
          <button className="bg-amber-600 hover:bg-amber-500 text-white py-3 rounded-lg flex items-center justify-center">
            <MessageSquare className="mr-2" size={18} />
            Chat
          </button>
        </div>
      </div>
    </div>
  );
};

export default WeighStationDetails;