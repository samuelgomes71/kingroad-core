package com.kingroad.cache

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.*
import com.kingroad.network.ApiClient
import com.kingroad.network.ApiResult
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.collections.HashMap

/**
 * Observa eventos no banco local e envia automaticamente para o backend via API ou Firebase
 * (ex: alerta enviado, POI criado)
 */
class RealtimeSyncService(
    private val context: Context,
    private val poiDao: POIDao,
    private val alertDao: AlertDao,
    private val feedbackDao: FeedbackDao,
    private val userDao: UserDao,
    private val apiClient: ApiClient,
    private val localSyncQueue: LocalSyncQueue? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "RealtimeSyncService"
        
        // Tipos de entidade monitorados
        enum class EntityType {
            POI,
            ALERT,
            FEEDBACK,
            USER_LOCATION
        }
        
        // Status da sincronização
        enum class SyncStatus {
            IDLE,
            SYNCING,
            ERROR,
            OFFLINE
        }
        
        // Modos de sincronização
        enum class SyncMode {
            REALTIME,      // Sincroniza em tempo real quando há alterações
            BATCH,         // Sincroniza em lotes periodicamente
            MANUAL,        // Sincroniza somente quando solicitado
            BACKGROUND     // Sincroniza em segundo plano quando o app não está em uso
        }
        
        // Prioridades de entidades para sincronização
        private val ENTITY_PRIORITY = mapOf(
            EntityType.ALERT to 10,        // Alertas têm maior prioridade
            EntityType.USER_LOCATION to 5, // Localização do usuário é importante para tempo real
            EntityType.POI to 3,           // POIs são importantes mas não críticos
            EntityType.FEEDBACK to 1       // Feedback pode ser enviado depois
        )
        
        // Intervalos de batch sync por tipo (em milissegundos)
        private val BATCH_SYNC_INTERVALS = mapOf(
            EntityType.ALERT to 30_000L,       // 30 segundos para alertas
            EntityType.USER_LOCATION to 60_000L, // 1 minuto para localização
            EntityType.POI to 5 * 60_000L,     // 5 minutos para POIs
            EntityType.FEEDBACK to 15 * 60_000L // 15 minutos para feedbacks
        )
    }

    // Status atual da sincronização
    private val _syncStatus = MutableStateFlow(SyncStatus.IDLE)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()
    
    // Modo de sincronização atual
    private var _syncMode = MutableStateFlow(SyncMode.REALTIME)
    val syncMode: StateFlow<SyncMode> = _syncMode.asStateFlow()
    
    // Estatísticas de sincronização
    private val _syncStats = MutableLiveData(SyncStats())
    val syncStats: LiveData<SyncStats> = _syncStats
    
    // Flags para controlar sincronização de cada tipo
    private val syncInProgress = HashMap<EntityType, AtomicBoolean>().apply {
        EntityType.values().forEach {
            put(it, AtomicBoolean(false))
        }
    }
    
    // Jobs para sincronização periódica
    private val batchSyncJobs = HashMap<EntityType, Job?>().apply {
        EntityType.values().forEach {
            put(it, null)
        }
    }
    
    // NetworkCallback para monitorar conectividade
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    
    // Observadores de banco de dados
    private var dbObservers = HashMap<EntityType, Job?>()
    
    // Status de conectividade
    private var isConnected = NetworkUtils.isConnected(context)
    
    init {
        // Registra callback de rede
        registerNetworkCallback()
        
        // Inicia observadores de banco de dados
        startDatabaseObservers()
        
        // Inicia jobs de sincronização em batch se necessário
        if (_syncMode.value == SyncMode.BATCH) {
            startBatchSyncJobs()
        }
    }

    /**
     * Define o modo de sincronização
     */
    fun setSyncMode(mode: SyncMode) {
        if (_syncMode.value == mode) return
        
        // Cancela jobs existentes antes de mudar o modo
        cancelAllJobs()
        
        _syncMode.value = mode
        
        // Configura jobs de acordo com o novo modo
        when (mode) {
            SyncMode.REALTIME -> {
                startDatabaseObservers()
            }
            SyncMode.BATCH -> {
                startBatchSyncJobs()
            }
            SyncMode.MANUAL -> {
                // Não faz nada, sincronização só acontecerá quando solicitada
            }
            SyncMode.BACKGROUND -> {
                // Similar ao batch, mas com intervalos maiores e condições especiais
                startBackgroundSyncJobs()
            }
        }
    }
    
    /**
     * Inicia sincronização manual para um tipo específico
     */
    fun startSync(entityType: EntityType): Job {
        return scope.launch {
            syncEntityType(entityType)
        }
    }
    
    /**
     * Inicia sincronização manual para todos os tipos de entidade
     */
    fun syncAll(): Job {
        return scope.launch {
            _syncStatus.value = SyncStatus.SYNCING
            
            try {
                // Sincroniza cada tipo de entidade em ordem de prioridade
                EntityType.values()
                    .sortedByDescending { ENTITY_PRIORITY[it] ?: 0 }
                    .forEach { entityType ->
                        try {
                            syncEntityType(entityType)
                        } catch (e: Exception) {
                            Log.e(TAG, "Erro ao sincronizar ${entityType.name}: ${e.message}", e)
                        }
                    }
                
                _syncStatus.value = SyncStatus.IDLE
            } catch (e: Exception) {
                Log.e(TAG, "Erro na sincronização geral: ${e.message}", e)
                _syncStatus.value = SyncStatus.ERROR
            }
        }
    }
    
    /**
     * Força sincronização imediata de todas as entidades, independente do modo atual
     */
    fun forceSyncAll(): Job {
        return scope.launch {
            // Salva o modo atual e restaura depois
            val originalMode = _syncMode.value
            
            try {
                // Define modo como manual temporariamente
                _syncMode.value = SyncMode.MANUAL
                
                // Sincroniza todas as entidades
                syncAll().join()
            } finally {
                // Restaura o modo original
                setSyncMode(originalMode)
            }
        }
    }
    
    /**
     * Sincroniza um tipo específico de entidade
     */
    private suspend fun syncEntityType(entityType: EntityType) {
        // Verifica se já está sincronizando este tipo
        if (syncInProgress[entityType]?.getAndSet(true) == true) {
            Log.d(TAG, "Sincronização de ${entityType.name} já em andamento. Ignorando.")
            return
        }
        
        try {
            // Verifica se há conexão
            if (!isConnected) {
                _syncStatus.value = SyncStatus.OFFLINE
                Log.d(TAG, "Sem conexão. Sincronização de ${entityType.name} adiada.")
                
                // Verifica se podemos enfileirar em vez de falhar
                if (localSyncQueue != null) {
                    enqueueForOfflineSync(entityType)
                }
                
                return
            }
            
            _syncStatus.value = SyncStatus.SYNCING
            
            // Realiza a sincronização de acordo com o tipo
            val syncedCount = when (entityType) {
                EntityType.POI -> syncPOIs()
                EntityType.ALERT -> syncAlerts()
                EntityType.FEEDBACK -> syncFeedbacks()
                EntityType.USER_LOCATION -> syncUserLocation()
            }
            
            // Atualiza estatísticas
            updateSyncStats(entityType, syncedCount)
            
            _syncStatus.value = SyncStatus.IDLE
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar ${entityType.name}: ${e.message}", e)
            _syncStatus.value = SyncStatus.ERROR
        } finally {
            syncInProgress[entityType]?.set(false)
        }
    }
    
    /**
     * Sincroniza POIs não enviados
     */
    private suspend fun syncPOIs(): Int = withContext(dispatcher) {
        val unsyncedPOIs = poiDao.getUnsyncedPOIs()
        Log.d(TAG, "Sincronizando ${unsyncedPOIs.size} POIs")
        
        var successCount = 0
        
        for (poi in unsyncedPOIs) {
            try {
                // Converte para formato de API
                val poiData = convertPOItoApiFormat(poi)
                
                // Envia para a API
                val result = when {
                    poi.isUpdate -> apiClient.updatePOI(poi.id, poiData)
                    else -> apiClient.createPOI(poiData)
                }
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        // Atualiza status no banco de dados
                        val updatedPoi = poi.copy(
                            synced = true,
                            syncTimestamp = System.currentTimeMillis(),
                            serverRef = result.data.optString("id", poi.id)
                        )
                        poiDao.update(updatedPoi)
                        successCount++
                    }
                    is ApiResult.Error -> {
                        Log.e(TAG, "Erro ao sincronizar POI ${poi.id}: ${result.message}")
                        // Incrementa contagem de tentativas
                        val updatedPoi = poi.copy(
                            syncAttempts = poi.syncAttempts + 1,
                            lastSyncAttempt = System.currentTimeMillis()
                        )
                        poiDao.update(updatedPoi)
                        
                        // Enfileira para retry se falhou muitas vezes
                        if (updatedPoi.syncAttempts >= 3 && localSyncQueue != null) {
                            enqueuePOIForOfflineSync(updatedPoi)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exceção ao sincronizar POI ${poi.id}: ${e.message}", e)
            }
        }
        
        return@withContext successCount
    }
    
    /**
     * Sincroniza alertas não enviados
     */
    private suspend fun syncAlerts(): Int = withContext(dispatcher) {
        val unsyncedAlerts = alertDao.getUnsyncedAlerts()
        Log.d(TAG, "Sincronizando ${unsyncedAlerts.size} alertas")
        
        var successCount = 0
        
        for (alert in unsyncedAlerts) {
            try {
                // Converte para formato de API
                val alertData = convertAlertToApiFormat(alert)
                
                // Envia para a API
                val result = when {
                    alert.isUpdate -> apiClient.updateAlert(alert.id, alertData)
                    else -> apiClient.createAlert(alertData)
                }
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        // Atualiza status no banco de dados
                        val updatedAlert = alert.copy(
                            synced = true,
                            syncTimestamp = System.currentTimeMillis(),
                            serverRef = result.data.optString("id", alert.id)
                        )
                        alertDao.update(updatedAlert)
                        successCount++
                    }
                    is ApiResult.Error -> {
                        Log.e(TAG, "Erro ao sincronizar alerta ${alert.id}: ${result.message}")
                        // Incrementa contagem de tentativas
                        val updatedAlert = alert.copy(
                            syncAttempts = alert.syncAttempts + 1,
                            lastSyncAttempt = System.currentTimeMillis()
                        )
                        alertDao.update(updatedAlert)
                        
                        // Enfileira para retry se falhou muitas vezes
                        if (updatedAlert.syncAttempts >= 3 && localSyncQueue != null) {
                            enqueueAlertForOfflineSync(updatedAlert)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exceção ao sincronizar alerta ${alert.id}: ${e.message}", e)
            }
        }
        
        return@withContext successCount
    }
    
    /**
     * Sincroniza feedbacks não enviados
     */
    private suspend fun syncFeedbacks(): Int = withContext(dispatcher) {
        val unsyncedFeedbacks = feedbackDao.getUnsyncedFeedbacks()
        Log.d(TAG, "Sincronizando ${unsyncedFeedbacks.size} feedbacks")
        
        var successCount = 0
        
        for (feedback in unsyncedFeedbacks) {
            try {
                // Converte para formato de API
                val feedbackData = convertFeedbackToApiFormat(feedback)
                
                // Envia para a API
                val result = apiClient.submitFeedback(feedbackData)
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        // Atualiza status no banco de dados
                        val updatedFeedback = feedback.copy(
                            synced = true,
                            syncTimestamp = System.currentTimeMillis(),
                            serverRef = result.data.optString("id", feedback.id)
                        )
                        feedbackDao.update(updatedFeedback)
                        successCount++
                    }
                    is ApiResult.Error -> {
                        Log.e(TAG, "Erro ao sincronizar feedback ${feedback.id}: ${result.message}")
                        // Incrementa contagem de tentativas
                        val updatedFeedback = feedback.copy(
                            syncAttempts = feedback.syncAttempts + 1,
                            lastSyncAttempt = System.currentTimeMillis()
                        )
                        feedbackDao.update(updatedFeedback)
                        
                        // Enfileira para retry se falhou muitas vezes
                        if (updatedFeedback.syncAttempts >= 3 && localSyncQueue != null) {
                            enqueueFeedbackForOfflineSync(updatedFeedback)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exceção ao sincronizar feedback ${feedback.id}: ${e.message}", e)
            }
        }
        
        return@withContext successCount
    }
    
    /**
     * Sincroniza localização do usuário
     */
    private suspend fun syncUserLocation(): Int = withContext(dispatcher) {
        val userLocation = userDao.getUserLocation() ?: return@withContext 0
        
        // Verifica se a localização precisa ser sincronizada
        if (userLocation.synced) {
            return@withContext 0
        }
        
        var successCount = 0
        
        try {
            // Converte para formato de API
            val locationData = JSONObject().apply {
                put("userId", userLocation.userId)
                put("latitude", userLocation.latitude)
                put("longitude", userLocation.longitude)
                put("speed", userLocation.speed)
                put("bearing", userLocation.bearing)
                put("altitude", userLocation.altitude)
                put("accuracy", userLocation.accuracy)
                put("timestamp", userLocation.timestamp)
            }
            
            // Envia para a API
            val result = apiClient.updateUserLocation(locationData)
            
            // Processa resultado
            when (result) {
                is ApiResult.Success -> {
                    // Atualiza status no banco de dados
                    val updatedLocation = userLocation.copy(
                        synced = true,
                        syncTimestamp = System.currentTimeMillis()
                    )
                    userDao.updateUserLocation(updatedLocation)
                    successCount++
                }
                is ApiResult.Error -> {
                    Log.e(TAG, "Erro ao sincronizar localização: ${result.message}")
                    // Não precisamos incrementar tentativas para localização, 
                    // pois geralmente será atualizada em breve
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao sincronizar localização: ${e.message}", e)
        }
        
        return@withContext successCount
    }
    
    /**
     * Converte um POI para o formato da API
     */
    private fun convertPOItoApiFormat(poi: POI): JSONObject {
        return JSONObject().apply {
            put("id", poi.id)
            put("name", poi.name)
            put("type", poi.type)
            put("latitude", poi.latitude)
            put("longitude", poi.longitude)
            put("description", poi.description ?: "")
            put("createdAt", poi.createdAt)
            put("updatedAt", poi.updatedAt ?: poi.createdAt)
            put("createdBy", poi.createdBy ?: "")
            put("isVerified", poi.isVerified)
            
            // Adiciona metadados se existirem
            if (!poi.metadata.isNullOrEmpty()) {
                try {
                    put("metadata", JSONObject(poi.metadata))
                } catch (e: Exception) {
                    put("metadata", JSONObject())
                }
            } else {
                put("metadata", JSONObject())
            }
        }
    }
    
    /**
     * Converte um alerta para o formato da API
     */
    private fun convertAlertToApiFormat(alert: Alert): JSONObject {
        return JSONObject().apply {
            put("id", alert.id)
            put("type", alert.type)
            put("latitude", alert.latitude)
            put("longitude", alert.longitude)
            put("description", alert.description ?: "")
            put("createdAt", alert.createdAt)
            put("expiresAt", alert.expiresAt ?: (alert.createdAt + 3600000)) // Default 1h
            put("severity", alert.severity ?: 2) // 1-5, default medium
            put("createdBy", alert.createdBy ?: "")
            put("direction", alert.direction ?: -1) // -1 = all directions
            
            // Adiciona metadados se existirem
            if (!alert.metadata.isNullOrEmpty()) {
                try {
                    put("metadata", JSONObject(alert.metadata))
                } catch (e: Exception) {
                    put("metadata", JSONObject())
                }
            } else {
                put("metadata", JSONObject())
            }
        }
    }
    
    /**
     * Converte um feedback para o formato da API
     */
    private fun convertFeedbackToApiFormat(feedback: Feedback): JSONObject {
        return JSONObject().apply {
            put("id", feedback.id)
            put("type", feedback.type)
            put("content", feedback.content)
            put("rating", feedback.rating ?: 0)
            put("latitude", feedback.latitude)
            put("longitude", feedback.longitude)
            put("createdAt", feedback.createdAt)
            put("createdBy", feedback.createdBy ?: "")
            put("referenceId", feedback.referenceId ?: "")
            put("referenceType", feedback.referenceType ?: "")
            
            // Adiciona metadados se existirem
            if (!feedback.metadata.isNullOrEmpty()) {
                try {
                    put("metadata", JSONObject(feedback.metadata))
                } catch (e: Exception) {
                    put("metadata", JSONObject())
                }
            } else {
                put("metadata", JSONObject())
            }
        }
    }
    
    /**
     * Enfileira um POI para sincronização offline
     */
    private suspend fun enqueuePOIForOfflineSync(poi: POI) {
        if (localSyncQueue == null) return
        
        try {
            val poiData = convertPOItoApiFormat(poi)
            localSyncQueue.enqueueItem(
                type = LocalSyncQueue.TYPE_POI,
                data = poiData,
                priority = ENTITY_PRIORITY[EntityType.POI] ?: 0
            )
            
            // Atualiza o POI para indicar que está na fila
            val updatedPoi = poi.copy(
                syncAttempts = 0, // Reset attempts count
                queuedForSync = true
            )
            poiDao.update(updatedPoi)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enfileirar POI para sincronização offline: ${e.message}", e)
        }
    }
    
    /**
     * Enfileira um alerta para sincronização offline
     */
    private suspend fun enqueueAlertForOfflineSync(alert: Alert) {
        if (localSyncQueue == null) return
        
        try {
            val alertData = convertAlertToApiFormat(alert)
            localSyncQueue.enqueueItem(
                type = LocalSyncQueue.TYPE_ALERT,
                data = alertData,
                priority = ENTITY_PRIORITY[EntityType.ALERT] ?: 0
            )
            
            // Atualiza o alerta para indicar que está na fila
            val updatedAlert = alert.copy(
                syncAttempts = 0, // Reset attempts count
                queuedForSync = true
            )
            alertDao.update(updatedAlert)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enfileirar alerta para sincronização offline: ${e.message}", e)
        }
    }
    
    /**
     * Enfileira um feedback para sincronização offline
     */
    private suspend fun enqueueFeedbackForOfflineSync(feedback: Feedback) {
        if (localSyncQueue == null) return
        
        try {
            val feedbackData = convertFeedbackToApiFormat(feedback)
            localSyncQueue.enqueueItem(
                type = LocalSyncQueue.TYPE_FEEDBACK,
                data = feedbackData,
                priority = ENTITY_PRIORITY[EntityType.FEEDBACK] ?: 0
            )
            
            // Atualiza o feedback para indicar que está na fila
            val updatedFeedback = feedback.copy(
                syncAttempts = 0, // Reset attempts count
                queuedForSync = true
            )
            feedbackDao.update(updatedFeedback)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enfileirar feedback para sincronização offline: ${e.message}", e)
        }
    }
    
    /**
     * Enfileira entidades para sincronização offline quando não há conexão
     */
    private suspend fun enqueueForOfflineSync(entityType: EntityType) {
        if (localSyncQueue == null) return
        
        when (entityType) {
            EntityType.POI -> {
                val unsyncedPOIs = poiDao.getUnsyncedPOIs()
                for (poi in unsyncedPOIs) {
                    if (!poi.queuedForSync) {
                        enqueuePOIForOfflineSync(poi)
                    }
                }
            }
            EntityType.ALERT -> {
                val unsyncedAlerts = alertDao.getUnsyncedAlerts()
                for (alert in unsyncedAlerts) {
                    if (!alert.queuedForSync) {
                        enqueueAlertForOfflineSync(alert)
                    }
                }
            }
            EntityType.FEEDBACK -> {
                val unsyncedFeedbacks = feedbackDao.getUnsyncedFeedbacks()
                for (feedback in unsyncedFeedbacks) {
                    if (!feedback.queuedForSync) {
                        enqueueFeedbackForOfflineSync(feedback)
                    }
                }
            }
            EntityType.USER_LOCATION -> {
                // Localização não precisa ser enfileirada, será atualizada em breve
            }
        }
    }
    
    /**
     * Atualiza estatísticas de sincronização
     */
    private fun updateSyncStats(entityType: EntityType, syncedCount: Int) {
        val currentStats = _syncStats.value ?: SyncStats()
        
        val updatedStats = when (entityType) {
            EntityType.POI -> currentStats.copy(
                poisSynced = currentStats.poisSynced + syncedCount,
                lastPOISyncTime = if (syncedCount > 0) System.currentTimeMillis() else currentStats.lastPOISyncTime
            )
            EntityType.ALERT -> currentStats.copy(
                alertsSynced = currentStats.alertsSynced + syncedCount,
                lastAlertSyncTime = if (syncedCount > 0) System.currentTimeMillis() else currentStats.lastAlertSyncTime
            )
            EntityType.FEEDBACK -> currentStats.copy(
                feedbacksSynced = currentStats.feedbacksSynced + syncedCount,
                lastFeedbackSyncTime = if (syncedCount > 0) System.currentTimeMillis() else currentStats.lastFeedbackSyncTime
            )
            EntityType.USER_LOCATION -> currentStats.copy(
                locationsSynced = currentStats.locationsSynced + syncedCount,
                lastLocationSyncTime = if (syncedCount > 0) System.currentTimeMillis() else currentStats.lastLocationSyncTime
            )
        }
        
        _syncStats.postValue(updatedStats.copy(
            totalSynced = updatedStats.poisSynced + updatedStats.alertsSynced + 
                    updatedStats.feedbacksSynced + updatedStats.locationsSynced,
            lastSyncTime = System.currentTimeMillis()
        ))
    }
    
    /**
     * Inicia observadores de banco de dados para sincronização em tempo real
     */
    private fun startDatabaseObservers() {
        // Cancela observadores existentes primeiro
        stopDatabaseObservers()
        
        // Observe POIs
        dbObservers[EntityType.POI] = scope.launch {
            try {
                poiDao.getUnsyncedPOIsFlow().collect { unsyncedPois ->
                    if (unsyncedPois.isNotEmpty() && _syncMode.value == SyncMode.REALTIME) {
                        syncEntityType(EntityType.POI)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro no observador de POIs: ${e.message}", e)
            }
        }
        
        // Observe Alertas
        dbObservers[EntityType.ALERT] = scope.launch {
            try {
                alertDao.getUnsyncedAlertsFlow().collect { unsyncedAlerts ->
                    if (unsyncedAlerts.isNotEmpty() && _syncMode.value == SyncMode.REALTIME) {
                        syncEntityType(EntityType.ALERT)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro no observador de Alertas: ${e.message}", e)
            }
        }
        
        // Observe Feedbacks
        dbObservers[EntityType.FEEDBACK] = scope.launch {
            try {
                feedbackDao.getUnsyncedFeedbacksFlow().collect { unsyncedFeedbacks ->
                    if (unsyncedFeedbacks.isNotEmpty() && _syncMode.value == SyncMode.REALTIME) {
                        syncEntityType(EntityType.FEEDBACK)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro no observador de Feedbacks: ${e.message}", e)
            }
        }
        
        // Observe Localização do Usuário
        dbObservers[EntityType.USER_LOCATION] = scope.launch {
            try {
                userDao.getUserLocationFlow().collect { userLocation ->
                    if (userLocation != null && !userLocation.synced && _syncMode.value == SyncMode.REALTIME) {
                        syncEntityType(EntityType.USER_LOCATION)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro no observador de Localização: ${e.message}", e)
            }
        }
    }
    
    /**
     * Para observadores de banco de dados
     */
    private fun stopDatabaseObservers() {
        dbObservers.forEach { (_, job) ->
            job?.cancel()
        }
        dbObservers.clear()
    }
    
    /**
     * Inicia jobs de sincronização em batch
     */
    private fun startBatchSyncJobs() {
        // Cancela jobs existentes primeiro
        cancelBatchSyncJobs()
        
        // Cria jobs para cada tipo de entidade com intervalos diferentes
        EntityType.values().forEach { entityType ->
            val interval = BATCH_SYNC_INTERVALS[entityType] ?: 5 * 60_000L // Default 5 minutos
            
            batchSyncJobs[entityType] = scope.launch {
                while (isActive) {
                    try {
                        syncEntityType(entityType)
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro no batch sync de ${entityType.name}: ${e.message}", e)
                    }
                    
                    delay(interval)
                }
            }
        }
    }
    
    /**
     * Inicia jobs de sincronização em background (intervalos maiores)
     */
    private fun startBackgroundSyncJobs() {
        // Cancela jobs existentes primeiro
        cancelBatchSyncJobs()
        
        // Cria jobs para cada tipo de entidade com intervalos maiores
        EntityType.values().forEach { entityType ->
            // No modo background, os intervalos são 3x maiores que no modo batch
            val interval = (BATCH_SYNC_INTERVALS[entityType] ?: 5 * 60_000L) * 3
            
            batchSyncJobs[entityType] = scope.launch {
                while (isActive) {
                    try {
                        // Sincroniza apenas se houver itens suficientes ou o intervalo for grande
                        val shouldSync = when (entityType) {
                            EntityType.POI -> poiDao.getUnsyncedPOIsCount() > 5
                            EntityType.ALERT -> alertDao.getUnsyncedAlertsCount() > 0 // Sempre sincronizar alertas
                            EntityType.FEEDBACK -> feedbackDao.getUnsyncedFeedbacksCount() > 10
                            EntityType.USER_LOCATION -> false // Não sincronizar localização em background
                        }
                        
                        if (shouldSync) {
                            syncEntityType(entityType)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro no background sync de ${entityType.name}: ${e.message}", e)
                    }
                    
                    delay(interval)
                }
            }
        }
    }
    
    /**
     * Cancela jobs de sincronização em batch
     */
    private fun cancelBatchSyncJobs() {
        batchSyncJobs.forEach { (_, job) ->
            job?.cancel()
        }
        
        batchSyncJobs.keys.forEach { type ->
            batchSyncJobs[type] = null
        }
    }
    
    /**
     * Registra callback para monitorar alterações na rede
     */
    private fun registerNetworkCallback() {
        try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            
            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    onNetworkAvailable()
                }
                
                override fun onLost(network: Network) {
                    onNetworkLost()
                }
                
                override fun onCapabilitiesChanged(
                    network: Network,
                    networkCapabilities: NetworkCapabilities
                ) {
                    val connected = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    
                    if (connected && !isConnected) {
                        onNetworkAvailable()
                    } else if (!connected && isConnected) {
                        onNetworkLost()
                    }
                }
            }
            
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            
            connectivityManager.registerNetworkCallback(request, networkCallback!!)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao registrar network callback: ${e.message}", e)
        }
    }
    
    /**
     * Chamado quando o dispositivo se conecta à rede
     */
    private fun onNetworkAvailable() {
        isConnected = true
        
        if (_syncStatus.value == SyncStatus.OFFLINE) {
            _syncStatus.value = SyncStatus.IDLE
        }
        
        // Inicia sincronização de itens pendentes
        when (_syncMode.value) {
            SyncMode.REALTIME -> {
                // Em modo realtime, inicia sincronização de todos os tipos
                scope.launch {
                    EntityType.values().forEach { type ->
                        launch {
                            syncEntityType(type)
                        }
                    }
                }
            }
            SyncMode.BATCH, SyncMode.BACKGROUND -> {
                // Em modo batch ou background, deixa os jobs programados cuidarem disso
            }
            SyncMode.MANUAL -> {
                // Em modo manual, não faz nada quando a conexão é restaurada
            }
        }
        
        Log.d(TAG, "Rede disponível, modo de sincronização: ${_syncMode.value}")
    }
    
    /**
     * Chamado quando o dispositivo perde a conexão
     */
    private fun onNetworkLost() {
        isConnected = false
        
        if (_syncStatus.value == SyncStatus.SYNCING) {
            _syncStatus.value = SyncStatus.OFFLINE
        }
        
        Log.d(TAG, "Rede indisponível, todas as sincronizações serão pausadas")
    }
    
    /**
     * Cancela todos os jobs e operações em andamento
     */
    private fun cancelAllJobs() {
        stopDatabaseObservers()
        cancelBatchSyncJobs()
    }
    
    /**
     * Libera todos os recursos
     */
    fun shutdown() {
        cancelAllJobs()
        
        try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let {
                connectivityManager.unregisterNetworkCallback(it)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao remover network callback: ${e.message}", e)
        }
        
        scope.cancel()
    }
    
    /**
     * Data class para estatísticas de sincronização
     */
    data class SyncStats(
        val poisSynced: Int = 0,
        val alertsSynced: Int = 0,
        val feedbacksSynced: Int = 0,
        val locationsSynced: Int = 0,
        val totalSynced: Int = 0,
        val lastSyncTime: Long = 0,
        val lastPOISyncTime: Long = 0,
        val lastAlertSyncTime: Long = 0,
        val lastFeedbackSyncTime: Long = 0,
        val lastLocationSyncTime: Long = 0
    )
}