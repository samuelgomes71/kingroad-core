import React, { useState } from 'react';
import { AlertTriangle, MapPin, Send, X, Info, Clock } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const AlertSubmissionScreen = () => {
  const [alertType, setAlertType] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('Usar localização atual');
  const [showSuccess, setShowSuccess] = useState(false);
  
  const alertTypes = [
    { id: 'tiroteio', name: 'Tiroteio', color: 'bg-red-500', icon: <AlertTriangle size={24} /> },
    { id: 'sequestro', name: 'Sequestro', color: 'bg-amber-500', icon: <AlertTriangle size={24} /> },
    { id: 'roubo_carga', name: 'Roubo de Carga', color: 'bg-orange-500', icon: <AlertTriangle size={24} /> },
    { id: 'veiculo_suspeito', name: 'Veículo Suspeito', color: 'bg-yellow-500', icon: <AlertTriangle size={24} /> },
    { id: 'alta_velocidade', name: 'Alta Velocidade', color: 'bg-blue-500', icon: <Clock size={24} /> }
  ];
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Enviando alerta:', { alertType, description, location });
    // Aqui seria feita a integração com o backend
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };
  
  const handleCancel = () => {
    setAlertType('');
    setDescription('');
    setLocation('Usar localização atual');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-md mx-auto bg-gray-800 rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold flex items-center">
            <AlertTriangle size={24} className="text-amber-500 mr-2" />
            Enviar Alerta de Segurança
          </h1>
          <button className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        {showSuccess && (
          <Alert className="mb-4 bg-green-800 border-green-600">
            <div className="flex items-center">
              <Info size={18} className="text-green-400" />
              <AlertTitle className="ml-2">Alerta enviado com sucesso!</AlertTitle>
            </div>
            <AlertDescription className="text-green-200 mt-1">
              Outros motoristas serão notificados sobre este alerta.
            </AlertDescription>
          </Alert>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">Tipo de Alerta</label>
            <div className="grid grid-cols-2 gap-2">
              {alertTypes.map((type) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setAlertType(type.id)}
                  className={`p-3 rounded-lg flex flex-col items-center justify-center ${
                    alertType === type.id 
                      ? `${type.color} text-white` 
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  <div className={`${alertType === type.id ? 'text-white' : 'text-gray-400'}`}>
                    {type.icon}
                  </div>
                  <span className="mt-1 text-sm">{type.name}</span>
                </button>
              ))}
            </div>
            {!alertType && (
              <p className="mt-2 text-red-400 text-sm">Selecione um tipo de alerta</p>
            )}
          </div>
          
          <div className="mb-6">
            <label htmlFor="description" className="block text-gray-300 mb-2">
              Descrição
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              rows="3"
              placeholder="Descreva a situação (opcional)"
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">Localização</label>
            <div className="flex items-center p-3 bg-gray-700 text-white rounded-lg">
              <MapPin size={20} className="text-amber-500 mr-2" />
              <span>{location}</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-8">
            <button
              type="button"
              onClick={handleCancel}
              className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 flex items-center"
            >
              <X size={18} className="mr-1" />
              Cancelar
            </button>
            
            <button
              type="submit"
              disabled={!alertType}
              className={`px-6 py-2 rounded-lg flex items-center ${
                alertType 
                  ? 'bg-amber-600 text-white hover:bg-amber-700' 
                  : 'bg-gray-700 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Send size={18} className="mr-2" />
              Enviar Alerta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AlertSubmissionScreen;