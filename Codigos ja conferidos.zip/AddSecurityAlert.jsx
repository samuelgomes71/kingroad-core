import React, { useState } from 'react';
import { AlertTriangle, Truck, Scissors, Wind, Camera, X, MapPin } from 'lucide-react';

const AddSecurityAlert = ({ onClose, onSubmit, currentLocation }) => {
  const [alertType, setAlertType] = useState('cargo_theft');
  const [description, setDescription] = useState('');
  const [useCurrentLocation, setUseCurrentLocation] = useState(true);
  const [locationName, setLocationName] = useState('');
  const [photos, setPhotos] = useState([]);

  // Definições de tipos de alerta
  const alertTypes = [
    { 
      id: 'cargo_theft', 
      name: 'Roubo de Carga', 
      icon: <Truck size={20} />,
      color: 'bg-red-600'
    },
    { 
      id: 'curtain_cutting', 
      name: 'Corte de Lona', 
      icon: <Scissors size={20} />,
      color: 'bg-amber-600'
    },
    { 
      id: 'gas_attack', 
      name: 'Ataque com Gás Sonífero', 
      icon: <Wind size={20} />,
      color: 'bg-purple-600'
    }
  ];

  // Função para simular adição de foto
  const handleAddPhoto = () => {
    // Em um app real, isso abriria a câmera ou galeria
    // Para demonstração, apenas adicionamos uma foto fictícia
    setPhotos([...photos, { id: Date.now(), url: '/api/placeholder/100/100' }]);
  };

  // Função para remover foto
  const handleRemovePhoto = (photoId) => {
    setPhotos(photos.filter(photo => photo.id !== photoId));
  };

  // Função para enviar o formulário
  const handleSubmit = (e) => {
    e.preventDefault();
    const newAlert = {
      alertType,
      description,
      location: locationName || 'Localização atual',
      coordinates: currentLocation || { lat: 0, lng: 0 },
      timestamp: Date.now(),
      photos: photos.map(p => p.url)
    };
    
    if (typeof onSubmit === 'function') {
      onSubmit(newAlert);
    }
    if (typeof onClose === 'function') {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-900 rounded-lg max-w-md w-full max-h-screen overflow-y-auto">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center sticky top-0 bg-gray-900 z-10">
          <h2 className="text-xl font-bold text-white flex items-center">
            <AlertTriangle className="mr-2 text-yellow-500" size={24} />
            Reportar Alerta de Segurança
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4">
          {/* Tipo de alerta */}
          <div className="mb-6">
            <label className="block text-gray-300 mb-3">Tipo de Alerta:</label>
            <div className="grid grid-cols-3 gap-2">
              {alertTypes.map(type => (
                <button
                  key={type.id}
                  type="button"
                  className={`p-3 rounded-lg border flex flex-col items-center justify-center text-center h-24 ${
                    alertType === type.id 
                      ? `${type.color} border-opacity-0 text-white` 
                      : 'border-gray-700 text-gray-400 hover:border-gray-500'
                  }`}
                  onClick={() => setAlertType(type.id)}
                >
                  {type.icon}
                  <span className="mt-2 text-sm">{type.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          {/* Localização */}
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">Localização:</label>
            <div className="flex items-center mb-3">
              <input
                type="checkbox"
                id="useCurrentLocation"
                checked={useCurrentLocation}
                onChange={() => setUseCurrentLocation(!useCurrentLocation)}
                className="mr-2"
              />
              <label htmlFor="useCurrentLocation" className="text-gray-300 text-sm">
                Usar minha localização atual
              </label>
            </div>
            
            {!useCurrentLocation && (
              <div className="flex items-center border border-gray-700 rounded-lg overflow-hidden bg-gray-800">
                <span className="px-3 text-gray-500">
                  <MapPin size={18} />
                </span>
                <input
                  type="text"
                  placeholder="Descreva o local (ex: Posto Shell na A1)"
                  className="bg-transparent border-none w-full p-3 text-white placeholder-gray-500 focus:outline-none"
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                />
              </div>
            )}
            
            {useCurrentLocation && (
              <div className="bg-gray-800 p-3 rounded-lg border border-gray-700 text-gray-300 flex items-center">
                <MapPin size={18} className="mr-2 text-blue-500" />
                <span className="text-sm">
                  Usando sua localização atual: <br />
                  {currentLocation 
                    ? `${currentLocation.lat?.toFixed(4) || 'N/A'}, ${currentLocation.lng?.toFixed(4) || 'N/A'}` 
                    : 'Obtendo localização...'}
                </span>
              </div>
            )}
          </div>
          
          {/* Descrição */}
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">Descrição do Incidente:</label>
            <textarea
              className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 min-h-32"
              placeholder="Descreva o que aconteceu, como ocorreu o roubo/incidente e qualquer detalhe importante para outros motoristas."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>
          
          {/* Fotos */}
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">Adicionar Fotos (opcional):</label>
            <div className="flex flex-wrap gap-2">
              {photos.map(photo => (
                <div key={photo.id} className="relative w-20 h-20">
                  <img src={photo.url} alt="Evidence" className="w-full h-full object-cover rounded-lg" />
                  <button
                    type="button"
                    className="absolute -top-2 -right-2 bg-red-600 rounded-full w-6 h-6 flex items-center justify-center text-white"
                    onClick={() => handleRemovePhoto(photo.id)}
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
              
              <button
                type="button"
                onClick={handleAddPhoto}
                className="w-20 h-20 border-2 border-dashed border-gray-600 rounded-lg flex flex-col items-center justify-center text-gray-500 hover:text-gray-300 hover:border-gray-400"
              >
                <Camera size={20} />
                <span className="text-xs mt-1">Adicionar</span>
              </button>
            </div>
          </div>
          
          {/* Botões de ação */}
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-white rounded-lg"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
            >
              Reportar Alerta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSecurityAlert;