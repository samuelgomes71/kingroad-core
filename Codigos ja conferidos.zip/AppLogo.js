import React, { useState } from 'react';
import { View, Image, TouchableOpacity, StyleSheet } from 'react-native';

const AppLogo = ({ onDeveloperMode }) => {
  const [clickCount, setClickCount] = useState(0);

  const handlePress = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);

    if (newCount >= 5) {
      onDeveloperMode(); // Ativa o modo desenvolvedor
      setClickCount(0); // Reseta o contador
    }

    setTimeout(() => setClickCount(0), 2000); // Reseta após 2 segundos sem cliques
  };

  return (
    <View style={styles.logoContainer}>
      <TouchableOpacity onPress={handlePress}>
        <Image
          source={require('./assets/logo.png')} // Caminho do logo oval vertical
          style={styles.logo}
        />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  logoContainer: {
    position: 'absolute',
    top: 20,
    left: 20,
  },
  logo: {
    width: 80, // Ajuste conforme necessário
    height: 100, // Ajuste conforme necessário
    resizeMode: 'contain',
  },
});

export default AppLogo;
