/**
 * RegionalSettingsService.js
 * Sistema de Internacionalização do KingRoad
 * 
 * Serviço responsável por fornecer configurações específicas de região
 * Gerencia formatação, unidades de medida, limites de velocidade, restrições regionais
 * e regras para veículos pesados com base na localização atual.
 * 
 * Combina funcionalidades de configurações gerais, formatação e regras específicas
 * para veículos pesados, integrando com o LocaleService.
 * 
 * @author KingRoad Team
 * @version 2.0.0
 * @date 2025-03-31
 */

import { AsyncStorage } from 'react-native';
import LocaleService from './LocaleService';
import { t } from './TranslationsService';

// Constantes para sistemas de medidas
const MEASUREMENT_SYSTEMS = {
  METRIC: 'metric',      // km, kg, litros
  IMPERIAL: 'imperial',  // milhas, libras, galões
  MIXED: 'mixed'         // combinação de sistemas (ex: Reino Unido)
};

// Constantes para tipos de veículos pesados
const HEAVY_VEHICLE_TYPES = {
  TRUCK: 'truck',
  BUS: 'bus',
  TRAILER: 'trailer',
  SEMI_TRAILER: 'semi_trailer',
  ROAD_TRAIN: 'road_train',
  SPECIAL_TRANSPORT: 'special_transport'
};

// Constantes para tipos de vias
const ROAD_TYPES = {
  HIGHWAY: 'highway',
  FREEWAY: 'freeway',
  EXPRESSWAY: 'expressway',
  NATIONAL_ROAD: 'national_road',
  REGIONAL_ROAD: 'regional_road',
  LOCAL_ROAD: 'local_road',
  URBAN_ROAD: 'urban_road',
  TUNNEL: 'tunnel',
  BRIDGE: 'bridge',
  FERRY_CONNECTION: 'ferry_connection'
};

/**
 * Configurações específicas por país.
 * Inclui limites de velocidade, restrições, sistemas de medida e outras
 * informações relevantes para veículos pesados.
 */
const COUNTRY_SETTINGS = {
  // Brasil
  'BR': {
    measurementSystem: MEASUREMENT_SYSTEMS.METRIC,
    speedLimits: {
      [HEAVY_VEHICLE_TYPES.TRUCK]: {
        [ROAD_TYPES.HIGHWAY]: 80,
        [ROAD_TYPES.URBAN_ROAD]: 60,
        default: 70
      },
      [HEAVY_VEHICLE_TYPES.BUS]: {
        [ROAD_TYPES.HIGHWAY]: 90,
        [ROAD_TYPES.URBAN_ROAD]: 60,
        default: 80
      },
      default: 80
    },
    restrictions: {
      weekendRestriction: {
        active: true,
        days: [5, 6], // Sexta e Sábado
        hours: { start: '16:00', end: '22:00' },
        appliesTo: ['SP', 'RJ'], // Estados com restrição
        roadTypes: [ROAD_TYPES.HIGHWAY],
        description: 'Restrição de circulação de veículos pesados em rodovias de SP e RJ'
      },
      holidayRestrictions: true,
      urbanRestrictions: true,
      specialZones: ['ZMRC-SP', 'LEZ-RJ'] // Zona de Máxima Restrição de Circulação (SP), Low Emission Zone (RJ)
    },
    roadTypes: {
      'rodovia_pedagiada': {
        basedOn: ROAD_TYPES.HIGHWAY,
        hasTolls: true
      }
    },
    heavyVehicleRules: {
      maxWeight: 45, // toneladas
      maxHeight: 4.4, // metros
      maxWidth: 2.6, // metros
      maxLength: 19.8, // metros para combinações veiculares
      requiresTachograph: true,
      requiresRestPeriods: {
        maxDrivingHours: 5.5,
        minRestTime: 0.5 // 30 minutos
      }
    },
    units: {
      distance: 'km',
      speed: 'km/h',
      temperature: 'celsius',
      coordinates: 'decimal'
    },
    dateTime: {
      timeFormat: '24h',
      dateFormat: 'DMY',
      firstDayOfWeek: 0
    },
    general: {
      emergencyNumbers: ['190', '192', '193'],
      safetyFeaturesEnabled: true,
      autoSaveInterval: 5 // em minutos
    }
  },
  
  // Estados Unidos
  'US': {
    measurementSystem: MEASUREMENT_SYSTEMS.IMPERIAL,
    speedLimits: {
      [HEAVY_VEHICLE_TYPES.TRUCK]: {
        [ROAD_TYPES.HIGHWAY]: 65, // mph
        [ROAD_TYPES.URBAN_ROAD]: 45, // mph
        default: 55
      },
      default: 65
    },
    restrictions: {
      weighStations: {
        mandatory: true,
        description: 'Paradas obrigatórias em postos de pesagem'
      },
      stateSpecific: true
    },
    roadTypes: {
      'interstate': {
        basedOn: ROAD_TYPES.HIGHWAY,
        federalSystem: true
      }
    },
    heavyVehicleRules: {
      maxWeight: 80000, // libras (cerca de 36 toneladas)
      maxHeight: 13.5, // pés (cerca de 4,1 metros)
      maxWidth: 8.5, // pés (cerca de 2,6 metros)
      variableByState: true,
      requiresElectronicLogging: true,
      requiresRestPeriods: {
        maxDrivingHours: 11,
        minRestTime: 10 // horas
      }
    },
    units: {
      distance: 'mi',
      speed: 'mph',
      temperature: 'fahrenheit',
      coordinates: 'decimal'
    },
    dateTime: {
      timeFormat: '12h',
      dateFormat: 'MDY',
      firstDayOfWeek: 0
    },
    general: {
      emergencyNumbers: ['911'],
      safetyFeaturesEnabled: true,
      autoSaveInterval: 10
    }
  },
  
  // Alemanha
  'DE': {
    measurementSystem: MEASUREMENT_SYSTEMS.METRIC,
    speedLimits: {
      [HEAVY_VEHICLE_TYPES.TRUCK]: {
        [ROAD_TYPES.HIGHWAY]: 80, // km/h em autobahns
        [ROAD_TYPES.URBAN_ROAD]: 50, // km/h
        default: 60
      },
      default: 80
    },
    restrictions: {
      weekendRestriction: {
        active: true,
        days: [0], // Domingo
        hours: { allDay: true },
        exceptions: ['perecíveis', 'emergência']
      },
      lowEmissionZones: {
        active: true,
        requiresSticker: true
      },
      maut: {
        active: true,
        description: 'Sistema de pedágio eletrônico para veículos acima de 7,5 toneladas'
      }
    },
    roadTypes: {
      'autobahn': {
        basedOn: ROAD_TYPES.HIGHWAY,
        noSpeedLimitForCars: true
      }
    },
    heavyVehicleRules: {
      maxWeight: 40, // toneladas
      maxHeight: 4, // metros
      maxWidth: 2.55, // metros
      maxLength: 18.75, // metros para combinações veiculares
      requiresTachograph: true,
      requiresRestPeriods: {
        maxDrivingHours: 4.5,
        minRestTime: 0.75 // 45 minutos
      }
    },
    units: {
      distance: 'km',
      speed: 'km/h',
      temperature: 'celsius',
      coordinates: 'decimal'
    },
    dateTime: {
      timeFormat: '24h',
      dateFormat: 'DMY',
      firstDayOfWeek: 1
    },
    general: {
      emergencyNumbers: ['112'],
      safetyFeaturesEnabled: true,
      autoSaveInterval: 5
    }
  },
  
  // Reino Unido (sistema misto)
  'GB': {
    measurementSystem: MEASUREMENT_SYSTEMS.MIXED,
    speedLimits: {
      [HEAVY_VEHICLE_TYPES.TRUCK]: {
        [ROAD_TYPES.HIGHWAY]: 56, // mph em motorways
        [ROAD_TYPES.URBAN_ROAD]: 30, // mph
        default: 50
      },
      default: 70
    },
    restrictions: {
      lowEmissionZones: {
        active: true,
        description: 'London Low Emission Zone e ULEZ'
      }
    },
    heavyVehicleRules: {
      maxWeight: 44, // toneladas
      maxHeight: 5.03, // metros (16ft 6in)
      maxWidth: 2.55, // metros
      maxLength: 18.75, // metros
      requiresTachograph: true
    },
    units: {
      distance: 'mi',
      speed: 'mph',
      temperature: 'celsius',
      coordinates: 'decimal'
    },
    dateTime: {
      timeFormat: '12h',
      dateFormat: 'DMY',
      firstDayOfWeek: 1
    },
    general: {
      emergencyNumbers: ['999', '112'],
      safetyFeaturesEnabled: true
    }
  },
  
  // Configuração padrão (usada quando o país específico não está disponível)
  'default': {
    measurementSystem: MEASUREMENT_SYSTEMS.METRIC,
    speedLimits: {
      [HEAVY_VEHICLE_TYPES.TRUCK]: {
        [ROAD_TYPES.HIGHWAY]: 80,
        [ROAD_TYPES.URBAN_ROAD]: 50,
        default: 60
      },
      default: 80
    },
    restrictions: {
      weekendRestriction: {
        active: false
      }
    },
    heavyVehicleRules: {
      maxWeight: 40, // toneladas
      maxHeight: 4, // metros
      maxWidth: 2.55, // metros
      maxLength: 16.5, // metros
      requiresTachograph: true
    },
    units: {
      distance: 'km',
      speed: 'km/h',
      temperature: 'celsius',
      coordinates: 'decimal'
    },
    dateTime: {
      timeFormat: '24h',
      dateFormat: 'DMY',
      firstDayOfWeek: 1
    },
    general: {
      safetyFeaturesEnabled: true,
      emergencyNumbers: ['112'],
      autoSaveInterval: 5
    }
  }
};

/**
 * Serviço unificado para gerenciar configurações específicas por região/país
 * Fornece métodos para configurações gerais, formatação e regras para veículos pesados
 */
class RegionalSettingsService {
  constructor() {
    // Propriedades básicas
    this.localeService = LocaleService;
    this.settings = {};
    this.defaultSettings = {};
    
    // Propriedades de localização
    this.currentCountry = null;
    this.currentRegion = null;
    this.currentSettings = null;
    
    // Propriedades para notificações
    this.isInitialized = false;
    this.locationChangeListeners = [];
    this.onSettingsChangeListeners = [];
    
    // Registra listener para mudanças de localização no LocaleService
    this.localeService.addCountryChangeListener(this.handleLocationChange.bind(this));
  }

  /**
   * Inicializa o serviço de configurações regionais
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async initialize() {
    if (this.isInitialized) return true;

    try {
      // Define configurações padrão
      this._setupDefaultSettings();
      
      // Detecta país e região atual
      this.updateCurrentLocation();
      
      // Carrega configurações específicas da região atual
      await this._loadRegionSettings();
      
      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('Falha ao inicializar RegionalSettingsService:', error);
      return false;
    }
  }

  /**
   * Configura as definições padrão para todas as regiões
   * @private
   */
  _setupDefaultSettings() {
    // Usa a configuração padrão de COUNTRY_SETTINGS
    this.defaultSettings = JSON.parse(JSON.stringify(COUNTRY_SETTINGS.default));
  }

  /**
   * Atualiza a localização atual com base nas informações do LocaleService
   */
  updateCurrentLocation() {
    // Obtém o país atual do LocaleService
    const countryCode = this.localeService.getCurrentCountry();
    const regionCode = this.localeService.getCurrentRegion();
    
    // Verifica se a localização mudou
    if (this.currentCountry !== countryCode || this.currentRegion !== regionCode) {
      this.currentCountry = countryCode;
      this.currentRegion = regionCode;
      
      // Atualiza configurações regionais
      this.updateRegionalSettings();
      
      // Notifica os listeners da mudança
      this._notifyLocationChange();
    }
  }

  /**
   * Manipula eventos de mudança de localização do LocaleService
   * @private
   * @param {string} countryCode - Código do país 
   * @param {Object} regionSettings - Configurações da região
   */
  handleLocationChange(countryCode, regionSettings) {
    if (!countryCode) return;
    
    // Atualiza país atual
    this.currentCountry = countryCode;
    
    // Tenta obter região atual
    this.currentRegion = this.localeService.getCurrentRegion();
    
    // Atualiza configurações regionais
    this.updateRegionalSettings();
    
    // Notifica os listeners da mudança
    this._notifyLocationChange();
  }

  /**
   * Atualiza as configurações regionais com base no país atual
   */
  updateRegionalSettings() {
    // Obtém configurações do país atual ou usa configuração padrão
    this.currentSettings = JSON.parse(JSON.stringify(
      COUNTRY_SETTINGS[this.currentCountry] || COUNTRY_SETTINGS.default
    ));
    
    // Adiciona informações específicas da região, se disponíveis
    this.enrichWithRegionalData();
    
    // Atualiza configurações gerais
    this.settings = this.currentSettings;
    
    // Notifica listeners sobre mudança de configurações
    this._notifySettingsChangeListeners();
    
    console.log(`[RegionalSettingsService] Configurações atualizadas para ${this.currentCountry}-${this.currentRegion}`);
  }

  /**
   * Adiciona informações específicas da região às configurações atuais
   * @private
   */
  enrichWithRegionalData() {
    if (!this.currentCountry || !this.currentRegion) return;
    
    // Implementa lógica específica para cada país/região
    if (this.currentCountry === 'BR') {
      // Configurações específicas por estado no Brasil
      if (this.currentRegion === 'SP') {
        this.currentSettings.regionalRestrictions = {
          rodizioVeicular: {
            active: true,
            description: 'Rodízio de veículos pesados na região metropolitana'
          }
        };
      }
    } else if (this.currentCountry === 'US') {
      // Configurações específicas por estado nos EUA
      if (['CA', 'OR', 'WA'].includes(this.currentRegion)) {
        // Estados da costa oeste
        this.currentSettings.regionalRestrictions = {
          emissionStandards: {
            active: true,
            description: 'Padrões rigorosos de emissão para veículos pesados'
          }
        };
      }
    }
  }

  /**
   * Carrega configurações específicas para a região atual
   * @returns {Promise<void>}
   * @private
   */
  async _loadRegionSettings() {
    try {
      const region = this.currentCountry;
      
      if (!region) {
        this.settings = { ...this.defaultSettings };
        return;
      }
      
      // Primeiro tenta carregar do cache
      const cachedSettings = await AsyncStorage.getItem(`region_settings_${region}`);
      
      if (cachedSettings) {
        const parsedSettings = JSON.parse(cachedSettings);
        this.settings = this._mergeWithDefaults(parsedSettings);
      } else {
        // Se não encontrar no cache, busca da API
        await this._fetchRegionSettingsFromAPI(region);
      }
    } catch (error) {
      console.error('Falha ao carregar configurações regionais:', error);
      
      // Em caso de erro, usa configurações padrão
      this.settings = { ...this.defaultSettings };
    }
  }

  /**
   * Busca configurações regionais da API
   * @param {string} region - Código da região
   * @returns {Promise<void>}
   * @private
   */
  async _fetchRegionSettingsFromAPI(region) {
    try {
      // Implementação de requisição à API
      // const response = await fetch(`https://api.kingroad.app/settings/region/${region}`);
      // const regionSettings = await response.json();
      
      // Para desenvolvimento, usar configurações específicas embutidas
      const regionSettings = this._getEmbeddedRegionSettings(region);
      
      // Mescla com configurações padrão
      this.settings = this._mergeWithDefaults(regionSettings);
      
      // Salva no cache
      await AsyncStorage.setItem(`region_settings_${region}`, JSON.stringify(regionSettings));
    } catch (error) {
      console.error(`Falha ao buscar configurações para região ${region}:`, error);
      
      // Em caso de erro, usa configurações padrão
      this.settings = { ...this.defaultSettings };
    }
  }

  /**
   * Retorna configurações embutidas para uma região específica (para desenvolvimento)
   * @param {string} region - Código da região
   * @returns {Object} - Configurações específicas da região
   * @private
   */
  _getEmbeddedRegionSettings(region) {
    // Retorna as configurações para a região específica ou um objeto vazio
    return COUNTRY_SETTINGS[region] || {};
  }

  /**
   * Mescla configurações específicas com as padrão
   * @param {Object} regionSettings - Configurações específicas da região
   * @returns {Object} - Configurações mescladas
   * @private
   */
  _mergeWithDefaults(regionSettings) {
    // Clone profundo das configurações padrão
    const result = JSON.parse(JSON.stringify(this.defaultSettings));
    
    // Função recursiva para mesclar objetos
    const deepMerge = (target, source) => {
      for (const key in source) {
        if (source.hasOwnProperty(key)) {
          if (source[key] instanceof Object && key in target) {
            deepMerge(target[key], source[key]);
          } else {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    
    // Mescla configurações regionais com padrões
    return deepMerge(result, regionSettings);
  }
/**
   * Notifica todos os listeners sobre mudança de localização
   * @private
   */
  _notifyLocationChange() {
    const locationData = {
      country: this.currentCountry,
      region: this.currentRegion,
      settings: this.currentSettings
    };
    
    this.locationChangeListeners.forEach(listener => {
      try {
        listener(locationData);
      } catch (error) {
        console.error('[RegionalSettingsService] Erro ao notificar listener:', error);
      }
    });
  }

  /**
   * Notifica todos os listeners sobre mudança de configurações
   * @private
   */
  _notifySettingsChangeListeners() {
    this.onSettingsChangeListeners.forEach(listener => {
      try {
        listener(this.settings);
      } catch (error) {
        console.error('Erro em listener de mudança de configurações:', error);
      }
    });
  }

  /**
   * Adiciona listener para mudanças de localização
   * @param {Function} listener - Função callback para notificar mudanças
   * @returns {Function} Função para remover o listener
   */
  addLocationChangeListener(listener) {
    if (typeof listener !== 'function') {
      throw new Error('[RegionalSettingsService] Listener deve ser uma função');
    }
    
    this.locationChangeListeners.push(listener);
    
    // Retorna função para remover o listener
    return () => {
      this.locationChangeListeners = this.locationChangeListeners.filter(l => l !== listener);
    };
  }

  /**
   * Adiciona listener para mudanças de configurações
   * @param {Function} listener - Função a ser chamada quando configurações mudarem
   * @returns {Function} - Função para remover o listener
   */
  addSettingsChangeListener(listener) {
    this.onSettingsChangeListeners.push(listener);
    
    // Retorna função para remover o listener
    return () => {
      this.onSettingsChangeListeners = this.onSettingsChangeListeners.filter(l => l !== listener);
    };
  }

  /**
   * Define manualmente o país e região (útil para testes ou quando a geolocalização falha)
   * @param {string} countryCode - Código ISO do país (ex: 'BR', 'US')
   * @param {string} regionCode - Código da região/estado (ex: 'SP', 'CA')
   * @returns {boolean} - Sucesso da operação
   */
  setCountryAndRegion(countryCode, regionCode) {
    if (!countryCode) {
      throw new Error('[RegionalSettingsService] Código do país é obrigatório');
    }
    
    this.currentCountry = countryCode;
    this.currentRegion = regionCode || null;
    
    // Atualiza configurações regionais
    this.updateRegionalSettings();
    
    // Notifica os listeners da mudança
    this._notifyLocationChange();
    
    return true;
  }

  /**
   * Atualiza quando a região muda
   * @param {string} region - Nova região
   * @returns {Promise<void>}
   */
  async updateRegion(region) {
    if (!region) return;
    
    // Carrega configurações para a nova região
    await this._fetchRegionSettingsFromAPI(region);
    
    // Notifica listeners sobre mudança
    this._notifySettingsChangeListeners();
  }

  /**
   * Obtém uma configuração específica
   * @param {string} path - Caminho para a configuração (ex: 'units.distance')
   * @param {*} defaultValue - Valor padrão caso a configuração não exista
   * @returns {*} - Valor da configuração
   */
  getSetting(path, defaultValue = null) {
    if (!this.isInitialized) {
      console.warn('RegionalSettingsService não foi inicializado. Chamando initialize()...');
      this.initialize();
      return defaultValue;
    }
    
    // Navega pelo objeto de configurações usando o caminho
    const parts = path.split('.');
    let current = this.settings;
    
    for (const part of parts) {
      if (current === undefined || current === null || !current.hasOwnProperty(part)) {
        return defaultValue;
      }
      current = current[part];
    }
    
    return current !== undefined ? current : defaultValue;
  }

  /**
   * Atualiza uma configuração específica
   * @param {string} path - Caminho para a configuração (ex: 'units.distance')
   * @param {*} value - Novo valor
   * @returns {Promise<void>}
   */
  async updateSetting(path, value) {
    if (!this.isInitialized) {
      console.warn('RegionalSettingsService não foi inicializado. Chamando initialize()...');
      await this.initialize();
    }
    
    // Navega pelo objeto de configurações usando o caminho
    const parts = path.split('.');
    let current = this.settings;
    
    // Navega até o penúltimo nível
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      if (current[part] === undefined || current[part] === null) {
        current[part] = {};
      }
      current = current[part];
    }
    
    // Define o valor
    current[parts[parts.length - 1]] = value;
    
    // Salva no cache
    const region = this.currentCountry;
    if (region) {
      await AsyncStorage.setItem(`region_settings_${region}`, JSON.stringify(this.settings));
    }
    
    // Notifica listeners
    this._notifySettingsChangeListeners();
  }
/**
   * Reseta as configurações para os valores padrão da região atual
   * @returns {Promise<void>}
   */
  async resetToDefaults() {
    const region = this.currentCountry;
    
    // Remove configurações do cache
    if (region) {
      await AsyncStorage.removeItem(`region_settings_${region}`);
    }
    
    // Recarrega configurações
    await this._loadRegionSettings();
    
    // Notifica listeners
    this._notifySettingsChangeListeners();
  }

  /**
   * Obtém o sistema de medidas atual
   * @returns {string} Sistema de medidas (metric, imperial, mixed)
   */
  getMeasurementSystem() {
    return this.currentSettings?.measurementSystem || MEASUREMENT_SYSTEMS.METRIC;
  }

  /**
   * Converte unidades de acordo com o sistema de medidas atual
   * @param {number} value - Valor a ser convertido
   * @param {string} fromUnit - Unidade de origem ('km', 'mi', 'kg', 'lb', etc)
   * @param {string} toUnit - Unidade de destino (se não fornecida, usa o sistema atual)
   * @returns {number} Valor convertido
   */
  convertUnit(value, fromUnit, toUnit) {
    // Implementa conversões de unidades comuns
    const conversions = {
      'km_to_mi': val => val * 0.621371,
      'mi_to_km': val => val * 1.60934,
      'kg_to_lb': val => val * 2.20462,
      'lb_to_kg': val => val * 0.453592,
      'l_to_gal': val => val * 0.264172, // galão americano
      'gal_to_l': val => val * 3.78541,
      'm_to_ft': val => val * 3.28084,
      'ft_to_m': val => val * 0.3048
    };
    
    // Se toUnit não for fornecido, determina com base no sistema atual
    if (!toUnit) {
      const system = this.getMeasurementSystem();
      switch (fromUnit) {
        case 'km': toUnit = system === MEASUREMENT_SYSTEMS.IMPERIAL ? 'mi' : 'km'; break;
        case 'mi': toUnit = system === MEASUREMENT_SYSTEMS.METRIC ? 'km' : 'mi'; break;
        case 'kg': toUnit = system === MEASUREMENT_SYSTEMS.IMPERIAL ? 'lb' : 'kg'; break;
        case 'lb': toUnit = system === MEASUREMENT_SYSTEMS.METRIC ? 'kg' : 'lb'; break;
        case 'l': toUnit = system === MEASUREMENT_SYSTEMS.IMPERIAL ? 'gal' : 'l'; break;
        case 'gal': toUnit = system === MEASUREMENT_SYSTEMS.METRIC ? 'l' : 'gal'; break;
        case 'm': toUnit = system === MEASUREMENT_SYSTEMS.IMPERIAL ? 'ft' : 'm'; break;
        case 'ft': toUnit = system === MEASUREMENT_SYSTEMS.METRIC ? 'm' : 'ft'; break;
        default: return value; // Se não conhece a unidade, retorna o valor original
      }
    }
    
    // Se a unidade de origem e destino forem iguais, retorna o valor original
    if (fromUnit === toUnit) return value;
    
    // Busca a conversão apropriada
    const conversionKey = `${fromUnit}_to_${toUnit}`;
    const conversion = conversions[conversionKey];
    
    if (conversion) {
      return conversion(value);
    }
    
    console.warn(`[RegionalSettingsService] Conversão de ${fromUnit} para ${toUnit} não implementada`);
    return value;
  }

  /**
   * Converte unidades de distância entre o sistema métrico e imperial
   * @param {number} value - Valor para converter
   * @param {string} fromUnit - Unidade de origem ('km' ou 'mi')
   * @param {string} toUnit - Unidade de destino ('km' ou 'mi')
   * @returns {number} - Valor convertido
   */
  convertDistance(value, fromUnit, toUnit) {
    return this.convertUnit(value, fromUnit, toUnit);
  }

  /**
   * Converte unidades de temperatura entre Celsius e Fahrenheit
   * @param {number} value - Valor para converter
   * @param {string} fromUnit - Unidade de origem ('celsius' ou 'fahrenheit')
   * @param {string} toUnit - Unidade de destino ('celsius' ou 'fahrenheit')
   * @returns {number} - Valor convertido
   */
  convertTemperature(value, fromUnit, toUnit) {
    if (fromUnit === toUnit) return value;
    
    if (fromUnit === 'celsius' && toUnit === 'fahrenheit') {
      return (value * 9/5) + 32;
    } else if (fromUnit === 'fahrenheit' && toUnit === 'celsius') {
      return (value - 32) * 5/9;
    }
    
    return value;
  }

  /**
   * Formata uma distância de acordo com as configurações regionais
   * @param {number} value - Valor da distância
   * @param {string} unit - Unidade da distância (opcional, usa a configuração regional se não informada)
   * @returns {string} - Distância formatada
   */
  formatDistance(value, unit = null) {
    const distanceUnit = unit || this.getSetting('units.distance', 'km');
    const formattedValue = this.localeService.formatNumber(value, 1);
    
    return `${formattedValue} ${distanceUnit}`;
  }

  /**
   * Formata uma velocidade de acordo com as configurações regionais
   * @param {number} value - Valor da velocidade
   * @param {string} unit - Unidade da velocidade (opcional, usa a configuração regional se não informada)
   * @returns {string} - Velocidade formatada
   */
  formatSpeed(value, unit = null) {
    const speedUnit = unit || this.getSetting('units.speed', 'km/h');
    const formattedValue = this.localeService.formatNumber(value, 0);
    
    return `${formattedValue} ${speedUnit}`;
  }
/**
   * Formata as coordenadas geográficas de acordo com as configurações regionais
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @returns {string} - Coordenadas formatadas
   */
  formatCoordinates(latitude, longitude) {
    const format = this.getSetting('units.coordinates', 'decimal');
    
    if (format === 'dms') {
      return `${this._decimalToDMS(latitude, true)}, ${this._decimalToDMS(longitude, false)}`;
    } else {
      // Formato decimal
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    }
  }

  /**
   * Converte coordenadas decimais para o formato DMS (graus, minutos, segundos)
   * @param {number} decimal - Valor decimal da coordenada
   * @param {boolean} isLatitude - Se é latitude (true) ou longitude (false)
   * @returns {string} - Coordenada no formato DMS
   * @private
   */
  _decimalToDMS(decimal, isLatitude) {
    const absolute = Math.abs(decimal);
    const degrees = Math.floor(absolute);
    const minutesNotTruncated = (absolute - degrees) * 60;
    const minutes = Math.floor(minutesNotTruncated);
    const seconds = ((minutesNotTruncated - minutes) * 60).toFixed(2);
    
    const direction = isLatitude
      ? (decimal >= 0 ? t('direction.north') : t('direction.south'))
      : (decimal >= 0 ? t('direction.east') : t('direction.west'));
    
    return `${degrees}° ${minutes}' ${seconds}" ${direction}`;
  }

  /**
   * Obtém o limite de velocidade para o tipo de veículo e via especificados
   * @param {string} vehicleType - Tipo de veículo (usar constantes HEAVY_VEHICLE_TYPES)
   * @param {string} roadType - Tipo de via (usar constantes ROAD_TYPES)
   * @param {boolean} convertToPreferredUnit - Se true, converte para a unidade preferida do usuário
   * @returns {number} Limite de velocidade
   */
  getSpeedLimit(vehicleType, roadType, convertToPreferredUnit = true) {
    if (!this.currentSettings) {
      return null;
    }
    
    let speedLimit = null;
    
    // Tenta encontrar o limite específico para o tipo de veículo e via
    if (this.currentSettings.speedLimits[vehicleType]?.[roadType]) {
      speedLimit = this.currentSettings.speedLimits[vehicleType][roadType];
    } 
    // Se não encontrar, tenta o limite padrão para o tipo de veículo
    else if (this.currentSettings.speedLimits[vehicleType]?.default) {
      speedLimit = this.currentSettings.speedLimits[vehicleType].default;
    } 
    // Se ainda não encontrar, usa o limite padrão geral
    else {
      speedLimit = this.currentSettings.speedLimits.default || 80;
    }
    
    // Se solicitado, converte para a unidade preferida do usuário
    if (convertToPreferredUnit) {
      const preferredSystem = this.localeService.getUserPreferences?.()?.measurementSystem 
        || this.getMeasurementSystem();
      
      const currentSystem = this.getMeasurementSystem();
      
      if (currentSystem === MEASUREMENT_SYSTEMS.METRIC && preferredSystem === MEASUREMENT_SYSTEMS.IMPERIAL) {
        // Converte de km/h para mph
        return this.convertUnit(speedLimit, 'km', 'mi');
      } else if (currentSystem === MEASUREMENT_SYSTEMS.IMPERIAL && preferredSystem === MEASUREMENT_SYSTEMS.METRIC) {
        // Converte de mph para km/h
        return this.convertUnit(speedLimit, 'mi', 'km');
      }
    }
    
    return speedLimit;
  }

  /**
   * Verifica se há restrições ativas para o momento atual no país/região
   * @param {string} vehicleType - Tipo de veículo (usar constantes HEAVY_VEHICLE_TYPES)
   * @param {Date} date - Data e hora para verificar (opcional, padrão: agora)
   * @returns {Array} Lista de restrições ativas
   */
  getActiveRestrictions(vehicleType, date = new Date()) {
    if (!this.currentSettings?.restrictions) {
      return [];
    }
    
    const activeRestrictions = [];
    const dayOfWeek = date.getDay(); // 0 = Domingo, 6 = Sábado
    const timeString = `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`;
    
    // Verifica restrições de fim de semana
    if (this.currentSettings.restrictions.weekendRestriction?.active) {
      const { days, hours } = this.currentSettings.restrictions.weekendRestriction;
      
      // Verifica se o dia atual está na lista de dias com restrição
      if (days.includes(dayOfWeek)) {
        // Verifica se há restrição para o horário atual
        if (hours.allDay || (timeString >= hours.start && timeString <= hours.end)) {
          activeRestrictions.push({
            type: 'weekendRestriction',
            description: this.currentSettings.restrictions.weekendRestriction.description || 
                         'Restrição de circulação em fim de semana/feriado'
          });
        }
      }
    }
    
    // Verifica restrições específicas da região
    if (this.currentSettings.regionalRestrictions) {
      Object.keys(this.currentSettings.regionalRestrictions).forEach(key => {
        const restriction = this.currentSettings.regionalRestrictions[key];
        if (restriction.active) {
          // Implementar lógica específica para cada tipo de restrição regional
          // Este é um exemplo simplificado
          activeRestrictions.push({
            type: key,
            description: restriction.description
          });
        }
      });
    }
    
    // Adicione outras verificações de restrições conforme necessário
    
    return activeRestrictions;
  }
/**
   * Obtém as regras para veículos pesados no país/região atual
   * @param {string} vehicleType - Tipo de veículo específico (opcional)
   * @returns {Object} Regras para veículos pesados
   */
  getHeavyVehicleRules(vehicleType) {
    if (!this.currentSettings?.heavyVehicleRules) {
      return null;
    }
    
    // Retorna as regras gerais para veículos pesados
    const rules = { ...this.currentSettings.heavyVehicleRules };
    
    // Adiciona regras específicas para o tipo de veículo, se disponíveis
    if (vehicleType && this.currentSettings.heavyVehicleRules[vehicleType]) {
      Object.assign(rules, this.currentSettings.heavyVehicleRules[vehicleType]);
    }
    
    return rules;
  }

  /**
   * Obtém informações sobre pedágios e taxas na região atual
   * @returns {Object} Informações sobre pedágios e taxas
   */
  getTollsAndFees() {
    const tollsAndFees = {};
    
    // Adiciona informações de pedágio do país
    if (this.currentSettings.restrictions?.maut) {
      tollsAndFees.maut = this.currentSettings.restrictions.maut;
    }
    
    // Adiciona taxas específicas de emissão
    if (this.currentSettings.restrictions?.lowEmissionZones) {
      tollsAndFees.emissionZones = this.currentSettings.restrictions.lowEmissionZones;
    }
    
    // Adiciona informações de rodovias com pedágio
    if (this.currentSettings.roadTypes?.['rodovia_pedagiada']) {
      tollsAndFees.tollRoads = this.currentSettings.roadTypes['rodovia_pedagiada'];
    }
    
    // Adicione outras informações específicas conforme necessário
    
    return Object.keys(tollsAndFees).length > 0 ? tollsAndFees : null;
  }

  /**
   * Verifica se há obrigatoriedade de períodos de descanso para motoristas
   * @returns {Object|null} Regras de períodos de descanso obrigatórios, se aplicável
   */
  getRequiredRestPeriods() {
    if (!this.currentSettings?.heavyVehicleRules?.requiresRestPeriods) {
      return null;
    }
    
    return this.currentSettings.heavyVehicleRules.requiresRestPeriods;
  }

  /**
   * Verifica se o sistema de medidas atual é métrico
   * @returns {boolean} - Verdadeiro se o sistema atual for métrico
   */
  isMetricSystem() {
    return this.getMeasurementSystem() === MEASUREMENT_SYSTEMS.METRIC;
  }

  /**
   * Obtém o formato de data atual
   * @returns {string} - Formato de data ('DMY', 'MDY', 'YMD')
   */
  getDateFormat() {
    return this.getSetting('dateTime.dateFormat', 'DMY');
  }

  /**
   * Obtém o formato de hora atual
   * @returns {string} - Formato de hora ('12h', '24h')
   */
  getTimeFormat() {
    return this.getSetting('dateTime.timeFormat', '24h');
  }

  /**
   * Obtém o primeiro dia da semana de acordo com as configurações regionais
   * @returns {number} - Índice do primeiro dia (0 = domingo, 1 = segunda, etc.)
   */
  getFirstDayOfWeek() {
    return this.getSetting('dateTime.firstDayOfWeek', 1);
  }

  /**
   * Obtém números de emergência para a região atual
   * @returns {Array<string>} - Lista de números de emergência
   */
  getEmergencyNumbers() {
    return this.getSetting('general.emergencyNumbers', ['911']);
  }

  /**
   * Obtém dicas e recomendações específicas para a região atual
   * @returns {Array} Lista de dicas e recomendações
   */
  getRegionalTips() {
    const tips = [];
    
    // Adiciona dicas com base no país atual
    switch (this.currentCountry) {
      case 'BR':
        tips.push(
          'Verifique a documentação obrigatória: CRLV, ANTT e exame toxicológico',
          'Atenção às restrições de circulação em grandes centros urbanos',
          'Mantenha-se informado sobre a tabela de frete mínimo'
        );
        break;
      case 'US':
        tips.push(
          'Electronic logging device (ELD) é obrigatório para registro de horas de serviço',
          'Verifique as regras específicas de cada estado antes de entrar',
          'Mantenha-se atento às estações de pesagem obrigatórias'
        );
        break;
      case 'DE':
        tips.push(
          'Verifique se seu veículo atende aos requisitos de emissões (adesivo ambiental)',
          'A taxa Maut é obrigatória para veículos acima de 7,5 toneladas',
          'Respeite rigorosamente as restrições de fim de semana'
        );
        break;
    }
    
    // Adiciona dicas com base nas restrições ativas
    if (this.getActiveRestrictions().length > 0) {
      tips.push('Existem restrições ativas para sua localização atual. Verifique detalhes');
    }
    
    // Adiciona dicas de descanso, se aplicável
    const restPeriods = this.getRequiredRestPeriods();
    if (restPeriods) {
      tips.push(`Respeite os períodos de descanso: ${restPeriods.maxDrivingHours}h dirigindo, ${restPeriods.minRestTime}h de descanso`);
    }
    
    return tips;
  }

  /**
   * Obtém configurações completas para a região atual
   * @returns {Object} Configurações regionais completas
   */
  getCurrentSettings() {
    return this.currentSettings;
  }

  /**
   * Obtém informações sobre a localização atual
   * @returns {Object} Informações sobre país e região atual
   */
  getCurrentLocation() {
    return {
      country: this.currentCountry,
      region: this.currentRegion,
      countryName: this.localeService.getCountryName?.(this.currentCountry) || this.currentCountry,
      regionName: this.localeService.getRegionName?.(this.currentCountry, this.currentRegion) || this.currentRegion
    };
  }

  /**
   * Limpa o cache de configurações regionais
   * @returns {Promise<void>}
   */
  async clearCache() {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const regionSettingsKeys = keys.filter(key => key.startsWith('region_settings_'));
      
      if (regionSettingsKeys.length > 0) {
        await AsyncStorage.multiRemove(regionSettingsKeys);
      }
      
      // Recarrega configurações
      await this._loadRegionSettings();
      
      // Notifica listeners
      this._notifySettingsChangeListeners();
    } catch (error) {
      console.error('Falha ao limpar cache de configurações regionais:', error);
    }
  }
}

// Exporta instância singleton
const regionalSettingsService = new RegionalSettingsService();
export default regionalSettingsService;