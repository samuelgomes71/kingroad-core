package com.kingroad.utils.map

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.kingroad.R
import com.kingroad.data.models.RouteInfo
import com.kingroad.data.models.POI
import com.kingroad.utils.FileCompressor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Classe utilitária para criar imagens/resumos da rota atual para 
 * compartilhamento ou registro posterior.
 *
 * Funcionalidades:
 * - Captura de snapshot do mapa atual
 * - Renderização da rota em uma imagem estática
 * - Adição de marcadores e POIs na imagem
 * - Geração de resumo da rota com distâncias e tempo estimado
 * - Opções para compartilhamento
 */
class RouteSnapshotHelper(private val context: Context) {

    companion object {
        private const val TAG = "RouteSnapshotHelper"
        private const val DEFAULT_WIDTH = 800
        private const val DEFAULT_HEIGHT = 600
        private const val SNAPSHOT_QUALITY = 85
        
        enum class SnapshotSize(val width: Int, val height: Int) {
            SMALL(600, 400),
            MEDIUM(800, 600),
            LARGE(1200, 900),
            SQUARE(800, 800),
            WIDE(1200, 600)
        }
        
        enum class SnapshotType {
            MAP_ONLY,           // Apenas o mapa com a rota
            MAP_WITH_INFO,      // Mapa com informações básicas (distância, tempo)
            FULL_REPORT,        // Relatório completo com mapa, informações e POIs
            TEXT_ONLY           // Apenas texto com informações resumidas
        }
    }
    
    // Cores para uso nos snapshots
    private val routeColor = ContextCompat.getColor(context, R.color.route_color)
    private val markerColor = ContextCompat.getColor(context, R.color.marker_color)
    private val textColor = ContextCompat.getColor(context, R.color.text_color)
    private val backgroundColor = ContextCompat.getColor(context, R.color.background_color)
    
    /**
     * Captura um snapshot do mapa com a rota atual
     * 
     * @param mapView MapView para capturar
     * @param routeInfo Informações da rota a ser desenhada
     * @param size Tamanho do snapshot
     * @param type Tipo de snapshot (apenas mapa, com informações, etc)
     * @param includeMarkers Se deve incluir marcadores de POIs
     * @param outputDir Diretório para salvar o snapshot (opcional)
     * @return Arquivo com a imagem ou null em caso de falha
     */
    suspend fun captureRouteSnapshot(
        mapView: MapView,
        routeInfo: RouteInfo,
        size: SnapshotSize = SnapshotSize.MEDIUM,
        type: SnapshotType = SnapshotType.MAP_WITH_INFO,
        includeMarkers: Boolean = true,
        outputDir: File? = null
    ): File? = withContext(Dispatchers.Main) {
        try {
            Log.d(TAG, "Iniciando captura de snapshot da rota")
            
            // Preparar mapa
            val googleMap = mapView.getMapAsync()
            
            // Ajustar câmera para exibir toda a rota
            val bounds = calculateRouteBounds(routeInfo.waypoints)
            googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
            
            // Adicionar elementos ao mapa
            if (includeMarkers) {
                addMarkersToMap(googleMap, routeInfo.waypoints, routeInfo.pois)
            }
            
            // Fazer snapshot do mapa
            val mapSnapshot = withContext(Dispatchers.IO) {
                googleMap.snapshot { bitmap ->
                    // Esta callback é executada assincronamente
                    // Precisamos tratar o bitmap no callback
                }
                
                // Como o snapshot é assíncrono, esta abordagem não funcionará
                // Vamos usar uma abordagem diferente
                return@withContext captureViewSnapshot(mapView, size.width, size.height)
            }
            
            // Processar o bitmap conforme o tipo de snapshot
            val finalBitmap = when (type) {
                SnapshotType.MAP_ONLY -> mapSnapshot
                SnapshotType.MAP_WITH_INFO -> addBasicInfoToSnapshot(mapSnapshot, routeInfo)
                SnapshotType.FULL_REPORT -> createFullReport(mapSnapshot, routeInfo)
                SnapshotType.TEXT_ONLY -> createTextOnlySummary(routeInfo, size.width, size.height)
            }
            
            // Salvar bitmap para arquivo
            return@withContext withContext(Dispatchers.IO) {
                saveBitmapToFile(finalBitmap, outputDir)
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao capturar snapshot: ${e.message}")
            withContext(Dispatchers.IO) {
                // Se houver erro, tentar criar pelo menos um relatório de texto
                if (type != SnapshotType.TEXT_ONLY) {
                    return@withContext createTextOnlyReport(routeInfo, outputDir)
                }
            }
            return@withContext null
        }
    }
    
    /**
     * Cria um resumo visual rápido da rota atual
     * Versão simplificada que não depende do GoogleMap
     * 
     * @param routeInfo Informações da rota
     * @param width Largura da imagem
     * @param height Altura da imagem
     * @param includeMap Se deve renderizar um mapa simplificado
     * @return Arquivo com a imagem ou null em caso de falha
     */
    suspend fun createQuickRouteSummary(
        routeInfo: RouteInfo,
        width: Int = DEFAULT_WIDTH,
        height: Int = DEFAULT_HEIGHT,
        includeMap: Boolean = true,
        outputDir: File? = null
    ): File? = withContext(Dispatchers.Default) {
        try {
            // Criar bitmap em branco
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            
            // Preencher fundo
            canvas.drawColor(backgroundColor)
            
            // Desenhar mapa simplificado se solicitado
            if (includeMap && routeInfo.waypoints.isNotEmpty()) {
                drawSimplifiedMap(canvas, routeInfo.waypoints, Rect(0, 0, width, height / 2))
            }
            
            // Adicionar informações da rota
            drawRouteInfo(
                canvas, 
                routeInfo,
                Rect(0, includeMap.let { if (it) height / 2 else 0 }, width, height)
            )
            
            // Salvar bitmap para arquivo
            return@withContext saveBitmapToFile(bitmap, outputDir)
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar resumo rápido: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Cria uma imagem com informações da rota para compartilhamento
     * 
     * @param routeInfo Informações da rota
     * @param size Tamanho da imagem
     * @param includeMap Se deve desenhar um mapa simplificado
     * @param includeDriverInfo Se deve incluir informações do motorista
     * @return Arquivo com a imagem pronta para compartilhamento
     */
    suspend fun createRouteShareImage(
        routeInfo: RouteInfo,
        size: SnapshotSize = SnapshotSize.MEDIUM,
        includeMap: Boolean = true,
        includeDriverInfo: Boolean = true
    ): File? = withContext(Dispatchers.Default) {
        try {
            // Criar bitmap em branco
            val bitmap = Bitmap.createBitmap(size.width, size.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            
            // Preencher fundo com cor de marca
            canvas.drawColor(Color.WHITE)
            
            // Desenhar cabeçalho com logo (25% superior)
            drawHeader(canvas, Rect(0, 0, size.width, size.height / 4))
            
            // Dividir o restante do espaço
            val contentHeight = size.height * 3 / 4
            val contentY = size.height / 4
            
            if (includeMap) {
                // Área do mapa (metade do conteúdo)
                val mapRect = Rect(
                    50, 
                    contentY, 
                    size.width - 50, 
                    contentY + contentHeight / 2 - 25
                )
                
                // Desenhar mapa simplificado
                drawSimplifiedMap(canvas, routeInfo.waypoints, mapRect)
                
                // Área de informações (metade inferior do conteúdo)
                val infoRect = Rect(
                    50,
                    contentY + contentHeight / 2 + 25,
                    size.width - 50,
                    size.height - 50
                )
                
                // Desenhar informações da rota
                drawShareableRouteInfo(canvas, routeInfo, infoRect, includeDriverInfo)
            } else {
                // Usar todo o espaço para informações
                val infoRect = Rect(
                    50,
                    contentY + 25,
                    size.width - 50,
                    size.height - 50
                )
                
                // Desenhar informações da rota
                drawShareableRouteInfo(canvas, routeInfo, infoRect, includeDriverInfo)
            }
            
            // Salvar bitmap para arquivo
            return@withContext saveBitmapToFile(bitmap, null, "route_share")
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar imagem para compartilhamento: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Captura um snapshot simples do mapa atual (sem esperar pelo carregamento)
     * 
     * @param mapView View do mapa a ser capturada
     * @return Arquivo com a imagem ou null em caso de falha
     */
    suspend fun captureQuickMapSnapshot(
        mapView: MapView
    ): File? = withContext(Dispatchers.Main) {
        try {
            val bitmap = captureViewSnapshot(mapView, mapView.width, mapView.height)
            
            return@withContext withContext(Dispatchers.IO) {
                saveBitmapToFile(bitmap, null)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao capturar snapshot rápido: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Cria um relatório textual sobre a rota (para casos onde a imagem falha)
     */
    private suspend fun createTextOnlyReport(
        routeInfo: RouteInfo,
        outputDir: File?
    ): File? = withContext(Dispatchers.IO) {
        try {
            // Definir diretório de saída
            val destination = outputDir ?: getSnapshotDirectory()
            if (!destination.exists()) {
                destination.mkdirs()
            }
            
            // Criar nome de arquivo com timestamp
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "route_text_${timestamp}.txt"
            val outputFile = File(destination, fileName)
            
            // Criar conteúdo do relatório
            val content = buildString {
                appendLine("=== RESUMO DA ROTA ===")
                appendLine("Data: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}")
                appendLine("")
                
                appendLine("INFORMAÇÕES BÁSICAS:")
                appendLine("Origem: ${routeInfo.origin}")
                appendLine("Destino: ${routeInfo.destination}")
                appendLine("Distância total: ${formatDistance(routeInfo.distance)}")
                appendLine("Tempo estimado: ${formatDuration(routeInfo.duration)}")
                if (routeInfo.estimatedFuel > 0) {
                    appendLine("Combustível estimado: ${String.format("%.2f", routeInfo.estimatedFuel)} litros")
                }
                appendLine("")
                
                if (routeInfo.waypoints.isNotEmpty()) {
                    appendLine("PONTOS DO TRAJETO:")
                    routeInfo.waypoints.forEachIndexed { index, point ->
                        appendLine("${index + 1}. ${point.latitude}, ${point.longitude}")
                    }
                    appendLine("")
                }
                
                if (routeInfo.pois.isNotEmpty()) {
                    appendLine("PONTOS DE INTERESSE:")
                    routeInfo.pois.forEach { poi ->
                        appendLine("- ${poi.name} (${poi.type})")
                        if (poi.description.isNotBlank()) {
                            appendLine("  ${poi.description}")
                        }
                    }
                }
            }
            
            // Escrever no arquivo
            outputFile.writeText(content)
            
            return@withContext outputFile
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar relatório textual: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Cria uma imagem apenas com texto para resumo da rota
     */
    private fun createTextOnlySummary(
        routeInfo: RouteInfo,
        width: Int,
        height: Int
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        
        // Preencher fundo
        canvas.drawColor(backgroundColor)
        
        // Configurar pincel para texto
        val textPaint = Paint().apply {
            color = textColor
            textSize = 40f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val smallTextPaint = Paint(textPaint).apply {
            textSize = 30f
            isFakeBoldText = false
        }
        
        // Desenhar título
        val title = "RESUMO DA ROTA"
        val titleWidth = textPaint.measureText(title)
        canvas.drawText(title, (width - titleWidth) / 2, 80f, textPaint)
        
        // Linha separadora
        val linePaint = Paint().apply {
            color = textColor
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(50f, 100f, width - 50f, 100f, linePaint)
        
        // Informações básicas
        var y = 160f
        canvas.drawText("Origem: ${routeInfo.origin}", 50f, y, smallTextPaint)
        y += 50
        canvas.drawText("Destino: ${routeInfo.destination}", 50f, y, smallTextPaint)
        y += 50
        canvas.drawText("Distância: ${formatDistance(routeInfo.distance)}", 50f, y, smallTextPaint)
        y += 50
        canvas.drawText("Tempo estimado: ${formatDuration(routeInfo.duration)}", 50f, y, smallTextPaint)
        
        if (routeInfo.estimatedFuel > 0) {
            y += 50
            canvas.drawText(
                "Combustível: ${String.format("%.2f", routeInfo.estimatedFuel)} litros", 
                50f, y, smallTextPaint
            )
        }
        
        // Linha separadora
        y += 70
        canvas.drawLine(50f, y, width - 50f, y, linePaint)
        y += 50
        
        // Pontos de interesse
        if (routeInfo.pois.isNotEmpty()) {
            canvas.drawText("PONTOS DE INTERESSE:", 50f, y, textPaint)
            y += 60
            
            val maxPois = min(routeInfo.pois.size, 5) // Limitar para não ultrapassar a imagem
            for (i in 0 until maxPois) {
                val poi = routeInfo.pois[i]
                canvas.drawText("• ${poi.name} (${poi.type})", 70f, y, smallTextPaint)
                y += 40
            }
            
            if (routeInfo.pois.size > maxPois) {
                canvas.drawText("... e mais ${routeInfo.pois.size - maxPois} pontos", 70f, y, smallTextPaint)
            }
        }
        
        return bitmap
    }
    
    /**
     * Adiciona informações básicas ao snapshot do mapa
     */
    private fun addBasicInfoToSnapshot(
        mapBitmap: Bitmap,
        routeInfo: RouteInfo
    ): Bitmap {
        // Criar nova bitmap com espaço adicional para informações
        val extraHeight = 200
        val resultBitmap = Bitmap.createBitmap(
            mapBitmap.width,
            mapBitmap.height + extraHeight,
            Bitmap.Config.ARGB_8888
        )
        
        val canvas = Canvas(resultBitmap)
        
        // Desenhar mapa
        canvas.drawBitmap(mapBitmap, 0f, 0f, null)
        
        // Desenhar retângulo para informações
        val paint = Paint().apply {
            color = backgroundColor
            style = Paint.Style.FILL
        }
        canvas.drawRect(
            0f,
            mapBitmap.height.toFloat(),
            mapBitmap.width.toFloat(),
            resultBitmap.height.toFloat(),
            paint
        )
        
        // Configurar pincel para texto
        val textPaint = Paint().apply {
            color = textColor
            textSize = 40f
            isAntiAlias = true
        }
        
        // Desenhar informações
        var y = mapBitmap.height + 60f
        
        // Distância
        val distance = "Distância: ${formatDistance(routeInfo.distance)}"
        canvas.drawText(distance, 50f, y, textPaint)
        
        // Tempo
        y += 60
        val time = "Tempo: ${formatDuration(routeInfo.duration)}"
        canvas.drawText(time, 50f, y, textPaint)
        
        // Data/hora
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateText = "Gerado em: ${dateFormat.format(Date())}"
        val dateWidth = textPaint.measureText(dateText)
        
        val smallTextPaint = Paint(textPaint).apply {
            textSize = 30f
        }
        
        canvas.drawText(
            dateText,
            mapBitmap.width - dateWidth - 20f,
            mapBitmap.height + 40f,
            smallTextPaint
        )
        
        return resultBitmap
    }
    
    /**
     * Cria um relatório completo com mapa e informações detalhadas
     */
    private fun createFullReport(
        mapBitmap: Bitmap,
        routeInfo: RouteInfo
    ): Bitmap {
        // Tamanho total do relatório
        val width = mapBitmap.width
        val infoHeight = 500 // Espaço para informações detalhadas
        val height = mapBitmap.height + infoHeight
        
        val resultBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)
        
        // Preencher fundo
        canvas.drawColor(backgroundColor)
        
        // Desenhar título
        val titlePaint = Paint().apply {
            color = textColor
            textSize = 50f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val title = "RELATÓRIO DE ROTA"
        val titleWidth = titlePaint.measureText(title)
        canvas.drawText(title, (width - titleWidth) / 2, 80f, titlePaint)
        
        // Desenhar mapa
        canvas.drawBitmap(mapBitmap, 0f, 120f, null)
        
        // Área de informações
        val infoY = 120 + mapBitmap.height
        
        // Configurar pincel para texto
        val textPaint = Paint().apply {
            color = textColor
            textSize = 35f
            isAntiAlias = true
        }
        
        val smallTextPaint = Paint(textPaint).apply {
            textSize = 30f
        }
        
        // Desenhar informações básicas
        var y = infoY + 60f
        
        // Origem e destino
        canvas.drawText("De: ${routeInfo.origin}", 50f, y, textPaint)
        y += 50
        canvas.drawText("Para: ${routeInfo.destination}", 50f, y, textPaint)
        y += 50
        
        // Distância e tempo
        canvas.drawText(
            "Distância: ${formatDistance(routeInfo.distance)} | " +
                    "Tempo estimado: ${formatDuration(routeInfo.duration)}",
            50f, y, textPaint
        )
        y += 70
        
        // POIs
        if (routeInfo.pois.isNotEmpty()) {
            canvas.drawText("Pontos de Interesse: ${routeInfo.pois.size}", 50f, y, textPaint)
            y += 50
            
            // Listar alguns POIs (até 3)
            val maxPois = min(routeInfo.pois.size, 3)
            for (i in 0 until maxPois) {
                val poi = routeInfo.pois[i]
                canvas.drawText("• ${poi.name} (${poi.type})", 70f, y, smallTextPaint)
                y += 40
            }
            
            if (routeInfo.pois.size > maxPois) {
                canvas.drawText("... e mais ${routeInfo.pois.size - maxPois} pontos", 70f, y, smallTextPaint)
            }
        }
        
        // Data de geração
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateText = "Gerado em: ${dateFormat.format(Date())}"
        
        canvas.drawText(
            dateText,
            50f,
            height - 50f,
            smallTextPaint
        )
        
        return resultBitmap
    }
    
    /**
     * Desenha um mapa simplificado baseado em uma lista de pontos
     */
    private fun drawSimplifiedMap(
        canvas: Canvas,
        waypoints: List<LatLng>,
        rect: Rect
    ) {
        if (waypoints.size < 2) return
        
        // Calcular limites da rota
        var minLat = Double.MAX_VALUE
        var maxLat = Double.MIN_VALUE
        var minLng = Double.MAX_VALUE
        var maxLng = Double.MIN_VALUE
        
        waypoints.forEach { point ->
            minLat = min(minLat, point.latitude)
            maxLat = max(maxLat, point.latitude)
            minLng = min(minLng, point.longitude)
            maxLng = max(maxLng, point.longitude)
        }
        
        // Adicionar margem
        val latMargin = (maxLat - minLat) * 0.1
        val lngMargin = (maxLng - minLng) * 0.1
        
        minLat -= latMargin
        maxLat += latMargin
        minLng -= lngMargin
        maxLng += lngMargin
        
        // Definir função para converter coordenadas para pixels
        fun latLngToPixel(point: LatLng): Pair<Float, Float> {
            val x = ((point.longitude - minLng) / (maxLng - minLng) * rect.width() + rect.left).toFloat()
            val y = ((maxLat - point.latitude) / (maxLat - minLat) * rect.height() + rect.top).toFloat()
            return Pair(x, y)
        }
        
        // Desenhar fundo do mapa
        val backgroundPaint = Paint().apply {
            color = Color.rgb(240, 240, 240) // Cor de fundo do mapa
            style = Paint.Style.FILL
        }
        canvas.drawRect(rect, backgroundPaint)
        
        // Configurar pincel para a rota
        val routePaint = Paint().apply {
            color = routeColor
            strokeWidth = 5f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }
        
        // Desenhar linha da rota
        val path = Path()
        val firstPoint = latLngToPixel(waypoints.first())
        path.moveTo(firstPoint.first, firstPoint.second)
        
        for (i in 1 until waypoints.size) {
            val point = latLngToPixel(waypoints[i])
            path.lineTo(point.first, point.second)
        }
        
        canvas.drawPath(path, routePaint)
        
        // Desenhar marcadores para origem e destino
        val markerPaint = Paint().apply {
            color = markerColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        
        val startPoint = latLngToPixel(waypoints.first())
        val endPoint = latLngToPixel(waypoints.last())
        
        // Origem (círculo verde)
        markerPaint.color = Color.rgb(76, 175, 80)
        canvas.drawCircle(startPoint.first, startPoint.second, 15f, markerPaint)
        
        // Destino (círculo vermelho)
        markerPaint.color = Color.rgb(211, 47, 47)
        canvas.drawCircle(endPoint.first, endPoint.second, 15f, markerPaint)
        
        // Borda do mapa
        val borderPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        canvas.drawRect(rect, borderPaint)
    }
    
    /**
     * Desenha as informações da rota em um canvas
     */
    private fun drawRouteInfo(
        canvas: Canvas,
        routeInfo: RouteInfo,
        rect: Rect
    ) {
        // Configurar pincel para texto
        val titlePaint = Paint().apply {
            color = textColor
            textSize = 40f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val textPaint = Paint(titlePaint).apply {
            textSize = 35f
            isFakeBoldText = false
        }
        
        // Título
        val title = "INFORMAÇÕES DA ROTA"
        val titleWidth = titlePaint.measureText(title)
        canvas.drawText(
            title, 
            rect.left + (rect.width() - titleWidth) / 2, 
            rect.top + 50f, 
            titlePaint
        )
        
        // Informações
        var y = rect.top + 120f
        
        // Origem e destino
        canvas.drawText("Origem: ${routeInfo.origin}", rect.left + 30f, y, textPaint)
        y += 50
        canvas.drawText("Destino: ${routeInfo.destination}", rect.left + 30f, y, textPaint)
        y += 70
        
        // Distância e duração
        val distanceText = "Distância: ${formatDistance(routeInfo.distance)}"
        canvas.drawText(distanceText, rect.left + 30f, y, textPaint)
        y += 50
        
        val durationText = "Tempo estimado: ${formatDuration(routeInfo.duration)}"
        canvas.drawText(durationText, rect.left + 30f, y, textPaint)
        y += 50
        
        // Informações adicionais se disponíveis
        if (routeInfo.estimatedFuel > 0) {
            val fuelText = "Combustível estimado: ${String.format("%.2f", routeInfo.estimatedFuel)} L"
            canvas.drawText(fuelText, rect.left + 30f, y, textPaint)
            y += 50
        }
        
        // Timestamp
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateText = "Gerado em: ${dateFormat.format(Date())}"
        
        val smallTextPaint = Paint(textPaint).apply {
            textSize = 25f
        }
        
        canvas.drawText(
            dateText,
            rect.right - smallTextPaint.measureText(dateText) - 30f,
            rect.bottom - 30f,
            smallTextPaint
        )
    }
    
    /**
     * Desenha informações da rota no formato para compartilhamento
     */
    private fun drawShareableRouteInfo(
        canvas: Canvas,
        routeInfo: RouteInfo,
        rect: Rect,
        includeDriverInfo: Boolean
    ) {
        // Configurar pincel para texto
        val titlePaint = Paint().apply {
            color = Color.rgb(50, 50, 50)
            textSize = 40f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val textPaint = Paint(titlePaint).apply {
            textSize = 35f
            isFakeBoldText = false
        }
        
        val smallTextPaint = Paint(textPaint).apply {
            textSize = 30f
            color = Color.rgb(80, 80, 80)
        }
        
        // Título
        val title = "DETALHES DO TRAJETO"
        val titleWidth = titlePaint.measureText(title)
        canvas.drawText(
            title, 
            rect.left + (rect.width() - titleWidth) / 2, 
            rect.top + 40f, 
            titlePaint
        )
        
        // Informações principais
        var y = rect.top + 120f
        
        // Origem e destino com ícones
        val iconPaint = Paint().apply {
            color = Color.rgb(76, 175, 80) // Verde para origem
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        
        // Ícone de origem (círculo verde)
        canvas.drawCircle(rect.left + 20f, y - 10f, 12f, iconPaint)
        canvas.drawText("Origem: ${routeInfo.origin}", rect.left + 50f, y, textPaint)
        
        y += 60
        
        // Ícone de destino (círculo vermelho)
        iconPaint.color = Color.rgb(211, 47, 47) // Vermelho para destino
        canvas.drawCircle(rect.left + 20f, y - 10f, 12f, iconPaint)
        canvas.drawText("Destino: ${routeInfo.destination}", rect.left + 50f, y, textPaint)
        
        y += 70
        
        // Dados da rota com ícones
        canvas.drawText("${formatDistance(routeInfo.distance)}", rect.left + 50f, y, textPaint)
        y += 50
        canvas.drawText("${formatDuration(routeInfo.duration)}", rect.left + 50f, y, textPaint)
        
        // Informações do motorista se solicitado
        if (includeDriverInfo) {
            y += 70
            
            val driverTitle = "MOTORISTA"
            canvas.drawText(driverTitle, rect.left + (rect.width() - titlePaint.measureText(driverTitle)) / 2, y, titlePaint)
            
            y += 60
            
            // Estas informações viriam do sistema real
            val driverName = "João Silva" // Exemplo
            val driverInfo = "ID: KR12345 - Veículo: ABC-1234" // Exemplo
            
            canvas.drawText(driverName, rect.left + 50f, y, textPaint)
            y += 40
            canvas.drawText(driverInfo, rect.left + 50f, y, smallTextPaint)
        }
        
        // Rodapé com timestamp
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateText = dateFormat.format(Date())
        
        val footerText = "KINGROAD · ${dateText}"
        val footerWidth = smallTextPaint.measureText(footerText)
        
        canvas.drawText(
            footerText,
            rect.left + (rect.width() - footerWidth) / 2,
            rect.bottom - 20f,
            smallTextPaint
        )
    }
    
    /**
     * Desenha o cabeçalho com logo para imagens compartilháveis
     */
    private fun drawHeader(
        canvas: Canvas,
        rect: Rect
    ) {
        // Em um app real, aqui carregaríamos e desenharíamos o logo da empresa
        // Para este exemplo, apenas desenhamos um retângulo com texto
        
        val headerPaint = Paint().apply {
            color = Color.rgb(41, 98, 255) // Azul do KingRoad
            style = Paint.Style.FILL
        }
        
        canvas.drawRect(rect, headerPaint)
        
        // Texto do logotipo
        val logoPaint = Paint().apply {
            color = Color.WHITE
            textSize = 60f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val logoText = "KINGROAD"
        val logoWidth = logoPaint.measureText(logoText)
        
        canvas.drawText(
            logoText,
            rect.left + (rect.width() - logoWidth) / 2,
            rect.top + rect.height() * 0.6f,
            logoPaint
        )
    }
    
    /**
     * Salva um bitmap para um arquivo
     */
    private fun saveBitmapToFile(
        bitmap: Bitmap,
        outputDir: File? = null,
        prefix: String = "route_snapshot"
    ): File {
        // Definir diretório de saída
        val destination = outputDir ?: getSnapshotDirectory()
        if (!destination.exists()) {
            destination.mkdirs()
        }
        
        // Criar nome de arquivo com timestamp
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "${prefix}_${timestamp}.jpg"
        val outputFile = File(destination, fileName)
        
        // Comprimir e salvar
        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, SNAPSHOT_QUALITY, out)
        }
        
        Log.i(TAG, "Snapshot salvo em: ${outputFile.absolutePath}")
        
        return outputFile
    }
    
    /**
     * Captura bitmap de uma view
     */
    private fun captureViewSnapshot(view: View, width: Int, height: Int): Bitmap {
        // Se a view ainda não estiver medida, configurar layout params
        if (view.width == 0 || view.height == 0) {
            view.layoutParams = FrameLayout.LayoutParams(width, height)
            view.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
            )
            view.layout(0, 0, width, height)
        }
        
        // Criar bitmap e canvas
        val bitmap = Bitmap.createBitmap(
            max(width, view.width),
            max(height, view.height),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        
        // Desenhar a view no canvas
        view.draw(canvas)
        
        return bitmap
    }
    
    /**
     * Adiciona marcadores ao mapa para origem, destino e POIs
     */
    private suspend fun addMarkersToMap(
        map: GoogleMap,
        waypoints: List<LatLng>,
        pois: List<POI>
    ) = withContext(Dispatchers.Main) {
        // Em uma implementação real, aqui adicionaríamos marcadores ao mapa
        // usando o GoogleMap. Como este é um exemplo simplificado, apenas
        // simulamos essa funcionalidade.
        
        // Exemplo de como seria:
        // if (waypoints.isNotEmpty()) {
        //     map.addMarker(MarkerOptions().position(waypoints.first()).title("Origem"))
        //     map.addMarker(MarkerOptions().position(waypoints.last()).title("Destino"))
        // }
        //
        // for (poi in pois) {
        //     map.addMarker(MarkerOptions().position(poi.location).title(poi.name))
        // }
    }
    
    /**
     * Calcula os limites da rota para ajustar a câmera do mapa
     */
    private fun calculateRouteBounds(waypoints: List<LatLng>): LatLngBounds {
        val builder = LatLngBounds.builder()
        
        for (point in waypoints) {
            builder.include(point)
        }
        
        return builder.build()
    }
    
    /**
     * Aguarda o mapa ser carregado e retorna a instância do GoogleMap
     * Note: Em um app real, você usaria o callback padrão do GoogleMap
     */
    private suspend fun MapView.getMapAsync(): GoogleMap = suspendCancellableCoroutine { continuation ->
        // Em um código real, usaríamos:
        // this.getMapAsync { googleMap ->
        //     continuation.resume(googleMap)
        // }
        
        // Como isso é apenas um exemplo, vamos simular o retorno
        // Em um app real, você nunca faria isso
        continuation.resume(GoogleMap::class.java.newInstance())
    }
    
    /**
     * Obtém o diretório para salvar snapshots
     */
    private fun getSnapshotDirectory(): File {
        val baseDir = if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
            context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                ?: context.filesDir
        } else {
            context.filesDir
        }
        
        return File(baseDir, "route_snapshots")
    }
    
    /**
     * Formata a distância em formato legível
     */
    private fun formatDistance(meters: Double): String {
        return if (meters >= 1000) {
            String.format("%.1f km", meters / 1000)
        } else {
            String.format("%d m", meters.toInt())
        }
    }
    
    /**
     * Formata a duração em formato legível
     */
    private fun formatDuration(seconds: Int): String {
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        
        return when {
            hours > 0 -> String.format("%dh %02dmin", hours, minutes)
            else -> String.format("%d min", minutes)
        }
    }
    
    /**
     * Comprime o snapshot usando FileCompressor
     */
    suspend fun compressSnapshotIfNeeded(
        snapshotFile: File,
        maxSizeKB: Int = 500
    ): File = withContext(Dispatchers.IO) {
        // Se o arquivo já é menor que o limite, retorna o original
        if (snapshotFile.length() <= maxSizeKB * 1024L) {
            return@withContext snapshotFile
        }
        
        try {
            // Usar o FileCompressor para reduzir o tamanho
            val compressor = FileCompressor(context)
            val compressed = compressor.getCompressedForUpload(snapshotFile, maxSizeKB)
            
            return@withContext compressed ?: snapshotFile
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao comprimir snapshot: ${e.message}")
            return@withContext snapshotFile
        }
    }
}