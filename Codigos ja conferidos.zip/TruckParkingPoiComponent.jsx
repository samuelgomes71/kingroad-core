// web/src/components/poi/TruckParkingPoiComponent.jsx

import React, { useState, useEffect } from 'react';
import { ParkingIcon, CameraIcon, StarIcon, PlusIcon, ThumbUpIcon, TrashIcon } from '../icons/MapIcons';
import { useMapContext } from '../../contexts/MapContext';
import { usePersonalParkingPois } from '../../hooks/usePersonalParkingPois';
import { usePoiRequests } from '../../hooks/usePoiRequests';
import { useTranslation } from '../../hooks/useTranslation';
import { useNotification } from '../../hooks/useNotification';
import { useAuth } from '../../contexts/AuthContext';
import { formatDate } from '../../utils/dateUtils';

/**
 * Componente para exibição e gestão de POIs de estacionamento de caminhões
 * Implementação para o KingRoad - Frontend React
 */
const TruckParkingPoiComponent = () => {
  const { t } = useTranslation('pois');
  const { currentLocation, map, addMarkerToMap, clearMarkers } = useMapContext();
  const { 
    personalParkingPois,
    isLoadingPersonal,
    addPersonalParkingPoi,
    updatePersonalParkingPoi,
    deletePersonalParkingPoi,
    markAsInaccessible,
    refreshPersonalPois,
    attachPhotoToPersonalPoi,
    updateRating,
    updateLastVisit
  } = usePersonalParkingPois();
  
  const {
    nearbyRequests,
    isLoadingRequests,
    requestNewOfficialPoi,
    requestFromPersonalPoi,
    attachPhotoToRequest,
    voteForRequest,
    refreshNearbyRequests
  } = usePoiRequests();
  
  const { showSuccess, showError, showConfirm } = useNotification();
  const { isAuthenticated, currentUser } = useAuth();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showRequestsTab, setShowRequestsTab] = useState(false);
  const [selectedPoi, setSelectedPoi] = useState(null);
  const [formMode, setFormMode] = useState('add'); // 'add' ou 'edit'
  
  // Carregar POIs quando a localização muda
  useEffect(() => {
    if (currentLocation && isAuthenticated) {
      refreshPersonalPois(currentLocation);
      refreshNearbyRequests(currentLocation);
    }
  }, [currentLocation, isAuthenticated, refreshPersonalPois, refreshNearbyRequests]);
  
  // Atualizar marcadores no mapa quando os POIs mudam
  useEffect(() => {
    if (!map || isLoadingPersonal) return;
    
    clearMarkers();
    
    // Adiciona POIs pessoais ao mapa
    personalParkingPois.forEach(poi => {
      addMarkerToMap({
        location: poi.location,
        type: 'personalParking',
        title: poi.name,
        subtitle: generateSubtitle(poi),
        onClick: () => handlePersonalPoiClick(poi),
        color: poi.isAccessible ? '#FFD700' : '#999999' // Dourado para POIs ativos, cinza para inacessíveis
      });
    });
    
    // Adiciona solicitações ao mapa se estiver na aba de solicitações
    if (showRequestsTab) {
      nearbyRequests.forEach(request => {
        addMarkerToMap({
          location: request.location,
          type: 'parkingRequest',
          title: request.name,
          subtitle: `${t('votes')}: ${request.votes}`,
          onClick: () => handleRequestClick(request),
          color: '#1E90FF' // Azul para solicitações
        });
      });
    }
  }, [personalParkingPois, nearbyRequests, map, isLoadingPersonal, showRequestsTab, addMarkerToMap, clearMarkers]);
  
  // Gera subtítulo para o marcador
  const generateSubtitle = (poi) => {
    const parts = [];
    
    if (poi.rating > 0) {
      parts.push(`★ ${poi.rating}/5`);
    }
    
    if (!poi.isFree && poi.price) {
      parts.push(`${poi.price.toFixed(2)}`);
    }
    
    if (poi.hasFacilities) {
      parts.push(t('facilities'));
    }
    
    return parts.join(' • ');
  };
  
  // Manipula clique em um POI pessoal
  const handlePersonalPoiClick = (poi) => {
    setSelectedPoi(poi);
    updateLastVisit(poi.id);
  };
  
  // Manipula clique em uma solicitação
  const handleRequestClick = (request) => {
    setSelectedPoi(request);
  };
  
  // Inicia adição de novo POI
  const handleAddPoi = () => {
    if (!isAuthenticated) {
      showError(t('loginRequired'));
      return;
    }
    
    setFormMode('add');
    setSelectedPoi(null);
    setShowAddForm(true);
  };
  
  // Inicia edição de POI existente
  const handleEditPoi = (poi) => {
    setFormMode('edit');
    setSelectedPoi(poi);
    setShowAddForm(true);
  };
  
  // Exclui um POI
  const handleDeletePoi = (poiId) => {
    showConfirm(
      t('confirmDeletePoi'),
      t('deletePoiWarning'),
      async () => {
        const success = await deletePersonalParkingPoi(poiId);
        if (success) {
          showSuccess(t('poiDeleted'));
          setSelectedPoi(null);
          refreshPersonalPois(currentLocation);
        } else {
          showError(t('deletePoiError'));
        }
      }
    );
  };
  
  // Marca um POI como inacessível
  const handleMarkInaccessible = (poiId) => {
    showConfirm(
      t('confirmMarkInaccessible'),
      t('markInaccessibleWarning'),
      async () => {
        const success = await markAsInaccessible(poiId);
        if (success) {
          showSuccess(t('poiMarkedInaccessible'));
          refreshPersonalPois(currentLocation);
          
          // Atualiza o POI selecionado se for o mesmo
          if (selectedPoi && selectedPoi.id === poiId) {
            setSelectedPoi({...selectedPoi, isAccessible: false});
          }
        } else {
          showError(t('markInaccessibleError'));
        }
      }
    );
  };
  
  // Solicita adição oficial de um POI
  const handleRequestOfficial = (poi) => {
    showConfirm(
      t('confirmRequestOfficial'),
      t('requestOfficialDescription'),
      async () => {
        const success = await requestFromPersonalPoi(poi.id);
        if (success) {
          showSuccess(t('requestSubmitted'));
          refreshNearbyRequests(currentLocation);
        } else {
          showError(t('requestError'));
        }
      }
    );
  };
  
  // Vota em uma solicitação
  const handleVoteForRequest = async (requestId) => {
    if (!isAuthenticated) {
      showError(t('loginRequired'));
      return;
    }
    
    const success = await voteForRequest(requestId);
    if (success) {
      showSuccess(t('voteRegistered'));
      refreshNearbyRequests(currentLocation);
      
      // Atualiza o POI selecionado se for o mesmo
      if (selectedPoi && selectedPoi.id === requestId) {
        setSelectedPoi({...selectedPoi, votes: (selectedPoi.votes || 0) + 1});
      }
    } else {
      showError(t('voteError'));
    }
  };
  
  // Tira uma foto para um POI
  const handleTakePhoto = async (poi, isRequest = false) => {
    if (!isAuthenticated) {
      showError(t('loginRequired'));
      return;
    }
    
    try {
      const photoPath = await navigator.camera.takePicture({
        quality: 70,
        destinationType: Camera.DestinationType.FILE_URI
      });
      
      let success;
      if (isRequest) {
        success = await attachPhotoToRequest(poi.id, photoPath);
      } else {
        success = await attachPhotoToPersonalPoi(poi.id, photoPath);
      }
      
      if (success) {
        showSuccess(t('photoAdded'));
        
        // Recarrega os dados
        if (isRequest) {
          refreshNearbyRequests(currentLocation);
        } else {
          refreshPersonalPois(currentLocation);
        }
      } else {
        showError(t('photoError'));
      }
    } catch (error) {
      console.error('Camera error:', error);
      showError(t('cameraError'));
    }
  };
  
  // Atualiza a classificação de um POI
  const handleRatingChange = async (poiId, newRating) => {
    const success = await updateRating(poiId, newRating);
    if (success) {
      // Atualiza o POI selecionado se for o mesmo
      if (selectedPoi && selectedPoi.id === poiId) {
        setSelectedPoi({...selectedPoi, rating: newRating});
      }
      
      refreshPersonalPois(currentLocation);
    } else {
      showError(t('ratingUpdateError'));
    }
  };
  
  // Alterna entre visualização pessoal e solicitações
  const toggleViewMode = () => {
    setShowRequestsTab(!showRequestsTab);
    setSelectedPoi(null);
  };
  
  // Renderiza a guia de POIs pessoais
  const renderPersonalTab = () => (
    <div className="personal-poi-tab">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-amber-500">{t('myParkingSpots')}</h2>
        
        <button
          className="bg-amber-500 text-black px-3 py-1 rounded-lg flex items-center"
          onClick={handleAddPoi}
        >
          <PlusIcon className="w-4 h-4 mr-1" />
          {t('addParking')}
        </button>
      </div>
      
      {isLoadingPersonal ? (
        <div className="loading-indicator">
          <span className="loading-spinner"></span>
          <p>{t('loadingPois')}</p>
        </div>
      ) : personalParkingPois.length === 0 ? (
        <div className="empty-state">
          <ParkingIcon className="w-16 h-16 text-gray-500 mx-auto mb-2" />
          <p className="text-center text-gray-400">{t('noPersonalParkingSpotsFound')}</p>
          <button
            className="bg-amber-500 text-black px-3 py-1 rounded-lg flex items-center mx-auto mt-3"
            onClick={handleAddPoi}
          >
            <PlusIcon className="w-4 h-4 mr-1" />
            {t('addYourFirst')}
          </button>
        </div>
      ) : (
        <div className="personal-poi-list space-y-3">
          {personalParkingPois.map(poi => (
            <div 
              key={poi.id}
              className={`personal-poi-item p-3 rounded-lg cursor-pointer ${
                selectedPoi && selectedPoi.id === poi.id 
                  ? 'bg-gray-700 border border-amber-500' 
                  : 'bg-gray-800 hover:bg-gray-700'
              } ${!poi.isAccessible ? 'opacity-60' : ''}`}
              onClick={() => handlePersonalPoiClick(poi)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-white">
                    {poi.name}
                    {!poi.isAccessible && (
                      <span className="ml-2 text-xs text-red-400">({t('inaccessible')})</span>
                    )}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {poi.surfaceType !== 'UNKNOWN' ? t(`surfaceType_${poi.surfaceType.toLowerCase()}`) : ''}
                    {poi.sizeCategory !== 'UNKNOWN' ? ` • ${t(`sizeCategory_${poi.sizeCategory.toLowerCase()}`)}` : ''}
                  </p>
                </div>
                <div className="rating">
                  {[1, 2, 3, 4, 5].map(star => (
                    <StarIcon 
                      key={star}
                      className={`w-4 h-4 inline-block ${
                        star <= poi.rating ? 'text-amber-500' : 'text-gray-600'
                      }`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRatingChange(poi.id, star);
                      }}
                    />
                  ))}
                </div>
              </div>
              
              {/* Informações adicionais quando selecionado */}
              {selectedPoi && selectedPoi.id === poi.id && (
                <div className="poi-details mt-3 pt-3 border-t border-gray-700">
                  {poi.lastVisitDate && (
                    <p className="text-xs text-gray-400 mb-2">
                      {t('lastVisit')}: {formatDate(poi.lastVisitDate)}
                    </p>
                  )}
                  
                  {poi.notes && (
                    <p className="text-sm mb-2">{poi.notes}</p>
                  )}
                  
                  <div className="flex flex-wrap gap-2 text-xs text-white mb-3">
                    {!poi.isFree && poi.price && (
                      <span className="bg-purple-900 px-2 py-1 rounded">
                        {t('price')}: {poi.price.toFixed(2)}
                      </span>
                    )}
                    
                    {poi.hasFacilities && (
                      <span className="bg-blue-900 px-2 py-1 rounded">
                        {t('hasFacilities')}
                      </span>
                    )}
                    
                    {poi.hasRestaurant && (
                      <span className="bg-green-900 px-2 py-1 rounded">
                        {t('hasRestaurant')}
                      </span>
                    )}
                    
                    {poi.securityLevel !== 'UNKNOWN' && (
                      <span className="bg-amber-900 px-2 py-1 rounded">
                        {t(`security_${poi.securityLevel.toLowerCase()}`)}
                      </span>
                    )}
                  </div>
                  
                  <div className="action-buttons flex mt-3 space-x-2">
                    <button
                      className="flex-1 py-1 bg-amber-500 text-black rounded"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTakePhoto(poi);
                      }}
                    >
                      <CameraIcon className="w-4 h-4 inline-block mr-1" />
                      {t('addPhoto')}
                    </button>
                    
                    <button
                      className="flex-1 py-1 bg-blue-500 text-white rounded"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRequestOfficial(poi);
                      }}
                    >
                      <ThumbUpIcon className="w-4 h-4 inline-block mr-1" />
                      {t('requestOfficial')}
                    </button>
                    
                    {poi.isAccessible && (
                      <button
                        className="flex-1 py-1 bg-gray-600 text-white rounded"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMarkInaccessible(poi.id);
                        }}
                      >
                        {t('markClosed')}
                      </button>
                    )}
                    
                    <button
                      className="py-1 px-2 bg-red-700 text-white rounded"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeletePoi(poi.id);
                      }}
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
  
  // Renderiza a guia de solicitações
  const renderRequestsTab = () => (
    <div className="requests-tab">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-amber-500">{t('parkingSpotRequests')}</h2>
      </div>
      
      {isLoadingRequests ? (
        <div className="loading-indicator">
          <span className="loading-spinner"></span>
          <p>{t('loadingRequests')}</p>
        </div>
      ) : nearbyRequests.length === 0 ? (
        <div className="empty-state">
          <p className="text-center text-gray-400">{t('noNearbyRequests')}</p>
        </div>
      ) : (
        <div className="requests-list space-y-3">
          {nearbyRequests.map(request => (
            <div 
              key={request.id}
              className={`request-item p-3 rounded-lg cursor-pointer ${
                selectedPoi && selectedPoi.id === request.id 
                  ? 'bg-gray-700 border border-blue-500' 
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
              onClick={() => handleRequestClick(request)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-white">{request.name}</h3>
                  <p className="text-sm text-gray-400">
                    {request.surfaceType !== 'UNKNOWN' ? t(`surfaceType_${request.surfaceType.toLowerCase()}`) : ''}
                    {request.sizeCategory !== 'UNKNOWN' ? ` • ${t(`sizeCategory_${request.sizeCategory.toLowerCase()}`)}` : ''}
                  </p>
                </div>
                <div className="votes bg-blue-900 px-2 py-1 rounded">
                  <ThumbUpIcon className="w-4 h-4 inline-block mr-1 text-blue-300" />
                  <span>{request.votes}</span>
                </div>
              </div>
              
              {/* Informações adicionais quando selecionado */}
              {selectedPoi && selectedPoi.id === request.id && (
                <div className="request-details mt-3 pt-3 border-t border-gray-700">
                  <p className="text-xs text-gray-400 mb-2">
                    {t('requestDate')}: {formatDate(request.submissionDate)}
                  </p>
                  
                  {request.description && (
                    <p className="text-sm mb-2">{request.description}</p>
                  )}
                  
                  <div className="flex flex-wrap gap-2 text-xs text-white mb-3">
                    {!request.isFree && request.price && (
                      <span className="bg-purple-900 px-2 py-1 rounded">
                        {t('price')}: {request.price.toFixed(2)}
                      </span>
                    )}
                    
                    {request.hasFacilities && (
                      <span className="bg-blue-900 px-2 py-1 rounded">
                        {t('hasFacilities')}
                      </span>
                    )}
                    
                    {request.hasRestaurant && (
                      <span className="bg-green-900 px-2 py-1 rounded">
                        {t('hasRestaurant')}
                      </span>
                    )}
                    
                    {request.securityLevel !== 'UNKNOWN' && (
                      <span className="bg-amber-900 px-2 py-1 rounded">
                        {t(`security_${request.securityLevel.toLowerCase()}`)}
                      </span>
                    )}
                  </div>
                  
                  <div className="action-buttons flex mt-3">
                    <button
                      className="flex-1 py-1 bg-blue-500 text-white rounded"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleVoteForRequest(request.id);
                      }}
                    >
                      <ThumbUpIcon className="w-4 h-4 inline-block mr-1" />
                      {t('voteForThis')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
  
  return (
    <div className="truck-parking-poi-container bg-black text-white">
      {/* Abas de navegação */}
      <div className="tab-navigation flex mb-4 border-b border-gray-800">
        <button
          className={`flex-1 py-2 ${!showRequestsTab ? 'text-amber-500 border-b-2 border-amber-500' : 'text-gray-400'}`}
          onClick={() => toggleViewMode()}
          disabled={!showRequestsTab}
        >
          {t('myParkingSpots')}
        </button>
        <button
          className={`flex-1 py-2 ${showRequestsTab ? 'text-amber-500 border-b-2 border-amber-500' : 'text-gray-400'}`}
          onClick={() => toggleViewMode()}
          disabled={showRequestsTab}
        >
          {t('communityRequests')}
        </button>
      </div>
      
      {/* Conteúdo baseado na aba selecionada */}
      {showRequestsTab ? renderRequestsTab() : renderPersonalTab()}
      
      {/* Botão flutuante para adicionar novo POI (apenas na visualização pessoal) */}
      {!showRequestsTab && (
        <button 
          className="add-poi-button fixed bottom-6 right-6 bg-amber-500 hover:bg-amber-600 text-black rounded-full p-4 shadow-lg"
          onClick={handleAddPoi}
        >
          <PlusIcon className="w-6 h-6" />
        </button>
      )}
      
      {/* Formulário de adição/edição de POI (como modal) */}
      {showAddForm && (
        <AddParkingPoiForm 
          mode={formMode}
          poi={selectedPoi}
          onClose={() => setShowAddForm(false)}
          onSave={(newPoi) => {
            if (formMode === 'add') {
              addPersonalParkingPoi(newPoi);
            } else {
              updatePersonalParkingPoi(newPoi);
            }
            setShowAddForm(false);
            refreshPersonalPois(currentLocation);
          }}
        />
      )}
    </div>
  );
};

// Stub para o formulário de adição/edição que seria implementado como componente separado
const AddParkingPoiForm = ({ mode, poi, onClose, onSave }) => {
  // Implementação básica - poderia ser movida para um componente separado
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <h2>{mode === 'add' ? 'Add Parking Spot' : 'Edit Parking Spot'}</h2>
        {/* Formulário aqui */}
        <div className="flex justify-end mt-4">
          <button className="mr-2" onClick={onClose}>Cancel</button>
          <button onClick={() => onSave({})}>Save</button>
        </div>
      </div>
    </div>
  );
};

export default TruckParkingPoiComponent;