/**
 * MapQuickReports.js
 * 
 * Componente para criação rápida de relatórios no mapa
 * Permite aos usuários reportar problemas e condições na estrada rapidamente
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Modal,
  TextInput,
  Image,
  ActivityIndicator,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useTheme } from '../contexts/ThemeContext';
import * as Location from 'expo-location';
import * as Haptics from 'expo-haptics';

// Importar serviços
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import ReportService from '../services/ReportService';

// Tipos de relatórios rápidos disponíveis
const REPORT_TYPES = [
  {
    id: 'traffic',
    icon: 'traffic',
    color: '#F44336',
  },
  {
    id: 'accident',
    icon: 'car-crash',
    color: '#E53935',
  },
  {
    id: 'police',
    icon: 'local-police',
    color: '#3F51B5',
  },
  {
    id: 'hazard',
    icon: 'warning',
    color: '#FF9800',
  },
  {
    id: 'closure',
    icon: 'block',
    color: '#795548',
  },
  {
    id: 'construction',
    icon: 'construction',
    color: '#FFC107',
  },
  {
    id: 'fog',
    icon: 'cloud',
    color: '#78909C',
  },
  {
    id: 'ice',
    icon: 'ac-unit',
    color: '#90CAF9',
  }
];

const MapQuickReports = ({ onClose, onReportSubmit, currentLocation }) => {
  const { theme } = useTheme();
  const [visible, setVisible] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [reportLocation, setReportLocation] = useState(null);
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [animation] = useState(new Animated.Value(0));
  
  // Anima a entrada do componente
  useEffect(() => {
    setVisible(true);
    
    Animated.timing(animation, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true
    }).start();
    
    // Obter localização atual se não fornecida
    if (!currentLocation) {
      getCurrentLocation();
    } else {
      setReportLocation(currentLocation);
    }
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Atualização de interface se necessário ao mudar idioma
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);
  
  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        Alert.alert(
          t('alert.error'),
          t('error.location_permission'),
          [{ text: t('button.ok') }]
        );
        return;
      }
      
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High
      });
      
      setReportLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        accuracy: location.coords.accuracy
      });
    } catch (error) {
      console.error('Error getting location:', error);
      Alert.alert(
        t('alert.error'),
        t('error.location_unavailable'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleClose = () => {
    Animated.timing(animation, {
      toValue: 0,
      duration: 200,
      useNativeDriver: true
    }).start(() => {
      setVisible(false);
      onClose && onClose();
    });
  };
  
  const handleTypeSelect = (type) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedType(type);
  };
  
  const handleSubmit = async () => {
    if (!selectedType) {
      Alert.alert(
        t('alert.validation_error'),
        t('component.map_reports.select_report_type'),
        [{ text: t('button.ok') }]
      );
      return;
    }
    
    if (!reportLocation) {
      Alert.alert(
        t('alert.validation_error'),
        t('component.map_reports.location_required'),
        [{ text: t('button.ok') }]
      );
      return;
    }
    
    setSubmitting(true);
    
    try {
      // Criar objeto do relatório
      const report = {
        type: selectedType.id,
        location: reportLocation,
        description: description.trim() || t('component.map_reports.default_description', { type: getReportTypeLabel(selectedType.id) }),
        timestamp: new Date().toISOString(),
        anonymous: false // Por padrão, não é anônimo
      };
      
      // Enviar relatório
      await ReportService.submitQuickReport(report);
      
      setSubmitting(false);
      setShowConfirmation(true);
      
      // Fechar confirmação após alguns segundos
      setTimeout(() => {
        setShowConfirmation(false);
        handleClose();
        onReportSubmit && onReportSubmit(report);
      }, 2000);
      
      // Feedback tátil de sucesso
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error('Error submitting report:', error);
      setSubmitting(false);
      
      Alert.alert(
        t('alert.error'),
        t('error.report_submission'),
        [{ text: t('button.ok') }]
      );
      
      // Feedback tátil de erro
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };
  
  const getReportTypeLabel = (typeId) => {
    const labels = {
      'traffic': t('component.map_reports.type_traffic'),
      'accident': t('component.map_reports.type_accident'),
      'police': t('component.map_reports.type_police'),
      'hazard': t('component.map_reports.type_hazard'),
      'closure': t('component.map_reports.type_closure'),
      'construction': t('component.map_reports.type_construction'),
      'fog': t('component.map_reports.type_fog'),
      'ice': t('component.map_reports.type_ice')
    };
    
    return labels[typeId] || typeId;
  };
  
  if (!visible) return null;
  
  return (
    <Modal
      transparent
      visible={visible}
      animationType="none"
      onRequestClose={handleClose}
    >
      <View style={styles.modalContainer}>
        <Animated.View 
          style={[
            styles.contentContainer,
            { 
              backgroundColor: theme.card,
              opacity: animation,
              transform: [
                {
                  translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [50, 0]
                  })
                }
              ]
            }
          ]}
        >
          {/* Cabeçalho */}
          <View style={styles.header}>
            <Text style={[styles.title, { color: theme.text }]}>
              {t('component.map_reports.title')}
            </Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={handleClose}
            >
              <Icon name="close" size={24} color={theme.textSecondary} />
            </TouchableOpacity>
          </View>
          
          {/* Localização atual */}
          <View style={[styles.locationContainer, { backgroundColor: theme.cardLight }]}>
            <Icon name="my-location" size={18} color={theme.primary} />
            <Text style={[styles.locationText, { color: theme.text }]}>
              {reportLocation 
                ? t('component.map_reports.current_location')
                : t('component.map_reports.getting_location')}
            </Text>
            
            {!reportLocation && (
              <ActivityIndicator size="small" color={theme.primary} />
            )}
            
            {reportLocation && (
              <Text style={[styles.accuracyText, { color: theme.textSecondary }]}>
                {reportLocation.accuracy
                  ? t('component.map_reports.location_accuracy', { 
                      accuracy: RegionalSettingsService.formatDistance(reportLocation.accuracy / 1000) 
                    })
                  : ''}
              </Text>
            )}
          </View>
          
          {/* Tipos de relatórios */}
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('component.map_reports.report_type')}
          </Text>
          
          <View style={styles.reportTypesContainer}>
            {REPORT_TYPES.map(type => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.typeButton,
                  selectedType && selectedType.id === type.id && {
                    backgroundColor: `${type.color}33`, // Adiciona transparência
                    borderColor: type.color
                  },
                  { borderColor: theme.border }
                ]}
                onPress={() => handleTypeSelect(type)}
              >
                <Icon 
                  name={type.icon} 
                  size={24} 
                  color={type.color} 
                />
                <Text 
                  style={[
                    styles.typeText, 
                    { color: theme.text },
                    selectedType && selectedType.id === type.id && { color: type.color }
                  ]}
                >
                  {getReportTypeLabel(type.id)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          
          {/* Campo de descrição */}
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('component.map_reports.description')}
          </Text>
          
          <TextInput
            style={[
              styles.descriptionInput,
              { 
                color: theme.text,
                backgroundColor: theme.inputBackground,
                borderColor: theme.border
              }
            ]}
            placeholder={t('component.map_reports.description_placeholder')}
            placeholderTextColor={theme.textSecondary}
            value={description}
            onChangeText={setDescription}
            multiline
            maxLength={100}
          />
          
          {/* Informação sobre privacidade */}
          <Text style={[styles.privacyText, { color: theme.textSecondary }]}>
            {t('component.map_reports.privacy_info')}
          </Text>
          
          {/* Botão de envio */}
          <TouchableOpacity
            style={[
              styles.submitButton,
              { backgroundColor: theme.primary },
              (!selectedType || !reportLocation || submitting) && { opacity: 0.5 }
            ]}
            onPress={handleSubmit}
            disabled={!selectedType || !reportLocation || submitting}
          >
            {submitting ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <>
                <Icon name="send" size={20} color="white" style={styles.submitIcon} />
                <Text style={styles.submitText}>
                  {t('button.submit_report')}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </Animated.View>
        
        {/* Modal de confirmação */}
        {showConfirmation && (
          <View style={styles.confirmationContainer}>
            <View style={[styles.confirmationContent, { backgroundColor: theme.successLight }]}>
              <Icon name="check-circle" size={40} color={theme.success} />
              <Text style={[styles.confirmationText, { color: theme.darkText }]}>
                {t('component.map_reports.report_submitted')}
              </Text>
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 20
  },
  contentContainer: {
    width: '100%',
    borderRadius: 12,
    padding: 16,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    maxHeight: '90%'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold'
  },
  closeButton: {
    padding: 4
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16
  },
  locationText: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14
  },
  accuracyText: {
    fontSize: 12,
    marginLeft: 4
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8
  },
  reportTypesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 16
  },
  typeButton: {
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 8
  },
  typeText: {
    marginLeft: 8,
    fontSize: 14
  },
  descriptionInput: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    minHeight: 80,
    textAlignVertical: 'top',
    marginBottom: 16
  },
  privacyText: {
    fontSize: 12,
    fontStyle: 'italic',
    marginBottom: 16,
    textAlign: 'center'
  },
  submitButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 14,
    borderRadius: 8
  },
  submitIcon: {
    marginRight: 8
  },
  submitText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500'
  },
  confirmationContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)'
  },
  confirmationContent: {
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },
  confirmationText: {
    marginTop: 8,
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center'
  }
});

export default MapQuickReports;