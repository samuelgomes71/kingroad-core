// POIDetails.jsx
import React from 'react';
import { ChevronRight, Star, Navigation, Clipboard } from 'lucide-react';
import { getParkingStatusColor, renderAmenityIcon } from '../utils/uiHelpers';
import { reviews, parkingHistory } from '../data/poiData';

const POIDetails = ({ poi, onBack }) => {
  if (!poi) return null;
  
  return (
    <div className="bg-stone-900 rounded-lg overflow-hidden h-full flex flex-col">
      <div className="bg-stone-800 px-4 py-3 flex justify-between items-center">
        <button 
          className="text-white p-1"
          onClick={onBack}
        >
          <ChevronRight className="transform rotate-180" size={24} />
        </button>
        <h2 className="text-white font-bold">{poi.name}</h2>
        <div className="w-8"></div>
      </div>
      
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Status atual e classificação */}
        <div className="flex justify-between">
          <div className="flex items-center">
            <Star size={20} className="text-amber-400 mr-1" />
            <span className="text-white font-bold text-xl">{poi.rating}</span>
            <span className="text-stone-400 text-sm ml-1">({poi.reviews})</span>
          </div>
          <div className={`px-3 py-1 rounded-md text-white ${getParkingStatusColor(poi.parking)}`}>
            {poi.parking === 'many' ? 'VAGAS DISPONÍVEIS' : 
             poi.parking === 'some' ? 'POUCAS VAGAS' : 'LOTADO'}
          </div>
        </div>
        
        {/* Informações */}
        <div className="bg-stone-800 rounded-lg p-3">
          <h3 className="text-amber-300 font-bold mb-2">Informações</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-stone-300">Rodovia:</span>
              <span className="text-white">{poi.direction || poi.highway}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-300">Localização:</span>
              <span className="text-white">{poi.city || 'Brasil'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-300">Distância:</span>
              <span className="text-white">{poi.distance} km</span>
            </div>
            {poi.security && (
              <div className="flex justify-between">
                <span className="text-stone-300">Segurança:</span>
                <span className={`${
                  poi.security === 'high' ? 'text-emerald-500' : 
                  poi.security === 'medium' ? 'text-amber-500' : 'text-red-500'
                }`}>
                  {poi.security === 'high' ? 'Alta' : 
                   poi.security === 'medium' ? 'Média' : 'Baixa'}
                </span>
              </div>
            )}
          </div>
        </div>
        
        {/* Comodidades (apenas para truck stops) */}
        {poi.amenities && (
          <div className="bg-stone-800 rounded-lg p-3">
            <h3 className="text-amber-300 font-bold mb-2">Comodidades</h3>
            <div className="grid grid-cols-3 gap-3">
              {poi.amenities.map((amenity, idx) => (
                <div key={idx} className="flex items-center bg-stone-700 rounded-lg p-2">
                  <div className="mr-2 text-amber-300">
                    {renderAmenityIcon(amenity)}
                  </div>
                  <span className="text-white text-sm capitalize">
                    {amenity === 'restaurant' ? 'Restaurante' :
                     amenity === 'shower' ? 'Chuveiro' :
                     amenity === 'wifi' ? 'Wi-Fi' :
                     amenity === 'fuel' ? 'Combustível' :
                     amenity === 'mechanic' ? 'Mecânico' :
                     amenity === 'atm' ? 'Caixa Eletrônico' :
                     amenity === 'laundry' ? 'Lavanderia' : amenity}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Histórico de ocupação */}
        <div className="bg-stone-800 rounded-lg p-3">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-amber-300 font-bold">Histórico de Ocupação</h3>
            <button className="text-amber-400 flex items-center text-sm">
              Ver completo <ChevronRight size={16} />
            </button>
          </div>
          <div className="space-y-1">
            {parkingHistory.slice(0, 4).map((record, idx) => (
              <div key={idx} className="flex justify-between py-1 border-b border-stone-700 text-sm">
                <div className="text-stone-300">{record.time} • {record.date}</div>
                <div className={`px-2 rounded text-xs ${
                  record.status.includes('MANY') ? 'bg-emerald-900 text-emerald-300' :
                  record.status.includes('SOME') ? 'bg-amber-900 text-amber-300' :
                  'bg-red-900 text-red-300'
                }`}>
                  {record.status.includes('MANY') ? 'VAGAS DISPONÍVEIS' :
                   record.status.includes('SOME') ? 'POUCAS VAGAS' : 'LOTADO'}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Avaliações */}
        <div className="bg-stone-800 rounded-lg p-3">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-amber-300 font-bold">Avaliações</h3>
            <button className="text-amber-400 flex items-center text-sm">
              Ver todas <ChevronRight size={16} />
            </button>
          </div>
          <div className="space-y-3">
            {reviews.map((review) => (
              <div key={review.id} className="border-b border-stone-700 pb-3">
                <div className="flex justify-between items-center mb-1">
                  <div className="font-medium text-white">{review.user}</div>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={14} className={i < review.rating ? 'text-amber-400' : 'text-stone-600'} />
                    ))}
                  </div>
                </div>
                <p className="text-stone-300 text-sm">{review.text}</p>
                <div className="text-stone-500 text-xs mt-1">{review.date}</div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Botões de ação */}
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-stone-700 hover:bg-stone-600 text-white py-3 rounded-lg flex items-center justify-center">
            <Navigation className="mr-2" size={18} />
            Navegar
          </button>
          <button className="bg-amber-600 hover:bg-amber-500 text-white py-3 rounded-lg flex items-center justify-center">
            <Clipboard className="mr-2" size={18} />
            Reportar
          </button>
        </div>
      </div>
    </div>
  );
};

export default POIDetails;