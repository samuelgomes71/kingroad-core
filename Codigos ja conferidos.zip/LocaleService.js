import { NativeModules, Platform, I18nManager } from 'react-native';
import * as Localization from 'expo-localization';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getCountryFromCoordinates } from './GeocodingService';
import resources from '../i18n/resources';
import { t } from './TranslationsService';

/**
 * Serviço responsável pela internacionalização e localização no sistema KingRoad
 * Gerencia idiomas, formatação regional, detecção de país e preferências do usuário
 * Fornece utilitários para formatação de datas, números e moedas de acordo com o locale
 */
class LocaleService {
  constructor() {
    // Propriedades de locale e região
    this.currentLocale = '';
    this.currentCountry = '';
    this.defaultLocale = 'en-US';
    
    // Propriedades de configuração
    this.isRTL = false;
    this.regionSettings = {};
    this.storedPreferences = {};
    this.supportedLocales = [];
    
    // Propriedades para padrão observer
    this.languageChangeListeners = [];
    this.countryChangeListeners = [];
  }

  /**
   * Inicializa o serviço de localização e internacionalização
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async initialize() {
    try {
      // Carregar locales suportados
      await this._loadSupportedLocales();
      
      // Carregar preferências armazenadas
      await this.loadStoredPreferences();
      
      // Inicializar i18n
      await this.initializeI18n();
      
      // Detectar localização do dispositivo
      await this.detectDeviceLocale();
      
      // Detectar país baseado nas coordenadas GPS
      if (this.storedPreferences.autoDetectCountry !== false) {
        this.setupCountryDetection();
      }
      
      // Carregar configurações regionais específicas
      await this.loadRegionalSettings();
      
      return true;
    } catch (error) {
      console.error('Erro ao inicializar LocaleService:', error);
      
      // Define valores padrão em caso de erro
      this.currentLocale = this.defaultLocale;
      this.currentCountry = this._getRegionFromLocale(this.defaultLocale);
      
      return false;
    }
  }

  /**
   * Carrega locales suportados da API ou configuração
   * @returns {Promise<void>}
   * @private
   */
  async _loadSupportedLocales() {
    try {
      // Primeiro tenta carregar do cache
      const cachedLocales = await AsyncStorage.getItem('supported_locales');
      
      if (cachedLocales) {
        this.supportedLocales = JSON.parse(cachedLocales);
      } else {
        // Se não encontrar no cache, busca da API
        await this._fetchSupportedLocalesFromAPI();
      }
      
      // Se mesmo assim não tiver locales suportados, usa lista padrão
      if (!this.supportedLocales || this.supportedLocales.length === 0) {
        this.supportedLocales = [
          { code: 'en-US', name: 'English (US)', region: 'US' },
          { code: 'pt-BR', name: 'Português (Brasil)', region: 'BR' },
          { code: 'es-ES', name: 'Español', region: 'ES' },
          { code: 'de-DE', name: 'Deutsch', region: 'DE' },
          { code: 'fr-FR', name: 'Français', region: 'FR' }
        ];
        
        // Salva no cache
        await AsyncStorage.setItem('supported_locales', JSON.stringify(this.supportedLocales));
      }
    } catch (error) {
      console.error('Falha ao carregar locales suportados:', error);
      
      // Define lista padrão em caso de erro
      this.supportedLocales = [
        { code: 'en-US', name: 'English (US)', region: 'US' },
        { code: 'pt-BR', name: 'Português (Brasil)', region: 'BR' }
      ];
    }
  }

  /**
   * Busca locales suportados da API
   * @returns {Promise<void>}
   * @private
   */
  async _fetchSupportedLocalesFromAPI() {
    try {
      // Implementação de requisição à API
      // const response = await fetch('https://api.kingroad.app/locales/supported');
      // this.supportedLocales = await response.json();
      
      // Para desenvolvimento, usar dados embutidos
      this.supportedLocales = [
        { code: 'en-US', name: 'English (US)', region: 'US' },
        { code: 'pt-BR', name: 'Português (Brasil)', region: 'BR' },
        { code: 'es-ES', name: 'Español', region: 'ES' },
        { code: 'de-DE', name: 'Deutsch', region: 'DE' },
        { code: 'fr-FR', name: 'Français', region: 'FR' },
        { code: 'it-IT', name: 'Italiano', region: 'IT' },
        { code: 'ja-JP', name: '日本語', region: 'JP' },
        { code: 'ko-KR', name: '한국어', region: 'KR' },
        { code: 'ar-SA', name: 'العربية', region: 'SA' },
        { code: 'ru-RU', name: 'Русский', region: 'RU' },
        { code: 'zh-CN', name: '中文', region: 'CN' }
      ];
      
      // Salva no cache
      await AsyncStorage.setItem('supported_locales', JSON.stringify(this.supportedLocales));
    } catch (error) {
      console.error('Falha ao buscar locales da API:', error);
      throw error;
    }
  }

  /**
   * Carrega preferências de idioma e região do armazenamento local
   */
  async loadStoredPreferences() {
    try {
      const storedPrefs = await AsyncStorage.getItem('kingroad_locale_preferences');
      if (storedPrefs) {
        this.storedPreferences = JSON.parse(storedPrefs);
      } else {
        this.storedPreferences = {
          language: null,
          country: null,
          autoDetectCountry: true,
        };
      }
    } catch (error) {
      console.error('Erro ao carregar preferências de localização:', error);
      this.storedPreferences = {
        language: null,
        country: null,
        autoDetectCountry: true,
      };
    }
  }

  /**
   * Configura e inicializa o sistema de internacionalização i18n
   */
  async initializeI18n() {
    try {
      await i18n
        .use(initReactI18next)
        .init({
          resources,
          lng: this.storedPreferences.language || Localization.locale.split('-')[0],
          fallbackLng: 'en',
          interpolation: {
            escapeValue: false,
          },
          react: {
            useSuspense: false,
          },
        });
      
      // Verificar se o idioma atual usa RTL (direita para esquerda)
      const isRTL = ['ar', 'he', 'ur', 'fa'].includes(i18n.language);
      this.isRTL = isRTL;
      
      // Aplicar RTL ao React Native
      if (I18nManager.isRTL !== isRTL) {
        I18nManager.forceRTL(isRTL);
        // Nota: Em um caso real, isso pode exigir reiniciar o app para aplicar as mudanças de RTL
      }
      
      this.currentLocale = i18n.language;
    } catch (error) {
      console.error('Erro ao inicializar i18n:', error);
      // Fallback para inglês em caso de erro
      this.currentLocale = 'en';
    }
  }
/**
   * Define o locale inicial baseado nas preferências do usuário ou dispositivo
   * @returns {Promise<void>}
   * @private
   */
  async _setInitialLocale() {
    try {
      // Verifica se o usuário já tem uma preferência salva
      const userPreferredLocale = await AsyncStorage.getItem('user_preferred_locale');
      
      if (userPreferredLocale) {
        // Verifica se o locale preferido ainda é suportado
        if (this._isLocaleSupported(userPreferredLocale)) {
          this.currentLocale = userPreferredLocale;
          this.currentCountry = this._getRegionFromLocale(userPreferredLocale);
          return;
        }
      }
      
      // Se não houver preferência do usuário, detecta do dispositivo
      const deviceLocale = await this.getDeviceLocale();
      
      if (deviceLocale && this._isLocaleSupported(deviceLocale)) {
        this.currentLocale = deviceLocale;
        this.currentCountry = this._getRegionFromLocale(deviceLocale);
      } else {
        // Usa o locale padrão se o do dispositivo não for suportado
        this.currentLocale = this.defaultLocale;
        this.currentCountry = this._getRegionFromLocale(this.defaultLocale);
      }
    } catch (error) {
      console.error('Erro ao definir locale inicial:', error);
      
      // Usa o locale padrão em caso de erro
      this.currentLocale = this.defaultLocale;
      this.currentCountry = this._getRegionFromLocale(this.defaultLocale);
    }
  }

  /**
   * Detecta o idioma e região do dispositivo
   */
  async detectDeviceLocale() {
    try {
      // Se o usuário já definiu um idioma manualmente, usamos essa configuração
      if (this.storedPreferences.language) {
        this.currentLocale = this.storedPreferences.language;
      } else {
        // Caso contrário, tenta obter o idioma do dispositivo
        const deviceLocale = Localization.locale;
        const languageCode = deviceLocale.split('-')[0] || 'en';
        this.currentLocale = languageCode;
      }
      
      // Se o país já foi definido manualmente, usamos essa configuração
      if (this.storedPreferences.country) {
        this.currentCountry = this.storedPreferences.country;
      } else {
        // Tenta obter o país do dispositivo
        const deviceCountry = Localization.region || 'US';
        this.currentCountry = deviceCountry;
      }
      
      // Aplicar o idioma ao i18n
      await i18n.changeLanguage(this.currentLocale);
      
      // Notificar ouvintes sobre mudança de idioma
      this.notifyLanguageChange();
    } catch (error) {
      console.error('Erro ao detectar locale do dispositivo:', error);
    }
  }

  /**
   * Configura a detecção de país com base nas coordenadas GPS
   */
  setupCountryDetection() {
    // Esta função seria chamada periodicamente ou quando a localização muda significativamente
    // Por exemplo, integrado com um serviço de localização/GPS
    
    // Simples exemplo que poderia ser expandido com geolocalização real
    setTimeout(async () => {
      try {
        // Em um cenário real, obteríamos as coordenadas GPS atuais
        const currentCoordinates = {
          latitude: 0, // Substitua por coordenadas reais
          longitude: 0  // Substitua por coordenadas reais
        };
        
        // Obter país a partir das coordenadas via serviço de geocodificação
        const detectedCountry = await getCountryFromCoordinates(currentCoordinates);
        
        // Atualizar país apenas se for diferente do atual
        if (detectedCountry && detectedCountry !== this.currentCountry) {
          this.setCountry(detectedCountry);
        }
      } catch (error) {
        console.error('Erro ao detectar país por coordenadas:', error);
      }
    }, 1000); // No app real, isso seria feito com o serviço de localização, não com setTimeout
  }

  /**
   * Carrega configurações específicas para a região/país atual
   */
  async loadRegionalSettings() {
    try {
      // Em um cenário real, isso poderia buscar de uma API ou arquivo local
      const regionalSettings = {
        US: {
          speedUnit: 'mph',
          distanceUnit: 'miles',
          weightUnit: 'lb',
          dateFormat: 'MM/DD/YYYY',
          timeFormat: '12h',
          currency: 'USD',
          emergencyNumber: '911',
          drivingSide: 'right',
          highwayTypes: ['interstate', 'highway', 'freeway'],
          restrictedVehicleRules: {/* regras específicas do país */}
        },
        BR: {
          speedUnit: 'km/h',
          distanceUnit: 'km',
          weightUnit: 'kg',
          dateFormat: 'DD/MM/YYYY',
          timeFormat: '24h',
          currency: 'BRL',
          emergencyNumber: '190',
          drivingSide: 'right',
          highwayTypes: ['rodovia', 'autoestrada', 'estrada'],
          restrictedVehicleRules: {/* regras específicas do país */}
        },
        ES: {
          speedUnit: 'km/h',
          distanceUnit: 'km',
          weightUnit: 'kg',
          dateFormat: 'DD/MM/YYYY',
          timeFormat: '24h',
          currency: 'EUR',
          emergencyNumber: '112',
          drivingSide: 'right',
          highwayTypes: ['autopista', 'autovía', 'carretera'],
          restrictedVehicleRules: {/* regras específicas do país */}
        },
        DE: {
          speedUnit: 'km/h',
          distanceUnit: 'km',
          weightUnit: 'kg',
          dateFormat: 'DD.MM.YYYY',
          timeFormat: '24h',
          currency: 'EUR',
          emergencyNumber: '112',
          drivingSide: 'right',
          highwayTypes: ['autobahn', 'bundesstraße', 'landstraße'],
          restrictedVehicleRules: {/* regras específicas do país */}
        },
        // Outros países seriam adicionados aqui
      };
      
      // Definir configurações padrão se o país não for encontrado
      const defaultSettings = {
        speedUnit: 'km/h',
        distanceUnit: 'km',
        weightUnit: 'kg',
        dateFormat: 'DD/MM/YYYY',
        timeFormat: '24h',
        currency: 'USD',
        emergencyNumber: '112',
        drivingSide: 'right',
        highwayTypes: ['highway', 'motorway', 'expressway'],
        restrictedVehicleRules: {}
      };
      
      // Usar configurações específicas do país ou padrão
      this.regionSettings = regionalSettings[this.currentCountry] || defaultSettings;
      
      // Notificar ouvintes sobre mudança de país/região
      this.notifyCountryChange();
    } catch (error) {
      console.error('Erro ao carregar configurações regionais:', error);
    }
  }

  /**
   * Verifica se um locale é suportado pela aplicação
   * @param {string} locale - Locale para verificar
   * @returns {boolean} - Verdadeiro se o locale for suportado
   * @private
   */
  _isLocaleSupported(locale) {
    return this.supportedLocales.some(supported => supported.code === locale);
  }

  /**
   * Extrai a região (país) de um código de locale
   * @param {string} locale - Locale no formato 'idioma-REGIÃO'
   * @returns {string} - Código da região
   * @private
   */
  _getRegionFromLocale(locale) {
    if (!locale) return null;
    
    // Encontra o locale na lista de suportados
    const supportedLocale = this.supportedLocales.find(l => l.code === locale);
    
    if (supportedLocale) {
      return supportedLocale.region;
    }
    
    // Fallback: extrai do código do locale (parte após o hífen)
    const parts = locale.split('-');
    return parts.length > 1 ? parts[1] : null;
  }

  /**
   * Obtém o locale do dispositivo
   * @returns {Promise<string>} - Locale do dispositivo
   */
  async getDeviceLocale() {
    try {
      let deviceLocale;
      
      if (Platform.OS === 'ios') {
        deviceLocale = NativeModules.SettingsManager.settings.AppleLocale ||
                      NativeModules.SettingsManager.settings.AppleLanguages[0];
      } else if (Platform.OS === 'android') {
        deviceLocale = NativeModules.I18nManager.localeIdentifier;
      } else {
        deviceLocale = 'en-US'; // Fallback para outras plataformas
      }
      
      // Normaliza o formato do locale
      return this._normalizeLocale(deviceLocale);
    } catch (error) {
      console.error('Falha ao obter locale do dispositivo:', error);
      return this.defaultLocale;
    }
  }

  /**
   * Normaliza o formato do locale para o padrão da aplicação
   * @param {string} locale - Locale para normalizar
   * @returns {string} - Locale normalizado
   * @private
   */
  _normalizeLocale(locale) {
    if (!locale) return this.defaultLocale;
    
    // Alguns dispositivos retornam formatos diferentes, normaliza para 'idioma-PAÍS'
    if (locale.includes('_')) {
      // Troca underscore por hífen
      locale = locale.replace('_', '-');
    }
    
    // Garante que a parte do país está em maiúsculas
    const parts = locale.split('-');
    if (parts.length === 2) {
      return `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}`;
    }
    
    // Se não tiver formato esperado, verifica se há correspondência parcial
    const matchedLocale = this.supportedLocales.find(l => 
      l.code.toLowerCase().startsWith(locale.toLowerCase())
    );
    
    return matchedLocale ? matchedLocale.code : this.defaultLocale;
  }

  /**
   * Define o idioma manualmente
   * @param {string} languageCode - Código do idioma (ex: 'en', 'pt', 'es')
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async setLanguage(languageCode) {
    try {
      // Verificar se o idioma é suportado
      const supportedLanguages = Object.keys(resources);
      if (!supportedLanguages.includes(languageCode)) {
        console.warn(`Idioma ${languageCode} não é suportado. Usando idioma padrão.`);
        languageCode = 'en';
      }
      
      // Atualizar idioma no i18n
      await i18n.changeLanguage(languageCode);
      
      // Atualizar estado local
      this.currentLocale = languageCode;
      
      // Verificar se é RTL
      this.isRTL = ['ar', 'he', 'ur', 'fa'].includes(languageCode);
      
      // Aplicar RTL se necessário
      if (I18nManager.isRTL !== this.isRTL) {
        I18nManager.forceRTL(this.isRTL);
        // Em um app real, isso pode exigir reiniciar o app
        // Poderia mostrar um diálogo solicitando reinicialização
      }
      
      // Salvar preferência
      this.storedPreferences.language = languageCode;
      await this.savePreferences();
      
      // Notificar ouvintes
      this.notifyLanguageChange();
      
      return true;
    } catch (error) {
      console.error('Erro ao definir idioma:', error);
      return false;
    }
  }
/**
   * Altera o locale atual (compatibilidade com versão anterior)
   * @param {string} locale - Novo locale
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async changeLocale(locale) {
    if (!this._isLocaleSupported(locale)) {
      console.warn(`Locale não suportado: ${locale}`);
      return false;
    }
    
    const languageCode = locale.split('-')[0];
    this.currentLocale = languageCode;
    this.currentCountry = this._getRegionFromLocale(locale);
    
    // Atualizar idioma no i18n
    await i18n.changeLanguage(languageCode);
    
    // Salvar preferências
    this.storedPreferences.language = languageCode;
    this.storedPreferences.country = this.currentCountry;
    await this.savePreferences();
    
    // Carregar configurações regionais
    await this.loadRegionalSettings();
    
    // Notificar ouvintes
    this.notifyLanguageChange();
    this.notifyCountryChange();
    
    return true;
  }

  /**
   * Define o país manualmente
   * @param {string} countryCode - Código do país (ex: 'US', 'BR', 'ES')
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async setCountry(countryCode) {
    try {
      // Atualizar país
      this.currentCountry = countryCode;
      
      // Salvar preferência
      this.storedPreferences.country = countryCode;
      await this.savePreferences();
      
      // Recarregar configurações regionais
      await this.loadRegionalSettings();
      
      // Notificar ouvintes
      this.notifyCountryChange();
      
      return true;
    } catch (error) {
      console.error('Erro ao definir país:', error);
      return false;
    }
  }

  /**
   * Ativa ou desativa a detecção automática de país
   * @param {boolean} enabled - Se a detecção automática deve estar ativada
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async setAutoDetectCountry(enabled) {
    try {
      this.storedPreferences.autoDetectCountry = enabled;
      await this.savePreferences();
      
      if (enabled) {
        this.setupCountryDetection();
      }
      
      return true;
    } catch (error) {
      console.error('Erro ao configurar detecção automática de país:', error);
      return false;
    }
  }

  /**
   * Salva as preferências no armazenamento local
   */
  async savePreferences() {
    try {
      await AsyncStorage.setItem(
        'kingroad_locale_preferences',
        JSON.stringify(this.storedPreferences)
      );
    } catch (error) {
      console.error('Erro ao salvar preferências de localização:', error);
    }
  }

  /**
   * Adiciona um ouvinte para mudanças de idioma
   * @param {Function} listener - Função a ser chamada quando o idioma mudar
   */
  addLanguageChangeListener(listener) {
    this.languageChangeListeners.push(listener);
  }

  /**
   * Remove um ouvinte de mudanças de idioma
   * @param {Function} listener - Função a ser removida
   */
  removeLanguageChangeListener(listener) {
    this.languageChangeListeners = this.languageChangeListeners.filter(
      item => item !== listener
    );
  }

  /**
   * Adiciona um ouvinte para mudanças de país
   * @param {Function} listener - Função a ser chamada quando o país mudar
   */
  addCountryChangeListener(listener) {
    this.countryChangeListeners.push(listener);
  }

  /**
   * Remove um ouvinte de mudanças de país
   * @param {Function} listener - Função a ser removida
   */
  removeCountryChangeListener(listener) {
    this.countryChangeListeners = this.countryChangeListeners.filter(
      item => item !== listener
    );
  }

  /**
   * Obtém o idioma atual
   * @returns {string} Código do idioma atual
   */
  getCurrentLocale() {
    return this.currentLocale || this.defaultLocale;
  }

  /**
   * Obtém o país atual
   * @returns {string} Código do país atual
   */
  getCurrentCountry() {
    return this.currentCountry;
  }

  /**
   * Obtém a região atual (compatibilidade com versão anterior)
   * @returns {string} Código da região atual
   */
  getCurrentRegion() {
    return this.currentCountry;
  }

  /**
   * Verifica se o layout atual é da direita para a esquerda (RTL)
   * @returns {boolean} True se for RTL, false caso contrário
   */
  isLayoutRTL() {
    return this.isRTL;
  }

  /**
   * Obtém as configurações regionais atuais
   * @returns {Object} Configurações específicas da região/país
   */
  getRegionalSettings() {
    return this.regionSettings;
  }

  /**
   * Obtém uma lista de idiomas suportados em formato simplificado
   * @returns {Array} Lista de idiomas suportados com código e nome
   */
  getSupportedLanguages() {
    // Em um app real, isso poderia vir de um arquivo de configuração
    return [
      { code: 'en', name: 'English' },
      { code: 'es', name: 'Español' },
      { code: 'pt', name: 'Português' },
      { code: 'fr', name: 'Français' },
      { code: 'de', name: 'Deutsch' },
      { code: 'it', name: 'Italiano' },
      { code: 'ru', name: 'Русский' },
      { code: 'zh', name: '中文' },
      { code: 'ja', name: '日本語' },
      { code: 'ar', name: 'العربية' },
      // Outros idiomas...
    ];
  }

  /**
   * Obtém uma lista completa de locales suportados
   * @returns {Array} Lista de locales suportados
   */
  getSupportedLocales() {
    return [...this.supportedLocales];
  }

  /**
   * Notifica todos os ouvintes sobre uma mudança de idioma
   */
  notifyLanguageChange() {
    this.languageChangeListeners.forEach(listener => {
      try {
        listener(this.currentLocale);
      } catch (error) {
        console.error('Erro ao notificar mudança de idioma:', error);
      }
    });
  }

  /**
   * Notifica todos os ouvintes sobre uma mudança de país
   */
  notifyCountryChange() {
    this.countryChangeListeners.forEach(listener => {
      try {
        listener(this.currentCountry, this.regionSettings);
      } catch (error) {
        console.error('Erro ao notificar mudança de país:', error);
      }
    });
  }

  /**
   * Formata uma data de acordo com o formato regional
   * @param {Date} date - Data a ser formatada
   * @param {Object} options - Opções de formatação (opcional)
   * @returns {string} Data formatada de acordo com o padrão regional
   */
  formatDate(date, options = {}) {
    try {
      // Se foram passadas opções personalizadas, usar a API toLocaleDateString
      if (Object.keys(options).length > 0) {
        const dateObj = typeof date === 'object' ? date : new Date(date);
        return dateObj.toLocaleDateString(this.currentLocale || this.defaultLocale, options);
      }
      
      // Caso contrário, usar o formato definido nas configurações regionais
      const format = this.regionSettings.dateFormat;
      const dateObj = typeof date === 'object' ? date : new Date(date);
      
      const day = dateObj.getDate().toString().padStart(2, '0');
      const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
      const year = dateObj.getFullYear();
      
      switch (format) {
        case 'MM/DD/YYYY':
          return `${month}/${day}/${year}`;
        case 'DD/MM/YYYY':
          return `${day}/${month}/${year}`;
        case 'YYYY-MM-DD':
          return `${year}-${month}-${day}`;
        case 'DD.MM.YYYY':
          return `${day}.${month}.${year}`;
        default:
          return `${day}/${month}/${year}`;
      }
    } catch (error) {
      console.error('Erro ao formatar data:', error);
      return String(date);
    }
  }
  
  /**
   * Formata um número de acordo com as configurações regionais
   * @param {number} value - Número a ser formatado
   * @param {number} decimalPlaces - Número de casas decimais
   * @returns {string} Número formatado
   */
  formatNumber(value, decimalPlaces = 2) {
    try {
      // Em um app real, poderia usar Intl.NumberFormat com suporte mais completo
      return value.toLocaleString(this.currentLocale, {
        minimumFractionDigits: decimalPlaces,
        maximumFractionDigits: decimalPlaces
      });
    } catch (error) {
      console.error('Erro ao formatar número:', error);
      return value.toFixed(decimalPlaces);
    }
  }
  
  /**
   * Formata uma distância de acordo com a unidade regional (km ou milhas)
   * @param {number} distanceInMeters - Distância em metros
   * @returns {string} Distância formatada com unidade
   */
  formatDistance(distanceInMeters) {
    const unit = this.regionSettings.distanceUnit;
    let value;
    
    if (unit === 'miles') {
      // Converter metros para milhas (1 milha = 1609.34 metros)
      value = distanceInMeters / 1609.34;
    } else {
      // Converter metros para quilômetros
      value = distanceInMeters / 1000;
    }
    
    // Determinar o número de casas decimais com base no valor
    const decimalPlaces = value < 10 ? 1 : 0;
    
    return `${this.formatNumber(value, decimalPlaces)} ${unit}`;
  }
  
  /**
   * Formata uma velocidade de acordo com a unidade regional (km/h ou mph)
   * @param {number} speedInKmh - Velocidade em km/h
   * @returns {string} Velocidade formatada com unidade
   */
  formatSpeed(speedInKmh) {
    const unit = this.regionSettings.speedUnit;
    let value;
    
    if (unit === 'mph') {
      // Converter km/h para mph (1 km/h = 0.621371 mph)
      value = speedInKmh * 0.621371;
    } else {
      value = speedInKmh;
    }
    
    return `${Math.round(value)} ${unit}`;
  }
  
  /**
   * Formata um peso de acordo com a unidade regional (kg ou lb)
   * @param {number} weightInKg - Peso em quilogramas
   * @returns {string} Peso formatado com unidade
   */
  formatWeight(weightInKg) {
    const unit = this.regionSettings.weightUnit;
    let value;
    
    if (unit === 'lb') {
      // Converter kg para lb (1 kg = 2.20462 lb)
      value = weightInKg * 2.20462;
    } else {
      value = weightInKg;
    }
    
    // Arredondar para números inteiros se for grande, ou 1 decimal se for pequeno
    const decimalPlaces = value < 10 ? 1 : 0;
    
    return `${this.formatNumber(value, decimalPlaces)} ${unit}`;
  }

  /**
   * Formata moeda conforme o locale atual
   * @param {number} amount - Valor para formatar
   * @param {string} currency - Código da moeda (USD, EUR, BRL)
   * @returns {string} - Valor formatado como moeda
   */
  formatCurrency(amount, currency) {
    try {
      return amount.toLocaleString(this.currentLocale || this.defaultLocale, {
        style: 'currency',
        currency: currency || this._getCurrencyForRegion(this.currentCountry)
      });
    } catch (error) {
      console.error('Erro ao formatar moeda:', error);
      return String(amount);
    }
  }

  /**
   * Obtém a moeda padrão para uma região
   * @param {string} region - Código da região
   * @returns {string} - Código da moeda
   * @private
   */
  _getCurrencyForRegion(region) {
    // Mapa de regiões para moedas - pode ser expandido conforme necessário
    const currencyMap = {
      'US': 'USD',
      'BR': 'BRL',
      'EU': 'EUR',
      'DE': 'EUR',
      'FR': 'EUR',
      'ES': 'EUR',
      'IT': 'EUR',
      'GB': 'GBP',
      'JP': 'JPY',
      'KR': 'KRW',
      'CN': 'CNY',
      'IN': 'INR',
      'RU': 'RUB',
      'AU': 'AUD',
      'CA': 'CAD'
    };
    
    return currencyMap[region] || 'USD';
  }
}

// Criar uma instância singleton
const localeService = new LocaleService();

export default localeService;