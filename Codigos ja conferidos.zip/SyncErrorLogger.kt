package com.kingroad.utils.logging

import android.content.Context
import android.os.Environment
import android.util.Log
import com.kingroad.database.entities.SyncError
import com.kingroad.database.dao.SyncErrorDao
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.collections.HashMap

/**
 * Classe responsável por registrar erros de sincronização e facilitar o debug em ambientes offline.
 * 
 * Funcionalidades:
 * - Registra falhas de sincronização em logs e banco de dados
 * - Agrupa erros similares para melhor análise
 * - Permite exportar relatórios para suporte técnico
 * - Monitora padrões de falha para detectar problemas recorrentes
 */
class SyncErrorLogger private constructor(private val context: Context) {

    // DAO para interação com o banco de dados
    private lateinit var syncErrorDao: SyncErrorDao
    
    // Fila para armazenar erros em memória antes de persistir
    private val errorQueue = ConcurrentLinkedQueue<SyncError>()
    
    // Contador de erros por tipo para identificar padrões
    private val errorCountMap = HashMap<String, Int>()
    
    // Job do coroutine para processamento em background
    private var processingJob: Job? = null
    
    // Flag para controle de verbosidade dos logs
    private var verboseLogging = false

    companion object {
        private const val TAG = "SyncErrorLogger"
        private var instance: SyncErrorLogger? = null

        // Níveis de severidade para erros de sincronização
        enum class Severity {
            LOW,      // Erro não crítico, pode ser tentado novamente automaticamente
            MEDIUM,   // Erro que requer atenção, mas não impede operação
            HIGH,     // Erro crítico que impede funcionalidade principal
            CRITICAL  // Erro que pode causar perda de dados ou corrupção
        }

        // Categorias de erros para melhor organização
        enum class Category {
            NETWORK,     // Erros de conexão ou timeout
            API,         // Erros de API (400, 500, etc)
            AUTH,        // Erros de autenticação
            DATA,        // Erros de formato ou validação de dados
            STORAGE,     // Erros de armazenamento local
            PERMISSION,  // Erros de permissão
            UNKNOWN      // Outros erros não categorizados
        }

        // Singleton para acesso global
        @Synchronized
        fun getInstance(context: Context): SyncErrorLogger {
            if (instance == null) {
                instance = SyncErrorLogger(context.applicationContext)
            }
            return instance!!
        }
    }

    /**
     * Inicializa o logger com as dependências necessárias
     */
    fun initialize(errorDao: SyncErrorDao) {
        syncErrorDao = errorDao
        startProcessingErrors()
        Log.i(TAG, "SyncErrorLogger inicializado")
    }

    /**
     * Registra um erro de sincronização
     * 
     * @param module Nome do módulo ou componente onde ocorreu o erro
     * @param errorMessage Mensagem descritiva do erro
     * @param exception Exceção relacionada (opcional)
     * @param category Categoria do erro
     * @param severity Severidade do erro
     * @param entityId ID da entidade relacionada ao erro (opcional)
     * @param metadata Dados adicionais como JSON para debug (opcional)
     * @return ID do erro registrado
     */
    fun logError(
        module: String,
        errorMessage: String,
        exception: Throwable? = null,
        category: Category = Category.UNKNOWN,
        severity: Severity = Severity.MEDIUM,
        entityId: String? = null,
        metadata: JSONObject? = null
    ): Long {
        
        // Obter stack trace se disponível
        val stackTrace = exception?.stackTraceToString() ?: ""
        
        // Gerar um ID único para o erro
        val errorId = UUID.randomUUID().toString()
        
        // Criar objeto de erro
        val syncError = SyncError(
            id = 0, // Será gerado pelo Room
            errorId = errorId,
            timestamp = System.currentTimeMillis(),
            module = module,
            message = errorMessage,
            stackTrace = stackTrace,
            category = category.name,
            severity = severity.name,
            entityId = entityId,
            metadata = metadata?.toString() ?: "",
            resolved = false,
            retryCount = 0
        )
        
        // Registrar no logcat para debug imediato
        if (verboseLogging || severity == Severity.HIGH || severity == Severity.CRITICAL) {
            Log.e(TAG, "[$module] $errorMessage (${category.name}) - ID: $errorId")
            if (exception != null) {
                Log.e(TAG, "Stack trace: $stackTrace")
            }
        }
        
        // Adicionar à fila para processamento em background
        errorQueue.add(syncError)
        
        // Incrementar contador para análise de padrões
        val errorType = "${module}_${category.name}"
        errorCountMap[errorType] = (errorCountMap[errorType] ?: 0) + 1
        
        // Checar por padrões se acumulou muitos erros do mesmo tipo
        if ((errorCountMap[errorType] ?: 0) > 5) {
            Log.w(TAG, "Padrão de erros detectado: $errorType ocorreu ${errorCountMap[errorType]} vezes")
        }
        
        return syncError.id
    }

    /**
     * Inicia o processamento em background de erros na fila
     */
    private fun startProcessingErrors() {
        // Cancelar job existente se houver
        processingJob?.cancel()
        
        // Iniciar novo job de processamento
        processingJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                try {
                    // Processar erros na fila
                    while (errorQueue.isNotEmpty()) {
                        val error = errorQueue.poll() ?: continue
                        syncErrorDao.insert(error)
                    }
                    // Aguardar antes da próxima verificação
                    delay(5000)
                } catch (e: Exception) {
                    Log.e(TAG, "Erro ao processar fila de erros: ${e.message}")
                }
            }
        }
    }

    /**
     * Marca um erro como resolvido
     * 
     * @param errorId ID do erro a ser resolvido
     * @param notes Notas sobre a resolução (opcional)
     */
    suspend fun markAsResolved(errorId: String, notes: String? = null) {
        withContext(Dispatchers.IO) {
            val error = syncErrorDao.findByErrorId(errorId)
            error?.let {
                it.resolved = true
                it.resolutionNotes = notes ?: "Resolvido manualmente"
                it.resolvedAt = System.currentTimeMillis()
                syncErrorDao.update(it)
                Log.d(TAG, "Erro $errorId marcado como resolvido")
            }
        }
    }

    /**
     * Marca todos os erros de um módulo como resolvidos
     * 
     * @param module Nome do módulo
     * @param category Categoria específica (opcional)
     * @return Número de erros marcados como resolvidos
     */
    suspend fun resolveAllForModule(module: String, category: Category? = null): Int {
        return withContext(Dispatchers.IO) {
            if (category != null) {
                syncErrorDao.resolveAllForModuleAndCategory(module, category.name)
            } else {
                syncErrorDao.resolveAllForModule(module)
            }
        }
    }

    /**
     * Exporta os logs de erros para um arquivo JSON que pode ser enviado para o suporte
     * 
     * @param days Número de dias para incluir no relatório (0 para todos)
     * @param includeResolved Se deve incluir erros já resolvidos
     * @param onlyHighSeverity Se deve incluir apenas erros de alta severidade
     * @return Arquivo criado ou null em caso de falha
     */
    suspend fun exportErrorsToFile(
        days: Int = 7,
        includeResolved: Boolean = false,
        onlyHighSeverity: Boolean = false
    ): File? {
        return withContext(Dispatchers.IO) {
            try {
                // Definir período para o relatório
                val cutoffTime = if (days > 0) {
                    val calendar = Calendar.getInstance()
                    calendar.add(Calendar.DAY_OF_YEAR, -days)
                    calendar.timeInMillis
                } else {
                    0L
                }
                
                // Obter erros do banco conforme filtros
                val errors = if (onlyHighSeverity) {
                    if (includeResolved) {
                        syncErrorDao.getHighSeverityErrorsSince(cutoffTime)
                    } else {
                        syncErrorDao.getUnresolvedHighSeverityErrorsSince(cutoffTime)
                    }
                } else {
                    if (includeResolved) {
                        syncErrorDao.getAllErrorsSince(cutoffTime)
                    } else {
                        syncErrorDao.getUnresolvedErrorsSince(cutoffTime)
                    }
                }
                
                // Criar diretório de exportação se não existir
                val exportDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "error_logs")
                if (!exportDir.exists()) {
                    exportDir.mkdirs()
                }
                
                // Formato de data para o nome do arquivo
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                val timestamp = dateFormat.format(Date())
                
                // Criar arquivo
                val exportFile = File(exportDir, "sync_errors_${timestamp}.json")
                
                // Converter erros para JSON
                val jsonArray = JSONArray()
                errors.forEach { error ->
                    val errorJson = JSONObject().apply {
                        put("errorId", error.errorId)
                        put("timestamp", error.timestamp)
                        put("formattedDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(error.timestamp)))
                        put("module", error.module)
                        put("message", error.message)
                        put("category", error.category)
                        put("severity", error.severity)
                        put("entityId", error.entityId ?: "")
                        put("resolved", error.resolved)
                        put("retryCount", error.retryCount)
                        
                        // Incluir stack trace apenas se não for muito grande
                        if (error.stackTrace.length <= 2000) {
                            put("stackTrace", error.stackTrace)
                        } else {
                            put("stackTrace", error.stackTrace.substring(0, 2000) + "... (truncado)")
                        }
                        
                        // Incluir metadados se existirem e forem JSON válido
                        if (error.metadata.isNotEmpty()) {
                            try {
                                put("metadata", JSONObject(error.metadata))
                            } catch (e: Exception) {
                                put("metadata", error.metadata)
                            }
                        }
                    }
                    jsonArray.put(errorJson)
                }
                
                // Criar objeto JSON raiz com informações adicionais
                val rootJson = JSONObject().apply {
                    put("exportDate", System.currentTimeMillis())
                    put("exportDateFormatted", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
                    put("totalErrors", errors.size)
                    put("deviceInfo", getDeviceInfo())
                    put("errors", jsonArray)
                }
                
                // Escrever no arquivo
                FileWriter(exportFile).use { writer ->
                    writer.write(rootJson.toString(2)) // Indentação para legibilidade
                }
                
                Log.i(TAG, "Relatório de erros exportado para ${exportFile.absolutePath}")
                exportFile
                
            } catch (e: Exception) {
                Log.e(TAG, "Falha ao exportar erros: ${e.message}")
                null
            }
        }
    }

    /**
     * Gera resumo estatístico dos erros recentes
     */
    suspend fun getErrorSummary(days: Int = 7): JSONObject {
        return withContext(Dispatchers.IO) {
            val summary = JSONObject()
            
            try {
                // Definir período para análise
                val cutoffTime = if (days > 0) {
                    val calendar = Calendar.getInstance()
                    calendar.add(Calendar.DAY_OF_YEAR, -days)
                    calendar.timeInMillis
                } else {
                    0L
                }
                
                // Obter contagens por categoria
                val categoryCounts = syncErrorDao.getErrorCountByCategory(cutoffTime)
                val categoryJson = JSONObject()
                categoryCounts.forEach { (category, count) ->
                    categoryJson.put(category, count)
                }
                
                // Obter contagens por módulo
                val moduleCounts = syncErrorDao.getErrorCountByModule(cutoffTime)
                val moduleJson = JSONObject()
                moduleCounts.forEach { (module, count) ->
                    moduleJson.put(module, count)
                }
                
                // Obter contagens por severidade
                val severityCounts = syncErrorDao.getErrorCountBySeverity(cutoffTime)
                val severityJson = JSONObject()
                severityCounts.forEach { (severity, count) ->
                    severityJson.put(severity, count)
                }
                
                // Obter erros mais frequentes
                val topErrors = syncErrorDao.getMostFrequentErrors(cutoffTime, 5)
                val topErrorsJson = JSONArray()
                topErrors.forEach { error ->
                    topErrorsJson.put(JSONObject().apply {
                        put("message", error.message)
                        put("count", error.count)
                        put("module", error.module)
                    })
                }
                
                // Compor o resumo final
                summary.apply {
                    put("period", "${days} dias")
                    put("totalErrors", syncErrorDao.getErrorCountSince(cutoffTime))
                    put("unresolvedErrors", syncErrorDao.getUnresolvedErrorCountSince(cutoffTime))
                    put("byCategory", categoryJson)
                    put("byModule", moduleJson)
                    put("bySeverity", severityJson)
                    put("topErrors", topErrorsJson)
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao gerar resumo: ${e.message}")
                summary.put("error", "Falha ao gerar resumo: ${e.message}")
            }
            
            summary
        }
    }

    /**
     * Configura o nível de verbosidade dos logs
     */
    fun setVerboseLogging(verbose: Boolean) {
        verboseLogging = verbose
        Log.d(TAG, "Modo verboso de logging ${if (verbose) "ativado" else "desativado"}")
    }

    /**
     * Limpa erros antigos para não sobrecarregar o banco de dados
     */
    suspend fun pruneOldErrors(olderThanDays: Int = 30): Int {
        return withContext(Dispatchers.IO) {
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_YEAR, -olderThanDays)
            val cutoffTime = calendar.timeInMillis
            
            val deletedCount = syncErrorDao.deleteOldResolvedErrors(cutoffTime)
            Log.i(TAG, "Limpeza de erros: $deletedCount erros antigos removidos")
            
            deletedCount
        }
    }

    /**
     * Coleta informações sobre o dispositivo para diagnóstico
     */
    private fun getDeviceInfo(): JSONObject {
        return JSONObject().apply {
            try {
                put("model", android.os.Build.MODEL)
                put("device", android.os.Build.DEVICE)
                put("manufacturer", android.os.Build.MANUFACTURER)
                put("androidVersion", android.os.Build.VERSION.RELEASE)
                put("apiLevel", android.os.Build.VERSION.SDK_INT)
                
                // Informações da aplicação
                val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                put("appVersion", packageInfo.versionName)
                put("appVersionCode", packageInfo.versionCode)
                
                // Estado da rede
                val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
                val networkInfo = connectivityManager.activeNetworkInfo
                put("networkAvailable", networkInfo != null && networkInfo.isConnected)
                put("networkType", networkInfo?.typeName ?: "Desconhecido")
                
                // Estado de armazenamento
                val freeSpace = Environment.getExternalStorageDirectory().freeSpace
                val totalSpace = Environment.getExternalStorageDirectory().totalSpace
                put("freeStorage", freeSpace)
                put("freeStorageFormatted", formatFileSize(freeSpace))
                put("totalStorage", totalSpace)
                put("totalStorageFormatted", formatFileSize(totalSpace))
                
            } catch (e: Exception) {
                put("error", "Falha ao coletar informações do dispositivo: ${e.message}")
            }
        }
    }

    /**
     * Formata tamanho de arquivo para exibição legível
     */
    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.1f %s", size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    /**
     * Libera recursos e finaliza processamento
     */
    fun shutdown() {
        processingJob?.cancel()
        // Processar erros restantes na fila
        runBlocking {
            withContext(Dispatchers.IO) {
                while (errorQueue.isNotEmpty()) {
                    val error = errorQueue.poll() ?: continue
                    try {
                        syncErrorDao.insert(error)
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro ao salvar durante shutdown: ${e.message}")
                    }
                }
            }
        }
        Log.i(TAG, "SyncErrorLogger finalizado")
    }
}