// EnhancedGlobalTruckWashersMap.jsx
import React, { useState, useEffect, useRef } from 'react';
import { Map, TileLayer, Marker, Popup, LayerGroup, ZoomControl } from 'react-leaflet';
import { 
  Droplet, 
  Star, 
  Phone, 
  Clock, 
  Info, 
  Navigation, 
  ThumbsUp, 
  ThumbsDown, 
  Filter, 
  DollarSign, 
  Calendar, 
  MessageSquare, 
  XCircle, 
  Send, 
  Camera
} from 'lucide-react';
import { Button, Select, MenuItem, FormControlLabel, Switch, TextField, Tooltip, Tabs, Tab, Rating } from '@/components/ui';
import { KingLocBridge } from '../services/KingLocBridge';

/**
 * Componente aprimorado para exibir lavadores de caminhões em escala global
 * com verificação de preços, horários detalhados e sistema de feedback
 */
const EnhancedGlobalTruckWashersMap = ({ 
  userId,
  userName = "Motorista",
  initialCenter = { lat: 20, lng: 0 }, 
  initialZoom = 2
}) => {
  // Estado principal
  const [truckWashers, setTruckWashers] = useState([]);
  const [filteredWashers, setFilteredWashers] = useState([]);
  const [selectedWasher, setSelectedWasher] = useState(null);
  const [userLocation, setUserLocation] = useState(initialCenter);
  const [mapCenter, setMapCenter] = useState(initialCenter);
  const [isLoading, setIsLoading] = useState(true);
  
  // Estado para detalhes expandidos
  const [activeTab, setActiveTab] = useState(0);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [feedbackData, setFeedbackData] = useState({
    rating: 0,
    comment: '',
    price: '',
    waitTime: '',
    serviceName: '',
    visited: new Date().toISOString().split('T')[0]
  });
  const [priceDetails, setPriceDetails] = useState([]);
  const [scheduleDetails, setScheduleDetails] = useState([]);
  const [reviews, setReviews] = useState([]);
  
  // Filtros
  const [filters, setFilters] = useState({
    openNow: false,
    highPressure: false,
    automaticWash: false,
    truckParking: false,
    restaurant: false,
    heavyDuty: false,
    country: 'all',
    priceRange: 'all',
    minRating: 0
  });
  
  const [showFilters, setShowFilters] = useState(false);
  
  const mapRef = useRef(null);
  const kingLocBridge = useRef(new KingLocBridge());
// Carregar dados de lavadores de caminhões
  useEffect(() => {
    const fetchWashers = async () => {
      try {
        setIsLoading(true);
        
        // Em um cenário real, isso seria uma chamada para uma API
        // Simulando dados de lavadores de caminhões em vários países
        const washersData = [
          // América do Norte
          {
            id: 'us-ca-1',
            name: 'Blue Beacon Truck Wash',
            address: '3501 Stockdale Hwy, Bakersfield, CA 93309',
            country: 'United States',
            countryCode: 'US',
            latitude: 35.3520,
            longitude: -119.0458,
            rating: 4.7,
            totalRatings: 834,
            phone: '+1 661-834-5506',
            hours: '24 hours',
            website: 'https://www.bluebeacon.com',
            services: {
              highPressure: true,
              automaticWash: true,
              manualWash: true,
              interiorCleaning: true,
              engineWash: true,
              truckParking: true,
              restaurant: true,
              heavyDuty: true
            },
            priceRange: '$$',
            detailedPrices: [
              { service: 'Lavagem Básica', price: '$45.00', description: 'Lavagem externa completa' },
              { service: 'Lavagem Completa', price: '$75.00', description: 'Inclui lavagem de chassi' },
              { service: 'Lavagem Premium', price: '$120.00', description: 'Inclui interior e desengordurante' },
              { service: 'Remoção de Insetos', price: '$15.00', description: 'Adicional' }
            ],
            detailedSchedule: [
              { day: 'Segunda-feira', hours: '24 horas' },
              { day: 'Terça-feira', hours: '24 horas' },
              { day: 'Quarta-feira', hours: '24 horas' },
              { day: 'Quinta-feira', hours: '24 horas' },
              { day: 'Sexta-feira', hours: '24 horas' },
              { day: 'Sábado', hours: '24 horas' },
              { day: 'Domingo', hours: '24 horas' }
            ],
            reviews: [
              { 
                user: 'Roberto A.', 
                rating: 5, 
                comment: 'Excelente serviço. Lavaram meu caminhão rapidamente e muito bem!', 
                date: '2023-06-15',
                serviceUsed: 'Lavagem Completa',
                waitTime: '30 minutos',
                price: '$75.00'
              },
              { 
                user: 'Carlos M.', 
                rating: 4, 
                comment: 'Bom serviço, mas um pouco caro para lavagem básica.', 
                date: '2023-05-22',
                serviceUsed: 'Lavagem Básica',
                waitTime: '45 minutos',
                price: '$45.00'
              }
            ],
            lastUpdatedPrice: '2023-11-10',
            averageWaitTime: '35 minutos'
          },
          {
            id: 'ca-on-1',
            name: 'Flying J Truck Wash',
            address: '1150 Hwy 33, Trenton, ON K8V 5P4',
            country: 'Canada',
            countryCode: 'CA',
            latitude: 44.1291,
            longitude: -77.5712,
            rating: 4.2,
            totalRatings: 356,
            phone: '+1 613-394-3041',
            hours: '7:00 AM - 9:00 PM',
            website: 'https://www.pilotflyingj.com',
            services: {
              highPressure: true,
              automaticWash: true,
              manualWash: true,
              interiorCleaning: false,
              engineWash: false,
              truckParking: true,
              restaurant: true,
              heavyDuty: true
            },
            priceRange: '$$',
            detailedPrices: [
              { service: 'Lavagem Padrão', price: 'C$60.00', description: 'Lavagem externa básica' },
              { service: 'Lavagem Premium', price: 'C$95.00', description: 'Lavagem avançada com chassis' },
              { service: 'Express Wash', price: 'C$45.00', description: 'Lavagem rápida sem espera' }
            ],
            detailedSchedule: [
              { day: 'Segunda-feira', hours: '7:00 - 21:00' },
              { day: 'Terça-feira', hours: '7:00 - 21:00' },
              { day: 'Quarta-feira', hours: '7:00 - 21:00' },
              { day: 'Quinta-feira', hours: '7:00 - 21:00' },
              { day: 'Sexta-feira', hours: '7:00 - 21:00' },
              { day: 'Sábado', hours: '7:00 - 21:00' },
              { day: 'Domingo', hours: '7:00 - 21:00' }
            ],
            reviews: [
              { 
                user: 'Jean P.', 
                rating: 5, 
                comment: 'Atendimento rápido, preço justo.', 
                date: '2023-08-10',
                serviceUsed: 'Lavagem Premium',
                waitTime: '40 minutos',
                price: 'C$95.00'
              },
              { 
                user: 'Miguel T.', 
                rating: 3, 
                comment: 'Serviço ok, mas tive que esperar muito.', 
                date: '2023-07-05',
                serviceUsed: 'Lavagem Padrão',
                waitTime: '1 hora e 20 minutos',
                price: 'C$60.00'
              }
            ],
            lastUpdatedPrice: '2023-10-15',
            averageWaitTime: '50 minutos'
          },
          // América do Sul
          {
            id: 'br-sp-1',
            name: 'Posto Presidente Lavagem',
            address: 'Rod. Presidente Dutra, km 230, São Paulo',
            country: 'Brazil',
            countryCode: 'BR',
            latitude: -23.4273,
            longitude: -46.3370,
            rating: 4.5,
            totalRatings: 423,
            phone: '+55 11-4422-1000',
            hours: '24 hours',
            services: {
              highPressure: true,
              automaticWash: false,
              manualWash: true,
              interiorCleaning: true,
              engineWash: true,
              truckParking: true,
              restaurant: true,
              heavyDuty: true
            },
            priceRange: '$$',
            detailedPrices: [
              { service: 'Lavagem Simples', price: 'R$120,00', description: 'Lavagem externa' },
              { service: 'Lavagem Completa', price: 'R$220,00', description: 'Externa e chassi' },
              { service: 'Lavagem Premium', price: 'R$320,00', description: 'Completa com limpeza de cabine' },
              { service: 'Enceramento', price: 'R$150,00', description: 'Adicional' }
            ],
            detailedSchedule: [
              { day: 'Segunda-feira', hours: '24 horas' },
              { day: 'Terça-feira', hours: '24 horas' },
              { day: 'Quarta-feira', hours: '24 horas' },
              { day: 'Quinta-feira', hours: '24 horas' },
              { day: 'Sexta-feira', hours: '24 horas' },
              { day: 'Sábado', hours: '24 horas' },
              { day: 'Domingo', hours: '24 horas' }
            ],
            reviews: [
              { 
                user: 'Paulo R.', 
                rating: 5, 
                comment: 'Melhor lavagem da Dutra! Pessoal muito atencioso.', 
                date: '2023-09-18',
                serviceUsed: 'Lavagem Completa',
                waitTime: '40 minutos',
                price: 'R$220,00'
              },
              { 
                user: 'José C.', 
                rating: 4, 
                comment: 'Bom serviço, preço razoável. Só acho que poderia ser mais rápido.', 
                date: '2023-08-12',
                serviceUsed: 'Lavagem Simples',
                waitTime: '1 hora',
                price: 'R$120,00'
              }
            ],
            lastUpdatedPrice: '2023-12-01',
            averageWaitTime: '50 minutos'
          },
          // Europa
          {
            id: 'de-1',
            name: 'Autohof Truck Wash',
            address: 'Autohof Rhüden, A7, 38723 Seesen',
            country: 'Germany',
            countryCode: 'DE',
            latitude: 51.9482,
            longitude: 10.1266,
            rating: 4.6,
            totalRatings: 512,
            phone: '+49 5384-9310',
            hours: '24 hours',
            website: 'https://www.autohof-rueden.de',
            services: {
              highPressure: true,
              automaticWash: true,
              manualWash: true,
              interiorCleaning: true,
              engineWash: true,
              truckParking: true,
              restaurant: true,
              heavyDuty: true
            },
            priceRange: '$$$',
            detailedPrices: [
              { service: 'Standard Wash', price: '€60,00', description: 'Lavagem externa básica' },
              { service: 'Premium Wash', price: '€90,00', description: 'Lavagem externa completa' },
              { service: 'Complete Clean', price: '€150,00', description: 'Lavagem completa com interior' }
            ],
            detailedSchedule: [
              { day: 'Segunda-feira', hours: '24 horas' },
              { day: 'Terça-feira', hours: '24 horas' },
              { day: 'Quarta-feira', hours: '24 horas' },
              { day: 'Quinta-feira', hours: '24 horas' },
              { day: 'Sexta-feira', hours: '24 horas' },
              { day: 'Sábado', hours: '24 horas' },
              { day: 'Domingo', hours: '24 horas' }
            ],
            reviews: [
              { 
                user: 'Hans M.', 
                rating: 5, 
                comment: 'Eficiente e muito profissional. Melhor lavagem da região.', 
                date: '2023-11-20',
                serviceUsed: 'Premium Wash',
                waitTime: '25 minutos',
                price: '€90,00'
              },
              { 
                user: 'Klaus B.', 
                rating: 4, 
                comment: 'Um pouco caro, mas o serviço é excelente.', 
                date: '2023-10-05',
                serviceUsed: 'Complete Clean',
                waitTime: '45 minutos',
                price: '€150,00'
              }
            ],
            lastUpdatedPrice: '2023-11-15',
            averageWaitTime: '35 minutos'
          },
          // Ásia
          {
            id: 'jp-1',
            name: 'トラック洗車センター東京',
            address: '〒270-1431 千葉県白井市根1775',
            country: 'Japan',
            countryCode: 'JP',
            latitude: 35.8187,
            longitude: 140.0489,
            rating: 4.8,
            totalRatings: 289,
            phone: '+81 47-492-1234',
            hours: '8:00 AM - 8:00 PM',
            services: {
              highPressure: true,
              automaticWash: true,
              manualWash: true,
              interiorCleaning: true,
              engineWash: true,
              truckParking: true,
              restaurant: false,
              heavyDuty: true
            },
            priceRange: '$$$',
            detailedPrices: [
              { service: 'Standard Wash', price: '¥6,500', description: 'Lavagem externa básica' },
              { service: 'Premium Wash', price: '¥10,800', description: 'Lavagem externa premium' },
              { service: 'Full Detail', price: '¥25,000', description: 'Lavagem completa detalhada' }
            ],
            detailedSchedule: [
              { day: 'Segunda-feira', hours: '8:00 - 20:00' },
              { day: 'Terça-feira', hours: '8:00 - 20:00' },
              { day: 'Quarta-feira', hours: '8:00 - 20:00' },
              { day: 'Quinta-feira', hours: '8:00 - 20:00' },
              { day: 'Sexta-feira', hours: '8:00 - 20:00' },
              { day: 'Sábado', hours: '8:00 - 20:00' },
              { day: 'Domingo', hours: '8:00 - 18:00' }
            ],
            reviews: [
              { 
                user: 'Takashi I.', 
                rating: 5, 
                comment: 'Serviço impecável. Jamais vi meu caminhão tão limpo.', 
                date: '2023-10-12',
                serviceUsed: 'Full Detail',
                waitTime: '1 hora',
                price: '¥25,000'
              },
              { 
                user: 'Hiroshi K.', 
                rating: 5, 
                comment: 'Excelente qualidade, pessoal muito atencioso.', 
                date: '2023-09-25',
                serviceUsed: 'Premium Wash',
                waitTime: '30 minutos',
                price: '¥10,800'
              }
            ],
            lastUpdatedPrice: '2023-12-05',
            averageWaitTime: '45 minutos'
          }
        ];
        
        setTruckWashers(washersData);
        setFilteredWashers(washersData);
        setIsLoading(false);
      } catch (error) {
        console.error('Erro ao carregar dados de lavadores de caminhões:', error);
        setIsLoading(false);
      }
    };
    
    fetchWashers();
  }, []);
// Efeito para carregar detalhes adicionais do lavador quando um for selecionado
  useEffect(() => {
    if (selectedWasher) {
      setPriceDetails(selectedWasher.detailedPrices || []);
      setScheduleDetails(selectedWasher.detailedSchedule || []);
      setReviews(selectedWasher.reviews || []);
    }
  }, [selectedWasher]);
  
  // Efeito para aplicar filtros
  useEffect(() => {
    if (truckWashers.length > 0) {
      let filtered = [...truckWashers];
      
      // Filtrar por país
      if (filters.country !== 'all') {
        filtered = filtered.filter(washer => washer.countryCode === filters.country);
      }
      
      // Filtrar por faixa de preço
      if (filters.priceRange !== 'all') {
        filtered = filtered.filter(washer => washer.priceRange === filters.priceRange);
      }
      
      // Filtrar por classificação mínima
      if (filters.minRating > 0) {
        filtered = filtered.filter(washer => washer.rating >= filters.minRating);
      }
      
      // Filtros de serviços
      if (filters.highPressure) {
        filtered = filtered.filter(washer => washer.services.highPressure);
      }
      
      if (filters.automaticWash) {
        filtered = filtered.filter(washer => washer.services.automaticWash);
      }
      
      if (filters.truckParking) {
        filtered = filtered.filter(washer => washer.services.truckParking);
      }
      
      if (filters.restaurant) {
        filtered = filtered.filter(washer => washer.services.restaurant);
      }
      
      if (filters.heavyDuty) {
        filtered = filtered.filter(washer => washer.services.heavyDuty);
      }
      
      // Filtro de aberto agora
      if (filters.openNow) {
        const now = new Date();
        const dayOfWeek = now.getDay();
        const currentHour = now.getHours();
        
        filtered = filtered.filter(washer => {
          if (washer.hours === '24 hours') return true;
          
          // Verificação mais precisa para horários personalizados seria implementada aqui
          // Essa é uma simplificação para demonstração
          return washer.hours.includes('AM') || washer.hours.includes('PM');
        });
      }
      
      setFilteredWashers(filtered);
    }
  }, [filters, truckWashers]);
  
  // Efeito para rastrear a localização do usuário
  useEffect(() => {
    // Obter localização atual do usuário
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
      }, error => {
        console.error('Erro ao obter localização:', error);
      });
    }
    
    // Inscrição para atualizações de localização via KingLoc (opcional)
    const locationSubscription = kingLocBridge.current.subscribeToLocationUpdates(userId, (location) => {
      if (location && location.latitude && location.longitude) {
        setUserLocation({
          lat: location.latitude,
          lng: location.longitude
        });
      }
    });
    
    // Limpar inscrição ao desmontar
    return () => {
      if (locationSubscription && locationSubscription.unsubscribe) {
        locationSubscription.unsubscribe();
      }
    };
  }, [userId]);
  
  // Manipuladores de eventos para filtros
  const handleFilterChange = (name, value) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };
// Lista de países para o filtro
  const countries = [
    { code: 'all', name: 'Todos os Países' },
    { code: 'US', name: 'Estados Unidos' },
    { code: 'CA', name: 'Canadá' },
    { code: 'MX', name: 'México' },
    { code: 'BR', name: 'Brasil' },
    { code: 'AR', name: 'Argentina' },
    { code: 'DE', name: 'Alemanha' },
    { code: 'FR', name: 'França' },
    { code: 'ES', name: 'Espanha' },
    { code: 'JP', name: 'Japão' },
    { code: 'CN', name: 'China' },
    { code: 'AU', name: 'Austrália' },
    { code: 'ZA', name: 'África do Sul' },
    { code: 'MA', name: 'Marrocos' }
  ];
  
  // Faixas de preço para filtro
  const priceRanges = [
    { value: 'all', label: 'Todos os Preços' },
    { value: '$', label: 'Econômico ($)' },
    { value: '$$', label: 'Moderado ($$)' },
    { value: '$$$', label: 'Premium ($$$)' }
  ];
  
  // Manipulador para mudança de aba
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  // Manipuladores para o formulário de feedback
  const handleFeedbackChange = (name, value) => {
    setFeedbackData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const submitFeedback = () => {
    if (!selectedWasher || !feedbackData.rating) return;
    
    // Aqui você enviaria os dados para o backend
    // Para demonstração, vamos apenas atualizar localmente
    const newReview = {
      user: userName,
      rating: feedbackData.rating,
      comment: feedbackData.comment,
      date: new Date().toISOString().split('T')[0],
      serviceUsed: feedbackData.serviceName,
      waitTime: feedbackData.waitTime,
      price: feedbackData.price,
      visited: feedbackData.visited
    };
    
    // Atualiza localmente
    const updatedReviews = [newReview, ...reviews];
    setReviews(updatedReviews);
    
    // Atualiza o lavador selecionado
    if (selectedWasher) {
      const updatedWasher = {
        ...selectedWasher,
        reviews: updatedReviews,
        // Recalcula a nova classificação
        rating: ((selectedWasher.rating * selectedWasher.totalRatings) + feedbackData.rating) / (selectedWasher.totalRatings + 1),
        totalRatings: selectedWasher.totalRatings + 1
      };
      
      // Atualiza o lavador selecionado e na lista
      setSelectedWasher(updatedWasher);
      setTruckWashers(truckWashers.map(washer => 
        washer.id === updatedWasher.id ? updatedWasher : washer
      ));
    }
    
    // Limpa o formulário e fecha
    setFeedbackData({
      rating: 0,
      comment: '',
      price: '',
      waitTime: '',
      serviceName: '',
      visited: new Date().toISOString().split('T')[0]
    });
    setShowFeedbackForm(false);
  };
  
  // Renderizar ícone personalizado para o washer
  const renderWasherIcon = (washer) => {
    // A cor do ícone varia com a classificação
    const ratingColors = {
      high: '#4CAF50', // Verde para rating >= 4.5
      medium: '#FFC107', // Amarelo para ratings >= 4.0 e < 4.5
      low: '#F44336' // Vermelho para ratings < 4.0
    };
    
    const getRatingColor = (rating) => {
      if (rating >= 4.5) return ratingColors.high;
      if (rating >= 4.0) return ratingColors.medium;
      return ratingColors.low;
    };
    
    return (
      <div 
        className="washer-marker" 
        style={{ 
          backgroundColor: 'white',
          border: `3px solid ${getRatingColor(washer.rating)}`,
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '36px',
          height: '36px',
          boxShadow: '0 2px 5px rgba(0,0,0,0.3)'
        }}
      >
        <Droplet size={20} color={getRatingColor(washer.rating)} />
      </div>
    );
  };
  
  // Navegação para o lavador de caminhões selecionado
  const navigateToWasher = (washer) => {
    if (window.KingLoc && typeof window.KingLoc.navigateTo === 'function') {
      window.KingLoc.navigateTo(washer.latitude, washer.longitude);
    }
  };
  
  if (isLoading) {
    return <div className="loading">Carregando lavadores de caminhões globais...</div>;
  }
return (
    <div className="truck-washers-map-container h-full w-full relative">
      <Map
        ref={mapRef}
        center={mapCenter}
        zoom={initialZoom}
        className="h-full w-full"
        zoomControl={false}
      >
        <ZoomControl position="bottomright" />
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {/* Marcador de localização do usuário */}
        <Marker position={[userLocation.lat, userLocation.lng]}>
          <Popup>Sua localização atual</Popup>
        </Marker>
        
        {/* Marcadores de lavadores de caminhões */}
        <LayerGroup>
          {filteredWashers.map(washer => (
            <Marker 
              key={washer.id}
              position={[washer.latitude, washer.longitude]}
              icon={renderWasherIcon(washer)}
              eventHandlers={{
                click: () => setSelectedWasher(washer)
              }}
            >
              <Popup>
                <div className="washer-popup">
                  <h3 className="text-lg font-bold">{washer.name}</h3>
                  <p className="text-sm text-gray-600">{washer.address}</p>
                  <p className="flex items-center mt-1">
                    <Star size={16} className="text-yellow-500 mr-1" />
                    <span className="font-semibold">{washer.rating.toFixed(1)}</span>
                    <span className="text-gray-500 text-xs ml-1">({washer.totalRatings} avaliações)</span>
                  </p>
                </div>
              </Popup>
            </Marker>
          ))}
        </LayerGroup>
      </Map>
      
      {/* Painel de filtros */}
      <div className="filter-toggle absolute top-4 left-4 z-10">
        <Button 
          onClick={() => setShowFilters(!showFilters)} 
          className="bg-white text-gray-800 shadow-lg hover:bg-gray-100"
        >
          <Filter size={16} className="mr-2" />
          Filtros {showFilters ? '▲' : '▼'}
        </Button>
      </div>
      
      {/* Painel de filtros expandido */}
      {showFilters && (
        <div className="filters-panel absolute top-16 left-4 bg-white rounded-lg shadow-lg p-4 z-10 w-64">
          <h3 className="font-bold text-gray-800 mb-3 border-b pb-2">Filtrar Lavadores</h3>
          
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 mb-2">País</h4>
            <Select
              value={filters.country}
              onChange={(e) => handleFilterChange('country', e.target.value)}
              className="w-full"
            >
              {countries.map(country => (
                <MenuItem key={country.code} value={country.code}>
                  {country.name}
                </MenuItem>
              ))}
            </Select>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 mb-2">Faixa de Preço</h4>
            <Select
              value={filters.priceRange}
              onChange={(e) => handleFilterChange('priceRange', e.target.value)}
              className="w-full"
            >
              {priceRanges.map(range => (
                <MenuItem key={range.value} value={range.value}>
                  {range.label}
                </MenuItem>
              ))}
            </Select>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 mb-2">Classificação Mínima</h4>
            <Rating
              value={filters.minRating}
              onChange={(event, newValue) => {
                handleFilterChange('minRating', newValue);
              }}
            />
          </div>
          
          <div className="mb-3">
            <h4 className="font-medium text-gray-700 mb-2">Serviços</h4>
            <div className="space-y-2">
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.openNow}
                    onChange={(e) => handleFilterChange('openNow', e.target.checked)}
                  />
                }
                label="Aberto Agora"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.highPressure}
                    onChange={(e) => handleFilterChange('highPressure', e.target.checked)}
                  />
                }
                label="Lavagem de Alta Pressão"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.automaticWash}
                    onChange={(e) => handleFilterChange('automaticWash', e.target.checked)}
                  />
                }
                label="Lavagem Automática"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.truckParking}
                    onChange={(e) => handleFilterChange('truckParking', e.target.checked)}
                  />
                }
                label="Estacionamento para Caminhões"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.restaurant}
                    onChange={(e) => handleFilterChange('restaurant', e.target.checked)}
                  />
                }
                label="Restaurante"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={filters.heavyDuty}
                    onChange={(e) => handleFilterChange('heavyDuty', e.target.checked)}
                  />
                }
                label="Para Veículos Pesados"
              />
            </div>
          </div>
          
          <Button 
            onClick={() => setFilters({
              openNow: false,
              highPressure: false,
              automaticWash: false,
              truckParking: false,
              restaurant: false,
              heavyDuty: false,
              country: 'all',
              priceRange: 'all',
              minRating: 0
            })}
            className="w-full mt-2 bg-gray-200 hover:bg-gray-300 text-gray-800"
          >
            Limpar Filtros
          </Button>
        </div>
      )}
      
      {/* Detalhes do lavador selecionado */}
      {selectedWasher && (
        <div className="washer-details absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 z-10 max-w-md w-full md:w-1/3">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-xl font-bold">{selectedWasher.name}</h2>
              <p className="text-gray-600">{selectedWasher.address}</p>
              <p className="text-gray-500">{selectedWasher.country}</p>
            </div>
            <button 
              onClick={() => setSelectedWasher(null)}
              className="text-gray-400 hover:text-gray-600"
            >
              <XCircle size={20} />
            </button>
          </div>
          
          <div className="flex items-center mt-2 mb-3">
            <div className="flex items-center mr-4">
              <Star size={16} className="text-yellow-500 mr-1" />
              <span className="font-semibold">{selectedWasher.rating.toFixed(1)}</span>
              <span className="text-gray-500 text-xs ml-1">({selectedWasher.totalRatings})</span>
            </div>
            <div className="text-gray-600">{selectedWasher.priceRange}</div>
          </div>
          
          <Tabs value={activeTab} onChange={handleTabChange} className="mb-3">
            <Tab label="Informações" />
            <Tab label="Preços" />
            <Tab label="Horários" />
            <Tab label="Avaliações" />
          </Tabs>
          
          {/* Conteúdo da aba de Informações */}
          {activeTab === 0 && (
            <div className="info-tab">
              <div className="mb-3 grid grid-cols-2 gap-2">
                <div className="flex items-center">
                  <Phone size={16} className="text-gray-500 mr-2" />
                  <span>{selectedWasher.phone || 'N/A'}</span>
                </div>
                <div className="flex items-center">
                  <Clock size={16} className="text-gray-500 mr-2" />
                  <span>{selectedWasher.hours || 'Horário não disponível'}</span>
                </div>
              </div>
              
              <div className="mb-3">
                <h3 className="font-semibold mb-1">Serviços Disponíveis:</h3>
                <div className="grid grid-cols-2 gap-1 text-sm">
                  {selectedWasher.services.highPressure && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Lavagem de Alta Pressão</span>
                    </div>
                  )}
                  {selectedWasher.services.automaticWash && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Lavagem Automática</span>
                    </div>
                  )}
                  {selectedWasher.services.manualWash && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Lavagem Manual</span>
                    </div>
                  )}
                  {selectedWasher.services.interiorCleaning && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Limpeza Interior</span>
                    </div>
                  )}
                  {selectedWasher.services.engineWash && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Lavagem de Motor</span>
                    </div>
                  )}
                  {selectedWasher.services.truckParking && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Estacionamento</span>
                    </div>
                  )}
                  {selectedWasher.services.restaurant && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Restaurante</span>
                    </div>
                  )}
                  {selectedWasher.services.heavyDuty && (
                    <div className="flex items-center">
                      <Droplet size={14} className="text-blue-500 mr-1" />
                      <span>Veículos Pesados</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mb-3">
                <p><strong>Tempo médio de espera:</strong> {selectedWasher.averageWaitTime || 'Não disponível'}</p>
                <p><strong>Última atualização de preços:</strong> {selectedWasher.lastUpdatedPrice || 'Não disponível'}</p>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={() => navigateToWasher(selectedWasher)}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Navigation size={16} className="mr-2" />
                  Navegar até aqui
                </Button>
                
                <Button
                  onClick={() => setShowFeedbackForm(true)}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <MessageSquare size={16} className="mr-2" />
                  Avaliar
                </Button>
              </div>
            </div>
          )}
          
          {/* Conteúdo da aba de Preços */}
          {activeTab === 1 && (
            <div className="prices-tab">
              <h3 className="font-semibold mb-2 text-gray-800">Tabela de Preços</h3>
              
              {priceDetails.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="py-2 px-2 text-left">Serviço</th>
                        <th className="py-2 px-2 text-right">Preço</th>
                        <th className="py-2 px-2 text-left">Descrição</th>
                      </tr>
                    </thead>
                    <tbody>
                      {priceDetails.map((item, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-2 font-medium">{item.service}</td>
                          <td className="py-2 px-2 text-right">{item.price}</td>
                          <td className="py-2 px-2 text-gray-600">{item.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-gray-500">Detalhes de preços não disponíveis</p>
              )}
              
              <div className="mt-3 text-sm text-gray-500">
                <p className="flex items-center">
                  <Info size={14} className="mr-1" />
                  Os preços podem variar. Última atualização: {selectedWasher.lastUpdatedPrice || 'Desconhecida'}
                </p>
              </div>
            </div>
          )}
          
          {/* Conteúdo da aba de Horários */}
          {activeTab === 2 && (
            <div className="schedule-tab">
              <h3 className="font-semibold mb-2 text-gray-800">Horário de Funcionamento</h3>
              
              {scheduleDetails.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="py-2 px-2 text-left">Dia</th>
                        <th className="py-2 px-2 text-right">Horário</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scheduleDetails.map((item, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-2 font-medium">{item.day}</td>
                          <td className="py-2 px-2 text-right">{item.hours}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-gray-500">Detalhes de horários não disponíveis</p>
              )}
            </div>
          )}
          
          {/* Conteúdo da aba de Avaliações */}
          {activeTab === 3 && (
            <div className="reviews-tab">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-semibold text-gray-800">Avaliações de Usuários</h3>
                <Button
                  onClick={() => setShowFeedbackForm(true)}
                  className="text-sm bg-blue-500 hover:bg-blue-600 text-white"
                >
                  Adicionar
                </Button>
              </div>
              
              {reviews.length > 0 ? (
                <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                  {reviews.map((review, index) => (
                    <div key={index} className="border-b pb-3">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          <span className="font-medium">{review.user}</span>
                          <span className="text-gray-500 text-xs ml-2">• {review.date}</span>
                        </div>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              size={14}
                              fill={i < review.rating ? "#FFD700" : "none"}
                              stroke={i < review.rating ? "#FFD700" : "#CBD5E0"}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-700 text-sm mt-1">{review.comment}</p>
                      <div className="mt-1 text-xs text-gray-500 flex flex-wrap gap-2">
                        {review.serviceUsed && <span>Serviço: {review.serviceUsed}</span>}
                        {review.price && <span>Preço: {review.price}</span>}
                        {review.waitTime && <span>Tempo de espera: {review.waitTime}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">Nenhuma avaliação disponível</p>
              )}
            </div>
          )}
        </div>
      )}
      
      {/* Formulário de feedback */}
      {showFeedbackForm && selectedWasher && (
        <div className="feedback-modal fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setShowFeedbackForm(false)}></div>
          <div className="relative bg-white rounded-lg p-6 m-4 max-w-md w-full z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-bold">Avaliar {selectedWasher.name}</h3>
              <button 
                onClick={() => setShowFeedbackForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <XCircle size={20} />
              </button>
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 mb-1">Sua classificação</label>
              <Rating
                value={feedbackData.rating}
                onChange={(event, newValue) => {
                  handleFeedbackChange('rating', newValue);
                }}
                size="large"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 mb-1">Serviço utilizado</label>
              <Select
                value={feedbackData.serviceName}
                onChange={(e) => handleFeedbackChange('serviceName', e.target.value)}
                className="w-full"
                displayEmpty
              >
                <MenuItem value="" disabled>Selecione o serviço</MenuItem>
                {priceDetails.map((price, idx) => (
                  <MenuItem key={idx} value={price.service}>
                    {price.service} ({price.price})
                  </MenuItem>
                ))}
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-gray-700 mb-1">Preço pago</label>
                <TextField
                  value={feedbackData.price}
                  onChange={(e) => handleFeedbackChange('price', e.target.value)}
                  placeholder="ex: R$150,00"
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-gray-700 mb-1">Tempo de espera</label>
                <TextField
                  value={feedbackData.waitTime}
                  onChange={(e) => handleFeedbackChange('waitTime', e.target.value)}
                  placeholder="ex: 30 minutos"
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 mb-1">Data da visita</label>
              <TextField
                type="date"
                value={feedbackData.visited}
                onChange={(e) => handleFeedbackChange('visited', e.target.value)}
                className="w-full"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 mb-1">Seu comentário</label>
              <TextField
                value={feedbackData.comment}
                onChange={(e) => handleFeedbackChange('comment', e.target.value)}
                multiline
                rows={3}
                placeholder="Conte sua experiência..."
                className="w-full"
              />
            </div>
            
            <div className="flex justify-end mt-4">
              <Button
                onClick={() => setShowFeedbackForm(false)}
                className="mr-2 bg-gray-200 hover:bg-gray-300 text-gray-800"
              >
                Cancelar
              </Button>
              
              <Button
                onClick={submitFeedback}
                disabled={!feedbackData.rating}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Send size={16} className="mr-2" />
                Enviar avaliação
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EnhancedGlobalTruckWashersMap;