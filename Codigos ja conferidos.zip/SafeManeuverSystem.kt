// Sistema de Manobras Seguras
// app/src/main/kotlin/com/kingroad/routing/maneuvers

class SafeManeuverManager(
    private val vehicleService: VehicleService,
    private val infrastructureService: InfrastructureService,
    private val terrainService: TerrainService
) {
    data class ManeuverAnalysis(
        val type: ManeuverType,
        val angle: Double,
        val requiredSpace: Space,
        val terrain: TerrainInfo,
        val risks: List<ManeuverRisk>
    )

    data class Space(
        val width: Double,
        val length: Double,
        val turningRadius: Double
    )

    data class TerrainInfo(
        val slope: Double,
        val surface: SurfaceType,
        val stability: TerrainStability
    )

    enum class ManeuverType {
        FORWARD_TURN,
        REVERSE_TURN,
        MULTI_POINT_TURN,
        ROUNDABOUT,
        INTERSECTION
    }

    enum class ManeuverRisk {
        TIGHT_ANGLE,
        INSUFFICIENT_SPACE,
        STEEP_TERRAIN,
        UNSTABLE_SURFACE,
        VISIBILITY_ISSUES,
        TRAFFIC_CONFLICT
    }

    // Validação de manobra
    suspend fun validateManeuver(
        maneuver: Maneuver,
        vehicle: Vehicle
    ): ManeuverValidation {
        // Análise completa da manobra
        val analysis = analyzeManeuver(maneuver, vehicle)
        
        // Verificar se a manobra é segura
        val risks = identifyRisks(analysis, vehicle)
        
        return if (risks.isEmpty()) {
            ManeuverValidation(isValid = true)
        } else {
            ManeuverValidation(
                isValid = false,
                risks = risks,
                alternativeSuggestion = findSafeAlternative(maneuver, vehicle)
            )
        }
    }

    // Análise de manobra
    private suspend fun analyzeManeuver(
        maneuver: Maneuver,
        vehicle: Vehicle
    ): ManeuverAnalysis {
        val space = calculateRequiredSpace(maneuver, vehicle)
        val terrain = analyzeTerrainConditions(maneuver.location)
        
        return ManeuverAnalysis(
            type = determineManeuverType(maneuver),
            angle = calculateManeuverAngle(maneuver),
            requiredSpace = space,
            terrain = terrain,
            risks = emptyList()
        )
    }

    // Cálculo de espaço necessário
    private fun calculateRequiredSpace(
        maneuver: Maneuver,
        vehicle: Vehicle
    ): Space {
        val minWidth = vehicle.width * 1.5
        val minLength = when (vehicle.type) {
            VehicleType.ARTICULATED_TRUCK -> vehicle.length * 2.5
            VehicleType.RIGID_TRUCK -> vehicle.length * 2.0
            else -> vehicle.length * 1.5
        }
        
        return Space(
            width = minWidth,
            length = minLength,
            turningRadius = vehicle.turningRadius * 1.2
        )
    }

    // Verifica se uma manobra em U é segura (normalmente não é)
    private suspend fun isUTurnSafe(
        location: Location,
        vehicle: Vehicle
    ): Boolean {
        val requiredWidth = vehicle.length * 1.5
        val availableSpace = infrastructureService.getAvailableSpace(location)
        
        // U-turns são quase sempre inseguros para caminhões
        if (vehicle.type == VehicleType.ARTICULATED_TRUCK) return false
        
        return availableSpace.width >= requiredWidth &&
               terrain.slope < MAX_SAFE_SLOPE &&
               !location.isUrbanArea
    }

    // Encontrar alternativa segura
    private suspend fun findSafeAlternative(
        maneuver: Maneuver,
        vehicle: Vehicle
    ): SafeAlternative {
        // Procurar rotas alternativas que evitem manobras perigosas
        val alternatives = infrastructureService.findAlternativeRoutes(
            location = maneuver.location,
            radius = SAFE_SEARCH_RADIUS,
            vehicle = vehicle
        )

        return alternatives
            .filter { validateManeuverSafety(it, vehicle) }
            .minByOrNull { it.distance }
            ?: createLongDistanceAlternative(maneuver, vehicle)
    }

    // Validação da segurança da manobra
    private suspend fun validateManeuverSafety(
        maneuver: Maneuver,
        vehicle: Vehicle
    ): Boolean {
        // Verificar ângulo da curva
        if (maneuver.angle > MAX_SAFE_ANGLE) return false
        
        // Verificar inclinação do terreno
        val terrain = terrainService.getTerrainInfo(maneuver.location)
        if (terrain.slope > MAX_SAFE_SLOPE) return false
        
        // Verificar espaço disponível
        val requiredSpace = calculateRequiredSpace(maneuver, vehicle)
        val availableSpace = infrastructureService.getAvailableSpace(maneuver.location)
        
        return availableSpace.width >= requiredSpace.width &&
               availableSpace.length >= requiredSpace.length &&
               terrain.stability == TerrainStability.STABLE
    }

    companion object {
        const val MAX_SAFE_ANGLE = 120.0 // graus
        const val MAX_SAFE_SLOPE = 5.0 // porcentagem
        const val SAFE_SEARCH_RADIUS = 5000.0 // metros
        const val MIN_TURNING_SPACE = 1.5 // multiplicador do comprimento do veículo
    }
}

// Tipos de superfície
enum class SurfaceType {
    ASPHALT,
    CONCRETE,
    GRAVEL,
    DIRT,
    UNSTABLE
}

// Estabilidade do terreno
enum class TerrainStability {
    STABLE,
    MODERATE,
    UNSTABLE,
    HAZARDOUS
}

// Resultado da validação
data class ManeuverValidation(
    val isValid: Boolean,
    val risks: List<ManeuverRisk> = emptyList(),
    val alternativeSuggestion: SafeAlternative? = null
)

// Alternativa segura
data class SafeAlternative(
    val route: Route,
    val distance: Double,
    val estimatedTime: Duration,
    val maneuvers: List<Maneuver>
)