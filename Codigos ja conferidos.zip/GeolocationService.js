// GeolocationService.js
// Serviço para monitorar localização e detectar cruzamento de fronteiras

import { useState, useEffect } from 'react';
import Geolocation from '@react-native-community/geolocation';
import { PermissionsAndroid, Platform } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

class GeolocationService {
  constructor() {
    this.watchId = null;
    this.isWatching = false;
    this.lastCountry = null;
    this.listeners = [];
    this.reverseGeocodingAPI = 'https://api.bigdatacloud.net/data/reverse-geocode-client';
    this.crossingHistory = [];
    
    // Carregar o último país conhecido
    this.loadLastCountry();
  }
  
  // Carregar o último país conhecido do armazenamento local
  async loadLastCountry() {
    try {
      const lastCountry = await AsyncStorage.getItem('lastCountry');
      if (lastCountry) {
        this.lastCountry = JSON.parse(lastCountry);
      }
    } catch (error) {
      console.error('Erro ao carregar último país:', error);
    }
  }
  
  // Salvar o país atual no armazenamento local
  async saveLastCountry(country) {
    try {
      await AsyncStorage.setItem('lastCountry', JSON.stringify(country));
    } catch (error) {
      console.error('Erro ao salvar último país:', error);
    }
  }
  
  // Solicitar permissões de localização no Android
  async requestLocationPermission() {
    if (Platform.OS === 'ios') {
      return true;
    }
    
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Permissão de Localização',
          message: 'O KingRoad precisa acessar sua localização para funcionar corretamente.',
          buttonNeutral: 'Perguntar Depois',
          buttonNegative: 'Cancelar',
          buttonPositive: 'OK',
        },
      );
      
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn('Erro ao solicitar permissão de localização:', err);
      return false;
    }
  }
  
  // Iniciar monitoramento de localização
  async startWatching() {
    if (this.isWatching) return;
    
    const hasPermission = await this.requestLocationPermission();
    
    if (!hasPermission) {
      console.warn('Permissão de localização não concedida');
      return false;
    }
    
    this.isWatching = true;
    
    this.watchId = Geolocation.watchPosition(
      (position) => {
        this.handlePositionUpdate(position);
      },
      (error) => {
        console.error('Erro de geolocalização:', error);
      },
      {
        enableHighAccuracy: true,
        distanceFilter: 500, // Atualizar a cada 500 metros
        interval: 10000, // 10 segundos no Android
        fastestInterval: 5000 // 5 segundos no Android
      }
    );
    
    return true;
  }
  
  // Parar monitoramento de localização
  stopWatching() {
    if (!this.isWatching) return;
    
    Geolocation.clearWatch(this.watchId);
    this.watchId = null;
    this.isWatching = false;
  }
  
  // Adicionar um listener para eventos de cruzamento de fronteira
  addBorderCrossingListener(listener) {
    this.listeners.push(listener);
    return () => this.removeBorderCrossingListener(listener);
  }
  
  // Remover um listener
  removeBorderCrossingListener(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  // Obter país com base nas coordenadas (geocodificação reversa)
  async getCountryFromCoordinates(latitude, longitude) {
    try {
      const response = await axios.get(this.reverseGeocodingAPI, {
        params: {
          latitude,
          longitude,
          localityLanguage: 'pt'
        }
      });
      
      // Dados do país atual
      const country = {
        name: response.data.countryName,
        code: response.data.countryCode,
        city: response.data.city || response.data.locality || null,
        timestamp: new Date().toISOString()
      };
      
      return country;
    } catch (error) {
      console.error('Erro na geocodificação reversa:', error);
      return null;
    }
  }
  
  // Processar atualização de posição e verificar cruzamento de fronteira
  async handlePositionUpdate(position) {
    const { latitude, longitude } = position.coords;
    
    try {
      // Obter informações do país com base nas coordenadas
      const currentCountry = await this.getCountryFromCoordinates(latitude, longitude);
      
      if (!currentCountry) return;
      
      // Verificar se houve cruzamento de fronteira
      if (this.lastCountry && this.lastCountry.code !== currentCountry.code) {
        // Registrar o cruzamento no histórico
        const crossing = {
          from: this.lastCountry.name,
          to: currentCountry.name,
          timestamp: new Date().toISOString(),
          location: {
            latitude,
            longitude
          }
        };
        
        this.crossingHistory.push(crossing);
        
        // Salvar histórico de cruzamentos
        await this.saveCrossingHistory();
        
        // Notificar listeners sobre o cruzamento de fronteira
        this.notifyBorderCrossing(currentCountry, this.lastCountry);
      }
      
      // Atualizar último país conhecido
      this.lastCountry = currentCountry;
      
      // Salvar último país no armazenamento local
      await this.saveLastCountry(currentCountry);
      
    } catch (error) {
      console.error('Erro ao processar atualização de posição:', error);
    }
  }
  
  // Notificar listeners sobre cruzamento de fronteira
  notifyBorderCrossing(newCountry, oldCountry) {
    this.listeners.forEach(listener => {
      listener({
        newCountry,
        oldCountry,
        timestamp: new Date().toISOString()
      });
    });
  }
  
  // Salvar histórico de cruzamentos no armazenamento local
  async saveCrossingHistory() {
    try {
      // Manter apenas os últimos 20 cruzamentos
      if (this.crossingHistory.length > 20) {
        this.crossingHistory = this.crossingHistory.slice(-20);
      }
      
      await AsyncStorage.setItem('borderCrossingHistory', JSON.stringify(this.crossingHistory));
    } catch (error) {
      console.error('Erro ao salvar histórico de cruzamentos:', error);
    }
  }
  
  // Carregar histórico de cruzamentos do armazenamento local
  async loadCrossingHistory() {
    try {
      const history = await AsyncStorage.getItem('borderCrossingHistory');
      
      if (history) {
        this.crossingHistory = JSON.parse(history);
      }
      
      return this.crossingHistory;
    } catch (error) {
      console.error('Erro ao carregar histórico de cruzamentos:', error);
      return [];
    }
  }
  
  // Obter histórico de cruzamentos
  getCrossingHistory() {
    return this.crossingHistory;
  }
  
  // Simular um cruzamento de fronteira (apenas para testes)
  simulateBorderCrossing(countryName, countryCode, cityName) {
    const oldCountry = this.lastCountry || { 
      name: 'Brasil', 
      code: 'BR',
      city: 'São Paulo',
      timestamp: new Date().toISOString()
    };
    
    const newCountry = {
      name: countryName,
      code: countryCode,
      city: cityName,
      timestamp: new Date().toISOString()
    };
    
    this.lastCountry = newCountry;
    this.saveLastCountry(newCountry);
    
    // Registrar no histórico
    const crossing = {
      from: oldCountry.name,
      to: newCountry.name,
      timestamp: new Date().toISOString(),
      location: {
        latitude: 0,
        longitude: 0
      }
    };
    
    this.crossingHistory.push(crossing);
    this.saveCrossingHistory();
    
    // Notificar listeners
    this.notifyBorderCrossing(newCountry, oldCountry);
    
    return { newCountry, oldCountry };
  }
}

// Criar e exportar uma instância única do serviço
const geolocationService = new GeolocationService();
export default geolocationService;

// Hook personalizado para usar o serviço de geolocalização em componentes React
export const useGeolocation = () => {
  const [currentCountry, setCurrentCountry] = useState(null);
  const [lastCrossing, setLastCrossing] = useState(null);
  const [isWatching, setIsWatching] = useState(geolocationService.isWatching);
  
  // Efeito para iniciar o monitoramento
  useEffect(() => {
    const startService = async () => {
      const started = await geolocationService.startWatching();
      setIsWatching(started);
      
      // Carregar último país conhecido
      if (geolocationService.lastCountry) {
        setCurrentCountry(geolocationService.lastCountry);
      }
      
      // Carregar último cruzamento
      const history = await geolocationService.loadCrossingHistory();
      if (history && history.length > 0) {
        setLastCrossing(history[history.length - 1]);
      }
    };
    
    startService();
    
    // Configurar listener para cruzamentos de fronteira
    const unsubscribe = geolocationService.addBorderCrossingListener((crossing) => {
      setCurrentCountry(crossing.newCountry);
      setLastCrossing({
        from: crossing.oldCountry.name,
        to: crossing.newCountry.name,
        timestamp: crossing.timestamp
      });
    });
    
    // Limpar ao desmontar
    return () => {
      unsubscribe();
    };
  }, []);
  
  // Expor métodos úteis e estado
  return {
    currentCountry,
    lastCrossing,
    isWatching,
    startWatching: geolocationService.startWatching.bind(geolocationService),
    stopWatching: geolocationService.stopWatching.bind(geolocationService),
    getHistory: geolocationService.loadCrossingHistory.bind(geolocationService),
    simulateCrossing: geolocationService.simulateBorderCrossing.bind(geolocationService)
  };
};