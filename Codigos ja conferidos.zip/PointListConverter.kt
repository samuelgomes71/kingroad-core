// PointListConverter.kt
package com.kingroad.database.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kingroad.database.GeoPoint

/**
 * Conversor para persistência de listas de pontos geográficos no Room
 */
class PointListConverter {
    private val gson = Gson()
    
    /**
     * Converte uma lista de pontos para string JSON para armazenamento
     * @param points Lista de pontos geográficos
     * @return String JSON representando a lista
     */
    @TypeConverter
    fun fromPointList(points: List<GeoPoint>): String {
        return gson.toJson(points)
    }
    
    /**
     * Converte uma string JSON para lista de pontos geográficos
     * @param json String JSON representando a lista
     * @return Lista de pontos geográficos
     */
    @TypeConverter
    fun toPointList(json: String): List<GeoPoint> {
        if (json.isBlank()) return emptyList()
        
        val listType = object : TypeToken<List<GeoPoint>>() {}.type
        return gson.fromJson(json, listType)
    }
}