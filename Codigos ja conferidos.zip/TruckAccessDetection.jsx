import React, { useState, useEffect } from 'react';
import { Truck, ArrowRight, ArrowLeft, AlertTriangle, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const TruckAccessDetection = () => {
  const [accessType, setAccessType] = useState(null); // 'single' ou 'separate'
  const [currentLocation, setCurrentLocation] = useState(null);
  const [showAccessInfo, setShowAccessInfo] = useState(false);

  // Estrutura de dados para pontos de acesso
  const AccessPointData = {
    type: '', // 'entrance', 'exit', 'both'
    coordinates: {
      lat: 0,
      lng: 0
    },
    restrictions: {
      height: 0,
      width: 0,
      weight: 0,
      turnRadius: 0
    },
    directions: {
      entry: 'left' || 'right',
      exit: 'left' || 'right'
    },
    isOneWay: false,
    trafficFlow: 'both', // 'in', 'out', 'both'
    maneuverSpace: {
      entryRadius: 0,
      exitRadius: 0,
      turningArea: false
    }
  };

  // Componente de Informações de Acesso
  const AccessInformation = () => (
    <div className="fixed top-4 right-4 bg-gray-900 p-4 rounded-lg shadow-lg max-w-md">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-white font-bold flex items-center">
          <Truck size={20} className="mr-2" />
          Informações de Acesso
        </h3>
        <button 
          onClick={() => setShowAccessInfo(false)}
          className="text-gray-400 hover:text-white"
        >
          <Info size={20} />
        </button>
      </div>

      <div className="space-y-4">
        {/* Tipo de Acesso */}
        <div className="bg-gray-800 p-3 rounded">
          <p className="text-white font-medium">
            {accessType === 'single' ? 'Acesso Único' : 'Acessos Separados'}
          </p>
          <p className="text-sm text-gray-400 mt-1">
            {accessType === 'single' 
              ? 'Entrada e saída pelo mesmo local'
              : 'Entrada e saída em locais diferentes'}
          </p>
        </div>

        {/* Restrições */}
        <div className="bg-gray-800 p-3 rounded">
          <p className="text-white font-medium mb-2">Restrições</p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-gray-400">Altura Máxima</p>
              <p className="text-white">4.5m</p>
            </div>
            <div>
              <p className="text-gray-400">Largura Máxima</p>
              <p className="text-white">3.2m</p>
            </div>
            <div>
              <p className="text-gray-400">Raio de Curva</p>
              <p className="text-white">15m</p>
            </div>
            <div>
              <p className="text-gray-400">Peso Máximo</p>
              <p className="text-white">40t</p>
            </div>
          </div>
        </div>

        {/* Área de Manobra */}
        <div className="bg-gray-800 p-3 rounded">
          <p className="text-white font-medium">Área de Manobra</p>
          <div className="mt-2 space-y-1">
            <p className="text-sm text-gray-400">
              {currentLocation?.maneuverSpace?.turningArea 
                ? '✓ Área de manobra disponível'
                : '✗ Sem área de manobra dedicada'}
            </p>
            <p className="text-sm text-gray-400">
              Raio de entrada: {currentLocation?.maneuverSpace?.entryRadius}m
            </p>
            <p className="text-sm text-gray-400">
              Raio de saída: {currentLocation?.maneuverSpace?.exitRadius}m
            </p>
          </div>
        </div>

        {/* Direções */}
        <div className="bg-gray-800 p-3 rounded">
          <p className="text-white font-medium mb-2">Direções</p>
          {accessType === 'single' ? (
            <div className="flex items-center text-sm text-gray-400">
              <ArrowRight size={16} className="mr-1" />
              <span>Entrada e saída pela {currentLocation?.directions?.entry}</span>
            </div>
          ) : (
            <div className="space-y-2 text-sm text-gray-400">
              <div className="flex items-center">
                <ArrowRight size={16} className="mr-1" />
                <span>Entrada pela {currentLocation?.directions?.entry}</span>
              </div>
              <div className="flex items-center">
                <ArrowLeft size={16} className="mr-1" />
                <span>Saída pela {currentLocation?.directions?.exit}</span>
              </div>
            </div>
          )}
        </div>

        {/* Alertas */}
        {currentLocation?.isOneWay && (
          <Alert className="bg-yellow-900 border-yellow-600">
            <AlertTriangle className="text-yellow-500" />
            <AlertDescription className="text-yellow-100">
              Atenção: Via de sentido único
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );

  // Indicador Visual de Acessos
  const AccessIndicator = () => (
    <div className="fixed bottom-4 left-4 bg-gray-900 p-3 rounded-lg shadow-lg">
      <button 
        onClick={() => setShowAccessInfo(true)}
        className="flex items-center space-x-2 text-white"
      >
        <Truck size={20} />
        <span>
          {accessType === 'single' ? 'Acesso Único' : 'Acessos Separados'}
        </span>
        <Info size={16} className="ml-2 text-gray-400" />
      </button>
    </div>
  );

  // Detectar tipo de acesso baseado na localização atual
  useEffect(() => {
    const detectAccess = (location) => {
      // Aqui seria implementada a lógica real de detecção
      // baseada nas coordenadas e dados do local
      
      // Exemplo de detecção
      if (location.entranceCount === 1 && location.exitCount === 1) {
        if (location.entranceCoordinates === location.exitCoordinates) {
          setAccessType('single');
        } else {
          setAccessType('separate');
        }
      }
    };

    // Simulação de dados de localização
    const mockLocation = {
      entranceCount: 1,
      exitCount: 1,
      entranceCoordinates: [0, 0],
      exitCoordinates: [1, 1],
      maneuverSpace: {
        entryRadius: 15,
        exitRadius: 15,
        turningArea: true
      },
      directions: {
        entry: 'direita',
        exit: 'esquerda'
      },
      isOneWay: true
    };

    setCurrentLocation(mockLocation);
    detectAccess(mockLocation);
  }, []);

  return (
    <div className="relative">
      {/* Mostrar indicador de acesso */}
      <AccessIndicator />

      {/* Mostrar informações detalhadas quando solicitado */}
      {showAccessInfo && <AccessInformation />}
    </div>
  );
};

export default TruckAccessDetection;