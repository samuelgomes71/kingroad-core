import React, { useState } from 'react';
import { Share2, Radio, User, Users, X, Check, Bell, Search, Play, Clock } from 'lucide-react';

const CompartilhamentoInternoRadios = () => {
  // Para demonstrar tanto o envio quanto o recebimento de rádios
  const [activeTab, setActiveTab] = useState('enviar'); // 'enviar' ou 'recebidas'
  
  // Estado para o modo de envio
  const [selectedRadio, setSelectedRadio] = useState(null);
  const [searchUser, setSearchUser] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [sendStatus, setSendStatus] = useState(null); // null, 'sending', 'sent', 'error'
  
  // Estado para o modo de recebimento
  const [receivedRadios, setReceivedRadios] = useState([
    {
      id: 1,
      radioName: 'Rádio Sertaneja FM',
      senderName: 'Carlos Silva',
      timestamp: '2 horas atrás',
      status: 'pending', // 'pending', 'accepted', 'ignored'
      country: 'Brasil',
      language: 'Português'
    },
    {
      id: 2,
      radioName: 'Clássicos do Rock',
      senderName: 'Ana Ribeiro',
      timestamp: '3 dias atrás',
      status: 'accepted',
      country: 'Brasil',
      language: 'Português'
    }
  ]);
  
  // Dados simulados
  const myRadios = [
    { id: 1, name: 'Rádio Estrada FM', country: 'Brasil', language: 'Português' },
    { id: 2, name: 'Caminhoneiros Mix', country: 'Brasil', language: 'Português' },
    { id: 3, name: 'Truckers USA', country: 'EUA', language: 'Inglês' }
  ];
  
  const contacts = [
    { id: 1, name: 'João Motorista', status: 'online', lastSeen: 'Agora' },
    { id: 2, name: 'Maria Transportes', status: 'offline', lastSeen: '2h atrás' },
    { id: 3, name: 'Roberto Caminhões', status: 'online', lastSeen: 'Agora' },
    { id: 4, name: 'Sandra Rotas', status: 'offline', lastSeen: '1d atrás' },
    { id: 5, name: 'Paulo Estrada', status: 'online', lastSeen: 'Agora' }
  ];
  
  // Estilo "Família 15": borda café, fundo bege claro
  const familyStyle = {
    borderColor: '#8B4513', // café
    backgroundColor: '#F5F5DC' // bege claro
  };
  
  // Filtra contatos baseado na pesquisa
  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchUser.toLowerCase())
  );
  
  // Manipuladores de eventos
  const handleRadioSelect = (radio) => {
    setSelectedRadio(radio);
  };
  
  const handleUserSelect = (user) => {
    setSelectedUser(user);
    setSearchUser('');
  };
  
  const handleSendRadio = () => {
    if (selectedRadio && selectedUser) {
      setSendStatus('sending');
      
      // Simula o envio (após 1 segundo)
      setTimeout(() => {
        setSendStatus('sent');
        
        // Reset após 3 segundos
        setTimeout(() => {
          setSendStatus(null);
          setSelectedRadio(null);
          setSelectedUser(null);
        }, 3000);
      }, 1000);
    }
  };
  
  const handleRadioAction = (radioId, action) => {
    setReceivedRadios(radios => 
      radios.map(radio => 
        radio.id === radioId 
          ? { ...radio, status: action === 'accept' ? 'accepted' : 'ignored' } 
          : radio
      )
    );
  };
  
  return (
    <div className="max-w-md mx-auto bg-white shadow-sm border border-gray-200 rounded-lg overflow-hidden">
      {/* Cabeçalho */}
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h2 className="text-lg font-semibold flex items-center">
          <Share2 className="h-5 w-5 mr-2 text-blue-600" />
          Compartilhamento de Rádios
        </h2>
        
        {/* Abas */}
        <div className="flex mt-2 border-b border-gray-200">
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === 'enviar' 
                ? 'text-blue-600 border-b-2 border-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('enviar')}
          >
            Enviar
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === 'recebidas' 
                ? 'text-blue-600 border-b-2 border-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            } flex items-center`}
            onClick={() => setActiveTab('recebidas')}
          >
            Recebidas
            {receivedRadios.some(r => r.status === 'pending') && (
              <span className="ml-1 w-2 h-2 bg-red-500 rounded-full"></span>
            )}
          </button>
        </div>
      </div>
      
      {/* Conteúdo baseado na aba ativa */}
      {activeTab === 'enviar' ? (
        <div className="p-4">
          {/* Passo 1: Selecionar rádio */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Passo 1: Selecione uma rádio para compartilhar
            </label>
            <div 
              className="rounded-md overflow-hidden"
              style={{
                border: '1px solid',
                borderColor: familyStyle.borderColor
              }}
            >
              {myRadios.map((radio) => (
                <div 
                  key={radio.id}
                  className={`p-3 flex items-center justify-between border-b last:border-b-0 ${
                    selectedRadio && selectedRadio.id === radio.id ? 'bg-blue-50' : ''
                  } hover:bg-gray-50 cursor-pointer`}
                  onClick={() => handleRadioSelect(radio)}
                >
                  <div className="flex items-center">
                    <div className="bg-white p-1 rounded-full border border-gray-200 mr-3">
                      <Radio className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{radio.name}</p>
                      <p className="text-xs text-gray-600">{radio.country} • {radio.language}</p>
                    </div>
                  </div>
                  
                  {selectedRadio && selectedRadio.id === radio.id && (
                    <Check className="h-5 w-5 text-blue-600" />
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Passo 2: Selecionar destinatário */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Passo 2: Selecione o destinatário
            </label>
            
            {selectedUser ? (
              <div 
                className="p-3 rounded-md flex items-center justify-between"
                style={{
                  backgroundColor: familyStyle.backgroundColor,
                  border: '1px solid',
                  borderColor: familyStyle.borderColor
                }}
              >
                <div className="flex items-center">
                  <div className="bg-white p-1 rounded-full border border-gray-200 mr-3">
                    <User className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{selectedUser.name}</p>
                    <p className="text-xs text-gray-600">
                      {selectedUser.status === 'online' ? (
                        <span className="flex items-center">
                          <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                          Online agora
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <span className="w-2 h-2 bg-gray-300 rounded-full mr-1"></span>
                          Visto por último: {selectedUser.lastSeen}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                
                <button 
                  className="p-1 rounded-full hover:bg-gray-200"
                  onClick={() => setSelectedUser(null)}
                >
                  <X className="h-4 w-4 text-gray-600" />
                </button>
              </div>
            ) : (
              <div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white 
                             placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 
                             focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Buscar contato..."
                    value={searchUser}
                    onChange={(e) => setSearchUser(e.target.value)}
                  />
                </div>
                
                <div className="mt-2 max-h-40 overflow-y-auto rounded-md shadow-sm border border-gray-200">
                  {filteredContacts.length > 0 ? (
                    filteredContacts.map((contact) => (
                      <div 
                        key={contact.id}
                        className="p-3 flex items-center justify-between border-b last:border-b-0 hover:bg-gray-50 cursor-pointer"
                        onClick={() => handleUserSelect(contact)}
                      >
                        <div className="flex items-center">
                          <div className="bg-white p-1 rounded-full border border-gray-200 mr-3">
                            <User className="h-5 w-5 text-gray-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{contact.name}</p>
                            <p className="text-xs text-gray-600">
                              {contact.status === 'online' ? (
                                <span className="flex items-center">
                                  <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                                  Online agora
                                </span>
                              ) : (
                                <span className="flex items-center">
                                  <span className="w-2 h-2 bg-gray-300 rounded-full mr-1"></span>
                                  Visto por último: {contact.lastSeen}
                                </span>
                              )}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-center text-sm text-gray-500">
                      Nenhum contato encontrado
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          
          {/* Botão de envio */}
          <div className="mt-6">
            <button
              className={`w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white ${
                selectedRadio && selectedUser && !sendStatus
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
              disabled={!selectedRadio || !selectedUser || sendStatus}
              onClick={handleSendRadio}
            >
              {sendStatus === 'sending' && <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>}
              {sendStatus === 'sent' && <Check className="h-4 w-4 mr-2" />}
              {sendStatus === 'sending' ? 'Enviando...' : sendStatus === 'sent' ? 'Enviado com sucesso!' : 'Enviar rádio'}
            </button>
          </div>
          
          {/* Informação de compartilhamento */}
          <div className="mt-4 p-3 bg-blue-50 rounded-md text-xs text-blue-800">
            <p>O destinatário receberá uma notificação no módulo de rádio e poderá escolher entre tocar, salvar ou ignorar a rádio compartilhada.</p>
          </div>
        </div>
      ) : (
        <div className="divide-y divide-gray-200">
          {receivedRadios.length > 0 ? (
            receivedRadios.map((radio) => (
              <div key={radio.id} className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <div className="bg-white p-1 rounded-full border border-gray-200 mr-3 mt-1">
                      <Radio className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{radio.radioName}</h3>
                      <p className="text-xs text-gray-500">{radio.country} • {radio.language}</p>
                      <p className="text-xs text-gray-500 mt-1 flex items-center">
                        <User className="h-3 w-3 mr-1" />
                        Enviado por {radio.senderName}
                      </p>
                      <p className="text-xs text-gray-500 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {radio.timestamp}
                      </p>
                    </div>
                  </div>
                  
                  {radio.status === 'accepted' && (
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      Aceito
                    </span>
                  )}
                  
                  {radio.status === 'ignored' && (
                    <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                      Ignorado
                    </span>
                  )}
                </div>
                
                {radio.status === 'pending' && (
                  <div className="mt-3 flex space-x-2">
                    <button 
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-4 rounded-md text-sm flex items-center justify-center"
                      onClick={() => handleRadioAction(radio.id, 'accept')}
                    >
                      <Play className="h-3 w-3 mr-1" />
                      Tocar
                    </button>
                    <button 
                      className="flex-1 bg-white hover:bg-gray-50 text-gray-800 py-1.5 px-4 rounded-md border border-gray-300 text-sm flex items-center justify-center"
                      onClick={() => handleRadioAction(radio.id, 'accept')}
                    >
                      <Check className="h-3 w-3 mr-1" />
                      Salvar
                    </button>
                    <button 
                      className="flex-1 bg-white hover:bg-gray-50 text-gray-600 py-1.5 px-4 rounded-md border border-gray-300 text-sm flex items-center justify-center"
                      onClick={() => handleRadioAction(radio.id, 'ignore')}
                    >
                      <X className="h-3 w-3 mr-1" />
                      Ignorar
                    </button>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <Bell className="h-10 w-10 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500">Não há rádios compartilhadas</p>
              <p className="text-xs text-gray-400 mt-1">Quando alguém compartilhar uma rádio com você, aparecerá aqui</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CompartilhamentoInternoRadios;