import React from 'react';
import { Platform } from 'react-native';
import { useTheme } from '../contexts/ThemeContext';

// Componentes específicos para React Native
let TouchableOpacity, Text, StyleSheet, ActivityIndicator, View, TouchableNativeFeedback;

// Importar componentes apenas quando estiver no ambiente React Native
if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
  // Estamos em um ambiente React Native
  const ReactNative = require('react-native');
  TouchableOpacity = ReactNative.TouchableOpacity;
  Text = ReactNative.Text;
  StyleSheet = ReactNative.StyleSheet;
  ActivityIndicator = ReactNative.ActivityIndicator;
  View = ReactNative.View;
  TouchableNativeFeedback = ReactNative.TouchableNativeFeedback;
}

// Componente de ícone compartilhado - detecta plataforma e renderiza adequadamente
const Icon = ({ name, size, color, style }) => {
  if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
    // Versão React Native
    const NativeIcon = require('./Icon').default;
    return <NativeIcon name={name} size={size} color={color} style={style} />;
  } else {
    // Versão Web - assumimos que o ícone é passado como um componente React
    return name;
  }
};

/**
 * Componente de botão reutilizável para o sistema KingRoad
 * Suporta diferentes variantes, estados e acessibilidade
 * Funciona tanto em React Native quanto em React Web
 */
const Button = (props) => {
  // Se estamos em ambiente React Native
  if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
    return <NativeButton {...props} />;
  } else {
    // Se estamos em ambiente Web
    return <WebButton {...props} />;
  }
};

/**
 * Implementação do botão para React Native
 */
const NativeButton = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  icon,
  iconPosition = 'left',
  disabled = false,
  loading = false,
  accessibilityLabel,
  style,
  textStyle,
  ...props
}) => {
  const { theme, isDark } = useTheme();
  
  // Definições de cores com base na variante e tema
  const getVariantStyle = () => {
    const variants = {
      primary: {
        backgroundColor: theme.colors.primary,
        textColor: '#ffffff',
      },
      secondary: {
        backgroundColor: isDark ? '#2c3e50' : '#ecf0f1',
        textColor: isDark ? '#ffffff' : '#2c3e50',
      },
      success: {
        backgroundColor: theme.colors.success,
        textColor: '#ffffff',
      },
      danger: {
        backgroundColor: theme.colors.danger,
        textColor: '#ffffff',
      },
      warning: {
        backgroundColor: theme.colors.warning,
        textColor: '#ffffff',
      },
      transparent: {
        backgroundColor: 'transparent',
        textColor: theme.colors.primary,
      },
      outline: {
        backgroundColor: 'transparent',
        textColor: theme.colors.primary,
        borderColor: theme.colors.primary,
        borderWidth: 1,
      },
    };
    
    return variants[variant] || variants.primary;
  };
  
  // Definições de tamanho
  const getSizeStyle = () => {
    const sizes = {
      small: {
        paddingVertical: 6,
        paddingHorizontal: 12,
        fontSize: 12,
        iconSize: 14,
      },
      medium: {
        paddingVertical: 10,
        paddingHorizontal: 16,
        fontSize: 14,
        iconSize: 18,
      },
      large: {
        paddingVertical: 14,
        paddingHorizontal: 20,
        fontSize: 16,
        iconSize: 22,
      },
    };
    
    return sizes[size] || sizes.medium;
  };
  
  const variantStyle = getVariantStyle();
  const sizeStyle = getSizeStyle();
  
  // Estados do botão
  const isDisabled = disabled || loading;
  
  // Estilo base do botão
  const buttonStyle = {
    backgroundColor: variantStyle.backgroundColor,
    opacity: isDisabled ? 0.7 : 1,
    paddingVertical: sizeStyle.paddingVertical,
    paddingHorizontal: sizeStyle.paddingHorizontal,
    borderRadius: 5,
    borderWidth: variantStyle.borderWidth || 0,
    borderColor: variantStyle.borderColor,
    ...style,
  };
  
  // Estilo do texto
  const buttonTextStyle = {
    color: variantStyle.textColor,
    fontSize: sizeStyle.fontSize,
    fontWeight: '500',
    textAlign: 'center',
    ...textStyle,
  };

  // Estilos definidos para React Native
  const styles = StyleSheet.create({
    container: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    contentContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    iconLeft: {
      marginRight: 8,
    },
    iconRight: {
      marginLeft: 8,
    },
    loader: {
      marginRight: 10,
    },
  });

  // Renderização condicional do componente TouchableOpacity ou TouchableNativeFeedback
  const ButtonComponent = Platform.OS === 'android' && variant !== 'transparent' && variant !== 'outline'
    ? TouchableNativeFeedback
    : TouchableOpacity;
  
  // Conteúdo do botão
  const renderContent = () => (
    <View style={[styles.container, buttonStyle]}>
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variantStyle.textColor} 
          style={styles.loader} 
        />
      ) : (
        <View style={styles.contentContainer}>
          {icon && iconPosition === 'left' && (
            <Icon
              name={icon}
              size={sizeStyle.iconSize}
              color={variantStyle.textColor}
              style={styles.iconLeft}
            />
          )}
          
          <Text style={buttonTextStyle}>{title}</Text>
          
          {icon && iconPosition === 'right' && (
            <Icon
              name={icon}
              size={sizeStyle.iconSize}
              color={variantStyle.textColor}
              style={styles.iconRight}
            />
          )}
        </View>
      )}
    </View>
  );
  
  // Para Android TouchableNativeFeedback
  if (Platform.OS === 'android' && variant !== 'transparent' && variant !== 'outline') {
    return (
      <ButtonComponent
        onPress={onPress}
        disabled={isDisabled}
        accessibilityLabel={accessibilityLabel || title}
        background={TouchableNativeFeedback.Ripple(
          variantStyle.textColor === '#ffffff' ? '#ffffff' : variantStyle.backgroundColor,
          false
        )}
        {...props}
      >
        {renderContent()}
      </ButtonComponent>
    );
  }
  
  // Para iOS - TouchableOpacity
  return (
    <ButtonComponent
      style={[styles.container, buttonStyle]}
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={0.7}
      accessibilityLabel={accessibilityLabel || title}
      {...props}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variantStyle.textColor} 
          style={styles.loader} 
        />
      ) : (
        <View style={styles.contentContainer}>
          {icon && iconPosition === 'left' && (
            <Icon
              name={icon}
              size={sizeStyle.iconSize}
              color={variantStyle.textColor}
              style={styles.iconLeft}
            />
          )}
          
          <Text style={buttonTextStyle}>{title}</Text>
          
          {icon && iconPosition === 'right' && (
            <Icon
              name={icon}
              size={sizeStyle.iconSize}
              color={variantStyle.textColor}
              style={styles.iconRight}
            />
          )}
        </View>
      )}
    </ButtonComponent>
  );
};

/**
 * Implementação do botão para React Web
 */
const WebButton = ({
  children,
  title,
  type = 'primary',
  variant = type, // Suporte para ambas propriedades
  size = 'medium',
  disabled = false,
  fullWidth = false,
  icon,
  iconPosition = 'left',
  onClick,
  onPress, // Suporte para ambas propriedades
  loading = false,
  loadingText = 'Carregando...',
  className = '',
  ...props
}) => {
  // Unificar callback de clique
  const handleClick = onClick || onPress;
  
  // Usar title como children se não houver children
  const buttonText = children || title;
  
  // Determinar classes CSS com base no tipo do botão
  const getTypeClasses = () => {
    const type = variant || 'primary'; // Usar variant se definido
    
    switch (type) {
      case 'primary':
        return 'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600 dark:border-blue-700';
      case 'secondary':
        return 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600';
      case 'danger':
        return 'bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200 dark:bg-yellow-900 dark:text-yellow-300 dark:hover:bg-yellow-800';
      case 'success':
        return 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800';
      case 'outline':
        return 'bg-transparent border border-gray-300 text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800';
      case 'link':
        return 'bg-transparent text-blue-600 hover:underline dark:text-blue-400';
      case 'transparent':
        return 'bg-transparent text-gray-700 dark:text-gray-300';
      default:
        return 'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600';
    }
  };

  // Determinar classes CSS com base no tamanho do botão
  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return 'py-1 px-2 text-sm';
      case 'medium':
        return 'py-2 px-4';
      case 'large':
        return 'py-3 px-6 text-lg';
      default:
        return 'py-2 px-4';
    }
  };
  
  // Construir as classes CSS finais
  const baseClasses = 'rounded-md transition-colors flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500';
  const typeClasses = getTypeClasses();
  const sizeClasses = getSizeClasses();
  const widthClass = fullWidth ? 'w-full' : '';
  const disabledClasses = disabled || loading ? 'opacity-50 cursor-not-allowed' : '';
  
  return (
    <button
      className={`${baseClasses} ${typeClasses} ${sizeClasses} ${widthClass} ${disabledClasses} ${className}`}
      disabled={disabled || loading}
      onClick={handleClick}
      {...props}
    >
      {loading ? (
        <>
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          {loadingText}
        </>
      ) : (
        <>
          {icon && iconPosition === 'left' && <span className="mr-2">{icon}</span>}
          {buttonText}
          {icon && iconPosition === 'right' && <span className="ml-2">{icon}</span>}
        </>
      )}
    </button>
  );
};

/**
 * Componente de botão flutuante (FAB) para ações rápidas
 */
const FloatingActionButton = (props) => {
  // Se estamos em ambiente React Native
  if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
    return <NativeFAB {...props} />;
  } else {
    // Se estamos em ambiente Web
    return <WebFAB {...props} />;
  }
};

/**
 * Implementação do FAB para React Native
 */
const NativeFAB = ({
  icon,
  onPress,
  color = 'primary',
  size = 'medium',
  position = 'bottomRight',
  disabled = false,
  accessibilityLabel,
  style,
  ...props
}) => {
  const { theme } = useTheme();
  
  // Definições de cores
  const getColorStyle = () => {
    const colors = {
      primary: theme.colors.primary,
      secondary: theme.colors.secondary,
      success: theme.colors.success,
      danger: theme.colors.danger,
      warning: theme.colors.warning,
    };
    
    return colors[color] || colors.primary;
  };
  
  // Definições de tamanho
  const getSizeStyle = () => {
    const sizes = {
      small: {
        size: 40,
        iconSize: 18,
      },
      medium: {
        size: 56,
        iconSize: 24,
      },
      large: {
        size: 64,
        iconSize: 28,
      },
    };
    
    return sizes[size] || sizes.medium;
  };
  
  // Definições de posição
  const getPositionStyle = () => {
    const positions = {
      bottomRight: {
        bottom: 20,
        right: 20,
      },
      bottomLeft: {
        bottom: 20,
        left: 20,
      },
      topRight: {
        top: 20,
        right: 20,
      },
      topLeft: {
        top: 20,
        left: 20,
      },
      center: {
        bottom: 20,
        alignSelf: 'center',
      },
    };
    
    return positions[position] || positions.bottomRight;
  };
  
  const colorStyle = getColorStyle();
  const sizeStyle = getSizeStyle();
  const positionStyle = getPositionStyle();
  
  const fabStyle = {
    backgroundColor: colorStyle,
    width: sizeStyle.size,
    height: sizeStyle.size,
    borderRadius: sizeStyle.size / 2,
    opacity: disabled ? 0.7 : 1,
    ...positionStyle,
    ...style,
  };

  // Estilos definidos para React Native
  const styles = StyleSheet.create({
    fabContainer: {
      position: 'absolute',
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 6,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      overflow: Platform.OS === 'android' ? 'hidden' : 'visible',
    },
    fabContent: {
      width: '100%',
      height: '100%',
      justifyContent: 'center',
      alignItems: 'center',
    }
  });
  
  // Renderização condicional do componente TouchableOpacity ou TouchableNativeFeedback
  const ButtonComponent = Platform.OS === 'android'
    ? TouchableNativeFeedback
    : TouchableOpacity;
  
  // Para Android - TouchableNativeFeedback
  if (Platform.OS === 'android') {
    return (
      <View style={[styles.fabContainer, fabStyle]}>
        <ButtonComponent
          onPress={onPress}
          disabled={disabled}
          accessibilityLabel={accessibilityLabel}
          background={TouchableNativeFeedback.Ripple('#ffffff', true)}
          {...props}
        >
          <View style={styles.fabContent}>
            <Icon name={icon} size={sizeStyle.iconSize} color="#ffffff" />
          </View>
        </ButtonComponent>
      </View>
    );
  }
  
  // Para iOS - TouchableOpacity
  return (
    <TouchableOpacity
      style={[styles.fabContainer, fabStyle]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.8}
      accessibilityLabel={accessibilityLabel}
      {...props}
    >
      <Icon name={icon} size={sizeStyle.iconSize} color="#ffffff" />
    </TouchableOpacity>
  );
};

/**
 * Implementação do FAB para React Web
 */
const WebFAB = ({
  icon,
  onClick,
  onPress, // Suporte para ambas propriedades
  color = 'primary',
  size = 'medium',
  position = 'bottomRight',
  disabled = false,
  className = '',
  ...props
}) => {
  // Unificar callback de clique
  const handleClick = onClick || onPress;
  
  // Mapear cores para classes
  const colorClasses = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    secondary: 'bg-gray-700 hover:bg-gray-800 text-white',
    danger: 'bg-red-600 hover:bg-red-700 text-white',
    warning: 'bg-amber-500 hover:bg-amber-600 text-white',
    success: 'bg-green-600 hover:bg-green-700 text-white'
  };
  
  // Mapear tamanhos para classes
  const sizeClasses = {
    small: 'w-10 h-10',
    medium: 'w-14 h-14',
    large: 'w-16 h-16'
  };
  
  // Mapear posições para classes
  const positionClasses = {
    bottomRight: 'fixed bottom-4 right-4',
    bottomLeft: 'fixed bottom-4 left-4',
    topRight: 'fixed top-4 right-4',
    topLeft: 'fixed top-4 left-4',
    center: 'fixed bottom-4 left-1/2 transform -translate-x-1/2'
  };
  
  return (
    <button
      className={`
        rounded-full shadow-lg flex items-center justify-center
        ${colorClasses[color] || colorClasses.primary}
        ${sizeClasses[size] || sizeClasses.medium}
        ${positionClasses[position] || positionClasses.bottomRight}
        ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        transition-all duration-200 
        focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
        ${className}
      `}
      onClick={handleClick}
      disabled={disabled}
      {...props}
    >
      {icon}
    </button>
  );
};

/**
 * Componente de botão de ícone sem texto
 */
const IconButton = (props) => {
  // Se estamos em ambiente React Native
  if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
    return <NativeIconButton {...props} />;
  } else {
    // Se estamos em ambiente Web
    return <WebIconButton {...props} />;
  }
};

/**
 * Implementação do IconButton para React Native
 */
const NativeIconButton = ({
  icon,
  onPress,
  color = 'primary',
  size = 'medium',
  disabled = false,
  accessibilityLabel,
  style,
  ...props
}) => {
  const { theme, isDark } = useTheme();
  
  // Definições de cores
  const getColorStyle = () => {
    const colors = {
      primary: theme.colors.primary,
      secondary: isDark ? '#ffffff' : '#2c3e50',
      success: theme.colors.success,
      danger: theme.colors.danger,
      warning: theme.colors.warning,
      light: '#ffffff',
      dark: '#2c3e50',
    };
    
    return colors[color] || colors.primary;
  };
  
  // Definições de tamanho
  const getSizeStyle = () => {
    const sizes = {
      small: {
        padding: 8,
        iconSize: 16,
      },
      medium: {
        padding: 10,
        iconSize: 20,
      },
      large: {
        padding: 12,
        iconSize: 24,
      },
    };
    
    return sizes[size] || sizes.medium;
  };
  
  const colorStyle = getColorStyle();
  const sizeStyle = getSizeStyle();
  
  const buttonStyle = {
    padding: sizeStyle.padding,
    opacity: disabled ? 0.7 : 1,
    ...style,
  };

  // Estilos definidos para React Native
  const styles = StyleSheet.create({
    iconButtonContainer: {
      justifyContent: 'center',
      alignItems: 'center',
    }
  });
  
  return (
    <TouchableOpacity
      style={[styles.iconButtonContainer, buttonStyle]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.7}
      accessibilityLabel={accessibilityLabel}
      hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
      {...props}
    >
      <Icon name={icon} size={sizeStyle.iconSize} color={colorStyle} />
    </TouchableOpacity>
  );
};

/**
 * Implementação do IconButton para React Web
 */
const WebIconButton = ({
  icon,
  onClick,
  onPress, // Suporte para ambas propriedades
  color = 'default',
  size = 'medium',
  disabled = false,
  tooltipText = '',
  className = '',
  ...props
}) => {
  // Unificar callback de clique
  const handleClick = onClick || onPress;
  
  // Mapear cores para classes
  const colorClasses = {
    default: 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300',
    primary: 'text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300',
    danger: 'text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300',
    warning: 'text-yellow-600 hover:text-yellow-700 dark:text-yellow-400 dark:hover:text-yellow-300',
    success: 'text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300'
  };
  
  // Mapear tamanhos para classes
  const sizeClasses = {
    small: 'p-1',
    medium: 'p-2',
    large: 'p-3'
  };
  
  return (
    <button
      className={`
        rounded-full hover:bg-gray-200 dark:hover:bg-gray-700
        ${colorClasses[color] || colorClasses.default}
        ${sizeClasses[size] || sizeClasses.medium}
        ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        focus:outline-none
        ${className}
      `}
      onClick={handleClick}
      disabled={disabled}
      title={tooltipText}
      {...props}
    >
      {icon}
    </button>
  );
};

/**
 * Botão de alternar estado (toggle) - apenas para Web
 */
const ToggleButton = ({
  isActive = false,
  onChange,
  activeIcon,
  inactiveIcon,
  activeText,
  inactiveText,
  disabled = false,
  size = 'medium',
  className = '',
  ...props
}) => {
  // Se estamos em ambiente React Native, retorna null
  if (Platform.OS && (Platform.OS === 'android' || Platform.OS === 'ios')) {
    console.warn('ToggleButton ainda não está implementado para React Native');
    return null;
  }
  
  // Mapear tamanhos para classes
  const sizeClasses = {
    small: 'h-8 text-xs',
    medium: 'h-10 text-sm',
    large: 'h-12 text-base'
  };
  
  // Classes para estado ativo/inativo
  const stateClasses = isActive
    ? 'bg-blue-600 text-white'
    : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300';
  
  return (
    <button
      className={`
        px-4 rounded-md flex items-center justify-center
        ${sizeClasses[size] || sizeClasses.medium}
        ${stateClasses}
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:brightness-95'}
        transition-all duration-200
        focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
        ${className}
      `}
      onClick={() => !disabled && onChange && onChange(!isActive)}
      disabled={disabled}
      {...props}
    >
      {isActive ? (
        <>
          {activeIcon && <span className="mr-2">{activeIcon}</span>}
          {activeText}
        </>
      ) : (
        <>
          {inactiveIcon && <span className="mr-2">{inactiveIcon}</span>}
          {inactiveText}
        </>
      )}
    </button>
  );
};

/**
 * Botão de loading - reutiliza o componente Button
 */
const LoadingButton = (props) => {
  return <Button {...props} loading={true} />;
};

// Exportar como objeto para compatibilidade com ambos os arquivos originais
const commonButtons = {
  Primary: (props) => <Button variant="primary" {...props} />,
  Secondary: (props) => <Button variant="secondary" {...props} />,
  Success: (props) => <Button variant="success" {...props} />,
  Danger: (props) => <Button variant="danger" {...props} />,
  Warning: (props) => <Button variant="warning" {...props} />,
  Outline: (props) => <Button variant="outline" {...props} />,
  Link: (props) => <Button variant="link" {...props} />,
  FAB: FloatingActionButton,
  IconButton,
  ToggleButton,
  LoadingButton,
  // Manter compatibilidade com nomenclaturas anteriores
  Button,
  FloatingActionButton,
  CommonButton: Button
};

// Exportar componentes individualmente e como padrão
export {
  Button,
  FloatingActionButton,
  IconButton,
  ToggleButton,
  LoadingButton
};

export default commonButtons;