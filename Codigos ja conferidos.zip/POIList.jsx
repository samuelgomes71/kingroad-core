import React, { useState } from 'react';
import { 
  MapPin, 
  Clock, 
  Star, 
  Truck, 
  Coffee, 
  Utensils, 
  Fuel, 
  Droplet, 
  Phone, 
  ChevronRight,
  ThumbsUp
} from 'lucide-react';

/**
 * Componente de Item de Ponto de Interesse (POI)
 * Para o sistema KingRoad
 * 
 * @param {Object} poi - Dados do ponto de interesse
 * @returns {JSX.Element} Componente React
 */
const POIItem = ({ poi }) => {
  const [expanded, setExpanded] = useState(false);
  
  // Dados de exemplo para demonstração (será substituído por props reais)
  const poiData = poi || {
    id: 'poi-001',
    name: 'Posto Ipiranga BR040',
    type: 'gas_station', // gas_station, restaurant, rest_area, service
    distance: '2,5 km',
    rating: 4.2,
    openNow: true,
    address: 'BR-040, km 456, Juiz de Fora, MG',
    phone: '(32) 3234-5678',
    features: ['fuel', 'food', 'shower', 'rest'],
    reviews: 142,
    liked: true,
    hours: '24 horas',
    lastVisit: '2 dias atrás'
  };
  
  // Função para renderizar ícone de acordo com o tipo de POI
  const renderIcon = (type) => {
    switch(type) {
      case 'gas_station':
        return <Fuel size={22} className="text-blue-500" />;
      case 'restaurant':
        return <Utensils size={22} className="text-amber-500" />;
      case 'rest_area':
        return <Truck size={22} className="text-green-500" />;
      case 'service':
        return <Truck size={22} className="text-red-500" />;
      case 'coffee':
        return <Coffee size={22} className="text-brown-500" />;
      default:
        return <MapPin size={22} className="text-blue-500" />;
    }
  };
  
  // Função para renderizar ícones de recursos disponíveis
  const renderFeatureIcons = (features) => {
    return (
      <div className="flex space-x-2 mt-2">
        {features.includes('fuel') && 
          <div className="flex flex-col items-center">
            <Fuel size={16} className="text-gray-600" />
            <span className="text-xs text-gray-500">Diesel</span>
          </div>
        }
        {features.includes('food') && 
          <div className="flex flex-col items-center">
            <Utensils size={16} className="text-gray-600" />
            <span className="text-xs text-gray-500">Comida</span>
          </div>
        }
        {features.includes('shower') && 
          <div className="flex flex-col items-center">
            <Droplet size={16} className="text-gray-600" />
            <span className="text-xs text-gray-500">Banho</span>
          </div>
        }
        {features.includes('rest') && 
          <div className="flex flex-col items-center">
            <Truck size={16} className="text-gray-600" />
            <span className="text-xs text-gray-500">Descanso</span>
          </div>
        }
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md mb-3 overflow-hidden border border-gray-200">
      {/* Cabeçalho do POI */}
      <div 
        className="p-3 flex items-center justify-between cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gray-100 rounded-lg">
            {renderIcon(poiData.type)}
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800">{poiData.name}</h3>
            <div className="flex items-center text-sm">
              <div className="flex items-center text-amber-500 mr-2">
                <Star size={16} className="fill-current" />
                <span className="ml-1">{poiData.rating}</span>
              </div>
              <span className="text-gray-500">
                • {poiData.distance} • 
                <span className={poiData.openNow ? "text-green-600" : "text-red-600"}>
                  {poiData.openNow ? " Aberto" : " Fechado"}
                </span>
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center">
          {poiData.liked && <ThumbsUp size={18} className="text-blue-500 mr-2" />}
          <ChevronRight 
            size={20} 
            className={`text-gray-400 transition-transform ${expanded ? 'transform rotate-90' : ''}`} 
          />
        </div>
      </div>
      
      {/* Detalhes expandidos */}
      {expanded && (
        <div className="px-3 pb-3 pt-0 border-t border-gray-100">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <div className="flex items-center">
              <Clock size={16} className="mr-1" />
              <span>{poiData.hours}</span>
            </div>
            <div className="text-blue-600">Última visita: {poiData.lastVisit}</div>
          </div>
          
          <div className="text-sm text-gray-600 mb-3">
            <div>{poiData.address}</div>
            <div className="flex items-center mt-1">
              <Phone size={16} className="mr-1" />
              <span>{poiData.phone}</span>
            </div>
          </div>
          
          {renderFeatureIcons(poiData.features)}
          
          <div className="mt-3 flex justify-between">
            <button className="px-3 py-1 text-sm bg-blue-600 text-white rounded-lg">
              Navegar
            </button>
            <button className="px-3 py-1 text-sm border border-gray-300 text-gray-600 rounded-lg">
              Detalhes
            </button>
            <button className="px-3 py-1 text-sm border border-gray-300 text-gray-600 rounded-lg">
              Ligar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Componente de Lista de Pontos de Interesse (POI)
 * Exibe vários POIs em uma lista
 * 
 * @returns {JSX.Element} Componente React
 */
const POIList = () => {
  const samplePOIs = [
    {
      id: 'poi-001',
      name: 'Posto Ipiranga BR040',
      type: 'gas_station',
      distance: '2,5 km',
      rating: 4.2,
      openNow: true,
      address: 'BR-040, km 456, Juiz de Fora, MG',
      phone: '(32) 3234-5678',
      features: ['fuel', 'food', 'shower', 'rest'],
      reviews: 142,
      liked: true,
      hours: '24 horas',
      lastVisit: '2 dias atrás'
    },
    {
      id: 'poi-002',
      name: 'Restaurante Bom Caminho',
      type: 'restaurant',
      distance: '5,1 km',
      rating: 4.7,
      openNow: true,
      address: 'Rodovia BR-116, km 320, Leopoldina, MG',
      phone: '(33) 3446-7890',
      features: ['food', 'rest'],
      reviews: 89,
      liked: false,
      hours: '06:00 - 22:00',
      lastVisit: '1 semana atrás'
    },
    {
      id: 'poi-003',
      name: 'Área de Descanso Serramar',
      type: 'rest_area',
      distance: '12 km',
      rating: 3.8,
      openNow: true,
      address: 'Rod. Presidente Dutra, km 214, Itatiaia, RJ',
      phone: '(24) 3351-2468',
      features: ['shower', 'rest'],
      reviews: 56,
      liked: true,
      hours: '24 horas',
      lastVisit: 'Nunca visitado'
    }
  ];

  return (
    <div className="bg-gray-100 p-4 max-w-md">
      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-lg font-bold text-gray-800">Pontos de Interesse</h2>
        <div className="text-sm text-blue-600">Ver Todos</div>
      </div>
      
      {samplePOIs.map(poi => (
        <POIItem key={poi.id} poi={poi} />
      ))}
    </div>
  );
};

export default POIList;