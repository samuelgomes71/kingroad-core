import React, { useState, useEffect } from 'react';
import { AlertTriangle, MapPin, Clock, ChevronRight, Filter, Bell, Activity } from 'lucide-react';

const AlertsScreen = () => {
  const [alerts, setAlerts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  // Mock data for visualization
  const mockAlerts = [
    {
      id: '1',
      type: 'accident',
      title: 'Acidente na BR-116',
      description: 'Colisão entre caminhão e carro no km 432',
      location: { lat: -23.5505, lng: -46.6333, address: 'BR-116, km 432' },
      severity: 'high',
      timestamp: new Date(Date.now() - 35 * 60000).toISOString(),
      reportedBy: 'João S.',
      verified: true,
      active: true,
    },
    {
      id: '2',
      type: 'roadblock',
      title: 'Bloqueio na Rodovia Fernão Dias',
      description: 'Bloqueio devido a obras na pista. Previsão de liberação: 2h',
      location: { lat: -22.9068, lng: -46.3928, address: 'Rodovia Fernão Dias, km 56' },
      severity: 'medium',
      timestamp: new Date(Date.now() - 120 * 60000).toISOString(),
      reportedBy: 'Sistema',
      verified: true,
      active: true,
    },
    {
      id: '3',
      type: 'weather',
      title: 'Neblina Intensa',
      description: 'Visibilidade reduzida a menos de 100m. Dirija com cuidado.',
      location: { lat: -25.4284, lng: -49.2733, address: 'BR-376, km 175' },
      severity: 'medium',
      timestamp: new Date(Date.now() - 45 * 60000).toISOString(),
      reportedBy: 'Maria L.',
      verified: false,
      active: true,
    },
    {
      id: '4',
      type: 'police',
      title: 'Blitz Policial',
      description: 'PRF realizando fiscalização de documentos e carga',
      location: { lat: -19.9167, lng: -43.9345, address: 'BR-381, km 490' },
      severity: 'low',
      timestamp: new Date(Date.now() - 90 * 60000).toISOString(),
      reportedBy: 'Carlos M.',
      verified: true,
      active: true,
    },
    {
      id: '5',
      type: 'road_condition',
      title: 'Buraco na Pista',
      description: 'Buraco grande na faixa da direita. Risco de danos ao veículo.',
      location: { lat: -20.3222, lng: -40.3381, address: 'BR-101, km 320' },
      severity: 'medium',
      timestamp: new Date(Date.now() - 240 * 60000).toISOString(),
      reportedBy: 'Ana P.',
      verified: false,
      active: true,
    }
  ];

  useEffect(() => {
    // Simulating API fetch
    const fetchAlerts = async () => {
      try {
        // In a real scenario, this would be an API call
        // const response = await fetch('api/alerts');
        // const data = await response.json();
        
        // Using mock data for preview
        setTimeout(() => {
          setAlerts(mockAlerts);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching alerts:', error);
        setLoading(false);
      }
    };

    fetchAlerts();
  }, []);

  const filteredAlerts = () => {
    if (filter === 'all') return alerts;
    return alerts.filter(alert => alert.type === filter);
  };

  const handleAlertPress = (alert) => {
    console.log('Alert pressed:', alert.id);
    // In actual implementation: navigation.navigate('AlertDetail', { alertId: alert.id });
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return '#FF4136';
      case 'medium':
        return '#FF851B';
      case 'low':
        return '#FFDC00';
      default:
        return '#AAAAAA';
    }
  };

  const getAlertTypeIcon = (type) => {
    switch (type) {
      case 'accident':
        return <AlertTriangle size={24} color="#FF4136" />;
      case 'roadblock':
        return <AlertTriangle size={24} color="#FF851B" />;
      case 'weather':
        return <AlertTriangle size={24} color="#0074D9" />;
      case 'police':
        return <AlertTriangle size={24} color="#001f3f" />;
      case 'road_condition':
        return <AlertTriangle size={24} color="#FF851B" />;
      default:
        return <AlertTriangle size={24} color="#AAAAAA" />;
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const alertTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now - alertTime) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'agora';
    if (diffInMinutes < 60) return `${diffInMinutes}m atrás`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h atrás`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d atrás`;
  };

  const FilterButton = ({ title, value }) => (
    <button
      className={`px-4 py-2 mx-1 rounded-full text-sm ${filter === value ? 'bg-yellow-500 text-black font-bold' : 'bg-gray-700 text-white'}`}
      onClick={() => setFilter(value)}
    >
      {title}
    </button>
  );

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <div className="flex items-center">
          <Bell size={24} color="#FFD700" />
          <h1 className="text-xl font-bold ml-2">Alertas</h1>
        </div>
        <button className="p-2">
          <Filter size={22} color="#FFD700" />
        </button>
      </div>
      
      {/* Filter */}
      <div className="p-2 border-b border-gray-700 overflow-x-auto whitespace-nowrap">
        <FilterButton title="Todos" value="all" />
        <FilterButton title="Acidentes" value="accident" />
        <FilterButton title="Bloqueios" value="roadblock" />
        <FilterButton title="Clima" value="weather" />
        <FilterButton title="Polícia" value="police" />
        <FilterButton title="Condição da Via" value="road_condition" />
      </div>
      
      {/* Content */}
      {loading ? (
        <div className="flex flex-col flex-1 justify-center items-center">
          <div className="animate-spin">
            <Activity size={32} color="#FFD700" />
          </div>
          <p className="mt-4 text-lg">Carregando alertas...</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          {filteredAlerts().length > 0 ? (
            <div className="p-4">
              {filteredAlerts().map(alert => (
                <div 
                  key={alert.id}
                  className="bg-gray-800 rounded-lg p-4 mb-3 border-l-4 border-yellow-500 cursor-pointer"
                  onClick={() => handleAlertPress(alert)}
                >
                  <div className="flex items-center">
                    {getAlertTypeIcon(alert.type)}
                    <div className="ml-3 flex-1">
                      <h3 className="font-bold text-white">{alert.title}</h3>
                      <p className="text-gray-300">{alert.description}</p>
                    </div>
                    <ChevronRight size={20} color="#666" />
                  </div>
                  
                  <div className="flex items-center justify-between mt-3 text-sm text-gray-400">
                    <div className="flex items-center">
                      <MapPin size={16} color="#666" />
                      <span className="ml-1">{alert.location.address}</span>
                    </div>
                    
                    <div className="flex items-center">
                      <Clock size={16} color="#666" />
                      <span className="ml-1">{formatTimeAgo(alert.timestamp)}</span>
                      <div 
                        className="w-2 h-2 rounded-full ml-2" 
                        style={{ backgroundColor: getSeverityColor(alert.severity) }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col flex-1 justify-center items-center p-6">
              <AlertTriangle size={48} color="#666" />
              <p className="text-xl font-bold mt-4">Nenhum alerta encontrado</p>
              <p className="text-gray-400 text-center mt-2">
                Tudo tranquilo nas suas rotas! Não há alertas {filter !== 'all' ? 'deste tipo' : ''} no momento.
              </p>
            </div>
          )}
        </div>
      )}
      
      {/* Report Button */}
      <div className="p-4">
        <button className="w-full bg-yellow-500 text-black font-bold py-3 px-4 rounded-lg">
          Reportar Problema
        </button>
      </div>
    </div>
  );
};

export default AlertsScreen;