# Família King - Redesign de Interface

Este repositório contém os arquivos necessários para implementar o novo design visual unificado para todos os aplicativos da Família King, começando pelo KingRoad.

## Visão Geral

O redesign da família King visa criar uma identidade visual consistente, sofisticada e elegante para todos os aplicativos da família, com elementos de UI padronizados como:

- Paleta de cores principal: café escuro (#4B3621), bege claro (#F5F5DC) e dourado (#D4AF37)
- Logo da família King no canto superior esquerdo
- Botão de menu circular no canto inferior esquerdo
- Splash screen personalizada com logo da família King

## Estrutura do Projeto

### Recursos Visuais
- **Logos**: Disponíveis em múltiplos tamanhos (small, medium, large, xlarge)
- **Splash screens**: Personalizadas para cada tamanho de tela
- **Ícones**: Compartilhados entre todos os aplicativos da família

### Arquivos de Valores
- **colors.xml**: Define a paleta de cores padrão
- **dimens.xml**: Define as dimensões padrão para todos os elementos de UI

### Layouts
- **activity_splash.xml**: Layout da tela de abertura
- **activity_main.xml**: Layout principal com o container para o conteúdo específico de cada app
- **main_menu_button.xml**: Layout do botão de menu circular personalizado

### Classes Principais
- **ResourceDownloader.kt**: Gerencia o download de recursos visuais do CDN
- **RegionalAssetsManager.kt**: Gerencia recursos específicos para cada região
- **SplashActivity.kt**: Exibe a tela de splash e inicia o download de recursos
- **MainActivity.kt**: Implementa o layout principal e a lógica de UI comum

### Configurações
- **cdn_config.json**: Configurações do CDN e mapeamento de recursos

## Instruções de Implementação

### 1. Preparação do Ambiente

1. Adicione os arquivos de recursos (colors.xml e dimens.xml) à pasta `res/values/`
2. Adicione os drawables XML (menu_button_background.xml) à pasta `res/drawable/`
3. Adicione os layouts (activity_splash.xml, activity_main.xml, main_menu_button.xml) à pasta `res/layout/`
4. Adicione o arquivo cdn_config.json à pasta `assets/`

### 2. Implementação das Classes

1. Crie o pacote `com.kingfamily.common.utils` e adicione:
   - ResourceDownloader.kt
   - RegionalAssetsManager.kt

2. Implemente as activities:
   - SplashActivity.kt
   - Modifique MainActivity.kt para incluir o novo design

### 3. Recursos Padrão

Certifique-se de incluir os recursos de fallback para quando o download falhar:
- Logo padrão (logo_king_family_default.png)
- Splash screen padrão (splash_screen_default.png)
- Logos em diferentes tamanhos (logo_king_family_small.png, logo_king_family_medium.png, etc.)
- Splash screens em diferentes tamanhos (splash_screen_small.png, splash_screen_medium.png, etc.)
- Ícone de busca (ic_search.png)

### 4. Configuração do Manifesto

Atualize o arquivo AndroidManifest.xml para definir SplashActivity como a activity inicial:

```xml
<activity
    android:name=".SplashActivity"
    android:theme="@style/Theme.AppCompat.NoActionBar">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

### 5. Modo Desenvolvedor

O modo desenvolvedor é ativado com 5 toques no logo seguido pela inserção da senha. Você precisará implementar a verificação de senha e as funcionalidades específicas do modo desenvolvedor.

## Adaptação para Outros Aplicativos

Para implementar o redesign em outros aplicativos da família King (KingMusic, KingScan, etc.):

1. Copie os arquivos de recursos, layouts e classes comuns
2. Adapte o conteúdo específico de cada aplicativo no container principal
3. Atualize o nome do aplicativo (APP_NAME) nas constantes

## Testes Requeridos

- Verificar carregamento correto de recursos por tamanho de tela
- Confirmar funcionamento do botão de menu principal
- Validar posicionamento do logo
- Testar fallback para recursos locais caso o download falhe
- Verificar a detecção correta de região e carregamento de recursos regionais

## Notas Adicionais

- A detecção de região é baseada no código do país da operadora móvel ou nas configurações de localidade do dispositivo
- Recursos visuais são atualizados automaticamente após 7 dias
- O modo Beta é controlado pela constante IS_BETA em SplashActivity.kt