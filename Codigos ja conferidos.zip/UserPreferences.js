// UserPreferences.js
// Gerenciador de preferências do usuário para o KingRoad

import AsyncStorage from '@react-native-async-storage/async-storage';

// Chaves para armazenamento de preferências
const KEYS = {
  BORDER_WELCOME_ENABLED: 'border_welcome_enabled',
  BORDER_WELCOME_AUDIO: 'border_welcome_audio',
  BORDER_WELCOME_ANIMATION: 'border_welcome_animation',
  BORDER_WELCOME_TIME: 'border_welcome_time',
  USER_PROFILE: 'user_profile',
  APP_SETTINGS: 'app_settings',
  LANGUAGE: 'app_language',
  THEME: 'app_theme',
};

// Valores padrão para preferências
const DEFAULT_PREFERENCES = {
  // Preferências de boas-vindas na fronteira
  [KEYS.BORDER_WELCOME_ENABLED]: true,
  [KEYS.BORDER_WELCOME_AUDIO]: true,
  [KEYS.BORDER_WELCOME_ANIMATION]: true,
  [KEYS.BORDER_WELCOME_TIME]: 5, // segundos
  
  // Perfil do usuário
  [KEYS.USER_PROFILE]: {
    name: '',
    avatar: null,
    qra: '',
    email: '',
    phone: '',
    truckModel: '',
    licensePlate: '',
  },
  
  // Configurações gerais do app
  [KEYS.APP_SETTINGS]: {
    notifications: true,
    dataUsage: 'medium', // low, medium, high
    offlineMode: false,
    autoDownloadMaps: true,
    distanceUnit: 'km', // km or miles
    darkMode: 'auto', // light, dark, auto
  },
  
  // Idioma do aplicativo
  [KEYS.LANGUAGE]: 'pt-BR',
  
  // Tema do aplicativo
  [KEYS.THEME]: 'auto', // light, dark, auto
};

class UserPreferences {
  constructor() {
    this.preferences = { ...DEFAULT_PREFERENCES };
    this.loaded = false;
    this.listeners = {};
    
    // Carregar preferências ao iniciar
    this.loadPreferences();
  }
  
  // Carregar todas as preferências do armazenamento
  async loadPreferences() {
    try {
      // Carregar cada preferência individualmente
      const promises = Object.keys(KEYS).map(async (key) => {
        const value = await AsyncStorage.getItem(KEYS[key]);
        
        if (value !== null) {
          try {
            // Tentar processar como JSON
            this.preferences[KEYS[key]] = JSON.parse(value);
          } catch (e) {
            // Se não for JSON, armazenar como string
            this.preferences[KEYS[key]] = value;
          }
        }
      });
      
      await Promise.all(promises);
      this.loaded = true;
      
      // Notificar listeners que as preferências foram carregadas
      this.notifyListeners('loaded', this.preferences);
    } catch (error) {
      console.error('Erro ao carregar preferências:', error);
    }
  }
  
  // Salvar uma preferência
  async setPreference(key, value) {
    try {
      // Verificar se a chave é válida
      if (!Object.values(KEYS).includes(key)) {
        throw new Error(`Chave de preferência inválida: ${key}`);
      }
      
      // Atualizar o valor em memória
      this.preferences[key] = value;
      
      // Converter para string se necessário
      const valueToStore = typeof value === 'object' ? JSON.stringify(value) : value;
      
      // Salvar no armazenamento local
      await AsyncStorage.setItem(key, valueToStore);
      
      // Notificar listeners sobre a mudança
      this.notifyListeners(key, value);
      
      return true;
    } catch (error) {
      console.error(`Erro ao salvar preferência ${key}:`, error);
      return false;
    }
  }
  
  // Obter uma preferência
  getPreference(key, defaultValue = null) {
    // Verificar se a chave é válida
    if (!Object.values(KEYS).includes(key)) {
      console.warn(`Chave de preferência inválida: ${key}`);
      return defaultValue;
    }
    
    // Retornar valor atual ou valor padrão se não existir
    return this.preferences[key] !== undefined ? this.preferences[key] : defaultValue;
  }
  
  // Verificar se as boas-vindas na fronteira estão ativadas
  isBorderWelcomeEnabled() {
    return this.getPreference(KEYS.BORDER_WELCOME_ENABLED, true);
  }
  
  // Ativar/desativar boas-vindas na fronteira
  async setBorderWelcomeEnabled(enabled) {
    return await this.setPreference(KEYS.BORDER_WELCOME_ENABLED, enabled);
  }
  
  // Verificar se o áudio de boas-vindas está ativado
  isBorderWelcomeAudioEnabled() {
    return this.getPreference(KEYS.BORDER_WELCOME_AUDIO, true);
  }
  
  // Ativar/desativar áudio de boas-vindas
  async setBorderWelcomeAudioEnabled(enabled) {
    return await this.setPreference(KEYS.BORDER_WELCOME_AUDIO, enabled);
  }
  
  // Verificar se animações de boas-vindas estão ativadas
  isBorderWelcomeAnimationEnabled() {
    return this.getPreference(KEYS.BORDER_WELCOME_ANIMATION, true);
  }
  
  // Ativar/desativar animações de boas-vindas
  async setBorderWelcomeAnimationEnabled(enabled) {
    return await this.setPreference(KEYS.BORDER_WELCOME_ANIMATION, enabled);
  }
  
  // Obter tempo de exibição de boas-vindas (em segundos)
  getBorderWelcomeTime() {
    return this.getPreference(KEYS.BORDER_WELCOME_TIME, 5);
  }
  
  // Definir tempo de exibição de boas-vindas
  async setBorderWelcomeTime(seconds) {
    return await this.setPreference(KEYS.BORDER_WELCOME_TIME, seconds);
  }
  
  // Obter perfil do usuário
  getUserProfile() {
    return this.getPreference(KEYS.USER_PROFILE, DEFAULT_PREFERENCES[KEYS.USER_PROFILE]);
  }
  
  // Atualizar perfil do usuário
  async updateUserProfile(profile) {
    const currentProfile = this.getUserProfile();
    const updatedProfile = { ...currentProfile, ...profile };
    return await this.setPreference(KEYS.USER_PROFILE, updatedProfile);
  }
  
  // Obter QRA do usuário (codinome de rádio)
  getUserQRA() {
    const profile = this.getUserProfile();
    return profile.qra || '';
  }
  
  // Adicionar listener para mudanças de preferências
  addListener(key, callback) {
    if (!this.listeners[key]) {
      this.listeners[key] = [];
    }
    
    this.listeners[key].push(callback);
    
    // Retornar função para remover o listener
    return () => this.removeListener(key, callback);
  }
  
  // Remover listener
  removeListener(key, callback) {
    if (!this.listeners[key]) return;
    
    this.listeners[key] = this.listeners[key].filter(cb => cb !== callback);
  }
  
  // Notificar listeners sobre mudanças
  notifyListeners(key, value) {
    // Notificar listeners específicos para esta chave
    if (this.listeners[key]) {
      this.listeners[key].forEach(callback => {
        try {
          callback(value);
        } catch (error) {
          console.error(`Erro em listener para ${key}:`, error);
        }
      });
    }
    
    // Notificar listeners para todas as mudanças
    if (this.listeners['*']) {
      this.listeners['*'].forEach(callback => {
        try {
          callback({ key, value });
        } catch (error) {
          console.error(`Erro em listener global:`, error);
        }
      });
    }
  }
  
  // Resetar todas as preferências para os valores padrão
  async resetToDefaults() {
    try {
      // Limpar todas as preferências do armazenamento
      await Promise.all(
        Object.values(KEYS).map(key => AsyncStorage.removeItem(key))
      );
      
      // Redefinir em memória
      this.preferences = { ...DEFAULT_PREFERENCES };
      
      // Notificar listeners
      this.notifyListeners('reset', this.preferences);
      
      return true;
    } catch (error) {
      console.error('Erro ao resetar preferências:', error);
      return false;
    }
  }
}

// Criar e exportar uma instância única
const userPreferences = new UserPreferences();
export default userPreferences;

// Exportar chaves para uso em outros módulos
export const PreferenceKeys = KEYS;

// Hook personalizado para usar preferências em componentes React
export function usePreferences() {
  const [preferences, setPreferences] = React.useState(userPreferences.preferences);
  
  React.useEffect(() => {
    // Função para atualizar o estado local
    const handlePreferencesLoaded = (prefs) => {
      setPreferences({ ...prefs });
    };
    
    // Registrar listener para quando as preferências forem carregadas
    const unsubscribe = userPreferences.addListener('loaded', handlePreferencesLoaded);
    
    // Se as preferências já estiverem carregadas, atualize imediatamente
    if (userPreferences.loaded) {
      setPreferences({ ...userPreferences.preferences });
    }
    
    // Limpar listener ao desmontar
    return unsubscribe;
  }, []);
  
  // Funções específicas para as preferências de boas-vindas na fronteira
  const borderWelcomeEnabled = userPreferences.isBorderWelcomeEnabled();
  const borderWelcomeAudioEnabled = userPreferences.isBorderWelcomeAudioEnabled();
  const borderWelcomeAnimationEnabled = userPreferences.isBorderWelcomeAnimationEnabled();
  const borderWelcomeTime = userPreferences.getBorderWelcomeTime();
  
  const setBorderWelcomeEnabled = (enabled) => {
    userPreferences.setBorderWelcomeEnabled(enabled);
  };
  
  const setBorderWelcomeAudioEnabled = (enabled) => {
    userPreferences.setBorderWelcomeAudioEnabled(enabled);
  };
  
  const setBorderWelcomeAnimationEnabled = (enabled) => {
    userPreferences.setBorderWelcomeAnimationEnabled(enabled);
  };
  
  const setBorderWelcomeTime = (seconds) => {
    userPreferences.setBorderWelcomeTime(seconds);
  };
  
  return {
    preferences,
    borderWelcomeEnabled,
    borderWelcomeAudioEnabled,
    borderWelcomeAnimationEnabled,
    borderWelcomeTime,
    setBorderWelcomeEnabled,
    setBorderWelcomeAudioEnabled,
    setBorderWelcomeAnimationEnabled,
    setBorderWelcomeTime,
    getUserProfile: userPreferences.getUserProfile.bind(userPreferences),
    updateUserProfile: userPreferences.updateUserProfile.bind(userPreferences),
    resetToDefaults: userPreferences.resetToDefaults.bind(userPreferences),
  };
}