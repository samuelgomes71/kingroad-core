/**
 * UserProfileScreen.js
 * 
 * Tela de perfil do usuário
 * Exibe informações do perfil, estatísticas e preferências do usuário
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Switch,
  Alert,
  ActivityIndicator
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import LocaleService from '../services/LocaleService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import UserService from '../services/UserService';
import StatisticsService from '../services/StatisticsService';
import { useTheme } from '../contexts/ThemeContext';

const UserProfileScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const [user, setUser] = useState(null);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationTrackingEnabled, setLocationTrackingEnabled] = useState(true);
  const [dataBackupEnabled, setDataBackupEnabled] = useState(true);

  useEffect(() => {
    loadUserData();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma para atualizar formatações
      loadUserData();
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);

  const loadUserData = async () => {
    try {
      setLoading(true);
      
      // Carrega dados do usuário
      const userData = await UserService.getCurrentUser();
      setUser(userData);
      
      // Carrega estatísticas
      const userStats = await StatisticsService.getUserStatistics(userData.id);
      setStatistics(userStats);
      
      // Carrega preferências
      setNotificationsEnabled(await UserService.getPreference('notifications_enabled', true));
      setLocationTrackingEnabled(await UserService.getPreference('location_tracking_enabled', true));
      setDataBackupEnabled(await UserService.getPreference('data_backup_enabled', true));
      
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar dados do usuário:', error);
      setLoading(false);
      
      Alert.alert(
        t('alert.error'),
        t('error.load_user_data'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadUserData();
    setRefreshing(false);
  };

  const handleSignOut = () => {
    Alert.alert(
      t('alert.confirm'),
      t('alert.confirm_signout'),
      [
        {
          text: t('button.cancel'),
          style: 'cancel'
        },
        {
          text: t('button.sign_out'),
          onPress: async () => {
            try {
              await UserService.signOut();
              navigation.reset({
                index: 0,
                routes: [{ name: 'Login' }],
              });
            } catch (error) {
              console.error('Erro ao fazer logout:', error);
              Alert.alert(
                t('alert.error'),
                t('error.sign_out_failed'),
                [{ text: t('button.ok') }]
              );
            }
          }
        }
      ]
    );
  };

  const handleToggleNotifications = async (value) => {
    setNotificationsEnabled(value);
    await UserService.setPreference('notifications_enabled', value);
  };

  const handleToggleLocationTracking = async (value) => {
    setLocationTrackingEnabled(value);
    await UserService.setPreference('location_tracking_enabled', value);
  };

  const handleToggleDataBackup = async (value) => {
    setDataBackupEnabled(value);
    await UserService.setPreference('data_backup_enabled', value);
  };

  const handleEditProfile = () => {
    navigation.navigate('EditProfile', { user });
  };

  const handleLanguageSettings = () => {
    navigation.navigate('LanguageSettings');
  };

  const handleRegionalSettings = () => {
    navigation.navigate('RegionalSettings');
  };

  const handlePrivacySettings = () => {
    navigation.navigate('PrivacySettings');
  };

  const handleAbout = () => {
    navigation.navigate('About');
  };

  const handleHelp = () => {
    navigation.navigate('Help');
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[styles.loadingText, { color: theme.text }]}>
          {t('screen.profile.loading')}
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshing={refreshing}
        onRefresh={handleRefresh}
      >
        {/* Cabeçalho do perfil */}
        <View style={styles.profileHeader}>
          <Image
            source={user?.profilePhoto ? { uri: user.profilePhoto } : require('../assets/default-avatar.png')}
            style={styles.profilePhoto}
          />
          <View style={styles.profileInfo}>
            <Text style={[styles.userName, { color: theme.text }]}>
              {user?.name || t('screen.profile.anonymous')}
            </Text>
            <Text style={[styles.userEmail, { color: theme.textSecondary }]}>
              {user?.email || ''}
            </Text>
            <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
              <Text style={[styles.editButtonText, { color: theme.primary }]}>
                {t('button.edit_profile')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Estatísticas */}
        <View style={[styles.section, { backgroundColor: theme.card }]}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.profile.statistics')}
          </Text>
          <View style={styles.statisticsContainer}>
            <View style={styles.statisticsItem}>
              <Icon name="directions-car" size={24} color={theme.primary} />
              <Text style={[styles.statisticsValue, { color: theme.text }]}>
                {RegionalSettingsService.formatDistance(statistics?.totalDistance || 0)}
              </Text>
              <Text style={[styles.statisticsLabel, { color: theme.textSecondary }]}>
                {t('screen.profile.total_distance')}
              </Text>
            </View>
            <View style={styles.statisticsItem}>
              <Icon name="access-time" size={24} color={theme.primary} />
              <Text style={[styles.statisticsValue, { color: theme.text }]}>
                {statistics?.totalTrips || 0}
              </Text>
              <Text style={[styles.statisticsLabel, { color: theme.textSecondary }]}>
                {t('screen.profile.total_trips')}
              </Text>
            </View>
            <View style={styles.statisticsItem}>
              <Icon name="star" size={24} color={theme.primary} />
              <Text style={[styles.statisticsValue, { color: theme.text }]}>
                {statistics?.safetyScore ? `${statistics.safetyScore}/100` : '-'}
              </Text>
              <Text style={[styles.statisticsLabel, { color: theme.textSecondary }]}>
                {t('screen.profile.safety_score')}
              </Text>
            </View>
          </View>
        </View>

        {/* Configurações */}
        <View style={[styles.section, { backgroundColor: theme.card }]}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.profile.settings')}
          </Text>
          
          <View style={styles.settingItem}>
            <Icon name="notifications" size={20} color={theme.primary} />
            <Text style={[styles.settingLabel, { color: theme.text }]}>
              {t('screen.profile.notifications')}
            </Text>
            <Switch
              value={notificationsEnabled}
              onValueChange={handleToggleNotifications}
              trackColor={{ false: theme.switchTrackOff, true: theme.primary }}
              thumbColor={theme.switchThumb}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Icon name="location-on" size={20} color={theme.primary} />
            <Text style={[styles.settingLabel, { color: theme.text }]}>
              {t('screen.profile.location_tracking')}
            </Text>
            <Switch
              value={locationTrackingEnabled}
              onValueChange={handleToggleLocationTracking}
              trackColor={{ false: theme.switchTrackOff, true: theme.primary }}
              thumbColor={theme.switchThumb}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Icon name="backup" size={20} color={theme.primary} />
            <Text style={[styles.settingLabel, { color: theme.text }]}>
              {t('screen.profile.data_backup')}
            </Text>
            <Switch
              value={dataBackupEnabled}
              onValueChange={handleToggleDataBackup}
              trackColor={{ false: theme.switchTrackOff, true: theme.primary }}
              thumbColor={theme.switchThumb}
            />
          </View>

          <TouchableOpacity style={styles.menuItem} onPress={handleLanguageSettings}>
            <Icon name="language" size={20} color={theme.primary} />
            <Text style={[styles.menuItemText, { color: theme.text }]}>
              {t('screen.profile.language_settings')}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={handleRegionalSettings}>
            <Icon name="public" size={20} color={theme.primary} />
            <Text style={[styles.menuItemText, { color: theme.text }]}>
              {t('screen.profile.regional_settings')}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={handlePrivacySettings}>
            <Icon name="security" size={20} color={theme.primary} />
            <Text style={[styles.menuItemText, { color: theme.text }]}>
              {t('screen.profile.privacy_settings')}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* Suporte */}
        <View style={[styles.section, { backgroundColor: theme.card }]}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.profile.support')}
          </Text>
          
          <TouchableOpacity style={styles.menuItem} onPress={handleAbout}>
            <Icon name="info" size={20} color={theme.primary} />
            <Text style={[styles.menuItemText, { color: theme.text }]}>
              {t('screen.profile.about')}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.textSecondary} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.menuItem} onPress={handleHelp}>
            <Icon name="help" size={20} color={theme.primary} />
            <Text style={[styles.menuItemText, { color: theme.text }]}>
              {t('screen.profile.help')}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* Botão de logout */}
        <TouchableOpacity
          style={[styles.signOutButton, { backgroundColor: theme.danger }]}
          onPress={handleSignOut}
        >
          <Text style={styles.signOutButtonText}>
            {t('button.sign_out')}
          </Text>
        </TouchableOpacity>

        {/* Versão do app */}
        <Text style={[styles.versionText, { color: theme.textSecondary }]}>
          {t('screen.profile.version', { version: '2.5.0' })}
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profilePhoto: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  profileInfo: {
    marginLeft: 16,
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  userEmail: {
    fontSize: 14,
    marginTop: 4,
  },
  editButton: {
    marginTop: 8,
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  section: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statisticsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statisticsItem: {
    alignItems: 'center',
    flex: 1,
  },
  statisticsValue: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 8,
  },
  statisticsLabel: {
    fontSize: 12,
    marginTop: 4,
    textAlign: 'center',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingLabel: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  menuItemText: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
  },
  signOutButton: {
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  signOutButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    marginBottom: 20,
  },
});

export default UserProfileScreen;