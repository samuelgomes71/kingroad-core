package com.kingroad.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.kingroad.db.converters.FacilityFeatureConverter
import com.kingroad.db.converters.OperatingHoursConverter
import com.kingroad.db.converters.ParkingSpotTypeConverter
import java.time.DayOfWeek

/**
 * Modelo que representa um local de estacionamento para caminhões
 */
@Entity(tableName = "parking_spots")
@TypeConverters(
    FacilityFeatureConverter::class,
    OperatingHoursConverter::class,
    ParkingSpotTypeConverter::class
)
data class ParkingSpot(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String? = null,
    val spotType: ParkingSpotType,
    val location: Location,
    val address: Address? = null,
    val phone: String? = null,
    val website: String? = null,
    val operatingHours: Map<DayOfWeek, OperatingHours>? = null,
    val features: List<FacilityFeature> = emptyList(),
    val totalSpaces: Int? = null,
    val availableSpaces: Int? = null,
    val hasPaidSpaces: Boolean = false,
    val pricePerHour: Double? = null,
    val maxStayHours: Int? = null,
    val rating: Double = 0.0,
    val reviewCount: Int = 0,
    val safetyRating: Double = 0.0,
    val securityFeatures: List<String> = emptyList(),
    val maxHeight: Double? = null,
    val maxWeight: Double? = null,
    val maxLength: Double? = null,
    val lastUpdated: Long = System.currentTimeMillis(),
    val isVerified: Boolean = false,
    val isUserReported: Boolean = false,
    val isClosed: Boolean = false
)

/**
 * Modelo que representa a localização geográfica
 */
data class Location(
    val latitude: Double,
    val longitude: Double
)

/**
 * Modelo que representa um endereço
 */
data class Address(
    val street: String,
    val city: String,
    val state: String,
    val postalCode: String,
    val country: String,
    val formattedAddress: String
)

/**
 * Modelo que representa horários de funcionamento
 */
data class OperatingHours(
    val open24Hours: Boolean = false,
    val openTime: String? = null,  // Formato HH:mm
    val closeTime: String? = null, // Formato HH:mm
    val isClosed: Boolean = false
)

/**
 * Tipos de estacionamento
 */
enum class ParkingSpotType {
    TRUCK_STOP,
    REST_AREA,
    SERVICE_AREA,
    DEDICATED_PARKING,
    WAREHOUSE_YARD,
    PUBLIC_PARKING,
    SHOPPING_CENTER,
    RESTAURANT_PARKING,
    GAS_STATION,
    INFORMAL_AREA,
    OTHER
}

/**
 * Recursos disponíveis no local de estacionamento
 */
enum class FacilityFeature {
    RESTROOMS,
    SHOWERS,
    RESTAURANT,
    CONVENIENCE_STORE,
    FUEL,
    ELECTRIC_CHARGING,
    WIFI,
    ATM,
    TRUCK_WASH,
    REPAIR_SERVICE,
    SECURITY_SURVEILLANCE,
    SECURITY_PERSONNEL,
    FENCED_AREA,
    LIGHTED_AREA,
    WATER_SUPPLY,
    TRASH_DISPOSAL,
    LAUNDRY,
    TRUCK_SCALES,
    LOUNGE,
    MEDICAL_SERVICES,
    HOTEL_NEARBY
}

/**
 * Especificações de um caminhão
 */
data class TruckSpecs(
    val height: Double, // em metros
    val weight: Double, // em kg
    val length: Double, // em metros
    val width: Double = 2.6,  // em metros (padrão para caminhões grandes)
    val hasHazardousMaterials: Boolean = false,
    val hasRefrigeration: Boolean = false,
    val fuelType: FuelType = FuelType.DIESEL
)

/**
 * Tipos de combustível
 */
enum class FuelType {
    DIESEL,
    GASOLINE,
    ELECTRIC,
    NATURAL_GAS,
    BIODIESEL,
    HYDROGEN
}

/**
 * Tipos de POI (Pontos de Interesse)
 */
enum class PoiType {
    RESTAURANT,
    CAFE,
    FAST_FOOD,
    SUPERMARKET,
    PHARMACY,
    HOSPITAL,
    BANK,
    HOTEL,
    GAS_STATION,
    TRUCK_STOP,
    REST_AREA,
    SHOPPING_CENTER,
    AUTOMOTIVE_SERVICE,
    LOADING_DOCK,
    WAREHOUSE,
    PARKING
}