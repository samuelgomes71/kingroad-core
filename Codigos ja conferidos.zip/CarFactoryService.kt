class CarFactoryService {
    private val factories = mutableMapOf<String, CarFactory>()
    
    fun addFactory(factory: CarFactory) {
        factories[factory.id] = factory
    }
    
    fun updateLoadingPointStatus(
        factoryId: String,
        loadingPointId: String,
        status: LoadingPointStatus
    ) {
        factories[factoryId]?.let { factory ->
            val updatedLoadingPoints = factory.loadingPoints.map { point ->
                if (point.id == loadingPointId) point.copy(status = status)
                else point
            }
            factories[factoryId] = factory.copy(loadingPoints = updatedLoadingPoints)
        }
    }
    
    fun getNearbyFactories(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 100.0,
        manufacturer: String? = null,
        filters: FactoryFilters = FactoryFilters()
    ): List<CarFactory> {
        return factories.values.filter { factory ->
            // Verifica distância
            val distance = calculateDistance(
                latitude, longitude,
                factory.location.latitude, factory.location.longitude
            )
            
            if (distance > radiusKm) return@filter false
            if (manufacturer != null && factory.manufacturer != manufacturer) return@filter false
            
            // Aplica filtros
            if (filters.requiresParking && !factory.facilities.hasParking) return@filter false
            if (filters.operationalLoadingPoints && 
                !factory.loadingPoints.any { it.status == LoadingPointStatus.OPERATIONAL }) {
                return@filter false
            }
            
            true
        }.sortedBy { factory ->
            calculateDistance(
                latitude, longitude,
                factory.location.latitude, factory.location.longitude
            )
        }
    }

    data class FactoryFilters(
        val requiresParking: Boolean = false,
        val operationalLoadingPoints: Boolean = true
    )

    // Exemplo de dados para teste
    fun initializeTestData() {
        // Volkswagen Wolfsburg
        addFactory(
            CarFactory(
                id = "vw_wolfsburg",
                name = "Volkswagen Werk Wolfsburg",
                manufacturer = "Volkswagen",
                location = Location(
                    latitude = 52.4263,
                    longitude = 10.7863,
                    accessRoutes = listOf(
                        AccessRoute(
                            name = "Truck Gate North",
                            type = RouteType.TRUCK_ENTRANCE,
                            restrictions = listOf(
                                RouteRestriction(
                                    type = RestrictionType.HEIGHT,
                                    value = "4.5m"
                                )
                            ),
                            recommendedForTrucks = true,
                            instructions = "Follow signs to 'Tor Nord'"
                        )
                    )
                ),
                country = "DE",
                address = "Stellfelder Str. 46, 38440 Wolfsburg, Germany",
                loadingPoints = listOf(
                    LoadingPoint(
                        id = "wolf_north_1",
                        name = "North Loading Dock 1",
                        type = LoadingType.TRUCK_LOADING,
                        capacity = 4,
                        restrictions = listOf(
                            LoadingRestriction(
                                type = "Registration",
                                description = "Pre-registration required 24h in advance"
                            )
                        ),
                        coordinates = Location(52.4270, 10.7865, listOf()),
                        instructions = "Report to security gate first"
                    )
                ),
                operatingHours = OperatingHours(
                    loadingHours = Schedule(
                        weekday = TimeRange("06:00", "22:00"),
                        saturday = TimeRange("08:00", "16:00"),
                        sunday = null,
                        holidays = null
                    ),
                    securityOfficeHours = Schedule(
                        weekday = TimeRange("00:00", "23:59"),
                        saturday = TimeRange("00:00", "23:59"),
                        sunday = TimeRange("00:00", "23:59"),
                        holidays = TimeRange("00:00", "23:59")
                    )
                ),
                contact = ContactInfo(
                    loadingDock = "+49 5361 12345",
                    security = "+49 5361 12346",
                    emergency = "112",
                    email = "logistics.wolfsburg@volkswagen.de",
                    specialInstructions = "Call 2 hours before arrival"
                ),
                facilities = FactoryFacilities(
                    hasDriverRoom = true,
                    hasRestroom = true,
                    hasParking = true,
                    parkingCapacity = 50,
                    hasWaitingArea = true,
                    hasCafeteria = true,
                    hasWifi = true
                ),
                securityRequirements = SecurityRequirements(
                    requiresPreRegistration = true,
                    requiresIdentification = true,
                    requiresVehicleInspection = true,
                    specialDocuments = listOf(
                        "Transport Order",
                        "Driver's License",
                        "Vehicle Registration"
                    )
                ),
                vehicles = listOf(
                    VehicleType(
                        make = "Volkswagen",
                        models = listOf("Golf", "Tiguan", "ID.4")
                    )
                )
            )
        )

        // Toyota Takaoka
        addFactory(
            CarFactory(
                id = "toyota_takaoka",
                name = "Toyota Takaoka Plant",
                manufacturer = "Toyota",
                location = Location(
                    latitude = 35.0538,
                    longitude = 137.1481,
                    accessRoutes = listOf(
                        AccessRoute(
                            name = "Main Truck Entrance",
                            type = RouteType.TRUCK_ENTRANCE,
                            restrictions = listOf(),
                            recommendedForTrucks = true,
                            instructions = "Follow Toyota Way to Gate 3"
                        )
                    )
                ),
                country = "JP",
                address = "1 Toyota-cho, Toyota, Aichi Prefecture 471-8571, Japan",
                loadingPoints = listOf(
                    LoadingPoint(
                        id = "takaoka_main",
                        name = "Main Loading Area",
                        type = LoadingType.TRUCK_LOADING,
                        capacity = 6,
                        restrictions = listOf(),
                        coordinates = Location(35.0540, 137.1485, listOf()),
                        instructions = "Check in at security post"
                    )
                ),
                operatingHours = OperatingHours(
                    loadingHours = Schedule(
                        weekday = TimeRange("07:00", "19:00"),
                        saturday = null,
                        sunday = null,
                        holidays = null
                    ),
                    securityOfficeHours = Schedule(
                        weekday = TimeRange("00:00", "23:59"),
                        saturday = TimeRange("00:00", "23:59"),
                        sunday = TimeRange("00:00", "23:59"),
                        holidays = TimeRange("00:00", "23:59")
                    )
                ),
                contact = ContactInfo(
                    loadingDock = "+81 565-12345",
                    security = "+81 565-12346",
                    emergency = "119",
                    email = "takaoka.logistics@toyota.co.jp",
                    specialInstructions = "Registration required 48h in advance"
                ),
                facilities = FactoryFacilities(
                    hasDriverRoom = true,
                    hasRestroom = true,
                    hasParking = true,
                    parkingCapacity = 30,
                    hasWaitingArea = true,
                    hasCafeteria = true,
                    hasWifi = false
                ),
                securityRequirements = SecurityRequirements(
                    requiresPreRegistration = true,
                    requiresIdentification = true,
                    requiresVehicleInspection = true,
                    specialDocuments = listOf(
                        "Transport Authorization",
                        "Driver ID",
                        "Vehicle Documents"
                    )
                ),
                vehicles = listOf(
                    VehicleType(
                        make = "Toyota",
                        models = listOf("Corolla", "RAV4")
                    )
                )
            )
        )
    }

    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val R = 6371.0 // Raio da Terra em km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }
}