import React, { useState, useEffect } from 'react';
import { Volume2, Download, Play, Pause, Plus, ChevronLeft, ChevronRight, Save, Sliders } from 'lucide-react';

const AlertSoundSettings = () => {
  // Estado para armazenar configurações de áudio para diferentes tipos de alertas
  const [audioSettings, setAudioSettings] = useState({
    radar_fixo: {
      nome: 'Radar Fixo',
      audioFile: 'radar_fixo_padrao.mp3',
      audioName: 'Bip Padrão',
      distanciaAviso1: 800,
      distanciaAviso2: 300,
      volume: 80,
      ativo: true
    },
    radar_movel: {
      nome: 'Radar Móvel',
      audioFile: 'radar_movel_padrao.mp3',
      audioName: 'Alerta Urgente',
      distanciaAviso1: 1000,
      distanciaAviso2: 400,
      volume: 90,
      ativo: true
    },
    radar_semaforo: {
      nome: 'Radar de Semáforo',
      audioFile: 'radar_semaforo_padrao.mp3',
      audioName: 'Sino',
      distanciaAviso1: 500,
      distanciaAviso2: 200,
      volume: 85,
      ativo: true
    },
    lombada_eletronica: {
      nome: 'Lombada Eletrônica',
      audioFile: 'lombada_eletronica_padrao.mp3',
      audioName: 'Bump',
      distanciaAviso1: 600,
      distanciaAviso2: 200,
      volume: 75,
      ativo: true
    },
    acidente: {
      nome: 'Acidente',
      audioFile: 'acidente_padrao.mp3',
      audioName: 'Sirene',
      distanciaAviso1: 1500,
      distanciaAviso2: 500,
      volume: 100,
      ativo: true
    },
    bloqueio: {
      nome: 'Bloqueio de Via',
      audioFile: 'bloqueio_padrao.mp3',
      audioName: 'Aviso Importante',
      distanciaAviso1: 2000,
      distanciaAviso2: 800,
      volume: 90,
      ativo: true
    }
  });

  // Lista de sons disponíveis para download
  const [avaliableSounds, setAvaliableSounds] = useState([
    { id: 1, name: 'Alerta Tio Sam', file: 'tio_sam_alerta.mp3', downloadSize: '36KB', category: 'all' },
    { id: 2, name: 'Sirene Bombeiros', file: 'bombeiros_sirene.mp3', downloadSize: '58KB', category: 'emergency' },
    { id: 3, name: 'Voz Feminina', file: 'voz_feminina_alerta.mp3', downloadSize: '120KB', category: 'voice' },
    { id: 4, name: 'Voz Masculina', file: 'voz_masculina_alerta.mp3', downloadSize: '118KB', category: 'voice' },
    { id: 5, name: 'Bip Discreto', file: 'bip_discreto.mp3', downloadSize: '24KB', category: 'soft' },
    { id: 6, name: 'Alerta Dinâmico', file: 'alerta_dinamico.mp3', downloadSize: '76KB', category: 'modern' },
    { id: 7, name: 'Som Vintage', file: 'radar_vintage.mp3', downloadSize: '65KB', category: 'fun' },
  ]);

  // Estado para controlar reprodução de áudio
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentlyPlaying, setCurrentlyPlaying] = useState(null);
  
  // Estado para controlar qual tipo de alerta está sendo editado
  const [editingType, setEditingType] = useState('radar_fixo');
  
  // Estado para filtro de sons disponíveis
  const [soundFilter, setSoundFilter] = useState('all');

  // Simula reprodução de áudio
  const playSound = (type) => {
    if (isPlaying && currentlyPlaying === type) {
      setIsPlaying(false);
      setCurrentlyPlaying(null);
    } else {
      setIsPlaying(true);
      setCurrentlyPlaying(type);
      
      // Aqui iria a reprodução real do áudio
      console.log(`Reproduzindo som: ${audioSettings[type].audioFile}`);
      
      // Simula o fim do áudio após 2 segundos
      setTimeout(() => {
        if (currentlyPlaying === type) {
          setIsPlaying(false);
          setCurrentlyPlaying(null);
        }
      }, 2000);
    }
  };

  // Baixa um novo som
  const downloadSound = (sound) => {
    console.log(`Baixando som: ${sound.name}`);
    // Implementação real faria o download do arquivo
    
    // Após download, adicionar à lista de sons disponíveis
    alert(`Som "${sound.name}" baixado com sucesso!`);
  };

  // Atualiza as configurações de um tipo de alerta
  const updateAlertSettings = (type, field, value) => {
    setAudioSettings(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        [field]: value
      }
    }));
  };

  // Salva todas as configurações
  const saveAllSettings = () => {
    console.log('Salvando configurações:', audioSettings);
    // Aqui salvaria as configurações no armazenamento persistente
    alert('Configurações salvas com sucesso!');
  };

  // Altera o som de um tipo de alerta
  const changeAlertSound = (type, soundName, soundFile) => {
    updateAlertSettings(type, 'audioName', soundName);
    updateAlertSettings(type, 'audioFile', soundFile);
  };

  // Filtra os sons disponíveis
  const filteredSounds = () => {
    if (soundFilter === 'all') return avaliableSounds;
    return avaliableSounds.filter(sound => sound.category === soundFilter);
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <div className="flex items-center">
          <Volume2 size={24} color="#FFD700" />
          <h1 className="text-xl font-bold ml-2">Personalizar Sons de Alerta</h1>
        </div>
        <button 
          className="bg-yellow-500 text-black font-bold py-2 px-4 rounded-lg flex items-center"
          onClick={saveAllSettings}
        >
          <Save size={18} />
          <span className="ml-1">Salvar</span>
        </button>
      </div>

      {/* Tipo de Alerta Seleção */}
      <div className="flex p-4 bg-gray-800 overflow-x-auto">
        {Object.keys(audioSettings).map(type => (
          <button
            key={type}
            className={`px-4 py-2 mx-1 whitespace-nowrap rounded-lg ${editingType === type ? 'bg-yellow-500 text-black font-bold' : 'bg-gray-700 text-white'}`}
            onClick={() => setEditingType(type)}
          >
            {audioSettings[type].nome}
          </button>
        ))}
      </div>
      
      {/* Configurações do Alerta Atual */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-bold mb-4">Configurações: {audioSettings[editingType].nome}</h2>
        
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-gray-400">Som Atual</h3>
            <div className="flex items-center mt-1">
              <p className="text-white mr-3">{audioSettings[editingType].audioName}</p>
              <button 
                className={`p-2 rounded-full ${isPlaying && currentlyPlaying === editingType ? 'bg-red-500' : 'bg-yellow-500'}`}
                onClick={() => playSound(editingType)}
              >
                {isPlaying && currentlyPlaying === editingType ? <Pause size={18} color="#000" /> : <Play size={18} color="#000" />}
              </button>
            </div>
          </div>
          
          <div className="text-right">
            <h3 className="text-gray-400">Status</h3>
            <label className="relative inline-flex items-center cursor-pointer mt-1">
              <input 
                type="checkbox" 
                className="sr-only peer"
                checked={audioSettings[editingType].ativo}
                onChange={(e) => updateAlertSettings(editingType, 'ativo', e.target.checked)}
              />
              <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
              <span className="ms-3 text-sm font-medium text-white">
                {audioSettings[editingType].ativo ? 'Ativo' : 'Desativado'}
              </span>
            </label>
          </div>
        </div>
        
        {/* Controle de Volume */}
        <div className="mb-4">
          <div className="flex justify-between">
            <label className="text-gray-400">Volume</label>
            <span className="text-white">{audioSettings[editingType].volume}%</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={audioSettings[editingType].volume} 
            onChange={(e) => updateAlertSettings(editingType, 'volume', parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer mt-2"
          />
        </div>
        
        {/* Controle de Distância */}
        <div className="mb-3">
          <div className="flex justify-between items-center">
            <label className="text-gray-400">Primeiro Aviso</label>
            <div className="flex items-center">
              <button 
                className="bg-gray-700 p-1 rounded-l"
                onClick={() => updateAlertSettings(editingType, 'distanciaAviso1', Math.max(100, audioSettings[editingType].distanciaAviso1 - 100))}
              >
                <ChevronLeft size={18} />
              </button>
              <span className="px-3 py-1 bg-gray-800">{audioSettings[editingType].distanciaAviso1}m</span>
              <button 
                className="bg-gray-700 p-1 rounded-r"
                onClick={() => updateAlertSettings(editingType, 'distanciaAviso1', Math.min(3000, audioSettings[editingType].distanciaAviso1 + 100))}
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between items-center">
            <label className="text-gray-400">Segundo Aviso</label>
            <div className="flex items-center">
              <button 
                className="bg-gray-700 p-1 rounded-l"
                onClick={() => updateAlertSettings(editingType, 'distanciaAviso2', Math.max(50, audioSettings[editingType].distanciaAviso2 - 50))}
              >
                <ChevronLeft size={18} />
              </button>
              <span className="px-3 py-1 bg-gray-800">{audioSettings[editingType].distanciaAviso2}m</span>
              <button 
                className="bg-gray-700 p-1 rounded-r"
                onClick={() => updateAlertSettings(editingType, 'distanciaAviso2', Math.min(audioSettings[editingType].distanciaAviso1 - 100, audioSettings[editingType].distanciaAviso2 + 50))}
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Biblioteca de Sons */}
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">Biblioteca de Sons</h2>
          <button className="flex items-center text-yellow-500">
            <Plus size={18} />
            <span className="ml-1">Mais Sons</span>
          </button>
        </div>
        
        {/* Filtros de Sons */}
        <div className="flex overflow-x-auto mb-4">
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'all' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('all')}
          >
            Todos
          </button>
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'voice' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('voice')}
          >
            Vozes
          </button>
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'emergency' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('emergency')}
          >
            Emergência
          </button>
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'soft' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('soft')}
          >
            Discretos
          </button>
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'modern' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('modern')}
          >
            Modernos
          </button>
          <button
            className={`px-3 py-1 mx-1 rounded-full text-sm ${soundFilter === 'fun' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white'}`}
            onClick={() => setSoundFilter('fun')}
          >
            Divertidos
          </button>
        </div>
        
        {/* Lista de Sons */}
        <div className="bg-gray-800 rounded-lg max-h-60 overflow-y-auto">
          {filteredSounds().map(sound => (
            <div key={sound.id} className="flex justify-between items-center p-3 border-b border-gray-700">
              <div>
                <p className="text-white font-medium">{sound.name}</p>
                <p className="text-gray-400 text-sm">{sound.downloadSize}</p>
              </div>
              
              <div className="flex items-center">
                <button 
                  className="p-2 mr-2 rounded-full bg-gray-700"
                  onClick={() => playSound(`sound_${sound.id}`)}
                >
                  {isPlaying && currentlyPlaying === `sound_${sound.id}` ? 
                    <Pause size={16} /> : <Play size={16} />}
                </button>
                
                <button 
                  className="p-2 mr-2 rounded-full bg-gray-700"
                  onClick={() => changeAlertSound(editingType, sound.name, sound.file)}
                >
                  <Sliders size={16} />
                </button>
                
                <button 
                  className="p-2 rounded-full bg-yellow-500"
                  onClick={() => downloadSound(sound)}
                >
                  <Download size={16} color="#000" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Dica de Uso */}
      <div className="p-4 mt-auto bg-gray-800 border-t border-gray-700">
        <p className="text-gray-400 text-sm text-center">
          Personalize cada tipo de alerta com sons diferentes para uma melhor experiência de navegação.
          Os alertas sonoros reproduzirão automaticamente ao se aproximar das distâncias configuradas.
        </p>
      </div>
    </div>
  );
};

export default AlertSoundSettings;