r/bin/env node

/**
 * King Road - Script de compilação e organização do projeto
 * 
 * Este script ajuda a:
 * 1. Identificar componentes duplicados
 * 2. Organizar e integrar diferentes partes do projeto
 * 3. Priorizar implementações mais recentes
 * 4. Garantir consistência na interface do usuário
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configurações
const CONFIG = {
  srcDir: './src',                     // Diretório de código fonte
  componentsDir: './src/components',    // Diretório de componentes
  interfaceDir: './src/interface',      // Diretório de interfaces
  outputDir: './build',                 // Diretório de saída
  preferredInterface: 'tomtom-truck',   // Interface preferencial (mais recente)
  logFile: './king-road-build.log',     // Arquivo de log
  hashLogFile: './component-hashes.json' // Arquivo de hash dos componentes
};

// Garantir que os diretórios existam
function ensureDirectoryExists(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`Diretório criado: ${dir}`);
  }
}

// Inicialização
function init() {
  console.log('🚚 King Road - Iniciando compilação e organização do projeto');
  
  ensureDirectoryExists(CONFIG.outputDir);
  ensureDirectoryExists(path.join(CONFIG.outputDir, 'components'));
  
  // Iniciar log
  fs.writeFileSync(CONFIG.logFile, `King Road - Log de Compilação\nData: ${new Date().toISOString()}\n\n`);
  logMessage('Iniciando compilação do King Road');
}

// Função para registrar mensagens no log
function logMessage(message) {
  const logEntry = `[${new Date().toISOString()}] ${message}\n`;
  console.log(message);
  fs.appendFileSync(CONFIG.logFile, logEntry);
}

// Gerar hash de conteúdo para identificar componentes similares
function generateContentHash(content) {
  return crypto.createHash('md5').update(content).digest('hex');
}

// Encontrar componentes duplicados baseados em conteúdo similar
function findDuplicateComponents() {
  logMessage('Analisando componentes em busca de duplicatas...');
  
  const components = {};
  const hashes = {};
  let duplicatesFound = 0;
  
  // Ler todos os arquivos de componentes
  function readComponentsRecursively(dir) {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    
    for (const item of items) {
      const itemPath = path.join(dir, item.name);
      
      if (item.isDirectory()) {
        readComponentsRecursively(itemPath);
      } else if (item.isFile() && (
        itemPath.endsWith('.js') || 
        itemPath.endsWith('.jsx') || 
        itemPath.endsWith('.ts') || 
        itemPath.endsWith('.tsx')
      )) {
        const content = fs.readFileSync(itemPath, 'utf8');
        const hash = generateContentHash(content);
        
        if (!components[hash]) {
          components[hash] = [];
        }
        
        components[hash].push({
          path: itemPath,
          name: item.name,
          size: content.length,
          modifiedTime: fs.statSync(itemPath).mtime
        });
        
        // Registrar o componente
        hashes[itemPath] = {
          hash,
          size: content.length,
          modifiedTime: fs.statSync(itemPath).mtime.toISOString()
        };
      }
    }
  }
  
  if (fs.existsSync(CONFIG.componentsDir)) {
    readComponentsRecursively(CONFIG.componentsDir);
  }
  
  // Salvar o registro de hashes
  fs.writeFileSync(CONFIG.hashLogFile, JSON.stringify(hashes, null, 2));
  
  // Identificar duplicatas
  for (const hash in components) {
    if (components[hash].length > 1) {
      duplicatesFound++;
      logMessage(`Possíveis componentes duplicados encontrados (hash: ${hash.substring(0, 8)}...):`);
      
      // Ordenar por data de modificação (mais recente primeiro)
      components[hash].sort((a, b) => b.modifiedTime - a.modifiedTime);
      
      components[hash].forEach((comp, index) => {
        logMessage(`  ${index === 0 ? '✅' : '❌'} ${comp.path} (${formatDate(comp.modifiedTime)})`);
      });
      
      // Marcar o componente mais recente para manter
      const mostRecent = components[hash][0];
      logMessage(`  Mantendo o componente mais recente: ${mostRecent.path}`);
    }
  }
  
  if (duplicatesFound === 0) {
    logMessage('Nenhum componente duplicado encontrado.');
  } else {
    logMessage(`Total de ${duplicatesFound} conjuntos de componentes duplicados encontrados.`);
  }
  
  return components;
}

// Identificar e consolidar interfaces
function consolidateInterfaces() {
  logMessage('Consolidando interfaces...');
  
  if (!fs.existsSync(CONFIG.interfaceDir)) {
    logMessage('Diretório de interfaces não encontrado.');
    return;
  }
  
  const interfaces = fs.readdirSync(CONFIG.interfaceDir, { withFileTypes: true })
    .filter(item => item.isDirectory())
    .map(item => item.name);
  
  logMessage(`Interfaces encontradas: ${interfaces.join(', ')}`);
  
  // Verificar se a interface preferida existe
  if (interfaces.includes(CONFIG.preferredInterface)) {
    logMessage(`Utilizando interface preferida: ${CONFIG.preferredInterface}`);
    
    // Copiar a interface preferida para o diretório de saída
    const srcDir = path.join(CONFIG.interfaceDir, CONFIG.preferredInterface);
    const destDir = path.join(CONFIG.outputDir, 'interface');
    
    ensureDirectoryExists(destDir);
    copyDirectory(srcDir, destDir);
    
    logMessage(`Interface ${CONFIG.preferredInterface} copiada para o diretório de saída.`);
  } else if (interfaces.length > 0) {
    // Se a interface preferida não existir, usar a mais recente
    const interfaceStats = interfaces.map(intf => {
      const intfPath = path.join(CONFIG.interfaceDir, intf);
      return {
        name: intf,
        path: intfPath,
        mtime: fs.statSync(intfPath).mtime
      };
    });
    
    // Ordenar por data de modificação (mais recente primeiro)
    interfaceStats.sort((a, b) => b.mtime - a.mtime);
    const latestInterface = interfaceStats[0];
    
    logMessage(`Interface preferida não encontrada. Usando a mais recente: ${latestInterface.name}`);
    
    // Copiar a interface mais recente para o diretório de saída
    const srcDir = path.join(CONFIG.interfaceDir, latestInterface.name);
    const destDir = path.join(CONFIG.outputDir, 'interface');
    
    ensureDirectoryExists(destDir);
    copyDirectory(srcDir, destDir);
    
    logMessage(`Interface ${latestInterface.name} copiada para o diretório de saída.`);
  } else {
    logMessage('Nenhuma interface encontrada.');
  }
}

// Copiar diretório recursivamente
function copyDirectory(src, dest) {
  ensureDirectoryExists(dest);
  
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDirectory(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// Formatação de data para exibição
function formatDate(date) {
  return new Date(date).toLocaleString();
}

// Função principal
function main() {
  init();
  
  try {
    const duplicateComponents = findDuplicateComponents();
    consolidateInterfaces();
    
    // Construir projeto final
    logMessage('Construindo projeto final...');
    
    // Aqui você pode adicionar passos adicionais como:
    // - Executar bundler (webpack, rollup, etc)
    // - Executar linter
    // - Executar testes
    
    logMessage('Compilação concluída com sucesso!');
    
  } catch (error) {
    logMessage(`❌ ERRO: ${error.message}`);
    console.error(error);
  }
}

// Executar o script
main();