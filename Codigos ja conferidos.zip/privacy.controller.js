// privacy.controller.js
// Controlador para gerenciar configurações de privacidade no KingChat

const PrivacyModel = require('../models/privacy.model');
const UserModel = require('../models/user.model');

/**
 * Get user privacy settings
 */
exports.getPrivacySettings = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming user ID comes from auth middleware
    
    const privacySettings = await PrivacyModel.findOne({ userId });
    
    if (!privacySettings) {
      // Return default settings if none exist
      return res.status(200).json({
        readReceiptOption: 'all',
        selectedContactsForReadReceipts: [],
        groupAdditionOption: 'all',
        selectedContactsForGroupAddition: []
      });
    }
    
    res.status(200).json(privacySettings);
  } catch (error) {
    console.error('Error fetching privacy settings:', error);
    res.status(500).json({ message: 'Failed to fetch privacy settings' });
  }
};

/**
 * Update user privacy settings
 */
exports.updatePrivacySettings = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming user ID comes from auth middleware
    const { readReceiptOption, selectedContactsForReadReceipts } = req.body;
    
    // Validate input data
    if (!['all', 'selected', 'none'].includes(readReceiptOption)) {
      return res.status(400).json({ message: 'Invalid read receipt option' });
    }
    
    // If 'selected' option, validate that contacts exist
    if (readReceiptOption === 'selected' && selectedContactsForReadReceipts) {
      for (const contactId of selectedContactsForReadReceipts) {
        const contactExists = await UserModel.exists(contactId);
        if (!contactExists) {
          return res.status(400).json({ 
            message: `Contact with ID ${contactId} does not exist` 
          });
        }
      }
    }
    
    // Update or create privacy settings
    const updatedSettings = await PrivacyModel.findOneAndUpdate(
      { userId },
      { 
        userId,
        readReceiptOption,
        selectedContactsForReadReceipts: readReceiptOption === 'selected' 
          ? selectedContactsForReadReceipts 
          : []
      },
      { new: true, upsert: true }
    );
    
    res.status(200).json(updatedSettings);
  } catch (error) {
    console.error('Error updating privacy settings:', error);
    res.status(500).json({ message: 'Failed to update privacy settings' });
  }
};

/**
 * Update just read receipt privacy settings
 */
exports.updateReadReceiptPrivacy = async (req, res) => {
  try {
    const userId = req.user.id;
    const { readReceiptOption, selectedContactsForReadReceipts } = req.body;
    
    // Validate input data
    if (!['all', 'selected', 'none'].includes(readReceiptOption)) {
      return res.status(400).json({ message: 'Invalid read receipt option' });
    }
    
    // Update only the read receipt related fields
    const updatedSettings = await PrivacyModel.findOneAndUpdate(
      { userId },
      { 
        $set: {
          readReceiptOption,
          selectedContactsForReadReceipts: readReceiptOption === 'selected' 
            ? selectedContactsForReadReceipts 
            : []
        }
      },
      { new: true, upsert: true }
    );
    
    res.status(200).json(updatedSettings);
  } catch (error) {
    console.error('Error updating read receipt privacy settings:', error);
    res.status(500).json({ message: 'Failed to update privacy settings' });
  }
};