/**
 * IntelligentRerouteSystem.js
 * Sistema otimizado de recálculo de rota para o KingRoad
 * Prioriza recálculos rápidos e seguros para veículos pesados
 */

import translationsService from './TranslationsService';

class IntelligentRerouteSystem {
  constructor() {
    this.MAX_EMERGENCY_DISTANCE = 50; // Distância máxima em km para rota emergencial
    this.TRAFFIC_SCOPE_DISTANCE = 200; // Distância em km para dados de tráfego após reintegração
    this.TRAFFIC_UPDATE_INTERVAL = 2 * 60 * 1000; // 2 minutos em milissegundos
    this.currentRoute = null;
    this.originalRoute = null;
    this.deviationPoint = null;
    this.routeStatus = 'INACTIVE'; // INACTIVE, ACTIVE, DEVIATED, RECALCULATING, RECALIBRATED
    this.trafficTimer = null;
    this.vehicleProfile = {
      type: 'truck', // truck, car, motorcycle, etc.
      preferences: {
        avoidTolls: false,
        avoidHighways: false,
        preferTruckRoutes: true
      }
    };
  }

  /**
   * Inicia uma nova rota planejada
   * @param {Object} origin - Ponto de origem
   * @param {Object} destination - Ponto de destino
   * @param {Object} vehicleProfile - Perfil do veículo e preferências
   * @returns {Promise<Object>} - Rota completa calculada
   */
  async startRoute(origin, destination, vehicleProfile = null) {
    if (vehicleProfile) {
      this.vehicleProfile = vehicleProfile;
    }

    try {
      // Calcula a rota completa com dados de tráfego
      const fullRoute = await this._calculateFullRoute(origin, destination);
      
      this.originalRoute = fullRoute;
      this.currentRoute = fullRoute;
      this.routeStatus = 'ACTIVE';
      
      // Inicia atualizações de tráfego para os próximos 200km
      this._startTrafficUpdates();
      
      return fullRoute;
    } catch (error) {
      console.error('Erro ao iniciar rota:', error);
      throw new Error(translationsService.translate('routes.errors.startFailed'));
    }
  }

  /**
   * Detecta quando o motorista desviou da rota atual
   * @param {Object} currentPosition - Posição atual do veículo
   * @param {number} threshold - Distância em metros considerada como desvio
   * @returns {boolean} - Indica se houve desvio da rota
   */
  detectDeviation(currentPosition, threshold = 100) {
    if (!this.currentRoute || this.routeStatus === 'INACTIVE') {
      return false;
    }

    // Verifica se a posição atual está longe demais da rota planejada
    const isDeviated = this._calculateDistanceToRoute(currentPosition, this.currentRoute) > threshold;
    
    if (isDeviated && this.routeStatus === 'ACTIVE') {
      // Salva o ponto onde ocorreu o desvio
      this.deviationPoint = currentPosition;
      this.routeStatus = 'DEVIATED';
      
      // Pausa atualizações de tráfego durante o desvio
      this._pauseTrafficUpdates();
      
      // Inicia processo de recálculo
      this._handleDeviation(currentPosition);
    }
    
    return isDeviated;
  }

  /**
   * Trata o processo de desvio de rota
   * @private
   * @param {Object} currentPosition - Posição atual do veículo
   */
  async _handleDeviation(currentPosition) {
    try {
      this.routeStatus = 'RECALCULATING';
      
      // Calcula uma rota emergencial curta sem dados de tráfego
      const emergencyRoute = await this._calculateEmergencyRoute(
        currentPosition, 
        this.originalRoute, 
        this.MAX_EMERGENCY_DISTANCE
      );
      
      // Substitui apenas o trecho necessário da rota
      this.currentRoute = this._mergeRoutes(emergencyRoute, this.originalRoute);
      this.routeStatus = 'RECALIBRATED';
      
      return emergencyRoute;
    } catch (error) {
      console.error('Erro ao recalcular rota de emergência:', error);
      this._activateFailsafeMode();
      throw new Error(translationsService.translate('routes.errors.recalculationFailed'));
    }
  }

  /**
   * Calcula uma rota de emergência para retornar à rota original
   * @private
   * @param {Object} currentPosition - Posição atual do veículo
   * @param {Object} originalRoute - Rota original planejada
   * @param {number} maxDistance - Distância máxima para buscar retorno
   * @returns {Promise<Object>} - Rota de emergência
   */
  async _calculateEmergencyRoute(currentPosition, originalRoute, maxDistance) {
    // Encontra o melhor ponto para retornar à rota original
    const rejoinPoint = this._findBestRejoinPoint(currentPosition, originalRoute, maxDistance);
    
    // Calcula rota sem dados de tráfego em tempo real, priorizando segurança para caminhões
    const routeOptions = {
      origin: currentPosition,
      destination: rejoinPoint,
      useTrafficData: false,
      vehicleType: this.vehicleProfile.type,
      prioritizeSafety: true,
      maxDistance: maxDistance
    };
    
    // Chamada do serviço de rotas (mock)
    return this._callRoutingService(routeOptions);
  }

  /**
   * Encontra o melhor ponto para retornar à rota original
   * @private
   * @param {Object} currentPosition - Posição atual do veículo
   * @param {Object} originalRoute - Rota original planejada
   * @param {number} maxDistance - Distância máxima para buscar retorno
   * @returns {Object} - Ponto para retorno à rota original
   */
  _findBestRejoinPoint(currentPosition, originalRoute, maxDistance) {
    // Lógica para encontrar pontos adequados para caminhões voltarem à rota
    // Prioriza pontos onde há espaço adequado para manobras de veículos pesados
    
    // Esta é uma implementação simplificada
    let bestPoint = null;
    let minDistance = Infinity;
    
    // Percorre os pontos da rota original à frente do ponto de desvio
    for (const point of originalRoute.points) {
      // Calcula a distância até o ponto candidato
      const distance = this._calculateDistance(currentPosition, point);
      
      // Verifica se está dentro da distância máxima e é melhor que o anterior
      if (distance < maxDistance && distance < minDistance && this._isSafeForTruck(point)) {
        minDistance = distance;
        bestPoint = point;
      }
    }
    
    return bestPoint || this._findDefaultRejoinPoint(originalRoute);
  }

  /**
   * Verifica se um ponto é seguro para manobras de caminhão
   * @private
   * @param {Object} point - Ponto a ser verificado
   * @returns {boolean} - Indica se o ponto é seguro
   */
  _isSafeForTruck(point) {
    // Implementação simplificada - verificaria dados da via, largura, etc.
    return point.isIntersection || point.isRestArea || !point.isNarrowRoad;
  }

  /**
   * Encontra um ponto padrão de retorno caso não encontre um ideal
   * @private
   * @param {Object} originalRoute - Rota original
   * @returns {Object} - Ponto padrão de retorno
   */
  _findDefaultRejoinPoint(originalRoute) {
    // Lógica simplificada - poderia buscar o próximo ponto de parada segura
    // como um posto de combustível, área de descanso, etc.
    return originalRoute.points[Math.floor(originalRoute.points.length / 2)];
  }

  /**
   * Mescla a rota de emergência com a rota original
   * @private
   * @param {Object} emergencyRoute - Rota de emergência
   * @param {Object} originalRoute - Rota original
   * @returns {Object} - Rota mesclada
   */
  _mergeRoutes(emergencyRoute, originalRoute) {
    // Encontra ponto de junção entre as rotas
    const joinPoint = emergencyRoute.points[emergencyRoute.points.length - 1];
    
    // Encontra índice do ponto na rota original
    const joinIndex = originalRoute.points.findIndex(point => 
      this._arePointsEqual(point, joinPoint)
    );
    
    if (joinIndex === -1) {
      // Não encontrou um ponto exato, usa o mais próximo
      return this._mergeRoutesByProximity(emergencyRoute, originalRoute);
    }
    
    // Mescla os pontos da rota
    const mergedPoints = [
      ...emergencyRoute.points,
      ...originalRoute.points.slice(joinIndex + 1)
    ];
    
    // Cria uma nova rota com os pontos mesclados
    return {
      ...originalRoute,
      points: mergedPoints,
      distance: this._recalculateRouteDistance(mergedPoints),
      duration: this._recalculateRouteDuration(mergedPoints)
    };
  }

  /**
   * Mescla rotas quando não há um ponto exato de junção
   * @private
   * @param {Object} emergencyRoute - Rota de emergência
   * @param {Object} originalRoute - Rota original
   * @returns {Object} - Rota mesclada
   */
  _mergeRoutesByProximity(emergencyRoute, originalRoute) {
    // Último ponto da rota de emergência
    const lastEmergencyPoint = emergencyRoute.points[emergencyRoute.points.length - 1];
    
    // Encontra o ponto mais próximo na rota original
    let nearestIndex = 0;
    let minDistance = Infinity;
    
    originalRoute.points.forEach((point, index) => {
      const distance = this._calculateDistance(lastEmergencyPoint, point);
      if (distance < minDistance) {
        minDistance = distance;
        nearestIndex = index;
      }
    });
    
    // Mescla os pontos das rotas
    const mergedPoints = [
      ...emergencyRoute.points,
      ...originalRoute.points.slice(nearestIndex)
    ];
    
    // Cria nova rota mesclada
    return {
      ...originalRoute,
      points: mergedPoints,
      distance: this._recalculateRouteDistance(mergedPoints),
      duration: this._recalculateRouteDuration(mergedPoints)
    };
  }

  /**
   * Compara se dois pontos são iguais
   * @private
   * @param {Object} point1 - Primeiro ponto
   * @param {Object} point2 - Segundo ponto
   * @returns {boolean} - Indica se os pontos são iguais
   */
  _arePointsEqual(point1, point2) {
    // Compara com tolerância devido a possíveis diferenças de precisão
    const TOLERANCE = 0.00001; // Aproximadamente 1 metro
    return Math.abs(point1.lat - point2.lat) < TOLERANCE && 
           Math.abs(point1.lng - point2.lng) < TOLERANCE;
  }

  /**
   * Recalcula a distância total de uma rota
   * @private
   * @param {Array} points - Pontos da rota
   * @returns {number} - Distância em metros
   */
  _recalculateRouteDistance(points) {
    let totalDistance = 0;
    for (let i = 1; i < points.length; i++) {
      totalDistance += this._calculateDistance(points[i-1], points[i]);
    }
    return totalDistance;
  }

  /**
   * Recalcula a duração de uma rota
   * @private
   * @param {Array} points - Pontos da rota
   * @returns {number} - Duração em segundos
   */
  _recalculateRouteDuration(points) {
    // Implementação simplificada - em um caso real usaria velocidades das vias
    const AVG_SPEED = 60; // km/h
    const distanceInKm = this._recalculateRouteDistance(points) / 1000;
    return (distanceInKm / AVG_SPEED) * 3600; // segundos
  }

  /**
   * Calcula distância entre dois pontos geográficos (Haversine)
   * @private
   * @param {Object} point1 - Primeiro ponto {lat, lng}
   * @param {Object} point2 - Segundo ponto {lat, lng}
   * @returns {number} - Distância em metros
   */
  _calculateDistance(point1, point2) {
    const R = 6371e3; // Raio da Terra em metros
    const φ1 = point1.lat * Math.PI / 180;
    const φ2 = point2.lat * Math.PI / 180;
    const Δφ = (point2.lat - point1.lat) * Math.PI / 180;
    const Δλ = (point2.lng - point1.lng) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distância em metros
  }

  /**
   * Calcula a distância de um ponto à rota
   * @private
   * @param {Object} position - Posição a ser verificada
   * @param {Object} route - Rota para verificar distância
   * @returns {number} - Menor distância em metros até a rota
   */
  _calculateDistanceToRoute(position, route) {
    let minDistance = Infinity;
    
    // Percorre todos os segmentos da rota
    for (let i = 1; i < route.points.length; i++) {
      const segmentDistance = this._distanceToSegment(
        position, 
        route.points[i-1], 
        route.points[i]
      );
      
      if (segmentDistance < minDistance) {
        minDistance = segmentDistance;
      }
    }
    
    return minDistance;
  }

  /**
   * Calcula a distância de um ponto a um segmento de reta
   * @private
   * @param {Object} point - Ponto a verificar
   * @param {Object} segStart - Início do segmento
   * @param {Object} segEnd - Fim do segmento
   * @returns {number} - Distância em metros
   */
  _distanceToSegment(point, segStart, segEnd) {
    // Converte coordenadas para um sistema cartesiano aproximado
    // Simplificação para exemplo - uma implementação real usaria projeções adequadas
    const p = [point.lng, point.lat];
    const v = [segStart.lng, segStart.lat];
    const w = [segEnd.lng, segEnd.lat];
    
    // Verifica se o segmento é um ponto
    if (v[0] === w[0] && v[1] === w[1]) {
      return this._calculateDistance(point, segStart);
    }
    
    // Calcula projeção do ponto no segmento
    // Produto escalar
    const l2 = Math.pow(w[0] - v[0], 2) + Math.pow(w[1] - v[1], 2);
    const t = Math.max(0, Math.min(1, (
      (p[0] - v[0]) * (w[0] - v[0]) + 
      (p[1] - v[1]) * (w[1] - v[1])
    ) / l2));
    
    // Ponto mais próximo no segmento
    const projection = {
      lat: v[1] + t * (w[1] - v[1]),
      lng: v[0] + t * (w[0] - v[0])
    };
    
    // Retorna distância ao ponto projetado
    return this._calculateDistance(point, projection);
  }

  /**
   * Ativa modo de contingência quando o recálculo falha
   * @private
   */
  _activateFailsafeMode() {
    // Define status especial para o sistema
    this.routeStatus = 'FAILSAFE_ACTIVE';
    
    // Prepara ações disponíveis para o usuário
    const safetyOptions = {
      showConfusionZone: true,
      availableActions: [
        {
          id: 'goto_safe_point',
          label: translationsService.translate('routes.failsafe.goToSafePoint'),
          action: () => this._navigateToSafePoint()
        },
        {
          id: 'return_to_intersection',
          label: translationsService.translate('routes.failsafe.returnToIntersection'),
          action: () => this._returnToLastSafeIntersection()
        },
        {
          id: 'show_rest_areas',
          label: translationsService.translate('routes.failsafe.showRestAreas'),
          action: () => this._showNearbyRestAreas()
        }
      ]
    };
    
    // Notifica a interface do usuário sobre o modo de contingência
    this._notifyFailsafeMode(safetyOptions);
  }

  /**
   * Notifica a UI sobre o modo de contingência
   * @private
   * @param {Object} options - Opções do modo de contingência
   */
  _notifyFailsafeMode(options) {
    // Esta função notificaria a interface para mostrar controles de emergência
    // Em uma implementação real, usaria um sistema de eventos ou callbacks
    console.warn('MODO DE CONTINGÊNCIA ATIVADO:', options);
    
    // Emite evento para a UI (mock)
    if (typeof window !== 'undefined' && window.dispatchEvent) {
      window.dispatchEvent(new CustomEvent('kingroad:failsafe_mode', {
        detail: options
      }));
    }
  }

  /**
   * Navega até o ponto seguro mais próximo
   * @private
   */
  async _navigateToSafePoint() {
    // Implementação de navegação para o ponto seguro mais próximo
    // Poderia ser um posto de combustível, área de descanso, etc.
    const currentPosition = await this._getCurrentPosition();
    const safePoints = await this._fetchNearbySafePoints(currentPosition);
    
    if (safePoints.length > 0) {
      const nearestPoint = this._findNearestPoint(currentPosition, safePoints);
      return this._calculateEmergencyRoute(currentPosition, { points: [nearestPoint] }, 50);
    }
    
    return null;
  }

  /**
   * Retorna para a última interseção segura
   * @private
   */
  async _returnToLastSafeIntersection() {
    // Busca a última interseção segura que o veículo passou
    const currentPosition = await this._getCurrentPosition();
    const lastIntersection = this._findLastSafeIntersection();
    
    if (lastIntersection) {
      return this._calculateEmergencyRoute(currentPosition, { points: [lastIntersection] }, 50);
    }
    
    return null;
  }

  /**
   * Mostra áreas de descanso próximas
   * @private
   */
  async _showNearbyRestAreas() {
    // Busca áreas de descanso nas proximidades
    const currentPosition = await this._getCurrentPosition();
    const restAreas = await this._fetchNearbyRestAreas(currentPosition);
    
    // Notifica a UI para mostrar estas áreas no mapa
    this._showPOIsOnMap(restAreas);
    
    return restAreas;
  }

  /**
   * Busca pontos seguros próximos
   * @private
   * @param {Object} position - Posição atual
   * @returns {Promise<Array>} - Lista de pontos seguros
   */
  async _fetchNearbySafePoints(position) {
    // Implementação mock - buscaria de uma API ou dados offline
    return [
      { lat: position.lat + 0.01, lng: position.lng + 0.01, type: 'rest_area' },
      { lat: position.lat - 0.01, lng: position.lng - 0.005, type: 'fuel_station' },
      { lat: position.lat + 0.005, lng: position.lng - 0.02, type: 'truck_parking' }
    ];
  }

  /**
   * Busca áreas de descanso próximas
   * @private
   * @param {Object} position - Posição atual
   * @returns {Promise<Array>} - Lista de áreas de descanso
   */
  async _fetchNearbyRestAreas(position) {
    // Implementação mock - buscaria de uma API ou dados offline
    return [
      { 
        lat: position.lat + 0.02, 
        lng: position.lng + 0.01, 
        type: 'rest_area',
        name: 'Área de Descanso Norte',
        amenities: ['banheiros', 'restaurante', 'estacionamento para caminhões']
      },
      { 
        lat: position.lat - 0.015, 
        lng: position.lng - 0.01, 
        type: 'rest_area',
        name: 'Área de Descanso Sul',
        amenities: ['banheiros', 'loja de conveniência']
      }
    ];
  }

  /**
   * Encontra a última interseção segura
   * @private
   * @returns {Object|null} - Última interseção segura
   */
  _findLastSafeIntersection() {
    // Implementação simplificada - buscaria no histórico de navegação
    if (!this.originalRoute || !this.deviationPoint) {
      return null;
    }
    
    // Encontra a última interseção antes do ponto de desvio
    const intersections = this.originalRoute.points.filter(point => point.isIntersection);
    
    for (let i = intersections.length - 1; i >= 0; i--) {
      if (this._isPointBeforeDeviation(intersections[i])) {
        return intersections[i];
      }
    }
    
    return null;
  }

  /**
   * Verifica se um ponto está antes do ponto de desvio
   * @private
   * @param {Object} point - Ponto a verificar
   * @returns {boolean} - Indica se está antes do desvio
   */
  _isPointBeforeDeviation(point) {
    if (!this.deviationPoint || !this.originalRoute) {
      return false;
    }
    
    const routePoints = this.originalRoute.points;
    const pointIndex = routePoints.findIndex(p => this._arePointsEqual(p, point));
    
    if (pointIndex === -1) {
      return false;
    }
    
    // Encontra o índice do ponto mais próximo ao desvio
    let deviationIndex = -1;
    let minDistance = Infinity;
    
    routePoints.forEach((p, idx) => {
      const dist = this._calculateDistance(p, this.deviationPoint);
      if (dist < minDistance) {
        minDistance = dist;
        deviationIndex = idx;
      }
    });
    
    return pointIndex < deviationIndex;
  }

  /**
   * Mostra POIs no mapa
   * @private
   * @param {Array} pois - Pontos de interesse
   */
  _showPOIsOnMap(pois) {
    // Esta função notificaria a interface para mostrar os POIs
    // Em uma implementação real, usaria um sistema de eventos ou callbacks
    console.log('Mostrando POIs no mapa:', pois);
    
    // Emite evento para a UI (mock)
    if (typeof window !== 'undefined' && window.dispatchEvent) {
      window.dispatchEvent(new CustomEvent('kingroad:show_pois', {
        detail: { pois }
      }));
    }
  }

  /**
   * Encontra o ponto mais próximo
   * @private
   * @param {Object} position - Posição de referência
   * @param {Array} points - Lista de pontos
   * @returns {Object} - Ponto mais próximo
   */
  _findNearestPoint(position, points) {
    let nearestPoint = null;
    let minDistance = Infinity;
    
    for (const point of points) {
      const distance = this._calculateDistance(position, point);
      if (distance < minDistance) {
        minDistance = distance;
        nearestPoint = point;
      }
    }
    
    return nearestPoint;
  }

  /**
   * Obtém a posição atual do veículo
   * @private
   * @returns {Promise<Object>} - Posição atual
   */
  async _getCurrentPosition() {
    // Em uma implementação real, usaria GPS ou outras fontes
    // Implementação mock para exemplo
    return new Promise((resolve) => {
      if (this.deviationPoint) {
        resolve(this.deviationPoint);
      } else if (this.currentRoute && this.currentRoute.points.length > 0) {
        resolve(this.currentRoute.points[0]);
      } else {
        // Posição padrão fictícia
        resolve({ lat: 40.7128, lng: -74.0060 });
      }
    });
  }

  /**
   * Inicia atualizações periódicas de dados de tráfego
   * @private
   */
  _startTrafficUpdates() {
    // Limpa timer anterior se existir
    if (this.trafficTimer) {
      clearInterval(this.trafficTimer);
    }
    
    // Define novo timer para atualizar dados de tráfego
    this.trafficTimer = setInterval(async () => {
      if (this.routeStatus === 'ACTIVE' || this.routeStatus === 'RECALIBRATED') {
        await this._updateTrafficData();
      }
    }, this.TRAFFIC_UPDATE_INTERVAL);
  }

  /**
   * Pausa atualizações de dados de tráfego
   * @private
   */
  _pauseTrafficUpdates() {
    if (this.trafficTimer) {
      clearInterval(this.trafficTimer);
      this.trafficTimer = null;
    }
  }

  /**
   * Atualiza dados de tráfego para a rota atual
   * @private
   */
  async _updateTrafficData() {
    try {
      // Obtém posição atual
      const currentPosition = await this._getCurrentPosition();
      
      // Calcula parte da rota a ser atualizada (próximos 200km)
      const routeSegment = this._extractRouteSegment(
        this.currentRoute, 
        currentPosition, 
        this.TRAFFIC_SCOPE_DISTANCE
      );
      
      // Busca dados de tráfego atualizados
      const trafficData = await this._fetchTrafficData(routeSegment);
      
      // Atualiza rota com novos dados de tráfego
      this._applyTrafficData(trafficData);
    } catch (error) {
      console.error('Erro ao atualizar dados de tráfego:', error);
    }
  }

  /**
   * Extrai um segmento da rota baseado na distância
   * @private
   * @param {Object} route - Rota completa
   * @param {Object} startPoint - Ponto inicial
   * @param {number} distance - Distância em km
   * @returns {Object} - Segmento da rota
   */
  _extractRouteSegment(route, startPoint, distance) {
    if (!route || !route.points || route.points.length === 0) {
      return null;
    }
    
    // Encontra o ponto mais próximo na rota
    let nearestIndex = 0;
    let minDistance = Infinity;
    
    route.points.forEach((point, index) => {
      const d = this._calculateDistance(startPoint, point);
      if (d < minDistance) {
        minDistance = d;
        nearestIndex = index;
      }
    });
    
    // Extrai pontos até a distância especificada
    const segmentPoints = [route.points[nearestIndex]];
    let accumulatedDistance = 0;
    
    for (let i = nearestIndex + 1; i < route.points.length; i++) {
      const d = this._calculateDistance(route.points[i-1], route.points[i]);
      accumulatedDistance += d / 1000; // Converte para km
      
      segmentPoints.push(route.points[i]);
      
      if (accumulatedDistance >= distance) {
        break;
      }
    }
    
    return {
      ...route,
      points: segmentPoints,
      distance: accumulatedDistance * 1000 // Metros
    };
  }

  /**
   * Busca dados de tráfego atualizados
   * @private
   * @param {Object} routeSegment - Segmento da rota
   * @returns {Promise<Object>} - Dados de tráfego
   */
  async _fetchTrafficData(routeSegment) {
    // Implementação mock - buscaria de uma API
    return new Promise(resolve => {
      // Simula um tempo de resposta
      setTimeout(() => {
        // Gera dados fictícios de tráfego
        const trafficData = {
          timestamp: Date.now(),
          congestionPoints: [
            // Gera pontos aleatórios de congestionamento
            ...Array(Math.floor(Math.random() * 3)).fill(0).map((_, i) => {
              // Seleciona um ponto aleatório na rota
              const routeIndex = Math.floor(Math.random() * routeSegment.points.length);
              return {
                position: routeSegment.points[routeIndex],
                severity: Math.floor(Math.random() * 3) + 1, // 1-3, onde 3 é o mais severo
                speedReduction: Math.random() * 0.8 // Redução de 0% a 80% da velocidade
              };
            })
          ],
          averageSpeeds: routeSegment.points.map(point => ({
            position: point,
            speed: 50 + Math.random() * 30 // Velocidade entre 50-80 km/h
          }))
        };
        
        resolve(trafficData);
      }, 500); // Tempo de resposta simulado
    });
  }
  
  /**
   * Aplica dados de tráfego à rota atual
   * @private
   * @param {Object} trafficData - Dados de tráfego
   */
  _applyTrafficData(trafficData) {
    if (!trafficData || !this.currentRoute) {
      return;
    }
    
    // Cria cópia da rota para aplicar alterações
    const updatedRoute = { ...this.currentRoute };
    let durationChanged = false;
    
    // Aplica dados de velocidade média
    if (trafficData.averageSpeeds && trafficData.averageSpeeds.length > 0) {
      // Cria mapa de velocidades por ponto
      const speedMap = new Map();
      
      trafficData.averageSpeeds.forEach(item => {
        const key = `${item.position.lat},${item.position.lng}`;
        speedMap.set(key, item.speed);
      });
      
      // Atualiza durações dos segmentos com base nas novas velocidades
      let totalDuration = 0;
      for (let i = 1; i < updatedRoute.points.length; i++) {
        const point1 = updatedRoute.points[i-1];
        const point2 = updatedRoute.points[i];
        
        // Calcula distância do segmento
        const distance = this._calculateDistance(point1, point2) / 1000; // km
        
        // Verifica se há dados de velocidade para os pontos
        const key1 = `${point1.lat},${point1.lng}`;
        const key2 = `${point2.lat},${point2.lng}`;
        
        // Usa média das velocidades disponíveis ou valor padrão
        let speed = 60; // km/h padrão
        let speedCount = 0;
        
        if (speedMap.has(key1)) {
          speed = speedMap.get(key1);
          speedCount++;
        }
        
        if (speedMap.has(key2)) {
          if (speedCount > 0) {
            speed = (speed + speedMap.get(key2)) / 2;
          } else {
            speed = speedMap.get(key2);
          }
        }
        
        // Calcula duração do segmento
        const segmentDuration = (distance / speed) * 3600; // segundos
        
        // Atualiza informação do ponto
        if (!updatedRoute.points[i].metadata) {
          updatedRoute.points[i].metadata = {};
        }
        
        updatedRoute.points[i].metadata.speedKmh = speed;
        updatedRoute.points[i].metadata.durationFromPrev = segmentDuration;
        
        totalDuration += segmentDuration;
      }
      
      // Atualiza duração total da rota
      if (updatedRoute.duration !== totalDuration) {
        updatedRoute.duration = totalDuration;
        durationChanged = true;
      }
    }
    
    // Aplica dados de congestionamento
    if (trafficData.congestionPoints && trafficData.congestionPoints.length > 0) {
      trafficData.congestionPoints.forEach(congestion => {
        // Encontra ponto mais próximo na rota
        const nearestPoint = this._findNearestPointInRoute(congestion.position, updatedRoute);
        
        if (nearestPoint) {
          // Adiciona informação de congestionamento ao ponto
          if (!nearestPoint.metadata) {
            nearestPoint.metadata = {};
          }
          
          nearestPoint.metadata.congestion = {
            severity: congestion.severity,
            speedReduction: congestion.speedReduction
          };
          
          // Atualiza UI para mostrar congestionamento
          this._notifyCongestion(nearestPoint, congestion.severity);
        }
      });
    }
    
    // Atualiza rota atual
    this.currentRoute = updatedRoute;
    
    // Notifica mudanças na duração total se necessário
    if (durationChanged) {
      this._notifyDurationChange(updatedRoute.duration);
    }
  }

  /**
   * Encontra o ponto mais próximo na rota
   * @private
   * @param {Object} position - Posição de referência
   * @param {Object} route - Rota para buscar
   * @returns {Object|null} - Ponto mais próximo ou null
   */
  _findNearestPointInRoute(position, route) {
    if (!route || !route.points || route.points.length === 0) {
      return null;
    }
    
    let nearestPoint = null;
    let minDistance = Infinity;
    
    route.points.forEach(point => {
      const distance = this._calculateDistance(position, point);
      if (distance < minDistance) {
        minDistance = distance;
        nearestPoint = point;
      }
    });
    
    return nearestPoint;
  }

  /**
   * Notifica sobre congestionamento
   * @private
   * @param {Object} point - Ponto com congestionamento
   * @param {number} severity - Gravidade do congestionamento
   */
  _notifyCongestion(point, severity) {
    // Em uma implementação real, notificaria a UI
    console.log(`Congestionamento detectado: ${severity} (1-3) em ${point.lat},${point.lng}`);
    
    // Emite evento para a UI (mock)
    if (typeof window !== 'undefined' && window.dispatchEvent) {
      window.dispatchEvent(new CustomEvent('kingroad:congestion', {
        detail: { point, severity }
      }));
    }
  }

  /**
   * Notifica sobre mudança na duração da rota
   * @private
   * @param {number} newDuration - Nova duração em segundos
   */
  _notifyDurationChange(newDuration) {
    // Em uma implementação real, notificaria a UI
    const minutes = Math.round(newDuration / 60);
    console.log(`Duração da rota atualizada: ${minutes} minutos`);
    
    // Emite evento para a UI (mock)
    if (typeof window !== 'undefined' && window.dispatchEvent) {
      window.dispatchEvent(new CustomEvent('kingroad:duration_change', {
        detail: { durationSeconds: newDuration }
      }));
    }
  }

  /**
   * Calcula rota completa com serviço de rotas
   * @private
   * @param {Object} origin - Ponto de origem
   * @param {Object} destination - Ponto de destino
   * @returns {Promise<Object>} - Rota calculada
   */
  async _calculateFullRoute(origin, destination) {
    // Opções para o cálculo da rota
    const options = {
      origin,
      destination,
      useTrafficData: true,
      vehicleType: this.vehicleProfile.type,
      preferences: this.vehicleProfile.preferences
    };
    
    // Chama serviço de rotas (mock)
    return this._callRoutingService(options);
  }

  /**
   * Chama o serviço de cálculo de rotas
   * @private
   * @param {Object} options - Opções para cálculo
   * @returns {Promise<Object>} - Rota calculada
   */
  async _callRoutingService(options) {
    // Implementação mock - em um sistema real, chamaria uma API
    return new Promise(resolve => {
      // Simula tempo de resposta
      setTimeout(() => {
        // Gera rota fictícia
        const numPoints = Math.floor(Math.random() * 50) + 50; // 50-100 pontos
        const points = [];
        
        // Cria pontos intermediários em linha reta com pequenas variações
        const latStep = (options.destination.lat - options.origin.lat) / numPoints;
        const lngStep = (options.destination.lng - options.origin.lng) / numPoints;
        
        // Adiciona ponto de origem
        points.push(options.origin);
        
        // Adiciona pontos intermediários
        for (let i = 1; i < numPoints; i++) {
          const randomLat = (Math.random() - 0.5) * 0.001; // Variação aleatória
          const randomLng = (Math.random() - 0.5) * 0.001;
          
          points.push({
            lat: options.origin.lat + (latStep * i) + randomLat,
            lng: options.origin.lng + (lngStep * i) + randomLng,
            // Adiciona metadados aos pontos
            isIntersection: Math.random() > 0.8, // 20% de chance de ser interseção
            isRestArea: Math.random() > 0.95, // 5% de chance de ser área de descanso
            isNarrowRoad: Math.random() > 0.7 // 30% de chance de ser estrada estreita
          });
        }
        
        // Adiciona ponto de destino
        points.push(options.destination);
        
        // Calcula distância e duração
        let totalDistance = 0;
        for (let i = 1; i < points.length; i++) {
          totalDistance += this._calculateDistance(points[i-1], points[i]);
        }
        
        // Estima duração com base na distância (60 km/h em média)
        const averageSpeed = options.vehicleType === 'truck' ? 60 : 80; // km/h
        const durationHours = (totalDistance / 1000) / averageSpeed;
        const durationSeconds = durationHours * 3600;
        
        // Cria objeto de rota
        const route = {
          origin: options.origin,
          destination: options.destination,
          points,
          distance: totalDistance, // metros
          duration: durationSeconds, // segundos
          vehicleType: options.vehicleType,
          useTrafficData: options.useTrafficData,
          timestamp: Date.now()
        };
        
        resolve(route);
      }, options.useTrafficData ? 1500 : 500); // Simula que o cálculo com tráfego é mais lento
    });
  }

  /**
   * Encerra a rota atual
   */
  endRoute() {
    // Limpa dados da rota
    this.currentRoute = null;
    this.originalRoute = null;
    this.deviationPoint = null;
    this.routeStatus = 'INACTIVE';
    
    // Para atualizações de tráfego
    this._pauseTrafficUpdates();
    
    return true;
  }

  /**
   * Obtém status atual da rota
   * @returns {Object} - Informações sobre a rota atual
   */
  getRouteStatus() {
    if (!this.currentRoute) {
      return {
        active: false,
        status: this.routeStatus
      };
    }
    
    return {
      active: this.routeStatus !== 'INACTIVE',
      status: this.routeStatus,
      origin: this.currentRoute.origin,
      destination: this.currentRoute.destination,
      distance: this.currentRoute.distance,
      duration: this.currentRoute.duration,
      isDeviated: this.routeStatus === 'DEVIATED',
      deviationPoint: this.deviationPoint,
      vehicleType: this.vehicleProfile.type
    };
  }

  /**
   * Define o perfil do veículo
   * @param {Object} profile - Perfil do veículo
   */
  setVehicleProfile(profile) {
    this.vehicleProfile = { ...profile };
    return true;
  }

  /**
   * Obtém o perfil do veículo atual
   * @returns {Object} - Perfil do veículo
   */
  getVehicleProfile() {
    return { ...this.vehicleProfile };
  }
}

// Exporta o sistema como um singleton
const intelligentRerouteSystem = new IntelligentRerouteSystem();
export default intelligentRerouteSystem;