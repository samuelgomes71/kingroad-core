import React, { useEffect, useState } from 'react';

const AutoDownloadPage = () => {
  const [status, setStatus] = useState('initializing'); // 'initializing', 'detecting', 'downloading', 'complete', 'error'
  const [progress, setProgress] = useState(0);
  const [deviceInfo, setDeviceInfo] = useState(null);
  const [countdown, setCountdown] = useState(5);
  
  // Detecta o tamanho do dispositivo
  const detectDeviceSize = () => {
    const width = window.innerWidth;
    
    if (width < 600) return 'xs'; // ~6 polegadas
    if (width < 900) return 'sm'; // ~7-8 polegadas
    if (width < 1200) return 'md'; // ~9-10 polegadas
    return 'lg'; // ~11-12 polegadas
  };
  
  // Retorna informações sobre o dispositivo
  const getDeviceInfo = () => {
    const size = detectDeviceSize();
    const deviceSizeText = {
      'xs': 'smartphone compacto',
      'sm': 'smartphone grande',
      'md': 'tablet médio',
      'lg': 'tablet grande'
    };
    
    return {
      size,
      sizeText: deviceSizeText[size],
      isAndroid: /Android/i.test(navigator.userAgent),
      isIOS: /iPhone|iPad|iPod/i.test(navigator.userAgent),
      downloadSize: size === 'xs' ? '30 MB' : 
                    size === 'sm' ? '33 MB' : 
                    size === 'md' ? '37 MB' : '40 MB'
    };
  };
  
  // Simula o download automático do aplicativo
  const startAutomaticDownload = () => {
    if (!deviceInfo) return;
    
    setStatus('downloading');
    
    // URL para o download automático (seria a URL real da versão para o dispositivo)
    const downloadUrl = `https://download.kingroad.app/kingroad-${deviceInfo.size}-latest.apk`;
    
    // Para demonstração, simulamos o progresso do download
    const downloadInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(downloadInterval);
          setStatus('complete');
          return 100;
        }
        return prev + 5;
      });
    }, 300);
    
    // Em um ambiente real, você usaria algo como:
    // window.location.href = downloadUrl;
    
    // Para Android, podemos iniciar o download direto (em produção)
    // if (deviceInfo.isAndroid) {
    //   window.location.href = downloadUrl;
    // }
    
    // Para iOS, redirecionar para a App Store
    // if (deviceInfo.isIOS) {
    //   window.location.href = 'https://apps.apple.com/app/kingroad';
    // }
  };
  
  // Efeito para detecção do dispositivo
  useEffect(() => {
    // Define o status inicial
    setStatus('detecting');
    
    // Detecta o dispositivo
    const info = getDeviceInfo();
    setDeviceInfo(info);
    
    // Agora podemos iniciar a contagem regressiva
    const countdownTimer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countdownTimer);
          startAutomaticDownload();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(countdownTimer);
  }, []);
  
  // Enquanto estamos inicializando, mostrar um loader simples
  if (status === 'initializing' || !deviceInfo) {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500"></div>
        <p className="text-yellow-500 mt-4">Preparando...</p>
      </div>
    );
  }
  
  // Tela de detecção e download
  if (status === 'detecting' || status === 'downloading') {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
        {/* Logo do KingRoad */}
        <img 
          src={`/assets/logos/kingroad-logo-${deviceInfo.size}.png`} 
          alt="KingRoad Logo" 
          className="w-32 h-32 object-contain mb-8"
        />
        
        <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full border border-gray-700">
          <h1 className="text-2xl font-bold text-yellow-500 mb-6 text-center">
            KingRoad - Navegação para Caminhoneiros
          </h1>
          
          {status === 'detecting' && (
            <>
              <p className="text-gray-300 text-center mb-4">
                Preparando download automático para o seu dispositivo...
              </p>
              <p className="text-yellow-500 text-center font-bold">
                Download automático em {countdown} segundos
              </p>
            </>
          )}
          
          {status === 'downloading' && (
            <>
              <p className="text-gray-300 text-center mb-4">
                Baixando KingRoad para o seu {deviceInfo.sizeText}
              </p>
              
              {/* Barra de progresso */}
              <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
                <div 
                  className="bg-yellow-600 h-4 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              
              <p className="text-gray-400 text-sm text-center">
                Tamanho total: {deviceInfo.downloadSize} • {progress}% concluído
              </p>
            </>
          )}
          
          {/* Botão para download manual (caso automático falhe) */}
          <button
            onClick={startAutomaticDownload}
            className="mt-6 w-full bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
          >
            {status === 'detecting' ? 'Iniciar download agora' : 'Reiniciar download'}
          </button>
        </div>
        
        <p className="text-gray-500 text-sm mt-8 text-center max-w-md">
          O KingRoad foi otimizado para o seu dispositivo. Não é necessário selecionar nenhuma opção, 
          o download mais adequado começará automaticamente.
        </p>
      </div>
    );
  }
  
  // Tela de download concluído
  if (status === 'complete') {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
        <img 
          src={`/assets/logos/kingroad-logo-${deviceInfo.size}.png`} 
          alt="KingRoad Logo" 
          className="w-32 h-32 object-contain mb-8"
        />
        
        <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full border border-gray-700">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-green-900 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          
          <h2 className="text-xl font-bold text-yellow-500 mb-4 text-center">
            Download Concluído!
          </h2>
          
          <p className="text-gray-300 text-center mb-6">
            {deviceInfo.isAndroid ? (
              "Abra o arquivo baixado para instalar o KingRoad"
            ) : (
              "A instalação começará automaticamente em instantes"
            )}
          </p>
          
          {deviceInfo.isAndroid && (
            <div className="bg-gray-900 p-4 rounded-lg mb-6">
              <p className="text-yellow-500 font-medium mb-2">Instruções simples:</p>
              <ol className="text-gray-300 text-sm space-y-2 list-decimal pl-5">
                <li>Toque no arquivo baixado na barra de notificações</li>
                <li>Se solicitado, permita a instalação de fontes desconhecidas</li>
                <li>Toque em "Instalar" e aguarde a conclusão</li>
                <li>Pronto! Abra o KingRoad e comece a usar</li>
              </ol>
            </div>
          )}
          
          <button className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-md transition-colors">
            {deviceInfo.isAndroid ? "Verificar instalação" : "Continuar para instalação"}
          </button>
        </div>
        
        <p className="text-gray-500 text-sm mt-8 text-center max-w-md">
          Precisa de ajuda? Entre em contato pelo WhatsApp clicando <a href="https://wa.me/5511999999999" className="text-yellow-500 underline">aqui</a>
        </p>
      </div>
    );
  }
  
  // Tela de erro (caso algo dê errado)
  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
      <img 
        src={`/assets/logos/kingroad-logo-${deviceInfo?.size || 'md'}.png`}
        alt="KingRoad Logo" 
        className="w-32 h-32 object-contain mb-8"
      />
      
      <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full border border-gray-700">
        <div className="flex items-center justify-center mb-6">
          <div className="w-16 h-16 rounded-full bg-red-900 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
        </div>
        
        <h2 className="text-xl font-bold text-yellow-500 mb-4 text-center">
          Houve um problema
        </h2>
        
        <p className="text-gray-300 text-center mb-6">
          Não foi possível completar o download automático. Tente novamente ou use uma das opções abaixo:
        </p>
        
        <div className="space-y-3">
          <button onClick={startAutomaticDownload} className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-3 px-4 rounded-md transition-colors">
            Tentar novamente
          </button>
          
          <a href={`https://download.kingroad.app/kingroad-${deviceInfo.size}-latest.apk`} className="block w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-md transition-colors text-center">
            Download manual
          </a>
        </div>
      </div>
      
      <p className="text-gray-500 text-sm mt-8 text-center max-w-md">
        Precisa de ajuda? Entre em contato pelo WhatsApp clicando <a href="https://wa.me/5511999999999" className="text-yellow-500 underline">aqui</a>
      </p>
    </div>
  );
};

export default AutoDownloadPage;