// LatestDestinations.jsx
import React, { useState, useEffect } from 'react';

/**
 * Componente que exibe lista de destinos recentes do usuário
 * ID do componente: 8502 (seguindo o sistema de IDs numéricos)
 */
const LatestDestinations = () => {
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Carregar destinos ao montar o componente
  useEffect(() => {
    loadRecentDestinations();
  }, []);

  // Função para carregar destinos recentes
  const loadRecentDestinations = async () => {
    setLoading(true);
    setError(null);

    try {
      // Chamar a API nativa para obter destinos recentes (últimos 15 dias)
      if (window.KingRoadNative && window.KingRoadNative.tripManager) {
        const result = await window.KingRoadNative.tripManager.getRecentTrips();
        // Garantir que a lista está ordenada do mais recente para o mais antigo
        const sortedDestinations = result.sort((a, b) => b.startDate - a.startDate);
        setDestinations(sortedDestinations || []);
      } else {
        // Mock para desenvolvimento
        const mockDestinations = [
          {
            id: 1,
            name: 'Viagem para São Paulo',
            startAddress: 'Rio de Janeiro, RJ',
            endAddress: 'São Paulo, SP',
            startDate: Date.now() - 86400000 * 2, // 2 dias atrás
            distanceKm: 429.7,
            isCompleted: true
          },
          {
            id: 2,
            name: 'Entrega em Campinas',
            startAddress: 'São Paulo, SP',
            endAddress: 'Campinas, SP',
            startDate: Date.now() - 86400000, // 1 dia atrás
            distanceKm: 99.2,
            isCompleted: true
          }
        ];
        // Ordernar por data (mais recente primeiro)
        const sortedMockDestinations = mockDestinations.sort((a, b) => b.startDate - a.startDate);
        setDestinations(sortedMockDestinations);
      }
    } catch (err) {
      console.error('Erro ao carregar destinos recentes:', err);
      setError('Não foi possível carregar os destinos recentes');
    } finally {
      setLoading(false);
    }
  };

  // Iniciar nova viagem com destino selecionado
  const startTrip = (destination) => {
    console.log('Iniciando viagem para:', destination);
    
    if (window.KingRoadNative && window.KingRoadNative.navigation) {
      window.KingRoadNative.navigation.startNavigation({
        destinationLat: destination.endLat,
        destinationLng: destination.endLng,
        destinationName: destination.endAddress,
        tripId: destination.id
      });
    }
  };

  // Formatar data
  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit'
    });
  };

  // Renderizar carregamento
  if (loading) {
    return (
      <div className="px-4 py-6 bg-black" id="latest-destinations-8502">
        <h2 className="text-xl font-bold text-white mb-4">Últimos Destinos</h2>
        <div className="flex justify-center">
          <div className="w-6 h-6 border-2 border-gold border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  // Renderizar erro
  if (error) {
    return (
      <div className="px-4 py-6 bg-black" id="latest-destinations-8502">
        <h2 className="text-xl font-bold text-white mb-4">Últimos Destinos</h2>
        <div className="bg-red-900 text-white p-3 rounded">
          {error}
        </div>
      </div>
    );
  }

  // Renderizar lista de destinos
  return (
    <div className="px-4 py-6 bg-black" id="latest-destinations-8502">
      <h2 className="text-xl font-bold text-white mb-4">Últimos Destinos</h2>
      
      {destinations.length === 0 ? (
        <div className="bg-gray-900 p-4 rounded text-gray-400 text-center">
          Nenhum destino recente encontrado
        </div>
      ) : (
        <div className="space-y-3">
          {destinations.map(destination => (
            <div 
              key={destination.id}
              className="bg-gray-900 rounded-lg p-3 border border-gray-800 hover:border-gold transition-colors"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-gold">{destination.name || destination.endAddress}</h3>
                  <p className="text-sm text-gray-400">{formatDate(destination.startDate)}</p>
                  <div className="mt-2">
                    <p className="text-xs text-gray-300">De: {destination.startAddress}</p>
                    <p className="text-xs text-gray-300">Para: {destination.endAddress}</p>
                  </div>
                  {destination.distanceKm && (
                    <p className="text-xs text-gray-400 mt-1">
                      {destination.distanceKm.toFixed(1)} km 
                      {destination.estimatedDurationMinutes && ` • ${Math.floor(destination.estimatedDurationMinutes / 60)}h ${destination.estimatedDurationMinutes % 60}min`}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => startTrip(destination)}
                  className="bg-gold hover:bg-yellow-600 text-black px-3 py-1 rounded text-sm font-medium transition-colors"
                >
                  Iniciar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <button 
        onClick={loadRecentDestinations}
        className="mt-4 w-full border border-gray-700 hover:border-gold text-white py-2 rounded-lg transition-colors flex items-center justify-center"
      >
        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
        </svg>
        Atualizar
      </button>
    </div>
  );
};

export default LatestDestinations;