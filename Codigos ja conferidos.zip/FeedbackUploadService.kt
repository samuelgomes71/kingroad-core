package com.kingroad.cache

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.AttachmentDao
import com.kingroad.database.AttachmentEntity
import com.kingroad.database.Feedback
import com.kingroad.database.FeedbackDao
import com.kingroad.network.ApiClient
import com.kingroad.network.ApiResult
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Envia os dados de feedback preenchidos pelo motorista, 
 * incluindo texto, imagem e localização, para a nuvem.
 */
class FeedbackUploadService(
    private val context: Context,
    private val apiClient: ApiClient,
    private val feedbackDao: FeedbackDao,
    private val attachmentDao: AttachmentDao,
    private val offlineAttachmentStore: OfflineAttachmentStore? = null,
    private val localSyncQueue: LocalSyncQueue? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "FeedbackUploadService"
        
        // Limite de tentativas de envio
        private const val MAX_RETRY_ATTEMPTS = 3
        
        // Prioridade para enfileiramento
        private const val FEEDBACK_PRIORITY = 5
        private const val ATTACHMENT_PRIORITY = 3
    }

    // Status atual de upload
    private val _uploadStatus = MutableStateFlow<UploadStatus>(UploadStatus.Idle)
    val uploadStatus: StateFlow<UploadStatus> = _uploadStatus.asStateFlow()
    
    // Estatísticas de upload
    private val _uploadStats = MutableLiveData(UploadStats())
    val uploadStats: LiveData<UploadStats> = _uploadStats
    
    // Map para controlar uploads em andamento
    private val activeUploads = ConcurrentHashMap<String, Job>()
    
    // Flag para controlar se o serviço está em processo de parada
    private val isStopping = AtomicBoolean(false)

    init {
        // Tenta enviar feedbacks pendentes no startup se houver conexão
        if (NetworkUtils.isConnected(context)) {
            scope.launch {
                processUnsentFeedbacks()
            }
        }
    }

    /**
     * Cria um novo feedback e tenta enviá-lo imediatamente
     *
     * @param content Conteúdo textual do feedback
     * @param type Tipo de feedback (sugestão, problema, elogio, etc)
     * @param rating Avaliação numérica opcional (0-5)
     * @param latitude Latitude onde o feedback foi criado
     * @param longitude Longitude onde o feedback foi criado
     * @param referenceId ID opcional de referência (POI, alerta, etc)
     * @param referenceType Tipo de referência associada
     * @param attachmentUris Lista de URIs de anexos (imagens, áudio, etc)
     * @param metadata Metadados adicionais em formato JSON
     * @return ID do feedback criado
     */
    suspend fun submitFeedback(
        content: String,
        type: String,
        rating: Int? = null,
        latitude: Double,
        longitude: Double,
        referenceId: String? = null,
        referenceType: String? = null,
        attachmentUris: List<Uri> = emptyList(),
        metadata: JSONObject? = null
    ): String = withContext(dispatcher) {
        // Gera ID único para o feedback
        val feedbackId = UUID.randomUUID().toString()
        
        try {
            // Cria feedback no banco local
            val feedback = Feedback(
                id = feedbackId,
                content = content,
                type = type,
                rating = rating,
                latitude = latitude,
                longitude = longitude,
                createdAt = System.currentTimeMillis(),
                createdBy = getUserId(),
                referenceId = referenceId,
                referenceType = referenceType,
                metadata = metadata?.toString(),
                synced = false,
                syncAttempts = 0,
                queuedForSync = false
            )
            
            // Salva feedback no banco
            feedbackDao.insert(feedback)
            
            // Processa anexos
            val attachmentIds = processAttachments(feedbackId, attachmentUris)
            
            // Tenta enviar imediatamente se houver conexão
            if (NetworkUtils.isConnected(context)) {
                startFeedbackUpload(feedbackId)
            } else if (localSyncQueue != null) {
                // Enfileira para envio posterior se não há conexão
                enqueueFeedbackForLaterSync(feedback)
            }
            
            return@withContext feedbackId
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar feedback: ${e.message}", e)
            throw e
        }
    }
    
    /**
     * Processa anexos do feedback, salvando-os localmente
     */
    private suspend fun processAttachments(
        feedbackId: String,
        attachmentUris: List<Uri>
    ): List<String> = withContext(dispatcher) {
        
        if (offlineAttachmentStore == null || attachmentUris.isEmpty()) {
            return@withContext emptyList()
        }
        
        val attachmentIds = mutableListOf<String>()
        
        for (uri in attachmentUris) {
            try {
                // Salva o anexo usando o OfflineAttachmentStore
                val category = detectAttachmentCategory(uri)
                val attachmentId = offlineAttachmentStore.storeFromUri(
                    sourceUri = uri,
                    category = category,
                    referenceId = feedbackId,
                    referenceType = "feedback",
                    description = "Anexo de feedback"
                )
                
                attachmentIds.add(attachmentId)
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao processar anexo para feedback $feedbackId: ${e.message}", e)
            }
        }
        
        return@withContext attachmentIds
    }
    
    /**
     * Detecta a categoria adequada para o anexo baseado no tipo do arquivo
     */
    private fun detectAttachmentCategory(uri: Uri): OfflineAttachmentStore.Companion.AttachmentCategory {
        val mimeType = context.contentResolver.getType(uri) ?: return OfflineAttachmentStore.Companion.AttachmentCategory.OTHER
        
        return when {
            mimeType.startsWith("image/") -> OfflineAttachmentStore.Companion.AttachmentCategory.IMAGE
            mimeType.startsWith("audio/") -> OfflineAttachmentStore.Companion.AttachmentCategory.VOICE
            mimeType.startsWith("application/") || mimeType.startsWith("text/") -> 
                OfflineAttachmentStore.Companion.AttachmentCategory.DOCUMENT
            else -> OfflineAttachmentStore.Companion.AttachmentCategory.OTHER
        }
    }
    
    /**
     * Inicia o upload de um feedback específico
     */
    fun startFeedbackUpload(feedbackId: String): Job {
        // Cancela upload anterior se existir
        activeUploads[feedbackId]?.cancel()
        
        val job = scope.launch {
            try {
                _uploadStatus.value = UploadStatus.Uploading(feedbackId)
                
                // Obtém feedback do banco
                val feedback = feedbackDao.getById(feedbackId)
                if (feedback == null) {
                    _uploadStatus.value = UploadStatus.Error(feedbackId, "Feedback não encontrado")
                    return@launch
                }
                
                // Se o feedback já foi sincronizado, ignora
                if (feedback.synced) {
                    _uploadStatus.value = UploadStatus.Success(feedbackId)
                    return@launch
                }
                
                // Verifica conexão
                if (!NetworkUtils.isConnected(context)) {
                    if (localSyncQueue != null) {
                        enqueueFeedbackForLaterSync(feedback)
                    }
                    _uploadStatus.value = UploadStatus.Offline(feedbackId)
                    return@launch
                }
                
                // Prepara os dados do feedback
                val feedbackData = prepareFeedbackData(feedback)
                
                // Obtém anexos associados
                val attachments = if (offlineAttachmentStore != null) {
                    attachmentDao.getByReference(feedback.id, "feedback")
                } else {
                    emptyList()
                }
                
                // Primeiro tenta enviar os anexos
                val uploadedAttachments = uploadAttachments(attachments)
                
                // Adiciona as URLs dos anexos enviados ao feedback
                if (uploadedAttachments.isNotEmpty()) {
                    val attachmentsArray = feedbackData.optJSONArray("attachments") ?: JSONObject().put("attachments", ArrayList<String>()).getJSONArray("attachments")
                    
                    uploadedAttachments.forEach { (id, url) ->
                        attachmentsArray.put(url)
                    }
                    
                    feedbackData.put("attachments", attachmentsArray)
                }
                
                // Envia o feedback
                val result = apiClient.submitFeedback(feedbackData)
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        // Atualiza o feedback no banco
                        val updatedFeedback = feedback.copy(
                            synced = true,
                            syncTimestamp = System.currentTimeMillis(),
                            serverRef = result.data.optString("id", feedback.id)
                        )
                        feedbackDao.update(updatedFeedback)
                        
                        // Atualiza estatísticas
                        updateUploadStats(true)
                        
                        // Atualiza status
                        _uploadStatus.value = UploadStatus.Success(feedbackId)
                    }
                    is ApiResult.Error -> {
                        // Incrementa tentativas
                        val updatedFeedback = feedback.copy(
                            syncAttempts = feedback.syncAttempts + 1,
                            lastSyncAttempt = System.currentTimeMillis()
                        )
                        feedbackDao.update(updatedFeedback)
                        
                        // Tenta enfileirar se ultrapassou o limite de tentativas
                        if (updatedFeedback.syncAttempts >= MAX_RETRY_ATTEMPTS && localSyncQueue != null) {
                            enqueueFeedbackForLaterSync(updatedFeedback)
                        }
                        
                        // Atualiza estatísticas
                        updateUploadStats(false)
                        
                        // Atualiza status
                        _uploadStatus.value = UploadStatus.Error(feedbackId, result.message)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao fazer upload de feedback $feedbackId: ${e.message}", e)
                _uploadStatus.value = UploadStatus.Error(feedbackId, e.message ?: "Erro desconhecido")
                updateUploadStats(false)
            } finally {
                activeUploads.remove(feedbackId)
            }
        }
        
        activeUploads[feedbackId] = job
        return job
    }
    
    /**
     * Faz upload dos anexos associados a um feedback
     * @return Mapa de ID local para URL remota dos anexos enviados com sucesso
     */
    private suspend fun uploadAttachments(
        attachments: List<AttachmentEntity>
    ): Map<String, String> = withContext(dispatcher) {
        val successfulUploads = mutableMapOf<String, String>()
        
        for (attachment in attachments) {
            // Pula anexos já enviados
            if (attachment.status == OfflineAttachmentStore.Companion.AttachmentStatus.UPLOADED.name &&
                !attachment.remoteUrl.isNullOrEmpty()) {
                successfulUploads[attachment.id] = attachment.remoteUrl
                continue
            }
            
            try {
                // Atualiza status para UPLOADING
                if (offlineAttachmentStore != null) {
                    offlineAttachmentStore.updateAttachmentStatus(
                        attachment.id,
                        OfflineAttachmentStore.Companion.AttachmentStatus.UPLOADING
                    )
                }
                
                // Obtém arquivo do anexo
                val file = File(attachment.localPath)
                if (!file.exists()) {
                    Log.e(TAG, "Arquivo de anexo não encontrado: ${attachment.localPath}")
                    continue
                }
                
                // Faz upload do arquivo
                val result = apiClient.uploadFile(
                    file = file,
                    fileName = attachment.fileName,
                    mimeType = attachment.mimeType,
                    metadata = JSONObject().apply {
                        put("referenceId", attachment.referenceId)
                        put("referenceType", attachment.referenceType)
                        put("category", attachment.category)
                    }
                )
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        val remoteUrl = result.data.optString("url", "")
                        
                        // Atualiza status do anexo
                        if (offlineAttachmentStore != null && remoteUrl.isNotEmpty()) {
                            offlineAttachmentStore.updateAttachmentStatus(
                                attachment.id,
                                OfflineAttachmentStore.Companion.AttachmentStatus.UPLOADED,
                                remoteUrl
                            )
                            
                            // Adiciona ao mapa de uploads bem-sucedidos
                            successfulUploads[attachment.id] = remoteUrl
                        }
                    }
                    is ApiResult.Error -> {
                        // Atualiza status para FAILED
                        if (offlineAttachmentStore != null) {
                            offlineAttachmentStore.updateAttachmentStatus(
                                attachment.id,
                                OfflineAttachmentStore.Companion.AttachmentStatus.FAILED
                            )
                        }
                        
                        Log.e(TAG, "Erro ao fazer upload de anexo: ${result.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exceção ao fazer upload de anexo: ${e.message}", e)
                
                // Atualiza status para FAILED em caso de erro
                if (offlineAttachmentStore != null) {
                    offlineAttachmentStore.updateAttachmentStatus(
                        attachment.id,
                        OfflineAttachmentStore.Companion.AttachmentStatus.FAILED
                    )
                }
            }
        }
        
        return@withContext successfulUploads
    }
    
    /**
     * Prepara os dados do feedback no formato esperado pela API
     */
    private fun prepareFeedbackData(feedback: Feedback): JSONObject {
        return JSONObject().apply {
            put("id", feedback.id)
            put("content", feedback.content)
            put("type", feedback.type)
            if (feedback.rating != null) {
                put("rating", feedback.rating)
            }
            put("latitude", feedback.latitude)
            put("longitude", feedback.longitude)
            put("createdAt", feedback.createdAt)
            put("createdBy", feedback.createdBy ?: "")
            
            if (!feedback.referenceId.isNullOrEmpty()) {
                put("referenceId", feedback.referenceId)
            }
            
            if (!feedback.referenceType.isNullOrEmpty()) {
                put("referenceType", feedback.referenceType)
            }
            
            // Adiciona metadados se existirem
            if (!feedback.metadata.isNullOrEmpty()) {
                try {
                    put("metadata", JSONObject(feedback.metadata))
                } catch (e: Exception) {
                    put("metadata", JSONObject())
                }
            } else {
                put("metadata", JSONObject())
            }
            
            // Inicializa array de anexos vazio
            put("attachments", ArrayList<String>())
        }
    }
    
    /**
     * Enfileira um feedback para sincronização posterior
     */
    private suspend fun enqueueFeedbackForLaterSync(feedback: Feedback) {
        if (localSyncQueue == null) return
        
        try {
            // Prepara dados para enfileiramento
            val feedbackData = prepareFeedbackData(feedback)
            
            // Enfileira
            localSyncQueue.enqueueItem(
                type = LocalSyncQueue.TYPE_FEEDBACK,
                data = feedbackData,
                priority = FEEDBACK_PRIORITY
            )
            
            // Atualiza status do feedback
            val updatedFeedback = feedback.copy(
                queuedForSync = true,
                syncAttempts = 0 // Reset attempts count
            )
            feedbackDao.update(updatedFeedback)
            
            Log.d(TAG, "Feedback ${feedback.id} enfileirado para sincronização posterior")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao enfileirar feedback para sincronização: ${e.message}", e)
        }
    }
    
    /**
     * Processa todos os feedbacks não enviados
     */
    suspend fun processUnsentFeedbacks(): Int = withContext(dispatcher) {
        val unsent = feedbackDao.getUnsyncedFeedbacks()
        Log.d(TAG, "Processando ${unsent.size} feedbacks não enviados")
        
        var successCount = 0
        
        for (feedback in unsent) {
            // Pula feedbacks já em fila para sincronização
            if (feedback.queuedForSync) continue
            
            // Verifica conexão
            if (!NetworkUtils.isConnected(context)) {
                // Enfileira todos os pendentes se não há conexão
                if (localSyncQueue != null) {
                    for (unsyncedFeedback in unsent) {
                        if (!unsyncedFeedback.queuedForSync) {
                            enqueueFeedbackForLaterSync(unsyncedFeedback)
                        }
                    }
                }
                break
            }
            
            try {
                // Faz upload do feedback
                _uploadStatus.value = UploadStatus.Uploading(feedback.id)
                
                // Prepara os dados
                val feedbackData = prepareFeedbackData(feedback)
                
                // Obtém anexos associados
                val attachments = if (offlineAttachmentStore != null) {
                    attachmentDao.getByReference(feedback.id, "feedback")
                } else {
                    emptyList()
                }
                
                // Upload dos anexos
                val uploadedAttachments = uploadAttachments(attachments)
                
                // Adiciona URLs dos anexos
                if (uploadedAttachments.isNotEmpty()) {
                    val attachmentsArray = feedbackData.optJSONArray("attachments") ?: JSONObject().put("attachments", ArrayList<String>()).getJSONArray("attachments")
                    
                    uploadedAttachments.forEach { (id, url) ->
                        attachmentsArray.put(url)
                    }
                    
                    feedbackData.put("attachments", attachmentsArray)
                }
                
                // Envia o feedback
                val result = apiClient.submitFeedback(feedbackData)
                
                // Processa resultado
                when (result) {
                    is ApiResult.Success -> {
                        // Atualiza o feedback no banco
                        val updatedFeedback = feedback.copy(
                            synced = true,
                            syncTimestamp = System.currentTimeMillis(),
                            serverRef = result.data.optString("id", feedback.id)
                        )
                        feedbackDao.update(updatedFeedback)
                        
                        // Atualiza estatísticas
                        updateUploadStats(true)
                        
                        successCount++
                        
                        // Atualiza status
                        _uploadStatus.value = UploadStatus.Success(feedback.id)
                    }
                    is ApiResult.Error -> {
                        // Incrementa tentativas
                        val updatedFeedback = feedback.copy(
                            syncAttempts = feedback.syncAttempts + 1,
                            lastSyncAttempt = System.currentTimeMillis()
                        )
                        feedbackDao.update(updatedFeedback)
                        
                        // Tenta enfileirar se ultrapassou o limite de tentativas
                        if (updatedFeedback.syncAttempts >= MAX_RETRY_ATTEMPTS && localSyncQueue != null) {
                            enqueueFeedbackForLaterSync(updatedFeedback)
                        }
                        
                        // Atualiza estatísticas
                        updateUploadStats(false)
                        
                        // Atualiza status
                        _uploadStatus.value = UploadStatus.Error(feedback.id, result.message)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao processar feedback não enviado ${feedback.id}: ${e.message}", e)
                _uploadStatus.value = UploadStatus.Error(feedback.id, e.message ?: "Erro desconhecido")
                updateUploadStats(false)
            }
            
            // Verifica se o serviço está sendo parado
            if (isStopping.get()) {
                Log.d(TAG, "Parada solicitada, interrompendo processamento de feedbacks")
                break
            }
        }
        
        _uploadStatus.value = UploadStatus.Idle
        return@withContext successCount
    }
    
    /**
     * Atualiza estatísticas de upload
     */
    private fun updateUploadStats(success: Boolean) {
        val currentStats = _uploadStats.value ?: UploadStats()
        
        val updatedStats = if (success) {
            currentStats.copy(
                success = currentStats.success + 1,
                lastSuccessTime = System.currentTimeMillis()
            )
        } else {
            currentStats.copy(
                failures = currentStats.failures + 1,
                lastFailureTime = System.currentTimeMillis()
            )
        }
        
        _uploadStats.postValue(updatedStats.copy(
            total = updatedStats.success + updatedStats.failures,
            lastAttemptTime = System.currentTimeMillis()
        ))
    }
    
    /**
     * Cancela todos os uploads em andamento
     */
    fun cancelAllUploads() {
        activeUploads.forEach { (_, job) -> job.cancel() }
        activeUploads.clear()
        _uploadStatus.value = UploadStatus.Idle
    }
    
    /**
     * Cancela um upload específico
     */
    fun cancelUpload(feedbackId: String): Boolean {
        val job = activeUploads[feedbackId] ?: return false
        job.cancel()
        activeUploads.remove(feedbackId)
        
        if (_uploadStatus.value is UploadStatus.Uploading && 
            (_uploadStatus.value as UploadStatus.Uploading).feedbackId == feedbackId) {
            _uploadStatus.value = UploadStatus.Cancelled(feedbackId)
        }
        
        return true
    }
    
    /**
     * Para o serviço, cancelando todas as operações em andamento
     */
    fun shutdown() {
        isStopping.set(true)
        cancelAllUploads()
        scope.cancel()
    }
    
    /**
     * Obtém o ID do usuário logado
     * Em um aplicativo real, isso viria de um sistema de autenticação
     */
    private fun getUserId(): String {
        // Implementação simulada - em um app real, isso viria do sistema de autenticação
        return "current_user"
    }
    
    /**
     * Classes para representar o estado de upload
     */
    sealed class UploadStatus {
        object Idle : UploadStatus()
        
        data class Uploading(val feedbackId: String) : UploadStatus()
        
        data class Success(val feedbackId: String) : UploadStatus()
        
        data class Error(val feedbackId: String, val errorMessage: String) : UploadStatus()
        
        data class Offline(val feedbackId: String) : UploadStatus()
        
        data class Cancelled(val feedbackId: String) : UploadStatus()
    }
    
    /**
     * Classe para estatísticas de upload
     */
    data class UploadStats(
        val total: Int = 0,
        val success: Int = 0,
        val failures: Int = 0,
        val lastAttemptTime: Long = 0,
        val lastSuccessTime: Long = 0,
        val lastFailureTime: Long = 0
    )
}