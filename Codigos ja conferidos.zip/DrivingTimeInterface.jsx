import React, { useState } from 'react';
import { Clock, MapPin, AlertTriangle, Check, Truck, Info } from 'lucide-react';

const DrivingTimeInterface = () => {
  const [selectedStop, setSelectedStop] = useState(null);
  
  return (
    <div className="h-screen bg-[#121212] text-gray-200">
      {/* Barra superior com tempo restante */}
      <div className="bg-[#1E1E1E] p-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">Tempo de Direção</h1>
            <div className="flex items-center mt-1 text-yellow-400">
              <Clock size={16} className="mr-1" />
              <span>2:45h restantes</span>
            </div>
          </div>
          <div className="bg-[#252525] px-3 py-1 rounded text-sm">
            Margem: 15min
          </div>
        </div>
      </div>

      {/* Alerta de alcance */}
      <div className="p-4 bg-[#252525]">
        <div className="flex items-start space-x-3">
          <AlertTriangle size={24} className="text-yellow-400 flex-shrink-0" />
          <div>
            <h2 className="font-medium">Alcance Máximo</h2>
            <p className="text-sm text-gray-400 mt-1">
              Com tempo efetivo de 2:30h, você pode alcançar os seguintes pontos com segurança:
            </p>
          </div>
        </div>
      </div>

      {/* Lista de pontos alcançáveis */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {/* Parada Recomendada */}
          <div className="bg-[#1A4B81] p-4 rounded-lg">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="flex items-center">
                  <Check size={16} className="text-green-400 mr-2" />
                  <span className="font-medium">Parada Recomendada</span>
                </div>
                <h3 className="text-lg font-bold mt-1">Flying J Truck Stop</h3>
                <p className="text-sm text-blue-200">2:15h para chegar</p>
              </div>
              <div className="bg-blue-600 px-3 py-1 rounded text-sm">
                15 vagas
              </div>
            </div>
            <div className="flex space-x-2 text-sm">
              <span className="bg-[#252525] px-2 py-1 rounded">Restaurante</span>
              <span className="bg-[#252525] px-2 py-1 rounded">Chuveiros</span>
              <span className="bg-[#252525] px-2 py-1 rounded">Segurança 24h</span>
            </div>
          </div>

          {/* Alternativas */}
          <h3 className="text-sm font-medium text-gray-400 mb-2">Alternativas Disponíveis</h3>
          
          {/* Parada Alternativa */}
          <div className="bg-[#1E1E1E] p-4 rounded-lg">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-medium">Área de Descanso I-95</h3>
                <p className="text-sm text-gray-400">1:45h para chegar</p>
              </div>
              <div className="bg-[#252525] px-3 py-1 rounded text-sm">
                8 vagas
              </div>
            </div>
            <div className="flex space-x-2 text-sm">
              <span className="bg-[#252525] px-2 py-1 rounded">Banheiros</span>
              <span className="bg-[#252525] px-2 py-1 rounded">Iluminação</span>
            </div>
          </div>

          {/* Parada de Emergência */}
          <div className="bg-[#1E1E1E] p-4 rounded-lg">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-medium">Posto de Combustível Shell</h3>
                <p className="text-sm text-gray-400">1:30h para chegar</p>
              </div>
              <div className="bg-[#252525] px-2 py-1 rounded text-sm text-yellow-400">
                2 vagas
              </div>
            </div>
            <div className="flex space-x-2 text-sm">
              <span className="bg-[#252525] px-2 py-1 rounded">Combustível</span>
              <span className="bg-[#252525] px-2 py-1 rounded">Loja</span>
            </div>
          </div>
        </div>
      </div>

      {/* Barra de alertas */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#1E1E1E]">
        <div className="flex items-center justify-between bg-[#252525] p-3 rounded-lg">
          <div className="flex items-center">
            <Info size={20} className="text-yellow-400 mr-2" />
            <span className="text-sm">
              Considere parar antes se encontrar congestionamento
            </span>
          </div>
          <button className="bg-blue-600 px-4 py-2 rounded-lg text-sm">
            Ver no Mapa
          </button>
        </div>
      </div>
    </div>
  );
};

export default DrivingTimeInterface;