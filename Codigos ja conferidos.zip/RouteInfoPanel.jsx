import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faRoad, faClock, faTachometerAlt } from '@fortawesome/free-solid-svg-icons';

/**
 * RouteInfoPanel - Painel com informações de rota para o KingRoad
 */
const RouteInfoPanel = ({
  eta,
  distance,
  currentSpeed,
  currentRoadName,
  isDarkMode
}) => {
  return (
    <View style={[styles.panel, isDarkMode && styles.panelDark]}>
      <View style={styles.infoItem}>
        <FontAwesomeIcon icon={faClock} size={16} color={isDarkMode ? '#FFF' : '#000'} />
        <Text style={[styles.text, isDarkMode && styles.textDark]}>{eta || '--:--'}</Text>
      </View>

      <View style={styles.infoItem}>
        <FontAwesomeIcon icon={faRoad} size={16} color={isDarkMode ? '#FFF' : '#000'} />
        <Text style={[styles.text, isDarkMode && styles.textDark]}>{distance || '-- km'}</Text>
      </View>

      <View style={styles.infoItem}>
        <FontAwesomeIcon icon={faTachometerAlt} size={16} color={isDarkMode ? '#FFF' : '#000'} />
        <Text style={[styles.text, isDarkMode && styles.textDark]}>{currentSpeed ? `${currentSpeed} km/h` : '-- km/h'}</Text>
      </View>

      <Text style={[styles.roadName, isDarkMode && styles.roadNameDark]} numberOfLines={1}>
        {currentRoadName || '---'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  panel: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    elevation: 6
  },
  panelDark: {
    backgroundColor: 'rgba(0, 0, 0, 0.85)'
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16
  },
  text: {
    marginLeft: 6,
    fontSize: 14,
    color: '#000'
  },
  textDark: {
    color: '#FFF'
  },
  roadName: {
    width: '100%',
    textAlign: 'center',
    marginTop: 6,
    fontSize: 12,
    color: '#555'
  },
  roadNameDark: {
    color: '#DDD'
  }
});

export default RouteInfoPanel;
