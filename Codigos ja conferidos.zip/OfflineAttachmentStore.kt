package com.kingroad.cache

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.kingroad.database.AttachmentDao
import com.kingroad.database.AttachmentEntity
import com.kingroad.utils.FileUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import java.io.*
import java.security.MessageDigest
import java.util.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Armazena imagens, documentos ou fotos tiradas durante o uso offline
 * para posterior upload.
 */
class OfflineAttachmentStore(
    private val context: Context,
    private val attachmentDao: AttachmentDao,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher)
) {
    companion object {
        private const val TAG = "OfflineAttachmentStore"
        private const val ATTACHMENTS_DIR = "attachments"
        
        // Categorias de anexos
        enum class AttachmentCategory(val directory: String) {
            IMAGE("images"),
            DOCUMENT("documents"),
            VOICE("voice"),
            OTHER("misc")
        }
        
        // Status de anexos
        enum class AttachmentStatus {
            PENDING, // Aguardando upload
            UPLOADING, // Em processo de upload
            UPLOADED, // Enviado com sucesso
            FAILED, // Falha no upload
            ORPHANED // Sem referência, candidato a limpeza
        }
        
        // Formatos de arquivo
        private val IMAGE_EXTENSIONS = arrayOf("jpg", "jpeg", "png", "gif", "webp")
        private val DOCUMENT_EXTENSIONS = arrayOf("pdf", "doc", "docx", "xls", "xlsx", "txt")
        private val VOICE_EXTENSIONS = arrayOf("mp3", "wav", "m4a", "aac", "ogg")
        
        // Configurações
        private const val MAX_ATTACHMENTS_SIZE_BYTES = 500 * 1024 * 1024L // 500 MB
        private const val DEFAULT_IMAGE_QUALITY = 85
        private const val MAX_IMAGE_WIDTH = 2048
    }

    // Diretório principal para armazenamento de anexos
    private val attachmentsDir: File by lazy {
        File(context.filesDir, ATTACHMENTS_DIR).apply {
            if (!exists()) mkdirs()
            
            // Cria subdiretórios para cada categoria
            AttachmentCategory.values().forEach { category ->
                File(this, category.directory).mkdir()
            }
        }
    }
    
    // Cache em memória de uploads em andamento
    private val activeUploads = ConcurrentHashMap<String, Job>()

    init {
        // Inicialização: verificar integridade do armazenamento
        scope.launch {
            try {
                validateStorageIntegrity()
                checkStorageSize()
            } catch (e: Exception) {
                Log.e(TAG, "Erro durante inicialização: ${e.message}", e)
            }
        }
    }

    /**
     * Salva um anexo a partir de uma Uri do content provider
     * 
     * @param sourceUri URI do arquivo de origem (content:// ou file://)
     * @param category Categoria do anexo
     * @param referenceId ID de referência (POI, alerta, etc.)
     * @param referenceType Tipo de referência ("poi", "alert", etc.)
     * @param description Descrição opcional do anexo
     * @param processImage Se true e for uma imagem, redimensiona e comprime
     * @return ID único do anexo
     */
    suspend fun storeFromUri(
        sourceUri: Uri,
        category: AttachmentCategory,
        referenceId: String,
        referenceType: String,
        description: String = "",
        processImage: Boolean = true
    ): String = withContext(dispatcher) {
        val inputStream = context.contentResolver.openInputStream(sourceUri)
            ?: throw IOException("Não foi possível abrir o arquivo: $sourceUri")
        
        val fileName = getFileNameFromUri(sourceUri)
        val mimeType = getMimeTypeFromUri(sourceUri)
        
        // Gera um ID único
        val attachmentId = UUID.randomUUID().toString()
        
        // Determina a extensão do arquivo
        val extension = fileName.substringAfterLast('.', "bin")
        
        // Verifica categoria com base na extensão
        val effectiveCategory = if (category == AttachmentCategory.OTHER) {
            detectCategoryFromExtension(extension)
        } else {
            category
        }
        
        // Cria o arquivo de destino
        val outputFile = createAttachmentFile(attachmentId, effectiveCategory, extension)
        
        try {
            // Se for uma imagem e processImage for true, redimensiona e comprime
            if (processImage && isImageExtension(extension)) {
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()
                
                if (bitmap != null) {
                    // Redimensiona se necessário
                    val resizedBitmap = resizeImageIfNeeded(bitmap)
                    
                    // Salva com compressão
                    FileOutputStream(outputFile).use { outputStream ->
                        val format = if (extension.equals("png", ignoreCase = true)) {
                            Bitmap.CompressFormat.PNG
                        } else {
                            Bitmap.CompressFormat.JPEG
                        }
                        
                        resizedBitmap.compress(format, DEFAULT_IMAGE_QUALITY, outputStream)
                        outputStream.flush()
                    }
                    
                    // Limpa bitmaps
                    if (resizedBitmap != bitmap) {
                        resizedBitmap.recycle()
                    }
                    bitmap.recycle()
                } else {
                    // Falhou ao decodificar imagem, copia diretamente
                    context.contentResolver.openInputStream(sourceUri)?.use { reopenStream ->
                        copyStreamToFile(reopenStream, outputFile)
                    }
                }
            } else {
                // Para outros tipos, copia diretamente
                copyStreamToFile(inputStream, outputFile)
            }
            
            // Cria a entidade para salvar no banco
            val attachmentEntity = AttachmentEntity(
                id = attachmentId,
                fileName = fileName,
                localPath = outputFile.absolutePath,
                category = effectiveCategory.name,
                mimeType = mimeType,
                size = outputFile.length(),
                referenceId = referenceId,
                referenceType = referenceType,
                description = description,
                createdAt = System.currentTimeMillis(),
                status = AttachmentStatus.PENDING.name,
                remoteUrl = "",
                uploadAttempts = 0
            )
            
            // Salva no banco de dados
            attachmentDao.insert(attachmentEntity)
            
            return@withContext attachmentId
            
        } catch (e: Exception) {
            // Em caso de erro, apaga o arquivo parcial
            if (outputFile.exists()) {
                outputFile.delete()
            }
            throw e
        }
    }
    
    /**
     * Salva um anexo a partir de um array de bytes
     * 
     * @param data Array de bytes com o conteúdo do arquivo
     * @param fileName Nome do arquivo
     * @param mimeType Tipo MIME do arquivo
     * @param category Categoria do anexo
     * @param referenceId ID de referência (POI, alerta, etc.)
     * @param referenceType Tipo de referência ("poi", "alert", etc.)
     * @param description Descrição opcional do anexo
     * @return ID único do anexo
     */
    suspend fun storeFromBytes(
        data: ByteArray,
        fileName: String,
        mimeType: String,
        category: AttachmentCategory,
        referenceId: String,
        referenceType: String,
        description: String = ""
    ): String = withContext(dispatcher) {
        // Gera um ID único
        val attachmentId = UUID.randomUUID().toString()
        
        // Determina a extensão do arquivo
        val extension = fileName.substringAfterLast('.', "bin")
        
        // Verifica categoria com base na extensão
        val effectiveCategory = if (category == AttachmentCategory.OTHER) {
            detectCategoryFromExtension(extension)
        } else {
            category
        }
        
        // Cria o arquivo de destino
        val outputFile = createAttachmentFile(attachmentId, effectiveCategory, extension)
        
        try {
            // Escreve os dados no arquivo
            FileOutputStream(outputFile).use { outputStream ->
                outputStream.write(data)
                outputStream.flush()
            }
            
            // Cria a entidade para salvar no banco
            val attachmentEntity = AttachmentEntity(
                id = attachmentId,
                fileName = fileName,
                localPath = outputFile.absolutePath,
                category = effectiveCategory.name,
                mimeType = mimeType,
                size = outputFile.length(),
                referenceId = referenceId,
                referenceType = referenceType,
                description = description,
                createdAt = System.currentTimeMillis(),
                status = AttachmentStatus.PENDING.name,
                remoteUrl = "",
                uploadAttempts = 0
            )
            
            // Salva no banco de dados
            attachmentDao.insert(attachmentEntity)
            
            return@withContext attachmentId
            
        } catch (e: Exception) {
            // Em caso de erro, apaga o arquivo parcial
            if (outputFile.exists()) {
                outputFile.delete()
            }
            throw e
        }
    }
    
    /**
     * Salva um anexo a partir de um Bitmap (imagem)
     * 
     * @param bitmap Bitmap da imagem
     * @param fileName Nome do arquivo
     * @param category Categoria do anexo
     * @param referenceId ID de referência (POI, alerta, etc.)
     * @param referenceType Tipo de referência ("poi", "alert", etc.)
     * @param description Descrição opcional do anexo
     * @param format Formato de compressão
     * @param quality Qualidade de compressão (0-100)
     * @return ID único do anexo
     */
    suspend fun storeFromBitmap(
        bitmap: Bitmap,
        fileName: String,
        category: AttachmentCategory = AttachmentCategory.IMAGE,
        referenceId: String,
        referenceType: String,
        description: String = "",
        format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG,
        quality: Int = DEFAULT_IMAGE_QUALITY
    ): String = withContext(dispatcher) {
        // Gera um ID único
        val attachmentId = UUID.randomUUID().toString()
        
        // Determina a extensão do arquivo
        val extension = when (format) {
            Bitmap.CompressFormat.JPEG -> "jpg"
            Bitmap.CompressFormat.PNG -> "png"
            Bitmap.CompressFormat.WEBP -> "webp"
            else -> "jpg"
        }
        
        // Cria o arquivo de destino
        val outputFile = createAttachmentFile(attachmentId, category, extension)
        
        try {
            // Redimensiona se necessário
            val resizedBitmap = resizeImageIfNeeded(bitmap)
            
            // Salva com compressão
            FileOutputStream(outputFile).use { outputStream ->
                resizedBitmap.compress(format, quality, outputStream)
                outputStream.flush()
            }
            
            // Limpa bitmap se for diferente
            if (resizedBitmap != bitmap) {
                resizedBitmap.recycle()
            }
            
            // Determina o MIME type
            val mimeType = when (format) {
                Bitmap.CompressFormat.JPEG -> "image/jpeg"
                Bitmap.CompressFormat.PNG -> "image/png"
                Bitmap.CompressFormat.WEBP -> "image/webp"
                else -> "image/jpeg"
            }
            
            // Cria a entidade para salvar no banco
            val attachmentEntity = AttachmentEntity(
                id = attachmentId,
                fileName = fileName,
                localPath = outputFile.absolutePath,
                category = category.name,
                mimeType = mimeType,
                size = outputFile.length(),
                referenceId = referenceId,
                referenceType = referenceType,
                description = description,
                createdAt = System.currentTimeMillis(),
                status = AttachmentStatus.PENDING.name,
                remoteUrl = "",
                uploadAttempts = 0
            )
            
            // Salva no banco de dados
            attachmentDao.insert(attachmentEntity)
            
            return@withContext attachmentId
            
        } catch (e: Exception) {
            // Em caso de erro, apaga o arquivo parcial
            if (outputFile.exists()) {
                outputFile.delete()
            }
            throw e
        }
    }
    
    /**
     * Obtém um anexo por ID
     * 
     * @param attachmentId ID do anexo
     * @return Entidade do anexo ou null se não existir
     */
    suspend fun getAttachment(attachmentId: String): AttachmentEntity? {
        return attachmentDao.getById(attachmentId)
    }
    
    /**
     * Obtém todos os anexos associados a uma referência
     * 
     * @param referenceId ID de referência
     * @param referenceType Tipo de referência
     * @return Lista de entidades de anexo
     */
    suspend fun getAttachmentsForReference(
        referenceId: String,
        referenceType: String
    ): List<AttachmentEntity> {
        return attachmentDao.getByReference(referenceId, referenceType)
    }
    
    /**
     * Obtém todos os anexos por status como um Flow
     * 
     * @param status Status desejado
     * @return Flow de lista de entidades de anexo
     */
    fun getAttachmentsByStatusFlow(status: AttachmentStatus): Flow<List<AttachmentEntity>> {
        return attachmentDao.getByStatusFlow(status.name)
    }
    
    /**
     * Obtém todos os anexos pendentes
     * 
     * @return Lista de entidades de anexo com status PENDING
     */
    suspend fun getPendingAttachments(): List<AttachmentEntity> {
        return attachmentDao.getByStatus(AttachmentStatus.PENDING.name)
    }
    
    /**
     * Atualiza o status de um anexo
     * 
     * @param attachmentId ID do anexo
     * @param status Novo status
     * @param remoteUrl URL remota após upload (opcional)
     */
    suspend fun updateAttachmentStatus(
        attachmentId: String,
        status: AttachmentStatus,
        remoteUrl: String = ""
    ) {
        val attachment = attachmentDao.getById(attachmentId) ?: return
        
        val updated = attachment.copy(
            status = status.name,
            remoteUrl = if (remoteUrl.isNotEmpty()) remoteUrl else attachment.remoteUrl,
            updatedAt = System.currentTimeMillis()
        )
        
        attachmentDao.update(updated)
    }
    
    /**
     * Marca um anexo como órfão (sem referência)
     * 
     * @param attachmentId ID do anexo
     */
    suspend fun markAsOrphaned(attachmentId: String) {
        updateAttachmentStatus(attachmentId, AttachmentStatus.ORPHANED)
    }
    
    /**
     * Exclui um anexo por ID
     * 
     * @param attachmentId ID do anexo
     * @return true se excluído com sucesso
     */
    suspend fun deleteAttachment(attachmentId: String): Boolean = withContext(dispatcher) {
        val attachment = attachmentDao.getById(attachmentId) ?: return@withContext false
        
        // Cancela upload se estiver em andamento
        activeUploads[attachmentId]?.cancel()
        activeUploads.remove(attachmentId)
        
        // Remove do banco de dados
        attachmentDao.delete(attachment)
        
        // Remove o arquivo
        val file = File(attachment.localPath)
        if (file.exists()) {
            file.delete()
        }
        
        return@withContext true
    }
    
    /**
     * Exclui todos os anexos associados a uma referência
     * 
     * @param referenceId ID de referência
     * @param referenceType Tipo de referência
     * @return Número de anexos excluídos
     */
    suspend fun deleteAttachmentsForReference(
        referenceId: String,
        referenceType: String
    ): Int = withContext(dispatcher) {
        val attachments = attachmentDao.getByReference(referenceId, referenceType)
        
        var deletedCount = 0
        for (attachment in attachments) {
            // Cancela upload se estiver em andamento
            activeUploads[attachment.id]?.cancel()
            activeUploads.remove(attachment.id)
            
            // Remove do banco de dados
            attachmentDao.delete(attachment)
            
            // Remove o arquivo
            val file = File(attachment.localPath)
            if (file.exists() && file.delete()) {
                deletedCount++
            }
        }
        
        return@withContext deletedCount
    }
    
    /**
     * Limpa anexos órfãos ou expirados
     * 
     * @param olderThanDays Limpa anexos órfãos mais antigos que este número de dias
     * @return Número de anexos excluídos
     */
    suspend fun cleanupOrphanedAttachments(olderThanDays: Int = 7): Int = withContext(dispatcher) {
        val cutoffTime = System.currentTimeMillis() - (olderThanDays * 24 * 60 * 60 * 1000L)
        val orphanedAttachments = attachmentDao.getOrphanedAttachmentsOlderThan(
            AttachmentStatus.ORPHANED.name,
            cutoffTime
        )
        
        var deletedCount = 0
        for (attachment in orphanedAttachments) {
            // Remove do banco de dados
            attachmentDao.delete(attachment)
            
            // Remove o arquivo
            val file = File(attachment.localPath)
            if (file.exists() && file.delete()) {
                deletedCount++
            }
        }
        
        return@withContext deletedCount
    }
    
    /**
     * Verifica se um anexo existe
     * 
     * @param attachmentId ID do anexo
     * @return true se o anexo existir
     */
    suspend fun attachmentExists(attachmentId: String): Boolean {
        val attachment = attachmentDao.getById(attachmentId) ?: return false
        val file = File(attachment.localPath)
        return file.exists()
    }
    
    /**
     * Obtém o arquivo de um anexo
     * 
     * @param attachmentId ID do anexo
     * @return Arquivo do anexo ou null se não existir
     */
    suspend fun getAttachmentFile(attachmentId: String): File? = withContext(dispatcher) {
        val attachment = attachmentDao.getById(attachmentId) ?: return@withContext null
        val file = File(attachment.localPath)
        if (!file.exists()) return@withContext null
        return@withContext file
    }
    
    /**
     * Redefine o status de upload de todos os anexos em status UPLOADING
     * Útil para recuperação após falha da aplicação
     */
    suspend fun resetUploadingStatus() = withContext(dispatcher) {
        val uploadingAttachments = attachmentDao.getByStatus(AttachmentStatus.UPLOADING.name)
        
        for (attachment in uploadingAttachments) {
            val updatedAttachment = attachment.copy(
                status = AttachmentStatus.PENDING.name,
                updatedAt = System.currentTimeMillis()
            )
            attachmentDao.update(updatedAttachment)
        }
    }
    
    /**
     * Verifica a integridade do armazenamento, removendo registros sem arquivos correspondentes
     */
    private suspend fun validateStorageIntegrity() = withContext(dispatcher) {
        Log.d(TAG, "Verificando integridade do armazenamento de anexos...")
        
        val allAttachments = attachmentDao.getAllAttachments()
        var integrityIssues = 0
        
        for (attachment in allAttachments) {
            val file = File(attachment.localPath)
            if (!file.exists()) {
                Log.w(TAG, "Arquivo não encontrado para anexo: ${attachment.id}, ${attachment.fileName}")
                attachmentDao.delete(attachment)
                integrityIssues++
            } else if (file.length() != attachment.size) {
                Log.w(TAG, "Tamanho de arquivo inconsistente para anexo: ${attachment.id}. " +
                        "Esperado: ${attachment.size}, Atual: ${file.length()}")
                
                // Atualiza o tamanho no banco para refletir a realidade
                val updated = attachment.copy(size = file.length())
                attachmentDao.update(updated)
                integrityIssues++
            }
        }
        
        // Verifica arquivos sem registros correspondentes
        val allDatabasePaths = allAttachments.map { it.localPath }.toSet()
        var orphanedFiles = 0
        
        for (category in AttachmentCategory.values()) {
            val categoryDir = File(attachmentsDir, category.directory)
            if (categoryDir.exists()) {
                categoryDir.listFiles()?.forEach { file ->
                    val path = file.absolutePath
                    if (!allDatabasePaths.contains(path)) {
                        Log.w(TAG, "Arquivo órfão encontrado sem registro no banco: $path")
                        file.delete()
                        orphanedFiles++
                    }
                }
            }
        }
        
        Log.d(TAG, "Verificação de integridade concluída. " +
                "Problemas de integridade: $integrityIssues, Arquivos órfãos removidos: $orphanedFiles")
    }
    
    /**
     * Verifica o tamanho do armazenamento e limpa anexos antigos se necessário
     */
    private suspend fun checkStorageSize() = withContext(dispatcher) {
        val totalSize = getDiskStorageSize()
        
        if (totalSize > MAX_ATTACHMENTS_SIZE_BYTES) {
            Log.w(TAG, "Armazenamento de anexos excedeu o limite. " +
                    "Atual: ${totalSize / (1024 * 1024)} MB, Limite: ${MAX_ATTACHMENTS_SIZE_BYTES / (1024 * 1024)} MB")
            
            // Limpa anexos antigos até atingir 80% do limite
            val targetSize = MAX_ATTACHMENTS_SIZE_BYTES * 0.8
            cleanAttachmentsToSize(targetSize.toLong())
        }
    }
    
    /**
     * Limpa anexos antigos até atingir o tamanho alvo
     */
    private suspend fun cleanAttachmentsToSize(targetSizeBytes: Long) = withContext(dispatcher) {
        // Prioridade de limpeza: ORPHANED > UPLOADED > FAILED > PENDING
        
        // 1. Primeiro limpa anexos órfãos
        cleanupOrphanedAttachments(1) // Limpa órfãos com mais de 1 dia
        
        // Verifica se já atingiu o alvo
        if (getDiskStorageSize() <= targetSizeBytes) return@withContext
        
        // 2. Limpa anexos já enviados, começando pelos mais antigos
        val uploadedAttachments = attachmentDao.getByStatusSortedByDate(AttachmentStatus.UPLOADED.name)
        for (attachment in uploadedAttachments) {
            val file = File(attachment.localPath)
            if (file.exists()) {
                val fileSize = file.length()
                if (file.delete()) {
                    attachmentDao.delete(attachment)
                    if (getDiskStorageSize() <= targetSizeBytes) return@withContext
                }
            } else {
                attachmentDao.delete(attachment)
            }
        }
        
        // 3. Limpa anexos com falha, começando pelos mais antigos
        val failedAttachments = attachmentDao.getByStatusSortedByDate(AttachmentStatus.FAILED.name)
        for (attachment in failedAttachments) {
            val file = File(attachment.localPath)
            if (file.exists()) {
                val fileSize = file.length()
                if (file.delete()) {
                    attachmentDao.delete(attachment)
                    if (getDiskStorageSize() <= targetSizeBytes) return@withContext
                }
            } else {
                attachmentDao.delete(attachment)
            }
        }
        
        // 4. Como último recurso, limpa anexos pendentes antigos
        val pendingAttachments = attachmentDao.getByStatusSortedByDate(AttachmentStatus.PENDING.name)
        
        // Evita remover anexos pendentes recentes (< 7 dias)
        val cutoffTime = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L)
        val oldPendingAttachments = pendingAttachments.filter { it.createdAt < cutoffTime }
        
        for (attachment in oldPendingAttachments) {
            val file = File(attachment.localPath)
            if (file.exists()) {
                val fileSize = file.length()
                if (file.delete()) {
                    attachmentDao.delete(attachment)
                    if (getDiskStorageSize() <= targetSizeBytes) return@withContext
                }
            } else {
                attachmentDao.delete(attachment)
            }
        }
    }
    
    /**
     * Obtém o tamanho total do armazenamento de anexos
     */
    private fun getDiskStorageSize(): Long {
        return FileUtils.getFolderSizeInBytes(attachmentsDir)
    }
    
    /**
     * Cria um arquivo para um anexo
     */
    private fun createAttachmentFile(
        attachmentId: String,
        category: AttachmentCategory,
        extension: String
    ): File {
        val categoryDir = File(attachmentsDir, category.directory)
        if (!categoryDir.exists()) {
            categoryDir.mkdirs()
        }
        
        return File(categoryDir, "$attachmentId.$extension")
    }
    
    /**
     * Redimensiona uma imagem se exceder o tamanho máximo
     */
    private fun resizeImageIfNeeded(bitmap: Bitmap): Bitmap {
        // Se a imagem for menor que o limite, retorna o bitmap original
        if (bitmap.width <= MAX_IMAGE_WIDTH && bitmap.height <= MAX_IMAGE_WIDTH) {
            return bitmap
        }
        
        // Calcula o fator de escala
        val scale = if (bitmap.width > bitmap.height) {
            MAX_IMAGE_WIDTH.toFloat() / bitmap.width
        } else {
            MAX_IMAGE_WIDTH.toFloat() / bitmap.height
        }
        
        // Calcula as novas dimensões
        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()
        
        // Redimensiona o bitmap
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
    
    /**
     * Obtém o nome do arquivo a partir de uma Uri
     */
    private fun getFileNameFromUri(uri: Uri): String {
        val contentResolver = context.contentResolver
        val cursor = contentResolver.query(uri, null, null, null, null)
        
        cursor?.use {
            if (it.moveToFirst()) {
                val displayNameIndex = it.getColumnIndex("_display_name")
                if (displayNameIndex >= 0) {
                    return it.getString(displayNameIndex)
                }
            }
        }
        
        // Fallback para o último segmento da Uri
        val path = uri.path
        if (path != null) {
            val lastSlashIndex = path.lastIndexOf('/')
            if (lastSlashIndex != -1) {
                return path.substring(lastSlashIndex + 1)
            }
        }
        
        // Não conseguiu obter o nome, gera um nome baseado em timestamp
        return "attachment_${System.currentTimeMillis()}"
    }
    
    /**
     * Obtém o MIME type a partir de uma Uri
     */
    private fun getMimeTypeFromUri(uri: Uri): String {
        val contentResolver = context.contentResolver
        return contentResolver.getType(uri) ?: "application/octet-stream"
    }
    
    /**
     * Copia o conteúdo de um InputStream para um arquivo
     */
    private fun copyStreamToFile(inputStream: InputStream, outputFile: File) {
        FileOutputStream(outputFile).use { outputStream ->
            val buffer = ByteArray(4 * 1024) // 4K buffer
            var bytesRead: Int
            
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
            }
            
            outputStream.flush()
        }
    }
    
    /**
     * Detecta a categoria de um anexo com base na extensão
     */
    private fun detectCategoryFromExtension(extension: String): AttachmentCategory {
        val lowerExt = extension.lowercase()
        
        return when {
            IMAGE_EXTENSIONS.any { it == lowerExt } -> AttachmentCategory.IMAGE
            DOCUMENT_EXTENSIONS.any { it == lowerExt } -> AttachmentCategory.DOCUMENT
            VOICE_EXTENSIONS.any { it == lowerExt } -> AttachmentCategory.VOICE
            else -> AttachmentCategory.OTHER
        }
    }
    
    /**
     * Verifica se uma extensão corresponde a uma imagem
     */
    private fun isImageExtension(extension: String): Boolean {
        val lowerExt = extension.lowercase()
        return IMAGE_EXTENSIONS.any { it == lowerExt }
    }

    /**
     * Gera um hash para um arquivo
     */
    suspend fun generateFileHash(file: File): String = withContext(dispatcher) {
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            var bytesRead: Int
            
            FileInputStream(file).use { inputStream ->
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    md.update(buffer, 0, bytesRead)
                }
            }
            
            val hashBytes = md.digest()
            return@withContext hashBytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao gerar hash para arquivo: ${e.message}", e)
            return@withContext ""
        }
    }
    
    /**
     * Libera recursos
     */
    fun shutdown() {
        activeUploads.forEach { (_, job) -> job.cancel() }
        activeUploads.clear()
        scope.cancel()
    }