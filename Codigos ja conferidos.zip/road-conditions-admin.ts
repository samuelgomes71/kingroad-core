// Parte 3: Rotas para resolução, remoção e operações administrativas
import express from 'express';
import { param, body, validationResult } from 'express-validator';
import { authenticate, authorizeAdmin } from '../middleware/auth';
import { RoadConditionRepository } from '../repositories/roadConditionRepository';
import { notifySubscribers } from '../services/notificationService';

const router = express.Router();
const roadConditionRepo = new RoadConditionRepository();

/**
 * @route   PUT /api/road-conditions/:id/resolve
 * @desc    Marcar uma condição como resolvida
 * @access  Private (requer autenticação)
 */
router.put(
  '/:id/resolve',
  authenticate,
  [
    param('id').isMongoId().withMessage('ID de condição inválido'),
    body('comment').optional().isString().isLength({ max: 280 }).withMessage('Comentário muito longo')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { id } = req.params;
      const { comment } = req.body;
      const userId = req.user.id;

      // Verificar se a condição existe
      const condition = await roadConditionRepo.findById(id);
      if (!condition) {
        return res.status(404).json({ message: 'Condição não encontrada' });
      }

      // Marcar como resolvida
      const resolvedCondition = await roadConditionRepo.markAsResolved(id, userId, comment);
      
      // Notificar usuários que reportaram ou confirmaram esta condição
      await notifySubscribers(
        condition.confirmedBy,
        'Condição de estrada resolvida',
        `A condição "${condition.type}" em ${condition.location} foi marcada como resolvida.`
      );

      res.json({
        message: 'Condição marcada como resolvida',
        condition: resolvedCondition
      });
    } catch (error) {
      console.error('Erro ao resolver condição:', error);
      res.status(500).json({ message: 'Erro ao processar resolução' });
    }
  }
);

/**
 * @route   DELETE /api/road-conditions/:id
 * @desc    Remover uma condição de estrada
 * @access  Private (requer autenticação e permissão)
 */
router.delete(
  '/:id',
  authenticate,
  [
    param('id').isMongoId().withMessage('ID de condição inválido')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { id } = req.params;
      const userId = req.user.id;

      // Verificar se a condição existe
      const condition = await roadConditionRepo.findById(id);
      if (!condition) {
        return res.status(404).json({ message: 'Condição não encontrada' });
      }

      // Verificar se o usuário tem permissão (criador ou admin)
      if (condition.userId !== userId && !req.user.isAdmin) {
        return res.status(403).json({ message: 'Sem permissão para remover esta condição' });
      }

      // Remover condição
      await roadConditionRepo.remove(id);

      res.json({ message: 'Condição removida com sucesso' });
    } catch (error) {
      console.error('Erro ao remover condição:', error);
      res.status(500).json({ message: 'Erro ao processar remoção' });
    }
  }
);

/**
 * @route   GET /api/road-conditions/stats
 * @desc    Obter estatísticas sobre condições reportadas
 * @access  Private (admin)
 */
router.get(
  '/stats',
  authenticate,
  authorizeAdmin,
  async (req, res) => {
    try {
      // Estatísticas globais
      const stats = await roadConditionRepo.getStats();
      
      res.json(stats);
    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
      res.status(500).json({ message: 'Erro ao processar estatísticas' });
    }
  }
);

/**
 * @route   POST /api/road-conditions/broadcast-alert
 * @desc    Enviar alerta para usuários em determinada região
 * @access  Private (admin)
 */
router.post(
  '/broadcast-alert',
  authenticate,
  authorizeAdmin,
  [
    body('latitude').isFloat({ min: -90, max: 90 }).withMessage('Latitude inválida'),
    body('longitude').isFloat({ min: -180, max: 180 }).withMessage('Longitude inválida'),
    body('radius').isNumeric({ min: 1, max: 200 }).withMessage('Raio inválido (1-200km)'),
    body('message').isString().isLength({ min: 10, max: 500 }).withMessage('Mensagem inválida'),
    body('title').isString().isLength({ min: 3, max: 100 }).withMessage('Título inválido'),
    body('severity').isIn(['info', 'warning', 'danger']).withMessage('Severidade inválida')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { latitude, longitude, radius, message, title, severity } = req.body;

      // Salvar alerta no banco de dados
      const alert = await roadConditionRepo.createBroadcastAlert({
        latitude,
        longitude,
        radius,
        message,
        title,
        severity,
        createdBy: req.user.id,
        createdAt: new Date()
      });

      // Enviar broadcast
      const recipientCount = await notifyUsersInRadius(
        latitude, 
        longitude, 
        radius, 
        title, 
        message, 
        severity
      );

      res.json({
        message: `Alerta enviado para ${recipientCount} usuários`,
        alert
      });
    } catch (error) {
      console.error('Erro ao enviar broadcast:', error);
      res.status(500).json({ message: 'Erro ao processar broadcast' });
    }
  }
);

export default router;