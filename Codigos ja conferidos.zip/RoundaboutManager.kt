// Gerenciador de Rotatórias
// app/src/main/kotlin/com/kingroad/navigation/roundabout

import android.graphics.Color
import android.location.Location

class RoundaboutManager(
    private val navigationService: NavigationService,
    private val alertService: AlertService,
    private val voiceService: VoiceService
) {
    data class Roundabout(
        val id: String,
        val location: Location,
        val exits: List<RoundaboutExit>,
        val targetExitNumber: Int,
        val radius: Double,
        val warnings: List<Warning>? = null
    )

    data class RoundaboutExit(
        val number: Int,
        val direction: String,
        val roadName: String?,
        val isTarget: Boolean = false
    )

    data class Warning(
        val type: WarningType,
        val message: String
    )

    enum class WarningType {
        TIGHT_TURN,
        LOW_CLEARANCE,
        TRAFFIC_SIGNAL,
        PEDESTRIAN_CROSSING
    }

    // Gerenciar aproximação de rotatória
    suspend fun handleRoundaboutApproach(
        roundabout: Roundabout,
        currentSpeed: Float
    ) {
        when {
            // Alerta inicial a 200m apenas se velocidade >= 60km/h
            isWithinDistance(roundabout.location, INITIAL_ALERT_DISTANCE) && 
            currentSpeed >= MIN_SPEED_FOR_EARLY_ALERT -> {
                showInitialAlert(roundabout)
            }
            // Alerta de preparação a 100m (todas velocidades)
            isWithinDistance(roundabout.location, PREP_ALERT_DISTANCE) -> {
                showPreparationAlert(roundabout)
            }
            // Alerta final a 50m (todas velocidades)
            isWithinDistance(roundabout.location, FINAL_ALERT_DISTANCE) -> {
                showFinalAlert(roundabout)
            }
        }
    }

    // Verificar se está dentro da distância especificada
    private fun isWithinDistance(targetLocation: Location, distance: Double): Boolean {
        val currentLocation = navigationService.getCurrentLocation() ?: return false
        return calculateDistance(currentLocation, targetLocation) <= distance
    }

    // Calcular distância entre dois pontos
    private fun calculateDistance(current: Location, target: Location): Double {
        val results = FloatArray(1)
        Location.distanceBetween(
            current.latitude, current.longitude,
            target.latitude, target.longitude,
            results
        )
        return results[0].toDouble()
    }

    // Mostrar alerta inicial
    private suspend fun showInitialAlert(roundabout: Roundabout) {
        val message = buildString {
            append("Rotatória a 200 metros. ")
            append("Prepare-se para pegar a ${roundabout.targetExitNumber}ª saída ")
            
            // Adicionar direção se disponível
            roundabout.exits.find { it.isTarget }?.let { exit ->
                append("em direção a ${exit.roadName ?: exit.direction}")
            }
        }

        alertService.showAlert(
            message = message,
            type = AlertType.ROUNDABOUT_APPROACH,
            priority = AlertPriority.HIGH
        )
    }

    // Mostrar alerta de preparação
    private suspend fun showPreparationAlert(roundabout: Roundabout) {
        val message = buildString {
            append("Prepare-se. ")
            append("Na rotatória, pegue a ${roundabout.targetExitNumber}ª saída")
        }

        alertService.showAlert(
            message = message,
            type = AlertType.ROUNDABOUT_PREPARATION,
            priority = AlertPriority.HIGH
        )
    }

    // Mostrar alerta final
    private suspend fun showFinalAlert(roundabout: Roundabout) {
        val message = "Pegue a ${roundabout.targetExitNumber}ª saída"

        alertService.showAlert(
            message = message,
            type = AlertType.ROUNDABOUT_FINAL,
            priority = AlertPriority.HIGH
        )
    }

    // Criar ícone dinâmico da rotatória
    fun createRoundaboutIcon(roundabout: Roundabout): Icon {
        return Icon(
            size = IconSize.LARGE,
            background = createRoundaboutCircle(),
            number = createExitNumber(roundabout.targetExitNumber),
            entryArrow = createEntryArrow(),
            exitArrow = createExitArrow(roundabout.targetExitNumber)
        )
    }

    private fun createRoundaboutCircle(): DrawableCircle {
        return DrawableCircle(
            radius = 40.0f,
            strokeWidth = 4.0f,
            fillColor = Color.TRANSPARENT,
            strokeColor = Color.WHITE
        )
    }

    private fun createEntryArrow(): DrawableArrow {
        return DrawableArrow(
            startX = 50.0f,
            startY = 90.0f,
            endX = 50.0f,
            endY = 120.0f,
            strokeWidth = 4.0f,
            color = Color.WHITE
        )
    }

    private fun createExitArrow(exitNumber: Int): DrawableArrow {
        // Posicionar a seta de saída com base no número da saída
        return when (exitNumber) {
            1 -> DrawableArrow( // Esquerda
                startX = 10.0f,
                startY = 50.0f,
                endX = -20.0f,
                endY = 50.0f,
                strokeWidth = 4.0f,
                color = Color.GREEN
            )
            2 -> DrawableArrow( // Em frente
                startX = 50.0f,
                startY = 10.0f,
                endX = 50.0f,
                endY = -20.0f,
                strokeWidth = 4.0f,
                color = Color.GREEN
            )
            else -> DrawableArrow( // Direita (3+)
                startX = 90.0f,
                startY = 50.0f,
                endX = 120.0f,
                endY = 50.0f,
                strokeWidth = 4.0f,
                color = Color.GREEN
            )
        }
    }

    private fun createExitNumber(number: Int): DrawableNumber {
        return DrawableNumber(
            value = number,
            size = 36.0f,
            color = Color.WHITE,
            style = NumberStyle.BOLD
        )
    }

    companion object {
        const val INITIAL_ALERT_DISTANCE = 200.0  // metros
        const val PREP_ALERT_DISTANCE = 100.0     // metros
        const val FINAL_ALERT_DISTANCE = 50.0     // metros
        const val MIN_SPEED_FOR_EARLY_ALERT = 60.0f  // km/h
    }
}

// Classes auxiliares para renderização (implementações simplificadas)
data class Icon(
    val size: IconSize,
    val background: DrawableCircle,
    val number: DrawableNumber,
    val entryArrow: DrawableArrow,
    val exitArrow: DrawableArrow
)

enum class IconSize { SMALL, MEDIUM, LARGE }

data class DrawableCircle(
    val radius: Float,
    val strokeWidth: Float,
    val fillColor: Int,
    val strokeColor: Int
)

data class DrawableArrow(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val strokeWidth: Float,
    val color: Int
)

data class DrawableNumber(
    val value: Int,
    val size: Float,
    val color: Int,
    val style: NumberStyle
)

enum class NumberStyle { NORMAL, BOLD, ITALIC }

// Enums para alertas
enum class AlertType {
    ROUNDABOUT_APPROACH,
    ROUNDABOUT_PREPARATION,
    ROUNDABOUT_FINAL
}

enum class AlertPriority {
    LOW,
    MEDIUM,
    HIGH
}

// Interfaces de serviço (implementações simplificadas)
interface NavigationService {
    fun getCurrentLocation(): Location?
}

interface AlertService {
    suspend fun showAlert(
        message: String,
        type: AlertType,
        priority: AlertPriority
    )
}

interface VoiceService {
    suspend fun speak(message: String, priority: AlertPriority)
}