import React, { useState, useEffect, useRef } from 'react';
import { AlertCircle, MapPin, Navigation, Clock, RefreshCw, X, Check, ChevronRight } from 'lucide-react';

/**
 * Componente que observa novas atualizações de POIs de outros 
 * motoristas e sugere atualização da rota.
 * 
 * @param {Object} props Propriedades do componente
 * @param {Array} props.newPOIs Lista de novos POIs detectados
 * @param {Object} props.currentRoute Rota atual (opcional)
 * @param {Object} props.currentLocation Localização atual do usuário {lat, lng}
 * @param {Function} props.onViewPOI Callback quando o usuário quer ver detalhes de um POI
 * @param {Function} props.onUpdateRoute Callback quando o usuário aceita a sugestão de nova rota
 * @param {Function} props.onDismiss Callback quando o usuário descarta a notificação
 * @param {Number} props.visibilityDuration Duração em ms que a notificação ficará visível (0 = não ocultar)
 * @param {Boolean} props.autoDismiss Se true, descarta notificações após visibilityDuration
 * @param {string} props.className Classes CSS adicionais
 */
const RealtimePOIUpdates = ({
  newPOIs = [],
  currentRoute = null,
  currentLocation = null,
  onViewPOI = () => {},
  onUpdateRoute = () => {},
  onDismiss = () => {},
  visibilityDuration = 15000, // 15 segundos
  autoDismiss = true,
  className = ""
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const [activePOIs, setActivePOIs] = useState([]);
  const [dismissedPOIs, setDismissedPOIs] = useState([]);
  const [selectedPOI, setSelectedPOI] = useState(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [canUpdateRoute, setCanUpdateRoute] = useState(false);
  const autoDismissTimerRef = useRef(null);
  const animationFrameRef = useRef(null);

  // Processa novos POIs quando eles chegam
  useEffect(() => {
    if (newPOIs.length > 0) {
      // Filtra apenas os POIs que ainda não foram processados ou demissados
      const filteredPOIs = newPOIs.filter(poi => 
        !activePOIs.some(active => active.id === poi.id) && 
        !dismissedPOIs.includes(poi.id)
      );
      
      if (filteredPOIs.length > 0) {
        // Adiciona os POIs filtrados à lista de ativos
        setActivePOIs(prev => [...prev, ...filteredPOIs]);
        
        // Mostra o componente
        setIsVisible(true);
        
        // Se tem apenas um POI, seleciona-o automaticamente
        if (activePOIs.length === 0 && filteredPOIs.length === 1) {
          setSelectedPOI(filteredPOIs[0]);
          setIsExpanded(true);
        }
        
        // Configura o timer para auto-dismiss se necessário
        resetAutoDismissTimer();
      }
    }
  }, [newPOIs]);

  // Verifica se é possível atualizar a rota sempre que o POI selecionado muda
  useEffect(() => {
    if (selectedPOI && currentRoute && currentLocation) {
      // Verifica se o POI está próximo da rota atual
      // Em uma implementação real, esta seria uma verificação mais complexa
      setCanUpdateRoute(isNearRoute(selectedPOI, currentRoute));
    } else {
      setCanUpdateRoute(false);
    }
  }, [selectedPOI, currentRoute, currentLocation]);

  // Limpa timers e animações ao desmontar
  useEffect(() => {
    return () => {
      if (autoDismissTimerRef.current) {
        clearTimeout(autoDismissTimerRef.current);
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  // Reseta o timer de auto-dismiss
  const resetAutoDismissTimer = () => {
    if (autoDismissTimerRef.current) {
      clearTimeout(autoDismissTimerRef.current);
    }
    
    if (autoDismiss && visibilityDuration > 0) {
      autoDismissTimerRef.current = setTimeout(() => {
        if (activePOIs.length > 0) {
          // Auto-dismiss apenas se o usuário não interagiu recentemente
          setIsVisible(false);
        }
      }, visibilityDuration);
    }
  };

  // Verifica se um POI está próximo de uma rota
  const isNearRoute = (poi, route) => {
    // Simulação - em um app real, seria uma verificação geométrica
    // entre o POI e a geometria da rota
    return Math.random() > 0.3; // 70% de chance de estar próximo
  };

  // Calcula distância entre dois pontos (em km)
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Raio da Terra em km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distância em km
    return distance;
  };
  
  const deg2rad = (deg) => {
    return deg * (Math.PI/180);
  };

  // Formata a distância para exibição
  const formatDistance = (distanceKm) => {
    if (distanceKm < 1) {
      return `${Math.round(distanceKm * 1000)} m`;
    } else if (distanceKm < 10) {
      return `${distanceKm.toFixed(1)} km`;
    } else {
      return `${Math.round(distanceKm)} km`;
    }
  };

  // Formata o tempo para exibição
  const formatTimeAgo = (timestamp) => {
    const now = Date.now();
    const diffMs = now - timestamp;
    const diffSec = Math.floor(diffMs / 1000);
    
    if (diffSec < 60) {
      return `${diffSec}s atrás`;
    } else if (diffSec < 3600) {
      return `${Math.floor(diffSec / 60)}min atrás`;
    } else if (diffSec < 86400) {
      return `${Math.floor(diffSec / 3600)}h atrás`;
    } else {
      return `${Math.floor(diffSec / 86400)}d atrás`;
    }
  };

  // Seleciona um POI para detalhar
  const handleSelectPOI = (poi) => {
    setSelectedPOI(poi);
    setIsExpanded(true);
    resetAutoDismissTimer();
  };

  // Visualiza detalhes completos de um POI
  const handleViewPOI = () => {
    if (selectedPOI) {
      onViewPOI(selectedPOI);
      dismissPOI(selectedPOI.id);
    }
  };

  // Atualiza a rota para incluir o POI
  const handleUpdateRoute = () => {
    if (selectedPOI && canUpdateRoute) {
      onUpdateRoute(selectedPOI);
      dismissPOI(selectedPOI.id);
    }
  };

  // Descarta um POI específico
  const dismissPOI = (poiId) => {
    setActivePOIs(prev => prev.filter(p => p.id !== poiId));
    setDismissedPOIs(prev => [...prev, poiId]);
    
    // Se não há mais POIs ativos, fecha o componente
    if (activePOIs.length <= 1) {
      setIsVisible(false);
      setIsExpanded(false);
      setSelectedPOI(null);
    } else if (selectedPOI && selectedPOI.id === poiId) {
      // Se o POI descartado era o selecionado, seleciona o próximo
      const nextPOI = activePOIs.find(p => p.id !== poiId);
      setSelectedPOI(nextPOI);
    }
    
    onDismiss(poiId);
  };

  // Limpa todas as notificações
  const dismissAll = () => {
    const ids = activePOIs.map(p => p.id);
    setDismissedPOIs(prev => [...prev, ...ids]);
    setActivePOIs([]);
    setIsVisible(false);
    setIsExpanded(false);
    setSelectedPOI(null);
    onDismiss(ids);
  };

  // Se não estiver visível ou não houver POIs ativos, não renderiza nada
  if (!isVisible || activePOIs.length === 0) {
    return null;
  }

  // Retorna o ícone correspondente ao tipo de POI
  const getPOIIcon = (type) => {
    switch (type) {
      case 'gas_station':
        return <div className="p-1 bg-red-100 dark:bg-red-800 rounded-full"><AlertCircle className="w-4 h-4 text-red-500 dark:text-red-300" /></div>;
      case 'restaurant':
        return <div className="p-1 bg-yellow-100 dark:bg-yellow-800 rounded-full"><AlertCircle className="w-4 h-4 text-yellow-500 dark:text-yellow-300" /></div>;
      case 'hotel':
        return <div className="p-1 bg-blue-100 dark:bg-blue-800 rounded-full"><AlertCircle className="w-4 h-4 text-blue-500 dark:text-blue-300" /></div>;
      default:
        return <div className="p-1 bg-gray-100 dark:bg-gray-800 rounded-full"><MapPin className="w-4 h-4 text-gray-500 dark:text-gray-300" /></div>;
    }
  };

  return (
    <div className={`fixed bottom-4 right-4 w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700 overflow-hidden transition-all duration-300 ${className}`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <MapPin className="w-5 h-5 text-blue-500 dark:text-blue-400 mr-2" />
          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
            {activePOIs.length > 1 ? `${activePOIs.length} novos pontos de interesse` : "Novo ponto de interesse"}
          </h3>
        </div>
        <div className="flex space-x-1">
          {activePOIs.length > 1 && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              aria-label={isExpanded ? "Minimizar" : "Expandir"}
            >
              <ChevronRight className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
            </button>
          )}
          <button
            onClick={dismissAll}
            className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      {/* Lista de POIs (visível apenas se expandido) */}
      {isExpanded && activePOIs.length > 1 && (
        <div className="max-h-48 overflow-y-auto">
          {activePOIs.map(poi => {
            const distance = currentLocation ? 
              calculateDistance(currentLocation.lat, currentLocation.lng, poi.latitude, poi.longitude) : null;
              
            return (
              <div 
                key={poi.id}
                className={`p-3 border-b border-gray-100 dark:border-gray-700 flex items-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 ${selectedPOI?.id === poi.id ? 'bg-blue-50 dark:bg-blue-900' : ''}`}
                onClick={() => handleSelectPOI(poi)}
              >
                {getPOIIcon(poi.type)}
                <div className="ml-3 flex-1">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">{poi.name}</h4>
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    {distance !== null && (
                      <span className="flex items-center mr-2">
                        <Navigation className="w-3 h-3 mr-1" />
                        {formatDistance(distance)}
                      </span>
                    )}
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatTimeAgo(poi.createdAt)}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400 dark:text-gray-500" />
              </div>
            );
          })}
        </div>
      )}
      
      {/* Detalhes do POI selecionado ou do único POI */}
      {selectedPOI && (
        <div className="p-4">
          <div className="mb-3 flex items-start">
            {getPOIIcon(selectedPOI.type)}
            <div className="ml-3">
              <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">{selectedPOI.name}</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400">{selectedPOI.description || `Ponto de interesse do tipo ${selectedPOI.type}`}</p>
              
              {currentLocation && (
                <div className="mt-1 flex items-center text-xs text-gray-500 dark:text-gray-400">
                  <Navigation className="w-3 h-3 mr-1" />
                  {formatDistance(calculateDistance(currentLocation.lat, currentLocation.lng, selectedPOI.latitude, selectedPOI.longitude))}
                  <span className="mx-1">•</span>
                  <Clock className="w-3 h-3 mr-1" />
                  {formatTimeAgo(selectedPOI.createdAt)}
                </div>
              )}
              
              {selectedPOI.createdBy && (
                <div className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Reportado por: {selectedPOI.createdBy}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex space-x-2">
            {canUpdateRoute && (
              <button
                onClick={handleUpdateRoute}
                className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Atualizar rota
              </button>
            )}
            
            <button
              onClick={handleViewPOI}
              className={`flex items-center justify-center px-3 py-2 text-xs font-medium rounded-md border
                ${canUpdateRoute ? 'flex-1' : 'w-full'}
                ${canUpdateRoute 
                  ? 'text-gray-700 bg-gray-100 hover:bg-gray-200 border-gray-300 dark:text-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 dark:border-gray-600' 
                  : 'text-white bg-blue-600 hover:bg-blue-700 border-blue-600 dark:bg-blue-700 dark:hover:bg-blue-600 dark:border-blue-700'}`
              }
            >
              <Check className="w-4 h-4 mr-1" />
              Ver detalhes
            </button>
          </div>
        </div>
      )}
      
      {/* Mostra apenas o contador se não estiver expandido e houver múltiplos POIs */}
      {!isExpanded && activePOIs.length > 1 && (
        <div className="p-4 flex justify-between items-center">
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {activePOIs.length} pontos de interesse nas proximidades
          </span>
          <button
            onClick={() => setIsExpanded(true)}
            className="py-1 px-2 text-xs text-blue-700 bg-blue-100 rounded-md hover:bg-blue-200 dark:text-blue-300 dark:bg-blue-900 dark:hover:bg-blue-800"
          >
            Ver todos
          </button>
        </div>
      )}
    </div>
  );
};

export default RealtimePOIUpdates;