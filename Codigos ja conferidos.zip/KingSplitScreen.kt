package com.kingroad.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.kingroad.R
import com.kingroad.data.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * KingSplitScreen component that implements the split screen functionality
 * between KingRoad and secondary apps.
 */
@Composable
fun KingSplitScreen(
    preferences: AppPreferences,
    mainContent: @Composable () -> Unit,
    scope: CoroutineScope = rememberCoroutineScope()
) {
    val configuration = LocalConfiguration.current
    val isLargeScreen = configuration.screenWidthDp > 900
    
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    var isAppFixed by remember { mutableStateOf(false) }
    var showAppSelector by remember { mutableStateOf(false) }
    
    // Load saved app preference if any
    LaunchedEffect(true) {
        val savedApp = preferences.getString("fixedApp", null)
        if (savedApp != null) {
            val appInfo = availableApps.find { it.id == savedApp }
            selectedApp = appInfo
            isAppFixed = true
        }
    }
    
    // Colors from the design specifications
    val backgroundColor = Color(0xFFE0D3C0)
    val textColor = Color(0xFF5E3C2B)
    val accentColor = Color(0xFF6B4B3E)
    
    Box(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Main KingRoad app content
            Box(
                modifier = Modifier
                    .weight(if (isLargeScreen && selectedApp != null) 0.5f else 1f)
                    .fillMaxHeight()
                    .background(backgroundColor)
            ) {
                mainContent()
            }
            
            // Secondary app content (only visible on large screens)
            if (isLargeScreen && selectedApp != null) {
                Box(
                    modifier = Modifier
                        .weight(0.5f)
                        .fillMaxHeight()
                        .background(backgroundColor)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(getStringResourceId(selectedApp!!.label)),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = textColor
                            )
                            
                            IconButton(
                                onClick = { selectedApp = null },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = accentColor
                                )
                            }
                        }
                        
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // App content would be loaded here in a real implementation
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = getAppIcon(selectedApp!!.icon),
                                    contentDescription = null,
                                    modifier = Modifier.size(80.dp),
                                    tint = accentColor
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Text(
                                    text = stringResource(getStringResourceId(selectedApp!!.label)) + " Content",
                                    fontSize = 20.sp,
                                    color = textColor
                                )
                                
                                Spacer(modifier = Modifier.height(24.dp))
                                
                                Button(
                                    onClick = {
                                        isAppFixed = !isAppFixed
                                        scope.launch {
                                            if (isAppFixed) {
                                                preferences.putString("fixedApp", selectedApp!!.id)
                                            } else {
                                                preferences.remove("fixedApp")
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                                ) {
                                    Text(
                                        text = stringResource(
                                            id = if (isAppFixed) R.string.unpin_app else R.string.pin_app
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Floating button for small screens
        if (!isLargeScreen) {
            FloatingActionButton(
                onClick = { showAppSelector = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                containerColor = accentColor,
                contentColor = Color.White
            ) {
                Text(
                    text = "+",
                    fontSize = 24.sp
                )
            }
        }
        
        // App selector dialog
        if (showAppSelector) {
            AppSelectorDialog(
                onDismiss = { showAppSelector = false },
                onAppSelected = { app ->
                    selectedApp = app
                    showAppSelector = false
                },
                backgroundColor = backgroundColor,
                textColor = textColor,
                accentColor = accentColor
            )
        }
    }
}

/**
 * Dialog for selecting a secondary app
 */
@Composable
fun AppSelectorDialog(
    onDismiss: () -> Unit,
    onAppSelected: (AppInfo) -> Unit,
    backgroundColor: Color,
    textColor: Color,
    accentColor: Color
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = backgroundColor,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.select_app),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                    
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = accentColor
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    availableApps.chunked(2).forEach { chunk ->
                        Column {
                            chunk.forEach { app ->
                                AppBlock(
                                    app = app,
                                    textColor = textColor,
                                    accentColor = accentColor,
                                    onClick = { onAppSelected(app) }
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Represents an app in the selector
 */
@Composable
fun AppBlock(
    app: AppInfo,
    textColor: Color,
    accentColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Icon(
            imageVector = getAppIcon(app.icon),
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = accentColor
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = stringResource(getStringResourceId(app.label)),
            fontSize = 16.sp,
            color = textColor
        )
    }
}

/**
 * Data class for app information
 */
data class AppInfo(
    val id: String,
    val label: String,
    val icon: String
)

/**
 * List of available apps
 */
val availableApps = listOf(
    AppInfo("KingChat", "app_kingchat", "chat"),
    AppInfo("KingSMS", "app_kingsms", "message"),
    AppInfo("KingLoc", "app_kingloc", "location"),
    AppInfo("AdminPortal", "app_adminportal", "settings")
)

/**
 * Helper function to get string resource ID from key
 */
fun getStringResourceId(key: String): Int {
    return when(key) {
        "app_kingroad" -> R.string.app_kingroad
        "app_kingchat" -> R.string.app_kingchat
        "app_kingsms" -> R.string.app_kingsms
        "app_kingloc" -> R.string.app_kingloc
        "app_adminportal" -> R.string.app_adminportal
        else -> R.string.app_kingroad
    }
}

/**
 * Helper function to get icon from key
 */
fun getAppIcon(key: String): ImageVector {
    return when(key) {
        "chat" -> Icons.Default.Chat
        "message" -> Icons.Default.Message
        "location" -> Icons.Default.LocationOn
        "settings" -> Icons.Default.Settings
        else -> Icons.Default.LocationOn
    }
}