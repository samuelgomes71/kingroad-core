import React from 'react';
import { 
  MessageSquare, 
  Map, 
  MessageCircle, 
  Settings, 
  AlertTriangle, 
  Home, 
  Search, 
  Calendar, 
  Bell
} from 'lucide-react';

const KingRoadThemePreview = () => {
  // Colors from design specs
  const colors = {
    background: '#E0D3C0',
    textColor: '#5E3C2B',
    accent: '#6B4B3E',
    voiceButtonColor: '#5E3C2B',
    
    // Additional colors for the theme showcase
    error: '#D32F2F',
    success: '#388E3C',
    warning: '#F57C00',
    info: '#1976D2',
    
    // Light/dark mode variants
    backgroundLight: '#F5EEE6',
    backgroundDark: '#3E331F',
    textColorLight: '#7A5543',
    textColorDark: '#D6C2B0',
    accentLight: '#8A6A5A',
    accentDark: '#493124'
  };
  
  // Common actions in the app
  const actions = [
    { icon: <Home size={24} />, label: 'Home' },
    { icon: <Map size={24} />, label: 'Navigation' },
    { icon: <Search size={24} />, label: 'Search' },
    { icon: <AlertTriangle size={24} />, label: 'Alerts' },
    { icon: <Calendar size={24} />, label: 'Schedule' },
    { icon: <Bell size={24} />, label: 'Notifications' }
  ];
  
  // Apps available in KingRoad
  const apps = [
    { icon: <Map size={24} />, label: 'KingRoad' },
    { icon: <MessageSquare size={24} />, label: 'KingChat' },
    { icon: <MessageCircle size={24} />, label: 'KingSMS' },
    { icon: <Map size={24} />, label: 'KingLoc' },
    { icon: <Settings size={24} />, label: 'AdminPortal' }
  ];
  
  return (
    <div className="p-6 w-full">
      <h1 className="text-2xl font-bold mb-8" style={{ color: colors.textColor }}>
        KingRoad Theme System
      </h1>
      
      {/* Color palette */}
      <section className="mb-12">
        <h2 className="text-xl font-bold mb-4" style={{ color: colors.textColor }}>
          Color Palette
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <ColorCard color={colors.background} name="Background" hex="#E0D3C0" />
          <ColorCard color={colors.textColor} name="Text" hex="#5E3C2B" />
          <ColorCard color={colors.accent} name="Accent" hex="#6B4B3E" />
          <ColorCard color={colors.voiceButtonColor} name="Voice" hex="#5E3C2B" />
          
          <ColorCard color={colors.error} name="Error" hex="#D32F2F" />
          <ColorCard color={colors.success} name="Success" hex="#388E3C" />
          <ColorCard color={colors.warning} name="Warning" hex="#F57C00" />
          <ColorCard color={colors.info} name="Info" hex="#1976D2" />
        </div>
      </section>
      
      {/* Light/Dark modes */}
      <section className="mb-12">
        <h2 className="text-xl font-bold mb-4" style={{ color: colors.textColor }}>
          Light & Dark Themes
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Light theme */}
          <div 
            className="rounded-lg p-6"
            style={{ backgroundColor: colors.backgroundLight }}
          >
            <h3 
              className="text-lg font-bold mb-3" 
              style={{ color: colors.textColorLight }}
            >
              Light Theme
            </h3>
            
            <div className="flex gap-3 mb-4">
              {actions.slice(0, 4).map((action, index) => (
                <button 
                  key={index}
                  className="flex flex-col items-center p-2 rounded-lg"
                  style={{ color: colors.textColorLight }}
                >
                  <div style={{ color: colors.accentLight }}>{action.icon}</div>
                  <span className="text-xs mt-1">{action.label}</span>
                </button>
              ))}
            </div>
            
            <div className="flex justify-between items-center p-3 rounded-lg" style={{ backgroundColor: colors.background }}>
              <span style={{ color: colors.textColorLight }}>Split Screen Mode</span>
              <div className="w-10 h-5 rounded-full bg-gray-300 relative">
                <div 
                  className="absolute top-0.5 left-0.5 w-4 h-4 rounded-full"
                  style={{ backgroundColor: colors.accentLight }}
                />
              </div>
            </div>
          </div>
          
          {/* Dark theme */}
          <div 
            className="rounded-lg p-6"
            style={{ backgroundColor: colors.backgroundDark }}
          >
            <h3 
              className="text-lg font-bold mb-3" 
              style={{ color: colors.textColorDark }}
            >
              Dark Theme
            </h3>
            
            <div className="flex gap-3 mb-4">
              {actions.slice(0, 4).map((action, index) => (
                <button 
                  key={index}
                  className="flex flex-col items-center p-2 rounded-lg"
                  style={{ color: colors.textColorDark }}
                >
                  <div style={{ color: colors.accentDark }}>{action.icon}</div>
                  <span className="text-xs mt-1">{action.label}</span>
                </button>
              ))}
            </div>
            
            <div 
              className="flex justify-between items-center p-3 rounded-lg" 
              style={{ backgroundColor: 'rgba(0,0,0,0.2)' }}
            >
              <span style={{ color: colors.textColorDark }}>Split Screen Mode</span>
              <div className="w-10 h-5 rounded-full bg-gray-700 relative">
                <div 
                  className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full"
                  style={{ backgroundColor: colors.accentDark }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Component Examples */}
      <section className="mb-12">
        <h2 className="text-xl font-bold mb-4" style={{ color: colors.textColor }}>
          Component Examples
        </h2>
        
        <div 
          className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 rounded-lg"
          style={{ backgroundColor: colors.background }}
        >
          {/* Buttons */}
          <div className="space-y-4">
            <h3 className="font-bold" style={{ color: colors.textColor }}>Buttons</h3>
            
            <div className="flex flex-wrap gap-3">
              <button 
                className="px-4 py-2 rounded-lg text-white"
                style={{ backgroundColor: colors.accent }}
              >
                Primary
              </button>
              
              <button 
                className="px-4 py-2 rounded-lg border"
                style={{ 
                  borderColor: colors.accent,
                  color: colors.accent 
                }}
              >
                Secondary
              </button>
              
              <button 
                className="px-4 py-2 rounded-lg text-white"
                style={{ backgroundColor: colors.error }}
              >
                Danger
              </button>
              
              <button 
                className="p-2 rounded-full"
                style={{ backgroundColor: colors.accent }}
              >
                <Map size={20} color="white" />
              </button>
            </div>
          </div>
          
          {/* Cards */}
          <div className="space-y-4">
            <h3 className="font-bold" style={{ color: colors.textColor }}>Cards</h3>
            
            <div 
              className="p-4 rounded-lg"
              style={{ backgroundColor: 'white', color: colors.textColor }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="font-bold">Rest Stop</span>
                <AlertTriangle size={16} color={colors.warning} />
              </div>
              <p className="text-sm">25km ahead - Estimated arrival in 18 min</p>
              <div className="flex justify-end mt-2">
                <button 
                  className="text-xs px-2 py-1 rounded"
                  style={{ backgroundColor: colors.accent, color: 'white' }}
                >
                  Navigate
                </button>
              </div>
            </div>
          </div>
          
          {/* App icons */}
          <div className="space-y-4 col-span-1 md:col-span-2">
            <h3 className="font-bold" style={{ color: colors.textColor }}>App Icons</h3>
            
            <div className="flex flex-wrap gap-6 justify-center">
              {apps.map((app, index) => (
                <div 
                  key={index} 
                  className="flex flex-col items-center"
                >
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center mb-2"
                    style={{ 
                      backgroundColor: index === 0 ? colors.accent : 'white',
                      color: index === 0 ? 'white' : colors.accent,
                      boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
                    }}
                  >
                    {React.cloneElement(app.icon, { size: 32 })}
                  </div>
                  <span 
                    className="text-sm"
                    style={{ color: colors.textColor }}
                  >
                    {app.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Split Screen Preview */}
      <section>
        <h2 className="text-xl font-bold mb-4" style={{ color: colors.textColor }}>
          Split Screen Layout
        </h2>
        
        <div 
          className="rounded-lg overflow-hidden border-2 border-gray-300"
          style={{ height: '300px' }}
        >
          <div className="flex h-full">
            {/* KingRoad side */}
            <div 
              className="w-1/2 h-full"
              style={{ backgroundColor: colors.background }}
            >
              <div 
                className="p-4 border-b"
                style={{ borderColor: 'rgba(0,0,0,0.1)' }}
              >
                <h3 
                  className="font-bold text-lg"
                  style={{ color: colors.textColor }}
                >
                  KingRoad
                </h3>
              </div>
              <div className="flex items-center justify-center h-5/6">
                <div className="text-center">
                  <Map size={64} color={colors.accent} />
                  <p 
                    className="mt-2"
                    style={{ color: colors.textColor }}
                  >
                    Map View
                  </p>
                </div>
              </div>
            </div>
            
            {/* Secondary app side */}
            <div 
              className="w-1/2 h-full"
              style={{ backgroundColor: colors.background }}
            >
              <div 
                className="p-4 border-b flex justify-between items-center"
                style={{ borderColor: 'rgba(0,0,0,0.1)' }}
              >
                <h3 
                  className="font-bold text-lg"
                  style={{ color: colors.textColor }}
                >
                  KingChat
                </h3>
                <button className="p-1 rounded-full hover:bg-gray-200">
                  ✕
                </button>
              </div>
              <div className="flex items-center justify-center h-5/6">
                <div className="text-center">
                  <MessageSquare size={64} color={colors.accent} />
                  <p 
                    className="mt-2"
                    style={{ color: colors.textColor }}
                  >
                    Chat View
                  </p>
                  <button 
                    className="mt-4 px-3 py-1 rounded text-white text-sm"
                    style={{ backgroundColor: colors.accent }}
                  >
                    Unpin App
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

// Color card component
const ColorCard = ({ color, name, hex }) => {
  const textColor = isLightColor(color) ? '#333' : '#fff';
  
  return (
    <div className="flex flex-col">
      <div 
        className="h-24 rounded-t-lg flex items-center justify-center"
        style={{ backgroundColor: color, color: textColor }}
      >
        <span className="font-bold">{name}</span>
      </div>
      <div className="bg-gray-100 p-2 rounded-b-lg text-xs text-center">
        {hex}
      </div>
    </div>
  );
};

// Helper function to determine if a color is light or dark
const isLightColor = (hexColor) => {
  // Convert hex to RGB
  let r, g, b;
  
  if (hexColor.startsWith('#')) {
    const hex = hexColor.slice(1);
    r = parseInt(hex.slice(0, 2), 16);
    g = parseInt(hex.slice(2, 4), 16);
    b = parseInt(hex.slice(4, 6), 16);
  } else {
    // Handle RGB format if needed
    return false;
  }
  
  // Calculate brightness (simplified YIQ formula)
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  
  // Return true if the color is light (brightness > 128)
  return brightness > 128;
};

export default KingRoadThemePreview;