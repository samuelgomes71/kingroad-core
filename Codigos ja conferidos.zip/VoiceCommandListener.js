/**
 * VoiceCommandListener.js
 * 
 * Serviço para processamento de comandos de voz multi-idioma.
 * Implementa sistema de reconhecimento de comandos por voz funcionando
 * em todos os 34 idiomas suportados, com capacidade de operar offline.
 * 
 * Inclui sistema de registro de comandos que permite associar
 * frases-chave a ações específicas do aplicativo.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import LocaleService from './LocaleService';

// Constantes para tipos de comandos
const COMMAND_TYPES = {
  NAVIGATION: 'navigation',
  REPORT: 'report',
  SETTINGS: 'settings',
  COMMUNICATION: 'communication',
  SYSTEM: 'system',
  MEDIA: 'media',
  CUSTOM: 'custom'
};

// Constantes para estados de reconhecimento
const RECOGNITION_STATES = {
  IDLE: 'idle',
  LISTENING: 'listening',
  PROCESSING: 'processing',
  SUCCESS: 'success',
  ERROR: 'error',
  NO_SPEECH: 'no_speech',
  NO_MATCH: 'no_match',
  UNSUPPORTED: 'unsupported'
};

/**
 * Serviço para reconhecimento e processamento de comandos de voz.
 * Suporta múltiplos idiomas, operação offline e comandos personalizados.
 */
class VoiceCommandListener {
  /**
   * Inicializa o serviço de comandos de voz
   */
  constructor() {
    this.localeService = new LocaleService();
    
    // Estado atual do reconhecimento
    this.recognitionState = RECOGNITION_STATES.IDLE;
    
    // Linguagem atual
    this.currentLanguage = this.localeService.getCurrentLanguage();
    
    // Flag para uso offline
    this.isOfflineMode = false;
    
    // Sistema de reconhecimento de voz nativo
    this.speechRecognition = null;
    
    // Comandos registrados agrupados por tipo e idioma
    this.registeredCommands = {
      // Estrutura: [idioma][tipo][comando] = { action, description, params }
    };
    
    // Callbacks para eventos do reconhecedor
    this.stateChangeCallbacks = [];
    this.commandRecognizedCallbacks = [];
    
    // Inicializa o sistema
    this.initialize();
    
    // Registra listener para mudanças de idioma no LocaleService
    this.localeService.addLanguageChangeListener(this.handleLanguageChange.bind(this));
  }
  
  /**
   * Inicializa o sistema de reconhecimento de voz
   * @private
   */
  initialize() {
    // Verifica se o navegador/dispositivo suporta reconhecimento de voz
    if (typeof window !== 'undefined') {
      // Tenta usar a API Web Speech Recognition
      const SpeechRecognition = window.SpeechRecognition || 
                                window.webkitSpeechRecognition || 
                                window.mozSpeechRecognition || 
                                window.msSpeechRecognition;
      
      if (SpeechRecognition) {
        this.speechRecognition = new SpeechRecognition();
        this.configureWebSpeechRecognition();
      } else {
        // Se Web Speech não for suportada, tenta usar a implementação nativa da plataforma
        this.setupPlatformSpecificRecognition();
      }
    } else {
      // Ambiente sem acesso a window (server-side)
      console.warn('[VoiceCommandListener] Executando em ambiente sem suporte a reconhecimento de voz');
      this.recognitionState = RECOGNITION_STATES.UNSUPPORTED;
      this.notifyStateChange();
    }
    
    // Carrega os comandos padrão para todos os idiomas
    this.loadDefaultCommands();
  }
  
  /**
   * Configura o reconhecimento de voz utilizando Web Speech API
   * @private
   */
  configureWebSpeechRecognition() {
    if (!this.speechRecognition) return;
    
    // Configura o idioma baseado no idioma atual do app
    this.speechRecognition.lang = this.convertToSpeechRecognitionLocale(this.currentLanguage);
    
    // Configura para resultados contínuos (não para após cada frase)
    this.speechRecognition.continuous = false;
    
    // Permite resultados intermediários para feedback ao usuário
    this.speechRecognition.interimResults = true;
    
    // Configura o número máximo de alternativas a retornar
    this.speechRecognition.maxAlternatives = 3;
    
    // Configura handlers de eventos
    this.speechRecognition.onstart = () => {
      this.recognitionState = RECOGNITION_STATES.LISTENING;
      this.notifyStateChange();
    };
    
    this.speechRecognition.onresult = (event) => {
      this.recognitionState = RECOGNITION_STATES.PROCESSING;
      this.notifyStateChange();
      
      // Obtém o resultado mais confiável
      const result = event.results[0];
      const mostConfidentResult = result[0];
      const transcript = mostConfidentResult.transcript.trim().toLowerCase();
      const confidence = mostConfidentResult.confidence;
      
      console.log(`[VoiceCommandListener] Texto reconhecido: "${transcript}" (confiança: ${confidence.toFixed(2)})`);
      
      // Processa o comando reconhecido
      this.processRecognizedText(transcript, confidence);
    };
    
    this.speechRecognition.onerror = (event) => {
      switch (event.error) {
        case 'no-speech':
          this.recognitionState = RECOGNITION_STATES.NO_SPEECH;
          break;
        case 'not-allowed':
        case 'service-not-allowed':
          this.recognitionState = RECOGNITION_STATES.ERROR;
          console.error('[VoiceCommandListener] Permissão de microfone negada');
          break;
        case 'network':
          // Tenta alternar para o modo offline
          this.enableOfflineMode();
          break;
        default:
          this.recognitionState = RECOGNITION_STATES.ERROR;
          console.error(`[VoiceCommandListener] Erro no reconhecimento: ${event.error}`);
      }
      
      this.notifyStateChange();
    };
    
    this.speechRecognition.onnomatch = () => {
      this.recognitionState = RECOGNITION_STATES.NO_MATCH;
      this.notifyStateChange();
    };
    
    this.speechRecognition.onend = () => {
      // Só muda para IDLE se não estiver em estado de erro ou processamento
      if (![RECOGNITION_STATES.ERROR, 
             RECOGNITION_STATES.PROCESSING, 
             RECOGNITION_STATES.SUCCESS].includes(this.recognitionState)) {
        this.recognitionState = RECOGNITION_STATES.IDLE;
        this.notifyStateChange();
      }
    };
  }
  
  /**
   * Configura reconhecimento específico para plataformas nativas (React Native)
   * @private
   */
  setupPlatformSpecificRecognition() {
    // Verifica se estamos em ambiente React Native
    const isReactNative = typeof navigator !== 'undefined' && navigator.product === 'ReactNative';
    
    if (isReactNative) {
      try {
        // Importação dinâmica do módulo de reconhecimento de voz para React Native
        // Este código assume que o projeto tem a biblioteca "react-native-voice" instalada
        // e configurada corretamente para Android e iOS
        import('react-native-voice')
          .then(VoiceModule => {
            this.voiceModule = VoiceModule.default;
            
            // Configura eventos
            this.voiceModule.onSpeechStart = () => {
              this.recognitionState = RECOGNITION_STATES.LISTENING;
              this.notifyStateChange();
            };
            
            this.voiceModule.onSpeechRecognized = () => {
              this.recognitionState = RECOGNITION_STATES.PROCESSING;
              this.notifyStateChange();
            };
            
            this.voiceModule.onSpeechResults = (event) => {
              if (event.value && event.value.length > 0) {
                const transcript = event.value[0].toLowerCase();
                // Não temos confiança na API nativa, então assumimos 0.8
                this.processRecognizedText(transcript, 0.8);
              }
            };
            
            this.voiceModule.onSpeechError = (error) => {
              if (error.error.code === '7' || error.error.code === '6') {
                this.recognitionState = RECOGNITION_STATES.NO_SPEECH;
              } else {
                this.recognitionState = RECOGNITION_STATES.ERROR;
              }
              this.notifyStateChange();
            };
            
            this.voiceModule.onSpeechEnd = () => {
              if (this.recognitionState === RECOGNITION_STATES.LISTENING) {
                this.recognitionState = RECOGNITION_STATES.IDLE;
                this.notifyStateChange();
              }
            };
            
          })
          .catch(error => {
            console.error('[VoiceCommandListener] Erro ao carregar módulo de voz nativo:', error);
            this.recognitionState = RECOGNITION_STATES.UNSUPPORTED;
            this.notifyStateChange();
          });
      } catch (error) {
        console.error('[VoiceCommandListener] Erro na configuração do reconhecimento nativo:', error);
        this.recognitionState = RECOGNITION_STATES.UNSUPPORTED;
        this.notifyStateChange();
      }
    } else {
      // Em outros ambientes sem suporte às APIs padrão, marcamos como não suportado
      this.recognitionState = RECOGNITION_STATES.UNSUPPORTED;
      this.notifyStateChange();
    }
  }
  
  /**
   * Ativa modo de reconhecimento offline
   * @private
   */
  enableOfflineMode() {
    console.log('[VoiceCommandListener] Alternando para modo offline de reconhecimento de voz');
    this.isOfflineMode = true;
    
    // Em uma implementação real, aqui carregaríamos os modelos offline
    // específicos para cada plataforma
    
    // Exemplo pseudocódigo para carregar modelos offline:
    // if (isAndroid) {
    //   this.loadAndroidOfflineRecognizer(this.currentLanguage);
    // } else if (isIOS) {
    //   this.loadIOSOfflineRecognizer(this.currentLanguage);
    // }
    
    // Para este exemplo, assumimos que o modo offline não está totalmente implementado
    console.warn('[VoiceCommandListener] Modo offline: funcionalidade limitada disponível');
  }
  
  /**
   * Desativa modo de reconhecimento offline
   */
  disableOfflineMode() {
    if (this.isOfflineMode) {
      console.log('[VoiceCommandListener] Retornando ao modo online de reconhecimento de voz');
      this.isOfflineMode = false;
      
      // Reinicia o sistema de reconhecimento
      if (this.speechRecognition) {
        this.configureWebSpeechRecognition();
      } else {
        this.setupPlatformSpecificRecognition();
      }
    }
  }
  
  /**
   * Carrega os comandos padrão para todos os idiomas suportados
   * @private
   */
  loadDefaultCommands() {
    // Obtém todos os idiomas suportados
    const supportedLanguages = this.localeService.getSupportedLanguages();
    
    // Inicializa estrutura de comandos para cada idioma
    supportedLanguages.forEach(lang => {
      if (!this.registeredCommands[lang]) {
        this.registeredCommands[lang] = {};
        
        // Inicializa cada tipo de comando
        Object.values(COMMAND_TYPES).forEach(type => {
          this.registeredCommands[lang][type] = {};
        });
      }
    });
    
    // Registra comandos padrão para navegação em EN (inglês)
    // Outros idiomas seriam configurados similarmente
    this.registerCommand(
      'en',
      COMMAND_TYPES.NAVIGATION,
      'navigate to',
      { action: 'navigateTo', params: ['destination'] },
      'Navigate to a specified destination'
    );
    
    this.registerCommand(
      'en',
      COMMAND_TYPES.NAVIGATION,
      'find nearest',
      { action: 'findNearest', params: ['placeType'] },
      'Find the nearest place of specified type'
    );
    
    this.registerCommand(
      'en',
      COMMAND_TYPES.REPORT,
      'report traffic',
      { action: 'createReport', params: ['reportType'], values: { reportType: 'traffic' } },
      'Create a traffic report at current location'
    );
    
    this.registerCommand(
      'en',
      COMMAND_TYPES.SYSTEM,
      'change to dark mode',
      { action: 'changeTheme', params: [], values: { theme: 'dark' } },
      'Switch app to dark mode'
    );
    
    // Registra comandos padrão para PT (português)
    this.registerCommand(
      'pt',
      COMMAND_TYPES.NAVIGATION,
      'navegar para',
      { action: 'navigateTo', params: ['destination'] },
      'Navegar para um destino específico'
    );
    
    this.registerCommand(
      'pt',
      COMMAND_TYPES.NAVIGATION,
      'encontrar mais próximo',
      { action: 'findNearest', params: ['placeType'] },
      'Encontrar o local mais próximo do tipo especificado'
    );
    
    this.registerCommand(
      'pt',
      COMMAND_TYPES.REPORT,
      'reportar tráfego',
      { action: 'createReport', params: ['reportType'], values: { reportType: 'traffic' } },
      'Criar um reporte de tráfego na localização atual'
    );
    
    this.registerCommand(
      'pt',
      COMMAND_TYPES.SYSTEM,
      'mudar para modo escuro',
      { action: 'changeTheme', params: [], values: { theme: 'dark' } },
      'Mudar o aplicativo para o modo escuro'
    );
    
    // Registra comandos padrão para ES (espanhol)
    this.registerCommand(
      'es',
      COMMAND_TYPES.NAVIGATION,
      'navegar a',
      { action: 'navigateTo', params: ['destination'] },
      'Navegar a un destino específico'
    );
    
    this.registerCommand(
      'es',
      COMMAND_TYPES.REPORT,
      'reportar tráfico',
      { action: 'createReport', params: ['reportType'], values: { reportType: 'traffic' } },
      'Crear un reporte de tráfico en la ubicación actual'
    );
    
    // E assim por diante para os outros idiomas...
    // Em uma implementação completa, teríamos comandos para todos os 34 idiomas
  }
  
  /**
   * Processa texto reconhecido para identificar comandos
   * @private
   * @param {string} text - Texto reconhecido pelo sistema de voz
   * @param {number} confidence - Nível de confiança do reconhecimento (0-1)
   */
  processRecognizedText(text, confidence) {
    if (!text || text.length === 0) {
      this.recognitionState = RECOGNITION_STATES.NO_MATCH;
      this.notifyStateChange();
      return;
    }
    
    // Limite mínimo de confiança para aceitar o comando
    const MIN_CONFIDENCE = 0.5;
    
    if (confidence < MIN_CONFIDENCE && !this.isOfflineMode) {
      console.warn(`[VoiceCommandListener] Confiança muito baixa (${confidence.toFixed(2)}), ignorando comando`);
      this.recognitionState = RECOGNITION_STATES.NO_MATCH;
      this.notifyStateChange();
      return;
    }
    
    // Obtém os comandos registrados para o idioma atual
    const commandsByType = this.registeredCommands[this.currentLanguage];
    
    if (!commandsByType) {
      console.warn(`[VoiceCommandListener] Nenhum comando registrado para o idioma ${this.currentLanguage}`);
      this.recognitionState = RECOGNITION_STATES.NO_MATCH;
      this.notifyStateChange();
      return;
    }
    
    // Flag para indicar se encontramos um comando
    let commandFound = false;
    
    // Procura em todos os tipos de comando
    for (const type in commandsByType) {
      const commands = commandsByType[type];
      
      // Procura um comando que corresponda ao texto reconhecido
      for (const commandPhrase in commands) {
        if (text.includes(commandPhrase)) {
          const commandData = commands[commandPhrase];
          
          // Extrai parâmetros do texto (se houver)
          const params = this.extractParamsFromText(text, commandPhrase, commandData.params);
          
          // Mescla parâmetros extraídos com valores padrão
          const finalParams = { ...commandData.values, ...params };
          
          // Constrói o resultado do comando
          const commandResult = {
            type,
            command: commandPhrase,
            action: commandData.action,
            params: finalParams,
            originalText: text,
            confidence
          };
          
          // Notifica sobre o comando reconhecido
          this.notifyCommandRecognized(commandResult);
          
          // Marca como sucesso
          this.recognitionState = RECOGNITION_STATES.SUCCESS;
          this.notifyStateChange();
          
          commandFound = true;
          break;
        }
      }
      
      if (commandFound) break;
    }
    
    // Se nenhum comando foi encontrado
    if (!commandFound) {
      console.log(`[VoiceCommandListener] Nenhum comando correspondente para: "${text}"`);
      this.recognitionState = RECOGNITION_STATES.NO_MATCH;
      this.notifyStateChange();
    }
  }
  
  /**
   * Extrai parâmetros do texto reconhecido
   * @private
   * @param {string} text - Texto completo reconhecido
   * @param {string} command - Comando base reconhecido
   * @param {Array<string>} paramNames - Nomes dos parâmetros esperados
   * @returns {Object} Objeto com os parâmetros extraídos
   */
  extractParamsFromText(text, command, paramNames) {
    if (!paramNames || paramNames.length === 0) {
      return {};
    }
    
    // Remove o comando do texto para extrair apenas os parâmetros
    const paramsText = text.replace(command, '').trim();
    
    if (!paramsText) {
      return {};
    }
    
    const params = {};
    
    // Estratégias de extração de parâmetros dependem do tipo de comando
    // Este é um exemplo simples para comando "navegar para [destino]"
    if (paramNames.includes('destination')) {
      params.destination = paramsText;
    } 
    // Para comando "encontrar mais próximo [tipo]"
    else if (paramNames.includes('placeType')) {
      params.placeType = paramsText;
    }
    // Implemente outras estratégias conforme necessário
    
    return params;
  }
  
  /**
   * Converte código de idioma do app para formato aceito pelo SpeechRecognition
   * @private
   * @param {string} languageCode - Código de idioma do app (ex: 'pt', 'en')
   * @returns {string} Código de idioma formatado para SpeechRecognition (ex: 'pt-BR', 'en-US')
   */
  convertToSpeechRecognitionLocale(languageCode) {
    // Mapeamento de códigos de idioma para locales de reconhecimento de voz
    const localeMap = {
      'en': 'en-US',
      'pt': 'pt-BR',
      'es': 'es-ES',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'it': 'it-IT',
      'nl': 'nl-NL',
      'ru': 'ru-RU',
      'ja': 'ja-JP',
      'zh': 'zh-CN',
      'ar': 'ar-SA',
      'hi': 'hi-IN',
      'ko': 'ko-KR',
      'pl': 'pl-PL',
      'tr': 'tr-TR',
      // Adicione outros idiomas conforme necessário
    };
    
    return localeMap[languageCode] || 'en-US'; // Fallback para inglês
  }
  
  /**
   * Inicia o reconhecimento de voz
   * @returns {boolean} True se iniciou com sucesso, False caso contrário
   */
  startListening() {
    // Verifica se já está ouvindo
    if (this.recognitionState === RECOGNITION_STATES.LISTENING) {
      console.warn('[VoiceCommandListener] Já está ouvindo comandos de voz');
      return false;
    }
    
    // Verifica se o reconhecimento é suportado
    if (this.recognitionState === RECOGNITION_STATES.UNSUPPORTED) {
      console.error('[VoiceCommandListener] Reconhecimento de voz não é suportado neste dispositivo');
      return false;
    }
    
    try {
      if (this.speechRecognition) {
        // Web Speech API
        this.speechRecognition.start();
        return true;
      } else if (this.voiceModule) {
        // React Native Voice
        const options = {
          locale: this.convertToSpeechRecognitionLocale(this.currentLanguage),
          partialResults: true
        };
        
        this.voiceModule.start(options);
        return true;
      } else {
        console.error('[VoiceCommandListener] Nenhum sistema de reconhecimento disponível');
        return false;
      }
    } catch (error) {
      console.error('[VoiceCommandListener] Erro ao iniciar reconhecimento:', error);
      this.recognitionState = RECOGNITION_STATES.ERROR;
      this.notifyStateChange();
      return false;
    }
  }
  
  /**
   * Para o reconhecimento de voz
   */
  stopListening() {
    if (this.recognitionState === RECOGNITION_STATES.LISTENING || 
        this.recognitionState === RECOGNITION_STATES.PROCESSING) {
      try {
        if (this.speechRecognition) {
          this.speechRecognition.stop();
        } else if (this.voiceModule) {
          this.voiceModule.stop();
        }
        
        this.recognitionState = RECOGNITION_STATES.IDLE;
        this.notifyStateChange();
      } catch (error) {
        console.error('[VoiceCommandListener] Erro ao parar reconhecimento:', error);
      }
    }
  }
  
  /**
   * Registra um comando de voz
   * @param {string} language - Código do idioma (ex: 'pt', 'en')
   * @param {string} type - Tipo de comando (usar constantes COMMAND_TYPES)
   * @param {string} commandPhrase - Frase que ativa o comando
   * @param {Object} handler - Objeto com {action, params, values}
   * @param {string} description - Descrição do comando para ajuda ao usuário
   * @returns {boolean} True se registrado com sucesso
   */
  registerCommand(language, type, commandPhrase, handler, description = '') {
    // Valida parâmetros
    if (!language || !type || !commandPhrase || !handler || !handler.action) {
      console.error('[VoiceCommandListener] Parâmetros inválidos para registrar comando');
      return false;
    }
    
    // Normaliza a frase do comando (minúsculas)
    const normalizedCommand = commandPhrase.toLowerCase().trim();
    
    // Inicializa a estrutura se necessário
    if (!this.registeredCommands[language]) {
      this.registeredCommands[language] = {};
    }
    
    if (!this.registeredCommands[language][type]) {
      this.registeredCommands[language][type] = {};
    }
    
    // Registra o comando
    this.registeredCommands[language][type][normalizedCommand] = {
      action: handler.action,
      params: handler.params || [],
      values: handler.values || {},
      description
    };
    
    console.log(`[VoiceCommandListener] Comando registrado: ${language}/${type}/${normalizedCommand}`);
    return true;
  }
  
  /**
   * Remove um comando de voz registrado
   * @param {string} language - Código do idioma
   * @param {string} type - Tipo de comando
   * @param {string} commandPhrase - Frase que ativa o comando
   * @returns {boolean} True se removido com sucesso
   */
  unregisterCommand(language, type, commandPhrase) {
    const normalizedCommand = commandPhrase.toLowerCase().trim();
    
    if (!this.registeredCommands[language] || 
        !this.registeredCommands[language][type] ||
        !this.registeredCommands[language][type][normalizedCommand]) {
      return false;
    }
    
    delete this.registeredCommands[language][type][normalizedCommand];
    return true;
  }
  
  /**
   * Obtém todos os comandos registrados para um idioma
   * @param {string} language - Código do idioma (opcional, usa o atual se não informado)
   * @returns {Object} Mapa de comandos organizados por tipo
   */
  getRegisteredCommands(language = null) {
    const targetLanguage = language || this.currentLanguage;
    return this.registeredCommands[targetLanguage] || {};
  }
  
  /**
   * Manipula mudanças de idioma do LocaleService
   * @private
   * @param {string} newLanguage - Novo código de idioma
   */
  handleLanguageChange(newLanguage) {
    console.log(`[VoiceCommandListener] Idioma alterado para: ${newLanguage}`);
    this.currentLanguage = newLanguage;
    
    // Atualiza o idioma do reconhecedor de voz
    if (this.speechRecognition) {
      this.speechRecognition.lang = this.convertToSpeechRecognitionLocale(newLanguage);
    }
  }
  
  /**
   * Adiciona callback para mudanças de estado do reconhecedor
   * @param {Function} callback - Função a ser chamada quando o estado mudar
   * @returns {Function} Função para remover o callback
   */
  addStateChangeListener(callback) {
    if (typeof callback !== 'function') {
      throw new Error('[VoiceCommandListener] Listener deve ser uma função');
    }
    
    this.stateChangeCallbacks.push(callback);
    
    return () => {
      this.stateChangeCallbacks = this.stateChangeCallbacks.filter(cb => cb !== callback);
    };
  }
  
  /**
   * Adiciona callback para comandos reconhecidos
   * @param {Function} callback - Função a ser chamada quando um comando for reconhecido
   * @returns {Function} Função para remover o callback
   */
  addCommandRecognizedListener(callback) {
    if (typeof callback !== 'function') {
      throw new Error('[VoiceCommandListener] Listener deve ser uma função');
    }
    
    this.commandRecognizedCallbacks.push(callback);
    
    return () => {
      this.commandRecognizedCallbacks = this.commandRecognizedCallbacks.filter(cb => cb !== callback);
    };
  }
  
  /**
   * Notifica sobre mudanças de estado
   * @private
   */
  notifyStateChange() {
    const stateData = {
      state: this.recognitionState,
      isOfflineMode: this.isOfflineMode,
      language: this.currentLanguage
    };
    
    this.stateChangeCallbacks.forEach(callback => {
      try {
        callback(stateData);
      } catch (error) {
        console.error('[VoiceCommandListener] Erro ao notificar mudança de estado:', error);
      }
    });
  }
  
  /**
   * Notifica sobre comando reconhecido
   * @private
   * @param {Object} commandResult - Dados do comando reconhecido
   */
  notifyCommandRecognized(commandResult) {
    this.commandRecognizedCallbacks.forEach(callback => {
      try {
        callback(commandResult);
      } catch (error) {
        console.error('[VoiceCommandListener] Erro ao notificar comando reconhecido:', error);
      }
    });
  }
  
  /**
   * Retorna o estado atual do reconhecedor
   * @returns {string} Estado atual (usar constantes RECOGNITION_STATES)
   */
  getState() {
    return this.recognitionState;
  }
  
  /**
   * Verifica se o reconhecimento de voz é suportado
   * @returns {boolean} True se suportado
   */
  isSupported() {
    return this.recognitionState !== RECOGNITION_STATES.UNSUPPORTED;
  }
  
  /**
   * Verifica se está no modo offline
   * @returns {boolean} True se estiver em modo offline
   */
  isOffline() {
    return this.isOfflineMode;
  }
  
  /**
   * Obtém uma lista de frases de ajuda para comandos disponíveis
   * @param {string} language - Código do idioma (opcional)
   * @returns {Array<string>} Lista de frases de ajuda
   */
  getHelpPhrases(language = null) {
    const targetLanguage = language || this.currentLanguage;
    const commands = this.getRegisteredCommands(targetLanguage);
    
    const helpPhrases = [];
    
    for (const type in commands) {
      for (const commandPhrase in commands[type]) {
        const command = commands[type][commandPhrase];
        if (command.description) {
          // Formata como: "Diga 'comando' para: descrição"
          const helpText = `${this.getCommandPrompt(targetLanguage)} '${commandPhrase}' ${this.getCommandSuffix(targetLanguage)}: ${command.description}`;
          helpPhrases.push(helpText);
        }
      }
    }
    
    return helpPhrases;
  }
  
  /**
   * Obtém o prefixo para frases de ajuda baseado no idioma
   * @private
   * @param {string} language - Código do idioma
   * @returns {string} Prefixo localizado
   */
  getCommandPrompt(language) {
    const prompts = {
      'en': 'Say',
      'pt': 'Diga',
      'es': 'Diga',
      'fr': 'Dites',
      'de': 'Sagen Sie',
      'it': 'Dica',
      // Outros idiomas...
    };
    
    return prompts[language] || prompts['en'];
  }
  
  /**
   * Obtém o sufixo para frases de ajuda baseado no idioma
   * @private
   * @param {string} language - Código do idioma
   * @returns {string} Sufixo localizado
   */
  getCommandSuffix(language) {
    const suffixes = {
      'en': 'to',
      'pt': 'para',
      'es': 'para',
      'fr': 'pour',
      'de': 'um zu',
      'it': 'per',
      // Outros idiomas...
    };
    
    return suffixes[language] || suffixes['en'];
  }
  
  /**
   * Obtém comandos filtrados por tipo
   * @param {string} type - Tipo de comando (usar constantes COMMAND_TYPES)
   * @param {string} language - Código do idioma (opcional)
   * @returns {Object} Comandos do tipo especificado
   */
  getCommandsByType(type, language = null) {
    const targetLanguage = language || this.currentLanguage;
    const commands = this.getRegisteredCommands(targetLanguage);
    
    return commands[type] || {};
  }
  
  /**
   * Executa um comando de voz manualmente (útil para testes)
   * @param {string} commandText - Texto do comando
   * @param {string} language - Código do idioma (opcional)
   * @returns {boolean} True se o comando foi reconhecido e executado
   */
  executeCommand(commandText, language = null) {
    const targetLanguage = language || this.currentLanguage;
    
    // Simula o reconhecimento com confiança máxima
    this.currentLanguage = targetLanguage;
    this.processRecognizedText(commandText.toLowerCase(), 1.0);
    
    // Retorna true se o estado final for SUCCESS
    return this.recognitionState === RECOGNITION_STATES.SUCCESS;
  }
  
  /**
   * Importa conjunto de comandos a partir de um arquivo de configuração
   * @param {Object} commandsConfig - Objeto com configurações de comandos
   * @returns {number} Quantidade de comandos importados
   */
  importCommands(commandsConfig) {
    if (!commandsConfig || typeof commandsConfig !== 'object') {
      console.error('[VoiceCommandListener] Configuração de comandos inválida');
      return 0;
    }
    
    let importCount = 0;
    
    try {
      // Estrutura esperada:
      // { language: { commandType: { phrase: { action, params, values, description } } } }
      for (const language in commandsConfig) {
        const languageCommands = commandsConfig[language];
        
        for (const type in languageCommands) {
          const typeCommands = languageCommands[type];
          
          for (const phrase in typeCommands) {
            const commandData = typeCommands[phrase];
            
            const registered = this.registerCommand(
              language,
              type,
              phrase,
              {
                action: commandData.action,
                params: commandData.params,
                values: commandData.values
              },
              commandData.description
            );
            
            if (registered) {
              importCount++;
            }
          }
        }
      }
      
      console.log(`[VoiceCommandListener] ${importCount} comandos importados com sucesso`);
    } catch (error) {
      console.error('[VoiceCommandListener] Erro ao importar comandos:', error);
    }
    
    return importCount;
  }
  
  /**
   * Exporta todos os comandos registrados
   * @returns {Object} Objeto com todos os comandos registrados
   */
  exportCommands() {
    return { ...this.registeredCommands };
  }
  
  /**
   * Treina o sistema para reconhecer melhor a voz do usuário
   * (Implementação simulada - em sistemas reais, isso dependeria da plataforma)
   * @returns {Promise<boolean>} Promise resolvida com true se o treinamento foi bem-sucedido
   */
  trainVoiceRecognition() {
    return new Promise((resolve, reject) => {
      console.log('[VoiceCommandListener] Iniciando treinamento de reconhecimento de voz...');
      
      // Aqui teríamos a lógica específica de cada plataforma para melhorar o reconhecimento
      
      // Simulação de processo de treinamento
      setTimeout(() => {
        console.log('[VoiceCommandListener] Treinamento de voz concluído');
        resolve(true);
      }, 2000);
    });
  }
  
  /**
   * Limpa todos os comandos registrados
   * @param {string} language - Código do idioma (se null, limpa todos os idiomas)
   * @param {string} type - Tipo de comando (se null, limpa todos os tipos)
   */
  clearCommands(language = null, type = null) {
    if (language && type) {
      // Limpa comandos específicos de um idioma e tipo
      if (this.registeredCommands[language] && this.registeredCommands[language][type]) {
        this.registeredCommands[language][type] = {};
      }
    } else if (language) {
      // Limpa todos os comandos de um idioma
      if (this.registeredCommands[language]) {
        Object.values(COMMAND_TYPES).forEach(cmdType => {
          this.registeredCommands[language][cmdType] = {};
        });
      }
    } else {
      // Limpa todos os comandos de todos os idiomas
      Object.keys(this.registeredCommands).forEach(lang => {
        Object.values(COMMAND_TYPES).forEach(cmdType => {
          this.registeredCommands[lang][cmdType] = {};
        });
      });
    }
  }
}

// Exporta constantes úteis junto com a classe
export { COMMAND_TYPES, RECOGNITION_STATES };

export default VoiceCommandListener;