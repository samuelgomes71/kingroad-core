// group.model.js
// Modelo de dados para grupos no KingChat

const mongoose = require('mongoose');

const GroupSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    default: '',
    trim: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  members: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  avatar: {
    type: String,
    default: null
  },
  isActive: {
    type: Boolean,
    default: true
  },
  settings: {
    onlyAdminsCanSendMessages: {
      type: Boolean,
      default: false
    },
    memberCanAddPeople: {
      type: Boolean,
      default: true
    }
  },
  admins: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  lastMessageAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Índice para melhorar a performance das consultas
GroupSchema.index({ createdBy: 1 });
GroupSchema.index({ members: 1 });
GroupSchema.index({ lastMessageAt: -1 });
GroupSchema.index({ name: 'text', description: 'text' });

// Método para verificar se um usuário é membro do grupo
GroupSchema.methods.isMember = function(userId) {
  return this.members.some(member => 
    member.toString() === userId.toString()
  );
};

// Método para verificar se um usuário é administrador do grupo
GroupSchema.methods.isAdmin = function(userId) {
  return this.admins.some(admin => 
    admin.toString() === userId.toString()
  ) || this.createdBy.toString() === userId.toString();
};

// Método para adicionar membros ao grupo
GroupSchema.methods.addMembers = function(userIds) {
  const newMembers = [];
  
  for (const userId of userIds) {
    // Verifica se o usuário já é membro
    if (!this.isMember(userId)) {
      this.members.push(userId);
      newMembers.push(userId);
    }
  }
  
  return newMembers;
};

// Método para remover membros do grupo
GroupSchema.methods.removeMembers = function(userIds) {
  this.members = this.members.filter(member => 
    !userIds.includes(member.toString())
  );
  
  // Remover também de administradores se for o caso
  this.admins = this.admins.filter(admin => 
    !userIds.includes(admin.toString())
  );
};

// Hook para garantir que o criador também seja administrador
GroupSchema.pre('save', function(next) {
  // Adiciona o criador como admin se ainda não for
  if (!this.isAdmin(this.createdBy)) {
    this.admins.push(this.createdBy);
  }
  
  // Garante que o criador seja membro
  if (!this.isMember(this.createdBy)) {
    this.members.push(this.createdBy);
  }
  
  next();
});

module.exports = mongoose.model('Group', GroupSchema);