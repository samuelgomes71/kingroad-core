import React, { useState, useEffect } from 'react';
import { AlertTriangle, Truck, Check, X, Watch, TrendingDown, Disc, Activity, User, Users } from 'lucide-react';

const SerraAlertSequence = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [simulationStage, setSimulationStage] = useState(0);
  const [isLoaded, setIsLoaded] = useState(null);
  const [currentSpeed, setCurrentSpeed] = useState(60);
  const [recommendedSpeed, setRecommendedSpeed] = useState(30);
  const [ignoreWarnings, setIgnoreWarnings] = useState(false);
  const [showTriangle, setShowTriangle] = useState(false);
  const [triangleType, setTriangleType] = useState('warning');
  const [alertMessage, setAlertMessage] = useState('');
  const [showStatistics, setShowStatistics] = useState(false);
  const [statIndex, setStatIndex] = useState(0);
  const [alertCount, setAlertCount] = useState(0);
  
  // Informações da serra
  const serraInfo = {
    name: "Serra da Cantareira - SP",
    length: "12 km",
    avgDeclive: "8%",
    maxDeclive: "12%",
    dangerPoints: 5,
    accidents: 26,
    fatalAccidents: 7,
    startAltitude: "1200m",
    endAltitude: "800m"
  };
  
  // Estatísticas de acidentes para mostrar em caso de velocidade excessiva persistente
  const accidentStats = [
    {
      location: "Km 84 - Curva do Mirante",
      description: "Motorista de caminhão carregado perdeu o controle após superaquecimento dos freios. Deixou 3 filhos pequenos.",
      date: "15/03/2023",
      type: "Fatal"
    },
    {
      location: "Km 78 - Curva da Onça",
      description: "Caminhão bateu na mureta de proteção. Motorista ficou 4 meses hospitalizado, sem poder trabalhar ou ver a família.",
      date: "22/11/2022",
      type: "Grave"
    },
    {
      location: "Km 82 - Trecho de Declive Acentuado",
      description: "Caminhoneiro tentou descer em 6ª marcha. Freios falharam completamente. 2 vítimas fatais na colisão com outro veículo.",
      date: "05/07/2023",
      type: "Fatal"
    },
    {
      location: "Km 86 - Entrada da Serra",
      description: "Motorista inexperiente deixou o caminhão 'embalar'. A esposa grávida de 7 meses nunca conheceu o filho.",
      date: "12/01/2023",
      type: "Fatal"
    },
    {
      location: "Km 80 - Curva Fechada",
      description: "Caminhão tombou sobre carro de passeio. Uma família inteira partiu. Freios completamente queimados.",
      date: "03/09/2022",
      type: "Fatal"
    }
  ];
  
  // Configurações de velocidade baseadas no estado de carga
  useEffect(() => {
    if (isLoaded !== null) {
      if (isLoaded) {
        // Caminhão carregado
        setRecommendedSpeed(30);
      } else {
        // Caminhão vazio
        setRecommendedSpeed(40);
      }
    }
  }, [isLoaded]);
  
  // Efeito para simular a sequência de alertas
  useEffect(() => {
    const simulationControl = () => {
      switch (simulationStage) {
        case 0: // Início da simulação
          console.log("Iniciando simulação");
          setSimulationStage(1);
          break;
          
        case 1: // 200m antes da descida - Mostrar triângulo amarelo por 3 segundos
          console.log("200m antes: Triângulo amarelo");
          setShowTriangle(true);
          setTriangleType('warning');
          setAlertMessage('ATENÇÃO! DESCIDA DE SERRA À FRENTE');
          setTimeout(() => {
            setShowTriangle(false);
            setSimulationStage(2);
          }, 3000);
          break;
          
        case 2: // Pergunta sobre carga
          console.log("Pergunta sobre carga");
          setSimulationStage(3);
          break;
          
        case 3: // Aguardando resposta sobre carga
          // Permanece neste estágio até que isLoaded seja definido
          if (isLoaded !== null) {
            console.log(`Resposta recebida: Caminhão ${isLoaded ? 'carregado' : 'vazio'}`);
            setSimulationStage(4);
          }
          break;
          
        case 4: // Mostrar recomendações iniciais baseadas no estado de carga
          console.log("Mostrando recomendações baseadas na carga");
          setTimeout(() => {
            setSimulationStage(5);
          }, 5000);
          break;
          
        case 5: // Monitoramento de velocidade
          console.log("Monitorando velocidade");
          // Criar um timer que periodicamente verifica a velocidade
          const speedCheckTimer = setInterval(() => {
            if (currentSpeed > recommendedSpeed * 1.2) {
              // Velocidade excessiva
              setAlertCount(prev => prev + 1);
              
              if (alertCount > 3) {
                // Vários alertas ignorados, iniciar alertas vermelhos
                clearInterval(speedCheckTimer);
                setSimulationStage(6);
              } else {
                // Mostrar alerta de velocidade
                setShowTriangle(true);
                setTriangleType('warning');
                setAlertMessage(`REDUZA A VELOCIDADE! Limite seguro: ${recommendedSpeed} km/h`);
                setTimeout(() => {
                  setShowTriangle(false);
                }, 3000);
              }
            }
          }, 5000);
          
          // Limpar timer se o componente for desmontado ou estágio mudar
          return () => clearInterval(speedCheckTimer);
          
        case 6: // Alertas vermelhos a cada 100m
          console.log("Iniciando alertas críticos");
          setShowTriangle(true);
          setTriangleType('danger');
          setAlertMessage('PERIGO! VELOCIDADE CRÍTICA. REDUZA IMEDIATAMENTE!');
          
          setTimeout(() => {
            setShowTriangle(false);
            setSimulationStage(7);
          }, 5000);
          break;
          
        case 7: // Mostrar estatísticas de acidentes
          console.log("Mostrando estatísticas de acidentes");
          setShowStatistics(true);
          
          // Avançar para o próximo acidente a cada 8 segundos
          const statTimer = setInterval(() => {
            setStatIndex(prev => {
              if (prev >= accidentStats.length - 1) {
                clearInterval(statTimer);
                setSimulationStage(8);
                setShowStatistics(false);
                return 0;
              }
              return prev + 1;
            });
          }, 8000);
          
          return () => clearInterval(statTimer);
          
        case 8: // Reiniciar ciclo de alertas vermelhos e estatísticas
          console.log("Reiniciando ciclo de alertas críticos");
          setTimeout(() => {
            setSimulationStage(6);
          }, 3000);
          break;
          
        default:
          break;
      }
    };
    
    simulationControl();
  }, [simulationStage, isLoaded, currentSpeed, recommendedSpeed, alertCount, statIndex]);
  
  // Renderização do triângulo de alerta (amarelo ou vermelho)
  const renderTriangle = () => {
    if (!showTriangle) return null;
    
    const colors = {
      warning: {
        background: '#ffee00',
        triangle: '#111111',
        text: '#111111'
      },
      danger: {
        background: '#ff5500',
        triangle: '#331111',
        text: '#ffffff'
      }
    };
    
    const selectedColors = colors[triangleType] || colors.warning;
    
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center flex-col"
        style={{ backgroundColor: selectedColors.background }}
      >
        <div className="w-64 h-64 mb-8">
          <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
            <path 
              d="M50,10 L90,90 L10,90 Z" 
              fill={selectedColors.triangle} 
            />
            <path 
              d="M50,30 L50,60 L50,60 Z" 
              fill={selectedColors.background} 
              stroke={selectedColors.background} 
              strokeWidth="10" 
              strokeLinecap="round" 
            />
            <circle 
              cx="50" 
              cy="75" 
              r="5" 
              fill={selectedColors.background} 
            />
          </svg>
        </div>
        
        <div 
          className="text-center text-2xl font-bold max-w-xl px-6"
          style={{ color: selectedColors.text }}
        >
          {alertMessage}
        </div>
      </div>
    );
  };
  
  // Renderização da pergunta sobre carga
  const renderLoadQuestion = () => {
    if (simulationStage !== 2 || isLoaded !== null) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
        <div className="bg-red-900 rounded-lg shadow-lg max-w-md w-full p-6 animate-pulse">
          <div className="flex items-center justify-center mb-4">
            <TrendingDown className="w-16 h-16 text-yellow-400" />
          </div>
          
          <h2 className="text-2xl font-bold text-center text-white mb-6">
            VOCÊ ESTÁ CARREGADO?
          </h2>
          
          <div className="text-center mb-6 text-yellow-200">
            <p>Você está prestes a descer a {serraInfo.name}</p>
            <p>Declive médio: {serraInfo.avgDeclive} • Extensão: {serraInfo.length}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => setIsLoaded(true)}
              className="py-4 bg-yellow-600 hover:bg-yellow-700 text-white text-xl font-bold rounded-lg transition-colors flex items-center justify-center"
            >
              <Truck className="w-6 h-6 mr-2" />
              SIM
            </button>
            
            <button 
              onClick={() => setIsLoaded(false)}
              className="py-4 bg-blue-600 hover:bg-blue-700 text-white text-xl font-bold rounded-lg transition-colors flex items-center justify-center"
            >
              <Check className="w-6 h-6 mr-2" />
              NÃO
            </button>
          </div>
          
          <div className="mt-6 text-center text-yellow-200 text-sm">
            <p>Esta informação é crucial para sua segurança</p>
            <p>e a de outros motoristas.</p>
          </div>
        </div>
      </div>
    );
  };
  
  // Renderização das recomendações de marcha e velocidade
  const renderRecommendations = () => {
    if (simulationStage < 4 || simulationStage > 5) return null;
    
    return (
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-6`}>
        <div className={`p-4 ${isLoaded ? 'bg-red-900' : 'bg-yellow-800'} rounded-lg text-white mb-4`}>
          <div className="flex items-start">
            <AlertTriangle className="w-6 h-6 mr-2 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-lg font-bold">
                {isLoaded ? 'CAMINHÃO CARREGADO - ATENÇÃO REDOBRADA!' : 'CAMINHÃO VAZIO - MANTENHA ATENÇÃO'}
              </h2>
              <p className="text-sm mt-1">
                {isLoaded 
                  ? 'Use a mesma marcha que você usaria para subir esta serra.' 
                  : 'Mesmo vazio, mantenha-se em marcha reduzida.'}
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="p-3 bg-gray-700 rounded-lg">
            <div className="text-xs text-gray-400 mb-1">Velocidade Máxima:</div>
            <div className="text-2xl font-bold text-white">
              {recommendedSpeed} <span className="text-sm">km/h</span>
            </div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg">
            <div className="text-xs text-gray-400 mb-1">Marcha Recomendada:</div>
            <div className="text-2xl font-bold text-white">
              {isLoaded ? '3ª' : '4ª'} marcha
            </div>
          </div>
        </div>
        
        <div className="p-3 bg-gray-700 rounded-lg">
          <div className="flex items-center text-white">
            <Watch className="w-5 h-5 mr-2 text-yellow-400" />
            <span className="text-sm">
              {isLoaded 
                ? 'Monitore temperatura dos freios constantemente. Use freio motor.' 
                : 'Mantenha distância segura. Evite frenagens bruscas.'}
            </span>
          </div>
        </div>
      </div>
    );
  };
  
  // Renderização das estatísticas de acidentes
  const renderAccidentStatistics = () => {
    if (!showStatistics) return null;
    
    const accident = accidentStats[statIndex];
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
        <div className="bg-red-900 rounded-lg shadow-lg max-w-md w-full p-6 animate-pulse">
          <div className="flex items-start mb-4">
            <Activity className="w-10 h-10 text-red-400 mr-3 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold text-white">ACIDENTE NESTA SERRA</h2>
              <p className="text-yellow-200 text-sm">{accident.location} • {accident.date}</p>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-black bg-opacity-40 rounded-lg">
            <p className="text-white text-lg mb-3">{accident.description}</p>
            
            <div className="flex items-center">
              {accident.type === 'Fatal' ? (
                <Users className="w-6 h-6 text-red-400 mr-2" />
              ) : (
                <User className="w-6 h-6 text-orange-400 mr-2" />
              )}
              <span className={`px-3 py-1 rounded ${accident.type === 'Fatal' ? 'bg-red-700 text-white' : 'bg-orange-700 text-white'}`}>
                {accident.type}
              </span>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <div className="text-lg font-bold text-white mb-2">
              VOCÊ É O PRÓXIMO?
            </div>
            <p className="text-yellow-200 text-sm">
              Reduza a velocidade para {recommendedSpeed} km/h e use a {isLoaded ? '3ª' : '4ª'} marcha
            </p>
          </div>
        </div>
      </div>
    );
  };
  
  // Painel de simulação para controlar o fluxo da demonstração
  const renderSimulationControls = () => {
    return (
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-6`}>
        <h2 className="text-lg font-medium mb-4">Controles de Simulação</h2>
        
        <div className="flex items-center justify-between mb-6">
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Velocidade Atual</div>
            <div 
              className={`text-4xl font-bold ${currentSpeed > recommendedSpeed ? 'text-red-500' : 'text-green-500'}`}
            >
              {currentSpeed}
              <span className="text-sm ml-1">km/h</span>
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Estágio Atual</div>
            <div className="text-xl font-bold text-blue-500">
              {simulationStage}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <button 
            onClick={() => setCurrentSpeed(Math.max(10, currentSpeed - 5))}
            className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
          >
            Reduzir Velocidade (-5)
          </button>
          
          <button 
            onClick={() => setCurrentSpeed(Math.min(100, currentSpeed + 5))}
            className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
          >
            Aumentar Velocidade (+5)
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => setSimulationStage(1)}
            className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg"
          >
            Iniciar Sequência
          </button>
          
          <button 
            onClick={() => {
              setSimulationStage(0);
              setIsLoaded(null);
              setShowTriangle(false);
              setShowStatistics(false);
              setAlertCount(0);
            }}
            className="p-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
          >
            Reiniciar
          </button>
        </div>
        
        {isLoaded !== null && (
          <div className="mt-4 p-3 bg-gray-700 rounded-lg text-center">
            <p className="text-sm text-white">
              Status do caminhão: <span className="font-bold">{isLoaded ? 'CARREGADO' : 'VAZIO'}</span>
            </p>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className={`${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'} min-h-screen p-4`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-6 border-b border-gray-700 pb-3">
        <div className="flex items-center">
          <TrendingDown className="w-6 h-6 mr-2 text-red-500" />
          <h1 className="text-xl font-bold">King Road - Sequência de Alertas para Serra</h1>
        </div>
      </div>
      
      {/* Renders dos elementos de interface baseados no estágio atual */}
      {renderSimulationControls()}
      {renderRecommendations()}
      {renderTriangle()}
      {renderLoadQuestion()}
      {renderAccidentStatistics()}
      
      {/* Informações da serra atual */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4`}>
        <h2 className="text-lg font-medium mb-4">Informações da Serra</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Nome</div>
            <div className="font-medium">{serraInfo.name}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Extensão</div>
            <div className="font-medium">{serraInfo.length}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Declive Médio</div>
            <div className="font-medium">{serraInfo.avgDeclive}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Declive Máximo</div>
            <div className="font-medium">{serraInfo.maxDeclive}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Pontos Perigosos</div>
            <div className="font-medium">{serraInfo.dangerPoints}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Acidentes</div>
            <div className="font-medium">{serraInfo.accidents} ({serraInfo.fatalAccidents} fatais)</div>
          </div>
        </div>
        
        <div className="p-3 bg-blue-900/30 rounded-lg text-sm">
          <p>
            Esta demonstração simula a sequência de alertas que serão mostrados durante a descida da serra, incluindo:
          </p>
          <ul className="mt-2 space-y-1 list-disc pl-5">
            <li>Alerta inicial 200m antes da descida (triângulo amarelo por 3 segundos)</li>
            <li>Pergunta sobre o estado de carga do caminhão</li>
            <li>Recomendações específicas baseadas na resposta</li>
            <li>Monitoramento contínuo da velocidade</li>
            <li>Alertas intensificados (triângulo vermelho) se velocidade excessiva persistir</li>
            <li>Estatísticas de acidentes reais para conscientização</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SerraAlertSequence;