// PowerButton.jsx
import React, { useState, useEffect, useRef } from 'react';

/**
 * Botão de desligamento rápido para o aplicativo King Road
 * ID do componente: 8501 (seguindo o sistema de IDs numéricos)
 */
const PowerButton = () => {
  const [pressing, setPressing] = useState(false);
  const timerRef = useRef(null);
  const buttonRef = useRef(null);
  
  // Função para desligar o aplicativo
  const shutdownApp = () => {
    console.log("Desligando aplicativo imediatamente");
    
    // Limpar cache mantendo apenas as duas últimas viagens
    clearCacheExceptLastTrips();
    
    // Chamar API nativa para encerrar o aplicativo
    // Dependendo da plataforma, usamos diferentes métodos
    if (window.KingRoadNative) {
      if (window.KingRoadNative.isAndroid) {
        window.KingRoadNative.exitApplication();
      } else if (window.KingRoadNative.isIOS) {
        window.KingRoadNative.terminateApp();
      } else if (window.KingRoadNative.isWindows) {
        window.KingRoadNative.closeApplication();
      }
    }
  };
  
  // Função para limpar o cache exceto as duas últimas viagens
  const clearCacheExceptLastTrips = () => {
    console.log("Limpando cache e preservando apenas as duas últimas viagens");
    
    // Implementação da lógica de limpeza do cache
    if (window.KingRoadNative && window.KingRoadNative.cacheManager) {
      window.KingRoadNative.cacheManager.clearCacheKeepingLastTrips(2);
    }
  };
  
  // Iniciar contagem ao pressionar
  const handlePressStart = () => {
    setPressing(true);
    timerRef.current = setTimeout(() => {
      shutdownApp();
    }, 3000); // 3 segundos
  };
  
  // Cancelar contagem ao soltar
  const handlePressEnd = () => {
    setPressing(false);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
  };
  
  // Cleanup no unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);
  
  // Prevenção contra cliques acidentais - adiciona proteção de "dead zone" ao redor do botão
  useEffect(() => {
    const button = buttonRef.current;
    if (button) {
      const createDeadZone = () => {
        const rect = button.getBoundingClientRect();
        const deadZone = document.createElement('div');
        deadZone.style.position = 'absolute';
        deadZone.style.left = `${rect.left - 10}px`;
        deadZone.style.top = `${rect.top - 10}px`;
        deadZone.style.width = `${rect.width + 20}px`;
        deadZone.style.height = `${rect.height + 20}px`;
        deadZone.style.zIndex = '998';
        deadZone.style.pointerEvents = 'none';
        document.body.appendChild(deadZone);
        
        return deadZone;
      };
      
      const deadZone = createDeadZone();
      
      // Observer para reposicionar a zona morta quando necessário
      const observer = new ResizeObserver(() => {
        const rect = button.getBoundingClientRect();
        deadZone.style.left = `${rect.left - 10}px`;
        deadZone.style.top = `${rect.top - 10}px`;
      });
      
      observer.observe(document.body);
      
      return () => {
        observer.disconnect();
        if (deadZone && deadZone.parentNode) {
          deadZone.parentNode.removeChild(deadZone);
        }
      };
    }
  }, []);
  
  return (
    <div 
      ref={buttonRef}
      className={`fixed top-4 left-4 z-999 w-12 h-12 rounded-full flex items-center justify-center shadow-lg ${
        pressing ? 'bg-red-800 scale-95' : 'bg-red-600 hover:bg-red-700'
      } transition-all duration-300`}
      onTouchStart={handlePressStart}
      onMouseDown={handlePressStart}
      onTouchEnd={handlePressEnd}
      onTouchCancel={handlePressEnd}
      onMouseUp={handlePressEnd}
      onMouseLeave={handlePressEnd}
      id="power-button-8501"
    >
      <div className={`w-6 h-6 rounded-full border-4 border-white relative ${
        pressing ? 'opacity-70' : 'opacity-100'
      }`}>
        <div className="absolute w-2 h-4 bg-white top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
      </div>
      
      {pressing && (
        <svg 
          className="absolute inset-0 w-full h-full" 
          viewBox="0 0 48 48"
        >
          <circle 
            cx="24" 
            cy="24" 
            r="18" 
            fill="none" 
            stroke="white" 
            strokeWidth="3" 
            strokeDasharray="113" 
            strokeDashoffset="113" 
            transform="rotate(-90 24 24)"
            style={{
              animation: 'countdown 3s linear forwards'
            }}
          />
        </svg>
      )}
      
      <style jsx>{`
        @keyframes countdown {
          from {
            stroke-dashoffset: 113;
          }
          to {
            stroke-dashoffset: 0;
          }
        }
      `}</style>
    </div>
  );
};

export default PowerButton;