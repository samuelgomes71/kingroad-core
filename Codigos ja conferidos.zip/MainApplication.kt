// MainApplication.kt (modificação)
package com.kingroad

import com.facebook.react.ReactApplication
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.soloader.SoLoader
import com.kingroad.native.PowerButtonPackage

class MainApplication : Application(), ReactApplication {
    private val reactNativeHost = object : DefaultReactNativeHost(this) {
        override fun getPackages(): List<ReactPackage> {
            val packages = PackageList(this).packages.toMutableList()
            
            // Adicionar pacotes nativos
            packages.add(PowerButtonPackage())
            packages.add(TripManagerPackage())
            
            return packages
        }
        
        // Outras configurações...
    }
    
    // Resto da implementação...
}