/**
 * AIAssistant.js
 * 
 * Assistente de IA para o aplicativo KingRoad
 * Oferece suporte e dicas personalizadas para o usuário
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Animated,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import LocaleService from '../services/LocaleService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import AIService from '../services/AIService';
import { useTheme } from '../contexts/ThemeContext';

const AIAssistant = ({ navigation }) => {
  const { theme } = useTheme();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [assistantConfig, setAssistantConfig] = useState(null);
  const scrollViewRef = useRef();
  const bubbleAnimation = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    loadAssistantConfig();
    addWelcomeMessage();

    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega configurações ao mudar o idioma
      loadAssistantConfig();
      // Adiciona mensagem informando sobre a mudança de idioma
      addSystemMessage(t('ai_assistant.language_changed'));
    });
    
    // Simula animação de digitação para a mensagem de boas-vindas
    Animated.timing(bubbleAnimation, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);

  const loadAssistantConfig = async () => {
    try {
      // Obtém configurações do assistente baseadas na região atual
      const region = LocaleService.getCurrentRegion();
      const config = await AIService.getAssistantConfiguration(region);
      setAssistantConfig(config);
    } catch (error) {
      console.error('Erro ao carregar configurações do assistente:', error);
      // Usa configuração padrão em caso de erro
      setAssistantConfig({
        name: t('ai_assistant.default_name'),
        avatar: require('../assets/assistant-default.png'),
        greeting: t('ai_assistant.default_greeting'),
        personality: 'helpful'
      });
    }
  };

  const addWelcomeMessage = () => {
    // Adiciona mensagem de boas-vindas baseada no horário do dia
    const hour = new Date().getHours();
    let greeting;
    
    if (hour < 12) {
      greeting = t('ai_assistant.greeting_morning');
    } else if (hour < 18) {
      greeting = t('ai_assistant.greeting_afternoon');
    } else {
      greeting = t('ai_assistant.greeting_evening');
    }
    
    const welcomeMessage = {
      id: 'welcome',
      text: greeting,
      sender: 'assistant',
      timestamp: new Date()
    };
    
    setMessages([welcomeMessage]);
  };

  const addSystemMessage = (text) => {
    const newMessage = {
      id: Date.now().toString(),
      text,
      sender: 'system',
      timestamp: new Date()
    };
    
    setMessages(prevMessages => [...prevMessages, newMessage]);
    scrollToBottom();
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;
    
    const userMessage = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setInputText('');
    scrollToBottom();
    
    // Simula digitação do assistente
    setLoading(true);
    
    try {
      // Envia mensagem para o serviço de IA
      const response = await AIService.sendMessage(inputText, LocaleService.getCurrentLocale());
      
      // Pequeno atraso para simular a digitação
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const assistantMessage = {
        id: Date.now().toString(),
        text: response.text,
        sender: 'assistant',
        timestamp: new Date(),
        suggestions: response.suggestions || []
      };
      
      setMessages(prevMessages => [...prevMessages, assistantMessage]);
      setLoading(false);
      scrollToBottom();
      
      // Anima a bolha de mensagem
      Animated.timing(bubbleAnimation, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } catch (error) {
      console.error('Erro ao processar mensagem:', error);
      
      // Adiciona mensagem de erro
      const errorMessage = {
        id: Date.now().toString(),
        text: t('ai_assistant.error_processing'),
        sender: 'system',
        timestamp: new Date()
      };
      
      setMessages(prevMessages => [...prevMessages, errorMessage]);
      setLoading(false);
      scrollToBottom();
    }
  };

  const handleSuggestionPress = (suggestion) => {
    setInputText(suggestion);
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString(LocaleService.getCurrentLocale(), { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const renderMessage = (message, index) => {
    const isUser = message.sender === 'user';
    const isSystem = message.sender === 'system';
    
    if (isSystem) {
      // Mensagem de sistema (informativa)
      return (
        <View key={message.id} style={styles.systemMessageContainer}>
          <Text style={[styles.systemMessageText, { color: theme.textSecondary }]}>
            {message.text}
          </Text>
        </View>
      );
    }
    
    // Estilo baseado no remetente (usuário ou assistente)
    const containerStyle = isUser ? 
      [styles.userMessageContainer, { backgroundColor: theme.primary }] : 
      [styles.assistantMessageContainer, { backgroundColor: theme.card }];
    
    const textStyle = isUser ? 
      [styles.userMessageText, { color: theme.textLight }] : 
      [styles.assistantMessageText, { color: theme.text }];
    
    const timeStyle = isUser ?
      [styles.messageTime, { color: 'rgba(255, 255, 255, 0.7)' }] :
      [styles.messageTime, { color: theme.textSecondary }];
    
    // Animação apenas para a última mensagem do assistente
    const isLastAssistantMessage = !isUser && 
      index === messages.length - 1 && 
      !loading;
    
    const animationStyle = isLastAssistantMessage ? {
      opacity: bubbleAnimation,
      transform: [{
        translateY: bubbleAnimation.interpolate({
          inputRange: [0, 1],
          outputRange: [20, 0]
        })
      }]
    } : {};
    
    return (
      <Animated.View key={message.id} style={[containerStyle, animationStyle]}>
        {!isUser && assistantConfig && (
          <Image 
            source={assistantConfig.avatar || require('../assets/assistant-default.png')} 
            style={styles.avatar} 
          />
        )}
        <View style={styles.messageContentContainer}>
          <Text style={textStyle}>{message.text}</Text>
          <Text style={timeStyle}>{formatTime(message.timestamp)}</Text>
          
          {/* Sugestões de resposta rápida */}
          {!isUser && message.suggestions && message.suggestions.length > 0 && (
            <View style={styles.suggestionsContainer}>
              {message.suggestions.map((suggestion, i) => (
                <TouchableOpacity
                  key={`suggestion-${i}`}
                  style={[styles.suggestionButton, { backgroundColor: theme.primaryLight }]}
                  onPress={() => handleSuggestionPress(suggestion)}
                >
                  <Text style={[styles.suggestionText, { color: theme.primary }]}>
                    {suggestion}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Cabeçalho */}
      <View style={[styles.header, { backgroundColor: theme.card }]}>
        <View style={styles.assistantInfo}>
          {assistantConfig && (
            <Image 
              source={assistantConfig.avatar || require('../assets/assistant-default.png')} 
              style={styles.headerAvatar} 
            />
          )}
          <View>
            <Text style={[styles.assistantName, { color: theme.text }]}>
              {assistantConfig?.name || t('ai_assistant.default_name')}
            </Text>
            <Text style={[styles.assistantStatus, { color: theme.success }]}>
              {t('ai_assistant.online')}
            </Text>
          </View>
        </View>
        
        <TouchableOpacity 
          style={styles.settingsButton}
          onPress={() => navigation.navigate('AssistantSettings')}
        >
          <Icon name="settings" size={24} color={theme.textSecondary} />
        </TouchableOpacity>
      </View>
      
      {/* Lista de mensagens */}
      <ScrollView 
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
      >
        {messages.map(renderMessage)}
        
        {/* Indicador de digitação */}
        {loading && (
          <View style={[styles.typingIndicator, { backgroundColor: theme.card }]}>
            <Image 
              source={assistantConfig?.avatar || require('../assets/assistant-default.png')} 
              style={styles.typingAvatar} 
            />
            <ActivityIndicator size="small" color={theme.primary} style={styles.typingAnimation} />
          </View>
        )}
      </ScrollView>
      
      {/* Campo de entrada de mensagem */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <View style={[styles.inputContainer, { backgroundColor: theme.card }]}>
          <TextInput
            style={[styles.textInput, { backgroundColor: theme.inputBackground, color: theme.text }]}
            placeholder={t('ai_assistant.type_message')}
            placeholderTextColor={theme.textSecondary}
            value={inputText}
            onChangeText={setInputText}
            multiline
          />
          <TouchableOpacity 
            style={[styles.sendButton, { backgroundColor: theme.primary }]}
            onPress={handleSendMessage}
            disabled={!inputText.trim()}
          >
            <Icon name="send" size={20} color="white" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  assistantInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  assistantName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  assistantStatus: {
    fontSize: 12,
  },
  settingsButton: {
    padding: 8,
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    paddingBottom: 24,
  },
  systemMessageContainer: {
    alignItems: 'center',
    marginVertical: 8,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 12,
    alignSelf: 'center',
  },
  systemMessageText: {
    fontSize: 12,
    fontStyle: 'italic',
  },
  userMessageContainer: {
    marginVertical: 8,
    padding: 12,
    borderRadius: 18,
    maxWidth: '80%',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  assistantMessageContainer: {
    flexDirection: 'row',
    marginVertical: 8,
    borderRadius: 18,
    maxWidth: '80%',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    margin: 8,
    alignSelf: 'flex-end',
  },
  messageContentContainer: {
    padding: 12,
    flex: 1,
  },
  userMessageText: {
    fontSize: 16,
  },
  assistantMessageText: {
    fontSize: 16,
  },
  messageTime: {
    fontSize: 10,
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  suggestionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  suggestionButton: {
    padding: 8,
    borderRadius: 16,
    marginRight: 8,
    marginTop: 8,
  },
  suggestionText: {
    fontSize: 12,
    fontWeight: '500',
  },
  typingIndicator: {
    flexDirection: 'row',
    padding: 8,
    borderRadius: 18,
    maxWidth: '50%',
    alignSelf: 'flex-start',
    marginVertical: 8,
    borderBottomLeftRadius: 4,
    alignItems: 'center',
  },
  typingAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  typingAnimation: {
    marginHorizontal: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    alignItems: 'center',
  },
  textInput: {
    flex: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginRight: 8,
    fontSize: 16,
    maxHeight: 120,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default AIAssistant;