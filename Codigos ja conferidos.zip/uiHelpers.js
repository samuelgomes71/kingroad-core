// utils/uiHelpers.js
import React from 'react';
import { Coffee, Info } from 'lucide-react';

export const getParkingStatusColor = (status) => {
  switch(status.toLowerCase()) {
    case 'many': return 'bg-emerald-500';
    case 'some': return 'bg-amber-500';
    case 'full': return 'bg-red-600';
    default: return 'bg-gray-500';
  }
};

export const getWeighStationStatusColor = (status) => {
  switch(status.toLowerCase()) {
    case 'open': return 'bg-emerald-100 text-emerald-600';
    case 'monitored': return 'bg-amber-100 text-amber-600';
    case 'closed': return 'bg-red-100 text-red-600';
    default: return 'bg-gray-100 text-gray-600';
  }
};

export const renderAmenityIcon = (amenity) => {
  switch(amenity) {
    case 'restaurant': return <Coffee size={16} />;
    case 'shower': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 6L6.5 3.5a1.5 1.5 0 0 0-1-.5C4.683 3 4 3.683 4 4.5V17a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5" /><line x1="7" y1="15" x2="8" y2="15" /><line x1="15" y1="15" x2="16" y2="15" /><line x1="7" y1="11" x2="16" y2="11" /><line x1="12" y1="7" x2="12" y2="15" /><path d="M16 3l-4 4-4-4" /></svg>;
    case 'fuel': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 2v17.5A2.5 2.5 0 0 0 11.5 22h1a2.5 2.5 0 0 0 2.5-2.5V2" /><path d="M14 8h2a2 2 0 0 1 2 2v3a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5" /></svg>;
    case 'wifi': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 13a10 10 0 0 1 14 0" /><path d="M8.5 16.5a5 5 0 0 1 7 0" /><path d="M2 8.82a15 15 0 0 1 20 0" /><line x1="12" y1="20" x2="12" y2="20" /></svg>;
    case 'mechanic': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" /></svg>;
    case 'atm': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" /><line x1="12" y1="15" x2="12" y2="15" /></svg>;
    case 'laundry': return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="12" cy="12" r="4" /><path d="M16 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" /></svg>;
    default: return <Info size={16} />;
  }
};