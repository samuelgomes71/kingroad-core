import React, { useState, useEffect } from 'react';
import { AlertCircle } from 'lucide-react';

const KingRoadSplashScreen = () => {
  const [loading, setLoading] = useState(true);
  
  // Simula carregamento inicial
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="relative h-screen w-full overflow-hidden bg-black">
      {/* Padrão de linhas douradas de fundo */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Linhas na parte superior */}
        {Array.from({ length: 20 }).map((_, index) => (
          <div 
            key={`top-${index}`} 
            className="absolute bg-gradient-to-r from-yellow-600/20 via-yellow-400 to-yellow-600/20"
            style={{
              height: '2px',
              width: '200%',
              top: `${index * 20}px`,
              left: '-50%',
              transform: `rotate(${15 + index}deg)`,
              opacity: 0.7
            }}
          />
        ))}
        
        {/* Linhas na parte inferior */}
        {Array.from({ length: 20 }).map((_, index) => (
          <div 
            key={`bottom-${index}`} 
            className="absolute bg-gradient-to-r from-yellow-600/20 via-yellow-400 to-yellow-600/20"
            style={{
              height: '2px',
              width: '200%',
              bottom: `${index * 20}px`,
              left: '-50%',
              transform: `rotate(${-15 - index}deg)`,
              opacity: 0.7
            }}
          />
        ))}
      </div>
      
      {/* Conteúdo Central */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
        {/* Logo Circular com K */}
        <div className="relative w-40 h-40 mb-6">
          {/* Círculos concêntricos */}
          <div className="absolute inset-0 rounded-full border-4 border-yellow-500 opacity-30"></div>
          <div className="absolute inset-2 rounded-full border-2 border-yellow-400 opacity-50"></div>
          <div className="absolute inset-4 rounded-full bg-black border border-yellow-600"></div>
          
          {/* Letra K */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-br from-yellow-300 via-yellow-500 to-yellow-700">K</span>
          </div>
          
          {/* Coroa */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/4">
            <svg width="60" height="30" viewBox="0 0 60 30" fill="none">
              <path d="M5 20 L15 5 L30 20 L45 5 L55 20 L30 30 Z" fill="url(#crownGradient)" />
              <defs>
                <linearGradient id="crownGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFE187" />
                  <stop offset="50%" stopColor="#D4AF37" />
                  <stop offset="100%" stopColor="#AF8C20" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          
          {/* Efeito de brilho em pontos específicos */}
          <div className="absolute top-0 left-1/4 w-2 h-2 rounded-full bg-yellow-300 animate-pulse"></div>
          <div className="absolute top-1/4 right-0 w-1 h-1 rounded-full bg-yellow-300 animate-pulse"></div>
          <div className="absolute bottom-0 right-1/4 w-1.5 h-1.5 rounded-full bg-yellow-300 animate-pulse"></div>
        </div>
        
        {/* Visualizador de áudio estilizado */}
        <div className="w-48 h-16 mb-12 flex items-end justify-center space-x-1">
          {Array.from({ length: 20 }).map((_, index) => {
            const height = Math.sin(index * 0.5) * 30 + Math.random() * 20;
            return (
              <div
                key={index}
                className="w-1 bg-gradient-to-t from-yellow-700 via-yellow-500 to-yellow-300"
                style={{ 
                  height: `${height}px`,
                  animationDelay: `${index * 0.1}s`,
                  animation: 'pulse 1.5s infinite'
                }}
              ></div>
            );
          })}
        </div>
        
        {/* Menu de ícones */}
        <div className="flex space-x-4 mt-auto mb-12">
          {['dashboard', 'list', 'map', 'settings', 'profile'].map((icon, index) => (
            <button 
              key={icon} 
              className="w-12 h-12 rounded-full bg-black border border-yellow-600 flex items-center justify-center text-yellow-500 hover:bg-yellow-900/20"
            >
              <IconPlaceholder index={index} />
            </button>
          ))}
        </div>
      </div>
      
      {/* Overlay de carregamento */}
      {loading && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-20">
          <div className="w-16 h-16 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
};

// Componente auxiliar para ícones
const IconPlaceholder = ({ index }) => {
  const icons = [
    <div className="grid grid-cols-2 gap-1 w-5 h-5">
      {[0,1,2,3].map(i => <div key={i} className="bg-yellow-500 rounded-sm"></div>)}
    </div>,
    <div className="flex flex-col space-y-1 w-5">
      {[0,1,2].map(i => <div key={i} className="h-1 bg-yellow-500 rounded-full"></div>)}
    </div>,
    <AlertCircle size={20} color="#eab308" />,
    <div className="w-5 h-5 flex items-center justify-center">
      <div className="w-4 h-4 border-2 border-yellow-500 rounded-full relative">
        <div className="absolute top-1/2 right-0 w-1.5 h-1 bg-yellow-500 transform translate-x-1/2 translate-y-1/2 rotate-45"></div>
      </div>
    </div>,
    <div className="w-5 h-5 rounded-full border-2 border-yellow-500 flex items-center justify-center">
      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
    </div>
  ];
  
  return icons[index];
};

// Adiciona animação global
const style = document.createElement('style');
style.textContent = `
  @keyframes pulse {
    0%, 100% { transform: scaleY(1); }
    50% { transform: scaleY(0.7); }
  }
`;
document.head.appendChild(style);

export default KingRoadSplashScreen;