data class BetaTester(
    val id: String,
    val name: String,
    val email: String,
    val country: String,
    val truckType: String,
    val activationCode: String,
    val validUntil: Long,
    val isFeedbackProvider: Boolean = false,
    val testingRegion: String
)

class BetaTestingSystem {
    private val betaTesters = mutableMapOf<String, BetaTester>()
    private val activationCodes = mutableMapOf<String, String>() // código -> id do tester

    fun generateActivationCode(region: String): String {
        // Gera um código de 8 caracteres com prefixo da região
        val prefix = when(region.uppercase()) {
            "EU" -> "EU"   // Europa
            "NA" -> "NA"   // América do Norte
            "BR" -> "BR"   // Brasil
            else -> "WW"   // Mundial
        }
        
        // Gera 6 caracteres aleatórios (números e letras)
        val chars = ('A'..'Z') + ('0'..'9')
        val randomPart = (1..6)
            .map { chars.random() }
            .joinToString("")
        
        return "${prefix}${randomPart}"
    }

    fun registerBetaTester(
        name: String,
        email: String,
        country: String,
        truckType: String,
        testingRegion: String
    ): BetaTester {
        val id = "BT${System.currentTimeMillis()}"
        val activationCode = generateActivationCode(testingRegion)
        
        // Beta válido por 90 dias
        val validUntil = System.currentTimeMillis() + (90L * 24 * 60 * 60 * 1000)
        
        val tester = BetaTester(
            id = id,
            name = name,
            email = email,
            country = country,
            truckType = truckType,
            activationCode = activationCode,
            validUntil = validUntil,
            testingRegion = testingRegion
        )
        
        betaTesters[id] = tester
        activationCodes[activationCode] = id
        
        return tester
    }

    fun validateActivationCode(code: String): Boolean {
        val testerId = activationCodes[code] ?: return false
        val tester = betaTesters[testerId] ?: return false
        
        // Verifica se o código ainda é válido
        return System.currentTimeMillis() < tester.validUntil
    }

    fun getTesterInfo(code: String): BetaTester? {
        val testerId = activationCodes[code] ?: return null
        return betaTesters[testerId]
    }

    fun extendBetaAccess(code: String, days: Int) {
        val testerId = activationCodes[code] ?: return
        betaTesters[testerId]?.let { tester ->
            betaTesters[testerId] = tester.copy(
                validUntil = tester.validUntil + (days * 24L * 60 * 60 * 1000)
            )
        }
    }

    // Sistema de relatórios de teste
    fun generateTestingReport(): Map<String, Int> {
        return betaTesters.values.groupBy { it.country }
            .mapValues { it.value.size }
    }
}

// Exemplo de uso:
fun main() {
    val betaSystem = BetaTestingSystem()
    
    // Registra um beta tester
    val tester = betaSystem.registerBetaTester(
        name = "João Silva",
        email = "joao@email.com",
        country = "BR",
        truckType = "Volvo FH",
        testingRegion = "BR"
    )
    
    // Código gerado para o tester: algo como "BR12AB34"
    println("Código de ativação: ${tester.activationCode}")
    
    // Validar o código
    val isValid = betaSystem.validateActivationCode(tester.activationCode)
    println("Código válido: $isValid")
    
    // Extender acesso beta por mais 30 dias
    betaSystem.extendBetaAccess(tester.activationCode, 30)
}