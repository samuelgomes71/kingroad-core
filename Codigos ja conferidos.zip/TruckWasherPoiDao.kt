package com.kingroad.database.dao

import androidx.room.*
import com.kingroad.poi.TruckWasherPoi

/**
 * Interface DAO para acessar a tabela de POIs de lavagem de veículos
 */
@Dao
interface TruckWasherPoiDao {
    
    /**
     * Insere um novo POI no banco de dados
     * @param poi O POI a ser inserido
     * @return ID do POI inserido
     */
    @Insert
    suspend fun insert(poi: TruckWasherPoi): Long
    
    /**
     * Insere vários POIs de uma vez
     * @param pois Lista de POIs a serem inseridos
     */
    @Insert
    suspend fun insertAll(pois: List<TruckWasherPoi>)
    
    /**
     * Atualiza um POI existente
     * @param poi O POI atualizado
     */
    @Update
    suspend fun update(poi: TruckWasherPoi)
    
    /**
     * Remove um POI
     * @param poi O POI a ser removido
     */
    @Delete
    suspend fun delete(poi: TruckWasherPoi)
    
    /**
     * Busca um POI pelo ID
     * @param id ID do POI
     * @return O POI encontrado ou null
     */
    @Query("SELECT * FROM truck_washer_pois WHERE id = :id")
    suspend fun findById(id: String): TruckWasherPoi?
    
    /**
     * Busca todos os POIs
     * @return Lista de todos os POIs
     */
    @Query("SELECT * FROM truck_washer_pois")
    suspend fun findAll(): List<TruckWasherPoi>
    
    /**
     * Busca POIs pelo modo de veículo
     * @param vehicleMode Modo de veículo (truck, car)
     * @return Lista de POIs do tipo especificado
     */
    @Query("SELECT * FROM truck_washer_pois WHERE vehicleMode = :vehicleMode")
    suspend fun findByVehicleMode(vehicleMode: String): List<TruckWasherPoi>
    
    /**
     * Busca POIs próximos a uma localização
     * Esta é uma função de consulta simplificada que seria implementada
     * com cálculos de distância mais complexos em uma versão real
     * 
     * @param lat Latitude central
     * @param lng Longitude central
     * @param radius Raio aproximado em graus
     * @return Lista de POIs dentro do raio
     */
    @Query("""
        SELECT * FROM truck_washer_pois 
        WHERE (latitude BETWEEN :lat - :radius AND :lat + :radius) 
        AND (longitude BETWEEN :lng - :radius AND :lng + :radius)
    """)
    suspend fun findNearby(lat: Double, lng: Double, radius: Double): List<TruckWasherPoi>
    
    /**
     * Busca POIs por cadeia de lavagem
     * @param chain Nome da cadeia
     * @return Lista de POIs da cadeia especificada
     */
    @Query("SELECT * FROM truck_washer_pois WHERE washerChain = :chain")
    suspend fun findByChain(chain: String): List<TruckWasherPoi>
    
    /**
     * Busca POIs com avaliação mínima
     * @param minRating Avaliação mínima
     * @return Lista de POIs com avaliação >= minRating
     */
    @Query("SELECT * FROM truck_washer_pois WHERE rating >= :minRating")
    suspend fun findByMinRating(minRating: Float): List<TruckWasherPoi>
    
    /**
     * Busca POIs abertos
     * @return Lista de POIs abertos
     */
    @Query("SELECT * FROM truck_washer_pois WHERE status = 'OPEN'")
    suspend fun findOpen(): List<TruckWasherPoi>
    
    /**
     * Conta o número de POIs no banco
     * @return Quantidade de POIs
     */
    @Query("SELECT COUNT(*) FROM truck_washer_pois")
    suspend fun getCount(): Int
    
    /**
     * Atualiza a avaliação de um POI
     * @param poiId ID do POI
     * @param rating Nova avaliação
     * @param reviewCount Novo número de avaliações
     */
    @Query("UPDATE truck_washer_pois SET rating = :rating, reviewCount = :reviewCount WHERE id = :poiId")
    suspend fun updateRating(poiId: String, rating: Float, reviewCount: Int)
    
    /**
     * Incrementa o contador de visualizações de um POI
     * @param poiId ID do POI
     */
    @Query("UPDATE truck_washer_pois SET viewCount = viewCount + 1 WHERE id = :poiId")
    suspend fun incrementViewCount(poiId: String)
    
    /**
     * Incrementa o contador de favoritos de um POI
     * @param poiId ID do POI
     */
    @Query("UPDATE truck_washer_pois SET favoriteCount = favoriteCount + 1 WHERE id = :poiId")
    suspend fun incrementFavoriteCount(poiId: String)
    
    /**
     * Decrementa o contador de favoritos de um POI
     * @param poiId ID do POI
     */
    @Query("UPDATE truck_washer_pois SET favoriteCount = CASE WHEN favoriteCount > 0 THEN favoriteCount - 1 ELSE 0 END WHERE id = :poiId")
    suspend fun decrementFavoriteCount(poiId: String)
}