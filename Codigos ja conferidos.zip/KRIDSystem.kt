// Sistema de Identificação KRID
// app/src/main/kotlin/com/kingroad/identity

import java.util.Locale
import kotlin.math.pow

class KRIDManager(
    private val database: LocalDatabase,
    private val countryService: CountryService
) {
    companion object {
        private val COUNTRY_FORMATS = mapOf(
            CountrySize.LARGE to 16,   // Países grandes: 16 dígitos
            CountrySize.MEDIUM to 12,  // Países médios: 12 dígitos
            CountrySize.SMALL to 8     // Países pequenos: 8 dígitos
        )
    }
    
    suspend fun generateKRID(countryCode: String): KRID {
        val countrySize = determineCountrySize(countryCode)
        val numDigits = COUNTRY_FORMATS[countrySize] ?: 
            throw IllegalArgumentException("Invalid country size")
        
        var krid: KRID
        do {
            val numbers = generateSequence { (0..9).random() }
                .take(numDigits - 1)
                .joinToString("")
            
            val checkDigit = calculateCheckDigit(countryCode + numbers)
            krid = KRID(
                countryCode = countryCode,
                numbers = numbers + checkDigit,
                size = countrySize
            )
        } while (!isUnique(krid))
        
        return krid
    }
    
    fun validateKRID(krid: String): Boolean {
        try {
            // Remove espaços e converte para maiúsculas
            val cleanKRID = krid.replace(" ", "").uppercase(Locale.ROOT)
            
            // Verifica formato básico
            if (!isValidFormat(cleanKRID)) return false
            
            // Extrai componentes
            val countryCode = cleanKRID.substring(0, 2)
            val numbers = cleanKRID.substring(2)
            
            // Valida país
            if (!isValidCountry(countryCode)) return false
            
            // Valida dígito verificador
            val checkDigit = numbers.last()
            val calculatedCheckDigit = calculateCheckDigit(countryCode + numbers.dropLast(1))
            
            return checkDigit == calculatedCheckDigit
        } catch (e: Exception) {
            return false
        }
    }
    
    private fun isValidFormat(krid: String): Boolean {
        val countryCode = krid.substring(0, 2)
        val numbers = krid.substring(2)
        
        // Verifica se o código do país tem letras válidas
        if (!countryCode.all { it.isLetter() }) return false
        
        // Verifica se os números são válidos
        if (!numbers.all { it.isDigit() }) return false
        
        // Verifica o tamanho baseado no país
        val expectedSize = COUNTRY_FORMATS[determineCountrySize(countryCode)]
        return numbers.length == expectedSize
    }
    
    private fun calculateCheckDigit(input: String): Char {
        // Converte letras para números (A=10, B=11, etc)
        val numericValue = input.map { char ->
            when {
                char.isLetter() -> (char.uppercase().first().code - 'A'.code + 10).toString()
                else -> char.toString()
            }
        }.joinToString("")
        
        // Calcula módulo 97 (similar ao IBAN)
        val remainder = numericValue.chunked(9)
            .map { it.toBigInteger() }
            .fold(0) { acc, value -> 
                ((acc * (10.0.pow(value.toString().length).toLong()) + value.toLong()) % 97).toInt()
            }
        
        return ((remainder % 10) + '0'.code).toChar()
    }
    
    private suspend fun isUnique(krid: KRID): Boolean {
        return !database.kridExists(krid.toString())
    }
    
    private fun determineCountrySize(countryCode: String): CountrySize {
        return when (countryService.getPopulation(countryCode)) {
            in 0..10_000_000 -> CountrySize.SMALL
            in 10_000_001..100_000_000 -> CountrySize.MEDIUM
            else -> CountrySize.LARGE
        }
    }
}

data class KRID(
    val countryCode: String,
    val numbers: String,
    val size: CountrySize
) {
    init {
        require(countryCode.length == 2 && countryCode.all { it.isLetter() }) {
            "Country code must be 2 letters"
        }
        require(numbers.all { it.isDigit() }) {
            "Numbers must be digits only"
        }
        require(numbers.length == when(size) {
            CountrySize.LARGE -> 16
            CountrySize.MEDIUM -> 12
            CountrySize.SMALL -> 8
        }) {
            "Invalid number length for country size"
        }
    }
    
    override fun toString(): String {
        // Formata o KRID com espaços a cada 4 dígitos
        val formattedNumbers = numbers.chunked(4).joinToString(" ")
        return "$countryCode $formattedNumbers"
    }
    
    fun toCleanString(): String = countryCode + numbers
}

enum class CountrySize {
    LARGE,   // > 100M habitantes
    MEDIUM,  // 10M-100M habitantes
    SMALL    // < 10M habitantes
}

// Interface para validação e serviços de país
interface CountryService {
    fun isValidCountry(countryCode: String): Boolean
    fun getPopulation(countryCode: String): Long
    fun getCountryName(countryCode: String): String
    fun getEmergencyNumbers(countryCode: String): List<String>
}

// Extensões para formatação
fun String.toKRID(): KRID? {
    try {
        val clean = this.replace(" ", "").uppercase(Locale.ROOT)
        val countryCode = clean.substring(0, 2)
        val numbers = clean.substring(2)
        val size = when (numbers.length) {
            16 -> CountrySize.LARGE
            12 -> CountrySize.MEDIUM
            8 -> CountrySize.SMALL
            else -> return null
        }
        return KRID(countryCode, numbers, size)
    } catch (e: Exception) {
        return null
    }
}