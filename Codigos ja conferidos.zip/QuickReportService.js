/**
 * QuickReportService.js
 * 
 * Service to manage quick reports functionality in the KingRoad app.
 * Allows users to quickly report road conditions, hazards, POI updates, etc.
 * Manages offline queueing and synchronization of reports.
 * 
 * @author KingRoad Development Team
 * @version 1.0.0
 */

import { Platform } from 'react-native';
import ApiService from './ApiService';
import LocationService from './LocationService';
import UserService from './UserService';
import OfflineCacheManager from './OfflineCacheManager';
import LogService from './LogService';
import { TranslationsService } from './TranslationsService';

// Singleton instance
let instance = null;

class QuickReportService {
  constructor() {
    if (instance) {
      return instance;
    }

    // Report types configuration
    this.reportTypes = [
      {
        id: 'traffic',
        icon: 'traffic',
        color: '#E53935',
        subtypes: ['jam', 'accident', 'roadwork', 'closure']
      },
      {
        id: 'hazard',
        icon: 'warning',
        color: '#FF9800',
        subtypes: ['obstacle', 'weather', 'animal', 'pothole']
      },
      {
        id: 'police',
        icon: 'local-police',
        color: '#2196F3',
        subtypes: ['visible', 'hidden', 'checkpoint']
      },
      {
        id: 'poi',
        icon: 'place',
        color: '#4CAF50',
        subtypes: ['new', 'closed', 'incorrect', 'missing']
      },
      {
        id: 'fuel',
        icon: 'local-gas-station',
        color: '#9C27B0',
        subtypes: ['price', 'quality', 'availability']
      }
    ];
    
    // Report state
    this.state = {
      pendingReports: [],
      recentReports: [],
      isSubmitting: false,
      lastSubmittedAt: null,
      maxRecentReports: 50,
      syncInProgress: false,
    };
    
    // Connection listener
    this.connectionListener = null;
    
    // Initialize the service
    this.init();
    
    instance = this;
  }
  
  /**
   * Initialize the service by loading saved data and setting up listeners
   */
  async init() {
    try {
      // Load pending reports
      const pendingReports = await OfflineCacheManager.getItem('pending_reports');
      if (pendingReports) {
        this.state.pendingReports = JSON.parse(pendingReports);
      }
      
      // Load recent reports
      const recentReports = await OfflineCacheManager.getItem('recent_reports');
      if (recentReports) {
        this.state.recentReports = JSON.parse(recentReports);
      }
      
      // Set up connection listener to sync reports when connection is restored
      this.connectionListener = OfflineCacheManager.addConnectionListener(async (connected) => {
        if (connected && this.state.pendingReports.length > 0) {
          await this.syncPendingReports();
        }
      });
      
      // Try to sync pending reports if we're online
      if (await OfflineCacheManager.isConnected() && this.state.pendingReports.length > 0) {
        this.syncPendingReports();
      }
      
      LogService.debug('QuickReportService initialized');
    } catch (error) {
      LogService.error('Error initializing QuickReportService:', error);
    }
  }
  
  /**
   * Clean up resources
   */
  destroy() {
    if (this.connectionListener) {
      OfflineCacheManager.removeConnectionListener(this.connectionListener);
    }
  }
  
  /**
   * Get all available report types
   * @returns {Array} List of report types
   */
  getReportTypes() {
    return [...this.reportTypes];
  }
  
  /**
   * Get recent reports submitted by the user
   * @returns {Array} Recent reports
   */
  getRecentReports() {
    return [...this.state.recentReports];
  }
  
  /**
   * Get pending reports that haven't been synced yet
   * @returns {Array} Pending reports
   */
  getPendingReports() {
    return [...this.state.pendingReports];
  }
  
  /**
   * Save pending reports to persistent storage
   */
  async savePendingReports() {
    try {
      await OfflineCacheManager.setItem(
        'pending_reports', 
        JSON.stringify(this.state.pendingReports)
      );
    } catch (error) {
      LogService.error('Error saving pending reports:', error);
    }
  }
  
  /**
   * Save recent reports to persistent storage
   */
  async saveRecentReports() {
    try {
      await OfflineCacheManager.setItem(
        'recent_reports', 
        JSON.stringify(this.state.recentReports)
      );
    } catch (error) {
      LogService.error('Error saving recent reports:', error);
    }
  }
  
  /**
   * Submit a new report
   * @param {Object} reportData - Report data (type, subtype, description, etc.)
   * @returns {Object} Submitted report with status
   */
  async submitReport(reportData) {
    try {
      this.state.isSubmitting = true;
      
      // Get current location
      const location = await LocationService.getCurrentLocation();
      
      // Get user info
      const userInfo = await UserService.getUserInfo();
      
      // Create the report object
      const report = {
        id: `report_${Date.now()}`,
        type: reportData.type,
        subtype: reportData.subtype,
        description: reportData.description || '',
        location: {
          latitude: location.latitude,
          longitude: location.longitude,
          accuracy: location.accuracy,
          altitude: location.altitude,
          heading: location.heading,
          speed: location.speed,
        },
        images: reportData.images || [],
        timestamp: Date.now(),
        userId: userInfo.id,
        username: userInfo.username,
        deviceInfo: {
          platform: Platform.OS,
          version: Platform.Version,
          appVersion: '1.0.0', // TODO: Get from app config
        },
        status: 'pending',
        synced: false,
      };
      
      // Try to submit immediately if online
      if (await OfflineCacheManager.isConnected()) {
        try {
          const response = await this.sendReportToServer(report);
          
          // Update report with server response
          report.id = response.id;
          report.status = 'submitted';
          report.synced = true;
          report.serverTimestamp = response.timestamp;
          
          // Add to recent reports
          this.addToRecentReports(report);
          
          this.state.lastSubmittedAt = Date.now();
          this.state.isSubmitting = false;
          
          return report;
        } catch (error) {
          // If server submission fails, queue for later
          LogService.error('Error submitting report, queueing for later:', error);
          report.status = 'queued';
          this.addToPendingReports(report);
          
          this.state.lastSubmittedAt = Date.now();
          this.state.isSubmitting = false;
          
          return report;
        }
      } else {
        // If offline, queue for later
        report.status = 'queued';
        this.addToPendingReports(report);
        
        this.state.lastSubmittedAt = Date.now();
        this.state.isSubmitting = false;
        
        return report;
      }
    } catch (error) {
      this.state.isSubmitting = false;
      LogService.error('Error in submitReport:', error);
      throw error;
    }
  }
  
  /**
   * Send a report to the server
   * @param {Object} report - Report to send
   * @returns {Object} Server response
   */
  async sendReportToServer(report) {
    try {
      // Upload images first if any
      const uploadedImageUrls = [];
      if (report.images && report.images.length > 0) {
        for (const image of report.images) {
          const uploadResponse = await ApiService.uploadImage('/reports/images', image);
          uploadedImageUrls.push(uploadResponse.url);
        }
      }
      
      // Prepare the report data for API
      const reportForApi = {
        ...report,
        images: uploadedImageUrls,
      };
      
      // Send report to server
      const response = await ApiService.post('/reports', reportForApi);
      
      return response;
    } catch (error) {
      LogService.error('Error in sendReportToServer:', error);
      throw error;
    }
  }
  
  /**
   * Add a report to pending reports queue
   * @param {Object} report - Report to add
   */
  addToPendingReports(report) {
    this.state.pendingReports.push(report);
    this.savePendingReports();
    
    // Also add to recent reports
    this.addToRecentReports(report);
  }
  
  /**
   * Add a report to recent reports
   * @param {Object} report - Report to add
   */
  addToRecentReports(report) {
    // Add to the beginning of the array
    this.state.recentReports.unshift(report);
    
    // Limit the size of recent reports
    if (this.state.recentReports.length > this.state.maxRecentReports) {
      this.state.recentReports = this.state.recentReports.slice(
        0,
        this.state.maxRecentReports
      );
    }
    
    this.saveRecentReports();
  }
  
  /**
   * Synchronize all pending reports with the server
   * @returns {Object} Sync result
   */
  async syncPendingReports() {
    if (this.state.syncInProgress || this.state.pendingReports.length === 0) {
      return {
        success: true,
        message: 'No reports to sync or sync already in progress',
        synced: 0,
        failed: 0,
      };
    }
    
    try {
      this.state.syncInProgress = true;
      
      const syncResults = {
        success: true,
        synced: 0,
        failed: 0,
        reports: [],
      };
      
      const newPendingReports = [];
      
      // Try to sync each pending report
      for (const report of this.state.pendingReports) {
        try {
          const response = await this.sendReportToServer(report);
          
          // Update report in recent reports
          const updatedReport = {
            ...report,
            id: response.id,
            status: 'submitted',
            synced: true,
            serverTimestamp: response.timestamp,
          };
          
          // Update in recent reports
          const recentIndex = this.state.recentReports.findIndex(r => r.id === report.id);
          if (recentIndex !== -1) {
            this.state.recentReports[recentIndex] = updatedReport;
          }
          
          syncResults.synced++;
          syncResults.reports.push({
            report: updatedReport,
            success: true,
          });
        } catch (error) {
          syncResults.failed++;
          syncResults.reports.push({
            report,
            success: false,
            error: error.message,
          });
          
          // Keep in pending reports
          newPendingReports.push(report);
        }
      }
      
      // Update pending reports
      this.state.pendingReports = newPendingReports;
      
      // Save changes
      this.savePendingReports();
      this.saveRecentReports();
      
      this.state.syncInProgress = false;
      
      return syncResults;
    } catch (error) {
      this.state.syncInProgress = false;
      LogService.error('Error in syncPendingReports:', error);
      
      return {
        success: false,
        message: error.message,
        synced: 0,
        failed: this.state.pendingReports.length,
      };
    }
  }
  
  /**
   * Delete a report from recent reports
   * @param {string} reportId - ID of the report to delete
   * @returns {boolean} Success indicator
   */
  async deleteRecentReport(reportId) {
    const index = this.state.recentReports.findIndex(r => r.id === reportId);
    
    if (index !== -1) {
      this.state.recentReports.splice(index, 1);
      await this.saveRecentReports();
      return true;
    }
    
    return false;
  }
  
  /**
   * Cancel a pending report
   * @param {string} reportId - ID of the report to cancel
   * @returns {boolean} Success indicator
   */
  async cancelPendingReport(reportId) {
    const index = this.state.pendingReports.findIndex(r => r.id === reportId);
    
    if (index !== -1) {
      // Get the report
      const report = this.state.pendingReports[index];
      
      // Remove from pending reports
      this.state.pendingReports.splice(index, 1);
      await this.savePendingReports();
      
      // Update in recent reports if it exists there
      const recentIndex = this.state.recentReports.findIndex(r => r.id === reportId);
      if (recentIndex !== -1) {
        this.state.recentReports[recentIndex] = {
          ...this.state.recentReports[recentIndex],
          status: 'cancelled',
        };
        await this.saveRecentReports();
      }
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Check if the service is currently submitting a report
   * @returns {boolean} True if submitting
   */
  isSubmitting() {
    return this.state.isSubmitting;
  }
  
  /**
   * Check if the service is currently syncing reports
   * @returns {boolean} True if syncing
   */
  isSyncing() {
    return this.state.syncInProgress;
  }
  
  /**
   * Get translation string
   * @param {string} key - Translation key
   * @returns {string} Translated string
   */
  getTranslation(key) {
    return TranslationsService.getTranslation(key);
  }
}

export default new QuickReportService();