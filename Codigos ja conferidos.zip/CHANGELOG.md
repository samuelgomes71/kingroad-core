# Changelog - Família King

Todas as alterações notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [1.0.0] - 2025-03-27

### Adicionado
- Implementação inicial do redesign visual para toda a família King
- Nova paleta de cores padronizada (café escuro, bege claro, dourado)
- Logo da família King posicionado no canto superior esquerdo
- Botão de menu circular no canto inferior esquerdo
- Splash screen personalizada com logo dourado sobre fundo escuro
- Suporte a múltiplos tamanhos de tela (small, medium, large, xlarge)
- Modo desenvolvedor ativado com 5 toques no logo + senha
- Suporte a temas claro e escuro
- Detecção automática de região para recursos regionalizados
- Download dinâmico de recursos visuais do CDN
- Indicador visual de versão beta

### Modificado
- Interface principal do KingRoad para seguir o novo padrão visual
- Fluxo de inicialização do app (agora começa com a SplashActivity)
- Sistema de carregamento de recursos (agora usa download dinâmico)

### Corrigido
- Inconsistências visuais entre os diferentes aplicativos da família
- Problemas de escalonamento em diferentes tamanhos de tela

## [0.9.0] - 2025-02-15

### Adicionado
- Versão beta inicial do KingRoad
- Funcionalidades básicas de navegação
- Pontos de interesse (POIs)
- Alertas de segurança
- Scanner
- Reportes rápidos
- Sistema de feedback e logs

### Pendente
- Redesign visual unificado
- Suporte completo a múltiplos idiomas
- Visuais regionais automatizados