import React, { useState } from 'react';

const ParkingTypeSelector = () => {
  const [selectedType, setSelectedType] = useState('TRUCK_STOP');
  
  // Opções de tipo de estacionamento
  const parkingTypes = [
    { value: 'TRUCK_STOP', label: 'Truck Stop', icon: '🚚', 
      description: 'Área projetada especificamente para parada de caminhões, geralmente com diversos serviços.' },
    { value: 'REST_AREA', label: 'Área de Descanso', icon: '🛏️', 
      description: 'Local designado para descanso de motoristas, geralmente com estrutura básica.' },
    { value: 'SERVICE_AREA', label: 'Área de Serviço', icon: '🔧', 
      description: 'Combina estacionamento com serviços de manutenção para caminhões.' },
    { value: 'DEDICATED_PARKING', label: 'Estacionamento', icon: '🅿️', 
      description: 'Estacionamento dedicado para veículos grandes, sem necessariamente oferecer serviços adicionais.' },
    { value: 'WAREHOUSE_YARD', label: 'Pátio', icon: '🏭', 
      description: 'Área externa de armazém ou centro de distribuição que permite estacionamento.' },
    { value: 'GAS_STATION', label: 'Posto', icon: '⛽', 
      description: 'Posto de combustível com espaço para estacionamento de caminhões.' },
    { value: 'SHOPPING_CENTER', label: 'Shopping', icon: '🛒', 
      description: 'Estacionamento de shopping center que permite veículos grandes.' },
    { value: 'OTHER', label: 'Outro', icon: '📍', 
      description: 'Outro tipo de local não listado nas opções acima.' }
  ];

  return (
    <div className="p-4 max-w-lg mx-auto bg-gray-50 rounded-lg">
      <h3 className="font-semibold mb-3">Tipo de Estacionamento</h3>
      
      {/* Seletor horizontal com ícones */}
      <div className="flex overflow-x-auto pb-2 mb-4">
        {parkingTypes.map(type => (
          <button
            key={type.value}
            className={`flex flex-col items-center justify-center p-3 mr-3 rounded-lg min-w-[80px] ${
              selectedType === type.value 
                ? 'bg-blue-100 border-2 border-blue-500' 
                : 'bg-white border border-gray-200'
            }`}
            onClick={() => setSelectedType(type.value)}
          >
            <span className="text-2xl mb-1">{type.icon}</span>
            <span className="text-xs text-center">{type.label}</span>
          </button>
        ))}
      </div>
      
      {/* Descrição do tipo selecionado */}
      {selectedType && (
        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="flex items-center mb-2">
            <span className="text-xl mr-2">
              {parkingTypes.find(t => t.value === selectedType)?.icon}
            </span>
            <span className="font-medium text-blue-600">
              {parkingTypes.find(t => t.value === selectedType)?.label}
            </span>
          </div>
          <p className="text-sm text-gray-600">
            {parkingTypes.find(t => t.value === selectedType)?.description}
          </p>
        </div>
      )}
      
      {/* Interação para testar */}
      <div className="mt-4 text-center text-sm text-gray-500">
        Clique nas opções acima para selecionar diferentes tipos de estacionamento
      </div>
    </div>
  );
};

export default ParkingTypeSelector;