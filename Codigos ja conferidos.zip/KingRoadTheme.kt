package com.kingroad.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Definição de cores principais do KingRoad
 * Cores conforme especificação do design (kingroad_split_screen_final_ready.json)
 */
object KingRoadColors {
    // Cores base do KingRoad
    val Background = Color(0xFFE0D3C0)
    val TextColor = Color(0xFF5E3C2B)
    val Accent = Color(0xFF6B4B3E)
    val VoiceButtonColor = Color(0xFF5E3C2B)
    
    // Cores de status
    val Error = Color(0xFFD32F2F)
    val Success = Color(0xFF388E3C)
    val Warning = Color(0xFFF57C00)
    val Info = Color(0xFF1976D2)
    
    // Variantes para tema claro
    val BackgroundLight = Color(0xFFF5EEE6)
    val TextColorLight = Color(0xFF7A5543)
    val AccentLight = Color(0xFF8A6A5A)
    
    // Variantes para tema escuro
    val BackgroundDark = Color(0xFF3E331F)
    val TextColorDark = Color(0xFFD6C2B0)
    val AccentDark = Color(0xFF493124)
}

/**
 * Esquemas de cores para temas claro e escuro
 */
private val LightColorScheme = lightColorScheme(
    primary = KingRoadColors.Accent,
    onPrimary = Color.White,
    secondary = KingRoadColors.AccentLight,
    onSecondary = Color.White,
    tertiary = KingRoadColors.TextColor,
    background = KingRoadColors.BackgroundLight,
    surface = KingRoadColors.Background,
    onBackground = KingRoadColors.TextColor,
    onSurface = KingRoadColors.TextColor,
    error = KingRoadColors.Error,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = KingRoadColors.AccentDark,
    onPrimary = Color.White,
    secondary = KingRoadColors.AccentLight,
    onSecondary = Color.White,
    tertiary = KingRoadColors.TextColorDark,
    background = KingRoadColors.BackgroundDark,
    surface = KingRoadColors.BackgroundDark,
    onBackground = KingRoadColors.TextColorDark,
    onSurface = KingRoadColors.TextColorDark,
    error = KingRoadColors.Error,
    onError = Color.White
)

/**
 * Classe que define as cores específicas do KingRoad que não fazem parte
 * do MaterialTheme padrão
 */
class KingRoadColorPalette(
    val voiceButton: Color,
    val success: Color,
    val warning: Color,
    val info: Color
)

/**
 * Provider para cores específicas do KingRoad
 */
val LocalKingRoadColors = compositionLocalOf {
    KingRoadColorPalette(
        voiceButton = KingRoadColors.VoiceButtonColor,
        success = KingRoadColors.Success,
        warning = KingRoadColors.Warning,
        info = KingRoadColors.Info
    )
}

/**
 * Tema principal do KingRoad
 */
@Composable
fun KingRoadTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Suporte para Material You em Android 12+
    content: @Composable () -> Unit
) {
    // Determinar esquema de cores
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    // Cores específicas do KingRoad com base no tema
    val kingRoadColors = if (darkTheme) {
        KingRoadColorPalette(
            voiceButton = KingRoadColors.TextColorDark,
            success = KingRoadColors.Success,
            warning = KingRoadColors.Warning,
            info = KingRoadColors.Info
        )
    } else {
        KingRoadColorPalette(
            voiceButton = KingRoadColors.VoiceButtonColor,
            success = KingRoadColors.Success,
            warning = KingRoadColors.Warning,
            info = KingRoadColors.Info
        )
    }
    
    // Aplicar cores na barra de status
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    // Prover cores específicas do KingRoad junto com o MaterialTheme
    CompositionLocalProvider(
        LocalKingRoadColors provides kingRoadColors
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

/**
 * Extensões para acessar facilmente as cores do KingRoad
 */
object KingRoadTheme {
    /**
     * Acesso às cores específicas do KingRoad
     */
    val colors: KingRoadColorPalette
        @Composable
        get() = LocalKingRoadColors.current
    
    /**
     * Função para criar facilmente variantes de cores regionais
     */
    fun createRegionalColors(
        background: Color = KingRoadColors.Background,
        text: Color = KingRoadColors.TextColor,
        accent: Color = KingRoadColors.Accent,
        voiceButton: Color = KingRoadColors.VoiceButtonColor
    ): Map<String, Color> {
        return mapOf(
            "background" to background,
            "text" to text,
            "accent" to accent,
            "voiceButton" to voiceButton
        )
    }
    
    /**
     * Mapa de cores regionais por país
     * Pode ser expandido com mais variações por país
     */
    val regionalColors = mapOf(
        "BR" to createRegionalColors(),
        "US" to createRegionalColors(
            background = Color(0xFFE6D8C0),
            accent = Color(0xFF5D4B3E)
        ),
        "ES" to createRegionalColors(
            background = Color(0xFFE8D0B8),
            accent = Color(0xFF7D4D34)
        )
        // Adicionar mais países conforme necessário
    )
}