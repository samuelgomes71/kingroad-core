/**
 * i18n/locales/fr-FR.js
 * 
 * Ressources de traduction pour Français (France).
 * Il s'agit de l'une des langues principales de l'application avec des traductions complètes.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

const frFR = {
  translation: {
    // Informations sur l'application
    app: {
      name: 'KingRoad',
      welcome: 'Bienvenue sur KingRoad',
      tagline: 'Votre assistant personnel de voyage',
      version: 'Version {{version}}',
      copyright: '© 2025 KingRoad. Tous droits réservés.'
    },
    
    // Authentification
    auth: {
      login: 'Connexion',
      logout: 'Déconnexion',
      register: 'S\'inscrire',
      forgotPassword: 'Mot de passe oublié ?',
      resetPassword: 'Réinitialiser le mot de passe',
      emailPlaceholder: 'Email',
      passwordPlaceholder: 'Mot de passe',
      confirmPasswordPlaceholder: 'Confirmer le mot de passe',
      loginSuccess: 'Connexion réussie !',
      loginError: 'Échec de la connexion. Veuillez vérifier vos identifiants.',
      logoutSuccess: 'Vous avez été déconnecté.',
      passwordResetSent: 'Les instructions de réinitialisation du mot de passe ont été envoyées.',
      passwordsDontMatch: 'Les mots de passe ne correspondent pas.',
      passwordRequirements: 'Le mot de passe doit contenir au moins 8 caractères, avec des majuscules, des minuscules et des chiffres.'
    },
    
    // Navigation
    nav: {
      home: 'Accueil',
      profile: 'Profil',
      settings: 'Paramètres',
      trips: 'Voyages',
      explore: 'Explorer',
      help: 'Aide',
      about: 'À propos'
    },
    
    // Profil utilisateur
    profile: {
      title: 'Mon Profil',
      edit: 'Modifier le Profil',
      save: 'Enregistrer les Modifications',
      cancel: 'Annuler',
      name: 'Nom',
      email: 'Email',
      phone: 'Téléphone',
      address: 'Adresse',
      preferences: 'Préférences',
      changePassword: 'Modifier le Mot de Passe',
      language: 'Langue',
      theme: 'Thème',
      notifications: 'Notifications',
      deleteAccount: 'Supprimer le Compte',
      deleteAccountConfirm: 'Êtes-vous sûr de vouloir supprimer votre compte ? Cette action ne peut pas être annulée.',
      profileUpdated: 'Profil mis à jour avec succès !',
      profileUpdateError: 'Erreur lors de la mise à jour du profil.'
    },
    
    // Paramètres
    settings: {
      title: 'Paramètres',
      general: 'Général',
      account: 'Compte',
      privacy: 'Confidentialité',
      notifications: 'Notifications',
      appearance: 'Apparence',
      language: 'Langue',
      region: 'Région',
      theme: {
        title: 'Thème',
        light: 'Clair',
        dark: 'Sombre',
        system: 'Système'
      },
      dataCurrency: 'Devise',
      dataUsage: 'Utilisation des Données',
      wifiOnly: 'Wi-Fi Uniquement',
      locationServices: 'Services de Localisation',
      resetSettings: 'Réinitialiser les Paramètres',
      resetSettingsConfirm: 'Êtes-vous sûr de vouloir réinitialiser tous les paramètres ?',
      settingsSaved: 'Paramètres enregistrés !',
      settingsError: 'Erreur lors de l\'enregistrement des paramètres.'
    },
    
    // Composants communs
    common: {
      ok: 'OK',
      cancel: 'Annuler',
      save: 'Enregistrer',
      delete: 'Supprimer',
      edit: 'Modifier',
      add: 'Ajouter',
      remove: 'Retirer',
      search: 'Rechercher',
      filter: 'Filtrer',
      sort: 'Trier',
      loading: 'Chargement...',
      retry: 'Réessayer',
      error: 'Erreur',
      success: 'Succès',
      warning: 'Avertissement',
      info: 'Information',
      yes: 'Oui',
      no: 'Non',
      back: 'Retour',
      next: 'Suivant',
      finish: 'Terminer',
      continue: 'Continuer',
      skip: 'Passer',
      done: 'Terminé',
      select: 'Sélectionner',
      today: 'Aujourd\'hui',
      yesterday: 'Hier',
      tomorrow: 'Demain',
      confirm: 'Confirmer',
      apply: 'Appliquer',
      reset: 'Réinitialiser',
      close: 'Fermer',
      open: 'Ouvrir',
      show: 'Afficher',
      hide: 'Masquer',
      all: 'Tous',
      none: 'Aucun',
      required: 'Obligatoire',
      optional: 'Optionnel',
      more: 'Plus',
      less: 'Moins',
      details: 'Détails',
      upload: 'Téléverser',
      download: 'Télécharger',
      noResults: 'Aucun résultat trouvé',
      noData: 'Aucune donnée disponible',
      emptyState: 'Il n\'y a rien ici pour le moment',
      offline: 'Vous êtes hors ligne',
      online: 'Vous êtes en ligne',
      day: 'Jour',
      week: 'Semaine',
      month: 'Mois',
      year: 'Année'
    },
    
    // Messages d'erreur
    errors: {
      generic: 'Une erreur s\'est produite. Veuillez réessayer.',
      connection: 'Erreur de connexion. Veuillez vérifier votre internet.',
      timeout: 'La requête a expiré. Veuillez réessayer.',
      unauthorized: 'Non autorisé. Veuillez vous reconnecter.',
      notFound: 'Ressource non trouvée.',
      serverError: 'Erreur du serveur. Veuillez réessayer plus tard.',
      validation: 'Veuillez vérifier vos données.',
      requiredField: 'Champ obligatoire',
      invalidEmail: 'Email invalide',
      weakPassword: 'Mot de passe trop faible',
      accountExists: 'Ce compte existe déjà',
      uploadFailed: 'Échec du téléversement du fichier',
      downloadFailed: 'Échec du téléchargement du fichier',
      locationPermissionDenied: 'Permission de localisation refusée',
      cameraPermissionDenied: 'Permission de caméra refusée',
      microphonePermissionDenied: 'Permission de microphone refusée',
      storagePermissionDenied: 'Permission de stockage refusée',
      networkError: 'Erreur réseau',
      sessionExpired: 'Session expirée. Veuillez vous reconnecter.'
    },
    
    // Composants spécifiques
    components: {
      // LocationPicker
      locationPicker: {
        searchPlaceholder: 'Rechercher une adresse',
        currentLocationButton: 'Position actuelle',
        confirmButton: 'Confirmer la position',
        permissionDeniedTitle: 'Permission refusée',
        permissionDeniedMessage: 'Permission de localisation refusée. Veuillez l\'activer dans les paramètres de l\'application.',
        locationErrorTitle: 'Erreur de localisation',
        locationErrorMessage: 'Impossible d\'obtenir la position actuelle',
        addressLabel: 'Adresse :',
        loadingLocation: 'Récupération de la position...',
        loadingAddress: 'Récupération de l\'adresse...',
        noAddressFound: 'Adresse non trouvée',
        searchingAddresses: 'Recherche d\'adresses...',
        noSearchResults: 'Aucun résultat trouvé',
        latitudeLongitudeFormat: 'Lat : {{lat}}, Lng : {{lng}}',
        manualInputButton: 'Saisie manuelle',
        manualInputTitle: 'Entrer les coordonnées',
        manualInputLatitude: 'Latitude',
        manualInputLongitude: 'Longitude',
        manualInputOk: 'OK',
        manualInputCancel: 'Annuler',
        manualInputError: 'Coordonnées invalides',
        standardMap: 'Standard',
        satelliteMap: 'Satellite',
        hybridMap: 'Hybride',
        terrainMap: 'Terrain'
      },
      
      // PhotoCapture
      photoCapture: {
        takePhoto: 'Prendre une photo',
        selectFromGallery: 'Sélectionner depuis la galerie',
        cancel: 'Annuler',
        retake: 'Reprendre',
        permissionDenied: 'Permission de caméra refusée',
        error: 'Erreur lors de la capture de la photo',
        processing: 'Traitement...',
        rotateLeft: 'Pivoter à gauche',
        rotateRight: 'Pivoter à droite',
        crop: 'Recadrer',
        save: 'Enregistrer',
        preview: 'Aperçu',
        addCaption: 'Ajouter une légende',
        removePhoto: 'Supprimer la photo'
      },
      
      // AudioRecorder
      audioRecorder: {
        record: 'Enregistrer',
        stop: 'Arrêter',
        play: 'Lire',
        pause: 'Pause',
        delete: 'Supprimer',
        save: 'Enregistrer',
        permissionDenied: 'Permission de microphone refusée',
        recording: 'Enregistrement...',
        recordingComplete: 'Enregistrement terminé',
        errorRecording: 'Erreur lors de l\'enregistrement audio',
        errorPlaying: 'Erreur lors de la lecture audio',
        duration: 'Durée : {{duration}}',
        addNote: 'Ajouter une note',
        quality: {
          title: 'Qualité',
          low: 'Basse',
          medium: 'Moyenne',
          high: 'Haute'
        }
      },
      
      // Formulaires et validation
      forms: {
        required: 'Champ obligatoire',
        minLength: 'Minimum {{count}} caractères',
        maxLength: 'Maximum {{count}} caractères',
        email: 'Email invalide',
        url: 'URL invalide',
        number: 'Doit être un nombre',
        integer: 'Doit être un nombre entier',
        alphanumeric: 'Lettres et chiffres uniquement',
        password: 'Mot de passe invalide',
        match: 'Les champs ne correspondent pas',
        date: 'Date invalide',
        phoneNumber: 'Numéro de téléphone invalide',
        zipCode: 'Code postal invalide',
        creditCard: 'Numéro de carte de crédit invalide'
      }
    },
    
    // Fonctionnalités de voyage
    trips: {
      title: 'Mes Voyages',
      new: 'Nouveau Voyage',
      edit: 'Modifier le Voyage',
      delete: 'Supprimer le Voyage',
      details: 'Détails du Voyage',
      itinerary: 'Itinéraire',
      expenses: 'Dépenses',
      photos: 'Photos',
      notes: 'Notes',
      map: 'Carte',
      shareTrip: 'Partager le Voyage',
      exportTrip: 'Exporter le Voyage',
      importTrip: 'Importer un Voyage',
      deleteConfirm: 'Êtes-vous sûr de vouloir supprimer ce voyage ?',
      noTrips: 'Vous n\'avez pas encore de voyages',
      createFirstTrip: 'Créez votre premier voyage',
      tripName: 'Nom du voyage',
      destination: 'Destination',
      startDate: 'Date de début',
      endDate: 'Date de fin',
      companions: 'Compagnons',
      status: {
        upcoming: 'À venir',
        inProgress: 'En cours',
        completed: 'Terminé',
        cancelled: 'Annulé'
      },
      transportType: {
        title: 'Type de transport',
        car: 'Voiture',
        bus: 'Bus',
        train: 'Train',
        airplane: 'Avion',
        boat: 'Bateau',
        walking: 'À pied',
        bicycle: 'Vélo',
        other: 'Autre'
      },
      accommodation: {
        title: 'Hébergement',
        hotel: 'Hôtel',
        hostel: 'Auberge',
        apartment: 'Appartement',
        house: 'Maison',
        camping: 'Camping',
        other: 'Autre'
      },
      budget: {
        title: 'Budget',
        estimated: 'Estimé',
        actual: 'Réel',
        remaining: 'Restant',
        currency: 'Devise',
        expenses: 'Dépenses',
        income: 'Revenus',
        categories: {
          accommodation: 'Hébergement',
          transportation: 'Transport',
          food: 'Nourriture',
          activities: 'Activités',
          shopping: 'Shopping',
          other: 'Autre'
        }
      }
    },
    
    // Fonctionnalités de synchronisation
    sync: {
      title: 'Synchronisation',
      lastSync: 'Dernière synchronisation : {{time}}',
      syncing: 'Synchronisation...',
      syncComplete: 'Synchronisation terminée',
      syncError: 'Erreur de synchronisation',
      syncSettings: 'Paramètres de synchronisation',
      autoSync: 'Synchronisation automatique',
      syncNow: 'Synchroniser maintenant',
      offlineChanges: 'Modifications hors ligne',
      uploadingData: 'Téléversement des données...',
      downloadingData: 'Téléchargement des données...',
      conflictResolution: {
        title: 'Résolution de conflits',
        local: 'Conserver la version locale',
        remote: 'Conserver la version distante',
        manual: 'Résoudre manuellement'
      }
    },
    
    // Fonctionnalités de langue et région
    locale: {
      title: 'Langue et Région',
      language: 'Langue',
      region: 'Région',
      dateFormat: 'Format de date',
      timeFormat: 'Format d\'heure',
      timezone: 'Fuseau horaire',
      currency: 'Devise',
      measurementSystem: 'Système de mesure',
      decimal: 'Séparateur décimal',
      thousands: 'Séparateur de milliers',
      firstDayOfWeek: 'Premier jour de la semaine',
      applyChanges: 'Appliquer les changements',
      systemDefault: 'Par défaut du système'
    }
  },
  
  // Métadonnées de la langue
  metadata: {
    name: 'Français (France)',
    nameEnglish: 'French (France)',
    isRTL: false,
    momentLocale: 'fr',
    dateFormat: {
      short: 'DD/MM/YYYY',
      medium: 'D MMM YYYY',
      long: 'D MMMM YYYY',
      full: 'dddd D MMMM YYYY'
    },
    timeFormat: {
      short: 'HH:mm',
      medium: 'HH:mm:ss',
      long: 'HH:mm:ss z',
      full: 'HH:mm:ss zzzz'
    },
    currency: {
      code: 'EUR',
      symbol: '€',
      format: '{amount} {symbol}',
      decimal: ',',
      thousand: ' '
    },
    country: 'FR',
    numberFormat: {
      decimal: ',',
      thousand: ' ',
      precision: 2
    },
    units: {
      system: 'metric',
      temperature: 'celsius',
      distance: {
        short: 'm',
        long: 'mètre',
        plural: 'mètres'
      },
      speed: 'km/h',
      weight: 'kg'
    }
  }
};

export default frFR;