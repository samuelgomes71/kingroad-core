import React from 'react';
import { useState } from 'react';

const NavigationPreview = () => {
  const [activeScreen, setActiveScreen] = useState('home');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [betaBadgeVisible, setBetaBadgeVisible] = useState(true);

  // Simulação do tema
  const theme = {
    primary: '#2E5BFF',
    background: '#F5F7FA',
    card: '#FFFFFF',
    text: '#14142B',
    textSecondary: '#6E7191',
    border: '#EFF0F7',
    cardText: '#FFFFFF',
  };

  // Simulação de textos traduzidos
  const translations = {
    'app.title': 'KingRoad',
    'navigation.home': 'Início',
    'navigation.saved_routes': 'Rotas Salvas',
    'navigation.navigate': 'Navegar',
    'navigation.poi': 'POIs',
    'navigation.settings': 'Ajustes',
    'navigation.profile': 'Perfil',
    'navigation.satellite': 'Satélite',
    'navigation.safety': 'Segurança',
    'navigation.assistant': 'Assistente',
    'navigation.import': 'Importar',
    'navigation.alerts': 'Alertas',
    'navigation.trail_modes': 'Trilhas',
  };

  const t = (key) => translations[key] || key;

  const TabBar = () => (
    <div className="flex w-full bg-white border-t border-gray-200 justify-between items-center px-2 py-1 absolute bottom-0 left-0 right-0">
      <TabButton icon="home" label={t('navigation.home')} active={activeScreen === 'home'} onClick={() => setActiveScreen('home')} />
      <TabButton icon="bookmark" label={t('navigation.saved_routes')} active={activeScreen === 'saved'} onClick={() => setActiveScreen('saved')} />
      <TabButton icon="navigation" label={t('navigation.navigate')} active={activeScreen === 'navigate'} onClick={() => setActiveScreen('navigate')} />
      <TabButton icon="place" label={t('navigation.poi')} active={activeScreen === 'poi'} onClick={() => setActiveScreen('poi')} />
      <TabButton icon="settings" label={t('navigation.settings')} active={activeScreen === 'settings'} onClick={() => setActiveScreen('settings')} />
    </div>
  );

  const TabButton = ({ icon, label, active, onClick }) => (
    <div 
      className={`flex flex-col items-center p-2 ${active ? 'text-blue-600' : 'text-gray-500'}`}
      onClick={onClick}
    >
      <div className="w-6 h-6 flex items-center justify-center">
        {icon === 'home' && <HomeIcon active={active} />}
        {icon === 'bookmark' && <BookmarkIcon active={active} />}
        {icon === 'navigation' && <NavigationIcon active={active} />}
        {icon === 'place' && <PlaceIcon active={active} />}
        {icon === 'settings' && <SettingsIcon active={active} />}
      </div>
      <span className="text-xs mt-1">{label}</span>
    </div>
  );

  const HomeIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
    </svg>
  );

  const BookmarkIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" />
    </svg>
  );

  const NavigationIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path d="M10 3.5a6.5 6.5 0 100 13 6.5 6.5 0 000-13zM10 2a8 8 0 110 16 8 8 0 010-16zm1 14.93V15h-2v1.93a6.002 6.002 0 004.013-2.45l-1.506-1.068A4.002 4.002 0 0111 16.93zM12.004 8l1.73-1.73a1 1 0 10-1.414-1.414L10.587 6.59 8.707 4.707a1 1 0 00-1.414 1.414L9.586 8.5 7.707 10.38a1 1 0 101.414 1.414L10.59 10.41l1.444 1.444a1 1 0 001.414-1.414L12.004 9z" />
    </svg>
  );

  const PlaceIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
    </svg>
  );

  const SettingsIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
    </svg>
  );

  const Header = () => (
    <div className="flex items-center justify-between p-4 bg-blue-600 text-white">
      <div className="flex items-center">
        <button className="mr-2" onClick={() => setDrawerOpen(!drawerOpen)}>
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
          </svg>
        </button>
        <div className="text-lg font-semibold">KingRoad</div>
      </div>
      <div className="relative">
        {betaBadgeVisible && (
          <div className="absolute -top-1 -right-1 bg-yellow-500 text-xs px-2 py-0.5 rounded-full text-white font-semibold">
            BETA
          </div>
        )}
        <img src="/api/placeholder/40/40" alt="Logo" className="w-10 h-10 rounded-full" />
      </div>
    </div>
  );

  const Drawer = () => (
    <div className={`fixed inset-0 z-40 ${drawerOpen ? 'block' : 'hidden'}`}>
      <div className="absolute inset-0 bg-black opacity-25" onClick={() => setDrawerOpen(false)}></div>
      <div className="absolute inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl">
        <div className="p-4 bg-blue-600 text-white">
          <div className="text-lg font-semibold">{t('app.title')}</div>
          {betaBadgeVisible && (
            <div className="inline-block bg-yellow-500 text-xs px-2 py-0.5 rounded-full text-white font-semibold mt-2">
              BETA
            </div>
          )}
        </div>
        <div className="overflow-y-auto h-full pb-20">
          <DrawerItem icon="home" label={t('navigation.home')} active={activeScreen === 'home'} onClick={() => {setActiveScreen('home'); setDrawerOpen(false);}} />
          <DrawerItem icon="person" label={t('navigation.profile')} active={activeScreen === 'profile'} onClick={() => {setActiveScreen('profile'); setDrawerOpen(false);}} />
          <DrawerItem icon="satellite" label={t('navigation.satellite')} active={activeScreen === 'satellite'} onClick={() => {setActiveScreen('satellite'); setDrawerOpen(false);}} />
          <DrawerItem icon="shield" label={t('navigation.safety')} active={activeScreen === 'safety'} onClick={() => {setActiveScreen('safety'); setDrawerOpen(false);}} />
          <DrawerItem icon="support_agent" label={t('navigation.assistant')} active={activeScreen === 'assistant'} onClick={() => {setActiveScreen('assistant'); setDrawerOpen(false);}} />
          <DrawerItem icon="upload_file" label={t('navigation.import')} active={activeScreen === 'import'} onClick={() => {setActiveScreen('import'); setDrawerOpen(false);}} />
          <DrawerItem icon="notifications" label={t('navigation.alerts')} active={activeScreen === 'alerts'} onClick={() => {setActiveScreen('alerts'); setDrawerOpen(false);}} />
          <DrawerItem icon="terrain" label={t('navigation.trail_modes')} active={activeScreen === 'trails'} onClick={() => {setActiveScreen('trails'); setDrawerOpen(false);}} />
        </div>
      </div>
    </div>
  );

  const DrawerItem = ({ icon, label, active, onClick }) => (
    <div 
      className={`flex items-center p-4 ${active ? 'bg-blue-50 text-blue-600' : 'text-gray-700'}`}
      onClick={onClick}
    >
      <div className="w-6 h-6 mr-4">
        {icon === 'home' && <HomeIcon active={active} />}
        {icon === 'person' && <PersonIcon active={active} />}
        {icon === 'satellite' && <SatelliteIcon active={active} />}
        {icon === 'shield' && <ShieldIcon active={active} />}
        {icon === 'support_agent' && <SupportAgentIcon active={active} />}
        {icon === 'upload_file' && <UploadFileIcon active={active} />}
        {icon === 'notifications' && <NotificationsIcon active={active} />}
        {icon === 'terrain' && <TerrainIcon active={active} />}
      </div>
      <span>{label}</span>
    </div>
  );

  const PersonIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
    </svg>
  );

  const SatelliteIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M8 16a6 6 0 006-6c0-1.655-.672-3.156-1.756-4.244l-.264.264a5 5 0 01-1.414 1.414l5.657 5.657A7.96 7.96 0 0116 8c0-4.418-3.582-8-8-8S0 3.582 0 8a7.965 7.965 0 012.344 5.657l5.657-5.657a5 5 0 011.414-1.414l.264-.264A6.016 6.016 0 008 16z" clipRule="evenodd" />
    </svg>
  );

  const ShieldIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
  );

  const SupportAgentIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v1h8v-1zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
    </svg>
  );

  const UploadFileIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
  );

  const NotificationsIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
    </svg>
  );

  const TerrainIcon = ({ active }) => (
    <svg className="w-5 h-5" fill={active ? '#2E5BFF' : '#6E7191'} viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M5.896 2.514a1 1 0 011.208 0l5 4a1 1 0 01.312 1.095l-2 6a1 1 0 01-.833.677l-6 1a1 1 0 01-1.103-.812l-1-6a1 1 0 01.229-.89l4.187-4.07zM14.5 10a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0z" clipRule="evenodd" />
    </svg>
  );

  const AppContent = () => {
    let content;
    switch (activeScreen) {
      case 'home':
        content = (
          <div className="p-4">
            <h1 className="text-xl font-semibold mb-4">KingRoad</h1>
            <div className="bg-white rounded-lg shadow p-4 mb-4">
              <h2 className="font-medium mb-2">Para onde você quer ir?</h2>
              <div className="bg-gray-100 rounded-lg p-3 flex items-center">
                <svg className="w-5 h-5 text-gray-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                </svg>
                <span className="text-gray-500">Buscar destino...</span>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-4 mb-4">
              <h2 className="font-medium mb-2">Rotas recentes</h2>
              <div className="space-y-3">
                <div className="flex items-center border-b pb-2">
                  <div className="bg-blue-100 rounded-full p-2 mr-3">
                    <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-medium">Porto Alegre → Florianópolis</div>
                    <div className="text-xs text-gray-500">460km · 5h 30min</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 rounded-full p-2 mr-3">
                    <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-medium">São Paulo → Rio de Janeiro</div>
                    <div className="text-xs text-gray-500">430km · 5h 10min</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow">
              <div className="p-4 border-b">
                <h2 className="font-medium">Alertas na sua região</h2>
              </div>
              <div className="p-4">
                <div className="flex items-center mb-3">
                  <div className="bg-red-100 rounded-full p-2 mr-3">
                    <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-medium">Acidente na BR-101 km 215</div>
                    <div className="text-xs text-gray-500">45min atrás · 2km</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="bg-yellow-100 rounded-full p-2 mr-3">
                    <svg className="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-medium">Controle policial no km 23</div>
                    <div className="text-xs text-gray-500">15min atrás · 5km</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
        break;
      case 'navigate':
        content = (
          <div className="relative h-full">
            <div className="bg-gray-200 h-full w-full flex items-center justify-center">
              <div className="text-center">
                <svg className="w-16 h-16 mx-auto text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <p className="mt-2 text-gray-600">Carregando mapa de navegação...</p>
              </div>
            </div>
            <div className="absolute bottom-20 right-4">
              <button className="bg-white rounded-full p-3 shadow-lg">
                <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        );
        break;
      default:
        content = (
          <div className="flex items-center justify-center h-full p-4 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">{activeScreen}</div>
              <p className="text-gray-600">Esta tela ainda está em desenvolvimento</p>
              <div className="mt-4">
                <button 
                  className="bg-blue-600 text-white py-2 px-4 rounded-lg mt-4"
                  onClick={() => setBetaBadgeVisible(!betaBadgeVisible)}
                >
                  {betaBadgeVisible ? 'Esconder' : 'Mostrar'} indicador BETA
                </button>
              </div>
            </div>
          </div>
        );
    }
    return content;
  };

  return (
    <div className="flex flex-col h-screen relative overflow-hidden bg-gray-100">
      <Header />
      <div className="flex-1 overflow-auto pb-16">
        <AppContent />
      </div>
      <TabBar />
      <Drawer />
    </div>
  );
};

export default NavigationPreview;