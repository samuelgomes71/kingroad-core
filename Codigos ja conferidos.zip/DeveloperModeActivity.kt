package com.kingfamily.kingroad.developer

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.kingfamily.kingroad.R
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Activity para o modo desenvolvedor, com ferramentas e opções de debug.
 */
class DeveloperModeActivity : AppCompatActivity() {

    companion object {
        private const val CONFIG_FILE = "king_family_config.json"
    }

    private lateinit var toolbar: Toolbar
    private lateinit var toolsList: ListView
    private var developerTools: List<DeveloperTool> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developer_mode)

        // Inicializa componentes da UI
        toolbar = findViewById(R.id.toolbar)
        toolsList = findViewById(R.id.tools_list)

        // Configura a toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Modo Desenvolvedor"

        // Carrega as ferramentas disponíveis
        loadDeveloperTools()

        // Configura a lista de ferramentas
        setupToolsList()
    }

    /**
     * Configura a lista de ferramentas de desenvolvedor
     */
    private fun setupToolsList() {
        val toolNames = developerTools.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, toolNames)
        toolsList.adapter = adapter

        toolsList.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val tool = developerTools[position]
            activateTool(tool)
        }
    }

    /**
     * Carrega as ferramentas disponíveis do arquivo de configuração
     */
    private fun loadDeveloperTools() {
        try {
            val inputStream = assets.open(CONFIG_FILE)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            reader.close()

            val config = JSONObject(jsonString)
            val toolsArray = config.optJSONObject("developer_mode")?.optJSONArray("tools")

            val tools = mutableListOf<DeveloperTool>()

            if (toolsArray != null) {
                for (i in 0 until toolsArray.length()) {
                    val toolJson = toolsArray.getJSONObject(i)
                    val tool = DeveloperTool(
                        id = toolJson.optString("id", ""),
                        name = toolJson.optString("name", ""),
                        icon = toolJson.optString("icon", "")
                    )
                    tools.add(tool)
                }
            }

            developerTools = tools
        } catch (e: Exception) {
            // Em caso de erro, inicializa com uma lista vazia
            developerTools = listOf()
        }
    }

    /**
     * Ativa a ferramenta selecionada
     */
    private fun activateTool(tool: DeveloperTool) {
        // Implementação para cada ferramenta específica
        when (tool.id) {
            "screen_recorder" -> startScreenRecording()
            "menu_editor" -> openMenuEditor()
            "visual_adjustments" -> openVisualAdjustments()
            "navigation_controls" -> openNavigationControls()
            "size_customization" -> openSizeCustomization()
            else -> {
                Toast.makeText(
                    this,
                    "Ferramenta ${tool.name} em desenvolvimento",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Implementações de cada ferramenta

    private fun startScreenRecording() {
        Toast.makeText(
            this,
            "Iniciando gravação de tela...",
            Toast.LENGTH_SHORT
        ).show()
        // Implementação real iria aqui
    }

    private fun openMenuEditor() {
        Toast.makeText(
            this,
            "Abrindo editor de menus...",
            Toast.LENGTH_SHORT
        ).show()
        // Implementação real iria aqui
    }

    private fun openVisualAdjustments() {
        Toast.makeText(
            this,
            "Abrindo ajustes visuais...",
            Toast.LENGTH_SHORT
        ).show()
        // Implementação real iria aqui
    }

    private fun openNavigationControls() {
        Toast.makeText(
            this,
            "Abrindo controles de navegação...",
            Toast.LENGTH_SHORT
        ).show()
        // Implementação real iria aqui
    }

    private fun openSizeCustomization() {
        Toast.makeText(
            this,
            "Abrindo personalização por tamanho...",
            Toast.LENGTH_SHORT
        ).show()
        // Implementação real iria aqui
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /**
     * Classe que representa uma ferramenta de desenvolvedor
     */
    data class DeveloperTool(
        val id: String,
        val name: String,
        val icon: String
    )
}