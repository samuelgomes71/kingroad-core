// TrashBinScreen.js
// Tela de lixeira para gerenciamento de arquivos excluídos

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Image
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import moment from 'moment';
import 'moment/locale/pt-br';
import FileStorageManager from '../utils/FileStorageManager';
import { formatFileSize } from '../utils/fileUtils';

// Definir o locale do moment para português
moment.locale('pt-br');

const TrashBinScreen = () => {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectMode, setSelectMode] = useState(false);
  
  // Carregar arquivos da lixeira
  const loadTrashFiles = async () => {
    try {
      setLoading(true);
      const trashFiles = await FileStorageManager.getTrashFiles();
      setFiles(trashFiles);
    } catch (error) {
      console.error('Erro ao carregar arquivos da lixeira:', error);
      Alert.alert('Erro', 'Não foi possível carregar os arquivos da lixeira');
    } finally {
      setLoading(false);
    }
  };
  
  // Carregar arquivos quando a tela receber foco
  useFocusEffect(
    useCallback(() => {
      loadTrashFiles();
    }, [])
  );
  
  // Função para atualizar a lista ao puxar para baixo
  const onRefresh = async () => {
    setRefreshing(true);
    await loadTrashFiles();
    setRefreshing(false);
  };
  
  // Restaurar um arquivo da lixeira
  const restoreFile = async (filePath) => {
    try {
      setLoading(true);
      await FileStorageManager.restoreFromTrash(filePath);
      
      // Atualizar a lista de arquivos na lixeira
      setFiles(files.filter(file => file.path !== filePath));
      
      Alert.alert('Sucesso', 'Arquivo restaurado com sucesso');
    } catch (error) {
      console.error('Erro ao restaurar arquivo:', error);
      Alert.alert('Erro', 'Não foi possível restaurar o arquivo');
    } finally {
      setLoading(false);
    }
  };
  
  // Excluir um arquivo permanentemente
  const deleteFilePermanently = async (filePath) => {
    try {
      setLoading(true);
      const success = await FileStorageManager.deletePermanently(filePath);
      
      if (success) {
        // Atualizar a lista de arquivos na lixeira
        setFiles(files.filter(file => file.path !== filePath));
        Alert.alert('Sucesso', 'Arquivo excluído permanentemente');
      } else {
        throw new Error('Falha ao excluir arquivo');
      }
    } catch (error) {
      console.error('Erro ao excluir arquivo permanentemente:', error);
      Alert.alert('Erro', 'Não foi possível excluir o arquivo');
    } finally {
      setLoading(false);
    }
  };
  
  // Confirmar restauração de arquivo
  const confirmRestore = (filePath) => {
    Alert.alert(
      'Restaurar Arquivo',
      'Tem certeza que deseja restaurar este arquivo?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Restaurar',
          onPress: () => restoreFile(filePath)
        }
      ]
    );
  };
  
  // Confirmar exclusão permanente de arquivo
  const confirmDelete = (filePath) => {
    Alert.alert(
      'Excluir Permanentemente',
      'Este arquivo será excluído permanentemente e não poderá ser recuperado. Continuar?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () => deleteFilePermanently(filePath)
        }
      ]
    );
  };
  
  // Esvaziar a lixeira
  const emptyTrash = async () => {
    try {
      setLoading(true);
      const success = await FileStorageManager.emptyTrash();
      
      if (success) {
        setFiles([]);
        Alert.alert('Sucesso', 'Lixeira esvaziada com sucesso');
      } else {
        throw new Error('Falha ao esvaziar lixeira');
      }
    } catch (error) {
      console.error('Erro ao esvaziar lixeira:', error);
      Alert.alert('Erro', 'Não foi possível esvaziar a lixeira');
    } finally {
      setLoading(false);
    }
  };
  
  // Confirmar esvaziamento da lixeira
  const confirmEmptyTrash = () => {
    if (files.length === 0) {
      Alert.alert('Lixeira Vazia', 'Não há arquivos para excluir');
      return;
    }
    
    Alert.alert(
      'Esvaziar Lixeira',
      'Todos os arquivos serão excluídos permanentemente e não poderão ser recuperados. Continuar?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Esvaziar',
          style: 'destructive',
          onPress: emptyTrash
        }
      ]
    );
  };
  
  // Alternar seleção de um arquivo
  const toggleSelectFile = (filePath) => {
    setSelectedFiles(prevSelected => {
      if (prevSelected.includes(filePath)) {
        return prevSelected.filter(path => path !== filePath);
      } else {
        return [...prevSelected, filePath];
      }
    });
  };
  
  // Entrar no modo de seleção
  const enterSelectMode = () => {
    setSelectMode(true);
    setSelectedFiles([]);
  };
  
  // Sair do modo de seleção
  const exitSelectMode = () => {
    setSelectMode(false);
    setSelectedFiles([]);
  };
  
  // Restaurar arquivos selecionados
  const restoreSelectedFiles = async () => {
    if (selectedFiles.length === 0) return;
    
    try {
      setLoading(true);
      
      for (const filePath of selectedFiles) {
        await FileStorageManager.restoreFromTrash(filePath);
      }
      
      // Atualizar a lista de arquivos na lixeira
      setFiles(files.filter(file => !selectedFiles.includes(file.path)));
      
      Alert.alert('Sucesso', 'Arquivos restaurados com sucesso');
      exitSelectMode();
    } catch (error) {
      console.error('Erro ao restaurar arquivos selecionados:', error);
      Alert.alert('Erro', 'Não foi possível restaurar alguns arquivos');
    } finally {
      setLoading(false);
    }
  };
  
  // Excluir arquivos selecionados
  const deleteSelectedFiles = async () => {
    if (selectedFiles.length === 0) return;
    
    try {
      setLoading(true);
      
      for (const filePath of selectedFiles) {
        await FileStorageManager.deletePermanently(filePath);
      }
      
      // Atualizar a lista de arquivos na lixeira
      setFiles(files.filter(file => !selectedFiles.includes(file.path)));
      
      Alert.alert('Sucesso', 'Arquivos excluídos permanentemente');
      exitSelectMode();
    } catch (error) {
      console.error('Erro ao excluir arquivos selecionados:', error);
      Alert.alert('Erro', 'Não foi possível excluir alguns arquivos');
    } finally {
      setLoading(false);
    }
  };
  
  // Confirmar restauração de arquivos selecionados
  const confirmRestoreSelected = () => {
    if (selectedFiles.length === 0) {
      Alert.alert('Nenhum Arquivo Selecionado', 'Selecione arquivos para restaurar');
      return;
    }
    
    Alert.alert(
      'Restaurar Arquivos',
      `Tem certeza que deseja restaurar ${selectedFiles.length} arquivo(s)?`,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Restaurar',
          onPress: restoreSelectedFiles
        }
      ]
    );
  };
  
  // Confirmar exclusão de arquivos selecionados
  const confirmDeleteSelected = () => {
    if (selectedFiles.length === 0) {
      Alert.alert('Nenhum Arquivo Selecionado', 'Selecione arquivos para excluir');
      return;
    }
    
    Alert.alert(
      'Excluir Permanentemente',
      `${selectedFiles.length} arquivo(s) serão excluídos permanentemente e não poderão ser recuperados. Continuar?`,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: deleteSelectedFiles
        }
      ]
    );
  };
  
  // Determinar o ícone para o tipo de arquivo
  const getFileIcon = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
      return 'image';
    } else if (['mp4', 'avi', 'mov', 'wmv'].includes(extension)) {
      return 'videocam';
    } else if (['mp3', 'wav', 'ogg'].includes(extension)) {
      return 'audiotrack';
    } else if (['pdf'].includes(extension)) {
      return 'picture-as-pdf';
    } else if (['doc', 'docx'].includes(extension)) {
      return 'description';
    } else if (['xls', 'xlsx'].includes(extension)) {
      return 'table-chart';
    } else if (['ppt', 'pptx'].includes(extension)) {
      return 'slideshow';
    } else if (['zip', 'rar', '7z'].includes(extension)) {
      return 'folder-zip';
    } else {
      return 'insert-drive-file';
    }
  };
  
  // Renderizar um item da lista de arquivos
  const renderItem = ({ item }) => {
    const isSelected = selectedFiles.includes(item.path);
    
    return (
      <TouchableOpacity
        style={[styles.fileItem, isSelected && styles.selectedItem]}
        onPress={() => selectMode ? toggleSelectFile(item.path) : null}
        onLongPress={() => !selectMode ? enterSelectMode() : null}
      >
        <View style={styles.fileIconContainer}>
          <Icon name={getFileIcon(item.name)} size={36} color="#4285f4" />
        </View>
        <View style={styles.fileInfo}>
          <Text style={styles.fileName} numberOfLines={1}>{item.name}</Text>
          <View style={styles.fileDetails}>
            <Text style={styles.fileSize}>{formatFileSize(item.size)}</Text>
            <Text style={styles.fileDate}>
              {moment(item.mtime).format('DD MMM, YYYY')}
            </Text>
            <Text style={styles.fileDuration}>
              Excluído há {moment(item.mtime).fromNow(true)}
            </Text>
          </View>
        </View>
        
        {selectMode ? (
          <View style={styles.checkbox}>
            <Icon 
              name={isSelected ? 'check-circle' : 'radio-button-unchecked'} 
              size={24} 
              color={isSelected ? '#4285f4' : '#888'}
            />
          </View>
        ) : (
          <View style={styles.fileActions}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => confirmRestore(item.path)}
            >
              <Icon name="restore" size={22} color="#4285f4" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => confirmDelete(item.path)}
            >
              <Icon name="delete-forever" size={22} color="#e74c3c" />
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    );
  };
  
  // Renderizar cabeçalho da lista
  const renderHeader = () => {
    if (files.length === 0 && !loading) {
      return null;
    }
    
    return (
      <View style={styles.listHeader}>
        <Text style={styles.headerText}>
          {files.length} {files.length === 1 ? 'arquivo' : 'arquivos'} na lixeira
        </Text>
        <Text style={styles.headerSubtext}>
          Os arquivos serão excluídos permanentemente após 7 dias
        </Text>
      </View>
    );
  };
  
  // Renderizar mensagem de lixeira vazia
  const renderEmpty = () => {
    if (loading) return null;
    
    return (
      <View style={styles.emptyContainer}>
        <Icon name="delete-outline" size={80} color="#ccc" />
        <Text style={styles.emptyText}>Lixeira Vazia</Text>
        <Text style={styles.emptySubtext}>
          Os arquivos excluídos aparecerão aqui por 7 dias antes de serem excluídos permanentemente
        </Text>
      </View>
    );
  };
  
  return (
    <View style={styles.container}>
      {/* Cabeçalho */}
      <View style={styles.header}>
        <View style={styles.headerTitleContainer}>
          <Icon name="delete" size={24} color="#333" />
          <Text style={styles.headerTitle}>Lixeira</Text>
        </View>
        
        {selectMode ? (
          <View style={styles.selectionActions}>
            <Text style={styles.selectionCount}>
              {selectedFiles.length} selecionado{selectedFiles.length !== 1 ? 's' : ''}
            </Text>
            <TouchableOpacity style={styles.headerButton} onPress={exitSelectMode}>
              <Icon name="close" size={24} color="#333" />
            </TouchableOpacity>
          </View>
        ) : (
          files.length > 0 && (
            <TouchableOpacity style={styles.headerButton} onPress={confirmEmptyTrash}>
              <Icon name="delete-sweep" size={24} color="#e74c3c" />
            </TouchableOpacity>
          )
        )}
      </View>
      
      {/* Lista de arquivos */}
      <FlatList
        data={files}
        renderItem={renderItem}
        keyExtractor={(item) => item.path}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={files.length === 0 ? styles.emptyList : null}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
      
      {/* Barra de ações no modo de seleção */}
      {selectMode && selectedFiles.length > 0 && (
        <View style={styles.selectionToolbar}>
          <TouchableOpacity
            style={styles.toolbarButton}
            onPress={confirmRestoreSelected}
          >
            <Icon name="restore" size={24} color="#fff" />
            <Text style={styles.toolbarButtonText}>Restaurar</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.toolbarButton}
            onPress={confirmDeleteSelected}
          >
            <Icon name="delete-forever" size={24} color="#fff" />
            <Text style={styles.toolbarButtonText}>Excluir</Text>
          </TouchableOpacity>
        </View>
      )}
      
      {/* Indicador de carregamento */}
      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4285f4" />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f7f7',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    elevation: 2,
  },
  headerTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  headerButton: {
    padding: 8,
  },
  selectionActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectionCount: {
    fontSize: 16,
    marginRight: 8,
  },
  listHeader: {
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  headerSubtext: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
  },
  fileItem: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  selectedItem: {
    backgroundColor: '#e3f2fd',
  },
  fileIconContainer: {
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  fileInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  fileName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  fileDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  fileSize: {
    fontSize: 14,
    color: '#666',
    marginRight: 8,
  },
  fileDate: {
    fontSize: 14,
    color: '#666',
    marginRight: 8,
  },
  fileDuration: {
    fontSize: 14,
    color: '#888',
  },
  fileActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    padding: 8,
    marginLeft: 4,
  },
  checkbox: {
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#888',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    marginTop: 8,
  },
  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectionToolbar: {
    flexDirection: 'row',
    backgroundColor: '#4285f4',
    padding: 12,
    justifyContent: 'space-around',
  },
  toolbarButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
  },
  toolbarButtonText: {
    color: '#fff',
    marginLeft: 8,
    fontWeight: '500',
    fontSize: 16,
  },
});

export default TrashBinScreen;