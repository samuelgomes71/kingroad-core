import React, { useState } from 'react';
import { 
  AlertTriangle, 
  MapPin, 
  ShieldAlert, 
  Truck, 
  Cloud, 
  X, 
  Camera, 
  Send, 
  MessageCircle, 
  Clock,
  ChevronRight
} from 'lucide-react';

// Componente interno para o menu de reportes
const QuickReportMenuInner = ({ onClose }) => {
  const [selectedType, setSelectedType] = useState(null);
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  // Tipos de reportes
  const reportTypes = [
    { id: 'roadblock', icon: <MapPin size={24} />, label: 'Bloqueio', color: 'bg-red-500' },
    { id: 'police', icon: <ShieldAlert size={24} />, label: 'Polícia', color: 'bg-blue-500' },
    { id: 'accident', icon: <AlertTriangle size={24} />, label: 'Acidente', color: 'bg-amber-500' },
    { id: 'heavy_traffic', icon: <Truck size={24} />, label: 'Trânsito', color: 'bg-orange-500' },
    { id: 'weather', icon: <Cloud size={24} />, label: 'Clima', color: 'bg-indigo-500' },
    { id: 'other', icon: <MessageCircle size={24} />, label: 'Outro', color: 'bg-gray-500' }
  ];
  
  // Botões de tempo estimado para resolução
  const timeButtons = [
    { duration: 30, label: '30 min' },
    { duration: 60, label: '1 hora' },
    { duration: 180, label: '3 horas' },
    { duration: 0, label: 'Não sei' }
  ];
  
  const handleSubmit = () => {
    setIsSubmitting(true);
    
    // Simular envio
    setTimeout(() => {
      setIsSubmitting(false);
      setShowConfirmation(true);
    }, 1000);
  };
  
  return (
    <div className="bg-gray-900 rounded-lg w-full max-w-sm overflow-hidden shadow-xl">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center p-4 border-b border-gray-800">
        <h2 className="text-lg font-bold text-white">Reportar Situação</h2>
        <button 
          onClick={onClose}
          className="text-gray-400 hover:text-white"
        >
          <X size={24} />
        </button>
      </div>
      
      {showConfirmation ? (
        /* Tela de confirmação */
        <div className="p-6 flex flex-col items-center text-center">
          <div className="bg-green-600 rounded-full p-4 mb-4">
            <Send size={32} className="text-white" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Reporte enviado!</h3>
          <p className="text-gray-400 mb-4">Obrigado por contribuir com a comunidade KingRoad.</p>
          <p className="text-sm text-gray-500">Este aviso será fechado automaticamente...</p>
        </div>
      ) : (
        <div className="p-4">
          {selectedType ? (
            /* Formulário de detalhes */
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                <div className={`p-2 rounded-lg ${reportTypes.find(type => type.id === selectedType)?.color}`}>
                  {reportTypes.find(type => type.id === selectedType)?.icon}
                </div>
                <div>
                  <h3 className="text-white font-medium">
                    {reportTypes.find(type => type.id === selectedType)?.label}
                  </h3>
                  <button 
                    onClick={() => setSelectedType(null)}
                    className="text-sm text-blue-400"
                  >
                    Trocar
                  </button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Tempo estimado de resolução
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {timeButtons.map(btn => (
                    <button
                      key={btn.duration}
                      className="bg-gray-800 text-white p-2 rounded-lg text-sm hover:bg-gray-700 flex items-center justify-center"
                    >
                      <Clock size={16} className="mr-2" />
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Adicionar detalhes (opcional)
                </label>
                <textarea
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3 h-24"
                  placeholder="Descreva a situação..."
                ></textarea>
              </div>
              
              <div className="flex justify-between">
                <button
                  className="bg-gray-800 text-white p-3 rounded-lg flex items-center"
                >
                  <Camera size={18} className="mr-2" />
                  Foto
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-blue-600 text-white px-4 py-3 rounded-lg flex items-center"
                >
                  {isSubmitting ? (
                    <span>Enviando...</span>
                  ) : (
                    <>
                      <Send size={18} className="mr-2" />
                      Enviar Reporte
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            /* Seleção de tipo de reporte */
            <div>
              <h3 className="text-white mb-3">Selecione o tipo de situação:</h3>
              <div className="grid grid-cols-2 gap-3">
                {reportTypes.map(type => (
                  <button
                    key={type.id}
                    onClick={() => setSelectedType(type.id)}
                    className="bg-gray-800 p-3 rounded-lg flex flex-col items-center hover:bg-gray-700"
                  >
                    <div className={`p-2 rounded-full ${type.color} mb-2`}>
                      {type.icon}
                    </div>
                    <span className="text-white text-sm">{type.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      
      {!selectedType && !showConfirmation && (
        <div className="p-4 border-t border-gray-800">
          <button className="w-full text-left flex items-center justify-between text-gray-400 py-2">
            <span>Reportes recentes nesta área</span>
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
};

// Componente de demonstração
const QuickReportDemo = () => {
  const [isOpen, setIsOpen] = useState(true);
  
  return (
    <div className="min-h-screen bg-gray-800 flex flex-col items-center justify-center p-4">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center"
        >
          <AlertTriangle size={18} className="mr-2" />
          Reportar Problema
        </button>
      ) : (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <QuickReportMenuInner onClose={() => setIsOpen(false)} />
        </div>
      )}
    </div>
  );
};

export default QuickReportDemo;