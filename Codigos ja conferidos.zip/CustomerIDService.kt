package com.kingroad.api

import com.kingroad.database.CustomerIDDao
import com.kingroad.database.CustomerID

class CustomerIDService(private val customerIDDao: CustomerIDDao) {

    fun buscarDestinoPorID(customerID: String): CustomerID? {
        return customerIDDao.getCustomerByID(customerID)
    }
}
