package com.kingroad.security.reputation

import com.kingroad.security.alerts.SecurityAlert
import com.kingroad.security.alerts.SecurityAlertComment
import com.kingroad.security.users.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.serialization.Serializable

/**
 * Entidade que representa a verificação de um alerta por um motorista
 */
@Serializable
data class AlertVerification(
    val id: String,
    val alertId: String,
    val userId: String,
    val isConfirmed: Boolean,
    val comment: String? = null,
    val timestamp: Instant = Clock.System.now()
)

/**
 * Entidade que representa a reputação de um usuário
 */
@Serializable
data class UserReputation(
    val userId: String,
    val score: Double,
    val totalAlertsReported: Int,
    val confirmedAlertsCount: Int,
    val rejectedAlertsCount: Int,
    val lastUpdated: Instant = Clock.System.now()
)

/**
 * Resultado da análise de reputação de um alerta
 */
@Serializable
data class AlertReputationResult(
    val alertId: String,
    val score: Double,
    val confidenceLevel: ConfidenceLevel,
    val verificationCount: Int,
    val confirmationCount: Int,
    val rejectionCount: Int
)

/**
 * Níveis de confiança para alertas
 */
enum class ConfidenceLevel {
    HIGH, MEDIUM, LOW, UNVERIFIED
}

/**
 * Serviço responsável pelo gerenciamento de reputação
 */
class ReputationService(
    private val alertRepository: SecurityAlertRepository,
    private val verificationRepository: AlertVerificationRepository,
    private val userReputationRepository: UserReputationRepository
) {
    /**
     * Obtém o histórico de alertas do usuário
     */
    suspend fun getUserAlertHistory(userId: String): List<SecurityAlert> {
        return alertRepository.getAlertsByUserId(userId)
    }
    
    /**
     * Obtém as verificações de um alerta
     */
    suspend fun getAlertVerifications(alertId: String): List<AlertVerification> {
        return verificationRepository.getVerificationsByAlertId(alertId)
    }
    
    /**
     * Verifica um alerta (confirmação ou rejeição)
     */
    suspend fun verifyAlert(verification: AlertVerification): AlertVerification {
        val saved = verificationRepository.saveVerification(verification)
        
        // Recalcular reputação do alerta
        calculateAlertReputation(verification.alertId)
        
        // Atualizar reputação do usuário que reportou o alerta
        val alert = alertRepository.getAlertById(verification.alertId)
        alert?.let {
            updateUserReputation(it.userId)
        }
        
        return saved
    }
    
    /**
     * Calcula a reputação de um alerta com base nas verificações
     */
    suspend fun calculateAlertReputation(alertId: String): AlertReputationResult {
        val alert = alertRepository.getAlertById(alertId) 
            ?: throw IllegalArgumentException("Alerta não encontrado: $alertId")
            
        val userReputation = userReputationRepository.getUserReputation(alert.userId)
        val verifications = verificationRepository.getVerificationsByAlertId(alertId)
        
        // Base inicial baseada na reputação do usuário
        val baseScore = userReputation?.score ?: 50.0
        
        // Calcular com base nas verificações
        val confirmations = verifications.count { it.isConfirmed }
        val rejections = verifications.size - confirmations
        
        // Fator de verificação (impacto maior com mais verificações)
        val verificationFactor = if (verifications.isNotEmpty()) {
            (confirmations.toDouble() / verifications.size) * 
            (1.0 + (verifications.size.coerceAtMost(10) / 10.0))
        } else {
            0.0
        }
        
        // Ajuste final
        val finalScore = (baseScore * 0.7) + (verificationFactor * 30.0)
        val normalizedScore = finalScore.coerceIn(0.0, 100.0)
        
        // Determinar nível de confiança
        val confidenceLevel = when {
            verifications.isEmpty() -> ConfidenceLevel.UNVERIFIED
            normalizedScore >= 80.0 -> ConfidenceLevel.HIGH
            normalizedScore >= 50.0 -> ConfidenceLevel.MEDIUM
            else -> ConfidenceLevel.LOW
        }
        
        return AlertReputationResult(
            alertId = alertId,
            score = normalizedScore,
            confidenceLevel = confidenceLevel,
            verificationCount = verifications.size,
            confirmationCount = confirmations,
            rejectionCount = rejections
        )
    }
    
    /**
     * Atualiza a reputação de um usuário com base no histórico
     */
    suspend fun updateUserReputation(userId: String): UserReputation {
        val alerts = alertRepository.getAlertsByUserId(userId)
        val alertIds = alerts.map { it.id }
        
        // Obter todas as verificações para os alertas deste usuário
        val allVerifications = alertIds.flatMap { 
            verificationRepository.getVerificationsByAlertId(it) 
        }
        
        // Calcular estatísticas
        val confirmedAlerts = alertIds.count { alertId ->
            val verifications = allVerifications.filter { it.alertId == alertId }
            verifications.count { it.isConfirmed } > verifications.count { !it.isConfirmed }
        }
        
        val rejectedAlerts = alertIds.count { alertId ->
            val verifications = allVerifications.filter { it.alertId == alertId }
            verifications.isNotEmpty() && 
            verifications.count { !it.isConfirmed } > verifications.count { it.isConfirmed }
        }
        
        // Calcular pontuação
        val accuracyScore = if (alerts.isNotEmpty()) {
            (confirmedAlerts.toDouble() / alerts.size) * 80.0
        } else {
            50.0 // Pontuação neutra para novos usuários
        }
        
        // Bônus por experiência (até 20 pontos)
        val experienceBonus = (alerts.size.coerceAtMost(20) / 20.0) * 20.0
        
        // Pontuação final
        val finalScore = (accuracyScore + experienceBonus).coerceIn(0.0, 100.0)
        
        val userReputation = UserReputation(
            userId = userId,
            score = finalScore,
            totalAlertsReported = alerts.size,
            confirmedAlertsCount = confirmedAlerts,
            rejectedAlertsCount = rejectedAlerts
        )
        
        return userReputationRepository.saveUserReputation(userReputation)
    }
    
    /**
     * Filtra alertas por nível de confiança
     */
    suspend fun filterAlertsByConfidence(
        alerts: List<SecurityAlert>,
        minimumConfidence: ConfidenceLevel
    ): Flow<SecurityAlert> = flow {
        val confidenceLevels = ConfidenceLevel.values()
        val minimumLevel = confidenceLevels.indexOf(minimumConfidence)
        
        for (alert in alerts) {
            val reputation = calculateAlertReputation(alert.id)
            val alertLevel = confidenceLevels.indexOf(reputation.confidenceLevel)
            
            if (alertLevel >= minimumLevel) {
                emit(alert)
            }
        }
    }
}

/**
 * Interface para o repositório de verificações de alertas
 */
interface AlertVerificationRepository {
    suspend fun getVerificationsByAlertId(alertId: String): List<AlertVerification>
    suspend fun saveVerification(verification: AlertVerification): AlertVerification
    suspend fun getVerificationsByUserId(userId: String): List<AlertVerification>
}

/**
 * Interface para o repositório de reputação de usuários
 */
interface UserReputationRepository {
    suspend fun getUserReputation(userId: String): UserReputation?
    suspend fun saveUserReputation(reputation: UserReputation): UserReputation
}

/**
 * Interface para o repositório de alertas de segurança
 */
interface SecurityAlertRepository {
    suspend fun getAlertById(alertId: String): SecurityAlert?
    suspend fun getAlertsByUserId(userId: String): List<SecurityAlert>
}