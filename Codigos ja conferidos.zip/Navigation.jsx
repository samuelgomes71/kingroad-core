import React, { useState } from 'react';
import NavigationPanel from './NavigationPanel';
import mapBackground from '../assets/images/map-background.png';
import pinIcon from '../assets/icons/pin-icon.svg';
import routeIcon from '../assets/icons/route-icon.svg';
import poiIcon from '../assets/icons/poi-icon.svg';
import shareIcon from '../assets/icons/share-icon.svg';

/**
 * Tela principal de navegação com design premium do KingRoad
 * Salvar em: web/src/components/Navigation.jsx
 */
const Navigation = () => {
  const [showPOIs, setShowPOIs] = useState(true);
  const [viewMode, setViewMode] = useState('3d');
  
  // Simulação de POIs - substituir por dados reais da API
  const pois = [
    { id: 1, name: "Posto Shell", type: "gas_station", distance: "2.3 km" },
    { id: 2, name: "Restaurante Bom Prato", type: "restaurant", distance: "5.1 km" },
    { id: 3, name: "Borracharia 24h", type: "service", distance: "12.7 km" },
    { id: 4, name: "Área de Descanso", type: "rest_area", distance: "28.4 km" }
  ];

  return (
    <div className="navigation-container">
      <div className="map-area" style={{ backgroundImage: `url(${mapBackground})` }}>
        {/* Aqui você integraria a real API de mapas */}
        <div className="map-overlay">
          <div className="map-controls">
            <button 
              className={`map-control-btn ${viewMode === '2d' ? 'active' : ''}`}
              onClick={() => setViewMode('2d')}
            >
              2D
            </button>
            <button 
              className={`map-control-btn ${viewMode === '3d' ? 'active' : ''}`}
              onClick={() => setViewMode('3d')}
            >
              3D
            </button>
          </div>
          
          <div className="map-actions">
            <button className="map-action-btn">
              <img src={pinIcon} alt="Minha Localização" />
            </button>
            <button className="map-action-btn">
              <img src={routeIcon} alt="Rotas Salvas" />
            </button>
            <button 
              className={`map-action-btn ${showPOIs ? 'active' : ''}`}
              onClick={() => setShowPOIs(!showPOIs)}
            >
              <img src={poiIcon} alt="Pontos de Interesse" />
            </button>
            <button className="map-action-btn">
              <img src={shareIcon} alt="Compartilhar" />
            </button>
          </div>
        </div>
      </div>
      
      <div className="navigation-sidebar">
        <NavigationPanel />
        
        {showPOIs && (
          <div className="poi-panel">
            <div className="poi-header">
              <h3 className="poi-title">Pontos de Interesse</h3>
              <span className="poi-subtitle">Na sua rota</span>
            </div>
            
            <ul className="poi-list">
              {pois.map(poi => (
                <li key={poi.id} className="poi-item">
                  <div className="poi-icon">
                    <img 
                      src={poiIcon} 
                      alt={poi.type} 
                    />
                  </div>
                  <div className="poi-details">
                    <span className="poi-name">{poi.name}</span>
                    <span className="poi-type">
                      {poi.type === 'gas_station' 
                        ? 'Posto de combustível' 
                        : poi.type === 'restaurant' 
                          ? 'Restaurante' 
                          : poi.type === 'service' 
                            ? 'Serviço' 
                            : 'Área de Descanso'}
                    </span>
                  </div>
                  <div className="poi-distance">{poi.distance}</div>
                </li>
              ))}
            </ul>
            
            <button className="btn-secondary btn-block">Ver Todos os POIs</button>
          </div>
        )}
      </div>
      
      <style jsx>{`
        .navigation-container {
          display: flex;
          height: calc(100vh - 70px); /* Ajuste conforme altura do seu header */
          position: relative;
        }
        
        .map-area {
          flex: 1;
          position: relative;
          background-size: cover;
          background-position: center;
        }
        
        .map-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 1rem;
        }
        
        .map-controls {
          display: flex;
          align-self: flex-end;
          background-color: rgba(15, 15, 16, 0.8);
          border-radius: var(--border-radius-pill);
          padding: 0.25rem;
          border: 1px solid var(--gold-dark);
        }
        
        .map-control-btn {
          background: transparent;
          border: none;
          color: var(--text-light);
          padding: 0.5rem 1rem;
          border-radius: var(--border-radius-pill);
          cursor: pointer;
          font-size: var(--font-size-sm);
          transition: all 0.2s ease;
        }
        
        .map-control-btn.active {
          background-color: var(--gold-primary);
          color: var(--black-primary);
        }
        
        .map-actions {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          align-self: flex-start;
        }
        
        .map-action-btn {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background-color: rgba(15, 15, 16, 0.8);
          border: 1px solid var(--gold-dark);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .map-action-btn img {
          width: 20px;
          height: 20px;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .map-action-btn:hover {
          background-color: rgba(212, 175, 55, 0.2);
        }
        
        .map-action-btn.active {
          background-color: var(--gold-primary);
        }
        
        .map-action-btn.active img {
          filter: brightness(0);
        }
        
        .navigation-sidebar {
          width: 350px;
          background-color: var(--black-primary);
          height: 100%;
          overflow-y: auto;
          padding: 1.5rem;
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
          border-left: 1px solid var(--gold-dark);
        }
        
        .poi-panel {
          background-color: var(--black-secondary);
          border-radius: var(--border-radius-lg);
          border: 1px solid var(--gold-dark);
          padding: 1.5rem;
          box-shadow: var(--shadow-medium);
        }
        
        .poi-header {
          margin-bottom: 1rem;
          padding-bottom: 0.75rem;
          border-bottom: 1px solid rgba(212, 175, 55, 0.3);
        }
        
        .poi-title {
          color: var(--gold-primary);
          font-family: var(--font-primary);
          font-size: var(--font-size-lg);
          margin: 0;
          margin-bottom: 0.25rem;
        }
        
        .poi-subtitle {
          color: var(--text-light);
          font-size: var(--font-size-sm);
          opacity: 0.7;
        }
        
        .poi-list {
          list-style: none;
          padding: 0;
          margin: 0 0 1.5rem 0;
        }
        
        .poi-item {
          display: flex;
          align-items: center;
          padding: 0.75rem 0;
          border-bottom: 1px solid rgba(212, 175, 55, 0.1);
        }
        
        .poi-item:last-child {
          border-bottom: none;
        }
        
        .poi-icon {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background-color: rgba(212, 175, 55, 0.1);
          margin-right: 0.75rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .poi-icon img {
          width: 16px;
          height: 16px;
          filter: invert(70%) sepia(93%) saturate(440%) hue-rotate(10deg) brightness(89%) contrast(91%);
        }
        
        .poi-details {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        
        .poi-name {
          color: var(--text-light);
          font-weight: 500;
        }
        
        .poi-type {
          color: var(--text-light);
          font-size: var(--font-size-xs);
          opacity: 0.7;
        }
        
        .poi-distance {
          color: var(--gold-primary);
          font-weight: 500;
          font-size: var(--font-size-sm);
        }
        
        .btn-secondary {
          background-color: transparent;
          color: var(--gold-primary);
          border: 1px solid var(--gold-primary);
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius-md);
          font-family: var(--font-primary);
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-size: var(--font-size-sm);
        }
        
        .btn-secondary:hover {
          background-color: rgba(212, 175, 55, 0.1);
          box-shadow: var(--gold-glow);
        }
        
        .btn-block {
          display: block;
          width: 100%;
          text-align: center;
        }
        
        @media (max-width: 992px) {
          .navigation-container {
            flex-direction: column;
            height: auto;
          }
          
          .map-area {
            height: 50vh;
          }
          
          .navigation-sidebar {
            width: 100%;
            border-left: none;
            border-top: 1px solid var(--gold-dark);
          }
        }
      `}</style>
    </div>
  );
};

export default Navigation;