/**
 * PhotoCapture.js
 * 
 * Componente para captura e visualização de fotos.
 * Permite tirar fotos ou selecionar da galeria, com suporte a 
 * prévia, remoção e limite de quantidade. Funciona com permissões
 * de câmera e mostra estados de carregamento.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Platform,
  Text,
  ScrollView,
  PermissionsAndroid
} from 'react-native';
import PropTypes from 'prop-types';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';

// Componentes personalizados
import Icon, { ICON_SETS, ICON_SIZES, ICON_STATES } from './Icon';
import { Button, IconButton } from './commonButtons';

// Constantes para tipos de ações
const PHOTO_ACTIONS = {
  TAKE_PHOTO: 'take_photo',
  SELECT_FROM_GALLERY: 'select_from_gallery',
  VIEW_PHOTO: 'view_photo',
  REMOVE_PHOTO: 'remove_photo'
};

// Constantes para tipos de orientação do layout
const LAYOUT_ORIENTATIONS = {
  HORIZONTAL: 'horizontal',
  VERTICAL: 'vertical',
  GRID: 'grid'
};

/**
 * Componente PhotoCapture para seleção e captura de imagens
 * @param {Object} props - Propriedades do componente
 * @returns {React.Component} Componente PhotoCapture
 */
const PhotoCapture = ({
  // Propriedades de configuração
  maxPhotos = 5,
  initialPhotos = [],
  maxFileSize = 10 * 1024 * 1024, // 10MB por padrão
  quality = 0.8,
  allowGallery = true,
  allowCamera = true,
  cameraOnly = false,
  galleryOnly = false,
  editable = true,
  layout = LAYOUT_ORIENTATIONS.HORIZONTAL,
  
  // Tamanhos e estilos
  thumbnailSize = 80,
  previewSize = 250,
  containerStyle = {},
  
  // Handlers
  onPhotoSelected = () => {},
  onPhotoRemoved = () => {},
  onError = () => {},
  
  // Textos para traduções
  texts = {
    addPhotoButton: 'Adicionar foto',
    takePhotoButton: 'Tirar foto',
    selectFromGalleryButton: 'Selecionar da galeria',
    photoLimitReached: 'Limite de fotos atingido',
    permissionDenied: 'Permissão negada',
    permissionDeniedCamera: 'Permissão de câmera negada. Por favor, habilite nas configurações do aplicativo.',
    permissionDeniedGallery: 'Permissão de galeria negada. Por favor, habilite nas configurações do aplicativo.',
    errorTooBig: 'Arquivo muito grande',
    photoActionTitle: 'Adicionar foto',
    photoActionMessage: 'Escolha uma opção',
    cancelButton: 'Cancelar',
    loading: 'Carregando...',
    errorLoadingPhoto: 'Erro ao carregar foto'
  }
}) => {
  // Estados
  const [photos, setPhotos] = useState(initialPhotos || []);
  const [loading, setLoading] = useState(false);
  const [cameraPermission, setCameraPermission] = useState(false);
  const [galleryPermission, setGalleryPermission] = useState(false);
  
  // Referência para o componente
  const scrollViewRef = useRef(null);

  // Efeito para verificar permissões ao montar o componente
  useEffect(() => {
    checkPermissions();
  }, []);

  /**
   * Verifica permissões de câmera e galeria
   */
  const checkPermissions = async () => {
    if (allowCamera) {
      const cameraPermissionStatus = await checkCameraPermission();
      setCameraPermission(cameraPermissionStatus);
    }
    
    if (allowGallery) {
      const galleryPermissionStatus = await checkGalleryPermission();
      setGalleryPermission(galleryPermissionStatus);
    }
  };

  /**
   * Verifica permissão de câmera
   * @returns {boolean} Status da permissão
   */
  const checkCameraPermission = async () => {
    try {
      const permission = Platform.OS === 'ios' 
        ? PERMISSIONS.IOS.CAMERA 
        : PERMISSIONS.ANDROID.CAMERA;
        
      const result = await check(permission);
      
      if (result === RESULTS.GRANTED) {
        return true;
      } else if (result === RESULTS.DENIED) {
        // Solicita permissão se ainda não concedida
        const requestResult = await request(permission);
        return requestResult === RESULTS.GRANTED;
      }
      
      return false;
    } catch (error) {
      console.error('[PhotoCapture] Erro ao verificar permissão da câmera:', error);
      return false;
    }
  };

  /**
   * Verifica permissão de galeria
   * @returns {boolean} Status da permissão
   */
  const checkGalleryPermission = async () => {
    try {
      let permission;
      
      if (Platform.OS === 'ios') {
        permission = PERMISSIONS.IOS.PHOTO_LIBRARY;
      } else {
        // Para Android, a permissão depende da versão do Android
        if (Platform.Version >= 33) { // Android 13+
          permission = PERMISSIONS.ANDROID.READ_MEDIA_IMAGES;
        } else {
          permission = PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE;
        }
      }
      
      const result = await check(permission);
      
      if (result === RESULTS.GRANTED) {
        return true;
      } else if (result === RESULTS.DENIED) {
        // Solicita permissão se ainda não concedida
        const requestResult = await request(permission);
        return requestResult === RESULTS.GRANTED;
      }
      
      return false;
    } catch (error) {
      console.error('[PhotoCapture] Erro ao verificar permissão da galeria:', error);
      return false;
    }
  };

  /**
   * Mostra o diálogo de opções para adicionar foto
   */
  const showPhotoActionDialog = () => {
    // Se estiver no limite de fotos, não mostra diálogo
    if (photos.length >= maxPhotos) {
      Alert.alert('', texts.photoLimitReached);
      return;
    }
    
    // Opções disponíveis com base nas flags
    const options = [];
    
    if (allowCamera && !galleryOnly) {
      options.push({
        text: texts.takePhotoButton,
        onPress: () => handlePhotoAction(PHOTO_ACTIONS.TAKE_PHOTO)
      });
    }
    
    if (allowGallery && !cameraOnly) {
      options.push({
        text: texts.selectFromGalleryButton,
        onPress: () => handlePhotoAction(PHOTO_ACTIONS.SELECT_FROM_GALLERY)
      });
    }
    
    // Adiciona opção de cancelar
    options.push({
      text: texts.cancelButton,
      style: 'cancel'
    });
    
    // Mostra alerta com opções
    Alert.alert(
      texts.photoActionTitle,
      texts.photoActionMessage,
      options,
      { cancelable: true }
    );
  };

  /**
   * Manipula as ações de foto (tirar, selecionar, remover)
   * @param {string} action - Tipo de ação
   * @param {Object} photoData - Dados da foto para ações específicas
   */
  const handlePhotoAction = async (action, photoData = null) => {
    switch (action) {
      case PHOTO_ACTIONS.TAKE_PHOTO:
        await takePhoto();
        break;
        
      case PHOTO_ACTIONS.SELECT_FROM_GALLERY:
        await selectFromGallery();
        break;
        
      case PHOTO_ACTIONS.REMOVE_PHOTO:
        removePhoto(photoData);
        break;
        
      case PHOTO_ACTIONS.VIEW_PHOTO:
        // Implement photo preview functionality
        // This could launch a modal with the full image
        break;
        
      default:
        console.warn(`[PhotoCapture] Ação desconhecida: ${action}`);
    }
  };

  /**
   * Captura uma foto usando a câmera
   */
  const takePhoto = async () => {
    try {
      // Verifica permissão
      if (!cameraPermission) {
        const hasPermission = await checkCameraPermission();
        
        if (!hasPermission) {
          Alert.alert('', texts.permissionDeniedCamera);
          onError('camera_permission_denied');
          return;
        }
        
        setCameraPermission(true);
      }
      
      // Configurações para captura de foto
      const options = {
        mediaType: 'photo',
        quality,
        maxWidth: 1200,
        maxHeight: 1200,
        includeBase64: false,
        saveToPhotos: false,
      };
      
      setLoading(true);
      
      // Lança a câmera
      const result = await launchCamera(options);
      
      setLoading(false);
      
      // Processa o resultado
      processImageResult(result);
      
    } catch (error) {
      setLoading(false);
      console.error('[PhotoCapture] Erro ao capturar foto:', error);
      onError('camera_error', error);
    }
  };

  /**
   * Seleciona uma foto da galeria
   */
  const selectFromGallery = async () => {
    try {
      // Verifica permissão
      if (!galleryPermission) {
        const hasPermission = await checkGalleryPermission();
        
        if (!hasPermission) {
          Alert.alert('', texts.permissionDeniedGallery);
          onError('gallery_permission_denied');
          return;
        }
        
        setGalleryPermission(true);
      }
      
      // Configurações para seleção de foto
      const options = {
        mediaType: 'photo',
        quality,
        maxWidth: 1200,
        maxHeight: 1200,
        includeBase64: false,
        selectionLimit: maxPhotos - photos.length,
      };
      
      setLoading(true);
      
      // Lança a galeria
      const result = await launchImageLibrary(options);
      
      setLoading(false);
      
      // Processa o resultado
      processImageResult(result);
      
    } catch (error) {
      setLoading(false);
      console.error('[PhotoCapture] Erro ao selecionar foto da galeria:', error);
      onError('gallery_error', error);
    }
  };

  /**
   * Processa o resultado da seleção/captura de imagem
   * @param {Object} result - Resultado da ação de foto
   */
  const processImageResult = (result) => {
    // Verifica se o usuário cancelou a ação
    if (result.didCancel) {
      return;
    }
    
    // Verifica se houve algum erro
    if (result.errorCode) {
      console.error(`[PhotoCapture] Erro: ${result.errorCode} - ${result.errorMessage}`);
      onError(result.errorCode, result.errorMessage);
      return;
    }
    
    // Processa as imagens selecionadas
    if (result.assets && result.assets.length > 0) {
      const newPhotos = [...photos];
      
      result.assets.forEach(asset => {
        // Verifica o tamanho do arquivo
        if (asset.fileSize > maxFileSize) {
          Alert.alert('', texts.errorTooBig);
          onError('file_too_big', { fileName: asset.fileName, fileSize: asset.fileSize });
          return;
        }
        
        // Verifica se já atingiu o limite
        if (newPhotos.length >= maxPhotos) {
          Alert.alert('', texts.photoLimitReached);
          return;
        }
        
        // Adiciona a nova foto
        newPhotos.push({
          uri: asset.uri,
          name: asset.fileName || `photo_${Date.now()}.jpg`,
          type: asset.type || 'image/jpeg',
          size: asset.fileSize,
          width: asset.width,
          height: asset.height,
          timestamp: Date.now()
        });
      });
      
      // Atualiza o estado
      setPhotos(newPhotos);
      
      // Notifica a aplicação
      onPhotoSelected(newPhotos);
      
      // Scroll para o final da lista
      setTimeout(() => {
        if (scrollViewRef.current && layout === LAYOUT_ORIENTATIONS.HORIZONTAL) {
          scrollViewRef.current.scrollToEnd({ animated: true });
        }
      }, 500);
    }
  };

  /**
   * Remove uma foto da lista
   * @param {Object} photo - Foto a ser removida
   */
  const removePhoto = (photo) => {
    // Encontra o índice da foto
    const index = photos.findIndex(p => p.uri === photo.uri);
    
    if (index >= 0) {
      // Cria uma nova lista sem a foto
      const newPhotos = [...photos];
      newPhotos.splice(index, 1);
      
      // Atualiza o estado
      setPhotos(newPhotos);
      
      // Notifica a aplicação
      onPhotoRemoved(photo, newPhotos);
    }
  };

  /**
   * Renderiza uma miniatura de foto
   * @param {Object} photo - Dados da foto
   * @param {number} index - Índice da foto na lista
   * @returns {React.Component} Componente de miniatura
   */
  const renderThumbnail = (photo, index) => {
    return (
      <View key={`${photo.uri}_${index}`} style={styles.thumbnailContainer}>
        <Image
          source={{ uri: photo.uri }}
          style={[
            styles.thumbnail, 
            { width: thumbnailSize, height: thumbnailSize }
          ]}
          resizeMode="cover"
        />
        
        {editable && (
          <TouchableOpacity
            style={styles.removeButton}
            onPress={() => handlePhotoAction(PHOTO_ACTIONS.REMOVE_PHOTO, photo)}
          >
            <Icon
              name="x-circle"
              set={ICON_SETS.FEATHER}
              size={ICON_SIZES.SMALL}
              color="#fff"
              state={ICON_STATES.ERROR}
              backgroundColor="rgba(0, 0, 0, 0.5)"
            />
          </TouchableOpacity>
        )}
      </View>
    );
  };

  /**
   * Renderiza o botão de adicionar foto
   * @returns {React.Component} Botão de adicionar foto
   */
  const renderAddButton = () => {
    // Se não for editável ou atingiu o limite, não mostra o botão
    if (!editable || photos.length >= maxPhotos) {
      return null;
    }
    
    // Se for grid, renderiza um botão normal
    if (layout === LAYOUT_ORIENTATIONS.GRID) {
      return (
        <TouchableOpacity
          style={[
            styles.addButton,
            { width: thumbnailSize, height: thumbnailSize }
          ]}
          onPress={showPhotoActionDialog}
        >
          <Icon
            name="plus"
            set={ICON_SETS.FEATHER}
            size={ICON_SIZES.MEDIUM}
            state={ICON_STATES.DEFAULT}
          />
          <Text style={styles.addButtonText}>
            {texts.addPhotoButton}
          </Text>
        </TouchableOpacity>
      );
    }
    
    // Para layouts horizontal e vertical, renderiza um ícone
    return (
      <TouchableOpacity
        style={[
          styles.addButtonIcon,
          { width: thumbnailSize, height: thumbnailSize }
        ]}
        onPress={showPhotoActionDialog}
      >
        <Icon
          name="plus-circle"
          set={ICON_SETS.FEATHER}
          size={ICON_SIZES.LARGE}
          state={ICON_STATES.ACTIVE}
        />
      </TouchableOpacity>
    );
  };

  /**
   * Renderiza o componente de acordo com o layout
   * @returns {React.Component} Componente renderizado
   */
  const renderContent = () => {
    // Renderiza indicador de carregamento, se necessário
    if (loading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#1E88E5" />
          <Text style={styles.loadingText}>{texts.loading}</Text>
        </View>
      );
    }
    
    // Layout da grade
    if (layout === LAYOUT_ORIENTATIONS.GRID) {
      return (
        <View style={styles.gridContainer}>
          {photos.map((photo, index) => renderThumbnail(photo, index))}
          {renderAddButton()}
        </View>
      );
    }
    
    // Layout horizontal com scroll
    if (layout === LAYOUT_ORIENTATIONS.HORIZONTAL) {
      return (
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalScrollContent}
        >
          {photos.map((photo, index) => renderThumbnail(photo, index))}
          {renderAddButton()}
        </ScrollView>
      );
    }
    
    // Layout vertical (padrão)
    return (
      <View style={styles.verticalContainer}>
        {photos.map((photo, index) => renderThumbnail(photo, index))}
        {renderAddButton()}
      </View>
    );
  };

  return (
    <View style={[styles.container, containerStyle]}>
      {renderContent()}
      
      {/* Botões principais abaixo do layout, se não houver fotos ainda */}
      {photos.length === 0 && editable && (
        <View style={styles.buttonsContainer}>
          {allowCamera && !galleryOnly && (
            <Button
              title={texts.takePhotoButton}
              leftIcon={{
                name: 'camera',
                set: ICON_SETS.FEATHER
              }}
              onPress={() => handlePhotoAction(PHOTO_ACTIONS.TAKE_PHOTO)}
              style={styles.actionButton}
            />
          )}
          
          {allowGallery && !cameraOnly && (
            <Button
              title={texts.selectFromGalleryButton}
              leftIcon={{
                name: 'image',
                set: ICON_SETS.FEATHER
              }}
              onPress={() => handlePhotoAction(PHOTO_ACTIONS.SELECT_FROM_GALLERY)}
              style={styles.actionButton}
            />
          )}
        </View>
      )}
    </View>
  );
};

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
  },
  horizontalScrollContent: {
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  verticalContainer: {
    flexDirection: 'column',
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  thumbnailContainer: {
    margin: 4,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#f0f0f0',
  },
  thumbnail: {
    borderRadius: 8,
  },
  removeButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    zIndex: 10,
  },
  addButton: {
    margin: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
  },
  addButtonIcon: {
    margin: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginTop: 4,
  },
  buttonsContainer: {
    marginTop: 16,
  },
  actionButton: {
    marginVertical: 6,
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  }
});

// Definição de PropTypes para documentação e validação
PhotoCapture.propTypes = {
  maxPhotos: PropTypes.number,
  initialPhotos: PropTypes.array,
  maxFileSize: PropTypes.number,
  quality: PropTypes.number,
  allowGallery: PropTypes.bool,
  allowCamera: PropTypes.bool,
  cameraOnly: PropTypes.bool,
  galleryOnly: PropTypes.bool,
  editable: PropTypes.bool,
  layout: PropTypes.oneOf(Object.values(LAYOUT_ORIENTATIONS)),
  thumbnailSize: PropTypes.number,
  previewSize: PropTypes.number,
  containerStyle: PropTypes.object,
  onPhotoSelected: PropTypes.func,
  onPhotoRemoved: PropTypes.func,
  onError: PropTypes.func,
  texts: PropTypes.object,
};

// Exporta o componente e constantes
export { PHOTO_ACTIONS, LAYOUT_ORIENTATIONS };
export default PhotoCapture;