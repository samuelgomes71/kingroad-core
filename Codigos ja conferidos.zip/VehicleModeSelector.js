import React, { useState, useEffect } from 'react';
import { Car, Truck, Bike, Map, ArrowRight, ChevronDown, ChevronUp, Settings } from 'lucide-react';

// Componente para alternar entre modos de veículo
// Implementa o componente futuro descrito em globalRecommendations: "VehicleModeSelector.js"

const VehicleModeSelector = ({
  currentMode = 'truck',
  onChange = () => {},
  language = 'pt',
  position = 'bottom', // 'bottom' ou 'top'
  isDarkMode = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedMode, setSelectedMode] = useState(currentMode);
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  // Cores do tema KingRoad
  const colors = {
    primary: '#0063B2',     // Azul KingRoad principal
    secondary: '#5CC8FF',   // Azul KingRoad secundário
    accent: '#FFB31A',      // Amarelo para alertas e destaques
    success: '#24A148',     // Verde para confirmações
    textInverse: '#FFFFFF'  // Texto em fundo colorido
  };
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      selectMode: 'Selecionar modo',
      truck: 'Caminhão',
      car: 'Carro',
      motorcycle: 'Moto',
      hiking: 'Trilha',
      changing: 'Mudando para',
      description: {
        truck: 'Rotas para caminhões, informações de pernoite, postos com diesel, altura de pontes',
        car: 'Rotas otimizadas para carros, postos de gasolina, estradas panorâmicas',
        motorcycle: 'Rotas para motos, estradas cênicas, avisos de pavimentação',
        hiking: 'Trilhas, pontos de descanso, água potável, altimetria'
      }
    },
    en: {
      selectMode: 'Select mode',
      truck: 'Truck',
      car: 'Car',
      motorcycle: 'Motorcycle',
      hiking: 'Hiking',
      changing: 'Changing to',
      description: {
        truck: 'Truck routes, overnight info, diesel stations, bridge heights',
        car: 'Optimized car routes, gas stations, scenic roads',
        motorcycle: 'Motorcycle routes, scenic roads, pavement warnings',
        hiking: 'Trails, rest spots, drinking water, altimetry'
      }
    },
    es: {
      selectMode: 'Seleccionar modo',
      truck: 'Camión',
      car: 'Coche',
      motorcycle: 'Moto',
      hiking: 'Senderismo',
      changing: 'Cambiando a',
      description: {
        truck: 'Rutas para camiones, información de pernocta, estaciones de diesel, altura de puentes',
        car: 'Rutas optimizadas para coches, gasolineras, carreteras panorámicas',
        motorcycle: 'Rutas para motos, carreteras escénicas, avisos de pavimentación',
        hiking: 'Senderos, puntos de descanso, agua potable, altimetría'
      }
    }
  };

  // Texto conforme o idioma
  const text = translations[language] || translations.en;
  
  // Definição dos modos de veículo
  const vehicleModes = [
    { 
      id: 'truck', 
      name: text.truck, 
      icon: <Truck size={24} />, 
      color: colors.primary,
      description: text.description.truck 
    },
    { 
      id: 'car', 
      name: text.car, 
      icon: <Car size={24} />, 
      color: colors.secondary,
      description: text.description.car
    },
    { 
      id: 'motorcycle', 
      name: text.motorcycle, 
      icon: <Bike size={24} />, 
      color: colors.accent,
      description: text.description.motorcycle
    },
    { 
      id: 'hiking', 
      name: text.hiking, 
      icon: <Map size={24} />, 
      color: colors.success,
      description: text.description.hiking
    }
  ];
  
  // Obtém o modo atual
  const currentVehicleMode = vehicleModes.find(mode => mode.id === selectedMode) || vehicleModes[0];
  
  // Atualiza o modo selecionado quando a prop currentMode muda
  useEffect(() => {
    setSelectedMode(currentMode);
  }, [currentMode]);
  
  // Toggle do menu
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  
  // Seleciona um novo modo
  const selectMode = (mode) => {
    if (mode.id === selectedMode) {
      setIsOpen(false);
      return;
    }
    
    setIsTransitioning(true);
    
    // Simula um tempo de transição para mostrar feedback ao usuário
    setTimeout(() => {
      setSelectedMode(mode.id);
      setIsOpen(false);
      setIsTransitioning(false);
      onChange(mode.id);
    }, 800);
  };
  
  // Renderiza o botão principal
  const renderMainButton = () => (
    <button
      onClick={toggleMenu}
      className={`flex items-center px-4 py-2 rounded-full shadow-md transition-all ${
        isOpen ? 'bg-gray-200 text-gray-800' : 'bg-white text-gray-800'
      }`}
      disabled={isTransitioning}
    >
      <div 
        className="p-1 rounded-full mr-2 text-white" 
        style={{ backgroundColor: currentVehicleMode.color }}
      >
        {currentVehicleMode.icon}
      </div>
      <span className="font-medium">{currentVehicleMode.name}</span>
      {isOpen ? (
        <ChevronUp size={20} className="ml-2" />
      ) : (
        <ChevronDown size={20} className="ml-2" />
      )}
    </button>
  );
  
  // Renderiza o menu de opções
  const renderMenu = () => {
    if (!isOpen) return null;
    
    return (
      <div className={`absolute ${position === 'bottom' ? 'top-full mt-2' : 'bottom-full mb-2'} left-0 right-0 bg-white rounded-lg shadow-xl overflow-hidden z-40`}>
        {vehicleModes.map((mode) => (
          <button
            key={mode.id}
            onClick={() => selectMode(mode)}
            className={`w-full flex items-center p-3 hover:bg-gray-50 transition-colors ${
              mode.id === selectedMode ? 'bg-gray-100' : ''
            }`}
          >
            <div 
              className="p-1 rounded-full mr-3 flex-shrink-0 text-white" 
              style={{ backgroundColor: mode.color }}
            >
              {mode.icon}
            </div>
            <div className="text-left">
              <div className="font-medium">{mode.name}</div>
              <div className="text-sm text-gray-500 mt-1">{mode.description}</div>
            </div>
            {mode.id === selectedMode && (
              <div className="ml-auto">
                <Settings size={16} className="text-gray-400" />
              </div>
            )}
          </button>
        ))}
      </div>
    );
  };
  
  // Renderiza a tela de transição
  const renderTransition = () => {
    if (!isTransitioning) return null;
    
    const nextMode = vehicleModes.find(mode => mode.id === selectedMode);
    
    return (
      <div className="fixed inset-0 bg-white bg-opacity-90 flex flex-col items-center justify-center z-50">
        <div className="flex items-center mb-6">
          <div 
            className="p-3 rounded-full text-white" 
            style={{ backgroundColor: currentVehicleMode.color }}
          >
            {currentVehicleMode.icon}
          </div>
          <ArrowRight size={32} className="mx-6 text-gray-400" />
          <div 
            className="p-3 rounded-full text-white" 
            style={{ backgroundColor: nextMode.color }}
          >
            {nextMode.icon}
          </div>
        </div>
        <p className="text-lg font-medium">
          {text.changing} <span className="font-bold">{nextMode.name}</span>
        </p>
        
        <div className="mt-8 w-48">
          <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-800 ease-in-out" 
              style={{ 
                width: '100%', 
                backgroundColor: nextMode.color,
                animation: 'progress 0.8s linear'
              }}
            />
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="relative">
      {/* Botão principal */}
      {renderMainButton()}
      
      {/* Menu de opções */}
      {renderMenu()}
      
      {/* Tela de transição */}
      {renderTransition()}
      
      {/* Estilos para animações */}
      <style jsx>{`
        @keyframes progress {
          from { width: 0%; }
          to { width: 100%; }
        }
      `}</style>
    </div>
  );
};

export default VehicleModeSelector;