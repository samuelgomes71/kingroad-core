// CountryMascotData.js
// Dados de países, mascotes e mensagens para a funcionalidade de boas-vindas ao cruzar fronteiras

// Importar as imagens dos mascotes (estas seriam importações reais em um projeto completo)
// Na implementação real, estas seriam importações de arquivos de imagem
const mascotImages = {
  'Tio Sam Alpino': require('../assets/mascots/tio-sam-alpino.png'),
  'Tio Sam Mexicano': require('../assets/mascots/tio-sam-mexicano.png'),
  'Tio Sam Pastor': require('../assets/mascots/tio-sam-pastor.png'),
  'Tio Sam Padrão': require('../assets/mascots/tio-sam-padrao.png'),
};

// Importar as bandeiras dos países (estas seriam importações reais em um projeto completo)
const countryFlags = {
  'Itália': require('../assets/flags/italy.png'),
  'México': require('../assets/flags/mexico.png'),
  'Portugal': require('../assets/flags/portugal.png'),
  // Adicionar mais países conforme necessário
};

// Importar fundos culturais (estas seriam importações reais em um projeto completo)
const backgroundImages = {
  'Itália': require('../assets/backgrounds/italy.jpg'),
  'México': require('../assets/backgrounds/mexico.jpg'),
  'Portugal': require('../assets/backgrounds/portugal.jpg'),
  // Adicionar mais países conforme necessário
};

// Importar áudios de saudação com sotaques regionais
const greetingAudios = {
  'Itália': require('../assets/audio/greetings/italy.mp3'),
  'México': require('../assets/audio/greetings/mexico.mp3'),
  'Portugal': require('../assets/audio/greetings/portugal.mp3'),
  // Adicionar mais países conforme necessário
};

// Lista de reações disponíveis para o usuário
const availableReactions = [
  { id: 'like', label: 'Curtir', emoji: '👍' },
  { id: 'love', label: 'Amar', emoji: '❤️' },
  { id: 'honk', label: 'Buzinar', emoji: '📢' },
  { id: 'photo', label: 'Foto', emoji: '📸' },
  { id: 'wow', label: 'Uau', emoji: '😮' },
];

// Definir dados para cada país
const countryData = {
  'Itália': {
    code: 'IT',
    mascot: 'Tio Sam Alpino',
    greeting: 'Benvenuto in Italia',
    mascotSpeech: 'Benvenuto, Q.R.A.! Strade sicure e ben tracciate, andiamo!',
    cities: ['Bergamo', 'Milano', 'Roma', 'Napoli', 'Firenze', 'Venezia'],
    backgroundImage: backgroundImages['Itália'],
    flagImage: countryFlags['Itália'],
    mascotImage: mascotImages['Tio Sam Alpino'],
    greetingAudio: greetingAudios['Itália'],
    // Animações disponíveis para o mascote
    animations: ['wave', 'wink', 'raiseHat'],
  },
  
  'México': {
    code: 'MX',
    mascot: 'Tio Sam Mexicano',
    greeting: '¡Bienvenido a México!',
    mascotSpeech: 'Órale, Q.R.A., estamos en tierra caliente. ¡A rodar con cuidado!',
    cities: ['Monterrey', 'Ciudad de México', 'Guadalajara', 'Cancún', 'Tijuana'],
    backgroundImage: backgroundImages['México'],
    flagImage: countryFlags['México'],
    mascotImage: mascotImages['Tio Sam Mexicano'],
    greetingAudio: greetingAudios['México'],
    animations: ['wave', 'wink', 'sombrero'],
  },
  
  'Portugal': {
    code: 'PT',
    mascot: 'Tio Sam Pastor',
    greeting: 'Bem-vindo a Portugal',
    mascotSpeech: 'Ora pois... já cá chegámos, pá! Tamos em terras portuguesas... o melhor país do mundo!',
    cities: ['Braga', 'Lisboa', 'Porto', 'Faro', 'Coimbra'],
    backgroundImage: backgroundImages['Portugal'],
    flagImage: countryFlags['Portugal'],
    mascotImage: mascotImages['Tio Sam Pastor'],
    greetingAudio: greetingAudios['Portugal'],
    animations: ['wave', 'wink', 'raiseCane'],
  },
  
  // Adicionar mais países conforme necessário
};

// Obter um país aleatório para testes
export const getRandomCountry = () => {
  const countries = Object.keys(countryData);
  const randomIndex = Math.floor(Math.random() * countries.length);
  return countries[randomIndex];
};

// Obter uma cidade aleatória de um país
export const getRandomCity = (country) => {
  if (!countryData[country]) return null;
  
  const cities = countryData[country].cities;
  const randomIndex = Math.floor(Math.random() * cities.length);
  return cities[randomIndex];
};

// Exportar os dados e funções auxiliares
export default {
  countryData,
  mascotImages,
  countryFlags,
  backgroundImages,
  greetingAudios,
  availableReactions,
  getRandomCountry,
  getRandomCity,
};