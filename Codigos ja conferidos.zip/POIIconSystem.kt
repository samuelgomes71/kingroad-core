// Sistema de Gerenciamento de Ícones POI
// app/src/main/kotlin/com/kingroad/poi/icons

class POIIconManager(
    private val iconStorage: IconStorage,
    private val userStorage: UserStorage,
    private val verificationService: VerificationService
) {
    data class POIIcon(
        val id: String,
        val name: String,
        val category: POICategory,
        val brand: String,
        val country: String?,
        val data: ByteArray,
        val source: IconSource,
        val verified: Boolean = false,
        val lastUpdate: Long = System.currentTimeMillis()
    )

    enum class POICategory {
        FUEL_STATION,     // Postos de combustível
        TRUCK_STOP,       // Paradas de caminhão
        RESTAURANT,       // Restaurantes
        CONVENIENCE,      // Lojas de conveniência
        SERVICE,          // Serviços
        CUSTOM           // Personalizado
    }

    enum class IconSource {
        SYSTEM,          // Ícones do sistema
        USER,            // Adicionado pelo usuário
        COMMUNITY        // Compartilhado pela comunidade
    }

    // Adicionar novo ícone
    suspend fun addIcon(
        name: String,
        category: POICategory,
        brand: String,
        iconData: ByteArray,
        country: String? = null
    ): POIIcon {
        // Validar dados do ícone
        validateIconData(iconData)
        
        val icon = POIIcon(
            id = generateId(),
            name = name,
            category = category,
            brand = brand,
            country = country,
            data = iconData,
            source = IconSource.USER
        )
        
        iconStorage.saveIcon(icon)
        return icon
    }

    // Buscar ícone por marca
    suspend fun findIconByBrand(brand: String): POIIcon? {
        return iconStorage.getIconsByBrand(brand)
            .firstOrNull { it.verified }
    }

    // Buscar ícones por categoria
    suspend fun findIconsByCategory(
        category: POICategory
    ): List<POIIcon> {
        return iconStorage.getIconsByCategory(category)
            .filter { it.verified }
    }

    // Adicionar ícone personalizado
    suspend fun addCustomIcon(
        name: String,
        iconData: ByteArray,
        category: POICategory = POICategory.CUSTOM
    ): POIIcon {
        validateIconData(iconData)
        
        val icon = POIIcon(
            id = generateId(),
            name = name,
            category = category,
            brand = name,
            data = iconData,
            source = IconSource.USER,
            verified = true
        )
        
        iconStorage.saveIcon(icon)
        return icon
    }

    // Substituir ícone existente
    suspend fun replaceIcon(
        originalIconId: String,
        newIconData: ByteArray
    ): POIIcon {
        val originalIcon = iconStorage.getIcon(originalIconId)
            ?: throw IconNotFoundException(originalIconId)
        
        validateIconData(newIconData)
        
        val updatedIcon = originalIcon.copy(
            data = newIconData,
            lastUpdate = System.currentTimeMillis(),
            verified = originalIcon.source == IconSource.USER
        )
        
        iconStorage.updateIcon(updatedIcon)
        return updatedIcon
    }

    // Sistema de pré-carregamento de ícones populares
    private val defaultIcons = mapOf(
        // Postos de combustível
        "SHELL" to POICategory.FUEL_STATION,
        "BP" to POICategory.FUEL_STATION,
        "PETROBRAS" to POICategory.FUEL_STATION,
        "IRVING" to POICategory.FUEL_STATION,
        "PILOT" to POICategory.FUEL_STATION,
        "FLYING_J" to POICategory.FUEL_STATION,
        "PETRO_CANADA" to POICategory.FUEL_STATION,
        "ULTRAMAR" to POICategory.FUEL_STATION,
        "TOTAL" to POICategory.FUEL_STATION,
        "ESSO" to POICategory.FUEL_STATION,
        "VALCARCE" to POICategory.FUEL_STATION,
        "PRIO" to POICategory.FUEL_STATION,
        "GALP" to POICategory.FUEL_STATION,
        
        // Restaurantes
        "MCDONALDS" to POICategory.RESTAURANT,
        "BURGER_KING" to POICategory.RESTAURANT,
        "SUBWAY" to POICategory.RESTAURANT,
        "TIM_HORTONS" to POICategory.RESTAURANT,
        
        // Lojas
        "DOLLARAMA" to POICategory.CONVENIENCE
    )

    // Inicializar ícones padrão
    suspend fun initializeDefaultIcons() {
        defaultIcons.forEach { (brand, category) ->
            val iconData = loadDefaultIcon(brand)
            if (iconData != null) {
                addIcon(
                    name = brand.toLowerCase().capitalize(),
                    category = category,
                    brand = brand,
                    iconData = iconData,
                    source = IconSource.SYSTEM
                )
            }
        }
    }

    private suspend fun validateIconData(data: ByteArray) {
        require(data.size <= MAX_ICON_SIZE) {
            "Tamanho do ícone excede o limite máximo"
        }
        
        require(isValidImageFormat(data)) {
            "Formato de imagem inválido"
        }
    }

    private fun isValidImageFormat(data: ByteArray): Boolean {
        return try {
            // Verificar assinatura do arquivo
            val signature = data.take(4)
            signature.contentEquals(PNG_SIGNATURE) ||
            signature.contentEquals(SVG_SIGNATURE)
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        const val MAX_ICON_SIZE = 50 * 1024  // 50KB
        val PNG_SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)
        val SVG_SIGNATURE = "<?xml".toByteArray()
    }
}

class IconNotFoundException(iconId: String) : 
    Exception("Ícone não encontrado: $iconId")

// Interface para armazenamento
interface IconStorage {
    suspend fun saveIcon(icon: POIIcon)
    suspend fun getIcon(id: String): POIIcon?
    suspend fun updateIcon(icon: POIIcon)
    suspend fun getIconsByBrand(brand: String): List<POIIcon>
    suspend fun getIconsByCategory(category: POICategory): List<POIIcon>
}