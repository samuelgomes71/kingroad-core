/**
 * AudioRecorder.js
 * 
 * Componente para gravação e reprodução de áudio.
 * Implementa gravador de áudio com visualização de forma de onda,
 * controles de reprodução, indicador de duração e opção para regravar.
 * Funciona com permissões de microfone.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Platform,
  PermissionsAndroid
} from 'react-native';
import PropTypes from 'prop-types';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import AudioRecorderPlayer from 'react-native-audio-recorder-player';
import RNFetchBlob from 'rn-fetch-blob';
import { PanResponder } from 'react-native';

// Componentes personalizados
import Icon, { ICON_SETS, ICON_SIZES, ICON_STATES } from './Icon';
import { Button, IconButton } from './commonButtons';

// Constantes para estados de gravação e reprodução
const RECORDING_STATUS = {
  IDLE: 'idle',           // Estado inicial ou reset
  RECORDING: 'recording', // Gravando áudio
  PAUSED: 'paused',       // Gravação pausada
  RECORDED: 'recorded',   // Gravação finalizada
  PLAYING: 'playing',     // Reproduzindo gravação
  ERROR: 'error'          // Erro durante gravação/reprodução
};

// Constantes para qualidade de gravação
const RECORDING_QUALITY = {
  LOW: 'low',         // Qualidade baixa (menor tamanho)
  MEDIUM: 'medium',   // Qualidade média (recomendado)
  HIGH: 'high'        // Alta qualidade (maior tamanho)
};
/**
 * Componente AudioRecorder para gravação e reprodução de áudio
 * @param {Object} props - Propriedades do componente
 * @returns {React.Component} Componente AudioRecorder
 */
const AudioRecorder = ({
  // Propriedades de configuração
  initialAudio = null,            // Áudio inicial (se houver)
  maxDuration = 120,              // Duração máxima em segundos (2 minutos)
  quality = RECORDING_QUALITY.MEDIUM, // Qualidade da gravação
  autoStart = false,              // Inicia gravação automaticamente
  showWaveform = true,            // Exibe forma de onda
  waveformSensitivity = 1.5,      // Sensibilidade da forma de onda
  showElapsedTime = true,         // Exibe tempo decorrido
  editable = true,                // Permite gravação/regravação
  
  // Estilos
  containerStyle = {},
  waveformStyle = {},
  
  // Handlers
  onRecordingStart = () => {},
  onRecordingStop = (audioData) => {},
  onPlaybackStart = () => {},
  onPlaybackStop = () => {},
  onError = () => {},
  
  // Textos para traduções
  texts = {
    startRecording: 'Iniciar gravação',
    stopRecording: 'Parar gravação',
    playRecording: 'Reproduzir',
    pausePlayback: 'Pausar',
    stopPlayback: 'Parar',
    reRecord: 'Gravar novamente',
    permissionDenied: 'Permissão negada',
    permissionDeniedMessage: 'Permissão de microfone negada. Por favor, habilite nas configurações do aplicativo.',
    errorTitle: 'Erro',
    errorStartRecording: 'Erro ao iniciar gravação',
    errorStopRecording: 'Erro ao parar gravação',
    errorPlayRecording: 'Erro ao reproduzir gravação',
    recordingComplete: 'Gravação concluída',
    noAudioFile: 'Nenhum áudio gravado',
    recordingTooLong: `Gravação atingiu o limite máximo de ${maxDuration} segundos`,
    seconds: 's'
  }
}) => {
  // Estado da gravação
  const [status, setStatus] = useState(initialAudio ? RECORDING_STATUS.RECORDED : RECORDING_STATUS.IDLE);
  const [micPermission, setMicPermission] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackPosition, setPlaybackPosition] = useState(0);
  const [audioFile, setAudioFile] = useState(initialAudio);
  const [error, setError] = useState(null);
  
  // Visualização da forma de onda
  const [waveformData, setWaveformData] = useState([]);
  const [maxAmplitude, setMaxAmplitude] = useState(1);
  const waveformMaxBars = 50; // Número máximo de barras na forma de onda
  
  // Referências
  const audioRecorderPlayer = useRef(new AudioRecorderPlayer());
  const recordingInterval = useRef(null);
  const playbackInterval = useRef(null);
  const metersInterval = useRef(null);
  
  // Configura o PanResponder para permitir arrastar o playback
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onStartShouldSetPanResponderCapture: () => true,
      onMoveShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponderCapture: () => true,
      onPanResponderGrant: (evt, gestureState) => {
        // Apenas se tiver um arquivo de áudio e não estiver gravando
        if (audioFile && status !== RECORDING_STATUS.RECORDING) {
          handleProgressBarTouch(evt.nativeEvent.locationX);
        }
      },
      onPanResponderMove: (evt, gestureState) => {
        // Apenas se tiver um arquivo de áudio e não estiver gravando
        if (audioFile && status !== RECORDING_STATUS.RECORDING) {
          handleProgressBarTouch(evt.nativeEvent.locationX);
        }
      },
      onPanResponderRelease: () => {
        // Implementar se necessário
      }
    })
  ).current;
  
  // Efeito para verificar permissão do microfone ao montar o componente
  useEffect(() => {
    checkMicrophonePermission();
    
    // Configura AudioRecorderPlayer
    setupAudioRecorderPlayer();
    
    // Inicia gravação se autoStart for true
    if (autoStart && !initialAudio) {
      startRecording();
    }
    
    // Limpa intervalos e listeners ao desmontar o componente
    return () => {
      stopRecording();
      stopPlayback();
      cleanupIntervals();
    };
  }, []);
  
  /**
   * Limpa todos os intervalos ativos
   */
  const cleanupIntervals = () => {
    if (recordingInterval.current) {
      clearInterval(recordingInterval.current);
      recordingInterval.current = null;
    }
    
    if (playbackInterval.current) {
      clearInterval(playbackInterval.current);
      playbackInterval.current = null;
    }
    
    if (metersInterval.current) {
      clearInterval(metersInterval.current);
      metersInterval.current = null;
    }
  };
  
  /**
   * Configura o AudioRecorderPlayer
   */
  const setupAudioRecorderPlayer = () => {
    audioRecorderPlayer.current.setSubscriptionDuration(0.1); // 100ms para atualizações frequentes
    
    // Subscriptions para eventos
    audioRecorderPlayer.current.addRecordBackListener((e) => {
      setElapsedTime(e.currentPosition / 1000);
      
      // Verifica se atingiu o limite máximo
      if (maxDuration > 0 && e.currentPosition / 1000 >= maxDuration) {
        stopRecording();
        Alert.alert('', texts.recordingTooLong);
      }
      
      return;
    });
    
    audioRecorderPlayer.current.addPlayBackListener((e) => {
      if (e.currentPosition === e.duration) {
        // Playback concluído
        setStatus(RECORDING_STATUS.RECORDED);
        setPlaybackPosition(0);
        onPlaybackStop();
      } else {
        setPlaybackPosition(e.currentPosition / 1000);
      }
      
      return;
    });
  };
/**
   * Verifica permissão do microfone
   */
  const checkMicrophonePermission = async () => {
    try {
      const permission = Platform.OS === 'ios' 
        ? PERMISSIONS.IOS.MICROPHONE 
        : PERMISSIONS.ANDROID.RECORD_AUDIO;
        
      const result = await check(permission);
      
      if (result === RESULTS.GRANTED) {
        setMicPermission(true);
        return true;
      } else if (result === RESULTS.DENIED) {
        // Solicita permissão se ainda não concedida
        const requestResult = await request(permission);
        const granted = requestResult === RESULTS.GRANTED;
        setMicPermission(granted);
        return granted;
      } else {
        setMicPermission(false);
        return false;
      }
    } catch (error) {
      console.error('[AudioRecorder] Erro ao verificar permissão do microfone:', error);
      setMicPermission(false);
      return false;
    }
  };
  
  /**
   * Inicia a gravação de áudio
   */
  const startRecording = async () => {
    try {
      // Verifica permissão primeiro
      if (!micPermission) {
        const hasPermission = await checkMicrophonePermission();
        if (!hasPermission) {
          Alert.alert(texts.permissionDenied, texts.permissionDeniedMessage);
          onError('microphone_permission_denied');
          return;
        }
      }
      
      // Limpa gravação anterior se houver
      if (audioFile) {
        await resetRecording();
      }
      
      // Configura qualidade de gravação
      const audioSetting = getAudioSettings();
      
      // Configura path para o arquivo
      const path = Platform.select({
        ios: `audio_recording_${Date.now()}.m4a`,
        android: `${RNFetchBlob.fs.dirs.CacheDir}/audio_recording_${Date.now()}.mp3`,
      });
      
      // Inicia gravação
      const uri = await audioRecorderPlayer.current.startRecorder(path, audioSetting);
      
      // Atualiza estado
      setStatus(RECORDING_STATUS.RECORDING);
      setAudioFile(uri);
      setElapsedTime(0);
      setWaveformData([]);
      
      // Notifica callback
      onRecordingStart();
      
      // Inicia monitoramento para forma de onda
      if (showWaveform) {
        startWaveformMonitoring();
      }
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao iniciar gravação:', error);
      setStatus(RECORDING_STATUS.ERROR);
      setError(error.message);
      onError('start_recording_failed', error);
      Alert.alert(texts.errorTitle, texts.errorStartRecording);
    }
  };
  
  /**
   * Para a gravação de áudio
   */
  const stopRecording = async () => {
    try {
      // Verifica se está gravando
      if (status !== RECORDING_STATUS.RECORDING) {
        return;
      }
      
      // Para a gravação
      const result = await audioRecorderPlayer.current.stopRecorder();
      
      // Limpa intervalo da forma de onda
      if (metersInterval.current) {
        clearInterval(metersInterval.current);
        metersInterval.current = null;
      }
      
      // Atualiza estado
      setStatus(RECORDING_STATUS.RECORDED);
      
      // Obtém duração da gravação
      const audioInfo = await getAudioInfo(audioFile);
      setDuration(audioInfo.duration);
      
      // Notifica callback
      onRecordingStop({
        uri: audioFile,
        duration: audioInfo.duration,
        size: audioInfo.size,
        name: audioFile.split('/').pop(),
        timestamp: Date.now()
      });
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao parar gravação:', error);
      setStatus(RECORDING_STATUS.ERROR);
      setError(error.message);
      onError('stop_recording_failed', error);
      Alert.alert(texts.errorTitle, texts.errorStopRecording);
    }
  };
  
  /**
   * Inicia reprodução do áudio gravado
   */
  const startPlayback = async () => {
    try {
      // Verifica se tem áudio gravado
      if (!audioFile) {
        Alert.alert('', texts.noAudioFile);
        return;
      }
      
      // Inicia reprodução
      await audioRecorderPlayer.current.startPlayer(audioFile);
      
      // Atualiza estado
      setStatus(RECORDING_STATUS.PLAYING);
      setPlaybackPosition(0);
      
      // Notifica callback
      onPlaybackStart();
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao reproduzir áudio:', error);
      setStatus(RECORDING_STATUS.ERROR);
      setError(error.message);
      onError('start_playback_failed', error);
      Alert.alert(texts.errorTitle, texts.errorPlayRecording);
    }
  };
  
  /**
   * Pausa reprodução do áudio
   */
  const pausePlayback = async () => {
    try {
      // Pausa reprodução
      await audioRecorderPlayer.current.pausePlayer();
      
      // Atualiza estado
      setStatus(RECORDING_STATUS.RECORDED);
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao pausar reprodução:', error);
      onError('pause_playback_failed', error);
    }
  };
  
  /**
   * Para a reprodução do áudio
   */
  const stopPlayback = async () => {
    try {
      // Para reprodução
      await audioRecorderPlayer.current.stopPlayer();
      
      // Atualiza estado
      setStatus(RECORDING_STATUS.RECORDED);
      setPlaybackPosition(0);
      
      // Notifica callback
      onPlaybackStop();
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao parar reprodução:', error);
      onError('stop_playback_failed', error);
    }
  };
  
  /**
   * Reseta o componente para iniciar nova gravação
   */
  const resetRecording = async () => {
    try {
      // Para reprodução/gravação se estiver em andamento
      if (status === RECORDING_STATUS.RECORDING) {
        await stopRecording();
      } else if (status === RECORDING_STATUS.PLAYING) {
        await stopPlayback();
      }
      
      // Limpa dados anteriores
      setAudioFile(null);
      setElapsedTime(0);
      setDuration(0);
      setPlaybackPosition(0);
      setWaveformData([]);
      setStatus(RECORDING_STATUS.IDLE);
      setError(null);
      
    } catch (error) {
      console.error('[AudioRecorder] Erro ao resetar gravação:', error);
      onError('reset_recording_failed', error);
    }
  };
  
  /**
   * Inicia monitoramento da forma de onda durante gravação
   */
  const startWaveformMonitoring = () => {
    // Limpa intervalo anterior se houver
    if (metersInterval.current) {
      clearInterval(metersInterval.current);
    }
    
    // Inicia monitoramento a cada 100ms
    metersInterval.current = setInterval(async () => {
      try {
        // Obtém nível de decibéis atual (simulado para plataformas sem suporte)
        let db = 0;
        
        // Em uma implementação real, usaríamos algo como:
        // const db = await audioRecorderPlayer.current.currentMetering();
        
        // Simulação do nível de decibéis para visualização
        db = Math.random() * 160 - 160; // Valores entre -160 e 0
        
        // Converte dB para amplitude (valores entre 0 e 1)
        // dB é logarítmico, então convertemos para linear
        let amplitude = 1.0 - (Math.abs(db) / 160.0);
        amplitude = Math.max(0.05, amplitude * waveformSensitivity);
        
        // Atualiza valor máximo se necessário
        if (amplitude > maxAmplitude) {
          setMaxAmplitude(amplitude);
        }
        
        // Adiciona à forma de onda
        setWaveformData(prevData => {
          // Mantém apenas os últimos N pontos
          const newData = [...prevData, amplitude];
          if (newData.length > waveformMaxBars) {
            return newData.slice(newData.length - waveformMaxBars);
          }
          return newData;
        });
        
      } catch (error) {
        console.error('[AudioRecorder] Erro ao monitorar forma de onda:', error);
      }
    }, 100);
  };
  
  /**
   * Manipula toque na barra de progresso para seekar o áudio
   * @param {number} touchX - Posição X do toque
   */
  const handleProgressBarTouch = async (touchX) => {
    if (!audioFile || duration <= 0) return;
    
    // Obtém largura do waveform container
    const progressBarWidth = 300; // Valor fixo para exemplo - idealmente seria dynamic
    
    // Calcula a porcentagem do toque
    const percent = Math.max(0, Math.min(1, touchX / progressBarWidth));
    
    // Calcula a posição em segundos
    const seekPosition = percent * duration;
    
    // Se estiver reproduzindo, faz seek
    if (status === RECORDING_STATUS.PLAYING) {
      await audioRecorderPlayer.current.seekToPlayer(seekPosition * 1000);
    }
    
    // Atualiza a posição de playback
    setPlaybackPosition(seekPosition);
  };
  
  /**
   * Obtém configurações de áudio com base na qualidade selecionada
   * @returns {Object} Configurações de áudio
   */
  const getAudioSettings = () => {
    // Configurações padrão
    const settings = {
      AudioEncoding: Platform.OS === 'ios' ? 'aac' : 'mp3',
      AudioEncodingBitRate: 128000,
      AudioSamplingRate: 44100,
    };
    
    // Ajusta configurações com base na qualidade
    switch (quality) {
      case RECORDING_QUALITY.LOW:
        settings.AudioEncodingBitRate = 64000;
        settings.AudioSamplingRate = 22050;
        break;
        
      case RECORDING_QUALITY.HIGH:
        settings.AudioEncodingBitRate = 192000;
        settings.AudioSamplingRate = 48000;
        break;
        
      // RECORDING_QUALITY.MEDIUM é o padrão (definido acima)
      default:
        break;
    }
    
    return settings;
  };
  
  /**
   * Obtém informações sobre o arquivo de áudio
   * @param {string} uri - URI do arquivo de áudio
   * @returns {Promise<Object>} Informações do arquivo
   */
  const getAudioInfo = async (uri) => {
    try {
      // Em uma implementação real, obteríamos a duração do arquivo
      // Aqui, usamos o tempo decorrido da gravação como aproximação
      const duration = elapsedTime;
      
      // Tenta obter o tamanho do arquivo
      let size = 0;
      try {
        // Converte path para formato adequado para RNFetchBlob
        const path = Platform.OS === 'ios' 
          ? uri.replace('file://', '') 
          : uri;
          
        const fileStats = await RNFetchBlob.fs.stat(path);
        size = fileStats.size;
      } catch (error) {
        console.error('[AudioRecorder] Erro ao obter tamanho do arquivo:', error);
      }
      
      return { duration, size };
    } catch (error) {
      console.error('[AudioRecorder] Erro ao obter informações do áudio:', error);
      return { duration: elapsedTime, size: 0 };
    }
  };
  
  /**
   * Formata tempo em segundos para exibição MM:SS
   * @param {number} seconds - Tempo em segundos
   * @returns {string} Tempo formatado
   */
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  /**
   * Renderiza barras da forma de onda
   * @returns {React.Component[]} Array de componentes de barra
   */
  const renderWaveform = () => {
    const barWidth = 4;
    const barGap = 2;
    const baseHeight = 60;
    
    return waveformData.map((amplitude, index) => {
      const height = Math.max(4, baseHeight * amplitude);
      
      return (
        <View 
          key={`bar_${index}`}
          style={[
            styles.waveformBar,
            {
              height,
              width: barWidth,
              marginHorizontal: barGap / 2,
              backgroundColor: status === RECORDING_STATUS.RECORDING ? '#FF5252' : '#1E88E5',
            }
          ]}
        />
      );
    });
  };
  
  /**
   * Renderiza barra de progresso para reprodução
   * @returns {React.Component} Componente de barra de progresso
   */
  const renderProgressBar = () => {
    // Calcula progresso de reprodução (de 0 a 1)
    const progress = duration > 0 ? playbackPosition / duration : 0;
    
    return (
      <View style={styles.progressBarContainer} {...panResponder.panHandlers}>
        <View style={styles.progressBarBackground} />
        <View 
          style={[
            styles.progressBarFill,
            { width: `${progress * 100}%` }
          ]}
        />
      </View>
    );
  };
  
  /**
   * Renderiza tempo de gravação/reprodução
   * @returns {React.Component} Componente de tempo
   */
  const renderTimeDisplay = () => {
    // Se estiver reproduzindo, mostra posição atual / total
    if (status === RECORDING_STATUS.PLAYING) {
      return (
        <Text style={styles.timeText}>
          {formatTime(playbackPosition)} / {formatTime(duration)}
        </Text>
      );
    }
    
    // Se estiver gravando, mostra tempo decorrido
    if (status === RECORDING_STATUS.RECORDING) {
      return (
        <Text style={styles.timeText}>
          {formatTime(elapsedTime)}
        </Text>
      );
    }
    
    // Se tiver gravação, mostra duração total
    if (status === RECORDING_STATUS.RECORDED) {
      return (
        <Text style={styles.timeText}>
          {formatTime(duration)}
        </Text>
      );
    }
    
    // Estado inicial
    return (
      <Text style={styles.timeText}>
        00:00
      </Text>
    );
  };
  
  /**
   * Renderiza os botões de controle
   * @returns {React.Component} Componente com botões de controle
   */
  const renderControls = () => {
    // Não renderiza controles se não for editável
    if (!editable && status === RECORDING_STATUS.IDLE) {
      return null;
    }
    
    // Controles para estado inicial
    if (status === RECORDING_STATUS.IDLE) {
      return (
        <Button
          title={texts.startRecording}
          leftIcon={{
            name: 'mic',
            set: ICON_SETS.FEATHER
          }}
          onPress={startRecording}
          style={styles.button}
        />
      );
    }
    
    // Controles para gravação em andamento
    if (status === RECORDING_STATUS.RECORDING) {
      return (
        <Button
          title={texts.stopRecording}
          leftIcon={{
            name: 'stop-circle',
            set: ICON_SETS.FEATHER
          }}
          onPress={stopRecording}
          style={styles.button}
        />
      );
    }
    
    // Controles para gravação concluída ou pausada
    if (status === RECORDING_STATUS.RECORDED) {
      return (
        <View style={styles.multipleControls}>
          <IconButton
            icon={{
              name: 'play',
              set: ICON_SETS.FEATHER,
              size: ICON_SIZES.LARGE
            }}
            onPress={startPlayback}
            style={styles.iconButton}
          />
          
          {editable && (
            <IconButton
              icon={{
                name: 'trash-2',
                set: ICON_SETS.FEATHER,
                size: ICON_SIZES.LARGE,
                state: ICON_STATES.ERROR
              }}
              onPress={resetRecording}
              style={styles.iconButton}
            />
          )}
        </View>
      );
    }
    
    // Controles para reprodução em andamento
    if (status === RECORDING_STATUS.PLAYING) {
      return (
        <View style={styles.multipleControls}>
          <IconButton
            icon={{
              name: 'pause',
              set: ICON_SETS.FEATHER,
              size: ICON_SIZES.LARGE
            }}
            onPress={pausePlayback}
            style={styles.iconButton}
          />
          
          <IconButton
            icon={{
              name: 'stop-circle',
              set: ICON_SETS.FEATHER,
              size: ICON_SIZES.LARGE
            }}
            onPress={stopPlayback}
            style={styles.iconButton}
          />
        </View>
      );
    }
    
    // Controles para estado de erro
    if (status === RECORDING_STATUS.ERROR) {
      return (
        <Button
          title={texts.reRecord}
          leftIcon={{
            name: 'refresh-cw',
            set: ICON_SETS.FEATHER
          }}
          onPress={resetRecording}
          style={styles.button}
        />
      );
    }
    
    // Fallback
    return null;
  };
  
  return (
    <View style={[styles.container, containerStyle]}>
      {/* Forma de onda e visualização */}
      {showWaveform && (status !== RECORDING_STATUS.IDLE || waveformData.length > 0) && (
        <View style={[styles.waveformContainer, waveformStyle]}>
          {renderWaveform()}
        </View>
      )}
      
      {/* Barra de progresso para reprodução */}
      {status === RECORDING_STATUS.PLAYING || status === RECORDING_STATUS.RECORDED ? (
        renderProgressBar()
      ) : null}
      
      {/* Exibição de tempo */}
      {showElapsedTime && (
        <View style={styles.timeDisplay}>
          {renderTimeDisplay()}
        </View>
      )}
      
      {/* Controles de gravação/reprodução */}
      <View style={styles.controlsContainer}>
        {renderControls()}
      </View>
      
      {/* Mensagem de erro */}
      {status === RECORDING_STATUS.ERROR && error && (
        <Text style={styles.errorText}>{error}</Text>
      )}
    </View>
  );
};

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    margin: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  waveformContainer: {
    flexDirection: 'row',
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },
  waveformBar: {
    borderRadius: 2,
  },
  progressBarContainer: {
    height: 6,
    backgroundColor: '#f0f0f0',
    borderRadius: 3,
    marginVertical: 12,
    overflow: 'hidden',
  },
  progressBarBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#e0e0e0',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#1E88E5',
  },
  timeDisplay: {
    alignItems: 'center',
    marginBottom: 12,
  },
  timeText: {
    fontSize: 16,
    color: '#424242',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 8,
  },
  multipleControls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  button: {
    minWidth: 150,
  },
  iconButton: {
    margin: 8,
  },
  errorText: {
    color: '#D32F2F',
    marginTop: 8,
    textAlign: 'center',
  }
});

// Definição de PropTypes para documentação e validação
AudioRecorder.propTypes = {
  initialAudio: PropTypes.string,
  maxDuration: PropTypes.number,
quality: PropTypes.oneOf(Object.values(RECORDING_QUALITY)),
  autoStart: PropTypes.bool,
  showWaveform: PropTypes.bool,
  waveformSensitivity: PropTypes.number,
  showElapsedTime: PropTypes.bool,
  editable: PropTypes.bool,
  containerStyle: PropTypes.object,
  waveformStyle: PropTypes.object,
  onRecordingStart: PropTypes.func,
  onRecordingStop: PropTypes.func,
  onPlaybackStart: PropTypes.func,
  onPlaybackStop: PropTypes.func,
  onError: PropTypes.func,
  texts: PropTypes.object,
};

// Exporta o componente e constantes
export { RECORDING_STATUS, RECORDING_QUALITY };
export default AudioRecorder;