import React, { useState, useEffect } from 'react';
import { MapPin, Truck, Car, Droplet, Filter, Star, Clock, DollarSign, AlertCircle } from 'lucide-react';

// Componente principal para POIs de lavagem de veículos
const VehicleWashPoiComponent = ({ vehicleMode = 'truck' }) => {
  // Estados
  const [pois, setPois] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilters, setActiveFilters] = useState({
    type: [],
    priceRange: [0, 100],
    rating: 0,
    distance: 50 // km
  });
  
  // Efeito para carregar os POIs adequados baseados no modo de veículo
  useEffect(() => {
    setLoading(true);
    
    // Simulação de carregamento de dados
    setTimeout(() => {
      if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
        setPois(mockTruckWashers);
      } else {
        setPois(mockCarWashers);
      }
      setLoading(false);
    }, 1000);
  }, [vehicleMode]);
  
  // Função para filtrar POIs
  const filteredPois = pois.filter(poi => {
    // Implementar lógica de filtro mais complexa conforme necessário
    return poi.distance <= activeFilters.distance && 
           poi.rating >= activeFilters.rating;
  });
  
  // Renderiza o ícone apropriado para o tipo de veículo
  const renderVehicleIcon = () => {
    if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
      return <Truck className="mr-2" size={24} />;
    }
    return <Car className="mr-2" size={24} />;
  };
  
  // Determina o título baseado no modo
  const getTitle = () => {
    if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
      return "Truck Washers";
    }
    return "Car Wash";
  };

  return (
    <div className="w-full max-w-4xl bg-gray-900 text-white rounded-lg shadow-lg p-4">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center mb-6 border-b border-gray-700 pb-4">
        <div className="flex items-center">
          {renderVehicleIcon()}
          <h2 className="text-xl font-bold text-amber-400">{getTitle()}</h2>
        </div>
        <button className="flex items-center bg-gray-800 hover:bg-gray-700 p-2 rounded-lg transition-colors">
          <Filter size={18} className="mr-2 text-amber-400" />
          <span>Filtros</span>
        </button>
      </div>
      
      {/* Lista de POIs */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-400"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPois.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle size={48} className="mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">Nenhum local de lavagem encontrado nas proximidades.</p>
            </div>
          ) : (
            filteredPois.map(poi => (
              <PoiCard 
                key={poi.id} 
                poi={poi} 
                vehicleMode={vehicleMode} 
              />
            ))
          )}
        </div>
      )}
      
      {/* Botão para adicionar novo POI */}
      <div className="mt-6 text-center">
        <button className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-4 rounded-lg transition-colors">
          Sugerir Novo Local
        </button>
      </div>
    </div>
  );
};

// Componente de cartão para um POI individual
const PoiCard = ({ poi, vehicleMode }) => {
  // Estados para hover
  const [isHovered, setIsHovered] = useState(false);
  
  // Renderiza os ícones apropriados para o tipo de lavagem
  const renderTypeIcons = () => {
    const icons = [];
    if (poi.types.includes('AUTOMATIC')) {
      icons.push(<span key="auto" className="bg-blue-900 text-blue-200 text-xs px-2 py-1 rounded">Automática</span>);
    }
    if (poi.types.includes('MANUAL')) {
      icons.push(<span key="manual" className="bg-green-900 text-green-200 text-xs px-2 py-1 rounded">Manual</span>);
    }
    if (poi.types.includes('SELF_SERVICE')) {
      icons.push(<span key="self" className="bg-purple-900 text-purple-200 text-xs px-2 py-1 rounded">Self-Service</span>);
    }
    if (poi.types.includes('HIGH_PRESSURE')) {
      icons.push(<span key="pressure" className="bg-red-900 text-red-200 text-xs px-2 py-1 rounded">Alta Pressão</span>);
    }
    return icons;
  };
  
  // Renderiza informações sobre o tamanho do veículo (apenas para caminhões)
  const renderSizeInfo = () => {
    if (vehicleMode !== 'truck' && vehicleMode !== 'bus' && vehicleMode !== 'rv') {
      return null;
    }
    
    const sizeClasses = {
      SMALL_TRUCK: "bg-green-900 text-green-200",
      MEDIUM_TRUCK: "bg-yellow-900 text-yellow-200",
      FULL_TRAILER: "bg-red-900 text-red-200"
    };
    
    return (
      <div className="mt-2">
        <p className="text-xs text-gray-400 mb-1">Veículos aceitos:</p>
        <div className="flex flex-wrap gap-1">
          {poi.truckTypes.map(type => (
            <span key={type} className={`${sizeClasses[type] || "bg-gray-700 text-gray-200"} text-xs px-2 py-1 rounded`}>
              {type === 'SMALL_TRUCK' ? 'Pequeno' : 
               type === 'MEDIUM_TRUCK' ? 'Médio' : 
               type === 'FULL_TRAILER' ? 'Grande' : type}
            </span>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div 
      className={`bg-gray-800 rounded-lg p-4 transition-all duration-200 ${isHovered ? 'shadow-lg shadow-amber-900/20 transform scale-[1.01]' : ''}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex justify-between">
        <div>
          <h3 className="font-bold text-lg text-amber-400">{poi.name}</h3>
          <div className="flex items-center text-sm text-gray-400 mt-1">
            <MapPin size={14} className="mr-1" />
            <span>{poi.distance} km</span>
            <span className="mx-2">•</span>
            <span>{poi.address}</span>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="flex items-center bg-amber-500 text-black font-bold px-2 py-1 rounded">
            <Star size={14} className="mr-1" />
            <span>{poi.rating.toFixed(1)}</span>
          </div>
        </div>
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-4">
        <div>
          <div className="flex items-center text-sm">
            <Clock size={16} className="mr-2 text-amber-400" />
            <span>{poi.waitTime} min espera</span>
          </div>
          
          <div className="flex items-center text-sm mt-2">
            <DollarSign size={16} className="mr-2 text-amber-400" />
            <span>A partir de {poi.currency} {poi.basePrice}</span>
          </div>
        </div>
        
        <div>
          <div className="flex flex-wrap gap-1">
            {renderTypeIcons()}
          </div>
          {renderSizeInfo()}
        </div>
      </div>
      
      {/* Botões de ação */}
      <div className="mt-4 flex justify-between">
        <button className="text-amber-400 hover:text-amber-300 text-sm flex items-center">
          <Star size={14} className="mr-1" />
          <span>Adicionar aos favoritos</span>
        </button>
        
        <button className="bg-amber-500 hover:bg-amber-600 text-black text-sm font-bold py-1 px-3 rounded transition-colors">
          Ver Detalhes
        </button>
      </div>
    </div>
  );
};

// Dados de exemplo para Truck Washers
const mockTruckWashers = [
  {
    id: 'tw1',
    name: 'Blue Beacon Truck Wash',
    address: 'BR-116, km 432',
    distance: 12.5,
    rating: 4.7,
    basePrice: 120,
    currency: 'R$',
    waitTime: 30,
    types: ['AUTOMATIC', 'HIGH_PRESSURE'],
    truckTypes: ['SMALL_TRUCK', 'MEDIUM_TRUCK', 'FULL_TRAILER'],
    chain: 'BLUE_BEACON'
  },
  {
    id: 'tw2',
    name: 'Posto Ipiranga Lava-Tudo',
    address: 'Rodovia Anhanguera, km 56',
    distance: 24.8,
    rating: 4.2,
    basePrice: 90,
    currency: 'R$',
    waitTime: 15,
    types: ['MANUAL', 'SELF_SERVICE'],
    truckTypes: ['SMALL_TRUCK', 'MEDIUM_TRUCK'],
    chain: 'IPIRANGA'
  },
  {
    id: 'tw3',
    name: 'Truck Clean Express',
    address: 'BR-101, km 215',
    distance: 35.2,
    rating: 4.5,
    basePrice: 150,
    currency: 'R$',
    waitTime: 45,
    types: ['AUTOMATIC', 'STEAM', 'HIGH_PRESSURE'],
    truckTypes: ['SMALL_TRUCK', 'MEDIUM_TRUCK', 'FULL_TRAILER'],
    chain: 'INDEPENDENT'
  }
];

// Dados de exemplo para Car Washers
const mockCarWashers = [
  {
    id: 'cw1',
    name: 'Lava Rápido Auto Shine',
    address: 'Av. Paulista, 1578',
    distance: 2.1,
    rating: 4.8,
    basePrice: 40,
    currency: 'R$',
    waitTime: 20,
    types: ['MANUAL', 'AUTOMATIC'],
  },
  {
    id: 'cw2',
    name: 'Shell Box Car Wash',
    address: 'Rua Augusta, 1200',
    distance: 3.5,
    rating: 4.3,
    basePrice: 35,
    currency: 'R$',
    waitTime: 10,
    types: ['SELF_SERVICE', 'HIGH_PRESSURE'],
  },
  {
    id: 'cw3',
    name: 'Eco Car Wash',
    address: 'Rua Oscar Freire, 540',
    distance: 5.8,
    rating: 4.6,
    basePrice: 50,
    currency: 'R$',
    waitTime: 30,
    types: ['MANUAL', 'ECO_FRIENDLY'],
  }
];

export default VehicleWashPoiComponent;