package com.kingroad.ui.components

import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.kingroad.data.AppPreferences
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
class KingSplitScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()
    
    private lateinit var context: Context
    private lateinit var appPreferences: AppPreferences
    
    @Before
    fun setup() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        appPreferences = mock(AppPreferences::class.java)
    }
    
    @Test
    fun testLargeScreenMode() {
        // Configurar tamanho de tela grande para o teste
        composeTestRule.setContent {
            KingSplitScreen(
                preferences = appPreferences,
                mainContent = { 
                    androidx.compose.material3.Text("KingRoad Main Content")
                }
            )
        }
        
        // Verificar se apenas o conteúdo principal está visível inicialmente
        composeTestRule.onNodeWithText("KingRoad Main Content").assertIsDisplayed()
        
        // Verificar se o botão flutuante não está visível em telas grandes
        composeTestRule.onNode(hasContentDescription("+")).assertDoesNotExist()
    }
    
    @Test
    fun testSmallScreenMode() {
        // Neste teste, simularemos uma tela pequena
        composeTestRule.setContent {
            androidx.compose.ui.window.WindowSize(900, 600) {
                KingSplitScreen(
                    preferences = appPreferences,
                    mainContent = { 
                        androidx.compose.material3.Text("KingRoad Main Content")
                    }
                )
            }
        }
        
        // Verificar se o botão flutuante está visível em telas pequenas
        composeTestRule.onNode(hasContentDescription("+")).assertIsDisplayed()
        
        // Verificar se ao clicar no botão flutuante, o seletor de apps é exibido
        composeTestRule.onNode(hasContentDescription("+")).performClick()
        composeTestRule.onNodeWithText("Select App").assertIsDisplayed()
        
        // Verificar se as opções de apps estão presentes
        composeTestRule.onNodeWithText("KingChat").assertIsDisplayed()
        composeTestRule.onNodeWithText("KingSMS").assertIsDisplayed()
        composeTestRule.onNodeWithText("KingLoc").assertIsDisplayed()
        composeTestRule.onNodeWithText("Admin Portal").assertIsDisplayed()
    }
    
    @Test
    fun testAppSelection() {
        // Configurar teste para tela grande
        composeTestRule.setContent {
            KingSplitScreen(
                preferences = appPreferences,
                mainContent = { 
                    androidx.compose.material3.Text("KingRoad Main Content")
                }
            )
        }
        
        // Simular abertura do seletor de apps
        // (Em tela grande, isso seria através de um menu ou botão)
        triggerAppSelectorInLargeScreen()
        
        // Selecionar um app
        composeTestRule.onNodeWithText("KingChat").performClick()
        
        // Verificar se o app selecionado é exibido
        composeTestRule.onNodeWithText("KingChat").assertIsDisplayed()
        composeTestRule.onNodeWithText("KingChat Content").assertIsDisplayed()
        
        // Verificar se o botão de Pin/Unpin está presente
        composeTestRule.onNodeWithText("Pin App").assertIsDisplayed()
    }
    
    @Test
    fun testAppPinning() = runTest {
        // Configurar mock para salvar preferência
        `when`(appPreferences.getString("fixedApp", null)).thenReturn(null)
        
        composeTestRule.setContent {
            KingSplitScreen(
                preferences = appPreferences,
                mainContent = { 
                    androidx.compose.material3.Text("KingRoad Main Content")
                }
            )
        }
        
        // Abrir seletor e escolher um app
        triggerAppSelectorInLargeScreen()
        composeTestRule.onNodeWithText("KingChat").performClick()
        
        // Fixar o app
        composeTestRule.onNodeWithText("Pin App").performClick()
        
        // Verificar se o método putString foi chamado com os parâmetros corretos
        verify(appPreferences).putString("fixedApp", "KingChat")
        
        // Verificar se o texto do botão mudou
        composeTestRule.onNodeWithText("Unpin App").assertIsDisplayed()
    }
    
    @Test
    fun testLoadSavedApp() = runTest {
        // Configurar mock para retornar um app salvo
        `when`(appPreferences.getString("fixedApp", null)).thenReturn("KingChat")
        
        composeTestRule.setContent {
            KingSplitScreen(
                preferences = appPreferences,
                mainContent = { 
                    androidx.compose.material3.Text("KingRoad Main Content")
                }
            )
        }
        
        // Verificar se o app salvo é carregado automaticamente
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("KingChat").assertIsDisplayed()
        composeTestRule.onNodeWithText("KingChat Content").assertIsDisplayed()
        
        // Verificar se o botão está como "Unpin App" já que o app está fixado
        composeTestRule.onNodeWithText("Unpin App").assertIsDisplayed()
    }
    
    @Test
    fun testCloseSecondaryApp() {
        // Configurar mock para retornar um app salvo
        runTest {
            `when`(appPreferences.getString("fixedApp", null)).thenReturn("KingChat")
        }
        
        composeTestRule.setContent {
            KingSplitScreen(
                preferences = appPreferences,
                mainContent = { 
                    androidx.compose.material3.Text("KingRoad Main Content")
                }
            )
        }
        
        // Verificar se o botão de fechar está presente
        composeTestRule.onNode(hasContentDescription("Close")).assertIsDisplayed()
        
        // Fechar o app secundário
        composeTestRule.onNode(hasContentDescription("Close")).performClick()
        
        // Verificar se o app secundário foi fechado
        composeTestRule.onNodeWithText("KingChat Content").assertDoesNotExist()
    }
    
    /**
     * Método helper para simular a abertura do seletor de apps em tela grande
     * (Na implementação real, isso seria feito por um botão ou menu)
     */
    private fun triggerAppSelectorInLargeScreen() {
        // Simular a abertura do seletor de apps (implementação depende do design real)
        // Este é apenas um placeholder - a implementação real dependeria de como
        // o seletor é aberto em telas grandes
        composeTestRule.mainClock.autoAdvance = false
        // Método para forçar a exibição do seletor diretamente
        showAppSelectorProgrammatically()
        composeTestRule.mainClock.autoAdvance = true
    }
    
    /**
     * Este método simula a abertura programática do seletor
     * (Na implementação real, isso seria exposto pelo componente para testes)
     */
    private fun showAppSelectorProgrammatically() {
        // Na implementação real, seria necessário expor um método para abrir
        // o seletor programaticamente para testes
    }
}