// BrazilSecurityAlertsMap.jsx
import React, { useState, useEffect, useRef } from 'react';
import { Map, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import { 
  AlertTriangle, 
  UserX, 
  Truck, 
  Car, 
  Wind, 
  MapPin, 
  Eye, 
  XCircle,
  AlertOctagon
} from 'lucide-react';
import { Button, Checkbox, Switch, FormGroup, FormControlLabel } from '@/components/ui';
import { BrazilSecurityAlertBridge } from '../services/BrazilSecurityAlertBridge';
import { KingLocBridge } from '../services/KingLocBridge';
import AddBrazilSecurityAlert from './AddBrazilSecurityAlert';
import BrazilEmergencyAlertModal from './BrazilEmergencyAlertModal';

// Cores para os diferentes tipos de alertas
const ALERT_COLORS = {
  SHOOTING: '#EF4444',          // Vermelho
  KIDNAPPING: '#8B5CF6',        // Roxo
  CARGO_THEFT: '#F59E0B',       // Âmbar
  SUSPICIOUS_VEHICLE: '#0EA5E9', // Azul
  SPEEDING_VEHICLE: '#EC4899'   // Rosa
};

// Raios de notificação para cada tipo (em metros)
const NOTIFICATION_RADIUS = {
  SHOOTING: 5000,
  KIDNAPPING: 10000,
  CARGO_THEFT: 20000,
  SUSPICIOUS_VEHICLE: 5000,
  SPEEDING_VEHICLE: 3000
};

/**
 * Componente para exibição de alertas de segurança brasileiros no mapa
 */
const BrazilSecurityAlertsMap = ({ 
  userId,
  initialCenter = { lat: -22.9068, lng: -43.1729 }, // Rio de Janeiro
  initialZoom = 12
}) => {
  const [alerts, setAlerts] = useState([]);
  const [filteredAlerts, setFilteredAlerts] = useState([]);
  const [filters, setFilters] = useState({
    SHOOTING: true,
    KIDNAPPING: true,
    CARGO_THEFT: true,
    SUSPICIOUS_VEHICLE: true,
    SPEEDING_VEHICLE: true
  });
  const [userLocation, setUserLocation] = useState(initialCenter);
  const [mapCenter, setMapCenter] = useState(initialCenter);
  const [isAddingAlert, setIsAddingAlert] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [showEmergencyAlert, setShowEmergencyAlert] = useState(false);
  const [emergencyAlertData, setEmergencyAlertData] = useState(null);
  
  const mapRef = useRef(null);
  const alertBridge = useRef(new BrazilSecurityAlertBridge());
  const locationBridge = useRef(new KingLocBridge());
  
  // Efeito para carregar alertas iniciais
  useEffect(() => {
    const loadAlerts = async () => {
      try {
        const alertsData = await alertBridge.current.getActiveAlertsInArea(
          userLocation.lat,
          userLocation.lng,
          30000 // 30km de raio inicial
        );
        
        if (alertsData && Array.isArray(alertsData)) {
          setAlerts(alertsData);
        }
      } catch (error) {
        console.error('Erro ao carregar alertas:', error);
      }
    };
    
    loadAlerts();
  }, [userLocation]);
  
  // Efeito para aplicar filtros
  useEffect(() => {
    if (alerts && Array.isArray(alerts)) {
      const filtered = alerts.filter(alert => 
        filters[alert.type] === true
      );
      setFilteredAlerts(filtered);
    }
  }, [alerts, filters]);
  
  // Efeito para escutar alertas em tempo real
  useEffect(() => {
    const subscription = alertBridge.current.subscribeToRealTimeAlerts((newAlert) => {
      // Verificar se o alerta está dentro do raio de notificação para o usuário
      const distance = calculateDistance(
        userLocation.lat, userLocation.lng,
        newAlert.latitude, newAlert.longitude
      );
      
      const notificationRadius = NOTIFICATION_RADIUS[newAlert.type] || 5000;
      
      if (distance <= notificationRadius) {
        // Adicionar o alerta à lista
        setAlerts(prevAlerts => [...prevAlerts, newAlert]);
        
        // Mostrar alerta de emergência se for um tipo prioritário
        if (newAlert.type === 'SHOOTING' || newAlert.type === 'KIDNAPPING') {
          setEmergencyAlertData(newAlert);
          setShowEmergencyAlert(true);
        }
      }
    });
    
    // Limpar a inscrição ao desmontar
    return () => {
      if (subscription && subscription.unsubscribe) {
        subscription.unsubscribe();
      }
    };
  }, [userLocation]);
  
  // Efeito para rastrear a localização do usuário
  useEffect(() => {
    const locationSubscription = locationBridge.current.subscribeToLocationUpdates(userId, (location) => {
      if (location && location.latitude && location.longitude) {
        setUserLocation({
          lat: location.latitude,
          lng: location.longitude
        });
      }
    });
    
    // Limpar a inscrição ao desmontar
    return () => {
      if (locationSubscription && locationSubscription.unsubscribe) {
        locationSubscription.unsubscribe();
      }
    };
  }, [userId]);
  
  /**
   * Manipula a alteração de filtros
   */
  const handleFilterChange = (type) => {
    setFilters(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };
  
  /**
   * Manipula a adição de um novo alerta
   */
  const handleAddAlert = async (alertData) => {
    try {
      const newAlert = await alertBridge.current.createAlert({
        ...alertData,
        userId,
        latitude: userLocation.lat,
        longitude: userLocation.lng
      });
      
      if (newAlert) {
        setAlerts(prev => [...prev, newAlert]);
        setIsAddingAlert(false);
      }
    } catch (error) {
      console.error('Erro ao adicionar alerta:', error);
    }
  };
  
  /**
   * Manipula a confirmação de um alerta
   */
  const handleConfirmAlert = async (alertId) => {
    try {
      const updatedAlert = await alertBridge.current.verifyAlert(alertId, userId, true);
      
      if (updatedAlert) {
        setAlerts(prev => 
          prev.map(alert => alert.id === updatedAlert.id ? updatedAlert : alert)
        );
      }
    } catch (error) {
      console.error('Erro ao confirmar alerta:', error);
    }
  };
  
  /**
   * Manipula o fechamento do alerta de emergência
   */
  const handleCloseEmergencyAlert = () => {
    setShowEmergencyAlert(false);
  };
  
  /**
   * Função para calcular a distância entre dois pontos geográficos
   */
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3; // metros
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  };
  
  /**
   * Renderiza ícone para cada tipo de alerta
   */
  const renderAlertIcon = (type) => {
    const iconProps = { 
      size: 24, 
      color: ALERT_COLORS[type] || '#000000'
    };
    
    switch (type) {
      case 'SHOOTING':
        return <AlertOctagon {...iconProps} />;
      case 'KIDNAPPING':
        return <UserX {...iconProps} />;
      case 'CARGO_THEFT':
        return <Truck {...iconProps} />;
      case 'SUSPICIOUS_VEHICLE':
        return <Eye {...iconProps} />;
      case 'SPEEDING_VEHICLE':
        return <Car {...iconProps} />;
      default:
        return <AlertTriangle {...iconProps} />;
    }
  };
  
  /**
   * Renderiza a descrição do tipo de alerta
   */
  const getAlertTypeDescription = (type) => {
    switch (type) {
      case 'SHOOTING':
        return 'Tiroteio';
      case 'KIDNAPPING':
        return 'Sequestro/Arrastão';
      case 'CARGO_THEFT':
        return 'Roubo de Carga';
      case 'SUSPICIOUS_VEHICLE':
        return 'Veículo Suspeito';
      case 'SPEEDING_VEHICLE':
        return 'Veículo em Alta Velocidade';
      default:
        return 'Alerta Desconhecido';
    }
  };
  
  return (
    <div className="brazil-security-map-container h-full w-full relative">
      {/* Mapa */}
      <Map
        ref={mapRef}
        center={mapCenter}
        zoom={initialZoom}
        className="h-full w-full"
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {/* Marcador de localização do usuário */}
        <Marker position={[userLocation.lat, userLocation.lng]}>
          <Popup>Sua localização atual</Popup>
        </Marker>
        
        {/* Marcadores de alertas */}
        {filteredAlerts.map(alert => (
          <React.Fragment key={alert.id}>
            <Marker 
              position={[alert.latitude, alert.longitude]}
              icon={renderAlertIcon(alert.type)}
              eventHandlers={{
                click: () => setSelectedAlert(alert)
              }}
            />
            
            {/* Círculo de raio do alerta */}
            <Circle 
              center={[alert.latitude, alert.longitude]}
              radius={NOTIFICATION_RADIUS[alert.type] || 5000}
              pathOptions={{
                color: ALERT_COLORS[alert.type] || '#000000',
                fillColor: ALERT_COLORS[alert.type] || '#000000',
                fillOpacity: 0.1
              }}
            />
          </React.Fragment>
        ))}
      </Map>
      
      {/* Painel lateral de filtros */}
      <div className="filter-panel absolute top-4 right-4 bg-gray-900 bg-opacity-90 p-4 rounded-lg shadow-lg text-white">
        <h3 className="text-lg font-bold mb-3 border-b border-gray-700 pb-2">Filtros de Alertas</h3>
        <FormGroup>
          {Object.keys(filters).map(filterType => (
            <FormControlLabel
              key={filterType}
              control={
                <Switch
                  checked={filters[filterType]}
                  onChange={() => handleFilterChange(filterType)}
                  style={{ 
                    color: ALERT_COLORS[filterType],
                    '& .MuiSwitch-track': { backgroundColor: ALERT_COLORS[filterType] }
                  }}
                />
              }
              label={
                <div className="flex items-center gap-2">
                  {renderAlertIcon(filterType)}
                  <span>{getAlertTypeDescription(filterType)}</span>
                </div>
              }
            />
          ))}
        </FormGroup>
        
        <Button 
          onClick={() => setIsAddingAlert(true)}
          className="mt-4 w-full bg-amber-500 hover:bg-amber-600 text-black font-bold"
        >
          Reportar Incidente
        </Button>
      </div>
      
      {/* Detalhes do alerta selecionado */}
      {selectedAlert && (
        <div className="alert-details absolute bottom-4 left-4 bg-gray-900 bg-opacity-90 p-4 rounded-lg shadow-lg text-white max-w-md">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-2">
              {renderAlertIcon(selectedAlert.type)}
              <h3 className="text-lg font-bold">
                {getAlertTypeDescription(selectedAlert.type)}
              </h3>
            </div>
            <button 
              onClick={() => setSelectedAlert(null)}
              className="text-gray-400 hover:text-white"
            >
              <XCircle size={20} />
            </button>
          </div>
          
          <div className="mt-2">
            {selectedAlert.description && (
              <p className="my-2">{selectedAlert.description}</p>
            )}
            
            {/* Informações específicas por tipo de alerta */}
            {selectedAlert.type === 'SHOOTING' && selectedAlert.shootingInfo && (
              <div className="mt-2">
                <p><strong>Intensidade:</strong> {
                  selectedAlert.shootingInfo.intensity === 'HIGH' ? 'Alta' :
                  selectedAlert.shootingInfo.intensity === 'MEDIUM' ? 'Média' : 'Baixa'
                }</p>
                {selectedAlert.shootingInfo.involvedGroups && selectedAlert.shootingInfo.involvedGroups.length > 0 && (
                  <p><strong>Grupos envolvidos:</strong> {selectedAlert.shootingInfo.involvedGroups.join(', ')}</p>
                )}
                {selectedAlert.shootingInfo.estimatedDuration && (
                  <p><strong>Duração estimada:</strong> {selectedAlert.shootingInfo.estimatedDuration} minutos</p>
                )}
              </div>
            )}
            
            {selectedAlert.type === 'KIDNAPPING' && selectedAlert.kidnappingInfo && (
              <div className="mt-2">
                <p><strong>Tipo:</strong> {
                  selectedAlert.kidnappingInfo.kidnapType === 'KIDNAPPING' ? 'Sequestro' :
                  selectedAlert.kidnappingInfo.kidnapType === 'FLASH_KIDNAP' ? 'Sequestro Relâmpago' : 'Arrastão'
                }</p>
                {selectedAlert.kidnappingInfo.vehiclesCount && (
                  <p><strong>Quantidade de veículos:</strong> {selectedAlert.kidnappingInfo.vehiclesCount}</p>
                )}
                {selectedAlert.kidnappingInfo.victimsCount && (
                  <p><strong>Vítimas envolvidas:</strong> {selectedAlert.kidnappingInfo.victimsCount}</p>
                )}
              </div>
            )}
            
            {selectedAlert.type === 'CARGO_THEFT' && selectedAlert.cargoTheftInfo && (
              <div className="mt-2">
                {selectedAlert.cargoTheftInfo.isBlockingRoad && (
                  <p className="text-red-300 font-bold">Bloqueia a rodovia!</p>
                )}
                {selectedAlert.cargoTheftInfo.weaponsPresent && (
                  <p className="text-red-300 font-bold">Presença de armamento!</p>
                )}
                {selectedAlert.cargoTheftInfo.vehiclesCount && (
                  <p><strong>Veículos envolvidos:</strong> {selectedAlert.cargoTheftInfo.vehiclesCount}</p>
                )}
                {selectedAlert.cargoTheftInfo.isTargetingSpecificCargo && selectedAlert.cargoTheftInfo.targetedCargoType && (
                  <p><strong>Alvo específico:</strong> {selectedAlert.cargoTheftInfo.targetedCargoType}</p>
                )}
              </div>
            )}
            
            {selectedAlert.type === 'SUSPICIOUS_VEHICLE' && selectedAlert.suspiciousVehicleInfo && (
              <div className="mt-2">
                {selectedAlert.suspiciousVehicleInfo.vehicleModel && (
                  <p><strong>Modelo:</strong> {selectedAlert.suspiciousVehicleInfo.vehicleModel}</p>
                )}
                {selectedAlert.suspiciousVehicleInfo.vehicleColor && (
                  <p><strong>Cor:</strong> {selectedAlert.suspiciousVehicleInfo.vehicleColor}</p>
                )}
                {selectedAlert.suspiciousVehicleInfo.licensePlate && (
                  <p><strong>Placa:</strong> {selectedAlert.suspiciousVehicleInfo.licensePlate}</p>
                )}
                <p><strong>Atividade suspeita:</strong> {
                  selectedAlert.suspiciousVehicleInfo.suspiciousActivity === 'FOLLOWING_TRUCKS' ? 'Seguindo caminhões' :
                  selectedAlert.suspiciousVehicleInfo.suspiciousActivity === 'MONITORING_ROAD' ? 'Monitorando a estrada' :
                  selectedAlert.suspiciousVehicleInfo.suspiciousActivity === 'SUSPICIOUS_STOPS' ? 'Paradas suspeitas' :
                  selectedAlert.suspiciousVehicleInfo.suspiciousActivity === 'FAKE_POLICE' ? 'Falsa blitz/polícia' : 
                  'Comunicações suspeitas'
                }</p>
              </div>
            )}
            
            {selectedAlert.type === 'SPEEDING_VEHICLE' && selectedAlert.speedingVehicleInfo && (
              <div className="mt-2">
                {selectedAlert.speedingVehicleInfo.vehicleModel && (
                  <p><strong>Modelo:</strong> {selectedAlert.speedingVehicleInfo.vehicleModel}</p>
                )}
                {selectedAlert.speedingVehicleInfo.vehicleColor && (
                  <p><strong>Cor:</strong> {selectedAlert.speedingVehicleInfo.vehicleColor}</p>
                )}
                {selectedAlert.speedingVehicleInfo.licensePlate && (
                  <p><strong>Placa:</strong> {selectedAlert.speedingVehicleInfo.licensePlate}</p>
                )}
                {selectedAlert.speedingVehicleInfo.estimatedSpeed && (
                  <p><strong>Velocidade estimada:</strong> {selectedAlert.speedingVehicleInfo.estimatedSpeed} km/h</p>
                )}
                {selectedAlert.speedingVehicleInfo.direction && (
                  <p><strong>Direção:</strong> {selectedAlert.speedingVehicleInfo.direction}</p>
                )}
                {selectedAlert.speedingVehicleInfo.isDrivingDangerously && (
                  <p className="text-red-300 font-bold">Dirigindo perigosamente!</p>
                )}
              </div>
            )}
            
            <div className="mt-3 flex justify-between">
              <Button
                onClick={() => handleConfirmAlert(selectedAlert.id)}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Confirmar Alerta
              </Button>
              
              <Button 
                onClick={() => {
                  // Navegação para o local do alerta usando KingLoc
                  if (window.KingLoc && typeof window.KingLoc.navigateTo === 'function') {
                    window.KingLoc.navigateTo(selectedAlert.latitude, selectedAlert.longitude);
                  }
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Navegar até Local
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Modal de adição de alerta */}
      {isAddingAlert && (
        <AddBrazilSecurityAlert 
          onClose={() => setIsAddingAlert(false)}
          onSubmit={handleAddAlert}
          userLocation={userLocation}
        />
      )}
      
      {/* Modal de alerta de emergência */}
      {showEmergencyAlert && emergencyAlertData && (
        <BrazilEmergencyAlertModal
          alert={emergencyAlertData}
          onClose={handleCloseEmergencyAlert}
        />
      )}
    </div>
  );
};

export default BrazilSecurityAlertsMap;