/**
 * NavigationScreen.jsx
 * 
 * Componente React Native para a tela de navegação ativa do sistema KingRoad.
 * Implementa o painel de navegação, simulação de rotas e reroteamento mencionados no relatório.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  StatusBar,
  Dimensions,
  Platform,
  Animated,
  Alert,
  BackHandler,
  SafeAreaView
} from 'react-native';

// Serviços do sistema KingRoad
import { NavigationService } from '../services/NavigationService';
import { POIService } from '../services/POIService';
import { TranslationsService } from '../services/TranslationsService';
import { RegionalVisualsService } from '../services/RegionalVisualsService';
import { VoiceCommandService } from '../services/VoiceCommandService';

// Componentes do sistema KingRoad
import NavMap from '../components/NavMap';
import SpeedPanel from '../components/SpeedPanel';
import NavigationPanel from '../components/NavigationPanel';
import SearchBar from '../components/SearchBar';
import RouteDetails from '../components/RouteDetails';
import AlertsPanel from '../components/AlertsPanel';
import BottomSheet from '../components/BottomSheet';
import QuickReportButton from '../components/QuickReportButton';
import VoiceButton from '../components/VoiceButton';
import LoadingOverlay from '../components/LoadingOverlay';

// Ícones e assets
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width, height } = Dimensions.get('window');

const NavigationScreen = ({ route, navigation }) => {
  // Serviços
  const navigationService = useRef(NavigationService.getInstance());
  const poiService = useRef(POIService.getInstance());
  const translationsService = useRef(TranslationsService.getInstance());
  const visualsService = useRef(RegionalVisualsService.getInstance());
  const voiceCommandService = useRef(VoiceCommandService.getInstance());
  
  // Parâmetros de navegação
  const destination = route.params?.destination;
  const routeOptions = route.params?.routeOptions;
  const simulationMode = route.params?.simulationMode || false;
  
  // Estados do componente
  const [currentLocation, setCurrentLocation] = useState(null);
  const [activeRoute, setActiveRoute] = useState(null);
  const [routeSimulation, setRouteSimulation] = useState(null);
  const [nextInstruction, setNextInstruction] = useState(null);
  const [distanceToNextPoint, setDistanceToNextPoint] = useState(null);
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState(null);
  const [currentSpeed, setCurrentSpeed] = useState(0);
  const [speedLimit, setSpeedLimit] = useState(null);
  const [isNavigating, setIsNavigating] = useState(false);
  const [mapType, setMapType] = useState('standard');
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [showRouteDetails, setShowRouteDetails] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [nearbyPOIs, setNearbyPOIs] = useState([]);
  const [activeAlerts, setActiveAlerts] = useState([]);
  const [showVoiceRecognition, setShowVoiceRecognition] = useState(false);
  const [isNightMode, setIsNightMode] = useState(false);
  const [showSpeedWarning, setShowSpeedWarning] = useState(false);
  const [truckMode, setTruckMode] = useState(true); // Por padrão, começa em modo caminhão
  const [mapZoomLevel, setMapZoomLevel] = useState(15);
  const [recentInstructions, setRecentInstructions] = useState([]);
  
  // Refs para animações e interações
  const mapRef = useRef(null);
  const bottomSheetRef = useRef(null);
  const instructionOpacity = useRef(new Animated.Value(1)).current;
  const warningAnimation = useRef(new Animated.Value(0)).current;
  
  // Obter valores de safe area para layouts seguros
  const insets = useSafeAreaInsets();
  
  // Efeito para lidar com o botão de voltar nativo do Android
  useEffect(() => {
    const handleBackPress = () => {
      if (isNavigating) {
        confirmExitNavigation();
        return true; // Impede o comportamento padrão
      }
      return false; // Permite o comportamento padrão
    };

    BackHandler.addEventListener('hardwareBackPress', handleBackPress);
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', handleBackPress);
    };
  }, [isNavigating]);
  
  // Efeito para inicializar o componente
  useEffect(() => {
    initializeScreen();
    
    // Cleanup
    return () => {
      cleanupScreen();
    };
  }, []);
  
  // Efeito para iniciar navegação quando um destino é fornecido
  useEffect(() => {
    if (destination) {
      startNavigationToDestination(destination, routeOptions);
    }
  }, [destination]);
  
  // Efeito para atualizar o tema baseado na hora do dia
  useEffect(() => {
    const checkTimeOfDay = () => {
      const currentHour = new Date().getHours();
      const newNightMode = currentHour < 6 || currentHour >= 18;
      if (newNightMode !== isNightMode) {
        setIsNightMode(newNightMode);
        setMapType(newNightMode ? 'night' : 'standard');
      }
    };
    
    // Verificar imediatamente e configurar um intervalo
    checkTimeOfDay();
    const intervalId = setInterval(checkTimeOfDay, 60000); // Verificar a cada minuto
    
    return () => clearInterval(intervalId);
  }, [isNightMode]);
  
  // Efeito para lidar com alertas de velocidade
  useEffect(() => {
    if (speedLimit && currentSpeed > speedLimit * 1.1) { // 10% acima do limite
      showSpeedWarningAnimation();
    } else {
      hideSpeedWarningAnimation();
    }
  }, [currentSpeed, speedLimit]);

  /**
   * Inicializa o componente da tela de navegação
   */
  const initializeScreen = async () => {
    setIsLoading(true);
    
    try {
      // Inicializar serviços necessários
      await navigationService.current.initialize();
      
      // Obter localização atual
      const location = await navigationService.current.getCurrentLocation();
      setCurrentLocation(location);
      
      // Verificar se deve entrar em modo simulação automaticamente
      if (simulationMode) {
        startSimulationMode();
      }
      
      // Configurar listeners para atualizações de navegação
      setupNavigationListeners();
      
      // Configurar listeners para alertas
      setupAlertsListeners();
      
      // Verificar tema atual
      const currentTheme = visualsService.current.getCurrentTheme();
      setIsNightMode(currentTheme.isDark);
      
      // Configurar o modo de navegação (caminhão/carro)
      const savedVehicleMode = await getSavedVehicleMode();
      setTruckMode(savedVehicleMode === 'truck');
      
      // Buscar POIs próximos
      if (location) {
        fetchNearbyPOIs(location);
      }
    } catch (error) {
      console.error('Erro ao inicializar a tela de navegação:', error);
      Alert.alert(
        'Erro de Inicialização',
        'Ocorreu um erro ao inicializar a navegação. Tente novamente.'
      );
    } finally {
      setIsLoading(false);
    }
  };
  
  /**
   * Limpa recursos ao desmontar o componente
   */
  const cleanupScreen = () => {
    // Parar navegação ativa, se houver
    if (isNavigating) {
      navigationService.current.stopNavigation();
    }
    
    // Remover listeners e outros recursos
    navigationService.current.removeAllListeners();
    
    // Parar serviço de comando de voz, se estiver ativo
    if (voiceCommandService.current) {
      voiceCommandService.current.stopListening();
    }
  };
  
  /**
   * Configura listeners para eventos de navegação
   */
  const setupNavigationListeners = () => {
    // Listener para atualizações de localização
    navigationService.current.addLocationUpdateListener((location) => {
      setCurrentLocation(location);
      
      // Atualizar velocidade
      if (location.speed !== undefined) {
        // Converter de m/s para km/h
        const speedKmh = location.speed * 3.6;
        setCurrentSpeed(speedKmh);
      }
      
      // Se estiver navegando, atualizar progresso da rota
      if (isNavigating && activeRoute) {
        updateRouteProgress(location);
      }
      
      // Atualizar POIs próximos ocasionalmente (a cada X metros)
      if (shouldUpdateNearbyPOIs(location)) {
        fetchNearbyPOIs(location);
      }
    });
    
    // Listener para mudanças de limite de velocidade
    navigationService.current.addSpeedLimitListener((limit) => {
      setSpeedLimit(limit);
    });
    
    // Listener para instruções de navegação
    navigationService.current.addNavigationInstructionListener((instruction) => {
      setNextInstruction(instruction);
      
      // Adicionar à lista de instruções recentes
      setRecentInstructions(prev => {
        const updated = [instruction, ...prev];
        // Manter apenas as últimas 5 instruções
        return updated.slice(0, 5);
      });
      
      // Animar a instrução (fade in/out)
      animateInstruction();
    });
    
    // Listener para finalização da rota
    navigationService.current.addRouteCompletionListener(() => {
      handleRouteCompletion();
    });
  };
  
  /**
   * Configura listeners para alertas
   */
  const setupAlertsListeners = () => {
    document.addEventListener('newAlert', (event) => {
      const newAlert = event.detail;
      handleNewAlert(newAlert);
    });
  };
  
  /**
   * Inicia a navegação para um destino específico
   */
  const startNavigationToDestination = async (dest, options = {}) => {
    setIsLoading(true);
    
    try {
      // Obter localização atual como ponto de partida
      const origin = await navigationService.current.getCurrentLocation();
      if (!origin) {
        throw new Error('Não foi possível obter sua localização atual');
      }
      
      // Configurar opções de rota
      const routeConfig = {
        ...options,
        avoidTolls: options.avoidTolls || false,
        avoidHighways: options.avoidHighways || false,
        truckMode: truckMode,
        truckHeight: options.truckHeight || 4.5, // padrão: 4.5m para caminhões
        truckWeight: options.truckWeight || 40, // padrão: 40 toneladas
        truckLength: options.truckLength || 18.5, // padrão: 18.5m
        truckAxles: options.truckAxles || 5, // padrão: 5 eixos
      };
      
      // Calcular rota
      const route = await navigationService.current.calculateRoute(origin, dest, routeConfig);
      
      // Iniciar navegação
      await navigationService.current.startNavigation(route);
      
      // Atualizar estados
      setActiveRoute(route);
      setIsNavigating(true);
      setEstimatedTimeRemaining(route.duration);
      
      // Centralizar mapa na rota
      if (mapRef.current) {
        mapRef.current.fitToRoute(route);
      }
      
      // Iniciar serviço de comando de voz
      if (voiceCommandService.current) {
        voiceCommandService.current.startListening();
      }
    } catch (error) {
      console.error('Erro ao iniciar navegação:', error);
      Alert.alert(
        'Erro de Navegação',
        'Não foi possível iniciar a navegação para o destino selecionado. Tente novamente.'
      );
    } finally {
      setIsLoading(false);
    }
  };
  
  /**
   * Inicia o modo de simulação de rota
   */
  const startSimulationMode = async () => {
    try {
      // Obter uma rota para simulação
      const simulationRoute = await navigationService.current.getSimulationRoute();
      
      if (simulationRoute) {
        // Configurar simulação
        const simulation = await navigationService.current.startSimulation(simulationRoute);
        
        // Atualizar estados
        setRouteSimulation(simulation);
        setActiveRoute(simulationRoute);
        setIsNavigating(true);
      }
    } catch (error) {
      console.error('Erro ao iniciar simulação:', error);
    }
  };
  
  /**
   * Atualiza o progresso da rota com base na localização atual
   */
  const updateRouteProgress = (location) => {
    if (!activeRoute) return;
    
    // Calcular distância até o próximo ponto
    const distanceToNext = navigationService.current.calculateDistanceToNextWaypoint(location, activeRoute);
    setDistanceToNextPoint(distanceToNext);
    
    // Atualizar tempo estimado restante
    const timeRemaining = navigationService.current.calculateRemainingTime(location, activeRoute, currentSpeed);
    setEstimatedTimeRemaining(timeRemaining);
  };
  
  /**
   * Verifica se deve atualizar os POIs próximos
   */
  const shouldUpdateNearbyPOIs = (newLocation) => {
    if (!currentLocation) return true;
    
    // Atualizar POIs a cada 2km
    const distance = calculateDistance(
      newLocation.latitude,
      newLocation.longitude,
      currentLocation.latitude,
      currentLocation.longitude
    );
    
    return distance > 2;
  };
  
  /**
   * Busca POIs próximos à localização
   */
  const fetchNearbyPOIs = async (location) => {
    try {
      const pois = await poiService.current.findNearbyPOIs(
        location,
        truckMode ? ['diesel', 'truck_stop', 'truck_parking', 'restaurant', 'rest_area'] : 
                    ['gas_station', 'restaurant', 'rest_area', 'hotel'],
        15 // raio em km
      );
      
      setNearbyPOIs(pois);
    } catch (error) {
      console.error('Erro ao buscar POIs próximos:', error);
    }
  };
  
  /**
   * Calcula a distância entre dois pontos geográficos (fórmula de Haversine)
   */
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Raio da Terra em km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c;
  };
  
  const toRad = (value) => {
    return value * Math.PI / 180;
  };
  
  /**
   * Manipula a conclusão da rota
   */
  const handleRouteCompletion = () => {
    setIsNavigating(false);
    setActiveRoute(null);
    
    // Parar o serviço de comando de voz
    if (voiceCommandService.current) {
      voiceCommandService.current.stopListening();
    }
    
    // Mostrar dialog de conclusão
    Alert.alert(
      'Destino Alcançado',
      'Você chegou ao seu destino!',
      [
        { text: 'OK', onPress: () => navigation.navigate('Home') }
      ]
    );
  };
  
  /**
   * Animação para instruções de navegação
   */
  const animateInstruction = () => {
    Animated.sequence([
      Animated.timing(instructionOpacity, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true
      }),
      Animated.timing(instructionOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true
      })
    ]).start();
  };
  
  /**
   * Mostrar animação de aviso de velocidade
   */
  const showSpeedWarningAnimation = () => {
    if (!showSpeedWarning) {
      setShowSpeedWarning(true);
      Animated.loop(
        Animated.sequence([
          Animated.timing(warningAnimation, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true
          }),
          Animated.timing(warningAnimation, {
            toValue: 0.3,
            duration: 500,
            useNativeDriver: true
          })
        ])
      ).start();
    }
  };
  
  /**
   * Esconder animação de aviso de velocidade
   */
  const hideSpeedWarningAnimation = () => {
    if (showSpeedWarning) {
      Animated.timing(warningAnimation, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true
      }).start(() => {
        setShowSpeedWarning(false);
      });
    }
  };
  
  /**
   * Manipula um novo alerta recebido
   */
  const handleNewAlert = (alert) => {
    // Adicionar o novo alerta à lista
    setActiveAlerts(prev => [...prev, alert]);
    
    // Mostrar notificação ou indicação visual
    if (alert.priority === 'high') {
      // Para alertas de alta prioridade, mostrar imediatamente
      setShowAlerts(true);
    }
    
    // Reproduzir som de alerta, se disponível
    playAlertSound(alert.type);
  };
  
  /**
   * Reproduz um som de alerta específico
   */
  const playAlertSound = (alertType) => {
    // Implementação depende da biblioteca de áudio utilizada
    console.log(`Reproduzindo som para alerta do tipo: ${alertType}`);
  };
  
  /**
   * Confirma a saída da navegação
   */
  const confirmExitNavigation = () => {
    Alert.alert(
      'Encerrar Navegação',
      'Tem certeza que deseja encerrar a navegação atual?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Encerrar', 
          style: 'destructive',
          onPress: () => {
            navigationService.current.stopNavigation();
            setIsNavigating(false);
            setActiveRoute(null);
            navigation.goBack();
          }
        }
      ]
    );
  };
  
  /**
   * Alterna o modo de veículo entre caminhão e carro
   */
  const toggleVehicleMode = async () => {
    const newMode = !truckMode;
    setTruckMode(newMode);
    
    // Salvar preferência
    try {
      await localStorage.setItem('kingroad_vehicle_mode', newMode ? 'truck' : 'car');
    } catch (error) {
      console.error('Erro ao salvar modo de veículo:', error);
    }
    
    // Se estiver navegando, perguntar se deseja recalcular a rota
    if (isNavigating && activeRoute) {
      Alert.alert(
        'Modo de Veículo Alterado',
        `Modo alterado para ${newMode ? 'caminhão' : 'carro'}. Deseja recalcular a rota atual?`,
        [
          { text: 'Não' },
          { 
            text: 'Sim', 
            onPress: () => recalculateRouteWithCurrentMode() 
          }
        ]
      );
    }
  };
  
  /**
   * Recalcula a rota com o modo de veículo atual
   */
  const recalculateRouteWithCurrentMode = async () => {
    if (!activeRoute) return;
    
    setIsLoading(true);
    
    try {
      const currentLocation = await navigationService.current.getCurrentLocation();
      const destination = activeRoute.destination;
      
      // Manter as opções da rota anterior, mas atualizar o modo de veículo
      const options = {
        ...route.params?.routeOptions,
        truckMode: truckMode
      };
      
      // Calcular nova rota
      const newRoute = await navigationService.current.calculateRoute(
        currentLocation,
        destination,
        options
      );
      
      // Atualizar navegação
      await navigationService.current.updateNavigation(newRoute);
      
      // Atualizar estado
      setActiveRoute(newRoute);
      
      // Ajustar visualização do mapa
      if (mapRef.current) {
        mapRef.current.fitToRoute(newRoute);
      }
    } catch (error) {
      console.error('Erro ao recalcular rota:', error);
      Alert.alert(
        'Erro de Recálculo',
        'Não foi possível recalcular a rota com o novo modo de veículo. A rota anterior será mantida.'
      );
    } finally {
      setIsLoading(false);
    }
  };
  
  /**
   * Obtém o modo de veículo salvo nas preferências
   */
  const getSavedVehicleMode = async () => {
    try {
      const savedMode = localStorage.getItem('kingroad_vehicle_mode');
      return savedMode || 'truck'; // Padrão: caminhão
    } catch (error) {
      console.error('Erro ao obter modo de veículo salvo:', error);
      return 'truck'; // Fallback para caminhão
    }
  };
  
  /**
   * Alterna a visibilidade da barra de pesquisa
   */
  const toggleSearchBar = () => {
    setShowSearchBar(!showSearchBar);
  };
  
  /**
   * Alterna a visibilidade do painel de detalhes da rota
   */
  const toggleRouteDetails = () => {
    setShowRouteDetails(!showRouteDetails);
  };
  
  /**
   * Alterna a visibilidade do painel de alertas
   */
  const toggleAlertsPanel = () => {
    setShowAlerts(!showAlerts);
  };
  
  /**
   * Alterna o reconhecimento de voz
   */
  const toggleVoiceRecognition = () => {
    setShowVoiceRecognition(!showVoiceRecognition);
    
    if (!showVoiceRecognition) {
      // Iniciar reconhecimento
      if (voiceCommandService.current) {
        voiceCommandService.current.startListening();
      }
    } else {
      // Parar reconhecimento
      if (voiceCommandService.current) {
        voiceCommandService.current.stopListening();
      }
    }
  };
  
  /**
   * Alterna o tipo de mapa (standard, satélite, noite)
   */
  const toggleMapType = () => {
    const mapTypes = ['standard', 'satellite', 'night'];
    const currentIndex = mapTypes.indexOf(mapType);
    const nextIndex = (currentIndex + 1) % mapTypes.length;
    setMapType(mapTypes[nextIndex]);
  };
  
  /**
   * Altera o nível de zoom do mapa
   */
  const changeMapZoom = (zoomIn) => {
    const newZoom = zoomIn ? 
      Math.min(mapZoomLevel + 1, 20) : // Máximo zoom: 20
      Math.max(mapZoomLevel - 1, 5);   // Mínimo zoom: 5
    
    setMapZoomLevel(newZoom);
    
    if (mapRef.current) {
      mapRef.current.setZoom(newZoom);
    }
  };
  
  /**
   * Centraliza o mapa na localização atual
   */
  const centerMapOnCurrentLocation = () => {
    if (!currentLocation) return;
    
    if (mapRef.current) {
      mapRef.current.animateToLocation(currentLocation);
    }
  };
  
  /**
   * Cria um novo reporte rápido
   */
  const createQuickReport = () => {
    // Navegar para a tela de reporte rápido
    navigation.navigate('QuickReport', {
      currentLocation: currentLocation
    });
  };
  
  // Renderização do componente
  return (
    <SafeAreaView style={[styles.container, isNightMode && styles.containerNight]}>
      <StatusBar
        barStyle={isNightMode ? 'light-content' : 'dark-content'}
        backgroundColor={isNightMode ? '#000000' : '#FFFFFF'}
      />
      
      {/* Mapa de Navegação */}
      <NavMap
        ref={mapRef}
        style={styles.map}
        currentLocation={currentLocation}
        activeRoute={activeRoute}
        mapType={mapType}
        nearbyPOIs={nearbyPOIs}
        truckMode={truckMode}
        speedRestrictions={activeRoute?.speedRestrictions}
        zoomLevel={mapZoomLevel}
      />
      
      {/* Cabeçalho */}
      <View style={[
        styles.header,
        isNightMode && styles.headerNight,
        { paddingTop: insets.top }
      ]}>
        {showSearchBar ? (
          <SearchBar
            onClose={toggleSearchBar}
            onSearch={(destination) => {
              toggleSearchBar();
              startNavigationToDestination(destination);
            }}
            style={styles.searchBar}
          />
        ) : (
          <>
            <TouchableOpacity style={styles.backButton} onPress={isNavigating ? confirmExitNavigation : () => navigation.goBack()}>
              <Icon name="arrow-left" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.searchButton} onPress={toggleSearchBar}>
              <Icon name="magnify" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
              <Text style={[styles.searchButtonText, isNightMode && styles.textNight]}>
                {isNavigating ? 'Buscar ao longo da rota' : 'Para onde vamos?'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.mapTypeButton} onPress={toggleMapType}>
              <Icon name={
                mapType === 'standard' ? 'map-outline' :
                mapType === 'satellite' ? 'satellite' : 'weather-night'
              } size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
            </TouchableOpacity>
          </>
        )}
      </View>
      
      {/* Painel de instruções de navegação */}
      {isNavigating && nextInstruction && (
        <Animated.View style={[
          styles.instructionPanel,
          isNightMode && styles.instructionPanelNight,
          { opacity: instructionOpacity }
        ]}>
          <View style={styles.instructionIconContainer}>
            <Icon 
              name={getInstructionIcon(nextInstruction.type)} 
              size={36} 
              color={isNightMode ? "#FFFFFF" : "#000000"} 
            />
          </View>
          <View style={styles.instructionTextContainer}>
            <Text style={[styles.instructionText, isNightMode && styles.textNight]}>
              {nextInstruction.text}
            </Text>
            {nextInstruction.distance && (
              <Text style={[styles.instructionDistance, isNightMode && styles.textNight]}>
                {formatDistance(nextInstruction.distance)}
              </Text>
            )}
          </View>
        </Animated.View>
      )}
      
      {/* Painel de velocidade */}
      <SpeedPanel
        currentSpeed={currentSpeed}
        speedLimit={speedLimit}
        style={styles.speedPanel}
        isNightMode={isNightMode}
        isWarning={showSpeedWarning}
        warningOpacity={warningAnimation}
      />
      
      {/* Botões de controle do mapa */}
      <View style={styles.mapControls}>
        <TouchableOpacity 
          style={[styles.mapControlButton, isNightMode && styles.mapControlButtonNight]} 
          onPress={() => changeMapZoom(true)}
        >
          <Icon name="plus" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.mapControlButton, isNightMode && styles.mapControlButtonNight]} 
          onPress={() => changeMapZoom(false)}
        >
          <Icon name="minus" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.mapControlButton, isNightMode && styles.mapControlButtonNight]} 
          onPress={centerMapOnCurrentLocation}
        >
          <Icon name="crosshairs-gps" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
        </TouchableOpacity>
      </View>
      
      {/* Botão de alternar modo de veículo */}
      <TouchableOpacity 
        style={[styles.vehicleModeButton, isNightMode && styles.vehicleModeButtonNight]} 
        onPress={toggleVehicleMode}
      >
        <Icon 
          name={truckMode ? "truck" : "car"} 
          size={24} 
          color={isNightMode ? "#FFFFFF" : "#000000"} 
        />
      </TouchableOpacity>
      
      {/* Botão de reporte rápido */}
      <QuickReportButton
        style={styles.quickReportButton}
        isNightMode={isNightMode}
        onPress={createQuickReport}
      />
      
      {/* Botão de comando de voz */}
      <VoiceButton
        style={styles.voiceButton}
        isActive={showVoiceRecognition}
        isNightMode={isNightMode}
        onPress={toggleVoiceRecognition}
      />
      
      {/* Painel de navegação (quando em navegação ativa) */}
      {isNavigating && (
        <NavigationPanel
          style={styles.navigationPanel}
          destination={activeRoute?.destination?.name || 'Destino'}
          distance={distanceToNextPoint}
          duration={estimatedTimeRemaining}
          arrivalTime={calculateArrivalTime(estimatedTimeRemaining)}
          isNightMode={isNightMode}
          onDetailsPress={toggleRouteDetails}
        />
      )}
      
      {/* BottomSheet para detalhes da rota */}
      <BottomSheet
        ref={bottomSheetRef}
        visible={showRouteDetails}
        onClose={() => setShowRouteDetails(false)}
        snapPoints={['30%', '50%', '80%']}
        initialSnap={1}
      >
        <RouteDetails
          route={activeRoute}
          recentInstructions={recentInstructions}
          isNightMode={isNightMode}
        />
      </BottomSheet>
      
      {/* Painel de alertas */}
      {showAlerts && (
        <AlertsPanel
          alerts={activeAlerts}
          onClose={toggleAlertsPanel}
          isNightMode={isNightMode}
          style={styles.alertsPanel}
        />
      )}
      
      {/* Overlay de carregamento */}
      {isLoading && (
        <LoadingOverlay message="Calculando rota..." />
      )}
    </SafeAreaView>
  );
};

/**
 * Calcula o horário estimado de chegada
 */
const calculateArrivalTime = (durationInSeconds) => {
  if (!durationInSeconds) return '--:--';
  
  const now = new Date();
  const arrivalTime = new Date(now.getTime() + (durationInSeconds * 1000));
  
  return arrivalTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

/**
 * Mapeia tipos de instrução para ícones
 */
const getInstructionIcon = (type) => {
  const iconMap = {
    'turn-left': 'turn-left',
    'turn-right': 'turn-right',
    'turn-slight-left': 'arrow-bottom-left',
    'turn-slight-right': 'arrow-bottom-right',
    'turn-sharp-left': 'arrow-bottom-left-bold',
    'turn-sharp-right': 'arrow-bottom-right-bold',
    'keep-left': 'arrow-split-vertical',
    'keep-right': 'arrow-split-vertical',
    'roundabout': 'rotate-right',
    'enter-highway': 'highway',
    'exit-highway': 'highway',
    'continue': 'arrow-up-bold',
    'arrive': 'flag-checkered',
    'fork': 'call-split',
    'merge': 'call-merge',
    'ferry': 'ferry',
    'uturn': 'u-turn-right',
    'default': 'navigation'
  };
  
  return iconMap[type] || iconMap['default'];
};

/**
 * Formata distâncias para exibição
 */
const formatDistance = (distanceInMeters) => {
  if (distanceInMeters < 1000) {
    return `${Math.round(distanceInMeters)}m`;
  } else {
    const km = (distanceInMeters / 1000).toFixed(1);
    return `${km}km`;
  }
};

// Estilos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  containerNight: {
    backgroundColor: '#121212'
  },
  map: {
    ...StyleSheet.absoluteFillObject
  },
  header: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
    zIndex: 10
  },
  headerNight: {
    backgroundColor: 'rgba(18, 18, 18, 0.9)',
    borderBottomColor: '#333333'
  },
  backButton: {
    padding: 10
  },
  searchButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    padding: 10,
    marginHorizontal: 10
  },
  searchButtonText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#333333'
  },
  mapTypeButton: {
    padding: 10
  },
  instructionPanel: {
    position: 'absolute',
    top: 120,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    flexDirection: 'row',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5
  },
  instructionPanelNight: {
    backgroundColor: 'rgba(30, 30, 30, 0.9)'
  },
  instructionIconContainer: {
    marginRight: 15
  },
  instructionTextContainer: {
    flex: 1
  },
  instructionText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000'
  },
  instructionDistance: {
    fontSize: 14,
    color: '#666666',
    marginTop: 4
  },
  speedPanel: {
    position: 'absolute',
    bottom: 220,
    left: 20
  },
  mapControls: {
    position: 'absolute',
    right: 20,
    top: 120,
    backgroundColor: 'transparent'
  },
  mapControlButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2
  },
  mapControlButtonNight: {
    backgroundColor: 'rgba(30, 30, 30, 0.9)'
  },
  vehicleModeButton: {
    position: 'absolute',
    right: 20,
    bottom: 220,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2
  },
  vehicleModeButtonNight: {
    backgroundColor: 'rgba(30, 30, 30, 0.9)'
  },
  quickReportButton: {
    position: 'absolute',
    right: 20,
    bottom: 160
  },
  voiceButton: {
    position: 'absolute',
    right: 20,
    bottom: 100
  },
  navigationPanel: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 80,
    zIndex: 5
  },
  searchBar: {
    flex: 1
  },
  alertsPanel: {
    position: 'absolute',
    top: 180,
    left: 20,
    right: 20,
    maxHeight: 300,
    zIndex: 10
  },
  textNight: {
    color: '#FFFFFF'
  }
});

export default NavigationScreen;