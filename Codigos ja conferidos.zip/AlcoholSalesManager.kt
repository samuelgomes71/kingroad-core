// Sistema de Informação de Vendas de Bebidas Alcoólicas
// app/src/main/kotlin/com/kingroad/poi/alcohol

class AlcoholSalesManager(
    private val poiDatabase: POIDatabase,
    private val regulationService: RegulationService,
    private val locationService: LocationService
) {
    data class AlcoholPoint(
        val id: String,
        val type: AlcoholVenueType,
        val location: Location,
        val name: String,
        val salesInfo: AlcoholSalesInfo,
        val regulations: AlcoholRegulations,
        val reviews: List<Review>,
        val distance: Double,          // distância da rodovia
        val openingHours: OpeningHours
    )

    enum class AlcoholVenueType {
        LIQUOR_STORE,         // Loja especializada
        TRUCK_STOP,           // Parada de caminhão
        CONVENIENCE_STORE,    // Loja de conveniência
        GAS_STATION,          // Posto de gasolina
        GROCERY_STORE        // Supermercado
    }

    data class AlcoholSalesInfo(
        val sellsAlcohol: Boolean,
        val alcoholTypes: Set<AlcoholType>,
        val restrictions: Set<SaleRestriction>,
        val prices: PriceLevel,
        val selection: SelectionSize,
        val requiresID: Boolean = true
    )

    enum class AlcoholType {
        BEER,
        WINE,
        SPIRITS,
        COOLERS,
        CRAFT_BEER
    }

    data class AlcoholRegulations(
        val state: String,
        val saleHours: TimeRange,
        val minimumAge: Int,
        val specialRestrictions: List<String>,
        val sundaySales: Boolean,
        val holidaySales: Boolean
    )

    // Buscar pontos de venda de bebidas
    suspend fun findAlcoholPoints(
        route: Route,
        preferences: AlcoholPreferences
    ): List<AlcoholPoint> {
        val jurisdictions = route.getJurisdictions()
        
        return jurisdictions.flatMap { jurisdiction ->
            findPointsInJurisdiction(
                jurisdiction = jurisdiction,
                preferences = preferences,
                route = route
            )
        }.sortedBy { it.distance }
    }

    // Encontrar pontos em uma jurisdição específica
    private suspend fun findPointsInJurisdiction(
        jurisdiction: String,
        preferences: AlcoholPreferences,
        route: Route
    ): List<AlcoholPoint> {
        // Obter regulamentações locais
        val regulations = regulationService.getAlcoholRegulations(jurisdiction)
        
        // Encontrar pontos permitidos
        return poiDatabase.findAlcoholPoints(
            jurisdiction = jurisdiction,
            route = route,
            maxDistance = preferences.maxDistance
        ).filter { point ->
            isPointValid(point, regulations, preferences)
        }
    }

    // Validar ponto de venda
    private fun isPointValid(
        point: AlcoholPoint,
        regulations: AlcoholRegulations,
        preferences: AlcoholPreferences
    ): Boolean {
        // Verificar horário de funcionamento
        if (!point.openingHours.isOpenAt(getCurrentTime())) {
            return false
        }

        // Verificar tipos de bebida disponíveis
        if (!point.salesInfo.alcoholTypes.containsAll(preferences.requiredTypes)) {
            return false
        }

        // Verificar restrições especiais
        if (point.salesInfo.restrictions.any { it in preferences.excludedRestrictions }) {
            return false
        }

        return true
    }

    // Obter informações detalhadas
    suspend fun getDetailedInfo(
        pointId: String
    ): AlcoholPointDetails {
        val point = poiDatabase.getAlcoholPoint(pointId)
        val regulations = regulationService.getAlcoholRegulations(point.location)
        
        return AlcoholPointDetails(
            point = point,
            regulations = regulations,
            warnings = generateWarnings(point, regulations),
            alternativePoints = findNearbyAlternatives(point)
        )
    }

    // Gerar avisos importantes
    private fun generateWarnings(
        point: AlcoholPoint,
        regulations: AlcoholRegulations
    ): List<Warning> {
        val warnings = mutableListOf<Warning>()

        // Verificar horário de fechamento próximo
        if (point.openingHours.isClosingSoon()) {
            warnings.add(Warning(
                type = WarningType.CLOSING_SOON,
                message = "Local fecha em ${point.openingHours.timeUntilClose()} minutos"
            ))
        }

        // Verificar restrições especiais
        regulations.specialRestrictions.forEach { restriction ->
            warnings.add(Warning(
                type = WarningType.SPECIAL_RESTRICTION,
                message = restriction
            ))
        }

        return warnings
    }

    // Encontrar alternativas próximas
    private suspend fun findNearbyAlternatives(
        point: AlcoholPoint
    ): List<AlcoholPoint> {
        return poiDatabase.findNearbyAlcoholPoints(
            location = point.location,
            radius = ALTERNATIVE_SEARCH_RADIUS,
            excludeId = point.id
        )
    }

    companion object {
        private const val ALTERNATIVE_SEARCH_RADIUS = 10000.0  // 10km
        private const val DEFAULT_MAX_DISTANCE = 1000.0       // 1km da rodovia
    }
}

// Enums de suporte
enum class SaleRestriction {
    NO_SUNDAY_SALES,
    LIMITED_HOURS,
    STATE_STORE_ONLY,
    NO_COLD_BEER,
    PACKAGE_ONLY
}

enum class PriceLevel {
    BUDGET,
    MODERATE,
    PREMIUM
}

enum class SelectionSize {
    LIMITED,    // Poucas opções
    MODERATE,   // Seleção média
    EXTENSIVE  // Grande variedade
}

enum class WarningType {
    CLOSING_SOON,
    SPECIAL_RESTRICTION,
    HOLIDAY_RESTRICTION,
    AGE_VERIFICATION_REQUIRED
}

data class Warning(
    val type: WarningType,
    val message: String
)