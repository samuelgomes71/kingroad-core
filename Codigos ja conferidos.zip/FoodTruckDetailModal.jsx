import React, { useState } from 'react';

const FoodTruckDetailModal = ({ foodTruck, visible, onClose, onNavigate, onAddToRoute }) => {
  const [userRating, setUserRating] = useState(0);
  const [ratingSubmitted, setRatingSubmitted] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);
  
  // Se não houver food truck ou o modal não estiver visível, não renderiza nada
  if (!foodTruck || !visible) return null;
  
  // Demo data para o truck selecionado
  const truckDetails = {
    ...foodTruck,
    description: "Van de comida especializada em café da manhã tradicional inglês, sanduíches e bebidas quentes. Estacionamento amplo para caminhões, com mesas externas disponíveis em dias de bom tempo.",
    openingHours: "05:30 - 15:00",
    daysOpen: "Seg-Sáb",
    cuisineType: "English Breakfast, Sanduíches, Café",
    parkingSpace: true,
    lastVerified: new Date(2024, 10, 15).getTime(),
    region: "Hertfordshire",
    roadName: "A1 Northbound",
    photos: ["/api/placeholder/400/300", "/api/placeholder/400/300"]
  };
  
  // Formata a data da última verificação
  const formatVerifiedDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };
  
  // Renderiza as estrelas para avaliação
  const renderRatingStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <button
          key={`star-${i}`}
          disabled={ratingSubmitted}
          onClick={() => !ratingSubmitted && setUserRating(i)}
          className="focus:outline-none"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="24" 
            height="24" 
            viewBox="0 0 24 24" 
            fill={i <= userRating ? "#FFD700" : "none"}
            stroke={i <= userRating ? "#FFD700" : "#888888"}
            strokeWidth="2"
            className="transition-all duration-200 hover:scale-110"
          >
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        </button>
      );
    }
    return (
      <div className="flex space-x-1">
        {stars}
      </div>
    );
  };
  
  // Simula envio de avaliação
  const handleSubmitRating = () => {
    if (userRating > 0) {
      setRatingSubmitted(true);
      // Aqui seria implementada a lógica para enviar a avaliação ao backend
      console.log(`Avaliação enviada: ${userRating} estrelas para ${truckDetails.name}`);
    }
  };
  
  // Simula verificação do food truck pela comunidade
  const handleVerify = () => {
    // Lógica para marcar o food truck como verificado
    console.log(`Food truck ${truckDetails.name} verificado pela comunidade`);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col border-2 border-yellow-600">
        {/* Cabeçalho */}
        <div className="bg-gray-800 px-6 py-4 flex justify-between items-center border-b border-gray-700">
          <h2 className="text-xl font-bold text-yellow-500">
            {truckDetails.name}
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-gray-700 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        
        {/* Conteúdo com scroll */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Informações principais */}
          <div className="mb-6">
            <div className="flex items-center mb-4">
              <div className={`px-3 py-1 rounded-full text-sm font-medium 
                ${truckDetails.verifiedByCommunity 
                  ? 'bg-green-900 text-green-300' 
                  : 'bg-yellow-900 text-yellow-300'}`}
              >
                {truckDetails.verifiedByCommunity 
                  ? 'Verificado pela comunidade' 
                  : 'Aguardando verificação'}
              </div>
              <div className="flex items-center ml-3">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="16" 
                  height="16" 
                  viewBox="0 0 24 24" 
                  fill="#FFD700" 
                  stroke="none" 
                  className="mr-1"
                >
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
                <span className="text-yellow-500 font-bold">{truckDetails.userRating.toFixed(1)}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 mt-1">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                <div>
                  <p className="text-gray-300">{truckDetails.roadName}</p>
                  <p className="text-gray-500 text-sm">{truckDetails.region}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 mt-1">
                  <circle cx="12" cy="12" r="10"/>
                  <polyline points="12 6 12 12 16 14"/>
                </svg>
                <div>
                  <p className="text-gray-300">{truckDetails.openingHours}</p>
                  <p className="text-gray-500 text-sm">{truckDetails.daysOpen}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 mt-1">
                  <path d="M7 10l5-6 5 6"/>
                  <path d="M21 10l-2 8c-.17.7-.76 1.16-1.48 1.16H6.48c-.72 0-1.31-.46-1.48-1.16l-2-8"/>
                  <path d="M12 15a2 2 0 1 1 0 4 2 2 0 1 1 0-4z"/>
                </svg>
                <div>
                  <p className="text-gray-300">{truckDetails.cuisineType}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 mt-1">
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                  <path d="M16 2v2"/>
                  <path d="M8 2v2"/>
                  <path d="M3 10h18"/>
                </svg>
                <div>
                  <p className="text-gray-300">Última verificação:</p>
                  <p className="text-gray-500 text-sm">{formatVerifiedDate(truckDetails.lastVerified)}</p>
                </div>
              </div>
            </div>
            
            {/* Descrição */}
            <div className="mb-4">
              <h3 className="text-white font-medium mb-2">Descrição</h3>
              <p className="text-gray-400 text-sm">
                {showFullDescription 
                  ? truckDetails.description 
                  : truckDetails.description.slice(0, 100) + (truckDetails.description.length > 100 ? '...' : '')}
              </p>
              {truckDetails.description.length > 100 && (
                <button 
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="text-yellow-500 text-sm mt-1 hover:underline"
                >
                  {showFullDescription ? 'Mostrar menos' : 'Ler mais'}
                </button>
              )}
            </div>
            
            {/* Estacionamento disponível */}
            {truckDetails.parkingSpace && (
              <div className="mb-4 p-3 bg-gray-800 rounded-lg flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-3">
                  <rect x="3" y="3" width="18" height="18" rx="2"/>
                  <path d="M9 17V7h4a3 3 0 0 1 0 6H9"/>
                </svg>
                <span className="text-green-400">Estacionamento para caminhões disponível</span>
              </div>
            )}
            
            {/* Fotos - Simuladas com placeholders */}
            <div className="mb-4">
              <h3 className="text-white font-medium mb-2">Fotos</h3>
              <div className="grid grid-cols-2 gap-2">
                {truckDetails.photos.map((photo, index) => (
                  <div key={`photo-${index}`} className="h-36 rounded-lg overflow-hidden">
                    <img 
                      src={photo} 
                      alt={`${truckDetails.name} - Foto ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
            
            {/* Avaliação */}
            <div className="mb-4">
              <h3 className="text-white font-medium mb-2">Sua avaliação</h3>
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                {renderRatingStars()}
                <button 
                  onClick={handleSubmitRating}
                  disabled={userRating === 0 || ratingSubmitted}
                  className={`px-4 py-2 rounded text-sm font-medium ${
                    userRating === 0 || ratingSubmitted
                      ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                      : 'bg-yellow-600 hover:bg-yellow-700 text-white'
                  }`}
                >
                  {ratingSubmitted ? 'Avaliação enviada' : 'Enviar avaliação'}
                </button>
              </div>
            </div>
            
            {/* Verificação pela comunidade */}
            {!truckDetails.verifiedByCommunity && (
              <div className="mb-4 p-4 border border-gray-700 rounded-lg">
                <h3 className="text-white font-medium mb-2">Verificar Food Truck</h3>
                <p className="text-gray-400 text-sm mb-3">
                  Você visitou este food truck recentemente? Ajude outros caminhoneiros confirmando que este POI ainda está ativo.
                </p>
                <button 
                  onClick={handleVerify}
                  className="px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded text-sm font-medium"
                >
                  Confirmar que existe
                </button>
              </div>
            )}
          </div>
        </div>
        
        {/* Barra de ações */}
        <div className="bg-gray-800 px-6 py-4 flex gap-2 border-t border-gray-700">
          <button 
            onClick={() => onNavigate && onNavigate(truckDetails)}
            className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white py-3 px-4 rounded-md font-medium flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <polygon points="3 11 22 2 13 21 11 13 3 11"/>
            </svg>
            Navegar
          </button>
          <button 
            onClick={() => onAddToRoute && onAddToRoute(truckDetails)}
            className="flex-1 border border-gray-600 text-gray-300 hover:bg-gray-700 py-3 px-4 rounded-md font-medium flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
            Adicionar parada
          </button>
        </div>
      </div>
    </div>
  );
};

export default FoodTruckDetailModal;