import React, { useState, useEffect } from 'react';
import { Alert } from '../ui/Alert';
import ReportModals from './ReportModals';
import { reportTypes } from './reportTypesConfig';
import { CommonButton } from './commonButtons';

/**
 * Componente principal para reportes e alertas no sistema KingRoad
 * Implementa suporte a múltiplos idiomas e geolocalização
 */
const ReportesComponent = ({ 
  currentLocation,
  isOnline,
  userType,
  currentLanguage,
  translations 
}) => {
  const [reports, setReports] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState(null);
  
  // Verificar permissões baseadas no tipo de usuário
  const canCreateReport = userType === 'MotoristaVIP' || userType === 'Administrador';
  const canViewAllReports = userType === 'Administrador';
  
  useEffect(() => {
    // Carregar reportes próximos à localização atual
    const loadNearbyReports = async () => {
      if (!currentLocation) return;
      
      setIsLoading(true);
      try {
        // Usar Firebase ou API REST dependendo da conexão
        const endpoint = isOnline 
          ? 'https://api.kingroad.com/reports/nearby'
          : 'local://reports/cached';
          
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            latitude: currentLocation.latitude,
            longitude: currentLocation.longitude,
            radius: 10000, // 10km
            limit: 50
          }),
        });
        
        if (!response.ok) {
          throw new Error(translations['Não foi possível carregar os pontos de interesse.'] || 'Failed to load reports');
        }
        
        const data = await response.json();
        setReports(data.reports);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadNearbyReports();
    
    // Sistema de atualização em tempo real para motoristas VIP
    if (userType === 'MotoristaVIP' && isOnline) {
      const realtimeSubscription = subscribeToRealtimeReports(currentLocation);
      return () => {
        // Limpar inscrição ao desmontar
        realtimeSubscription.unsubscribe();
      };
    }
  }, [currentLocation, isOnline]);
  
  // Função para inscrever em atualizações em tempo real
  const subscribeToRealtimeReports = (location) => {
    // Implementação de Firebase Realtime Database ou WebSockets
    // Esta é uma função mock
    console.log('Subscrevendo a alertas de segurança', location);
    return {
      unsubscribe: () => console.log('Unsubscribed from realtime updates')
    };
  };
  
  // Função para criar um novo reporte
  const handleCreateReport = async (reportData) => {
    try {
      const response = await fetch('https://api.kingroad.com/reports/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...reportData,
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          timestamp: new Date().toISOString(),
          userId: 'current-user-id' // Deve vir de um contexto de autenticação
        }),
      });
      
      if (!response.ok) {
        throw new Error(translations['Não foi possível adicionar o ponto de interesse.'] || 'Failed to create report');
      }
      
      const data = await response.json();
      setReports([data.report, ...reports]);
      setShowModal(false);
      
      // Mostrar mensagem de sucesso
      Alert.success(translations['Novo ponto de interesse adicionado.'] || 'Report added successfully');
    } catch (err) {
      setError(err.message);
      Alert.error(err.message);
    }
  };
  
  const openReportModal = (type) => {
    setSelectedReportType(type);
    setShowModal(true);
  };
  
  return (
    <div className="flex flex-col items-center justify-center p-4">
      {error && (
        <div className="w-full bg-red-100 text-red-700 p-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Menu rápido de tipos de reportes */}
      <div className="flex space-x-2 mb-4 overflow-x-auto w-full pb-2">
        {reportTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => openReportModal(type)}
            className="flex flex-col items-center p-2 bg-gray-800 rounded-lg min-w-[80px] hover:bg-gray-700"
            disabled={!canCreateReport}
          >
            <div className="w-8 h-8 flex items-center justify-center text-white mb-1">
              {type.icon}
            </div>
            <span className="text-xs text-white whitespace-nowrap">{translations[type.name] || type.name}</span>
          </button>
        ))}
      </div>
      
      {/* Lista de reportes */}
      <div className="w-full space-y-4">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : reports.length > 0 ? (
          reports.map((report) => (
            <div 
              key={report.id} 
              className="bg-gray-800 p-4 rounded-lg shadow"
            >
              <div className="flex items-center mb-2">
                <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                  {reportTypes.find(t => t.id === report.type)?.icon}
                </div>
                <div>
                  <h3 className="text-white font-medium">{report.title}</h3>
                  <p className="text-gray-400 text-sm">{report.distance} • {report.timestamp}</p>
                </div>
              </div>
              <p className="text-gray-300 mb-3">{report.description}</p>
              
              {/* Ações nos reportes */}
              <div className="flex space-x-2">
                <CommonButton 
                  type="primary" 
                  size="small" 
                  onClick={() => {/* Navegar para */}}
                >
                  {translations['Navegar'] || 'Navigate'}
                </CommonButton>
                <CommonButton 
                  type="secondary" 
                  size="small" 
                  onClick={() => {/* Ver detalhes */}}
                >
                  {translations['Detalhes'] || 'Details'}
                </CommonButton>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-gray-400">
            {translations['Sem reportes recentes nesta área'] || 'No recent reports in this area'}
          </div>
        )}
      </div>
      
      {/* Modal para criar reportes */}
      {showModal && (
        <ReportModals
          type={selectedReportType}
          onClose={() => setShowModal(false)}
          onSubmit={handleCreateReport}
          currentLocation={currentLocation}
          translations={translations}
        />
      )}
    </div>
  );
};

export default ReportesComponent;