// Sistema de POIs Culturais
// app/src/main/kotlin/com/kingroad/poi/cultural

class CulturalPOIManager(
    private val poiDatabase: POIDatabase,
    private val regionManager: RegionManager,
    private val reviewService: ReviewService
) {
    data class CulturalPOI(
        val id: String,
        val type: POIType,
        val location: Location,
        val name: String,
        val facilities: Set<Facility>,
        val culturalFeatures: Set<CulturalFeature>,
        val reviews: List<Review>,
        val lastVerified: Long,
        val regionSpecific: RegionSpecificInfo? = null
    )

    enum class CulturalFeature {
        WINE_SERVICE,           // Serviço de vinhos
        QUALITY_RESTAURANT,     // Restaurante de qualidade
        SHOWERS,               // Chuveiros
        TRUCK_SHOP,            // Loja de acessórios
        GAMING_MACHINES,       // Máquinas de jogo
        LOTTERY,               // Loteria
        WATER_POINT,           // Ponto de água
        NATURAL_SPRING,        // Fonte natural
        MARKET_NEARBY,         // Mercado próximo
        GROCERY_NEARBY        // Mercearia próxima
    }

    data class RegionSpecificInfo(
        val country: String,
        val region: String,
        val culturalNotes: List<String>,
        val localSpecialties: List<String>,
        val bestTimeToVisit: TimeRange?,
        val popularWithDrivers: Boolean,
        val authenticityScore: Double      // 0.0 a 1.0
    )

    data class Review(
        val userId: String,
        val rating: Int,            // 1-5
        val comment: String,
        val features: Set<CulturalFeature>,
        val timestamp: Long,
        val nationality: String?,
        val verified: Boolean
    )

    // Buscar POIs culturais na rota
    suspend fun findCulturalPOIsOnRoute(
        route: Route,
        preferences: CulturalPreferences
    ): List<CulturalPOI> {
        val region = regionManager.determineRegion(route)
        val culturalContext = getCulturalContext(region)
        
        return poiDatabase.findPOIsAlong(route)
            .filter { poi -> 
                matchesCulturalPreferences(poi, preferences, culturalContext)
            }
            .sortedByDescending { poi ->
                calculateCulturalRelevance(poi, preferences, culturalContext)
            }
    }

    // Verificar adequação cultural
    private fun matchesCulturalPreferences(
        poi: CulturalPOI,
        preferences: CulturalPreferences,
        context: CulturalContext
    ): Boolean {
        // Verificar requisitos básicos
        if (!poi.facilities.containsAll(preferences.requiredFacilities)) {
            return false
        }

        // Verificar adequação cultural
        val culturalScore = calculateCulturalScore(
            poi = poi,
            context = context
        )

        return culturalScore >= MINIMUM_CULTURAL_SCORE
    }

    // Calcular relevância cultural
    private fun calculateCulturalRelevance(
        poi: CulturalPOI,
        preferences: CulturalPreferences,
        context: CulturalContext
    ): Double {
        return listOf(
            calculateFacilityScore(poi, preferences),
            calculateAuthenticityScore(poi, context),
            calculatePopularityScore(poi),
            calculateReviewScore(poi)
        ).average()
    }

    // Buscar fontes naturais de água
    suspend fun findNaturalWaterSources(
        region: Region,
        maxDistance: Double
    ): List<CulturalPOI> {
        return poiDatabase.findByFeature(
            feature = CulturalFeature.NATURAL_SPRING,
            region = region,
            maxDistance = maxDistance
        ).filter { poi ->
            poi.reviews.averageRating() >= MINIMUM_WATER_RATING &&
            poi.lastVerified >= System.currentTimeMillis() - MAX_WATER_VERIFICATION_AGE
        }
    }

    // Encontrar restaurantes com características específicas
    suspend fun findSpecialtyRestaurants(
        location: Location,
        preferences: RestaurantPreferences
    ): List<CulturalPOI> {
        val region = regionManager.determineRegion(location)
        val timeContext = timeService.getCurrentTimeContext()
        
        return poiDatabase.findRestaurants(location)
            .filter { restaurant ->
                matchesRestaurantCriteria(restaurant, preferences, region)
            }
            .sortedByDescending { restaurant ->
                calculateRestaurantScore(restaurant, preferences, timeContext)
            }
    }

    // Verificar disponibilidade de facilidades
    suspend fun checkFacilityAvailability(
        poi: CulturalPOI,
        facility: CulturalFeature
    ): FacilityStatus {
        return when (facility) {
            CulturalFeature.SHOWERS -> checkShowerAvailability(poi)
            CulturalFeature.WINE_SERVICE -> checkWineService(poi)
            CulturalFeature.GAMING_MACHINES -> checkGamingAvailability(poi)
            CulturalFeature.WATER_POINT -> checkWaterAvailability(poi)
            else -> FacilityStatus.UNKNOWN
        }
    }

    companion object {
        private const val MINIMUM_CULTURAL_SCORE = 0.7
        private const val MINIMUM_WATER_RATING = 4.0
        private const val MAX_WATER_VERIFICATION_AGE = 30L * 24 * 60 * 60 * 1000 // 30 dias
    }
}

// Extensões úteis
fun List<Review>.averageRating(): Double {
    return if (isNotEmpty()) {
        map { it.rating }.average()
    } else 0.0
}

// Enums de suporte
enum class FacilityStatus {
    AVAILABLE,
    BUSY,
    CLOSED,
    MAINTENANCE,
    UNKNOWN
}

data class RestaurantPreferences(
    val wineService: Boolean = false,
    val localCuisine: Boolean = false,
    val truckParking: Boolean = true,
    val showers: Boolean = false,
    val openLate: Boolean = false,
    val priceRange: PriceRange = PriceRange.MEDIUM
)

enum class PriceRange {
    BUDGET,
    MEDIUM,
    PREMIUM
}