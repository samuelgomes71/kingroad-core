import SQLite from 'react-native-sqlite-storage';

/**
 * Serviço para gerenciamento de banco de dados SQLite
 */
const DatabaseService = {
  /**
   * Inicializa o banco de dados SQLite
   * @returns {Promise<SQLite.SQLiteDatabase>} Instância do banco de dados
   */
  async initDatabase() {
    try {
      SQLite.enablePromise(true);
      const db = await SQLite.openDatabase({
        name: 'kingroad.db',
        location: 'default',
      });
      
      // Criar tabelas se não existirem
      await this.createTables(db);
      console.log('Banco de dados inicializado com sucesso');
      return db;
    } catch (error) {
      console.error('Erro ao inicializar banco de dados:', error);
      throw error;
    }
  },

  /**
   * Cria as tabelas necessárias no banco de dados
   * @param {SQLite.SQLiteDatabase} db - Instância do banco de dados
   * @returns {Promise<void>}
   */
  async createTables(db) {
    // Tabela para dados do mapa
    await db.executeSql(`
      CREATE TABLE IF NOT EXISTS map_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        data TEXT,
        last_updated INTEGER
      );
    `);

    // Tabela para alertas de segurança
    await db.executeSql(`
      CREATE TABLE IF NOT EXISTS security_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        latitude REAL,
        longitude REAL,
        description TEXT,
        created_at INTEGER,
        expires_at INTEGER,
        reported_by TEXT,
        acknowledged INTEGER DEFAULT 0
      );
    `);

    // Tabela para rotas salvas
    await db.executeSql(`
      CREATE TABLE IF NOT EXISTS saved_routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        origin TEXT,
        destination TEXT,
        waypoints TEXT,
        distance REAL,
        duration INTEGER,
        created_at INTEGER
      );
    `);
  },

  /**
   * Salva dados do mapa no banco de dados
   * @param {Object} data - Dados do mapa a serem salvos
   * @returns {Promise<number>} ID do registro inserido
   */
  async saveMapData(data) {
    try {
      const db = await this.initDatabase();
      const timestamp = Date.now();
      
      const [result] = await db.executeSql(
        `INSERT INTO map_data (title, data, last_updated) VALUES (?, ?, ?);`,
        [data.title, JSON.stringify(data), timestamp]
      );
      
      console.log('Dados do mapa salvos com sucesso');
      return result.insertId;
    } catch (error) {
      console.error('Erro ao salvar dados do mapa:', error);
      throw error;
    }
  },

  /**
   * Recupera todos os dados do mapa do banco de dados
   * @returns {Promise<Array>} Array com os dados do mapa
   */
  async getMapData() {
    try {
      const db = await this.initDatabase();
      const [results] = await db.executeSql('SELECT * FROM map_data ORDER BY last_updated DESC;');
      
      const mapData = [];
      for (let i = 0; i < results.rows.length; i++) {
        const item = results.rows.item(i);
        mapData.push({
          id: item.id,
          title: item.title,
          data: JSON.parse(item.data),
          lastUpdated: item.last_updated
        });
      }
      
      return mapData;
    } catch (error) {
      console.error('Erro ao recuperar dados do mapa:', error);
      return [];
    }
  },
  
  /**
   * Salva um alerta de segurança no banco de dados
   * @param {Object} alert - Dados do alerta
   * @returns {Promise<number>} ID do alerta inserido
   */
  async saveSecurityAlert(alert) {
    try {
      const db = await this.initDatabase();
      const timestamp = Date.now();
      // Alertas expiram após 24 horas por padrão
      const expiryTime = timestamp + (24 * 60 * 60 * 1000);
      
      const [result] = await db.executeSql(
        `INSERT INTO security_alerts (
          type, latitude, longitude, description, 
          created_at, expires_at, reported_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?);`,
        [
          alert.type, 
          alert.latitude, 
          alert.longitude, 
          alert.description || '', 
          timestamp,
          alert.expiresAt || expiryTime,
          alert.reportedBy || 'anonymous'
        ]
      );
      
      console.log('Alerta de segurança salvo com sucesso');
      return result.insertId;
    } catch (error) {
      console.error('Erro ao salvar alerta de segurança:', error);
      throw error;
    }
  },
  
  /**
   * Recupera alertas de segurança ativos
   * @param {String} type - Tipo de alerta (opcional)
   * @returns {Promise<Array>} Array com os alertas
   */
  async getSecurityAlerts(type = null) {
    try {
      const db = await this.initDatabase();
      const now = Date.now();
      let query = 'SELECT * FROM security_alerts WHERE expires_at > ? ';
      const params = [now];
      
      if (type) {
        query += 'AND type = ? ';
        params.push(type);
      }
      
      query += 'ORDER BY created_at DESC;';
      const [results] = await db.executeSql(query, params);
      
      const alerts = [];
      for (let i = 0; i < results.rows.length; i++) {
        const item = results.rows.item(i);
        alerts.push({
          id: item.id,
          type: item.type,
          latitude: item.latitude,
          longitude: item.longitude,
          description: item.description,
          createdAt: item.created_at,
          expiresAt: item.expires_at,
          reportedBy: item.reported_by,
          acknowledged: item.acknowledged === 1
        });
      }
      
      return alerts;
    } catch (error) {
      console.error('Erro ao recuperar alertas de segurança:', error);
      return [];
    }
  },
  
  /**
   * Salva uma rota no banco de dados
   * @param {Object} route - Dados da rota
   * @returns {Promise<number>} ID da rota inserida
   */
  async saveRoute(route) {
    try {
      const db = await this.initDatabase();
      const timestamp = Date.now();
      
      const [result] = await db.executeSql(
        `INSERT INTO saved_routes (
          name, origin, destination, waypoints, 
          distance, duration, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?);`,
        [
          route.name,
          JSON.stringify(route.origin),
          JSON.stringify(route.destination),
          JSON.stringify(route.waypoints || []),
          route.distance,
          route.duration,
          timestamp
        ]
      );
      
      console.log('Rota salva com sucesso');
      return result.insertId;
    } catch (error) {
      console.error('Erro ao salvar rota:', error);
      throw error;
    }
  },
  
  /**
   * Recupera rotas salvas do banco de dados
   * @returns {Promise<Array>} Array com as rotas salvas
   */
  async getSavedRoutes() {
    try {
      const db = await this.initDatabase();
      const [results] = await db.executeSql('SELECT * FROM saved_routes ORDER BY created_at DESC;');
      
      const routes = [];
      for (let i = 0; i < results.rows.length; i++) {
        const item = results.rows.item(i);
        routes.push({
          id: item.id,
          name: item.name,
          origin: JSON.parse(item.origin),
          destination: JSON.parse(item.destination),
          waypoints: JSON.parse(item.waypoints),
          distance: item.distance,
          duration: item.duration,
          createdAt: item.created_at
        });
      }
      
      return routes;
    } catch (error) {
      console.error('Erro ao recuperar rotas salvas:', error);
      return [];
    }
  },
  
  /**
   * Fecha a conexão com o banco de dados
   * @returns {Promise<void>}
   */
  async closeDatabase() {
    try {
      const db = await this.initDatabase();
      await db.close();
      console.log('Conexão com banco de dados fechada');
    } catch (error) {
      console.error('Erro ao fechar banco de dados:', error);
    }
  }
};

export default DatabaseService;