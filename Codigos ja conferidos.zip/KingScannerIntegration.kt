package com.kingroad.utils

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.kingroad.database.DocumentDao
import com.kingroad.database.Document
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Integra com biblioteca OCR e permite digitalizar comprovantes
 * e documentos, vinculando-os a viagens ou entregas.
 */
class KingScannerIntegration(
    private val context: Context,
    private val documentDao: DocumentDao,
    private val fileCompressor: FileCompressor? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "KingScannerIntegration"
        
        // Tipos de documento suportados
        enum class DocumentType(val id: String) {
            RECEIPT("receipt"),              // Recibo/comprovante
            INVOICE("invoice"),              // Nota fiscal
            DELIVERY_PROOF("delivery_proof"), // Comprovante de entrega
            ID_DOCUMENT("id_document"),      // Documento de identidade
            VEHICLE_DOC("vehicle_doc"),      // Documento do veículo
            CARGO_MANIFEST("cargo_manifest"), // Manifesto de carga
            OTHER("other")                   // Outros
        }
        
        // Diretório para armazenar documentos
        private const val DOCUMENT_DIR = "kingroad_documents"
        
        // Tamanho máximo de documentos (5MB)
        private const val MAX_DOCUMENT_SIZE = 5 * 1024 * 1024
    }
    
    // Estado do scanner
    private val _scannerState = MutableStateFlow<ScannerState>(ScannerState.Idle)
    val scannerState: StateFlow<ScannerState> = _scannerState.asStateFlow()
    
    // Histórico de documentos escaneados
    private val _scanHistory = MutableLiveData<List<ScanHistoryItem>>(emptyList())
    val scanHistory: LiveData<List<ScanHistoryItem>> = _scanHistory
    
    // Reconhecedor de texto
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    
    init {
        // Garante que o diretório de documentos existe
        createDocumentDirectory()
    }

    /**
     * Garante que o diretório para armazenamento de documentos existe
     */
    private fun createDocumentDirectory() {
        val dir = File(context.filesDir, DOCUMENT_DIR)
        if (!dir.exists()) {
            if (dir.mkdirs()) {
                Log.d(TAG, "Diretório de documentos criado com sucesso")
            } else {
                Log.e(TAG, "Falha ao criar diretório de documentos")
            }
        }
    }
    
    /**
     * Escaneia um documento a partir de uma URI de imagem
     * 
     * @param imageUri URI da imagem a ser escaneada
     * @param documentType Tipo do documento
     * @param tripId ID da viagem (opcional)
     * @param deliveryId ID da entrega (opcional)
     * @param metadata Metadados adicionais (opcional)
     * @return ID do documento escaneado
     */
    suspend fun scanDocument(
        imageUri: Uri,
        documentType: DocumentType,
        tripId: String? = null,
        deliveryId: String? = null,
        metadata: String? = null
    ): String = withContext(dispatcher) {
        try {
            _scannerState.value = ScannerState.Scanning
            
            // Extrai texto do documento
            val inputImage = InputImage.fromFilePath(context, imageUri)
            val recognizedText = recognizeTextFromImage(inputImage)
            
            // Salva a imagem do documento localmente
            val documentFile = saveDocumentImage(imageUri, documentType)
            
            // Cria um identificador único para o documento
            val documentId = UUID.randomUUID().toString()
            
            // Cria o objeto do documento
            val document = Document(
                id = documentId,
                type = documentType.id,
                filePath = documentFile.absolutePath,
                fileName = documentFile.name,
                extractedText = recognizedText.text,
                tripId = tripId,
                deliveryId = deliveryId,
                createdAt = System.currentTimeMillis(),
                metadata = metadata,
                synced = false,
                syncTimestamp = null
            )
            
            // Salva no banco de dados
            documentDao.insert(document)
            
            // Adiciona ao histórico
            addToScanHistory(ScanHistoryItem(
                id = documentId,
                type = documentType.id,
                fileName = documentFile.name,
                timestamp = System.currentTimeMillis(),
                tripId = tripId,
                deliveryId = deliveryId
            ))
            
            // Atualiza estado
            _scannerState.value = ScannerState.Success(documentId)
            
            return@withContext documentId
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao escanear documento: ${e.message}", e)
            _scannerState.value = ScannerState.Error(e.message ?: "Erro desconhecido")
            throw e
        }
    }
    
    /**
     * Escaneia um documento a partir de um bitmap
     * 
     * @param bitmap Bitmap da imagem a ser escaneada
     * @param documentType Tipo do documento
     * @param tripId ID da viagem (opcional)
     * @param deliveryId ID da entrega (opcional)
     * @param metadata Metadados adicionais (opcional)
     * @return ID do documento escaneado
     */
    suspend fun scanDocument(
        bitmap: Bitmap,
        documentType: DocumentType,
        tripId: String? = null,
        deliveryId: String? = null,
        metadata: String? = null
    ): String = withContext(dispatcher) {
        try {
            _scannerState.value = ScannerState.Scanning
            
            // Extrai texto do documento
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val recognizedText = recognizeTextFromImage(inputImage)
            
            // Salva a imagem do documento localmente
            val documentFile = saveDocumentImage(bitmap, documentType)
            
            // Cria um identificador único para o documento
            val documentId = UUID.randomUUID().toString()
            
            // Cria o objeto do documento
            val document = Document(
                id = documentId,
                type = documentType.id,
                filePath = documentFile.absolutePath,
                fileName = documentFile.name,
                extractedText = recognizedText.text,
                tripId = tripId,
                deliveryId = deliveryId,
                createdAt = System.currentTimeMillis(),
                metadata = metadata,
                synced = false,
                syncTimestamp = null
            )
            
            // Salva no banco de dados
            documentDao.insert(document)
            
            // Adiciona ao histórico
            addToScanHistory(ScanHistoryItem(
                id = documentId,
                type = documentType.id,
                fileName = documentFile.name,
                timestamp = System.currentTimeMillis(),
                tripId = tripId,
                deliveryId = deliveryId
            ))
            
            // Atualiza estado
            _scannerState.value = ScannerState.Success(documentId)
            
            return@withContext documentId
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao escanear documento: ${e.message}", e)
            _scannerState.value = ScannerState.Error(e.message ?: "Erro desconhecido")
            throw e
        }
    }
    
    /**
     * Reconhece texto de uma imagem usando ML Kit
     */
    private suspend fun recognizeTextFromImage(image: InputImage): Text = 
        suspendCancellableCoroutine { continuation ->
            textRecognizer.process(image)
                .addOnSuccessListener { text ->
                    continuation.resume(text)
                }
                .addOnFailureListener { e ->
                    continuation.resumeWithException(e)
                }
        }
    
    /**
     * Salva a imagem do documento a partir de uma URI
     */
    private suspend fun saveDocumentImage(imageUri: Uri, documentType: DocumentType): File = 
        withContext(dispatcher) {
            val dir = File(context.filesDir, DOCUMENT_DIR)
            
            // Cria nome de arquivo único
            val timestamp = System.currentTimeMillis()
            val filename = "${documentType.id}_${timestamp}.jpg"
            val file = File(dir, filename)
            
            // Copia o arquivo
            val inputStream = context.contentResolver.openInputStream(imageUri)
            val outputStream = FileOutputStream(file)
            
            inputStream?.use { input ->
                outputStream.use { output ->
                    // Comprime o arquivo se o compressor estiver disponível
                    if (fileCompressor != null) {
                        // Comprime o arquivo antes de salvar
                        val compressedData = fileCompressor.compressImage(input, MAX_DOCUMENT_SIZE)
                        output.write(compressedData)
                    } else {
                        // Copia o arquivo sem compressão
                        input.copyTo(output)
                    }
                }
            } ?: throw IllegalStateException("Não foi possível abrir o arquivo de imagem")
            
            return@withContext file
        }
    
    /**
     * Salva a imagem do documento a partir de um bitmap
     */
    private suspend fun saveDocumentImage(bitmap: Bitmap, documentType: DocumentType): File = 
        withContext(dispatcher) {
            val dir = File(context.filesDir, DOCUMENT_DIR)
            
            // Cria nome de arquivo único
            val timestamp = System.currentTimeMillis()
            val filename = "${documentType.id}_${timestamp}.jpg"
            val file = File(dir, filename)
            
            // Salva o bitmap
            FileOutputStream(file).use { output ->
                // Comprime o bitmap
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, output)
                output.flush()
            }
            
            return@withContext file
        }
    
    /**
     * Anexa um documento a uma viagem
     * 
     * @param documentId ID do documento
     * @param tripId ID da viagem
     * @return true se o documento foi anexado com sucesso
     */
    suspend fun attachDocumentToTrip(documentId: String, tripId: String): Boolean = 
        withContext(dispatcher) {
            try {
                val document = documentDao.getById(documentId) ?: return@withContext false
                
                // Atualiza o documento com o ID da viagem
                val updatedDocument = document.copy(
                    tripId = tripId,
                    synced = false,
                    syncTimestamp = null
                )
                
                // Salva no banco de dados
                documentDao.update(updatedDocument)
                
                return@withContext true
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao anexar documento a viagem: ${e.message}", e)
                return@withContext false
            }
        }
    
    /**
     * Anexa um documento a uma entrega
     * 
     * @param documentId ID do documento
     * @param deliveryId ID da entrega
     * @return true se o documento foi anexado com sucesso
     */
    suspend fun attachDocumentToDelivery(documentId: String, deliveryId: String): Boolean = 
        withContext(dispatcher) {
            try {
                val document = documentDao.getById(documentId) ?: return@withContext false
                
                // Atualiza o documento com o ID da entrega
                val updatedDocument = document.copy(
                    deliveryId = deliveryId,
                    synced = false,
                    syncTimestamp = null
                )
                
                // Salva no banco de dados
                documentDao.update(updatedDocument)
                
                return@withContext true
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao anexar documento a entrega: ${e.message}", e)
                return@withContext false
            }
        }
    
    /**
     * Obtém um documento pelo ID
     * 
     * @param documentId ID do documento
     * @return Documento ou null se não encontrado
     */
    suspend fun getDocument(documentId: String): Document? = 
        withContext(dispatcher) {
            return@withContext documentDao.getById(documentId)
        }
    
    /**
     * Obtém o arquivo de imagem do documento
     * 
     * @param document Documento
     * @return Arquivo de imagem ou null se não encontrado
     */
    fun getDocumentFile(document: Document): File? {
        val file = File(document.filePath)
        return if (file.exists()) file else null
    }
    
    /**
     * Obtém todos os documentos de uma viagem
     * 
     * @param tripId ID da viagem
     * @return Lista de documentos
     */
    suspend fun getDocumentsForTrip(tripId: String): List<Document> = 
        withContext(dispatcher) {
            return@withContext documentDao.getByTripId(tripId)
        }
    
    /**
     * Obtém todos os documentos de uma entrega
     * 
     * @param deliveryId ID da entrega
     * @return Lista de documentos
     */
    suspend fun getDocumentsForDelivery(deliveryId: String): List<Document> = 
        withContext(dispatcher) {
            return@withContext documentDao.getByDeliveryId(deliveryId)
        }
    
    /**
     * Exclui um documento
     * 
     * @param documentId ID do documento
     * @return true se o documento foi excluído com sucesso
     */
    suspend fun deleteDocument(documentId: String): Boolean = 
        withContext(dispatcher) {
            try {
                val document = documentDao.getById(documentId) ?: return@withContext false
                
                // Exclui o arquivo físico
                val file = File(document.filePath)
                if (file.exists()) {
                    file.delete()
                }
                
                // Exclui do banco de dados
                documentDao.delete(document)
                
                return@withContext true
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao excluir documento: ${e.message}", e)
                return@withContext false
            }
        }
    
    /**
     * Obtém o número total de documentos armazenados
     * 
     * @return Número de documentos
     */
    suspend fun getDocumentCount(): Int = 
        withContext(dispatcher) {
            return@withContext documentDao.getCount()
        }
    
    /**
     * Obtém o espaço total ocupado por documentos (em bytes)
     * 
     * @return Espaço ocupado em bytes
     */
    suspend fun getDocumentStorageSize(): Long = 
        withContext(dispatcher) {
            val dir = File(context.filesDir, DOCUMENT_DIR)
            return@withContext calculateDirectorySize(dir)
        }
    
    /**
     * Calcula o tamanho total de um diretório recursivamente
     */
    private fun calculateDirectorySize(directory: File): Long {
        var size: Long = 0
        val files = directory.listFiles() ?: return 0
        
        for (file in files) {
            size += if (file.isDirectory) {
                calculateDirectorySize(file)
            } else {
                file.length()
            }
        }
        
        return size
    }
    
    /**
     * Extrai informações específicas do documento com base em seu tipo
     * 
     * @param documentId ID do documento
     * @return Mapa com informações extraídas ou null se falhar
     */
    suspend fun extractDocumentInfo(documentId: String): Map<String, String>? = 
        withContext(dispatcher) {
            try {
                val document = documentDao.getById(documentId) ?: return@withContext null
                val text = document.extractedText ?: return@withContext null
                
                // Use diferentes estratégias de extração com base no tipo de documento
                return@withContext when (document.type) {
                    DocumentType.RECEIPT.id -> extractReceiptInfo(text)
                    DocumentType.INVOICE.id -> extractInvoiceInfo(text)
                    DocumentType.CARGO_MANIFEST.id -> extractCargoManifestInfo(text)
                    else -> extractGenericInfo(text)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao extrair informações do documento: ${e.message}", e)
                return@withContext null
            }
        }
    
    /**
     * Extrai informações de um recibo/comprovante
     */
    private fun extractReceiptInfo(text: String): Map<String, String> {
        val info = mutableMapOf<String, String>()
        
        // Extrai data e hora
        val dateRegex = Regex("(\\d{2}/\\d{2}/\\d{4}|\\d{2}/\\d{2}/\\d{2})")
        val dateMatch = dateRegex.find(text)
        if (dateMatch != null) {
            info["date"] = dateMatch.value
        }
        
        // Extrai valor total
        val totalRegex = Regex("(TOTAL:?|VALOR:?|R\\$)[\\s]*([\\d\\.,]+)")
        val totalMatch = totalRegex.find(text)
        if (totalMatch != null) {
            info["total"] = totalMatch.groupValues[2]
        }
        
        // Extrai CNPJ/CPF
        val documentRegex = Regex("(CNPJ|CPF):?[\\s]*(\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2}|\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2})")
        val documentMatch = documentRegex.find(text)
        if (documentMatch != null) {
            info["document"] = documentMatch.groupValues[2]
        }
        
        return info
    }
    
    /**
     * Extrai informações de uma nota fiscal
     */
    private fun extractInvoiceInfo(text: String): Map<String, String> {
        val info = mutableMapOf<String, String>()
        
        // Extrai número da nota
        val nfRegex = Regex("(NF-e|NOTA FISCAL)[:\\s]*(\\d+)")
        val nfMatch = nfRegex.find(text)
        if (nfMatch != null) {
            info["invoice_number"] = nfMatch.groupValues[2]
        }
        
        // Extrai data de emissão
        val dateRegex = Regex("(EMISSÃO|DATA DE EMISSÃO)[:\\s]*(\\d{2}/\\d{2}/\\d{4})")
        val dateMatch = dateRegex.find(text)
        if (dateMatch != null) {
            info["issue_date"] = dateMatch.groupValues[2]
        }
        
        // Extrai valor total
        val totalRegex = Regex("(VALOR TOTAL|TOTAL)[:\\s]*(R\\$)?[\\s]*([\\d\\.,]+)")
        val totalMatch = totalRegex.find(text)
        if (totalMatch != null) {
            info["total"] = totalMatch.groupValues[3]
        }
        
        // Extrai CNPJ emitente
        val cnpjRegex = Regex("(CNPJ)[:\\s]*(\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2})")
        val cnpjMatch = cnpjRegex.find(text)
        if (cnpjMatch != null) {
            info["cnpj"] = cnpjMatch.groupValues[2]
        }
        
        return info
    }
    
    /**
     * Extrai informações de um manifesto de carga
     */
    private fun extractCargoManifestInfo(text: String): Map<String, String> {
        val info = mutableMapOf<String, String>()
        
        // Extrai número do manifesto
        val manifestRegex = Regex("(MANIFESTO|MDF-e)[:\\s]*(\\d+)")
        val manifestMatch = manifestRegex.find(text)
        if (manifestMatch != null) {
            info["manifest_number"] = manifestMatch.groupValues[2]
        }
        
        // Extrai data
        val dateRegex = Regex("(DATA|EMISSÃO|DATA DE EMISSÃO)[:\\s]*(\\d{2}/\\d{2}/\\d{4})")
        val dateMatch = dateRegex.find(text)
        if (dateMatch != null) {
            info["date"] = dateMatch.groupValues[2]
        }
        
        // Extrai origem
        val originRegex = Regex("(ORIGEM|LOCAL DE INÍCIO)[:\\s]*([\\w\\s]+)")
        val originMatch = originRegex.find(text)
        if (originMatch != null) {
            info["origin"] = originMatch.groupValues[2].trim()
        }
        
        // Extrai destino
        val destinationRegex = Regex("(DESTINO|LOCAL DE TÉRMINO)[:\\s]*([\\w\\s]+)")
        val destinationMatch = destinationRegex.find(text)
        if (destinationMatch != null) {
            info["destination"] = destinationMatch.groupValues[2].trim()
        }
        
        return info
    }
    
    /**
     * Extrai informações genéricas de um documento
     */
    private fun extractGenericInfo(text: String): Map<String, String> {
        val info = mutableMapOf<String, String>()
        
        // Extrai datas
        val dateRegex = Regex("\\d{2}/\\d{2}/\\d{4}")
        val dateMatches = dateRegex.findAll(text)
        if (dateMatches.any()) {
            info["dates"] = dateMatches.map { it.value }.joinToString(", ")
        }
        
        // Extrai valores monetários
        val valueRegex = Regex("R\\$\\s*([\\d\\.,]+)")
        val valueMatches = valueRegex.findAll(text)
        if (valueMatches.any()) {
            info["values"] = valueMatches.map { it.groupValues[1] }.joinToString(", ")
        }
        
        // Extrai possíveis números de documentos (CNPJs, CPFs)
        val docRegex = Regex("\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2}|\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}")
        val docMatches = docRegex.findAll(text)
        if (docMatches.any()) {
            info["documents"] = docMatches.map { it.value }.joinToString(", ")
        }
        
        return info
    }
    
    /**
     * Adiciona um item ao histórico de escaneamentos
     */
    private fun addToScanHistory(item: ScanHistoryItem) {
        val currentList = _scanHistory.value ?: emptyList()
        val newList = currentList.toMutableList().apply {
            add(0, item) // Adiciona no topo da lista
            
            // Mantém o limite máximo de 50 itens
            if (size > 50) {
                removeRange(50, size)
            }
        }
        _scanHistory.postValue(newList)
    }
    
    /**
     * Limpa o histórico de escaneamentos
     */
    fun clearScanHistory() {
        _scanHistory.postValue(emptyList())
    }
    
    /**
     * Marca um documento como sincronizado
     */
    suspend fun markDocumentAsSynced(documentId: String): Boolean = 
        withContext(dispatcher) {
            try {
                val document = documentDao.getById(documentId) ?: return@withContext false
                
                // Atualiza o documento
                val updatedDocument = document.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis()
                )
                
                // Salva no banco de dados
                documentDao.update(updatedDocument)
                
                return@withContext true
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao marcar documento como sincronizado: ${e.message}", e)
                return@withContext false
            }
        }
    
    /**
     * Obtém documentos não sincronizados
     * 
     * @return Lista de documentos não sincronizados
     */
    suspend fun getUnsyncedDocuments(): List<Document> = 
        withContext(dispatcher) {
            return@withContext documentDao.getUnsyncedDocuments()
        }
    
    /**
     * Busca documentos com base em um texto contido no texto extraído
     * 
     * @param searchText Texto a ser buscado
     * @return Lista de documentos que contêm o texto
     */
    suspend fun searchDocumentsByContent(searchText: String): List<Document> = 
        withContext(dispatcher) {
            return@withContext documentDao.searchByContent("%$searchText%")
        }
    
    /**
     * Recicla recursos quando o componente é destruído
     */
    fun shutdown() {
        textRecognizer.close()
    }
    
    /**
     * Classe que representa um item no histórico de escaneamentos
     */
    data class ScanHistoryItem(
        val id: String,
        val type: String,
        val fileName: String,
        val timestamp: Long,
        val tripId: String? = null,
        val deliveryId: String? = null
    )
    
    /**
     * Estados possíveis do scanner
     */
    sealed class ScannerState {
        object Idle : ScannerState()
        object Scanning : ScannerState()
        data class Success(val documentId: String) : ScannerState()
        data class Error(val message: String) : ScannerState()
    }
}