/**
 * i18n/locales/pt-BR.js
 * 
 * Recursos de tradução para Português (Brasil).
 * Este é o idioma padrão da aplicação e deve conter todas as chaves de tradução.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

const ptBR = {
  translation: {
    // Informações do aplicativo
    app: {
      name: 'KingRoad',
      welcome: 'Bem-vindo ao KingRoad',
      tagline: 'Seu assistente pessoal de viagem',
      version: 'Versão {{version}}',
      copyright: '© 2025 KingRoad. Todos os direitos reservados.'
    },
    
    // Autenticação
    auth: {
      login: 'Entrar',
      logout: 'Sair',
      register: 'Cadastrar',
      forgotPassword: 'Esqueceu a senha?',
      resetPassword: 'Redefinir senha',
      emailPlaceholder: 'E-mail',
      passwordPlaceholder: 'Senha',
      confirmPasswordPlaceholder: 'Confirmar senha',
      loginSuccess: 'Login realizado com sucesso!',
      loginError: 'Erro ao fazer login. Verifique suas credenciais.',
      logoutSuccess: 'Você saiu da sua conta.',
      passwordResetSent: 'Enviamos instruções para redefinir sua senha.',
      passwordsDontMatch: 'As senhas não conferem.',
      passwordRequirements: 'A senha deve ter pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas e números.'
    },
    
    // Navegação
    nav: {
      home: 'Início',
      profile: 'Perfil',
      settings: 'Configurações',
      trips: 'Viagens',
      explore: 'Explorar',
      help: 'Ajuda',
      about: 'Sobre'
    },
    
    // Perfil de usuário
    profile: {
      title: 'Meu Perfil',
      edit: 'Editar Perfil',
      save: 'Salvar Alterações',
      cancel: 'Cancelar',
      name: 'Nome',
      email: 'E-mail',
      phone: 'Telefone',
      address: 'Endereço',
      preferences: 'Preferências',
      changePassword: 'Alterar Senha',
      language: 'Idioma',
      theme: 'Tema',
      notifications: 'Notificações',
      deleteAccount: 'Excluir Conta',
      deleteAccountConfirm: 'Tem certeza que deseja excluir sua conta? Esta ação não pode ser desfeita.',
      profileUpdated: 'Perfil atualizado com sucesso!',
      profileUpdateError: 'Erro ao atualizar perfil.'
    },
    
    // Configurações
    settings: {
      title: 'Configurações',
      general: 'Geral',
      account: 'Conta',
      privacy: 'Privacidade',
      notifications: 'Notificações',
      appearance: 'Aparência',
      language: 'Idioma',
      region: 'Região',
      theme: {
        title: 'Tema',
        light: 'Claro',
        dark: 'Escuro',
        system: 'Sistema'
      },
      dataCurrency: 'Moeda',
      dataUsage: 'Uso de dados',
      wifiOnly: 'Apenas Wi-Fi',
      locationServices: 'Serviços de localização',
      resetSettings: 'Redefinir configurações',
      resetSettingsConfirm: 'Tem certeza que deseja redefinir todas as configurações?',
      settingsSaved: 'Configurações salvas!',
      settingsError: 'Erro ao salvar configurações.'
    },
    
    // Componentes comuns
    common: {
      ok: 'OK',
      cancel: 'Cancelar',
      save: 'Salvar',
      delete: 'Excluir',
      edit: 'Editar',
      add: 'Adicionar',
      remove: 'Remover',
      search: 'Buscar',
      filter: 'Filtrar',
      sort: 'Ordenar',
      loading: 'Carregando...',
      retry: 'Tentar novamente',
      error: 'Erro',
      success: 'Sucesso',
      warning: 'Aviso',
      info: 'Informação',
      yes: 'Sim',
      no: 'Não',
      back: 'Voltar',
      next: 'Próximo',
      finish: 'Finalizar',
      continue: 'Continuar',
      skip: 'Pular',
      done: 'Concluído',
      select: 'Selecionar',
      today: 'Hoje',
      yesterday: 'Ontem',
      tomorrow: 'Amanhã',
      confirm: 'Confirmar',
      apply: 'Aplicar',
      reset: 'Redefinir',
      close: 'Fechar',
      open: 'Abrir',
      show: 'Mostrar',
      hide: 'Ocultar',
      all: 'Todos',
      none: 'Nenhum',
      required: 'Obrigatório',
      optional: 'Opcional',
      more: 'Mais',
      less: 'Menos',
      details: 'Detalhes',
      upload: 'Enviar',
      download: 'Baixar',
      noResults: 'Nenhum resultado encontrado',
      noData: 'Nenhum dado disponível',
      emptyState: 'Não há nada aqui ainda',
      offline: 'Você está offline',
      online: 'Você está online',
      day: 'Dia',
      week: 'Semana',
      month: 'Mês',
      year: 'Ano'
    },
    
    // Mensagens de erro
    errors: {
      generic: 'Ocorreu um erro. Por favor, tente novamente.',
      connection: 'Erro de conexão. Verifique sua internet.',
      timeout: 'A solicitação expirou. Por favor, tente novamente.',
      unauthorized: 'Não autorizado. Faça login novamente.',
      notFound: 'Recurso não encontrado.',
      serverError: 'Erro no servidor. Tente novamente mais tarde.',
      validation: 'Verifique os dados informados.',
      requiredField: 'Campo obrigatório',
      invalidEmail: 'E-mail inválido',
      weakPassword: 'Senha muito fraca',
      accountExists: 'Esta conta já existe',
      uploadFailed: 'Falha no envio do arquivo',
      downloadFailed: 'Falha no download do arquivo',
      locationPermissionDenied: 'Permissão de localização negada',
      cameraPermissionDenied: 'Permissão de câmera negada',
      microphonePermissionDenied: 'Permissão de microfone negada',
      storagePermissionDenied: 'Permissão de armazenamento negada',
      networkError: 'Erro de rede',
      sessionExpired: 'Sessão expirada. Faça login novamente.'
    },
    
    // Componentes específicos
    components: {
      // LocationPicker
      locationPicker: {
        searchPlaceholder: 'Buscar endereço',
        currentLocationButton: 'Localização atual',
        confirmButton: 'Confirmar localização',
        permissionDeniedTitle: 'Permissão negada',
        permissionDeniedMessage: 'Permissão de localização negada. Por favor, habilite nas configurações do aplicativo.',
        locationErrorTitle: 'Erro de localização',
        locationErrorMessage: 'Não foi possível obter a localização atual',
        addressLabel: 'Endereço:',
        loadingLocation: 'Obtendo localização...',
        loadingAddress: 'Obtendo endereço...',
        noAddressFound: 'Endereço não encontrado',
        searchingAddresses: 'Buscando endereços...',
        noSearchResults: 'Nenhum resultado encontrado',
        latitudeLongitudeFormat: 'Lat: {{lat}}, Lng: {{lng}}',
        manualInputButton: 'Entrada manual',
        manualInputTitle: 'Inserir coordenadas',
        manualInputLatitude: 'Latitude',
        manualInputLongitude: 'Longitude',
        manualInputOk: 'OK',
        manualInputCancel: 'Cancelar',
        manualInputError: 'Coordenadas inválidas',
        standardMap: 'Padrão',
        satelliteMap: 'Satélite',
        hybridMap: 'Híbrido',
        terrainMap: 'Terreno'
      },
      
      // PhotoCapture
      photoCapture: {
        takePhoto: 'Tirar foto',
        selectFromGallery: 'Selecionar da galeria',
        cancel: 'Cancelar',
        retake: 'Tirar novamente',
        permissionDenied: 'Permissão de câmera negada',
        error: 'Erro ao capturar foto',
        processing: 'Processando...',
        rotateLeft: 'Girar à esquerda',
        rotateRight: 'Girar à direita',
        crop: 'Recortar',
        save: 'Salvar',
        preview: 'Pré-visualização',
        addCaption: 'Adicionar legenda',
        removePhoto: 'Remover foto'
      },
      
      // AudioRecorder
      audioRecorder: {
        record: 'Gravar',
        stop: 'Parar',
        play: 'Reproduzir',
        pause: 'Pausar',
        delete: 'Excluir',
        save: 'Salvar',
        permissionDenied: 'Permissão de microfone negada',
        recording: 'Gravando...',
        recordingComplete: 'Gravação concluída',
        errorRecording: 'Erro ao gravar áudio',
        errorPlaying: 'Erro ao reproduzir áudio',
        duration: 'Duração: {{duration}}',
        addNote: 'Adicionar nota',
        quality: {
          title: 'Qualidade',
          low: 'Baixa',
          medium: 'Média',
          high: 'Alta'
        }
      },
      
      // Formulários e validação
      forms: {
        required: 'Campo obrigatório',
        minLength: 'Mínimo de {{count}} caracteres',
        maxLength: 'Máximo de {{count}} caracteres',
        email: 'E-mail inválido',
        url: 'URL inválida',
        number: 'Deve ser um número',
        integer: 'Deve ser um número inteiro',
        alphanumeric: 'Apenas letras e números',
        password: 'Senha inválida',
        match: 'Os campos não conferem',
        date: 'Data inválida',
        phoneNumber: 'Número de telefone inválido',
        zipCode: 'CEP inválido',
        creditCard: 'Número de cartão de crédito inválido'
      }
    },
    
    // Funcionalidades de viagem
    trips: {
      title: 'Minhas Viagens',
      new: 'Nova Viagem',
      edit: 'Editar Viagem',
      delete: 'Excluir Viagem',
      details: 'Detalhes da Viagem',
      itinerary: 'Itinerário',
      expenses: 'Despesas',
      photos: 'Fotos',
      notes: 'Notas',
      map: 'Mapa',
      shareTrip: 'Compartilhar Viagem',
      exportTrip: 'Exportar Viagem',
      importTrip: 'Importar Viagem',
      deleteConfirm: 'Tem certeza que deseja excluir esta viagem?',
      noTrips: 'Você ainda não tem viagens',
      createFirstTrip: 'Crie sua primeira viagem',
      tripName: 'Nome da viagem',
      destination: 'Destino',
      startDate: 'Data de início',
      endDate: 'Data de fim',
      companions: 'Acompanhantes',
      status: {
        upcoming: 'Próxima',
        inProgress: 'Em andamento',
        completed: 'Concluída',
        cancelled: 'Cancelada'
      },
      transportType: {
        title: 'Meio de transporte',
        car: 'Carro',
        bus: 'Ônibus',
        train: 'Trem',
        airplane: 'Avião',
        boat: 'Barco',
        walking: 'A pé',
        bicycle: 'Bicicleta',
        other: 'Outro'
      },
      accommodation: {
        title: 'Hospedagem',
        hotel: 'Hotel',
        hostel: 'Hostel',
        apartment: 'Apartamento',
        house: 'Casa',
        camping: 'Camping',
        other: 'Outro'
      },
      budget: {
        title: 'Orçamento',
        estimated: 'Estimado',
        actual: 'Real',
        remaining: 'Restante',
        currency: 'Moeda',
        expenses: 'Despesas',
        income: 'Receitas',
        categories: {
          accommodation: 'Hospedagem',
          transportation: 'Transporte',
          food: 'Alimentação',
          activities: 'Atividades',
          shopping: 'Compras',
          other: 'Outros'
        }
      }
    },
    
    // Funcionalidades de sincronização
    sync: {
      title: 'Sincronização',
      lastSync: 'Última sincronização: {{time}}',
      syncing: 'Sincronizando...',
      syncComplete: 'Sincronização concluída',
      syncError: 'Erro de sincronização',
      syncSettings: 'Configurações de sincronização',
      autoSync: 'Sincronização automática',
      syncNow: 'Sincronizar agora',
      offlineChanges: 'Alterações offline',
      uploadingData: 'Enviando dados...',
      downloadingData: 'Baixando dados...',
      conflictResolution: {
        title: 'Resolução de conflitos',
        local: 'Manter versão local',
        remote: 'Manter versão remota',
        manual: 'Resolver manualmente'
      }
    },
    
    // Funcionalidades de idioma e região
    locale: {
      title: 'Idioma e Região',
      language: 'Idioma',
      region: 'Região',
      dateFormat: 'Formato de data',
      timeFormat: 'Formato de hora',
      timezone: 'Fuso horário',
      currency: 'Moeda',
      measurementSystem: 'Sistema de medidas',
      decimal: 'Separador decimal',
      thousands: 'Separador de milhares',
      firstDayOfWeek: 'Primeiro dia da semana',
      applyChanges: 'Aplicar alterações',
      systemDefault: 'Padrão do sistema'
    }
  },
  
  // Metadados do idioma
  metadata: {
    name: 'Português (Brasil)',
    nameEnglish: 'Portuguese (Brazil)',
    isRTL: false,
    momentLocale: 'pt-br',
    dateFormat: {
      short: 'DD/MM/YYYY',
      medium: 'D [de] MMM [de] YYYY',
      long: 'D [de] MMMM [de] YYYY',
      full: 'dddd, D [de] MMMM [de] YYYY'
    },
    timeFormat: {
      short: 'HH:mm',
      medium: 'HH:mm:ss',
      long: 'HH:mm:ss z',
      full: 'HH:mm:ss zzzz'
    },
    currency: {
      code: 'BRL',
      symbol: 'R$',
      format: '{symbol} {amount}',
      decimal: ',',
      thousand: '.'
    },
    country: 'BR',
    numberFormat: {
      decimal: ',',
      thousand: '.',
      precision: 2
    },
    units: {
      system: 'metric',
      temperature: 'celsius',
      distance: {
        short: 'm',
        long: 'metro',
        plural: 'metros'
      },
      speed: 'km/h',
      weight: 'kg'
    }
  }
};

export default ptBR;