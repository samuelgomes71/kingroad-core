import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { AlertCircle, Scissors, Wind, TrendingDown } from 'lucide-react';

const SecurityStatisticsDashboard = () => {
  const [securityData, setSecurityData] = useState({
    loading: true,
    alertsByType: [],
    alertsByMonth: [],
    alertsByRegion: [],
    totalAlerts: 0,
    highRiskAreas: []
  });
  
  // Cores para os diferentes tipos de alertas
  const alertColors = {
    'CARGO_THEFT': '#EF4444',     // Vermelho
    'CURTAIN_CUT': '#F59E0B',     // Âmbar
    'GAS_ATTACK': '#8B5CF6',      // Roxo
    'BRAKE_FAILURE': '#DC2626'    // Vermelho escuro
  };
  
  useEffect(() => {
    // Esta seria uma chamada real à API
    const fetchSecurityData = async () => {
      try {
        // Simulando dados para demonstração
        const mockData = {
          alertsByType: [
            { name: 'Roubo de Carga', value: 245, type: 'CARGO_THEFT' },
            { name: 'Corte de Lona', value: 187, type: 'CURTAIN_CUT' },
            { name: 'Ataque com Gás', value: 94, type: 'GAS_ATTACK' },
            { name: 'Caminhão sem Freio', value: 63, type: 'BRAKE_FAILURE' }
          ],
          alertsByMonth: [
            { name: 'Jan', cargoTheft: 15, curtainCut: 12, gasAttack: 7, brakeFail: 4 },
            { name: 'Fev', cargoTheft: 20, curtainCut: 14, gasAttack: 10, brakeFail: 5 },
            { name: 'Mar', cargoTheft: 35, curtainCut: 25, gasAttack: 12, brakeFail: 6 },
            { name: 'Abr', cargoTheft: 28, curtainCut: 22, gasAttack: 9, brakeFail: 8 },
            { name: 'Mai', cargoTheft: 22, curtainCut: 18, gasAttack: 8, brakeFail: 7 },
            { name: 'Jun', cargoTheft: 25, curtainCut: 19, gasAttack: 7, brakeFail: 6 }
          ],
          alertsByRegion: [
            { name: 'Sudeste', value: 297 },
            { name: 'Sul', value: 142 },
            { name: 'Nordeste', value: 87 },
            { name: 'Centro-Oeste', value: 45 },
            { name: 'Norte', value: 18 }
          ],
          highRiskAreas: [
            { name: 'BR-116, km 40 - Região de Duque de Caxias', incidents: 28, type: 'CARGO_THEFT' },
            { name: 'BR-381, Serra do Tigre - MG', incidents: 24, type: 'BRAKE_FAILURE' },
            { name: 'BR-116, Serra das Araras - RJ', incidents: 22, type: 'BRAKE_FAILURE' },
            { name: 'BR-101, Região dos Lagos - RJ', incidents: 19, type: 'CARGO_THEFT' },
            { name: 'BR-050, Triângulo Mineiro', incidents: 17, type: 'CURTAIN_CUT' }
          ]
        };
        
        setSecurityData({
          ...mockData,
          totalAlerts: mockData.alertsByType.reduce((sum, item) => sum + item.value, 0),
          loading: false
        });
      } catch (error) {
        console.error('Erro ao carregar estatísticas de segurança:', error);
        setSecurityData(prev => ({ ...prev, loading: false }));
      }
    };
    
    fetchSecurityData();
  }, []);
  
  // Componentes para estatísticas específicas
  const AlertTypeIcon = ({ type }) => {
    switch (type) {
      case 'CARGO_THEFT':
        return <AlertCircle size={16} className="text-red-500" />;
      case 'CURTAIN_CUT':
        return <Scissors size={16} className="text-amber-500" />;
      case 'GAS_ATTACK':
        return <Wind size={16} className="text-purple-500" />;
      case 'BRAKE_FAILURE':
        return <TrendingDown size={16} className="text-red-700" />;
      default:
        return <AlertCircle size={16} />;
    }
  };
  
  if (securityData.loading) {
    return <div className="p-4 text-center">Carregando estatísticas de segurança...</div>;
  }
  
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {securityData.alertsByType.map((item) => (
          <Card key={item.type} className="shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">{item.name}</CardTitle>
              <AlertTypeIcon type={item.type} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: alertColors[item.type] }}>
                {item.value}
              </div>
              <p className="text-xs text-gray-500">
                {Math.round((item.value / securityData.totalAlerts) * 100)}% do total
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Alertas por Mês</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={securityData.alertsByMonth}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="cargoTheft" 
                  name="Roubo de Carga"
                  stroke={alertColors.CARGO_THEFT} 
                  activeDot={{ r: 8 }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="curtainCut" 
                  name="Corte de Lona"
                  stroke={alertColors.CURTAIN_CUT} 
                />
                <Line 
                  type="monotone" 
                  dataKey="gasAttack" 
                  name="Ataque com Gás"
                  stroke={alertColors.GAS_ATTACK} 
                />
                <Line 
                  type="monotone" 
                  dataKey="brakeFail" 
                  name="Sem Freio"
                  stroke={alertColors.BRAKE_FAILURE} 
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Distribuição por Região</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={securityData.alertsByRegion}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {securityData.alertsByRegion.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={`hsl(${index * 45}, 70%, 50%)`} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Áreas de Alto Risco</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="py-2 px-4 text-left">Localização</th>
                  <th className="py-2 px-4 text-center">Incidentes</th>
                  <th className="py-2 px-4 text-center">Tipo Principal</th>
                </tr>
              </thead>
              <tbody>
                {securityData.highRiskAreas.map((area, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">{area.name}</td>
                    <td className="py-3 px-4 text-center font-medium">{area.incidents}</td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <AlertTypeIcon type={area.type} />
                        <span>
                          {area.type === 'CARGO_THEFT' && 'Roubo de Carga'}
                          {area.type === 'CURTAIN_CUT' && 'Corte de Lona'}
                          {area.type === 'GAS_ATTACK' && 'Ataque com Gás'}
                          {area.type === 'BRAKE_FAILURE' && 'Sem Freio'}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityStatisticsDashboard;