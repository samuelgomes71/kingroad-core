package com.kingroad.cache

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.kingroad.database.MapRegionDao
import com.kingroad.utils.BitmapUtils
import kotlinx.coroutines.*
import org.osmdroid.tileprovider.IRegisterReceiver
import org.osmdroid.tileprovider.MapTileRequestState
import org.osmdroid.tileprovider.modules.IFilesystemCache
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.util.MapTile
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.concurrent.atomic.AtomicReference

/**
 * Implementa o provedor de tiles customizado para o MapView, renderizando mapas
 * offline a partir dos dados baixados com o OfflineMapCacheManager.
 */
class OfflineTileProvider(
    private val context: Context,
    private val mapRegionDao: MapRegionDao,
    private val offlineMapCacheManager: OfflineMapCacheManager,
    pRegisterReceiver: IRegisterReceiver?,
    private val filesystemCache: IFilesystemCache? = null,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) : MapTileModuleProviderBase(
    MIN_ZOOM_LEVEL,
    MAX_ZOOM_LEVEL,
    TILE_EXPIRY_TIME_MILLISECONDS,
    pRegisterReceiver
) {
    companion object {
        private const val TAG = "OfflineTileProvider"
        
        // Constantes para configuração dos tiles
        private const val MIN_ZOOM_LEVEL = 0
        private const val MAX_ZOOM_LEVEL = 22
        private const val TILE_EXPIRY_TIME_MILLISECONDS = (1000 * 60 * 60 * 24 * 7).toLong() // 1 semana
        
        // Formato de tiles suportados
        private val SUPPORTED_FORMATS = arrayOf("png", "jpg", "jpeg", "webp")
        
        // Modo de fallback - como lidar com tiles que não existem
        enum class FallbackMode {
            ONLINE, // Tenta online se não encontrar offline
            LOWER_ZOOM, // Tenta um zoom menor se não encontrar exato
            ERROR_TILE, // Mostra um tile de erro
            PLACEHOLDER // Mostra um placeholder
        }
    }

    // Referência à fonte de tiles atual
    private val tileSource = AtomicReference<ITileSource?>(null)
    
    // Configurações de fallback
    private var fallbackMode = FallbackMode.LOWER_ZOOM
    
    // Bitmap para placeholder/erro
    private var errorTileBitmap: Bitmap? = null
    
    /**
     * Define o modo de fallback para quando tiles não são encontrados
     */
    fun setFallbackMode(mode: FallbackMode) {
        fallbackMode = mode
        Log.d(TAG, "Modo de fallback definido para: $mode")
    }
    
    /**
     * Define um bitmap personalizado para mostrar quando um tile não é encontrado
     */
    fun setErrorTileBitmap(bitmap: Bitmap) {
        errorTileBitmap = bitmap
    }

    /**
     * Define a fonte de tiles atual
     * @param tileSource A fonte de tiles a ser usada
     */
    fun setTileSource(tileSource: ITileSource?) {
        this.tileSource.set(tileSource)
    }
    
    /**
     * Obtém a fonte de tiles atual
     * @return A fonte de tiles atual
     */
    fun getTileSource(): ITileSource? {
        return tileSource.get()
    }
    
    /**
     * Verifica se o provedor tem os tiles para uma determinada região
     * @param tile Tile a ser verificado
     * @return true se o provedor tem os tiles para a região
     */
    override fun getUsesDataConnection(): Boolean {
        return fallbackMode == FallbackMode.ONLINE
    }
    
    /**
     * Obtém o nome do provedor
     * @return Nome do provedor
     */
    override fun getName(): String {
        return "OfflineTileProvider"
    }
    
    /**
     * Método principal que carrega os tiles
     * @param pState Estado da requisição de tile
     * @return Resultado do carregamento
     */
    override fun loadTile(pState: MapTileRequestState?): Drawable {
        if (pState == null) {
            return null
        }
        
        val tile = pState.mapTile
        val currentSource = tileSource.get()
        
        // Verifica se temos uma fonte de tiles válida
        if (currentSource == null) {
            Log.d(TAG, "Fonte de tiles não definida")
            return null
        }
        
        // Tentativa de carregamento do tile offline
        try {
            var tileStream: InputStream? = null
            var tileFile: File? = null
            
            // Lança uma coroutine para buscar o caminho do tile
            val tilePath = runBlocking {
                offlineMapCacheManager.getTilePath(
                    tile.zoomLevel,
                    tile.x,
                    tile.y
                )
            }
            
            if (tilePath != null) {
                tileFile = File(tilePath)
                
                if (tileFile.exists()) {
                    tileStream = FileInputStream(tileFile)
                    
                    // Carrega o bitmap do arquivo
                    val bitmap = BitmapFactory.decodeStream(tileStream)
                    if (bitmap != null) {
                        // Converte o bitmap em um drawable com métrica de densidade correta
                        val drawable = BitmapUtils.bitmapToDrawable(context, bitmap)
                        
                        // Adiciona o tile ao cache se o cache estiver disponível
                        if (filesystemCache != null && fallbackMode == FallbackMode.ONLINE && 
                            currentSource != null) {
                            filesystemCache.saveFile(currentSource, tile, tileStream)
                        }
                        
                        return drawable
                    }
                }
            }
            
            // Se não encontrou o tile diretamente, tenta estratégias de fallback
            return handleFallbackStrategies(pState, tile)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar tile: ${e.message}", e)
            return null
        }
    }
    
    /**
     * Implementa estratégias de fallback quando um tile não é encontrado
     */
    private fun handleFallbackStrategies(pState: MapTileRequestState, tile: MapTile): Drawable? {
        when (fallbackMode) {
            FallbackMode.LOWER_ZOOM -> {
                return tryLowerZoomLevel(pState, tile)
            }
            FallbackMode.ERROR_TILE, FallbackMode.PLACEHOLDER -> {
                return getErrorTileDrawable()
            }
            FallbackMode.ONLINE -> {
                // Não faz nada aqui, pois o retorno null fará com que o próximo
                // provedor na cadeia (online) seja chamado
                return null
            }
        }
    }
    
    /**
     * Tenta encontrar tiles em níveis de zoom inferiores quando o zoom exato não está disponível
     */
    private fun tryLowerZoomLevel(pState: MapTileRequestState, originalTile: MapTile): Drawable? {
        // Tenta encontrar em níveis inferiores de zoom (até 3 níveis abaixo)
        val maxLevelDiff = 3
        
        for (levelDiff in 1..maxLevelDiff) {
            val lowerZoom = originalTile.zoomLevel - levelDiff
            
            if (lowerZoom < MIN_ZOOM_LEVEL) {
                continue
            }
            
            // Calcula as coordenadas para o nível de zoom inferior
            val factor = 1 shl levelDiff
            val lowerX = originalTile.x / factor
            val lowerY = originalTile.y / factor
            
            val lowerTile = MapTile(lowerZoom, lowerX, lowerY)
            
            // Tenta carregar o tile de zoom inferior
            val tilePath = runBlocking {
                offlineMapCacheManager.getTilePath(
                    lowerTile.zoomLevel,
                    lowerTile.x,
                    lowerTile.y
                )
            }
            
            if (tilePath != null) {
                val tileFile = File(tilePath)
                
                if (tileFile.exists()) {
                    try {
                        val inputStream = FileInputStream(tileFile)
                        val fullBitmap = BitmapFactory.decodeStream(inputStream)
                        inputStream.close()
                        
                        if (fullBitmap != null) {
                            // Agora precisamos extrair a parte específica do tile
                            val modX = (originalTile.x % factor)
                            val modY = (originalTile.y % factor)
                            
                            // Calcula as coordenadas na imagem
                            val tileSize = 256 // Tamanho padrão de tiles
                            val subRectX = (modX * tileSize) / factor
                            val subRectY = (modY * tileSize) / factor
                            val subRectWidth = tileSize / factor
                            val subRectHeight = tileSize / factor
                            
                            // Extrai a parte específica e redimensiona para tamanho padrão
                            val subBitmap = Bitmap.createBitmap(
                                fullBitmap,
                                subRectX, subRectY,
                                subRectWidth, subRectHeight
                            )
                            
                            val scaledBitmap = Bitmap.createScaledBitmap(
                                subBitmap,
                                tileSize, tileSize,
                                true
                            )
                            
                            // Limpa os bitmaps intermediários
                            if (subBitmap != scaledBitmap) {
                                subBitmap.recycle()
                            }
                            fullBitmap.recycle()
                            
                            return BitmapUtils.bitmapToDrawable(context, scaledBitmap)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro ao processar zoom inferior: ${e.message}", e)
                    }
                }
            }
        }
        
        // Fallback final: retorna um tile de erro
        return getErrorTileDrawable()
    }
    
    /**
     * Retorna um drawable para usar quando um tile não é encontrado
     */
    private fun getErrorTileDrawable(): Drawable? {
        if (errorTileBitmap != null) {
            return BitmapUtils.bitmapToDrawable(context, errorTileBitmap!!)
        }
        
        // Se não tiver um bitmap de erro definido, cria um padrão
        val tileSize = 256
        val defaultErrorBitmap = Bitmap.createBitmap(tileSize, tileSize, Bitmap.Config.ARGB_8888)
        defaultErrorBitmap.eraseColor(0x11000000) // Cinza semitransparente
        
        return BitmapUtils.bitmapToDrawable(context, defaultErrorBitmap)
    }
    
    /**
     * Libera recursos quando o provedor é finalizado
     */
    override fun detach() {
        super.detach()
        coroutineScope.cancel()
        errorTileBitmap?.recycle()
        errorTileBitmap = null
    }
    
    /**
     * Builder para facilitar a criação de instâncias de OfflineTileProvider
     */
    class Builder(private val context: Context) {
        private var mapRegionDao: MapRegionDao? = null
        private var offlineMapCacheManager: OfflineMapCacheManager? = null
        private var registerReceiver: IRegisterReceiver? = null
        private var filesystemCache: IFilesystemCache? = null
        private var fallbackMode = FallbackMode.LOWER_ZOOM
        private var errorTileBitmap: Bitmap? = null
        
        fun setMapRegionDao(dao: MapRegionDao): Builder {
            this.mapRegionDao = dao
            return this
        }
        
        fun setOfflineMapCacheManager(manager: OfflineMapCacheManager): Builder {
            this.offlineMapCacheManager = manager
            return this
        }
        
        fun setRegisterReceiver(receiver: IRegisterReceiver): Builder {
            this.registerReceiver = receiver
            return this
        }
        
        fun setFilesystemCache(cache: IFilesystemCache): Builder {
            this.filesystemCache = cache
            return this
        }
        
        fun setFallbackMode(mode: FallbackMode): Builder {
            this.fallbackMode = mode
            return this
        }
        
        fun setErrorTileBitmap(bitmap: Bitmap): Builder {
            this.errorTileBitmap = bitmap
            return this
        }
        
        fun build(): OfflineTileProvider {
            if (mapRegionDao == null) {
                throw IllegalStateException("MapRegionDao deve ser fornecido")
            }
            
            if (offlineMapCacheManager == null) {
                throw IllegalStateException("OfflineMapCacheManager deve ser fornecido")
            }
            
            val provider = OfflineTileProvider(
                context,
                mapRegionDao!!,
                offlineMapCacheManager!!,
                registerReceiver,
                filesystemCache
            )
            
            provider.setFallbackMode(fallbackMode)
            if (errorTileBitmap != null) {
                provider.setErrorTileBitmap(errorTileBitmap!!)
            }
            
            return provider
        }
    }
}