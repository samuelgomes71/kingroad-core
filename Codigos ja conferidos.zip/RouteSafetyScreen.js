/**
 * RouteSafetyScreen.js
 * 
 * Tela de análise de segurança de rotas
 * Exibe informações de segurança, alertas e estatísticas de uma rota
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Polyline, Marker } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import RouteService from '../services/RouteService';
import SafetyService from '../services/SafetyService';
import { useTheme } from '../contexts/ThemeContext';

const RouteSafetyScreen = ({ route, navigation }) => {
  const { routeId } = route.params;
  const { theme } = useTheme();
  const [routeData, setRouteData] = useState(null);
  const [safetyData, setSafetyData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSegment, setSelectedSegment] = useState(null);
  
  useEffect(() => {
    loadRouteData();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma para atualizar formatações
      loadRouteData();
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, [routeId]);

  const loadRouteData = async () => {
    try {
      setLoading(true);
      
      // Carrega dados da rota
      const route = await RouteService.getRouteById(routeId);
      setRouteData(route);
      
      // Carrega dados de segurança
      const safety = await SafetyService.getRouteSafetyAnalysis(routeId);
      setSafetyData(safety);
      
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar dados da rota:', error);
      setLoading(false);
      
      Alert.alert(
        t('alert.error'),
        t('error.load_route_data'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const getSafetyColor = (score) => {
    if (score >= 80) return theme.safetyGood;
    if (score >= 50) return theme.safetyModerate;
    return theme.safetyRisk;
  };

  const getSafetyLevel = (score) => {
    if (score >= 80) return t('screen.route_safety.level_safe');
    if (score >= 50) return t('screen.route_safety.level_moderate');
    return t('screen.route_safety.level_unsafe');
  };

  const handleSegmentPress = (segment) => {
    setSelectedSegment(segment);
  };

  const handleSaveReport = async () => {
    try {
      await SafetyService.saveRouteSafetyReport(routeId);
      Alert.alert(
        t('alert.success'),
        t('success.safety_report_saved'),
        [{ text: t('button.ok') }]
      );
    } catch (error) {
      console.error('Erro ao salvar relatório:', error);
      Alert.alert(
        t('alert.error'),
        t('error.save_report_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const handleShareReport = () => {
    Alert.alert(
      t('alert.coming_soon'),
      t('alert.share_feature_coming_soon'),
      [{ text: t('button.ok') }]
    );
  };

  const handleSuggestions = () => {
    navigation.navigate('RouteSuggestions', { routeId });
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[styles.loadingText, { color: theme.text }]}>
          {t('screen.route_safety.loading')}
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Cabeçalho com informações da rota */}
        <View style={styles.header}>
          <Text style={[styles.routeName, { color: theme.text }]}>
            {routeData?.name || t('screen.route_safety.unnamed_route')}
          </Text>
          <Text style={[styles.routeDetails, { color: theme.textSecondary }]}>
            {RegionalSettingsService.formatDistance(routeData?.distance || 0)} • 
            {routeData?.duration ? ` ${Math.ceil(routeData.duration / 60)} ${t('screen.route_safety.minutes')}` : ''}
          </Text>
        </View>

        {/* Mapa da rota com marcações de segurança */}
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: routeData?.coordinates[0]?.latitude || 0,
              longitude: routeData?.coordinates[0]?.longitude || 0,
              latitudeDelta: 0.05,
              longitudeDelta: 0.05,
            }}
            scrollEnabled={false}
            zoomEnabled={false}
          >
            {routeData?.coordinates?.length > 0 && (
              <Polyline
                coordinates={routeData.coordinates}
                strokeWidth={4}
                strokeColor={theme.primary}
              />
            )}
            
            {safetyData?.hazardPoints?.map((point, index) => (
              <Marker
                key={`hazard-${index}`}
                coordinate={{
                  latitude: point.latitude,
                  longitude: point.longitude,
                }}
                title={t(`hazard_type.${point.type}`)}
                description={point.description}
              >
                <Icon name="warning" size={24} color={theme.warning} />
              </Marker>
            ))}
          </MapView>
          
          <TouchableOpacity 
            style={[styles.fullMapButton, { backgroundColor: theme.primary }]}
            onPress={() => navigation.navigate('RouteMap', { routeId })}
          >
            <Text style={styles.fullMapButtonText}>
              {t('button.view_full_map')}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Resumo de segurança */}
        <View style={[styles.safetyScoreContainer, { backgroundColor: theme.card }]}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.route_safety.safety_score')}
          </Text>
          
          <View style={styles.scoreRow}>
            <View style={styles.scoreCircle}>
              <Text style={styles.scoreText}>
                {safetyData?.overallScore || 0}
              </Text>
              <Text style={styles.scoreLabel}>
                {t('screen.route_safety.out_of_100')}
              </Text>
            </View>
            
            <View style={styles.scoreDetails}>
              <Text style={[styles.safetyLevelText, { color: getSafetyColor(safetyData?.overallScore || 0) }]}>
                {getSafetyLevel(safetyData?.overallScore || 0)}
              </Text>
              <Text style={[styles.safetyDescription, { color: theme.textSecondary }]}>
                {safetyData?.summary || t('screen.route_safety.no_summary_available')}
              </Text>
            </View>
          </View>
        </View>

        {/* Fatores de segurança */}
        <View style={[styles.section, { backgroundColor: theme.card }]}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.route_safety.safety_factors')}
          </Text>
          
          {safetyData?.factors?.map((factor, index) => (
            <View key={`factor-${index}`} style={styles.factorItem}>
              <Icon name={factor.icon || 'info'} size={24} color={theme.primary} />
              <View style={styles.factorDetails}>
                <Text style={[styles.factorName, { color: theme.text }]}>
                  {t(`safety_factor.${factor.type}`)}
                </Text>
                <Text style={[styles.factorDescription, { color: theme.textSecondary }]}>
                  {factor.description}
                </Text>
              </View>
              <View style={styles.factorScore}>
                <Text style={[styles.factorScoreText, { color: getSafetyColor(factor.score) }]}>
                  {factor.score}/100
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Segmentos da rota */}
        {safetyData?.segments?.length > 0 && (
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.route_safety.route_segments')}
            </Text>
            
            {safetyData.segments.map((segment, index) => (
              <TouchableOpacity
                key={`segment-${index}`}
                style={[
                  styles.segmentItem,
                  selectedSegment?.id === segment.id && { backgroundColor: theme.highlight }
                ]}
                onPress={() => handleSegmentPress(segment)}
              >
                <LinearGradient
                  colors={['transparent', getSafetyColor(segment.safetyScore)]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.segmentGradient}
                />
                <View style={styles.segmentDetails}>
                  <Text style={[styles.segmentName, { color: theme.text }]}>
                    {segment.name || t('screen.route_safety.segment', { number: index + 1 })}
                  </Text>
                  <Text style={[styles.segmentDescription, { color: theme.textSecondary }]}>
                    {RegionalSettingsService.formatDistance(segment.distance)} • 
                    {segment.hazardCount > 0 
                      ? ` ${segment.hazardCount} ${t('screen.route_safety.hazards')}`
                      : ` ${t('screen.route_safety.no_hazards')}`
                    }
                  </Text>
                </View>
                <Text style={[styles.segmentScore, { color: getSafetyColor(segment.safetyScore) }]}>
                  {segment.safetyScore}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Detalhes do segmento selecionado */}
        {selectedSegment && (
          <View style={[styles.section, { backgroundColor: theme.card }]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('screen.route_safety.segment_details')}
            </Text>
            
            <View style={styles.segmentDetailsContent}>
              <Text style={[styles.segmentDetailTitle, { color: theme.text }]}>
                {selectedSegment.name || t('screen.route_safety.segment_title')}
              </Text>
              
              <Text style={[styles.segmentDetailDescription, { color: theme.textSecondary }]}>
                {selectedSegment.description || t('screen.route_safety.no_details')}
              </Text>
              
              {selectedSegment.hazards?.map((hazard, index) => (
                <View key={`hazard-${index}`} style={styles.hazardItem}>
                  <Icon name="warning" size={20} color={theme.warning} />
                  <Text style={[styles.hazardText, { color: theme.text }]}>
                    {t(`hazard_type.${hazard.type}`)}: {hazard.description}
                  </Text>
                </View>
              ))}
              
              <TouchableOpacity 
                style={[styles.segmentActionButton, { backgroundColor: theme.primaryLight }]}
                onPress={() => navigation.navigate('SegmentDetails', { segmentId: selectedSegment.id })}
              >
                <Text style={[styles.segmentActionButtonText, { color: theme.primary }]}>
                  {t('button.view_details')}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Botões de ação */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primary }]}
            onPress={handleSaveReport}
          >
            <Icon name="save" size={20} color="white" />
            <Text style={styles.actionButtonText}>
              {t('button.save_report')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.secondary }]}
            onPress={handleShareReport}
          >
            <Icon name="share" size={20} color="white" />
            <Text style={styles.actionButtonText}>
              {t('button.share')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.accent }]}
            onPress={handleSuggestions}
          >
            <Icon name="lightbulb" size={20} color="white" />
            <Text style={styles.actionButtonText}>
              {t('button.suggestions')}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
  },
  header: {
    marginBottom: 16,
  },
  routeName: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  routeDetails: {
    fontSize: 14,
    marginTop: 4,
  },
  mapContainer: {
    height: 200,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    position: 'relative',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  fullMapButton: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  fullMapButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  safetyScoreContainer: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  scoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scoreCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  scoreText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  scoreLabel: {
    fontSize: 10,
    color: '#666',
  },
  scoreDetails: {
    flex: 1,
  },
  safetyLevelText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  safetyDescription: {
    fontSize: 14,
    lineHeight: 20,
  },
  section: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  factorItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  factorDetails: {
    flex: 1,
    marginLeft: 12,
  },
  factorName: {
    fontSize: 16,
    fontWeight: '500',
  },
  factorDescription: {
    fontSize: 12,
    marginTop: 4,
  },
  factorScore: {
    marginLeft: 8,
  },
  factorScoreText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  segmentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    position: 'relative',
  },
  segmentGradient: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
  },
  segmentDetails: {
    flex: 1,
    marginLeft: 8,
  },
  segmentName: {
    fontSize: 16,
    fontWeight: '500',
  },
  segmentDescription: {
    fontSize: 12,
    marginTop: 4,
  },
  segmentScore: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  segmentDetailsContent: {
    padding: 8,
  },
  segmentDetailTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  segmentDetailDescription: {
    fontSize: 14,
    marginBottom: 12,
    lineHeight: 20,
  },
  hazardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#fff9e6',
    borderRadius: 8,
  },
  hazardText: {
    marginLeft: 8,
    fontSize: 14,
  },
  segmentActionButton: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 12,
  },
  segmentActionButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 4,
  },
  actionButtonText: {
    color: 'white',
    marginLeft: 6,
    fontSize: 14,
    fontWeight: '500',
  },
});

export default RouteSafetyScreen;