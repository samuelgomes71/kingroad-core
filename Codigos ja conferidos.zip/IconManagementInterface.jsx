import React, { useState } from 'react';
import { Upload, Folder, Image, Settings, Plus, Edit, Trash } from 'lucide-react';

const IconManagementInterface = () => {
  const [selectedCategory, setSelectedCategory] = useState('TRUCK_STOP');
  const [selectedIcon, setSelectedIcon] = useState(null);
  
  return (
    <div className="h-screen bg-gray-100">
      {/* Barra superior */}
      <div className="bg-blue-700 p-4">
        <h1 className="text-white text-xl font-bold">Gerenciamento de Ícones</h1>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        {/* Categorias */}
        <div className="w-64 bg-white border-r">
          <div className="p-4">
            <button className="w-full bg-blue-600 text-white p-2 rounded-lg flex items-center justify-center">
              <Plus size={20} className="mr-2" />
              Novo Ícone
            </button>
          </div>

          <div className="p-4 space-y-2">
            <button
              onClick={() => setSelectedCategory('TRUCK_STOP')}
              className={`w-full p-2 rounded-lg flex items-center ${
                selectedCategory === 'TRUCK_STOP' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Folder size={20} className="mr-2" />
              Truck Stops
            </button>

            <button
              onClick={() => setSelectedCategory('FUEL_BRAND')}
              className={`w-full p-2 rounded-lg flex items-center ${
                selectedCategory === 'FUEL_BRAND' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Folder size={20} className="mr-2" />
              Marcas de Combustível
            </button>

            <button
              onClick={() => setSelectedCategory('MENU')}
              className={`w-full p-2 rounded-lg flex items-center ${
                selectedCategory === 'MENU' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Folder size={20} className="mr-2" />
              Menu
            </button>

            <button
              onClick={() => setSelectedCategory('CUSTOM')}
              className={`w-full p-2 rounded-lg flex items-center ${
                selectedCategory === 'CUSTOM' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Folder size={20} className="mr-2" />
              Personalizados
            </button>
          </div>
        </div>

        {/* Grade de ícones */}
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="grid grid-cols-4 gap-4">
            {/* Exemplo de cartão de ícone */}
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                <Image size={48} className="text-gray-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Flying J</span>
                <div className="flex space-x-2">
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <Edit size={16} className="text-gray-600" />
                  </button>
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <Trash size={16} className="text-gray-600" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Painel de detalhes */}
        {selectedIcon && (
          <div className="w-80 bg-white border-l p-4">
            <h3 className="text-lg font-bold mb-4">Detalhes do Ícone</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nome</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded-lg"
                  value={selectedIcon.name}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Categoria</label>
                <select className="w-full p-2 border rounded-lg">
                  <option value="TRUCK_STOP">Truck Stop</option>
                  <option value="FUEL_BRAND">Marca de Combustível</option>
                  <option value="MENU">Menu</option>
                  <option value="CUSTOM">Personalizado</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Visualização</label>
                <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                  <Image size={64} className="text-gray-400" />
                </div>
              </div>

              <div className="flex space-x-2">
                <button className="flex-1 p-2 bg-blue-600 text-white rounded-lg">
                  Salvar
                </button>
                <button className="flex-1 p-2 border border-gray-300 rounded-lg">
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IconManagementInterface;