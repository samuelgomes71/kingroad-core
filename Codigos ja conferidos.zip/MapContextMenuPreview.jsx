import React, { useState, useEffect, useRef } from 'react';
import { Truck, Car, Star, Ban, MapPin, Navigation, Flag, AlertTriangle, X, Settings, Clock, TrendingUp } from 'lucide-react';

const MapContextMenuPreview = () => {
  // Estados
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const [routeStatus, setRouteStatus] = useState('idle'); // 'idle', 'planned', 'active'
  const [vehicleMode, setVehicleMode] = useState('truck');
  const [actions, setActions] = useState([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successAction, setSuccessAction] = useState(null);
  const [pressIndicator, setPressIndicator] = useState({ visible: false, x: 0, y: 0, progress: 0 });
  const [pressTimer, setPressTimer] = useState(null);
  const [progressTimer, setProgressTimer] = useState(null);
  
  const mapRef = useRef(null);
  
  // Simula um atraso de ativação para demonstrar o efeito de pressionar e segurar
  useEffect(() => {
    const handleMouseDown = (e) => {
      if (e.target === mapRef.current || mapRef.current.contains(e.target)) {
        const rect = mapRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Inicia o indicador de progresso
        setPressIndicator({
          visible: true,
          x,
          y,
          progress: 0
        });
        
        // Configura o timer para incrementar o progresso gradualmente
        const newProgressTimer = setInterval(() => {
          setPressIndicator(prev => ({
            ...prev,
            progress: Math.min(100, prev.progress + 5)
          }));
        }, 100);
        
        setProgressTimer(newProgressTimer);
        
        // Configura o timer para mostrar o menu após 2 segundos
        const newPressTimer = setTimeout(() => {
          setMenuPosition({ x: e.clientX, y: e.clientY });
          setIsMenuOpen(true);
          setPressIndicator({ visible: false, x: 0, y: 0, progress: 0 });
          clearInterval(newProgressTimer);
        }, 2000);
        
        setPressTimer(newPressTimer);
      }
    };
    
    const handleMouseUp = () => {
      // Cancela os timers e esconde o indicador quando o usuário solta o mouse
      if (pressTimer) {
        clearTimeout(pressTimer);
        setPressTimer(null);
      }
      
      if (progressTimer) {
        clearInterval(progressTimer);
        setProgressTimer(null);
      }
      
      setPressIndicator({ visible: false, x: 0, y: 0, progress: 0 });
    };
    
    // Adiciona os event listeners
    document.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mouseup', handleMouseUp);
    
    // Cleanup
    return () => {
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mouseup', handleMouseUp);
      
      if (pressTimer) {
        clearTimeout(pressTimer);
      }
      
      if (progressTimer) {
        clearInterval(progressTimer);
      }
    };
  }, []);
  
  // Registra uma ação e exibe feedback de sucesso
  const handleAction = (actionType, actionText) => {
    // Registra a ação no histórico
    setActions(prev => [
      { type: actionType, text: actionText, time: new Date().toLocaleTimeString() },
      ...prev.slice(0, 4) // Mantém apenas as 5 ações mais recentes
    ]);
    
    // Mostra feedback de sucesso
    setShowSuccess(true);
    setSuccessAction(actionType);
    
    // Fecha o menu após um tempo
    setTimeout(() => {
      setIsMenuOpen(false);
      setShowSuccess(false);
      setSuccessAction(null);
    }, 1500);
  };
  
  // Alterna entre os estados de navegação
  const cycleRouteStatus = () => {
    setRouteStatus(prev => {
      if (prev === 'idle') return 'planned';
      if (prev === 'planned') return 'active';
      return 'idle';
    });
  };
  
  // Alterna o modo de veículo
  const toggleVehicleMode = () => {
    setVehicleMode(prev => prev === 'truck' ? 'car' : 'truck');
  };
  
  // Verifica se existe uma rota
  const hasRoute = routeStatus === 'planned' || routeStatus === 'active';
  
  return (
    <div className="bg-gray-950 min-h-screen p-4">
      {/* Cabeçalho */}
      <div className="bg-gray-900 p-4 rounded-lg shadow-lg mb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-amber-400">KingRoad - Menu de Contexto (Preview)</h1>
          <div className="flex space-x-2">
            <button 
              className="flex items-center bg-gray-800 hover:bg-gray-700 px-3 py-2 rounded transition-colors text-white"
              onClick={toggleVehicleMode}
            >
              {vehicleMode === 'truck' ? <Truck size={16} className="mr-2" /> : <Car size={16} className="mr-2" />}
              <span>{vehicleMode === 'truck' ? 'Caminhão' : 'Carro'}</span>
            </button>
            <button 
              className="flex items-center bg-gray-800 hover:bg-gray-700 px-3 py-2 rounded transition-colors text-white"
              onClick={cycleRouteStatus}
            >
              <Settings size={16} className="mr-2" />
              <span>
                {routeStatus === 'idle' ? 'Sem rota' : 
                 routeStatus === 'planned' ? 'Rota planejada' : 'Navegando'}
              </span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Instruções */}
      <div className="bg-gray-900 p-4 rounded-lg mb-4">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Instruções</h2>
        <p className="text-gray-300 mb-2">
          Pressione e segure por 2 segundos em qualquer lugar da área do mapa abaixo para abrir o menu de contexto.
        </p>
        <div className="p-3 bg-gray-800 rounded-lg text-sm text-gray-300">
          <p><strong>Status atual:</strong> {routeStatus === 'idle' ? 'Sem rota' : routeStatus === 'planned' ? 'Rota planejada' : 'Navegando'}</p>
          <p><strong>Modo de veículo:</strong> {vehicleMode === 'truck' ? 'Caminhão' : 'Carro'}</p>
          <p className="mt-2 text-amber-400">O menu mostrará opções diferentes com base no estado atual.</p>
        </div>
      </div>
      
      {/* Área do mapa simulada */}
      <div 
        ref={mapRef}
        className="bg-gray-800 rounded-lg overflow-hidden mb-4 relative cursor-pointer"
        style={{
          height: '300px',
          backgroundImage: 'linear-gradient(to right, #444 1px, transparent 1px), linear-gradient(to bottom, #444 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      >
        {/* Visualização de rota simulada */}
        {hasRoute && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <path 
              d="M20%,50% Q40%,20% 60%,40% T80%,50%" 
              stroke="#3B82F6" 
              strokeWidth="3" 
              strokeDasharray={routeStatus === 'active' ? "none" : "5,5"}
              fill="none" 
            />
          </svg>
        )}
        
        {/* Posição atual */}
        <div className="absolute left-[20%] top-[50%] transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
          <div className="w-8 h-8 bg-blue-500 rounded-full border-2 border-white flex items-center justify-center text-white">
            {vehicleMode === 'truck' ? <Truck size={16} /> : <Car size={16} />}
          </div>
        </div>
        
        {/* Destino (se houver rota) */}
        {hasRoute && (
          <div className="absolute left-[80%] top-[50%] transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
            <div className="w-8 h-8 bg-red-500 rounded-full border-2 border-white flex items-center justify-center text-white">
              <MapPin size={16} />
            </div>
          </div>
        )}
        
        {/* Instrução visual */}
        {!pressIndicator.visible && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-black bg-opacity-60 p-3 rounded text-white text-center">
              <p>Pressione e segure por 2 segundos em qualquer lugar</p>
            </div>
          </div>
        )}
        
        {/* Indicador de pressionar e segurar */}
        {pressIndicator.visible && (
          <div 
            className="absolute pointer-events-none"
            style={{
              left: `${pressIndicator.x}px`,
              top: `${pressIndicator.y}px`,
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div className="relative w-12 h-12">
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <circle cx="18" cy="18" r="15" fill="none" stroke="#111" strokeWidth="3" />
                <circle 
                  cx="18" 
                  cy="18" 
                  r="15" 
                  fill="none" 
                  stroke="#f59e0b" 
                  strokeWidth="3" 
                  strokeDasharray="94.2"
                  strokeDashoffset={94.2 - (94.2 * pressIndicator.progress / 100)}
                  transform="rotate(-90 18 18)"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-white font-medium">
                {Math.round(pressIndicator.progress / 5) / 10}s
              </div>
            </div>
          </div>
        )}
        
        {/* Barra de navegação (se estiver no modo de navegação ativa) */}
        {routeStatus === 'active' && (
          <div className="absolute bottom-0 left-0 right-0 bg-gray-900 bg-opacity-90 p-3">
            <div className="flex items-center text-white">
              <div className="bg-amber-500 text-black rounded-full w-8 h-8 flex items-center justify-center mr-3">
                →
              </div>
              <div className="flex-1">
                <div className="font-bold">Continue na Av. Paulista</div>
                <div className="text-sm text-gray-400">25 km - 30 min</div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Histórico de ações */}
      <div className="bg-gray-900 p-4 rounded-lg">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Ações Realizadas</h2>
        {actions.length === 0 ? (
          <p className="text-gray-400 text-center p-4">Nenhuma ação realizada ainda. Pressione e segure no mapa para começar.</p>
        ) : (
          <div className="space-y-2">
            {actions.map((action, index) => (
              <div key={index} className="bg-gray-800 p-2 rounded flex items-center">
                <ActionIcon type={action.type} />
                <div className="ml-2 flex-1">
                  <div className="text-white">{action.text}</div>
                  <div className="text-xs text-gray-400">{action.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Menu de contexto */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          <div 
            className="absolute inset-0 bg-black bg-opacity-50 pointer-events-auto"
            onClick={() => setIsMenuOpen(false)}
          />
          
          <div 
            className="absolute bg-gray-900 rounded-lg shadow-xl pointer-events-auto w-72"
            style={{
              left: Math.min(menuPosition.x, window.innerWidth - 290),
              top: Math.min(menuPosition.y, window.innerHeight - 300)
            }}
          >
            {/* Cabeçalho do menu */}
            <div className="flex items-center justify-between p-3 border-b border-gray-800">
              <div className="flex items-center">
                <MapPin className="text-amber-400 mr-2" size={20} />
                <div>
                  <h3 className="font-bold text-white">Local selecionado</h3>
                  <p className="text-xs text-gray-400">Av. Paulista, 1578</p>
                </div>
              </div>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="text-gray-500 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>
            
            {/* Conteúdo do menu */}
            <div className="p-3">
              {showSuccess ? (
                // Mensagem de sucesso
                <div className="text-center py-4">
                  <div className="mx-auto w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h4 className="text-lg font-bold text-white mb-1">
                    {successAction === 'navigate' && 'Iniciando navegação...'}
                    {successAction === 'start' && 'Definido como ponto de partida'}
                    {successAction === 'end' && 'Definido como destino'}
                    {successAction === 'waypoint' && 'Ponto de passagem adicionado'}
                    {successAction === 'favorite' && 'Adicionado às rotas favoritas'}
                    {successAction === 'prohibited' && 'Adicionado às rotas proibidas'}
                    {successAction === 'articulated' && 'Marcado como rota para caminhões articulados'}
                    {successAction === 'report' && 'Problema reportado'}
                  </h4>
                </div>
              ) : (
                <>
                  {/* Distância e tempo */}
                  <div className="bg-gray-800 p-2 rounded-lg mb-3 flex justify-between">
                    <div className="flex items-center text-xs text-gray-300">
                      <TrendingUp size={14} className="mr-1 text-amber-400" />
                      <span>15.2 km</span>
                    </div>
                    <div className="flex items-center text-xs text-gray-300">
                      <Clock size={14} className="mr-1 text-amber-400" />
                      <span>22 min</span>
                    </div>
                  </div>
                
                  <div className="space-y-2">
                    {/* Menu quando não há rota */}
                    {!hasRoute && (
                      <>
                        <button
                          className="w-full bg-amber-500 hover:bg-amber-600 p-3 rounded-lg flex items-start transition-colors text-left text-black"
                          onClick={() => handleAction('navigate', 'Navegação iniciada')}
                        >
                          <Navigation size={18} className="mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium">Navegar para este ponto</div>
                            <div className="text-xs text-black text-opacity-70">Iniciar navegação</div>
                          </div>
                        </button>
                        
                        <button
                          className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                          onClick={() => handleAction('start', 'Definido como ponto de partida')}
                        >
                          <Flag size={18} className="text-amber-400 mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium text-white">Definir como ponto de partida</div>
                            <div className="text-xs text-gray-400">Ponto A</div>
                          </div>
                        </button>
                        
                        <button
                          className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                          onClick={() => handleAction('end', 'Definido como destino')}
                        >
                          <MapPin size={18} className="text-amber-400 mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium text-white">Definir como destino</div>
                            <div className="text-xs text-gray-400">Ponto B</div>
                          </div>
                        </button>
                      </>
                    )}
                    
                    {/* Menu quando há uma rota planejada ou ativa */}
                    {hasRoute && (
                      <>
                        <button
                          className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                          onClick={() => handleAction('waypoint', 'Ponto de passagem adicionado')}
                        >
                          <MapPin size={18} className="text-amber-400 mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium text-white">Adicionar ponto de passagem</div>
                            <div className="text-xs text-gray-400">Recalcular rota para passar por aqui</div>
                          </div>
                        </button>
                        
                        <button
                          className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                          onClick={() => handleAction('favorite', 'Adicionado às rotas favoritas')}
                        >
                          <Star size={18} className="text-amber-400 mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium text-white">Adicionar às rotas favoritas</div>
                            <div className="text-xs text-gray-400">Preferencial para navegação</div>
                          </div>
                        </button>
                        
                        <button
                          className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                          onClick={() => handleAction('prohibited', 'Adicionado às rotas proibidas')}
                        >
                          <Ban size={18} className="text-amber-400 mr-3 mt-0.5" />
                          <div>
                            <div className="font-medium text-white">Adicionar às rotas proibidas</div>
                            <div className="text-xs text-gray-400">Evitar esta rota</div>
                          </div>
                        </button>
                        
                        {vehicleMode === 'truck' && (
                          <button
                            className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                            onClick={() => handleAction('articulated', 'Marcado como rota possível para caminhões articulados')}
                          >
                            <Truck size={18} className="text-amber-400 mr-3 mt-0.5" />
                            <div>
                              <div className="font-medium text-white">Rota para caminhões articulados</div>
                              <div className="text-xs text-gray-400">Apenas para destinos nesta área</div>
                            </div>
                          </button>
                        )}
                      </>
                    )}
                    
                    {/* Opção comum para todos os estados */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => handleAction('report', 'Problema reportado na via')}
                    >
                      <AlertTriangle size={18} className="text-amber-400 mr-3 mt-0.5" />
                      <div>
                        <div className="font-medium text-white">Reportar problema na via</div>
                        <div className="text-xs text-gray-400">Buracos, bloqueios, etc.</div>
                      </div>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Componente auxiliar para ícones de ação
const ActionIcon = ({ type }) => {
  switch (type) {
    case 'navigate': return <Navigation size={16} className="text-amber-400" />;
    case 'start': return <Flag size={16} className="text-green-400" />;
    case 'end': return <MapPin size={16} className="text-red-400" />;
    case 'waypoint': return <MapPin size={16} className="text-blue-400" />;
    case 'favorite': return <Star size={16} className="text-amber-400" />;
    case 'prohibited': return <Ban size={16} className="text-red-400" />;
    case 'articulated': return <Truck size={16} className="text-green-400" />;
    case 'report': return <AlertTriangle size={16} className="text-amber-400" />;
    default: return <MapPin size={16} className="text-gray-400" />;
  }
};

export default MapContextMenuPreview;