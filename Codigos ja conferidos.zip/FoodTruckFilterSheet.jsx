import React, { useState, useEffect } from 'react';

const FoodTruckFilterSheet = ({ visible, filters, onApply, onClose }) => {
  // Estado local para os filtros
  const [localFilters, setLocalFilters] = useState({
    country: 'all',
    parkingSpace: false,
    minRating: 0,
    cuisineType: [],
    openNow: false
  });
  
  // Opções de país
  const countryOptions = [
    { id: 'all', label: 'Reino Unido e Irlanda' },
    { id: 'UK', label: 'Reino Unido' },
    { id: 'Ireland', label: 'Irlanda' }
  ];
  
  // Opções de tipo de cozinha
  const cuisineOptions = [
    { id: 'english_breakfast', label: 'English Breakfast' },
    { id: 'sandwich', label: 'Sanduíches' },
    { id: 'coffee', label: 'Café' },
    { id: 'tea', label: 'Chá' },
    { id: 'irish_food', label: 'Comida Irlandesa' },
    { id: 'hot_food', label: 'Comida Quente' },
    { id: 'pastries', label: 'Doces e Bolos' }
  ];
  
  // Inicializa os filtros locais quando os filtros externos mudam
  useEffect(() => {
    if (filters) {
      setLocalFilters(filters);
    }
  }, [filters]);
  
  // Se o painel não estiver visível, não renderiza nada
  if (!visible) return null;
  
  // Atualiza um filtro específico
  const updateFilter = (key, value) => {
    setLocalFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  // Toggle para tipos de cozinha
  const toggleCuisineType = (cuisineId) => {
    setLocalFilters(prev => {
      const cuisineTypes = [...prev.cuisineType];
      if (cuisineTypes.includes(cuisineId)) {
        return {
          ...prev,
          cuisineType: cuisineTypes.filter(id => id !== cuisineId)
        };
      } else {
        return {
          ...prev,
          cuisineType: [...cuisineTypes, cuisineId]
        };
      }
    });
  };
  
  // Limpa todos os filtros
  const clearFilters = () => {
    setLocalFilters({
      country: 'all',
      parkingSpace: false,
      minRating: 0,
      cuisineType: [],
      openNow: false
    });
  };
  
  // Aplica os filtros
  const handleApply = () => {
    onApply(localFilters);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex flex-col">
      {/* Cabeçalho */}
      <div className="bg-gray-800 px-6 py-4 flex justify-between items-center border-b border-gray-700">
        <h2 className="text-xl font-bold text-yellow-500">
          Filtrar Food Trucks
        </h2>
        <button 
          onClick={onClose}
          className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-gray-700 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
      
      {/* Conteúdo com scroll */}
      <div className="flex-1 overflow-y-auto p-6 bg-gray-900">
        {/* Filtro por país */}
        <div className="mb-6">
          <h3 className="text-white font-medium mb-3">País</h3>
          <div className="grid grid-cols-3 gap-2">
            {countryOptions.map(option => (
              <button
                key={option.id}
                className={`py-2 px-3 rounded-md text-sm font-medium ${
                  localFilters.country === option.id
                    ? 'bg-yellow-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
                onClick={() => updateFilter('country', option.id)}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Filtro por avaliação mínima */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-white font-medium">Avaliação Mínima</h3>
            <span className="text-yellow-500 font-medium">
              {localFilters.minRating > 0 ? `${localFilters.minRating}+ estrelas` : 'Qualquer'}
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="5"
            step="0.5"
            value={localFilters.minRating}
            onChange={(e) => updateFilter('minRating', parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-500"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Qualquer</span>
            <span>5 estrelas</span>
          </div>
        </div>
        
        {/* Filtro por tipo de cozinha */}
        <div className="mb-6">
          <h3 className="text-white font-medium mb-3">Tipo de Comida</h3>
          <div className="grid grid-cols-2 gap-2">
            {cuisineOptions.map(option => (
              <button
                key={option.id}
                className={`py-2 px-3 rounded-md text-sm font-medium text-left flex items-center ${
                  localFilters.cuisineType.includes(option.id)
                    ? 'bg-gray-800 border border-yellow-600 text-white'
                    : 'bg-gray-800 border border-gray-700 text-gray-300 hover:border-gray-600'
                }`}
                onClick={() => toggleCuisineType(option.id)}
              >
                <div className={`w-4 h-4 mr-2 rounded border flex items-center justify-center ${
                  localFilters.cuisineType.includes(option.id)
                    ? 'bg-yellow-600 border-yellow-600'
                    : 'border-gray-500'
                }`}>
                  {localFilters.cuisineType.includes(option.id) && (
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  )}
                </div>
                {option.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Toggle para espaço de estacionamento e aberto agora */}
        <div className="mb-6 space-y-3">
          <div className="flex items-center justify-between bg-gray-800 p-3 rounded-md">
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-3">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <path d="M9 17V7h4a3 3 0 0 1 0 6H9"/>
              </svg>
              <span className="text-white">Estacionamento para caminhões</span>
            </div>
            <button
              className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
                localFilters.parkingSpace ? 'bg-yellow-600' : 'bg-gray-600'
              }`}
              onClick={() => updateFilter('parkingSpace', !localFilters.parkingSpace)}
            >
              <span
                className={`inline-block w-4 h-4 transform transition-transform bg-white rounded-full ${
                  localFilters.parkingSpace ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          
          <div className="flex items-center justify-between bg-gray-800 p-3 rounded-md">
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-3">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
              <span className="text-white">Aberto agora</span>
            </div>
            <button
              className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
                localFilters.openNow ? 'bg-yellow-600' : 'bg-gray-600'
              }`}
              onClick={() => updateFilter('openNow', !localFilters.openNow)}
            >
              <span
                className={`inline-block w-4 h-4 transform transition-transform bg-white rounded-full ${
                  localFilters.openNow ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
      
      {/* Barra de ações */}
      <div className="bg-gray-800 px-6 py-4 flex gap-2 border-t border-gray-700">
        <button 
          onClick={clearFilters}
          className="flex-1 border border-gray-600 text-gray-300 hover:bg-gray-700 py-3 px-4 rounded-md font-medium"
        >
          Limpar filtros
        </button>
        <button 
          onClick={handleApply}
          className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white py-3 px-4 rounded-md font-medium"
        >
          Aplicar filtros
        </button>
      </div>
    </div>
  );
};

export default FoodTruckFilterSheet;