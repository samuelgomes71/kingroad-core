package com.kingfamily.kingroad

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.kingfamily.common.utils.ResourceDownloader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SplashActivity : AppCompatActivity() {

    companion object {
        private const val SPLASH_DISPLAY_TIME = 2000L // 2 segundos
        private const val APP_NAME = "KingRoad"
        private const val IS_BETA = true // Controla se o indicador de beta é exibido
    }

    private lateinit var splashLogo: ImageView
    private lateinit var versionText: TextView
    private lateinit var betaIndicator: TextView
    private lateinit var resourceDownloader: ResourceDownloader

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Inicialização dos componentes de UI
        splashLogo = findViewById(R.id.splash_logo)
        versionText = findViewById(R.id.version_text)
        betaIndicator = findViewById(R.id.beta_indicator)

        // Inicializa o ResourceDownloader
        resourceDownloader = ResourceDownloader(this)

        // Configura a versão do aplicativo
        setupVersionText()

        // Configura o indicador de versão beta
        setupBetaIndicator()

        // Carrega a splash screen adequada ao tamanho da tela
        loadSplashImage()

        // Inicia o download dos recursos em segundo plano
        downloadResources()

        // Configura o delay para navegar para a MainActivity
        setupSplashDelay()
    }

    /**
     * Configura o texto de versão do app
     */
    private fun setupVersionText() {
        try {
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            val versionName = packageInfo.versionName
            versionText.text = getString(R.string.version_format, versionName)
        } catch (e: Exception) {
            versionText.visibility = View.GONE
        }
    }

    /**
     * Configura a exibição do indicador de beta, se necessário
     */
    private fun setupBetaIndicator() {
        if (IS_BETA) {
            betaIndicator.visibility = View.VISIBLE
        } else {
            betaIndicator.visibility = View.GONE
        }
    }

    /**
     * Carrega a imagem de splash screen de acordo com o tamanho da tela
     */
    private fun loadSplashImage() {
        val screenSize = resourceDownloader.getScreenSizeCategory()
        
        // Tenta carregar a imagem baixada do CDN
        val splashFile = resourceDownloader.getResourceFile(
            ResourceDownloader.Companion.ResourceType.SPLASH_SCREEN,
            APP_NAME,
            screenSize
        )
        
        if (splashFile != null && splashFile.exists()) {
            // Carrega a imagem baixada
            splashLogo.setImageURI(android.net.Uri.fromFile(splashFile))
        } else {
            // Usa a imagem padrão do projeto
            val resourceId = getSplashResourceByScreenSize(screenSize)
            splashLogo.setImageResource(resourceId)
        }
    }

    /**
     * Retorna o ID do recurso de splash screen com base no tamanho da tela
     */
    private fun getSplashResourceByScreenSize(
        screenSize: ResourceDownloader.Companion.ScreenSizeCategory
    ): Int {
        return when (screenSize) {
            ResourceDownloader.Companion.ScreenSizeCategory.SMALL -> R.drawable.splash_screen_small
            ResourceDownloader.Companion.ScreenSizeCategory.MEDIUM -> R.drawable.splash_screen_medium
            ResourceDownloader.Companion.ScreenSizeCategory.LARGE -> R.drawable.splash_screen_large
            ResourceDownloader.Companion.ScreenSizeCategory.XLARGE -> R.drawable.splash_screen_xlarge
        }
    }

    /**
     * Inicia o download de recursos em segundo plano
     */
    private fun downloadResources() {
        CoroutineScope(Dispatchers.IO).launch {
            resourceDownloader.downloadAllResources(APP_NAME)
        }
    }

    /**
     * Configura o atraso da splash screen e a navegação para a MainActivity
     */
    private fun setupSplashDelay() {
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashActivity, MainActivity::class.java)
            startActivity(intent)
            finish() // Finaliza a SplashActivity para que não seja possível voltar a ela
        }, SPLASH_DISPLAY_TIME)
    }
}