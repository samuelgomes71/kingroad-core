import React, { useState, useEffect } from 'react';
import { X, AlertTriangle, Truck, Scissors, Wind, PhoneOutgoing, Volume2, VolumeX, MapPin, Navigation } from 'lucide-react';

const EmergencyAlertWithLocation = ({ 
  alert, 
  onClose, 
  onCallPolice,
  onAddComment,
  onNavigateTo 
}) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [comment, setComment] = useState('');
  const [reporterLocation, setReporterLocation] = useState(null);
  
  // Verificar se o alerta está definido
  if (!alert) {
    return null;
  }
  
  // Efeito para timer
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Efeito para simular atualizações de localização em tempo real
  // Em um app real, isso seria substituído por atualizações do KingLoc
  useEffect(() => {
    if (!alert || !alert.coordinates) return;
    
    // Inicializar a localização do repórter com as coordenadas do alerta
    setReporterLocation(alert.coordinates);
    
    const locationUpdateInterval = setInterval(() => {
      // Simulação de movimento para demonstração
      // Em um app real, receberíamos atualizações do serviço KingLoc
      setReporterLocation(prev => {
        if (!prev) return alert.coordinates;
        return {
          latitude: prev.latitude + (Math.random() - 0.5) * 0.0001,
          longitude: prev.longitude + (Math.random() - 0.5) * 0.0001
        };
      });
    }, 3000);
    
    return () => clearInterval(locationUpdateInterval);
  }, [alert]);
  
  // Formatar o tempo decorrido
  const formatElapsedTime = () => {
    const minutes = Math.floor(secondsElapsed / 60);
    const seconds = secondsElapsed % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Submeter comentário
  const handleSubmitComment = () => {
    if (comment.trim() && typeof onAddComment === 'function') {
      onAddComment(comment);
      setComment('');
    }
  };
  
  // Controle de som
  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
  };
  
  // Calcular distância entre usuário e o alerta
  const calculateDistance = (userLocation) => {
    if (!reporterLocation || !userLocation) return "N/A";
    
    // Em um app real, usaríamos a localização atual do usuário
    // Aqui usamos uma localização simulada próxima
    const userLat = reporterLocation.latitude + 0.002;
    const userLng = reporterLocation.longitude + 0.001;
    
    // Cálculo de distância usando a fórmula de Haversine
    const R = 6371; // Raio da Terra em km
    const dLat = (reporterLocation.latitude - userLat) * Math.PI / 180;
    const dLon = (reporterLocation.longitude - userLng) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(userLat * Math.PI / 180) * Math.cos(reporterLocation.latitude * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    return distance.toFixed(1);
  };
  
  // Ícone baseado no tipo de alerta
  const getAlertIcon = () => {
    if (!alert) return <AlertTriangle size={28} className="text-black" />;
    
    switch (alert.alertType) {
      case 'cargo_theft':
        return <Truck size={28} className="text-black" />;
      case 'curtain_cutting':
        return <Scissors size={28} className="text-black" />;
      case 'gas_attack':
        return <Wind size={28} className="text-black" />;
      case 'brake_failure':
        return <AlertTriangle size={28} className="text-black" />;
      default:
        return <AlertTriangle size={28} className="text-black" />;
    }
  };
  
  // Simulação da localização do usuário
  const simulatedUserLocation = reporterLocation ? {
    latitude: reporterLocation.latitude + 0.002,
    longitude: reporterLocation.longitude + 0.001
  } : null;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 p-4 bg-black bg-opacity-80">
      <div 
        className="w-full max-w-lg bg-gray-900 rounded-lg overflow-hidden shadow-2xl border-2 border-amber-500 animate-pulse"
        style={{animationDuration: '2s'}}
      >
        {/* Cabeçalho estilo AMBER Alert */}
        <div className="bg-amber-600 p-4 flex justify-between items-center">
          <div className="flex items-center">
            {getAlertIcon()}
            <h2 className="text-xl font-bold text-black ml-2">
              EMERGENCY ALERT • ALERTA DE EMERGÊNCIA
            </h2>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={toggleSound}
              className="p-1 rounded-full bg-gray-800 hover:bg-gray-700"
            >
              {soundEnabled ? <Volume2 size={20} className="text-white" /> : <VolumeX size={20} className="text-white" />}
            </button>
            <button 
              onClick={() => typeof onClose === 'function' && onClose()}
              className="p-1 rounded-full bg-gray-800 hover:bg-gray-700"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>
        
        {/* Conteúdo */}
        <div className="p-4">
          {/* Info de tempo e localização */}
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-start">
              <MapPin size={18} className="text-red-500 mt-1 mr-1 flex-shrink-0" />
              <div>
                <p className="text-white font-medium">{alert.locationName || "Localização não disponível"}</p>
                <p className="text-xs text-gray-400">
                  A {calculateDistance(simulatedUserLocation)} km de você
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-400">Alerta enviado há {formatElapsedTime()}</p>
            </div>
          </div>
          
          {/* Descrição do Alerta */}
          <div className="bg-red-950 p-3 rounded-lg border border-red-800 mb-4">
            <p className="text-white">{alert.description || "Sem descrição disponível"}</p>
          </div>
          
          {/* Mapa de localização em tempo real */}
          <div className="bg-gray-800 rounded-lg overflow-hidden mb-4 relative" style={{height: '200px'}}>
            {/* Em um app real, aqui seria inserido um componente de mapa real */}
            <div className="absolute inset-0 flex items-center justify-center text-gray-500">
              Mapa de Localização em Tempo Real
            </div>
            
            {/* Ponto pulsante representando a localização do alerta */}
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-4 h-4 bg-red-500 rounded-full relative">
                <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-75"></div>
              </div>
            </div>
            
            {/* Texto de atualização de localização */}
            <div className="absolute bottom-2 left-2 right-2 bg-black bg-opacity-70 text-white text-xs p-2 rounded">
              <div className="flex items-center justify-between">
                <span>Localização em tempo real via KingLoc</span>
                <span>Última atualização: agora</span>
              </div>
            </div>
          </div>
          
          {/* Instruções */}
          <div className="mt-4 text-sm text-amber-300 bg-amber-950 p-3 rounded-lg border border-amber-800">
            <p className="font-bold mb-1">INSTRUÇÕES DE SEGURANÇA:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Acenda os faróis do seu veículo</li>
              <li>Tranque as portas da cabine</li>
              <li>Busque se posicionar onde haja outros motoristas</li>
              <li>Não confronte os suspeitos</li>
              <li>Ligue para as autoridades se necessário</li>
            </ul>
          </div>
          
          {/* Botões de Ação */}
          <div className="grid grid-cols-3 gap-3 mt-4">
            <button
              onClick={() => typeof onNavigateTo === 'function' && reporterLocation && onNavigateTo(reporterLocation)}
              className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded"
            >
              <Navigation size={18} className="mr-2" />
              Navegar até
            </button>
            <button
              onClick={() => typeof onCallPolice === 'function' && onCallPolice()}
              className="flex items-center justify-center bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded"
            >
              <PhoneOutgoing size={18} className="mr-2" />
              Ligar Polícia
            </button>
            <button
              onClick={() => typeof onClose === 'function' && onClose()}
              className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded"
            >
              Entendi
            </button>
          </div>
          
          {/* Campo para adicionar informações */}
          <div className="mt-4">
            <label className="block text-gray-300 text-sm font-bold mb-2">
              Adicionar informações:
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
              placeholder="Descreva o que está vendo (veículos, pessoas, direção de fuga...)"
              rows={3}
            />
            <button
              onClick={handleSubmitComment}
              className="mt-2 w-full bg-green-700 hover:bg-green-800 text-white font-bold py-2 px-4 rounded"
            >
              Compartilhar Informação
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmergencyAlertWithLocation;