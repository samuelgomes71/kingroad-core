import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Image,
  ActivityIndicator,
  Platform,
  Alert,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';

// Importação dos renderizadores de configurações
import { renderHikingSettings, renderBikeSettings } from '../components/trail/renderers/HikingAndBikeRenderers';
import { renderMotoSettings, render4x4Settings } from '../components/trail/renderers/MotoAnd4x4Renderers';
import { renderSnowmobileSettings } from '../components/trail/renderers/SnowmobileRenderer';

const { width } = Dimensions.get('window');

const TrailModesScreen = () => {
  const navigation = useNavigation();
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMode, setSelectedMode] = useState(null);
  const [trailModes, setTrailModes] = useState([]);
  const [userPreferences, setUserPreferences] = useState({});
  
  // Configurações para cada modo de trilha
  const [hikingSettings, setHikingSettings] = useState({
    recordingEnabled: true,
    autoDetectStops: true,
    difficultyFilter: 'all', // all, easy, moderate, hard
    showElevation: true,
    maxSlope: 30, // em percentual (%)
    terrainTypes: ['paved', 'dirt', 'rocky'],
    preferScenic: true
  });
  
  const [bikeSettings, setBikeSettings] = useState({
    recordingEnabled: true,
    recordHeartRate: false,
    bikeType: 'mountain', // mountain, road, hybrid
    showBikeTrails: true,
    avoidSteps: true,
    preferPaved: false,
    showDifficulty: true
  });
  
  const [motoSettings, setMotoSettings] = useState({
    recordingEnabled: true,
    motoType: 'trail', // urban, road, trail
    showGasStations: true,
    preferScenic: true,
    avoidHighways: false,
    showTrailConditions: true,
    recordAltitude: true
  });
  
  const [fourByFourSettings, setFourByFourSettings] = useState({
    recordingEnabled: true,
    vehicleHeight: 2.5, // em metros
    vehicleWidth: 2.1, // em metros
    clearanceHeight: 0.4, // em metros
    showWaterCrossings: true,
    showOffRoadTrails: true,
    difficultyClearance: 'advanced' // beginner, intermediate, advanced
  });
  
  const [snowmobileSettings, setSnowmobileSettings] = useState({
    recordingEnabled: true,
    showGroomedTrails: true,
    showAvalangeRisk: true,
    showShelters: true,
    recordTemperature: true,
    showSnowDepth: true,
    ungroomedFilter: 'all' // all, avoid, prefer
  });
  
  // Dados de modos de trilha
  const modeData = [
    {
      id: 'hike',
      name: 'Trilha',
      icon: 'hiking',
      color: '#4CAF50',
      image: require('../assets/mode-hiking.jpg'),
      description: 'Trilhas e caminhos para caminhadas, de fáceis a avançados',
      getSettings: () => hikingSettings,
      setSettings: setHikingSettings
    },
    {
      id: 'bike',
      name: 'Bike',
      icon: 'bike',
      color: '#FF9800',
      image: require('../assets/mode-biking.jpg'),
      description: 'Rotas para bicicletas em estradas, montanhas e trilhas urbanas',
      getSettings: () => bikeSettings,
      setSettings: setBikeSettings
    },
    {
      id: 'moto',
      name: 'Moto',
      icon: 'motorbike',
      color: '#E91E63',
      image: require('../assets/mode-moto.jpg'),
      description: 'Rotas especiais para motocicletas com foco em trilhas e estradas cênicas',
      getSettings: () => motoSettings,
      setSettings: setMotoSettings
    },
    {
      id: '4x4',
      name: '4x4',
      icon: 'jeepney',
      color: '#795548',
      image: require('../assets/mode-4x4.jpg'),
      description: 'Trajetos off-road para veículos 4x4 com diferentes níveis de dificuldade',
      getSettings: () => fourByFourSettings,
      setSettings: setFourByFourSettings
    },
    {
      id: 'snowmobile',
      name: 'Snowmobile',
      icon: 'snowflake',
      color: '#9C27B0',
      image: require('../assets/mode-snowmobile.jpg'),
      description: 'Trilhas de neve para snowmobiles com informações de segurança e condições',
      getSettings: () => snowmobileSettings,
      setSettings: setSnowmobileSettings
    }
  ];
  
  // Carregar modos e preferências do usuário
  useEffect(() => {
    const loadData = async () => {
      try {
        setTrailModes(modeData);
        
        // Carregar preferências salvas
        const savedPrefs = await AsyncStorage.getItem('trail_modes_prefs');
        if (savedPrefs) {
          const preferences = JSON.parse(savedPrefs);
          setUserPreferences(preferences);
          
          // Aplicar preferências salvas às configurações
          if (preferences.hiking) setHikingSettings(preferences.hiking);
          if (preferences.bike) setBikeSettings(preferences.bike);
          if (preferences.moto) setMotoSettings(preferences.moto);
          if (preferences.fourByFour) setFourByFourSettings(preferences.fourByFour);
          if (preferences.snowmobile) setSnowmobileSettings(preferences.snowmobile);
          
          // Definir último modo selecionado, se disponível
          if (preferences.lastSelectedMode) {
            setSelectedMode(preferences.lastSelectedMode);
          } else {
            setSelectedMode('hike'); // Padrão
          }
        } else {
          // Se não há preferências salvas, definir o modo padrão
          setSelectedMode('hike');
        }
      } catch (error) {
        console.error('Erro ao carregar preferências:', error);
        // Em caso de erro, definir o modo padrão
        setSelectedMode('hike');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);
  
  // Salvar preferências do usuário
  const savePreferences = async () => {
    try {
      const preferences = {
        lastSelectedMode: selectedMode,
        hiking: hikingSettings,
        bike: bikeSettings,
        moto: motoSettings,
        fourByFour: fourByFourSettings,
        snowmobile: snowmobileSettings
      };
      
      await AsyncStorage.setItem('trail_modes_prefs', JSON.stringify(preferences));
      Alert.alert('Sucesso', 'Preferências salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar preferências:', error);
      Alert.alert('Erro', 'Não foi possível salvar suas preferências.');
    }
  };
  
  // Começar uma nova rota com o modo selecionado
  const startNewRoute = () => {
    if (!selectedMode) return;
    
    // Salvar o modo selecionado como o último usado
    const updatedPrefs = {
      ...userPreferences,
      lastSelectedMode: selectedMode
    };
    AsyncStorage.setItem('trail_modes_prefs', JSON.stringify(updatedPrefs));
    
    // Navegar para a tela de navegação com o modo selecionado
    navigation.navigate('NavigationScreen', {
      mode: selectedMode,
      settings: getCurrentModeSettings()
    });
  };
  
  // Obter as configurações atuais do modo selecionado
  const getCurrentModeSettings = () => {
    const selectedModeData = modeData.find(mode => mode.id === selectedMode);
    return selectedModeData ? selectedModeData.getSettings() : null;
  };
  
  // Atualizar uma configuração específica para o modo atual
  const updateSetting = (key, value) => {
    const selectedModeData = modeData.find(mode => mode.id === selectedMode);
    if (!selectedModeData) return;
    
    const currentSettings = selectedModeData.getSettings();
    const updatedSettings = { ...currentSettings, [key]: value };
    selectedModeData.setSettings(updatedSettings);
  };
  
  // Renderizar configurações baseadas no modo selecionado
  const renderModeSettings = () => {
    if (!selectedMode) return null;
    
    const settings = getCurrentModeSettings();
    if (!settings) return null;
    
    // Renderizar configurações específicas para cada modo usando os componentes importados
    switch (selectedMode) {
      case 'hike':
        return renderHikingSettings(settings, updateSetting, styles);
      case 'bike':
        return renderBikeSettings(settings, updateSetting, styles);
      case 'moto':
        return renderMotoSettings(settings, updateSetting, styles);
      case '4x4':
        return render4x4Settings(settings, updateSetting, styles);
      case 'snowmobile':
        return renderSnowmobileSettings(settings, updateSetting, styles);
      default:
        return null;
    }
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A90E2" />
        <Text style={styles.loadingText}>Carregando modos de trilha...</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      {/* Cabeçalho */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-left" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Modos de Trilha</Text>
        <TouchableOpacity 
          style={styles.headerAction}
          onPress={savePreferences}
        >
          <Icon name="content-save" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>
      
      {/* Seletor de modos */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.modeSelector}
        contentContainerStyle={styles.modeSelectorContent}
      >
        {trailModes.map((mode) => (
          <TouchableOpacity
            key={mode.id}
            style={[
              styles.modeCard,
              selectedMode === mode.id && styles.modeCardSelected,
              { borderColor: mode.color }
            ]}
            onPress={() => setSelectedMode(mode.id)}
          >
            <View style={[styles.modeIconContainer, { backgroundColor: mode.color }]}>
              <Icon name={mode.icon} size={24} color="#FFF" />
            </View>
            <Text style={styles.modeName}>{mode.name}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      {/* Conteúdo principal */}
      <ScrollView style={styles.content}>
        {/* Preview do modo selecionado */}
        {selectedMode && (
          <View style={styles.selectedModePreview}>
            {/* Card com imagem e descrição */}
            <View style={styles.previewCard}>
              <Image
                source={trailModes.find(mode => mode.id === selectedMode)?.image}
                style={styles.previewImage}
                resizeMode="cover"
              />
              <LinearGradient
                colors={['transparent', 'rgba(0,0,0,0.8)']}
                style={styles.previewGradient}
              >
                <Text style={styles.previewTitle}>
                  {trailModes.find(mode => mode.id === selectedMode)?.name}
                </Text>
                <Text style={styles.previewDescription}>
                  {trailModes.find(mode => mode.id === selectedMode)?.description}
                </Text>
              </LinearGradient>
            </View>
            
            {/* Botão de iniciar navegação */}
            <TouchableOpacity
              style={[
                styles.startButton,
                { backgroundColor: trailModes.find(mode => mode.id === selectedMode)?.color }
              ]}
              onPress={startNewRoute}
            >
              <Icon name="navigation" size={20} color="#FFF" />
              <Text style={styles.startButtonText}>Iniciar Nova Rota</Text>
            </TouchableOpacity>
            
            {/* Configurações específicas para o modo */}
            <Text style={styles.settingsTitle}>Configurações</Text>
            {renderModeSettings()}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#4A90E2',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 15,
    paddingHorizontal: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
    flex: 1,
textAlign: 'center',
  },
  headerAction: {
    padding: 5,
  },
  modeSelector: {
    backgroundColor: '#FFF',
    paddingVertical: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  modeSelectorContent: {
    paddingHorizontal: 15,
  },
  modeCard: {
    alignItems: 'center',
    marginRight: 15,
    width: 80,
    padding: 10,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  modeCardSelected: {
    backgroundColor: '#F5F5F5',
  },
  modeIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  modeName: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    padding: 15,
  },
  selectedModePreview: {
    marginBottom: 20,
  },
  previewCard: {
    height: 180,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  previewImage: {
    width: '100%',
    height: '100%',
  },
  previewGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 15,
    paddingVertical: 12,
  },
  previewTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 4,
  },
  previewDescription: {
    fontSize: 14,
    color: '#EEEEEE',
  },
  startButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4A90E2',
    borderRadius: 8,
    paddingVertical: 12,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  startButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
    marginLeft: 8,
  },
  settingsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  settingsContainer: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    color: '#333',
    marginLeft: 10,
  },
  settingGroupTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#555',
    marginBottom: 10,
    marginTop: 5,
  },
  optionButtonsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 15,
  },
  optionButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 4,
    borderWidth: 1,
    marginRight: 8,
    marginBottom: 8,
  },
  optionButtonActive: {
    backgroundColor: '#E3F2FD',
  },
  optionButtonText: {
    fontSize: 14,
    color: '#555',
  },
  optionButtonTextActive: {
    fontWeight: 'bold',
    color: '#333',
  },
  vehicleDimensions: {
    marginBottom: 15,
  },
  dimensionControl: {
    marginBottom: 10,
  },
  dimensionLabel: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5,
  },
  dimensionButtonsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  dimensionButton: {
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dimensionValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    width: 50,
    textAlign: 'center',
  }
});

export default TrailModesScreen;
