// messaging.service.js
// Serviço para manipulação de mensagens e confirmações de leitura no KingChat

const PrivacyModel = require('../models/privacy.model');
const MessageModel = require('../models/message.model');
const UserModel = require('../models/user.model');
const NotificationService = require('./notification.service');

/**
 * Serviço para gerenciar mensagens e confirmações de leitura
 */
class MessagingService {
  /**
   * Marca uma mensagem como lida e envia confirmação se permitido
   * @param {String} messageId - ID da mensagem
   * @param {String} recipientId - ID do usuário que leu a mensagem
   * @returns {Promise<Object>} Status da operação
   */
  static async markMessageAsRead(messageId, recipientId) {
    try {
      // Encontra a mensagem
      const message = await MessageModel.findById(messageId);
      
      if (!message) {
        throw new Error('Mensagem não encontrada');
      }
      
      // Certifica-se de que o destinatário é o que está marcando como lida
      if (message.recipientId.toString() !== recipientId.toString()) {
        throw new Error('Usuário não autorizado a marcar esta mensagem como lida');
      }
      
      // Marca a mensagem como lida
      message.readAt = new Date();
      await message.save();
      
      // Verifica se o remetente pode ver confirmações de leitura
      const canSeeReadReceipts = await this.canSeeReadReceipts(
        message.senderId,
        message.recipientId
      );
      
      // Se permitido, envia confirmação de leitura ao remetente
      if (canSeeReadReceipts) {
        await NotificationService.sendReadReceiptNotification(
          message.senderId,
          message.recipientId,
          messageId
        );
      }
      
      return {
        success: true,
        readAt: message.readAt,
        readReceiptSent: canSeeReadReceipts
      };
    } catch (error) {
      console.error('Erro ao marcar mensagem como lida:', error);
      throw error;
    }
  }
  
  /**
   * Verifica se um usuário pode ver confirmações de leitura de outro usuário
   * @param {String} senderId - ID do remetente da mensagem
   * @param {String} recipientId - ID do destinatário da mensagem
   * @returns {Promise<Boolean>} Se o remetente pode ver confirmações
   */
  static async canSeeReadReceipts(senderId, recipientId) {
    try {
      // Obtém configurações de privacidade do destinatário
      const recipientPrivacy = await PrivacyModel.findOne({ userId: recipientId });
      
      // Se não houver configurações, o padrão é 'all' (todos podem ver)
      if (!recipientPrivacy) return true;
      
      const { readReceiptOption, selectedContactsForReadReceipts } = recipientPrivacy;
      
      // Verifica com base na opção de privacidade
      switch (readReceiptOption) {
        case 'all':
          return true;
        case 'selected':
          return selectedContactsForReadReceipts.includes(senderId);
        case 'none':
          return false;
        default:
          return true;
      }
    } catch (error) {
      console.error('Erro ao verificar permissões de confirmação de leitura:', error);
      // Em caso de erro, usa a opção mais privada
      return false;
    }
  }
  
  /**
   * Envia uma nova mensagem
   * @param {Object} messageData - Dados da mensagem
   * @returns {Promise<Object>} A mensagem criada
   */
  static async sendMessage(messageData) {
    try {
      const { senderId, recipientId, content, contentType } = messageData;
      
      // Cria a nova mensagem
      const newMessage = new MessageModel({
        senderId,
        recipientId,
        content,
        contentType,
        sentAt: new Date()
      });
      
      // Salva a mensagem
      await newMessage.save();
      
      // Notifica o destinatário
      await NotificationService.sendNewMessageNotification(
        recipientId,
        senderId,
        newMessage._id
      );
      
      return newMessage;
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      throw error;
    }
  }
}

module.exports = MessagingService;