import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Car, 
  Shield, 
  X,
  AlertCircle,
  MapPin,
  Construction,
  Ban,
  Radio,
  Clock,
  Activity,
  Map
} from 'lucide-react';

const RoadAlertSystem = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('road');

  const mainAlerts = [
    {
      id: 'accident',
      icon: AlertTriangle,
      label: 'Accident',
      color: 'bg-red-500',
      textColor: 'text-red-800',
      bgHover: 'hover:bg-red-200'
    },
    {
      id: 'stopped_vehicle',
      icon: Car,
      label: 'Carro Parado',
      color: 'bg-orange-500',
      textColor: 'text-orange-800',
      bgHover: 'hover:bg-orange-200'
    }
  ];

  const roadConditions = [
    {
      id: 'police',
      icon: Shield,
      label: 'Police',
      color: 'bg-blue-500'
    },
    {
      id: 'traffic',
      icon: Car,
      label: 'Traffic',
      color: 'bg-orange-500'
    },
    {
      id: 'danger',
      icon: AlertTriangle,
      label: 'Danger',
      color: 'bg-yellow-500'
    },
    {
      id: 'inspection',
      icon: Shield,
      label: 'Inspection',
      color: 'bg-blue-500'
    },
    {
      id: 'closure',
      icon: Ban,
      label: 'Closure',
      color: 'bg-red-500'
    },
    {
      id: 'construction',
      icon: Construction,
      label: 'Construction',
      color: 'bg-orange-500'
    }
  ];

  const mapIssues = [
    {
      id: 'wrong_destination',
      icon: MapPin,
      label: 'Wrong Destination',
      color: 'bg-red-500'
    },
    {
      id: 'not_truck_route',
      icon: Ban,
      label: 'Not a Truck Route',
      color: 'bg-orange-500'
    },
    {
      id: 'detour',
      icon: Map,
      label: 'Detour',
      color: 'bg-yellow-500'
    },
    {
      id: 'no_turns',
      icon: Ban,
      label: 'No Turns Allowed',
      color: 'bg-red-500'
    },
    {
      id: 'no_signal',
      icon: Radio,
      label: 'No Signal',
      color: 'bg-gray-500'
    },
    {
      id: 'glitch',
      icon: AlertCircle,
      label: 'Glitch',
      color: 'bg-red-500'
    },
    {
      id: 'speed_limit',
      icon: Activity,
      label: 'Speed Limit',
      color: 'bg-blue-500'
    },
    {
      id: 'other',
      icon: AlertCircle,
      label: 'Other',
      color: 'bg-gray-500'
    }
  ];

  const handleReport = (type, category) => {
    // Em um ambiente real, esta função obteria a geolocalização
    // e enviaria o relatório para um servidor
    console.log('Reported:', { type, category });
    
    // Simular criação de relatório
    alert(`Relatório enviado: ${type} (${category})`);
  };

  if (!isMenuOpen) {
    return (
      <div className="fixed bottom-4 right-4">
        <button 
          onClick={() => setIsMenuOpen(true)} 
          className="bg-red-500 text-white p-4 rounded-full shadow-lg hover:bg-red-600"
        >
          <AlertTriangle className="w-6 h-6" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-900 text-white rounded-lg shadow-xl p-4 m-4 max-w-lg w-full border border-gray-700">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-blue-300">Send a report</h2>
          <button 
            onClick={() => setIsMenuOpen(false)}
            className="p-2 hover:bg-gray-800 rounded-full"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Main Alerts - Always Visible and Prominent */}
        <div className="mb-6">
          <div className="grid grid-cols-2 gap-4">
            {mainAlerts.map((alert) => {
              const Icon = alert.icon;
              return (
                <button
                  key={alert.id}
                  onClick={() => handleReport(alert.id, 'main')}
                  className={`flex items-center justify-center space-x-2 ${alert.color} 
                    bg-opacity-20 text-white hover:bg-opacity-30 rounded-lg p-4`}
                >
                  <Icon className="w-6 h-6" />
                  <span className="font-medium">{alert.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex space-x-4 mb-4">
          <button 
            onClick={() => setSelectedCategory('road')}
            className={`px-4 py-2 rounded-lg ${
              selectedCategory === 'road' 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-800 text-gray-300'
            }`}
          >
            Road Condition
          </button>
          <button 
            onClick={() => setSelectedCategory('map')}
            className={`px-4 py-2 rounded-lg ${
              selectedCategory === 'map' 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-800 text-gray-300'
            }`}
          >
            Map Issue
          </button>
        </div>

        {/* Grid of Condition/Issue Options */}
        <div className="grid grid-cols-3 gap-4">
          {(selectedCategory === 'road' ? roadConditions : mapIssues).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleReport(item.id, selectedCategory)}
                className="flex flex-col items-center space-y-2 p-4 rounded-lg hover:bg-gray-800"
              >
                <div className={`${item.color} bg-opacity-20 p-2 rounded-full`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-sm text-center text-gray-300">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default RoadAlertSystem;