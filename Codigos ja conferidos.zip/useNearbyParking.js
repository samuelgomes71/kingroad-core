import { useState, useEffect, useCallback } from 'react';
import { Alert } from 'react-native';
import { useTranslation } from 'react-i18next';
import NearbyParkingService from '../services/NearbyParkingService';
import { useConnectivity } from './useConnectivity';
import { useAuth } from './useAuth';

/**
 * Hook personalizado para gerenciar a busca de estacionamentos próximos
 * a um ponto de interesse específico
 * 
 * @param {string} poiId - ID do ponto de interesse
 * @param {number} radius - Raio de busca em metros (padrão: 200m)
 * @param {object} truckSpecs - Especificações do caminhão
 * @returns {object} - Dados de estacionamentos e métodos relacionados
 */
export const useNearbyParking = (poiId, radius = 200, truckSpecs) => {
  const [parkingOptions, setParkingOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { t } = useTranslation();
  const { isConnected } = useConnectivity();
  const { user } = useAuth();

  // Função para buscar estacionamentos próximos
  const fetchNearbyParking = useCallback(async () => {
    if (!poiId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const options = await NearbyParkingService.findNearbyParkingForPoi(
        poiId,
        radius,
        truckSpecs
      );
      
      setParkingOptions(options);
    } catch (err) {
      console.error('Error fetching nearby parking:', err);
      setError(err.message || t('errors.unknownError'));
      
      // Se estiver offline, tenta carregar dados locais
      if (!isConnected) {
        try {
          const localOptions = await NearbyParkingService.findNearbyParkingOffline(
            poiId,
            radius,
            truckSpecs
          );
          
          if (localOptions.length > 0) {
            setParkingOptions(localOptions);
            setError(null); // Limpa o erro se conseguiu dados locais
          }
        } catch (localErr) {
          console.error('Error fetching local parking data:', localErr);
        }
      }
    } finally {
      setLoading(false);
    }
  }, [poiId, radius, truckSpecs, isConnected, t]);

  // Efeito para carregar dados quando o componente montar ou dependências mudarem
  useEffect(() => {
    fetchNearbyParking();
  }, [fetchNearbyParking]);

  // Função para adicionar uma nova opção de estacionamento
  const addParkingOption = useCallback(async (newParkingSpot) => {
    try {
      setLoading(true);
      
      // Adiciona informações do usuário que reportou
      const enrichedParkingSpot = {
        ...newParkingSpot,
        isUserReported: true,
        reportedBy: user.id,
        reportedAt: new Date().toISOString()
      };
      
      // Salva no serviço
      const parkingId = await NearbyParkingService.addNewParkingSpot(enrichedParkingSpot);
      
      if (parkingId) {
        // Recalcula a distância até o POI
        const distanceResult = await NearbyParkingService.calculateDistanceBetweenPoints(
          poiId,
          parkingId
        );
        
        // Cria o objeto de resultado completo
        const newOption = {
          parkingSpot: {
            ...enrichedParkingSpot,
            id: parkingId
          },
          distanceToPoi: distanceResult.distance,
          securityRating: 5.0, // Rating padrão inicial
          walkingTimeMins: distanceResult.walkingTime
        };
        
        // Adiciona à lista atual
        setParkingOptions(current => [...current, newOption].sort((a, b) => 
          a.distanceToPoi - b.distanceToPoi
        ));
        
        Alert.alert(
          t('parking.success'),
          t('parking.parkingAddedSuccess'),
          [{ text: t('common.ok') }]
        );
        
        return parkingId;
      }
    } catch (err) {
      console.error('Error adding parking spot:', err);
      Alert.alert(
        t('common.error'),
        t('parking.errorAddingParking'),
        [{ text: t('common.ok') }]
      );
      return null;
    } finally {
      setLoading(false);
    }
  }, [poiId, user, t]);

  // Função para atualizar a avaliação de segurança de um estacionamento
  const updateSecurityRating = useCallback(async (parkingId, newRating) => {
    try {
      await NearbyParkingService.saveSecurityRating(parkingId, newRating);
      
      // Atualiza o estado local
      setParkingOptions(current => 
        current.map(option => 
          option.parkingSpot.id === parkingId
            ? {
                ...option,
                securityRating: (option.securityRating * option.parkingSpot.reviewCount + newRating) / 
                                (option.parkingSpot.reviewCount + 1)
              }
            : option
        )
      );
      
      return true;
    } catch (err) {
      console.error('Error updating security rating:', err);
      return false;
    }
  }, []);

  return {
    parkingOptions,
    loading,
    error,
    refreshParkingOptions: fetchNearbyParking,
    addParkingOption,
    updateSecurityRating
  };
};

export default useNearbyParking;