import React, { useState, useEffect } from 'react';
import { MapPin, ChevronRight, ArrowDown, Navigation } from 'lucide-react';

const EscapeAreasSidebar = ({ 
  visible = false,
  escapeAreas = [],
  userLocation, 
  userSpeed,
  onNavigateToArea 
}) => {
  const [expanded, setExpanded] = useState(false);
  const [sortedAreas, setSortedAreas] = useState([]);
  
  // Valores padrão seguros para props potencialmente indefinidas
  const safeUserLocation = userLocation || { latitude: 0, longitude: 0 };
  const safeUserSpeed = userSpeed || 0;
  const safeEscapeAreas = escapeAreas || [];
  
  // Ordenar áreas de escape por distância quando a localização mudar
  useEffect(() => {
    if (!safeUserLocation) return;
    
    const sorted = [...safeEscapeAreas].sort((a, b) => {
      const distA = calculateDistance(safeUserLocation, a.coordinates);
      const distB = calculateDistance(safeUserLocation, b.coordinates);
      return distA - distB;
    });
    
    setSortedAreas(sorted);
  }, [safeEscapeAreas, safeUserLocation]);
  
  // Calcular distância entre coordenadas
  const calculateDistance = (coord1, coord2) => {
    if (!coord1 || !coord2) return 0;
    
    const R = 6371; // Raio da Terra em km
    const dLat = (coord2.latitude - coord1.latitude) * Math.PI / 180;
    const dLon = (coord2.longitude - coord1.longitude) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(coord1.latitude * Math.PI / 180) * Math.cos(coord2.latitude * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };
  
  // Calcular tempo estimado até a área
  const calculateETA = (coordinates) => {
    if (!safeUserSpeed || !safeUserLocation) return 'Calculando...';
    
    const distance = calculateDistance(safeUserLocation, coordinates);
    const timeInHours = distance / safeUserSpeed;
    const timeInMinutes = timeInHours * 60;
    
    if (timeInMinutes < 1) {
      return 'Menos de 1 min';
    }
    
    return `${Math.round(timeInMinutes)} min`;
  };
  
  // Não renderizar nada se não estiver visível
  if (!visible) return null;
  
  return (
    <div 
      className={`fixed left-0 top-1/4 max-w-xs z-30 transition-all duration-500 ease-in-out transform ${expanded ? 'translate-x-0' : 'translate-x-[-90%]'}`}
      style={{maxHeight: '60vh'}}
    >
      {/* Botão de expansão/contração */}
      <button 
        className="absolute right-0 top-0 transform translate-x-full bg-gray-800 p-2 rounded-r-md"
        onClick={() => setExpanded(!expanded)}
      >
        <ChevronRight 
          size={24} 
          className={`text-amber-400 transition-transform duration-300 ${expanded ? 'rotate-0' : 'rotate-180'}`} 
        />
      </button>
      
      {/* Conteúdo principal */}
      <div className="bg-gray-900 border-r border-amber-500 rounded-r-lg shadow-lg overflow-hidden flex flex-col" 
           style={{maxHeight: '60vh'}}>
        {/* Cabeçalho */}
        <div className="bg-amber-600 p-3 border-b border-gray-700">
          <h3 className="font-bold text-black flex items-center">
            <ArrowDown size={20} className="mr-2" />
            ÁREAS DE ESCAPE NA ROTA
          </h3>
        </div>
        
        {/* Lista de áreas de escape */}
        <div className="overflow-y-auto flex-grow">
          {sortedAreas.length > 0 ? (
            <div className="divide-y divide-gray-800">
              {sortedAreas.map((area, index) => (
                <div 
                  key={index} 
                  className="p-3 hover:bg-gray-800 cursor-pointer transition-colors"
                  onClick={() => typeof onNavigateToArea === 'function' && onNavigateToArea(area)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-start">
                      <MapPin size={16} className="text-amber-500 mt-1 mr-1" />
                      <div>
                        <p className="font-medium text-white">{area.name}</p>
                        <p className="text-xs text-gray-400">{area.description}</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-end ml-2">
                      <span className="text-sm font-bold text-white">
                        {calculateDistance(safeUserLocation, area.coordinates).toFixed(1)} km
                      </span>
                      <span className="text-xs text-gray-400">
                        {calculateETA(area.coordinates)}
                      </span>
                    </div>
                  </div>
                  
                  {/* Barra de progresso - quão próximo está */}
                  <div className="mt-2 bg-gray-700 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className="bg-amber-500 h-full rounded-full"
                      style={{ width: `${Math.min(100, 100 - (calculateDistance(safeUserLocation, area.coordinates) / 0.2) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-400">
              Nenhuma área de escape detectada nesta rota.
            </div>
          )}
        </div>
        
        {/* Botão de navegação para a mais próxima */}
        {sortedAreas.length > 0 && (
          <div className="p-3 bg-gray-800 border-t border-gray-700">
            <button
              className="w-full py-2 px-3 bg-amber-600 hover:bg-amber-700 text-black font-medium rounded flex items-center justify-center"
              onClick={() => typeof onNavigateToArea === 'function' && onNavigateToArea(sortedAreas[0])}
            >
              <Navigation size={16} className="mr-2" />
              Navegar para a Mais Próxima
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default EscapeAreasSidebar;