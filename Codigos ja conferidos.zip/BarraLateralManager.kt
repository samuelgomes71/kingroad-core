package com.kingroad.services

import com.kingroad.database.entities.PontoRota
import com.kingroad.utils.GPSUtils
import com.kingroad.native.NativeEventEmitter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Gerenciador da barra lateral de navegação que identifica e organiza os pontos
 * na rota com base na posição atual do veículo e na direção de condução.
 */
class BarraLateralManager(
    private val nativeEventEmitter: NativeEventEmitter,
    private val gpsUtils: GPSUtils
) {
    // Estado dos pontos da rota que serão exibidos na barra lateral
    private val _pontosRota = MutableStateFlow<List<PontoRotaUI>>(emptyList())
    val pontosRota: StateFlow<List<PontoRotaUI>> = _pontosRota.asStateFlow()

    // Estado de visibilidade da barra
    private val _barraVisivel = MutableStateFlow(true)
    val barraVisivel: StateFlow<Boolean> = _barraVisivel.asStateFlow()

    /**
     * Atualiza a lista de pontos com base na rota atual e na posição do veículo
     */
    fun atualizarPontosRota(pontosRota: List<PontoRota>, posicaoAtual: Pair<Double, Double>, direcaoAtual: Float) {
        val pontosProcessados = pontosRota.mapNotNull { ponto ->
            processarPonto(ponto, posicaoAtual, direcaoAtual)
        }.sortedBy { it.distancia }
        
        _pontosRota.value = pontosProcessados
        
        // Enviar para camada React
        nativeEventEmitter.emitEvent("PONTOS_ROTA_ATUALIZADOS", pontosProcessados)
    }

    /**
     * Processa um ponto da rota e determina se está no mesmo sentido de condução
     */
    private fun processarPonto(
        ponto: PontoRota, 
        posicaoAtual: Pair<Double, Double>, 
        direcaoAtual: Float
    ): PontoRotaUI? {
        // Calcula a distância do ponto atual
        val distancia = gpsUtils.calcularDistanciaEmKm(
            posicaoAtual.first, posicaoAtual.second,
            ponto.latitude, ponto.longitude
        )
        
        // Se distância for maior que 200km, não exibir na barra
        if (distancia > 200.0) return null
        
        // Determina o sentido do ponto em relação à direção de condução
        val mesmoSentido = determinarSentidoDoTrafego(ponto, direcaoAtual)
        
        // Para áreas de descanso e postos de combustível, verificar se há acesso do lado contrário
        val acessoContrario = if (!mesmoSentido && (ponto.tipo == "AREA_DESCANSO" || ponto.tipo == "POSTO_COMBUSTIVEL")) {
            ponto.temAcessoContrario ?: false
        } else {
            false
        }
        
        // Somente mostrar pontos no sentido contrário se tiverem acesso
        if (!mesmoSentido && !acessoContrario) return null
        
        return PontoRotaUI(
            id = ponto.id,
            nome = ponto.nome,
            distancia = distancia,
            tipo = mapearTipo(ponto.tipo),
            mesmoSentido = mesmoSentido,
            comprimento = ponto.comprimento,
            atraso = ponto.atrasoEstimado
        )
    }
    
    /**
     * Determina se o ponto está no mesmo sentido da direção de condução atual
     */
    private fun determinarSentidoDoTrafego(ponto: PontoRota, direcaoAtual: Float): Boolean {
        // Se for um ponto sem direção específica (como um POI), considerar mesmo sentido
        if (ponto.direcaoRodovia == null) return true
        
        // Compara a direção do ponto com a direção atual de condução
        val diferenca = Math.abs(ponto.direcaoRodovia - direcaoAtual)
        return diferenca <= 45 || diferenca >= 315
    }
    
    /**
     * Mapeia o tipo do ponto da base de dados para o tipo de exibição no UI
     */
    private fun mapearTipo(tipo: String): String = when (tipo) {
        "PEDAGIO" -> "pedagio"
        "CONGESTIONAMENTO" -> "congestionamento"
        "ACIDENTE" -> "acidente"
        "OBRAS" -> "obras"
        "POSTO_COMBUSTIVEL" -> "poi"
        "AREA_DESCANSO" -> "poi"
        "PONTO_INTERESSE" -> "poi"
        "PONTE_PEDAGIO" -> "pedagio"
        else -> "poi"
    }
    
    /**
     * Alterna a visibilidade da barra lateral
     */
    fun alternarVisibilidade() {
        _barraVisivel.value = !_barraVisivel.value
        nativeEventEmitter.emitEvent("BARRA_LATERAL_VISIBILIDADE", _barraVisivel.value)
    }
}

/**
 * Modelo UI de um ponto de rota para exibição na barra lateral
 */
data class PontoRotaUI(
    val id: String,
    val nome: String,
    val distancia: Double,
    val tipo: String,
    val mesmoSentido: Boolean,
    val comprimento: Double? = null,
    val atraso: Int? = null
)