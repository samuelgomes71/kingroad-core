// water_pois_global_reference.js
export const waterPOIs = [
  {
    type: "Fonte Natural",
    global: true,
    appliesToAllCountriesFromGlobalReference: true,
    icon: "natural_spring",
    description: {
      "pt-BR": "Fonte de água potável natural. Pode ser usada para reabastecimento.",
      "en-US": "Natural spring with drinkable water. Useful for refilling.",
      "pt-PT": "Fonte natural de água potável. Útil para reabastecer."
    },
    visibilityRules: {
      vehicleTypes: [
        "car",
        "truck"
      ],
      highlightFor: [
        "truck"
      ]
    },
    regionsWithKnownAvailability: [
      "PT",
      "ES"
    ]
  },
  {
    type: "Torneira para caminhoneiros",
    global: true,
    appliesToAllCountriesFromGlobalReference: true,
    icon: "water_tap",
    description: {
      "pt-BR": "Torneira para encher galões de água. Pode não ser potável.",
      "en-US": "Tap for filling water containers. May not be drinkable.",
      "pt-PT": "Torneira para encher garrafões de água. Pode não ser potável."
    },
    visibilityRules: {
      vehicleTypes: [
        "truck"
      ],
      highlightFor: [
        "truck"
      ]
    },
    regionsWithKnownAvailability: [
      "PT",
      "ES"
    ]
  }
];

export default waterPOIs;