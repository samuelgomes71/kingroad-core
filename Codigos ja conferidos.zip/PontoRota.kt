package com.kingroad.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

/**
 * Entidade que representa um ponto na rota de navegação
 * Inclui pontos de interesse, pedágios, congestionamentos, etc.
 */
@Entity(tableName = "pontos_rota")
data class PontoRota(
    @PrimaryKey
    val id: String,
    
    @ColumnInfo(name = "nome")
    val nome: String,
    
    @ColumnInfo(name = "latitude")
    val latitude: Double,
    
    @ColumnInfo(name = "longitude")
    val longitude: Double,
    
    @ColumnInfo(name = "tipo")
    val tipo: String,
    
    @ColumnInfo(name = "direcao_rodovia")
    val direcaoRodovia: Float? = null,
    
    @ColumnInfo(name = "tem_acesso_contrario")
    val temAcessoContrario: Boolean? = false,
    
    @ColumnInfo(name = "distancia_rota")
    val distanciaRota: Double? = null,
    
    @ColumnInfo(name = "comprimento")
    val comprimento: Double? = null,
    
    @ColumnInfo(name = "atraso_estimado")
    val atrasoEstimado: Int? = null,
    
    @ColumnInfo(name = "data_inicio")
    val dataInicio: Long? = null,
    
    @ColumnInfo(name = "data_fim")
    val dataFim: Long? = null,
    
    @ColumnInfo(name = "icone_url")
    val iconeUrl: String? = null,
    
    @ColumnInfo(name = "descricao")
    val descricao: String? = null,
    
    @ColumnInfo(name = "id_rota")
    val idRota: String? = null
)