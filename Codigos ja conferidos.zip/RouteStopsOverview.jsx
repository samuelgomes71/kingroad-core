import React, { useState } from 'react';
import { ChevronDown, ChevronUp, X, MapPin, Clock, AlertCircle } from 'lucide-react';

const RouteStopsOverview = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Estado simulado de uma rota com paradas
  const [routeData] = useState({
    totalDistance: 986.9,
    totalTime: "12h 33m",
    stops: [
      {
        id: 1,
        name: "Petro-Canada Gas Station & Petro-Pass Truck Stop",
        distance: 54.6,
        timeToReach: "40mins",
        arrivalTime: "8:35 AM EST",
        type: "fuel" // fuel, rest, delivery, etc
      },
      {
        id: 2,
        name: "Halte-routière des Monadnocks, St-Philippe",
        distance: 45.6,
        timeToReach: "38mins",
        arrivalTime: "9:13 AM EST",
        type: "rest"
      },
      {
        id: 3,
        name: "38 James Boyle Dr, East Hants",
        distance: 886.7,
        timeToReach: "11h 15m",
        arrivalTime: "9:28 PM AST",
        type: "delivery"
      }
    ]
  });

  // Componente para mostrar o resumo compacto
  const CompactView = () => (
    <div 
      className="bg-white rounded-t-lg shadow-lg p-4 cursor-pointer"
      onClick={() => setIsExpanded(true)}
    >
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <div className="bg-blue-100 rounded-full w-6 h-6 flex items-center justify-center mr-2">
            <span className="text-blue-600 text-sm">1</span>
          </div>
          <div className="flex-1 mr-4">
            <h3 className="text-gray-800 font-medium truncate">{routeData.stops[0].name}</h3>
            <div className="flex items-center text-sm text-gray-600 mt-1">
              <span className="font-medium">{routeData.stops[0].distance}km</span>
              <span className="mx-2">|</span>
              <span>{routeData.stops[0].timeToReach}</span>
              <span className="mx-2">|</span>
              <span>{routeData.stops[0].arrivalTime}</span>
            </div>
          </div>
        </div>
        <ChevronDown className="text-gray-400" />
      </div>
    </div>
  );

  // Componente para a visão expandida
  const ExpandedView = () => (
    <div className="bg-white rounded-lg shadow-lg">
      {/* Cabeçalho com informações totais */}
      <div className="p-4 border-b">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-bold text-gray-800">Entire Trip</h2>
          <button 
            onClick={() => setIsExpanded(false)}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </button>
        </div>
        <div className="flex items-center text-gray-600">
          <span className="font-medium">{routeData.totalDistance} km</span>
          <span className="mx-2">|</span>
          <span>{routeData.totalTime}</span>
        </div>
      </div>

      {/* Lista de paradas */}
      <div className="divide-y">
        {routeData.stops.map((stop, index) => (
          <div key={stop.id} className="p-4 hover:bg-gray-50">
            <div className="flex items-start">
              <div className="bg-blue-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1">
                <span className="text-blue-600 text-sm">{index + 1}</span>
              </div>
              <div className="flex-1">
                <h3 className="text-gray-800 font-medium">{stop.name}</h3>
                <div className="flex items-center text-sm text-gray-600 mt-1">
                  <span className="font-medium">{stop.distance}km</span>
                  <span className="mx-2">|</span>
                  <span>{stop.timeToReach}</span>
                  <span className="mx-2">|</span>
                  <span>{stop.arrivalTime}</span>
                </div>

                {/* Ícones e indicadores específicos do tipo de parada */}
                <div className="flex items-center mt-2">
                  {stop.type === 'fuel' && (
                    <div className="flex items-center text-green-600 text-sm">
                      <AlertCircle size={16} className="mr-1" />
                      <span>Posto de Combustível</span>
                    </div>
                  )}
                  {stop.type === 'rest' && (
                    <div className="flex items-center text-blue-600 text-sm">
                      <Clock size={16} className="mr-1" />
                      <span>Área de Descanso</span>
                    </div>
                  )}
                  {stop.type === 'delivery' && (
                    <div className="flex items-center text-purple-600 text-sm">
                      <MapPin size={16} className="mr-1" />
                      <span>Ponto de Entrega</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Botão de remoção da parada */}
              <button className="text-gray-400 hover:text-red-500">
                <X size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Botões de ação */}
      <div className="p-4 bg-gray-50 rounded-b-lg flex justify-between">
        <button className="text-blue-600 font-medium">
          Adicionar Parada
        </button>
        <button className="text-gray-600 font-medium">
          Otimizar Rota
        </button>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-x-0 bottom-0 max-w-xl mx-auto">
      {isExpanded ? <ExpandedView /> : <CompactView />}
    </div>
  );
};

export default RouteStopsOverview;