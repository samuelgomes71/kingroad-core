package com.kingroad.services

import android.location.Location
import android.location.LocationManager
import android.util.Log

class GpsCalibrator(private val locationManager: LocationManager) {

    fun calibrateGps() {
        val lastLocation = getLastKnownLocation()
        
        if (lastLocation != null) {
            if (isGpsDescalibrado(lastLocation)) {
                Log.w("GpsCalibrator", "⚠️ GPS descalibrado! Tentando recalibrar...")
                resetGps()
            } else {
                Log.i("GpsCalibrator", "✅ GPS calibrado corretamente.")
            }
        } else {
            Log.e("GpsCalibrator", "❌ Não foi possível obter a localização atual.")
        }
    }

    private fun getLastKnownLocation(): Location? {
        return try {
            locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        } catch (e: SecurityException) {
            Log.e("GpsCalibrator", "❌ Permissão de GPS não concedida.")
            null
        }
    }

    private fun isGpsDescalibrado(location: Location): Boolean {
        val referenceLatitude = 45.4215 // Exemplo de referência
        val referenceLongitude = -75.6972
        val errorMargin = 0.0003
        
        return (Math.abs(location.latitude - referenceLatitude) > errorMargin || 
                Math.abs(location.longitude - referenceLongitude) > errorMargin)
    }

    private fun resetGps() {
        // Tentativa de reset do GPS
        try {
            Log.d("GpsCalibrator", "🔄 Reiniciando o GPS...")
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "delete_aiding_data", null)
            Log.d("GpsCalibrator", "✅ GPS recalibrado com sucesso!")
        } catch (e: Exception) {
            Log.e("GpsCalibrator", "❌ Falha ao resetar o GPS: ${e.message}")
        }
    }
}
