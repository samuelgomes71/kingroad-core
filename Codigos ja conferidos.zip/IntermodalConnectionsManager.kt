package com.kingroad.navigation.intermodal

import android.location.Location
import androidx.compose.runtime.Immutable
import com.kingroad.data.AppPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Gerenciador de conexões intermodais (balsas, ferries e túneis) para o KingRoad.
 * 
 * Esta classe é responsável por:
 * 1. Armazenar e atualizar o banco de dados global de conexões intermodais
 * 2. Detectar rotas que exigem travessias especiais
 * 3. Fornecer opções de rota com/sem conexões intermodais
 * 4. Gerenciar as preferências do usuário relacionadas a conexões intermodais
 */
class IntermodalConnectionsManager(
    private val repository: IntermodalConnectionRepository,
    private val preferences: AppPreferences
) {
    // Estado observável das preferências de navegação do usuário
    private val _routePreferences = MutableStateFlow(RoutePreferences())
    val routePreferences: StateFlow<RoutePreferences> = _routePreferences.asStateFlow()
    
    // Estado atual das conexões próximas à localização do usuário
    private val _nearbyConnections = MutableStateFlow<List<IntermodalConnection>>(emptyList())
    val nearbyConnections: StateFlow<List<IntermodalConnection>> = _nearbyConnections.asStateFlow()
    
    init {
        // Carregar preferências salvas
        loadSavedPreferences()
    }
    
    /**
     * Encontra conexões intermodais ao longo de uma rota proposta
     * @param startLocation Ponto de origem
     * @param endLocation Ponto de destino
     * @return Lista de conexões intermodais no caminho
     */
    suspend fun findConnectionsOnRoute(
        startLocation: Location,
        endLocation: Location
    ): List<IntermodalConnection> {
        // Implementação real faria uma consulta no banco de dados de conexões
        // e cruzaria com a rota calculada
        return repository.findConnectionsBetween(startLocation, endLocation)
    }
    
    /**
     * Atualiza as preferências do usuário para rotas com conexões intermodais
     * @param preferences Novas preferências
     */
    suspend fun updateRoutePreferences(preferences: RoutePreferences) {
        _routePreferences.value = preferences
        savePreferences(preferences)
    }
    
    /**
     * Encontra rotas alternativas quando uma conexão intermodal é evitada
     * @param startLocation Ponto de origem
     * @param endLocation Ponto de destino
     * @param avoidedConnection Conexão a ser evitada
     * @return Lista de rotas alternativas
     */
    suspend fun findAlternativeRoutes(
        startLocation: Location,
        endLocation: Location,
        avoidedConnection: IntermodalConnection
    ): List<RouteInfo> {
        // Na implementação real, consultaria o serviço de roteamento
        // com parâmetros para evitar certas conexões
        return repository.findAlternativeRoutes(startLocation, endLocation, avoidedConnection)
    }
    
    /**
     * Atualiza conexões próximas à localização atual do usuário
     * @param currentLocation Localização atual do usuário
     * @param radiusInKm Raio de busca em quilômetros
     */
    suspend fun updateNearbyConnections(currentLocation: Location, radiusInKm: Double = 50.0) {
        val connections = repository.findConnectionsNear(currentLocation, radiusInKm)
        _nearbyConnections.value = connections
    }
    
    /**
     * Obtém detalhes de uma conexão específica
     * @param connectionId ID da conexão
     * @return Detalhes da conexão, se encontrada
     */
    suspend fun getConnectionDetails(connectionId: String): ConnectionDetails? {
        return repository.getConnectionDetails(connectionId)
    }
    
    /**
     * Obtém horários disponíveis para uma conexão específica
     * @param connectionId ID da conexão
     * @param date Data desejada
     * @return Lista de horários disponíveis
     */
    suspend fun getConnectionSchedule(
        connectionId: String,
        date: Long
    ): List<ScheduleEntry> {
        return repository.getSchedule(connectionId, date)
    }
    
    /**
     * Calcula o impacto estimado de uma conexão intermodal na duração total da viagem
     * @param connection Conexão a ser avaliada
     * @param arrivalTime Horário previsto de chegada à conexão
     * @return Impacto estimado em minutos, incluindo tempo de espera
     */
    fun estimateConnectionImpact(connection: IntermodalConnection, arrivalTime: Long): Int {
        // Implementação real consideraria horários de partida, tempos de espera médios, etc.
        return connection.averageDuration + connection.averageWaitingTime
    }
    
    // Métodos privados para gerenciamento de preferências
    
    private fun loadSavedPreferences() {
        // Na implementação real, carregaria as preferências de AppPreferences
        // Por enquanto, usando valores padrão
        _routePreferences.value = RoutePreferences(
            avoidFerries = false,
            avoidTunnels = false,
            preferFastestRoute = true,
            maxCostForIntermodal = 200.0
        )
    }
    
    private suspend fun savePreferences(preferences: RoutePreferences) {
        // Salvar preferências usando AppPreferences
        preferences.apply {
            this@IntermodalConnectionsManager.preferences.putBoolean("avoid_ferries", avoidFerries)
            this@IntermodalConnectionsManager.preferences.putBoolean("avoid_tunnels", avoidTunnels)
            this@IntermodalConnectionsManager.preferences.putBoolean("prefer_fastest_route", preferFastestRoute)
            this@IntermodalConnectionsManager.preferences.putDouble("max_cost_intermodal", maxCostForIntermodal)
        }
    }
}

/**
 * Modelo de dados para conexões intermodais (balsas, ferries, túneis)
 */
@Immutable
@Serializable
data class IntermodalConnection(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ConnectionType,
    val startLocation: GeoPoint,
    val endLocation: GeoPoint,
    val distance: Double, // em quilômetros
    val averageDuration: Int, // em minutos
    val averageWaitingTime: Int = 0, // em minutos
    val baseFee: Double? = null, // valor base, pode ser nulo se gratuito
    val currency: String = "EUR", // Moeda padrão
    val hasSchedule: Boolean = true, // Se opera em horários fixos
    val operatesAllYear: Boolean = true // Se opera durante todo o ano
)

/**
 * Tipos de conexão intermodal
 */
enum class ConnectionType {
    FERRY, // Balsa/Ferry para veículos e passageiros
    PASSENGER_FERRY, // Apenas para passageiros
    CAR_TUNNEL, // Túnel para carros
    TRUCK_TUNNEL, // Túnel para caminhões
    TRAIN_TUNNEL, // Túnel para trens (ex: Eurotúnel com serviço para veículos)
    BRIDGE_TOLL // Ponte com pedágio
}

/**
 * Modelo para preferências de rota
 */
@Immutable
data class RoutePreferences(
    val avoidFerries: Boolean = false,
    val avoidTunnels: Boolean = false,
    val preferFastestRoute: Boolean = true,
    val maxCostForIntermodal: Double = Double.MAX_VALUE // Custo máximo em moeda padrão
)

/**
 * Representação simplificada de um ponto geográfico
 */
@Immutable
@Serializable
data class GeoPoint(
    val latitude: Double,
    val longitude: Double,
    val name: String? = null
)

/**
 * Informações detalhadas sobre uma conexão
 */
@Immutable
@Serializable
data class ConnectionDetails(
    val connection: IntermodalConnection,
    val description: String,
    val paymentMethods: List<String>,
    val facilityFeatures: List<String>,
    val restrictions: List<String>,
    val contactInfo: String? = null,
    val websiteUrl: String? = null,
    val imageUrl: String? = null
)

/**
 * Modelo para uma entrada na programação de horários
 */
@Immutable
@Serializable
data class ScheduleEntry(
    val departureTime: Long, // timestamp
    val arrivalTime: Long, // timestamp
    val availableVehicleSpots: Int? = null,
    val availablePassengerSpots: Int? = null,
    val currentFee: Double? = null // tarifa atual, pode variar do valor base
)

/**
 * Informações sobre uma rota calculada
 */
@Immutable
data class RouteInfo(
    val id: String = UUID.randomUUID().toString(),
    val startPoint: GeoPoint,
    val endPoint: GeoPoint,
    val distance: Double, // em quilômetros
    val duration: Int, // em minutos
    val intermodalConnections: List<IntermodalConnection>,
    val totalCost: Double, // custo total incluindo todas as conexões
    val currency: String = "EUR"
)