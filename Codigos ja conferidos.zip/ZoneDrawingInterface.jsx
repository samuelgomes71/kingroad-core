import React, { useState, useRef } from 'react';
import { MapPin, Settings, Undo, Check, Circle, Square, Pen } from 'lucide-react';

const ZoneDrawingInterface = () => {
  const [drawMode, setDrawMode] = useState('none');
  const [points, setPoints] = useState([]);
  const [isDrawing, setIsDrawing] = useState(false);
  
  const handleTouchStart = (e) => {
    const touch = e.touches[0];
    const point = {
      x: touch.clientX,
      y: touch.clientY
    };
    
    setIsDrawing(true);
    if (drawMode === 'freeform') {
      setPoints([...points, point]);
    } else if (drawMode === 'street') {
      setPoints([point]);
    }
  };
  
  const handleTouchMove = (e) => {
    if (!isDrawing) return;
    
    const touch = e.touches[0];
    const point = {
      x: touch.clientX,
      y: touch.clientY
    };
    
    if (drawMode === 'freeform') {
      setPoints([...points, point]);
    } else if (drawMode === 'street') {
      setPoints([points[0], point]);
    }
  };
  
  const handleTouchEnd = () => {
    setIsDrawing(false);
    if (drawMode === 'street') {
      // Finaliza o desenho da rua
      saveZone();
    }
  };

  return (
    <div className="h-screen bg-[#121212]">
      {/* Barra superior */}
      <div className="bg-[#1E1E1E] p-4 flex justify-between items-center">
        <h1 className="text-gray-200 text-xl font-bold">Demarcar Zona de Risco</h1>
        <MapPin size={24} className="text-gray-400" />
      </div>

      {/* Área de desenho */}
      <div 
        className="flex-1 bg-[#252525] relative"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* SVG para renderizar o desenho */}
        <svg className="w-full h-full absolute top-0 left-0">
          {drawMode === 'freeform' && points.length > 0 && (
            <path
              d={`M ${points[0].x} ${points[0].y} ${points.slice(1).map(p => `L ${p.x} ${p.y}`).join(' ')}`}
              stroke="#FF4444"
              strokeWidth="2"
              fill="none"
            />
          )}
          
          {drawMode === 'street' && points.length === 2 && (
            <line
              x1={points[0].x}
              y1={points[0].y}
              x2={points[1].x}
              y2={points[1].y}
              stroke="#FF4444"
              strokeWidth="4"
            />
          )}
        </svg>

        {/* Instruções de desenho */}
        {drawMode !== 'none' && (
          <div className="absolute top-4 left-4 right-4 bg-[#1A4B81] p-4 rounded-lg">
            <div className="flex items-center space-x-2 text-blue-100">
              <Pen size={20} />
              <span>
                {drawMode === 'freeform' 
                  ? 'Desenhe a área livremente com o dedo' 
                  : 'Marque o início e fim da rua'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Barra de ferramentas */}
      <div className="bg-[#1E1E1E] p-4">
        <div className="flex justify-around mb-4">
          <button 
            onClick={() => setDrawMode('circle')}
            className={`p-4 rounded-lg ${
              drawMode === 'circle' ? 'bg-blue-600' : 'bg-[#252525]'
            }`}
          >
            <Circle size={24} className="text-gray-200" />
          </button>
          
          <button 
            onClick={() => setDrawMode('square')}
            className={`p-4 rounded-lg ${
              drawMode === 'square' ? 'bg-blue-600' : 'bg-[#252525]'
            }`}
          >
            <Square size={24} className="text-gray-200" />
          </button>
          
          <button 
            onClick={() => setDrawMode('freeform')}
            className={`p-4 rounded-lg ${
              drawMode === 'freeform' ? 'bg-blue-600' : 'bg-[#252525]'
            }`}
          >
            <Pen size={24} className="text-gray-200" />
          </button>
          
          <button 
            onClick={() => setDrawMode('street')}
            className={`p-4 rounded-lg ${
              drawMode === 'street' ? 'bg-blue-600' : 'bg-[#252525]'
            }`}
          >
            <MapPin size={24} className="text-gray-200" />
          </button>
        </div>

        {/* Botões de ação */}
        <div className="flex space-x-4">
          <button 
            onClick={() => setPoints([])}
            className="flex-1 bg-[#252525] p-4 rounded-lg text-gray-200 flex items-center justify-center"
          >
            <Undo size={20} className="mr-2" />
            Desfazer
          </button>
          
          <button 
            onClick={() => saveZone()}
            className="flex-1 bg-red-600 p-4 rounded-lg text-white flex items-center justify-center"
          >
            <Check size={20} className="mr-2" />
            Salvar Zona
          </button>
        </div>
      </div>
    </div>
  );
};

export default ZoneDrawingInterface;