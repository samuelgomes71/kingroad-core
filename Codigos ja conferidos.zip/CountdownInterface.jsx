import React from 'react';

const CountdownDisplay = ({ distance, time, speed }) => {
  return (
    <div className="flex gap-4 p-4 bg-gray-900 min-h-[160px]">
      {/* Próximo Comando - Distância */}
      <div className="flex-1 bg-gray-800 rounded-lg p-4 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold text-white mb-4">{distance}</span>
        <div className="w-full h-px bg-gray-700 mb-4"></div>
        <span className="text-lg text-gray-300">Próxima Saída</span>
      </div>

      {/* Cronômetro/Timer */}
      <div className="flex-1 bg-gray-800 rounded-lg p-4 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold text-white mb-4">{time}</span>
        <div className="w-full h-px bg-gray-700 mb-4"></div>
        <span className="text-lg text-gray-300">Tempo Estimado</span>
      </div>

      {/* Próximo Comando com Velocidade */}
      <div className="flex-1 bg-gray-800 rounded-lg p-4 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold text-white mb-2">{distance}</span>
        <span className="text-2xl font-bold text-green-400 mb-4">{speed}</span>
        <div className="w-full h-px bg-gray-700 mb-4"></div>
        <span className="text-lg text-gray-300">Velocidade Ideal</span>
      </div>
    </div>
  );
};

// Componente de demonstração
const CountdownInterface = () => {
  return (
    <CountdownDisplay
      distance="500m"
      time="2:30"
      speed="80 km/h"
    />
  );
};

export default CountdownInterface;