import React, { useState, useRef, useEffect } from 'react';
import { Camera, ImagePlus, X, RotateCw, Upload, Check, Trash } from 'lucide-react';

/**
 * Componente que permite ao motorista tirar foto (ou escolher arquivo)
 * e visualizar antes de anexar a um POI ou alerta.
 * 
 * @param {Object} props Propriedades do componente
 * @param {Function} props.onImageSelected Callback quando uma imagem é selecionada e confirmada
 * @param {Function} props.onCancel Callback quando o usuário cancela a operação
 * @param {string} props.title Título do componente
 * @param {string} props.acceptTypes Tipos de arquivo aceitos (ex: "image/*")
 * @param {boolean} props.allowCamera Permite usar a câmera do dispositivo
 * @param {number} props.maxFileSizeMB Tamanho máximo do arquivo em MB
 * @param {string} props.className Classes CSS adicionais
 */
const ImagePreviewUpload = ({
  onImageSelected,
  onCancel,
  title = "Anexar imagem",
  acceptTypes = "image/*",
  allowCamera = true,
  maxFileSizeMB = 10,
  className = ""
}) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [error, setError] = useState(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [isCameraAvailable, setIsCameraAvailable] = useState(false);
  const [isRotating, setIsRotating] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);

  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  // Verifica se a câmera está disponível
  useEffect(() => {
    if (allowCamera && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      setIsCameraAvailable(true);
    }

    // Cleanup
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [allowCamera]);

  // Cleanup URL do preview quando o componente é desmontado
  useEffect(() => {
    return () => {
      if (previewUrl && previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  // Manipula a seleção de arquivo
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      validateAndSetImage(file);
    }
  };

  // Valida e configura a imagem selecionada
  const validateAndSetImage = (file) => {
    setError(null);

    // Verifica o tipo do arquivo
    if (!file.type.startsWith('image/')) {
      setError('O arquivo selecionado não é uma imagem válida.');
      return;
    }

    // Verifica o tamanho do arquivo
    const maxSizeBytes = maxFileSizeMB * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setError(`O tamanho da imagem excede o limite de ${maxFileSizeMB}MB.`);
      return;
    }

    // Configura a imagem e preview
    setSelectedImage(file);
    const fileUrl = URL.createObjectURL(file);
    setPreviewUrl(fileUrl);
    setRotationAngle(0);
  };

  // Inicia a captura de câmera
  const startCamera = async () => {
    setError(null);
    setIsCapturing(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error("Erro ao acessar a câmera:", err);
      setError("Não foi possível acessar a câmera. Verifique se você concedeu permissões.");
      setIsCapturing(false);
      setIsCameraAvailable(false);
    }
  };

  // Captura a foto da câmera
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Configura o canvas com as dimensões do vídeo
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Desenha o frame atual no canvas
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Converte para blob
      canvas.toBlob((blob) => {
        // Cria um arquivo a partir do blob
        const file = new File([blob], "camera_capture.jpg", { type: "image/jpeg" });
        
        // Para a câmera
        stopCamera();
        
        // Configura a imagem capturada
        validateAndSetImage(file);
      }, 'image/jpeg', 0.9);
    }
  };

  // Para a câmera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsCapturing(false);
  };

  // Confirma a seleção da imagem
  const confirmSelection = () => {
    if (selectedImage) {
      // Se a imagem foi rotacionada, precisamos recriar o arquivo
      if (rotationAngle !== 0 && canvasRef.current) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        
        // Cria uma imagem a partir do preview
        const img = new Image();
        img.onload = () => {
          // Ajusta o tamanho do canvas
          canvas.width = img.height;
          canvas.height = img.width;
          
          // Configura a transformação para a rotação
          ctx.translate(canvas.width / 2, canvas.height / 2);
          ctx.rotate((rotationAngle * Math.PI) / 180);
          ctx.drawImage(img, -img.width / 2, -img.height / 2);
          
          // Converte para blob
          canvas.toBlob((blob) => {
            // Cria um arquivo a partir do blob
            const rotatedFile = new File([blob], selectedImage.name, { 
              type: selectedImage.type 
            });
            
            // Chama o callback com o arquivo rotacionado
            onImageSelected(rotatedFile);
          }, selectedImage.type, 0.9);
        };
        
        img.src = previewUrl;
      } else {
        // Sem rotação, usa o arquivo original
        onImageSelected(selectedImage);
      }
    }
  };

  // Cancela a seleção
  const cancelSelection = () => {
    // Limpa a seleção
    setSelectedImage(null);
    setPreviewUrl(null);
    setRotationAngle(0);
    
    if (isCapturing) {
      stopCamera();
    }
    
    // Chama o callback de cancelamento
    if (onCancel) {
      onCancel();
    }
  };

  // Rotaciona a imagem
  const rotateImage = () => {
    // Adiciona 90 graus à rotação atual
    setIsRotating(true);
    setTimeout(() => {
      setRotationAngle((prev) => (prev + 90) % 360);
      setIsRotating(false);
    }, 50);
  };

  // Remove a imagem selecionada
  const removeImage = () => {
    setSelectedImage(null);
    setPreviewUrl(null);
    setRotationAngle(0);
    
    // Limpa o input de arquivo
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Renderiza o conteúdo baseado no estado atual
  const renderContent = () => {
    if (isCapturing) {
      return (
        <div className="relative w-full h-full flex flex-col items-center">
          <video 
            ref={videoRef} 
            className="w-full max-h-72 bg-black object-contain" 
            autoPlay 
            playsInline
          />
          
          <div className="absolute bottom-4 w-full flex justify-center">
            <button 
              onClick={capturePhoto} 
              className="rounded-full bg-white p-3 shadow-lg"
              aria-label="Capturar foto"
            >
              <div className="rounded-full border-2 border-gray-500 w-12 h-12"></div>
            </button>
          </div>
          
          <button 
            onClick={stopCamera} 
            className="absolute top-2 right-2 bg-gray-800 bg-opacity-50 rounded-full p-1 text-white"
            aria-label="Fechar câmera"
          >
            <X size={24} />
          </button>
        </div>
      );
    }
    
    if (previewUrl) {
      return (
        <div className="relative w-full flex flex-col items-center">
          <div className="relative w-full flex justify-center bg-gray-100 dark:bg-gray-800 rounded-md overflow-hidden" style={{ minHeight: "200px" }}>
            <img 
              src={previewUrl} 
              alt="Preview" 
              className="max-h-72 object-contain transition-transform duration-300 ease-in-out"
              style={{ transform: isRotating ? 'scale(0.8)' : `rotate(${rotationAngle}deg)` }}
            />
            
            <div className="absolute bottom-2 right-2 flex space-x-2">
              <button 
                onClick={rotateImage} 
                className="bg-gray-800 bg-opacity-50 rounded-full p-2 text-white"
                aria-label="Rotacionar imagem"
              >
                <RotateCw size={18} />
              </button>
              
              <button 
                onClick={removeImage} 
                className="bg-red-500 bg-opacity-50 rounded-full p-2 text-white"
                aria-label="Remover imagem"
              >
                <Trash size={18} />
              </button>
            </div>
          </div>
          
          <div className="mt-4 flex space-x-4">
            <button 
              onClick={confirmSelection} 
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <Check size={18} className="mr-2" />
              Confirmar
            </button>
            
            <button 
              onClick={cancelSelection} 
              className="flex items-center px-4 py-2 bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-400 dark:hover:bg-gray-600 transition-colors"
            >
              <X size={18} className="mr-2" />
              Cancelar
            </button>
          </div>
        </div>
      );
    }
    
    return (
      <div className="w-full flex flex-col items-center">
        <div className="w-full p-6 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-md flex flex-col items-center justify-center text-center bg-gray-50 dark:bg-gray-800">
          <div className="space-y-2">
            <div className="flex justify-center">
              <ImagePlus size={36} className="text-gray-400 dark:text-gray-500" />
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              <p className="font-medium">Clique para selecionar</p>
              <p>ou arraste e solte</p>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-500">
              PNG, JPG ou JPEG (máx. {maxFileSizeMB}MB)
            </p>
          </div>
          
          <input
            type="file"
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            accept={acceptTypes}
            onChange={handleFileChange}
            ref={fileInputRef}
          />
        </div>
        
        {isCameraAvailable && (
          <button 
            onClick={startCamera} 
            className="mt-4 flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Camera size={18} className="mr-2" />
            Usar câmera
          </button>
        )}
      </div>
    );
  };

  return (
    <div className={`w-full ${className}`}>
      <div className="mb-3 flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">{title}</h3>
        
        {previewUrl && !isCapturing && (
          <div className="text-xs text-gray-500 dark:text-gray-400">
            {selectedImage && (
              <span>
                {(selectedImage.size / (1024 * 1024)).toFixed(2)} MB
              </span>
            )}
          </div>
        )}
      </div>
      
      {error && (
        <div className="mb-3 p-2 bg-red-100 text-red-700 text-sm rounded-md">
          {error}
        </div>
      )}
      
      {renderContent()}
      
      {/* Canvas oculto para processamento de imagem */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default ImagePreviewUpload;