// Sistema Colaborativo do King Road
// app/src/main/kotlin/com/kingroad/collaborative

// Entidades para locais de interesse
data class TruckStop(
    val id: String,
    val location: Location,
    val name: String,
    val parkingStatus: ParkingStatus? = null,
    val facilities: TruckStopFacilities = TruckStopFacilities(),
    val lastUpdate: Long = System.currentTimeMillis()
)

data class WeighStation(
    val id: String,
    val location: Location,
    val status: WeighStationStatus? = null,
    val inspectionType: InspectionType? = null,
    val waitingTime: Int? = null, // em minutos
    val lastUpdate: Long = System.currentTimeMillis()
)

// Status e tipos de informação colaborativa
enum class ParkingStatus {
    MANY_SPOTS,     // Verde
    SOME_SPOTS,     // Amarelo
    PAID_ONLY,      // Azul
    FULL            // Vermelho
}

enum class WeighStationStatus {
    OPEN,
    CLOSED
}

enum class InspectionType {
    BYPASS_ALLOWED,
    QUICK_WEIGHING,
    FULL_INSPECTION
}

data class TruckStopFacilities(
    val dieselPrice: Double? = null,
    val hasShowers: Boolean = false,
    val restaurantOpen: Boolean = false
)

// Gerenciador de feedback colaborativo
class CollaborativeFeedbackManager(
    private val database: LocalDatabase,
    private val apiService: ApiService
) {
    suspend fun submitTruckStopUpdate(
        truckStopId: String,
        parkingStatus: ParkingStatus,
        facilities: TruckStopFacilities? = null
    ) {
        val update = TruckStopUpdate(
            truckStopId = truckStopId,
            parkingStatus = parkingStatus,
            facilities = facilities,
            timestamp = System.currentTimeMillis()
        )
        
        database.saveTruckStopUpdate(update)
        apiService.sendTruckStopUpdate(update)
    }
    
    suspend fun submitWeighStationUpdate(
        weighStationId: String,
        status: WeighStationStatus,
        inspectionType: InspectionType? = null,
        waitingTime: Int? = null
    ) {
        val update = WeighStationUpdate(
            weighStationId = weighStationId,
            status = status,
            inspectionType = inspectionType,
            waitingTime = waitingTime,
            timestamp = System.currentTimeMillis()
        )
        
        database.saveWeighStationUpdate(update)
        apiService.sendWeighStationUpdate(update)
    }
}

// Sistema de notificações baseado em localização
class ProximityAlertManager(
    private val locationService: LocationService,
    private val notificationService: NotificationService
) {
    private val alertRadius = 5000 // 5km em metros
    
    fun startMonitoring() {
        locationService.requestLocationUpdates { location ->
            checkNearbyTruckStops(location)
            checkNearbyWeighStations(location)
        }
    }
    
    private suspend fun checkNearbyTruckStops(currentLocation: Location) {
        val nearbyStops = database.getNearbyTruckStops(
            location = currentLocation,
            radius = alertRadius
        )
        
        nearbyStops.forEach { stop ->
            notificationService.showTruckStopAlert(
                stop,
                distanceToLocation(currentLocation, stop.location)
            )
        }
    }
    
    private suspend fun checkNearbyWeighStations(currentLocation: Location) {
        val nearbyStations = database.getNearbyWeighStations(
            location = currentLocation,
            radius = alertRadius
        )
        
        nearbyStations.forEach { station ->
            notificationService.showWeighStationAlert(
                station,
                distanceToLocation(currentLocation, station.location)
            )
        }
    }
}

// Sistema de comandos de voz
class VoiceCommandManager(
    private val speechRecognizer: SpeechRecognizer,
    private val feedbackManager: CollaborativeFeedbackManager
) {
    fun startListening() {
        speechRecognizer.startListening { command ->
            processVoiceCommand(command)
        }
    }
    
    private fun processVoiceCommand(command: String) {
        when {
            command.contains("paradas", ignoreCase = true) -> {
                // Processar comandos relacionados a truck stops
            }
            command.contains("balança", ignoreCase = true) -> {
                // Processar comandos relacionados a balanças
            }
            // Adicionar outros comandos conforme necessário
        }
    }
}

// Interface do banco de dados para dados colaborativos
interface CollaborativeDatabase {
    suspend fun saveTruckStopUpdate(update: TruckStopUpdate)
    suspend fun saveWeighStationUpdate(update: WeighStationUpdate)
    suspend fun getNearbyTruckStops(location: Location, radius: Int): List<TruckStop>
    suspend fun getNearbyWeighStations(location: Location, radius: Int): List<WeighStation>
    suspend fun getRecentUpdates(location: Location): List<Update>
}