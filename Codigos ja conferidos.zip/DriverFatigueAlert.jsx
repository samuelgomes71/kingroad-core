import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Vibration } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeModules } from 'react-native';

const { DriverFatigueModule } = NativeModules;

/**
 * Componente que exibe alertas de fadiga ao motorista e sugere locais para pausa
 */
const DriverFatigueAlert = () => {
  const [drivingStatus, setDrivingStatus] = useState('OK');
  const [visibleAlert, setVisibleAlert] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState('');
  const [nearbyRestStops, setNearbyRestStops] = useState([]);
  const fadeAnim = new Animated.Value(0);
  const navigation = useNavigation();

  useEffect(() => {
    // Inscrever-se para receber atualizações do módulo nativo
    const subscription = DriverFatigueModule.addListener('drivingStatusChange', (status) => {
      setDrivingStatus(status.status);
      setTimeRemaining(status.timeRemaining);
      if (status.status !== 'OK') {
        setVisibleAlert(true);
        // Vibrar o dispositivo para alertas críticos
        if (status.status === 'BREAK_REQUIRED' || status.status === 'DAILY_LIMIT_REACHED') {
          Vibration.vibrate([0, 500, 200, 500]);
        }
      } else {
        setVisibleAlert(false);
      }
    });

    return () => {
      subscription.remove();
    };
  }, []);

  useEffect(() => {
    if (visibleAlert) {
      // Buscar pontos de parada próximos
      DriverFatigueModule.findNearbyRestStops()
        .then(stops => setNearbyRestStops(stops))
        .catch(error => console.error('Error fetching rest stops:', error));

      // Animar a entrada do alerta
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
    } else {
      // Animar a saída do alerta
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }).start();
    }
  }, [visibleAlert, fadeAnim]);

  const getStatusColor = () => {
    switch (drivingStatus) {
      case 'BREAK_RECOMMENDED':
        return '#FFA500'; // Laranja
      case 'BREAK_REQUIRED':
        return '#FF0000'; // Vermelho
      case 'APPROACHING_DAILY_LIMIT':
        return '#FFA500'; // Laranja
      case 'DAILY_LIMIT_REACHED':
        return '#FF0000'; // Vermelho
      default:
        return '#00AA00'; // Verde
    }
  };

  const getStatusMessage = () => {
    switch (drivingStatus) {
      case 'BREAK_RECOMMENDED':
        return 'Pausa recomendada em breve';
      case 'BREAK_REQUIRED':
        return 'PARE E DESCANSE! Limite de condução atingido';
      case 'APPROACHING_DAILY_LIMIT':
        return 'Aproximando-se do limite diário de condução';
      case 'DAILY_LIMIT_REACHED':
        return 'PARE AGORA! Limite diário de condução excedido';
      default:
        return 'Tempo de condução OK';
    }
  };

  const handleShowRestStops = () => {
    navigation.navigate('RestStops', { nearbyStops: nearbyRestStops });
  };

  const handleRegisterBreak = () => {
    DriverFatigueModule.registerBreak()
      .then(() => setVisibleAlert(false))
      .catch(error => console.error('Error registering break:', error));
  };

  if (!visibleAlert) return null;

  return (
    <Animated.View 
      style={[
        styles.container, 
        { 
          backgroundColor: getStatusColor(),
          opacity: fadeAnim 
        }
      ]}
    >
      <View style={styles.iconContainer}>
        <Icon name="sleep" size={24} color="#FFFFFF" />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.alertTitle}>{getStatusMessage()}</Text>
        {timeRemaining ? (
          <Text style={styles.timeText}>{timeRemaining}</Text>
        ) : null}
      </View>
      <View style={styles.buttonsContainer}>
        <TouchableOpacity 
          style={styles.button} 
          onPress={handleShowRestStops}
        >
          <Text style={styles.buttonText}>Paradas Próximas</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.button, styles.primaryButton]} 
          onPress={handleRegisterBreak}
        >
          <Text style={styles.buttonText}>Registrar Pausa</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 20,
    left: 10,
    right: 10,
    borderRadius: 8,
    padding: 15,
    flexDirection: 'column',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    zIndex: 1000,
  },
  iconContainer: {
    marginRight: 10,
    alignItems: 'center',
  },
  textContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  alertTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  timeText: {
    color: '#FFFFFF',
    fontSize: 14,
    marginTop: 5,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  button: {
    padding: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginHorizontal: 5,
  },
  primaryButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
});

export default DriverFatigueAlert;