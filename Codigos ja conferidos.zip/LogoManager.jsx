import React, { useState, useEffect } from 'react';

const LogoVariantDisplay = ({ variant }) => {
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simular carregamento da imagem
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [variant]);
  
  // Mapeamento de informações das variantes
  const variantInfo = {
    xs: { name: "Extra Pequeno", inches: "< 5″", size: "160px" },
    sm: { name: "Pequeno", inches: "5-7″", size: "200px" },
    md: { name: "Médio", inches: "7-9″", size: "240px" },
    lg: { name: "Grande", inches: "9-11″", size: "280px" },
    xl: { name: "Extra Grande", inches: "11+″", size: "320px" }
  };
  
  // Informações da variante atual
  const info = variantInfo[variant] || variantInfo.md;
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center bg-black rounded-lg p-4 mb-4">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-yellow-500 mb-2"></div>
        <p className="text-yellow-500 text-sm">Carregando logo {variant}...</p>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center bg-gray-900 rounded-lg p-4 mb-4 border border-gray-800">
      <div className="flex items-center justify-center bg-black rounded-lg p-4 mb-2 w-full">
        {/* Área reservada para a imagem - em produção usaria uma imagem real */}
        <div 
          className="flex items-center justify-center bg-black rounded-full border-2 border-yellow-600"
          style={{ width: info.size, height: info.size }}
        >
          <div className="text-yellow-500 text-center font-bold" style={{ fontSize: parseInt(info.size)/6 }}>
            K
          </div>
        </div>
      </div>
      <div className="text-center mt-2">
        <h3 className="text-yellow-500 font-bold text-lg">Logo {variant.toUpperCase()}</h3>
        <p className="text-gray-400 text-sm">{info.name} ({info.inches})</p>
      </div>
    </div>
  );
};

const LogoManager = () => {
  const [selectedVariant, setSelectedVariant] = useState('md');
  const [deviceSize, setDeviceSize] = useState(null);
  
  useEffect(() => {
    // Detectar tamanho do dispositivo
    const detectDeviceSize = () => {
      const width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      const height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
      
      // Aproximação do DPI
      let dpi = 96;
      if (window.devicePixelRatio) {
        dpi = 96 * window.devicePixelRatio;
      }
      
      // Diagonal em polegadas
      const diagonalPixels = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
      const diagonalInches = diagonalPixels / dpi;
      
      // Determinar variante com base no tamanho
      let variant;
      if (diagonalInches < 5) variant = 'xs';
      else if (diagonalInches < 7) variant = 'sm';
      else if (diagonalInches < 9) variant = 'md';
      else if (diagonalInches < 11) variant = 'lg';
      else variant = 'xl';
      
      setDeviceSize({
        width,
        height,
        diagonalInches: diagonalInches.toFixed(1),
        variant
      });
      
      // Selecionar variante recomendada automaticamente
      setSelectedVariant(variant);
    };
    
    detectDeviceSize();
    window.addEventListener('resize', detectDeviceSize);
    
    return () => window.removeEventListener('resize', detectDeviceSize);
  }, []);
  
  const variants = ['xs', 'sm', 'md', 'lg', 'xl'];
  
  return (
    <div className="bg-gray-900 text-white p-6 rounded-xl max-w-2xl mx-auto shadow-2xl">
      <h1 className="text-2xl font-bold mb-4 text-center text-yellow-500">KingRoad - Logos</h1>
      
      {deviceSize && (
        <div className="mb-6 text-center p-3 bg-black bg-opacity-50 rounded-lg">
          <p className="text-sm text-gray-300">
            Seu dispositivo: <span className="text-yellow-500">{deviceSize.diagonalInches}″</span>
          </p>
          <p className="text-sm text-gray-400">
            Logo recomendado: <span className="font-bold text-yellow-500">{deviceSize.variant.toUpperCase()}</span>
          </p>
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex justify-center space-x-2 mb-4">
          {variants.map(variant => (
            <button
              key={variant}
              onClick={() => setSelectedVariant(variant)}
              className={`px-3 py-1 rounded-full text-sm ${
                selectedVariant === variant 
                  ? 'bg-yellow-600 text-white' 
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              {variant.toUpperCase()}
            </button>
          ))}
        </div>
        
        <LogoVariantDisplay variant={selectedVariant} />
      </div>
      
      <div className="bg-black bg-opacity-50 p-4 rounded-lg text-sm">
        <h3 className="text-yellow-500 font-bold mb-2">Informações técnicas</h3>
        <ul className="space-y-1 text-gray-300">
          <li><span className="text-gray-500">XS:</span> Logo extra pequeno para telas menores que 5 polegadas</li>
          <li><span className="text-gray-500">SM:</span> Logo pequeno para smartphones (5-7 polegadas)</li>
          <li><span className="text-gray-500">MD:</span> Logo médio para tablets pequenos (7-9 polegadas)</li>
          <li><span className="text-gray-500">LG:</span> Logo grande para tablets médios (9-11 polegadas)</li>
          <li><span className="text-gray-500">XL:</span> Logo extra grande para tablets grandes (11+ polegadas)</li>
        </ul>
        <p className="mt-3 text-xs text-gray-400">
          O KingRoad detecta automaticamente o tamanho do seu dispositivo e seleciona a versão 
          otimizada do logo e splash screen.
        </p>
      </div>
    </div>
  );
};

export default LogoManager;