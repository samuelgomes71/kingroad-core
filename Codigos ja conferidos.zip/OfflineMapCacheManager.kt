package com.kingroad.cache

import android.content.Context
import android.util.Log
import com.kingroad.database.MapRegion
import com.kingroad.database.MapRegionDao
import com.kingroad.utils.FileUtils
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.*
import kotlin.math.max
import kotlin.math.min

/**
 * Gerencia o download e armazenamento de mapas regionais para uso offline.
 * Salva arquivos .mbtiles ou similares e fornece visualização embutida.
 */
class OfflineMapCacheManager(
    private val context: Context,
    private val mapRegionDao: MapRegionDao,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    companion object {
        private const val TAG = "OfflineMapCacheManager"
        private const val MAP_CACHE_DIR = "map_cache"
        private const val MAX_ZOOM_LEVEL = 18
        private const val MIN_ZOOM_LEVEL = 10
        private const val DEFAULT_TILE_FORMAT = "png"
        
        // Tamanho aproximado em KB por tile em diferentes níveis de zoom
        private val TILE_SIZE_KB = mapOf(
            10 to 5,
            12 to 10,
            14 to 20,
            16 to 40,
            18 to 80
        )
    }

    // Diretório principal para armazenamento de mapas
    private val mapCacheDir: File by lazy {
        File(context.filesDir, MAP_CACHE_DIR).apply {
            if (!exists()) mkdirs()
        }
    }

    // Controla o estado de download atual
    private val _downloadProgress = MutableStateFlow<DownloadProgress>(DownloadProgress.Idle)
    val downloadProgress: StateFlow<DownloadProgress> = _downloadProgress.asStateFlow()

    // Jobs ativos de download
    private val activeDownloadJobs = mutableMapOf<String, Job>()

    /**
     * Inicia o download de uma região do mapa
     * @param regionName Nome da região (ex: "São Paulo", "Rio de Janeiro")
     * @param bounds Limites geográficos da região (minLat, minLng, maxLat, maxLng)
     * @param maxZoom Nível máximo de zoom a ser baixado (detalhes)
     * @param minZoom Nível mínimo de zoom a ser baixado (visão geral)
     * @return ID único do download para acompanhamento
     */
    fun startMapDownload(
        regionName: String,
        bounds: MapBounds,
        maxZoom: Int = MAX_ZOOM_LEVEL,
        minZoom: Int = MIN_ZOOM_LEVEL
    ): String {
        val downloadId = UUID.randomUUID().toString()
        val sanitizedRegionName = sanitizeFileName(regionName)
        
        // Cria diretório específico para esta região
        val regionDir = File(mapCacheDir, sanitizedRegionName).apply {
            if (!exists()) mkdirs()
        }
        
        // Estima o tamanho total do download
        val estimatedSize = estimateDownloadSize(bounds, minZoom, maxZoom)
        Log.d(TAG, "Tamanho estimado do download para $regionName: $estimatedSize KB")
        
        // Inicia o job de download
        val downloadJob = CoroutineScope(dispatcher).launch {
            try {
                _downloadProgress.value = DownloadProgress.Started(
                    id = downloadId,
                    regionName = regionName,
                    totalSize = estimatedSize,
                    currentProgress = 0
                )
                
                // Download de metadados primeiro
                downloadMetadata(regionName, bounds, regionDir)
                
                // Download dos tiles em ordem de zoom (do menor para o maior)
                for (zoom in minZoom..maxZoom) {
                    if (!isActive) break // Verifica se o job ainda está ativo
                    
                    val tileCount = downloadTilesForZoom(bounds, zoom, regionDir, downloadId, estimatedSize)
                    Log.d(TAG, "Download de $tileCount tiles concluído para zoom $zoom")
                    
                    // Verifica conexão a cada nível de zoom
                    if (!NetworkUtils.isConnected(context)) {
                        _downloadProgress.value = DownloadProgress.Paused(
                            id = downloadId,
                            regionName = regionName,
                            reason = "Conexão perdida"
                        )
                        delay(30000) // Aguarda 30s antes de tentar novamente
                        
                        if (!NetworkUtils.isConnected(context)) {
                            throw Exception("Download cancelado: sem conexão")
                        }
                    }
                }
                
                // Salva os metadados da região no banco de dados
                val region = MapRegion(
                    name = regionName,
                    path = regionDir.absolutePath,
                    minZoom = minZoom,
                    maxZoom = maxZoom,
                    minLat = bounds.minLat,
                    minLng = bounds.minLng,
                    maxLat = bounds.maxLat,
                    maxLng = bounds.maxLng,
                    downloadDate = System.currentTimeMillis(),
                    size = FileUtils.getFolderSizeInKB(regionDir)
                )
                
                mapRegionDao.insert(region)
                
                // Finaliza o download com sucesso
                _downloadProgress.value = DownloadProgress.Completed(
                    id = downloadId,
                    regionName = regionName,
                    totalSize = FileUtils.getFolderSizeInKB(regionDir)
                )
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao baixar mapa: ${e.message}", e)
                _downloadProgress.value = DownloadProgress.Failed(
                    id = downloadId,
                    regionName = regionName,
                    error = e.message ?: "Erro desconhecido"
                )
            } finally {
                activeDownloadJobs.remove(downloadId)
            }
        }
        
        activeDownloadJobs[downloadId] = downloadJob
        return downloadId
    }
    
    /**
     * Cancela um download em andamento
     * @param downloadId ID do download a ser cancelado
     * @return true se cancelado com sucesso, false caso contrário
     */
    fun cancelDownload(downloadId: String): Boolean {
        val job = activeDownloadJobs[downloadId] ?: return false
        job.cancel()
        activeDownloadJobs.remove(downloadId)
        
        val currentProgress = _downloadProgress.value
        if (currentProgress is DownloadProgress.Started && currentProgress.id == downloadId) {
            _downloadProgress.value = DownloadProgress.Cancelled(
                id = downloadId,
                regionName = currentProgress.regionName
            )
        }
        
        return true
    }
    
    /**
     * Pausa um download em andamento
     * @param downloadId ID do download a ser pausado
     * @return true se pausado com sucesso, false caso contrário
     */
    fun pauseDownload(downloadId: String): Boolean {
        // Implementação futura - requer suporte a pause/resume
        // No momento, apenas cancela e registra para retomada posterior
        val job = activeDownloadJobs[downloadId] ?: return false
        job.cancel()
        activeDownloadJobs.remove(downloadId)
        
        val currentProgress = _downloadProgress.value
        if (currentProgress is DownloadProgress.Started && currentProgress.id == downloadId) {
            _downloadProgress.value = DownloadProgress.Paused(
                id = downloadId,
                regionName = currentProgress.regionName,
                reason = "Pausado pelo usuário"
            )
        }
        
        return true
    }
    
    /**
     * Lista todas as regiões de mapa disponíveis offline
     * @return Flow de regiões de mapa disponíveis
     */
    fun getAvailableRegions(): Flow<List<MapRegion>> {
        return mapRegionDao.getAllRegionsFlow()
    }
    
    /**
     * Verifica se uma região de mapa específica está disponível offline
     * @param regionName Nome da região
     * @return true se a região estiver disponível, false caso contrário
     */
    suspend fun isRegionAvailable(regionName: String): Boolean {
        val region = mapRegionDao.getRegionByName(regionName)
        return region != null && File(region.path).exists()
    }
    
    /**
     * Verifica se um ponto específico (lat, lng) está coberto por alguma região offline
     * @param lat Latitude do ponto
     * @param lng Longitude do ponto
     * @return Região que cobre o ponto, ou null se nenhuma região cobrir
     */
    suspend fun getRegionForLocation(lat: Double, lng: Double): MapRegion? {
        val regions = mapRegionDao.getAllRegions()
        return regions.find { region ->
            lat >= region.minLat && lat <= region.maxLat &&
            lng >= region.minLng && lng <= region.maxLng
        }
    }
    
    /**
     * Remove uma região de mapa do armazenamento offline
     * @param regionName Nome da região a ser removida
     * @return true se removida com sucesso, false caso contrário
     */
    suspend fun removeRegion(regionName: String): Boolean {
        val region = mapRegionDao.getRegionByName(regionName) ?: return false
        
        return withContext(dispatcher) {
            val regionDir = File(region.path)
            if (regionDir.exists() && regionDir.isDirectory) {
                val deleted = regionDir.deleteRecursively()
                if (deleted) {
                    mapRegionDao.delete(region)
                }
                deleted
            } else {
                mapRegionDao.delete(region)
                true
            }
        }
    }
    
    /**
     * Obtém o caminho para um tile específico, se disponível offline
     * @param z Nível de zoom
     * @param x Coordenada X do tile
     * @param y Coordenada Y do tile
     * @return Caminho para o arquivo do tile, ou null se não estiver disponível
     */
    suspend fun getTilePath(z: Int, x: Int, y: Int): String? {
        return withContext(dispatcher) {
            val regions = mapRegionDao.getAllRegions()
            
            for (region in regions) {
                if (z < region.minZoom || z > region.maxZoom) continue
                
                val tileFileName = "$z/$x/$y.$DEFAULT_TILE_FORMAT"
                val tileFile = File(region.path, tileFileName)
                
                if (tileFile.exists()) {
                    return@withContext tileFile.absolutePath
                }
            }
            
            null
        }
    }
    
    /**
     * Limpa o cache de tiles temporários não associados a nenhuma região
     */
    suspend fun clearTemporaryCache() {
        withContext(dispatcher) {
            val tempDir = File(context.cacheDir, "map_temp")
            if (tempDir.exists()) {
                tempDir.deleteRecursively()
            }
        }
    }

    /**
     * Estima o tamanho de download para uma região
     * @param bounds Limites geográficos da região
     * @param minZoom Nível mínimo de zoom
     * @param maxZoom Nível máximo de zoom
     * @return Tamanho estimado em KB
     */
    private fun estimateDownloadSize(bounds: MapBounds, minZoom: Int, maxZoom: Int): Long {
        var totalTiles = 0L
        var totalSize = 0L
        
        for (zoom in minZoom..maxZoom) {
            // Calcula a quantidade de tiles neste zoom
            val tilesAtZoom = calculateTileCount(bounds, zoom)
            totalTiles += tilesAtZoom
            
            // Estima o tamanho baseado na média de tamanho dos tiles
            val tileSize = TILE_SIZE_KB[zoom] ?: TILE_SIZE_KB.getOrDefault(
                TILE_SIZE_KB.keys.minByOrNull { Math.abs(it - zoom) } ?: 14, 
                20
            )
            
            totalSize += tilesAtZoom * tileSize
        }
        
        Log.d(TAG, "Estimativa: $totalTiles tiles, ~$totalSize KB")
        return totalSize
    }
    
    /**
     * Calcula a quantidade de tiles necessários para uma região em um nível de zoom
     */
    private fun calculateTileCount(bounds: MapBounds, zoom: Int): Long {
        // Converte coordenadas para tiles
        val minX = longitudeToTileX(bounds.minLng, zoom)
        val maxX = longitudeToTileX(bounds.maxLng, zoom)
        val minY = latitudeToTileY(bounds.maxLat, zoom) // Note a inversão: maxLat -> minY
        val maxY = latitudeToTileY(bounds.minLat, zoom) // Note a inversão: minLat -> maxY
        
        // Calcula a quantidade de tiles
        val tilesX = maxX - minX + 1
        val tilesY = maxY - minY + 1
        
        return tilesX * tilesY
    }
    
    /**
     * Baixa os metadados da região
     */
    private suspend fun downloadMetadata(regionName: String, bounds: MapBounds, regionDir: File) {
        // Implementação de download de metadados da região
        // Os metadados geralmente incluem:
        // - Informações de licença
        // - Provedores de mapas
        // - Formato de tiles
        // - Timestamp da criação
        
        val metadataFile = File(regionDir, "metadata.json")
        val metadata = """
            {
                "name": "$regionName",
                "format": "$DEFAULT_TILE_FORMAT",
                "bounds": {
                    "minLat": ${bounds.minLat},
                    "minLng": ${bounds.minLng},
                    "maxLat": ${bounds.maxLat},
                    "maxLng": ${bounds.maxLng}
                },
                "created": "${Date()}",
                "provider": "OpenStreetMap",
                "license": "©OpenStreetMap contributors"
            }
        """.trimIndent()
        
        withContext(dispatcher) {
            metadataFile.writeText(metadata)
        }
    }
    
    /**
     * Baixa os tiles para um nível de zoom específico
     * @return Quantidade de tiles baixados
     */
    private suspend fun downloadTilesForZoom(
        bounds: MapBounds,
        zoom: Int,
        regionDir: File,
        downloadId: String,
        estimatedTotalSize: Long
    ): Int {
        var downloadedTiles = 0
        var currentProgress = 0L
        
        // Converte coordenadas para tiles
        val minX = longitudeToTileX(bounds.minLng, zoom)
        val maxX = longitudeToTileX(bounds.maxLng, zoom)
        val minY = latitudeToTileY(bounds.maxLat, zoom)
        val maxY = latitudeToTileY(bounds.minLat, zoom)
        
        // Cria as pastas para o nível de zoom
        val zoomDir = File(regionDir, zoom.toString())
        zoomDir.mkdirs()
        
        // Calcula o total de tiles para este zoom
        val totalTilesForZoom = (maxX - minX + 1) * (maxY - minY + 1)
        Log.d(TAG, "Baixando $totalTilesForZoom tiles para zoom $zoom")
        
        // Obtém o último progresso (para continuar de onde parou)
        val lastProgress = if (_downloadProgress.value is DownloadProgress.Started) {
            (_downloadProgress.value as DownloadProgress.Started).currentProgress
        } else {
            0
        }
        
        // Baixa os tiles
        for (x in minX..maxX) {
            // Cria a pasta para o X
            val xDir = File(zoomDir, x.toString())
            xDir.mkdirs()
            
            for (y in minY..maxY) {
                // Verifica se o job foi cancelado
                if (!coroutineContext.isActive) {
                    throw CancellationException("Download cancelado pelo usuário")
                }
                
                // Baixa o tile
                val tileFile = File(xDir, "$y.$DEFAULT_TILE_FORMAT")
                
                // Se o tile já existe, pula
                if (tileFile.exists()) {
                    downloadedTiles++
                    continue
                }
                
                try {
                    // Simula o download do tile (em um projeto real, isso seria uma chamada HTTP)
                    // downloadTileFromServer(zoom, x, y, tileFile)
                    delay(50) // Simulação do tempo de download
                    
                    // Em um projeto real, você faria algo como:
                    // val tileUrl = "https://tile.openstreetmap.org/$zoom/$x/$y.png"
                    // val response = httpClient.get(tileUrl)
                    // tileFile.writeBytes(response.body?.bytes() ?: ByteArray(0))
                    
                    // Para fins de simulação, criamos um arquivo vazio
                    tileFile.createNewFile()
                    
                    downloadedTiles++
                    
                    // Atualiza o progresso
                    val tileSize = TILE_SIZE_KB.getOrDefault(zoom, 20)
                    currentProgress += tileSize
                    
                    // Só atualiza o progresso a cada 10 tiles para evitar sobrecarga
                    if (downloadedTiles % 10 == 0) {
                        _downloadProgress.value = DownloadProgress.Started(
                            id = downloadId,
                            regionName = ((_downloadProgress.value as? DownloadProgress.Started)?.regionName ?: ""),
                            totalSize = estimatedTotalSize,
                            currentProgress = lastProgress + currentProgress,
                            message = "Baixando zoom $zoom: ${downloadedTiles * 100 / totalTilesForZoom}%"
                        )
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Erro ao baixar tile $zoom/$x/$y: ${e.message}", e)
                    // Continua mesmo com erro em um tile específico
                }
            }
        }
        
        return downloadedTiles
    }

    /**
     * Converte longitude para coordenada X de tile
     */
    private fun longitudeToTileX(lng: Double, zoom: Int): Int {
        return ((lng + 180.0) / 360.0 * (1 shl zoom)).toInt()
    }
    
    /**
     * Converte latitude para coordenada Y de tile
     */
    private fun latitudeToTileY(lat: Double, zoom: Int): Int {
        val latRad = Math.toRadians(lat)
        return ((1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * (1 shl zoom)).toInt()
    }
    
    /**
     * Sanitiza um nome para uso como nome de arquivo
     */
    private fun sanitizeFileName(name: String): String {
        return name.replace("[^a-zA-Z0-9\\-_]".toRegex(), "_")
    }
}

/**
 * Define os limites geográficos de uma região
 */
data class MapBounds(
    val minLat: Double,
    val minLng: Double,
    val maxLat: Double,
    val maxLng: Double
) {
    fun contains(lat: Double, lng: Double): Boolean {
        return lat >= minLat && lat <= maxLat && lng >= minLng && lng <= maxLng
    }
    
    fun intersects(other: MapBounds): Boolean {
        return !(minLat > other.maxLat || maxLat < other.minLat || 
                minLng > other.maxLng || maxLng < other.minLng)
    }
    
    fun expandBy(latDelta: Double, lngDelta: Double): MapBounds {
        return MapBounds(
            minLat = max(-90.0, minLat - latDelta),
            minLng = max(-180.0, minLng - lngDelta),
            maxLat = min(90.0, maxLat + latDelta),
            maxLng = min(180.0, maxLng + lngDelta)
        )
    }
}

/**
 * Sealed class para representar os diferentes estados de progresso de download
 */
sealed class DownloadProgress {
    object Idle : DownloadProgress()
    
    data class Started(
        val id: String,
        val regionName: String,
        val totalSize: Long,      // Em KB
        val currentProgress: Long, // Em KB
        val message: String = ""
    ) : DownloadProgress() {
        val progressPercentage: Int 
            get() = if (totalSize > 0) ((currentProgress * 100) / totalSize).toInt() else 0
    }
    
    data class Paused(
        val id: String,
        val regionName: String,
        val reason: String
    ) : DownloadProgress()
    
    data class Completed(
        val id: String,
        val regionName: String,
        val totalSize: Long       // Tamanho final em KB
    ) : DownloadProgress()
    
    data class Failed(
        val id: String,
        val regionName: String,
        val error: String
    ) : DownloadProgress()
    
    data class Cancelled(
        val id: String,
        val regionName: String
    ) : DownloadProgress()
}