// ReputationSystem.js
import React, { useState, useEffect } from 'react';
import { SecurityAlertService } from '../services/SecurityAlertService';

/**
 * Componente de Sistema de Reputação para validar a confiabilidade dos alertas
 * Este sistema avalia a confiabilidade dos alertas baseado em:
 * - Histórico do usuário que reportou
 * - Confirmações de outros motoristas
 * - Tempo desde o último alerta válido
 */
const ReputationSystem = ({ alertId, userId, onReputationCalculated }) => {
  const [reputationScore, setReputationScore] = useState(0);
  const [verifications, setVerifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReputationData = async () => {
      try {
        setIsLoading(true);
        // Carregar histórico de alertas do usuário
        const userHistory = await SecurityAlertService.getUserAlertHistory(userId);
        
        // Carregar verificações de outros motoristas para este alerta
        const alertVerifications = await SecurityAlertService.getAlertVerifications(alertId);
        setVerifications(alertVerifications);
        
        // Calcular pontuação de reputação
        const score = calculateReputationScore(userHistory, alertVerifications);
        setReputationScore(score);
        
        // Callback para componente pai
        if (onReputationCalculated) {
          onReputationCalculated(score);
        }
      } catch (err) {
        console.error("Erro ao carregar dados de reputação:", err);
        setError("Falha ao carregar informações de reputação");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchReputationData();
  }, [alertId, userId, onReputationCalculated]);

  /**
   * Calcula pontuação de reputação baseado no histórico e verificações
   * @param {Array} history - Histórico de alertas do usuário
   * @param {Array} verifications - Verificações de outros motoristas
   * @return {number} Pontuação de reputação (0-100)
   */
  const calculateReputationScore = (history, verifications) => {
    // Base inicial de confiança
    let baseScore = 50;
    
    // Fator de histórico (até +30 pontos)
    const historyFactor = calculateHistoryFactor(history);
    
    // Fator de verificação (até +20 pontos)
    const verificationFactor = verifications.length > 0 
      ? (verifications.filter(v => v.isConfirmed).length / verifications.length) * 20
      : 0;
    
    // Cálculo final com limite mínimo de 10 e máximo de 100
    return Math.min(100, Math.max(10, baseScore + historyFactor + verificationFactor));
  };

  /**
   * Calcula o fator de histórico baseado em alertas passados
   * @param {Array} history - Histórico de alertas do usuário
   * @return {number} Fator de histórico (0-30)
   */
  const calculateHistoryFactor = (history) => {
    if (!history || history.length === 0) return 0;
    
    // Avaliar precisão de alertas anteriores
    const confirmedAlerts = history.filter(alert => alert.isConfirmed).length;
    const accuracy = confirmedAlerts / history.length;
    
    // Bônus por experiência (quantidade de alertas reportados)
    const experienceBonus = Math.min(10, history.length / 2);
    
    return (accuracy * 20) + experienceBonus;
  };

  /**
   * Renderiza indicador visual de reputação
   */
  const renderReputationIndicator = () => {
    let color = '#9CA3AF'; // Cinza (neutro)
    
    if (reputationScore >= 80) {
      color = '#10B981'; // Verde (alta confiança)
    } else if (reputationScore >= 50) {
      color = '#F59E0B'; // Âmbar (média confiança)
    } else {
      color = '#EF4444'; // Vermelho (baixa confiança)
    }
    
    return (
      <div className="reputation-indicator" style={{ backgroundColor: color }}>
        <span className="reputation-score">{reputationScore}</span>
        <span className="reputation-label">
          {reputationScore >= 80 ? 'Alta Confiança' : 
           reputationScore >= 50 ? 'Confiança Média' : 'Baixa Confiança'}
        </span>
      </div>
    );
  };

  /**
   * Componente para verificar um alerta
   */
  const VerifyAlertButton = () => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const handleVerify = async (isConfirmed) => {
      try {
        setIsSubmitting(true);
        await SecurityAlertService.verifyAlert(alertId, {
          userId: userId,
          isConfirmed: isConfirmed,
          timestamp: new Date().toISOString()
        });
        
        // Atualizar verificações localmente
        setVerifications(prev => [
          ...prev,
          {
            userId: userId,
            isConfirmed: isConfirmed,
            timestamp: new Date().toISOString()
          }
        ]);
      } catch (err) {
        console.error("Erro ao verificar alerta:", err);
        setError("Falha ao enviar verificação");
      } finally {
        setIsSubmitting(false);
      }
    };
    
    return (
      <div className="verify-buttons">
        <button 
          onClick={() => handleVerify(true)}
          disabled={isSubmitting}
          className="confirm-button"
        >
          Confirmar Alerta
        </button>
        <button 
          onClick={() => handleVerify(false)}
          disabled={isSubmitting}
          className="deny-button"
        >
          Reportar Falso Alerta
        </button>
      </div>
    );
  };

  if (isLoading) {
    return <div className="loading">Carregando informações de confiabilidade...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="reputation-system">
      <h3>Confiabilidade do Alerta</h3>
      {renderReputationIndicator()}
      
      <div className="verification-info">
        <p>Verificado por {verifications.length} motoristas</p>
        <p>{verifications.filter(v => v.isConfirmed).length} confirmações</p>
      </div>
      
      <VerifyAlertButton />
    </div>
  );
};

export default ReputationSystem;