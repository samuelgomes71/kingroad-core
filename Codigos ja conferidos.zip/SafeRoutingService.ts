import { LatLng, RouteSegment, SafetyReport, WeightedRoute } from '../types';
import { getIncidentReports } from '../data/incidentReportsRepository';
import { getSecurityAlerts } from '../data/securityAlertsRepository';
import { getRouteAlternatives } from '../services/routingService';
import { getTimeOfDay } from '../utils/dateTimeUtils';

/**
 * Serviço para análise e recomendação de rotas com base em segurança
 */
export class SafeRoutingService {
  // Fatores de peso para o algoritmo de pontuação
  private readonly WEIGHT_INCIDENTS = 0.35;
  private readonly WEIGHT_ALERTS = 0.25;
  private readonly WEIGHT_TIME_OF_DAY = 0.15;
  private readonly WEIGHT_DRIVER_RATINGS = 0.25;
  
  /**
   * Encontra a rota mais segura entre origem e destino
   * @param origin Ponto de origem
   * @param destination Ponto de destino
   * @param truckProfile Perfil do caminhão (altura, peso, comprimento)
   * @returns Array de rotas ordenadas por segurança
   */
  public async findSafestRoutes(
    origin: LatLng,
    destination: LatLng,
    truckProfile: {
      height: number;
      weight: number;
      length: number;
    }
  ): Promise<WeightedRoute[]> {
    // Obter rotas alternativas da API de rotas
    const routeAlternatives = await getRouteAlternatives(origin, destination, truckProfile);
    
    // Para cada rota, calcular pontuação de segurança
    const scoredRoutes = await Promise.all(
      routeAlternatives.map(async route => {
        const safetyScore = await this.calculateRouteSafetyScore(route.segments);
        return {
          ...route,
          safetyScore,
        };
      })
    );
    
    // Ordenar por pontuação de segurança (maior é melhor)
    return scoredRoutes.sort((a, b) => b.safetyScore - a.safetyScore);
  }
  
  /**
   * Calcula a pontuação de segurança para uma rota
   * @param segments Segmentos da rota
   * @returns Pontuação de segurança (0-100)
   */
  private async calculateRouteSafetyScore(segments: RouteSegment[]): Promise<number> {
    // Pontuação base começa em 100 (perfeita)
    let baseScore = 100;
    
    // Calcular pontuações para cada segmento
    const segmentScores = await Promise.all(
      segments.map(async segment => {
        // Obtém dados de incidentes para o segmento
        const incidents = await getIncidentReports(segment.bounds);
        const incidentScore = this.calculateIncidentScore(incidents);
        
        // Obtém alertas de segurança para o segmento
        const alerts = await getSecurityAlerts(segment.bounds);
        const alertScore = this.calculateAlertScore(alerts);
        
        // Calcula fator de tempo (noite é mais perigoso)
        const timeOfDayFactor = this.calculateTimeOfDayFactor();
        
        // Calcula pontuação das avaliações de motoristas
        const driverRatingScore = await this.calculateDriverRatingScore(segment);
        
        // Combina as pontuações com os pesos respectivos
        return (
          incidentScore * this.WEIGHT_INCIDENTS +
          alertScore * this.WEIGHT_ALERTS +
          timeOfDayFactor * this.WEIGHT_TIME_OF_DAY +
          driverRatingScore * this.WEIGHT_DRIVER_RATINGS
        );
      })
    );
    
    // Calcular média ponderada pela distância de cada segmento
    const totalDistance = segments.reduce((acc, segment) => acc + segment.distance, 0);
    const weightedScoreSum = segments.reduce(
      (acc, segment, index) => acc + segmentScores[index] * (segment.distance / totalDistance),
      0
    );
    
    // Ajustar a pontuação base com a média ponderada
    baseScore *= weightedScoreSum;
    
    return Math.min(100, Math.max(0, baseScore));
  }
  
  /**
   * Calcula pontuação baseada em incidentes relatados
   * @param incidents Lista de incidentes na região
   * @returns Pontuação (0-1)
   */
  private calculateIncidentScore(incidents: SafetyReport[]): number {
    if (incidents.length === 0) return 1.0;
    
    // Pesos por tipo de incidente
    const weights = {
      theft: 0.7,
      assault: 0.5, 
      robbery: 0.3,
      carjacking: 0.2,
      other: 0.9
    };
    
    // Somar pesos de incidentes recentes (últimos 90 dias)
    const ninetyDaysAgo = Date.now() - 90 * 24 * 60 * 60 * 1000;
    const recentIncidents = incidents.filter(incident => incident.timestamp > ninetyDaysAgo);
    
    // Soma os pesos dos incidentes
    const totalWeight = recentIncidents.reduce((sum, incident) => {
      const typeWeight = weights[incident.type as keyof typeof weights] || weights.other;
      return sum + typeWeight;
    }, 0);
    
    // Calcular score baseado na quantidade ajustada por peso
    return Math.max(0, 1 - (totalWeight / 10));
  }
  
  /**
   * Calcula pontuação baseada em alertas de segurança
   * @param alerts Lista de alertas ativos
   * @returns Pontuação (0-1)
   */
  private calculateAlertScore(alerts: any[]): number {
    if (alerts.length === 0) return 1.0;
    
    // Classificação por severidade
    const severityWeights = {
      high: 0.7,
      medium: 0.3,
      low: 0.1
    };
    
    // Pontuação baseada na severidade
    const totalWeight = alerts.reduce((sum, alert) => {
      return sum + (severityWeights[alert.severity as keyof typeof severityWeights] || 0.1);
    }, 0);
    
    return Math.max(0, 1 - (totalWeight / 5));
  }
  
  /**
   * Calcula fator de segurança com base na hora do dia
   * @returns Fator de tempo (0-1)
   */
  private calculateTimeOfDayFactor(): number {
    const timeOfDay = getTimeOfDay();
    
    // Fatores de segurança por período
    switch (timeOfDay) {
      case 'morning':
        return 1.0;
      case 'afternoon':
        return 0.9;
      case 'evening':
        return 0.7;
      case 'night':
        return 0.5;
      default:
        return 0.8;
    }
  }
  
  /**
   * Calcula pontuação baseada em avaliações de outros motoristas
   * @param segment Segmento da rota
   * @returns Pontuação (0-1)
   */
  private async calculateDriverRatingScore(segment: RouteSegment): Promise<number> {
    // Implementação simplificada - em produção, consultar banco de dados de ratings
    return 0.85; // Valor exemplo
  }
}

export default new SafeRoutingService();