import React, { useState, useEffect } from 'react';
import { AlertTriangle, Calendar, Check, Compass, LocateFixed, Map, PieChart, SendHorizonal, Truck, X } from 'lucide-react';

// Componente de reportes rápidos flutuante para a tela de mapa
// Implementa as funcionalidades mencionadas em MapQuickReports.js
// com suporte a diferentes tipos de veículos conforme recomendação de melhoria

const SimpleMapQuickReports = ({ 
  onReport = () => {}, 
  currentScreen = 'navigation',
  vehicleType = 'truck', // truck, motorcycle, car, hiking
  language = 'pt',
  position = { latitude: -23.5505, longitude: -46.6333 } // São Paulo como exemplo
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      report: 'Reportar',
      police: 'Polícia',
      accident: 'Acidente',
      trafficJam: 'Congestionamento',
      roadClosed: 'Via Bloqueada',
      hazard: 'Perigo',
      construction: 'Obras',
      weather: 'Clima',
      camera: 'Radar',
      lowVisibility: 'Baixa Visibilidade',
      submit: 'Enviar',
      cancel: 'Cancelar',
      success: 'Reporte enviado com sucesso!',
      confirmReport: 'Confirmar reporte de',
      at: 'em'
    },
    en: {
      report: 'Report',
      police: 'Police',
      accident: 'Accident',
      trafficJam: 'Traffic Jam',
      roadClosed: 'Road Closed',
      hazard: 'Hazard',
      construction: 'Construction',
      weather: 'Weather',
      camera: 'Camera',
      lowVisibility: 'Low Visibility',
      submit: 'Submit',
      cancel: 'Cancel',
      success: 'Report sent successfully!',
      confirmReport: 'Confirm report of',
      at: 'at'
    },
    es: {
      report: 'Reportar',
      police: 'Policía',
      accident: 'Accidente',
      trafficJam: 'Congestión',
      roadClosed: 'Vía Cerrada',
      hazard: 'Peligro',
      construction: 'Obras',
      weather: 'Clima',
      camera: 'Radar',
      lowVisibility: 'Baja Visibilidad',
      submit: 'Enviar',
      cancel: 'Cancelar',
      success: '¡Reporte enviado con éxito!',
      confirmReport: 'Confirmar reporte de',
      at: 'en'
    }
  };
  
  // Texto conforme o idioma, com fallback para inglês
  const text = translations[language] || translations.en;
  
  // Tipos de reportes por tipo de veículo
  const reportTypes = {
    // Reportes para caminhões
    truck: [
      { id: 'police', icon: <AlertTriangle size={24} />, color: 'bg-blue-600', name: text.police },
      { id: 'accident', icon: <AlertTriangle size={24} />, color: 'bg-red-500', name: text.accident },
      { id: 'trafficJam', icon: <Truck size={24} />, color: 'bg-orange-500', name: text.trafficJam },
      { id: 'roadClosed', icon: <X size={24} />, color: 'bg-red-700', name: text.roadClosed },
      { id: 'hazard', icon: <AlertTriangle size={24} />, color: 'bg-amber-500', name: text.hazard },
      { id: 'construction', icon: <PieChart size={24} />, color: 'bg-yellow-500', name: text.construction },
      { id: 'weather', icon: <Calendar size={24} />, color: 'bg-blue-400', name: text.weather }
    ],
    // Reportes para motos
    motorcycle: [
      { id: 'police', icon: <AlertTriangle size={24} />, color: 'bg-blue-600', name: text.police },
      { id: 'accident', icon: <AlertTriangle size={24} />, color: 'bg-red-500', name: text.accident },
      { id: 'roadClosed', icon: <X size={24} />, color: 'bg-red-700', name: text.roadClosed },
      { id: 'hazard', icon: <AlertTriangle size={24} />, color: 'bg-amber-500', name: text.hazard },
      { id: 'lowVisibility', icon: <Map size={24} />, color: 'bg-purple-500', name: text.lowVisibility }
    ],
    // Reportes para carros
    car: [
      { id: 'police', icon: <AlertTriangle size={24} />, color: 'bg-blue-600', name: text.police },
      { id: 'accident', icon: <AlertTriangle size={24} />, color: 'bg-red-500', name: text.accident },
      { id: 'trafficJam', icon: <Truck size={24} />, color: 'bg-orange-500', name: text.trafficJam },
      { id: 'camera', icon: <Compass size={24} />, color: 'bg-green-500', name: text.camera },
      { id: 'roadClosed', icon: <X size={24} />, color: 'bg-red-700', name: text.roadClosed },
      { id: 'hazard', icon: <AlertTriangle size={24} />, color: 'bg-amber-500', name: text.hazard }
    ],
    // Reportes para trilhas
    hiking: [
      { id: 'hazard', icon: <AlertTriangle size={24} />, color: 'bg-amber-500', name: text.hazard },
      { id: 'weather', icon: <Calendar size={24} />, color: 'bg-blue-400', name: text.weather },
      { id: 'lowVisibility', icon: <Map size={24} />, color: 'bg-purple-500', name: text.lowVisibility }
    ]
  };
  
  // Seleciona os tipos de reporte baseado no tipo de veículo
  const currentReportTypes = reportTypes[vehicleType] || reportTypes.truck;
  
  // Função para abrir o menu de reportes
  const toggleReports = () => {
    setIsOpen(!isOpen);
    setSelectedType(null);
  };
  
  // Função para selecionar um tipo de reporte
  const selectReportType = (type) => {
    setSelectedType(type);
  };
  
  // Função para enviar o reporte
  const submitReport = () => {
    if (!selectedType) return;
    
    setIsSubmitting(true);
    
    // Simulação de envio para o servidor
    setTimeout(() => {
      // Dados do reporte
      const reportData = {
        type: selectedType.id,
        position,
        timestamp: new Date().toISOString(),
        vehicleType,
        screenType: currentScreen
      };
      
      // Callback com os dados
      onReport(reportData);
      
      setIsSubmitting(false);
      setSelectedType(null);
      setIsOpen(false);
      setShowSuccess(true);
      
      // Esconde mensagem de sucesso após 3 segundos
      setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
    }, 1000);
  };
  
  // Função para cancelar o reporte
  const cancelReport = () => {
    setSelectedType(null);
  };
  
  // Renderiza o modal de confirmação
  const renderConfirmationModal = () => {
    if (!selectedType) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-4">{text.confirmReport} {selectedType.name}</h3>
          
          <div className={`${selectedType.color} text-white p-4 rounded-lg mb-4 flex items-center`}>
            {selectedType.icon}
            <span className="ml-2 font-medium">{selectedType.name}</span>
          </div>
          
          <div className="mb-6">
            <div className="flex items-center text-gray-500 text-sm mb-1">
              <LocateFixed size={16} className="mr-1" />
              <span>Lat: {position.latitude.toFixed(4)}, Lng: {position.longitude.toFixed(4)}</span>
            </div>
            <div className="flex items-center text-gray-500 text-sm">
              <Calendar size={16} className="mr-1" />
              <span>{new Date().toLocaleString(language === 'pt' ? 'pt-BR' : language === 'es' ? 'es-ES' : 'en-US')}</span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={cancelReport}
              className="flex-1 py-2 px-4 border border-gray-300 rounded-md text-gray-700 font-medium hover:bg-gray-50 transition-colors"
            >
              {text.cancel}
            </button>
            <button
              onClick={submitReport}
              className={`flex-1 py-2 px-4 ${selectedType.color} rounded-md text-white font-medium hover:opacity-90 transition-colors flex items-center justify-center`}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <>
                  <SendHorizonal size={18} className="mr-1" />
                  {text.submit}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  // Renderiza a mensagem de sucesso
  const renderSuccessMessage = () => {
    if (!showSuccess) return null;
    
    return (
      <div className="fixed bottom-20 left-0 right-0 mx-auto max-w-sm p-4">
        <div className="bg-green-500 text-white px-4 py-3 rounded-lg shadow-lg flex items-center">
          <Check size={20} className="mr-2" />
          <span>{text.success}</span>
        </div>
      </div>
    );
  };
  
  return (
    <>
      {/* Botão flutuante de reportes */}
      <div className="fixed bottom-8 right-8 z-40">
        <button
          onClick={toggleReports}
          className={`w-14 h-14 rounded-full ${isOpen ? 'bg-gray-800' : 'bg-blue-600'} text-white shadow-lg flex items-center justify-center hover:opacity-90 transition-colors`}
        >
          {isOpen ? (
            <X size={24} />
          ) : (
            <AlertTriangle size={24} />
          )}
        </button>
        
        {/* Menu circular de reportes */}
        {isOpen && (
          <div className="absolute bottom-16 right-0 flex flex-col-reverse space-y-reverse space-y-3 items-end">
            {currentReportTypes.map((type, index) => (
              <button
                key={type.id}
                onClick={() => selectReportType(type)}
                className={`flex items-center ${type.color} text-white py-2 pl-3 pr-4 rounded-full shadow-md transition-all transform hover:scale-105`}
                style={{
                  animationDelay: `${index * 50}ms`,
                  animation: 'slideIn 0.2s ease-out forwards'
                }}
              >
                <span className="mr-2">{type.icon}</span>
                <span className="font-medium">{type.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Modal de confirmação */}
      {renderConfirmationModal()}
      
      {/* Mensagem de sucesso */}
      {renderSuccessMessage()}
      
      {/* Estilos para animação */}
      <style jsx>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </>
  );
};

export default SimpleMapQuickReports;