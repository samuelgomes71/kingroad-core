import React, { useState } from 'react';
import { Upload, Folder, Image, Plus, Search, Settings } from 'lucide-react';

const POIIconInterface = () => {
  const [selectedCategory, setSelectedCategory] = useState('FUEL_STATION');
  const [searchQuery, setSearchQuery] = useState('');
  
  return (
    <div className="h-screen bg-[#121212]">
      {/* Barra superior */}
      <div className="bg-[#1E1E1E] p-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-white text-xl font-bold">Ícones POI</h1>
          <button className="p-2 rounded-lg bg-[#252525]">
            <Settings size={24} className="text-gray-300" />
          </button>
        </div>

        {/* Barra de busca */}
        <div className="relative">
          <Search 
            size={20} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
          />
          <input
            type="text"
            placeholder="Buscar ícone..."
            className="w-full bg-[#252525] text-gray-200 pl-10 pr-4 py-2 rounded-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Categorias e grade de ícones */}
      <div className="flex h-[calc(100vh-132px)]">
        {/* Lista de categorias */}
        <div className="w-64 bg-[#1E1E1E] border-r border-[#303030] overflow-y-auto">
          <div className="p-4">
            <button className="w-full bg-blue-600 text-white p-2 rounded-lg flex items-center justify-center mb-4">
              <Plus size={20} className="mr-2" />
              Novo Ícone
            </button>

            {/* Categorias */}
            <div className="space-y-2">
              <button
                onClick={() => setSelectedCategory('FUEL_STATION')}
                className={`w-full p-2 rounded-lg flex items-center ${
                  selectedCategory === 'FUEL_STATION' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:bg-[#252525]'
                }`}
              >
                <Folder size={20} className="mr-2" />
                Postos de Combustível
              </button>

              <button
                onClick={() => setSelectedCategory('RESTAURANT')}
                className={`w-full p-2 rounded-lg flex items-center ${
                  selectedCategory === 'RESTAURANT' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:bg-[#252525]'
                }`}
              >
                <Folder size={20} className="mr-2" />
                Restaurantes
              </button>

              <button
                onClick={() => setSelectedCategory('CONVENIENCE')}
                className={`w-full p-2 rounded-lg flex items-center ${
                  selectedCategory === 'CONVENIENCE' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:bg-[#252525]'
                }`}
              >
                <Folder size={20} className="mr-2" />
                Conveniência
              </button>

              <button
                onClick={() => setSelectedCategory('CUSTOM')}
                className={`w-full p-2 rounded-lg flex items-center ${
                  selectedCategory === 'CUSTOM' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:bg-[#252525]'
                }`}
              >
                <Folder size={20} className="mr-2" />
                Personalizados
              </button>
            </div>
          </div>
        </div>

        {/* Grade de ícones */}
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="grid grid-cols-4 gap-4">
            {/* Exemplo de cartão de ícone */}
            <div className="bg-[#1E1E1E] p-4 rounded-lg">
              <div className="aspect-square bg-[#252525] rounded-lg flex items-center justify-center mb-3">
                <Image size={48} className="text-gray-400" />
              </div>
              <div className="text-sm">
                <div className="font-medium text-gray-200">Shell</div>
                <div className="text-gray-400">Posto de Combustível</div>
              </div>
            </div>

            {/* Cartão de upload */}
            <div className="bg-[#1E1E1E] p-4 rounded-lg border-2 border-dashed border-[#303030] flex flex-col items-center justify-center">
              <Upload size={32} className="text-gray-400 mb-2" />
              <span className="text-sm text-gray-400">Adicionar Ícone</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default POIIconInterface;