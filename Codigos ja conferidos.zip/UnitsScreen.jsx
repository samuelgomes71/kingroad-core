import React, { useState } from 'react';
import { ChevronLeft, Check } from 'lucide-react';

const UnitsScreen = ({ onBack, onSave }) => {
  const [selectedUnit, setSelectedUnit] = useState('metric');
  
  const units = [
    {
      id: 'metric',
      label: 'Kilometers, meters & metric tons (km/m/t)'
    },
    {
      id: 'imperial_metric',
      label: 'Miles, yards & metric tons (mi/yd/t)'
    },
    {
      id: 'imperial',
      label: 'Miles, feet & pounds (mi/ft/lb)'
    },
    {
      id: 'automatic',
      label: 'Automatic'
    }
  ];

  return (
    <div className="h-screen bg-[#121212]">
      {/* Header */}
      <div className="flex items-center p-4 bg-[#1E1E1E]">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="text-white" size={24} />
        </button>
        <h1 className="text-white text-xl ml-2">Units</h1>
      </div>

      {/* Options */}
      <div className="p-4">
        {units.map(unit => (
          <button
            key={unit.id}
            className={`w-full p-4 mb-2 flex items-center justify-between rounded-lg ${
              selectedUnit === unit.id ? 'bg-blue-600' : 'bg-[#1E1E1E]'
            }`}
            onClick={() => setSelectedUnit(unit.id)}
          >
            <span className="text-white">{unit.label}</span>
            {selectedUnit === unit.id && (
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <Check size={16} className="text-blue-600" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default UnitsScreen;