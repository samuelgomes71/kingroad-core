package com.kingroad.alerts.security

import com.kingroad.database.entities.SecurityAlert
import com.kingroad.services.SecurityAlertService
import com.kingroad.utils.LocationUtils
import com.kingroad.utils.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

/**
 * Gerenciador especializado para alertas de segurança no Brasil.
 * Implementa recursos específicos de segurança para a realidade brasileira.
 */
class BrazilSecurityAlertManager(
    private val securityAlertService: SecurityAlertService,
    private val userPreferences: UserPreferences,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    // Tipos de alertas específicos para o Brasil
    enum class BrazilAlertType {
        TIROTEIO,
        SEQUESTRO,
        ROUBO_CARGA,
        VEICULO_SUSPEITO,
        VEICULO_ALTA_VELOCIDADE
    }

    // Configurações de notificação por tipo de alerta
    private val alertSettings = MutableStateFlow(
        mapOf(
            BrazilAlertType.TIROTEIO to true,
            BrazilAlertType.SEQUESTRO to true,
            BrazilAlertType.ROUBO_CARGA to true,
            BrazilAlertType.VEICULO_SUSPEITO to true,
            BrazilAlertType.VEICULO_ALTA_VELOCIDADE to true
        )
    )

    // Cache de alertas ativos
    private val activeAlerts = MutableStateFlow<List<SecurityAlert>>(emptyList())
    
    /**
     * Inicializa o gerenciador carregando as configurações do usuário
     * e iniciando a observação de alertas
     */
    init {
        loadUserSettings()
        scope.launch {
            observeSecurityAlerts()
        }
    }

    /**
     * Carrega as configurações do usuário para notificações
     */
    private fun loadUserSettings() {
        scope.launch {
            val settings = userPreferences.getSecurityAlertSettings()
            alertSettings.value = mapOf(
                BrazilAlertType.TIROTEIO to settings.getOrDefault("alert_br_tiroteio", true),
                BrazilAlertType.SEQUESTRO to settings.getOrDefault("alert_br_sequestro", true),
                BrazilAlertType.ROUBO_CARGA to settings.getOrDefault("alert_br_roubo_carga", true),
                BrazilAlertType.VEICULO_SUSPEITO to settings.getOrDefault("alert_br_veiculo_suspeito", true),
                BrazilAlertType.VEICULO_ALTA_VELOCIDADE to settings.getOrDefault("alert_br_veiculo_alta_velocidade", true)
            )
        }
    }

    /**
     * Observa alertas de segurança do serviço principal
     */
    private suspend fun observeSecurityAlerts() {
        securityAlertService.getActiveAlerts()
            .collect { alerts ->
                val brazilAlerts = alerts.filter { 
                    it.country == "BR" && it.expirationTime > Date().time 
                }
                activeAlerts.value = brazilAlerts
            }
    }

    /**
     * Retorna os alertas ativos com base na localização atual e
     * distância máxima configurada pelo usuário
     */
    fun getActiveAlerts(
        currentLat: Double, 
        currentLng: Double, 
        maxDistanceKm: Int = 30
    ): Flow<List<SecurityAlert>> {
        return activeAlerts.map { alerts ->
            alerts.filter { alert ->
                val distance = LocationUtils.calculateDistance(
                    currentLat, currentLng,
                    alert.latitude, alert.longitude
                )
                distance <= maxDistanceKm
            }.sortedBy { alert ->
                LocationUtils.calculateDistance(
                    currentLat, currentLng,
                    alert.latitude, alert.longitude
                )
            }
        }
    }

    /**
     * Cria um novo alerta de segurança
     */
    suspend fun createAlert(
        type: BrazilAlertType,
        latitude: Double,
        longitude: Double,
        description: String,
        severity: String,
        anonymous: Boolean = false
    ): SecurityAlert {
        val alert = SecurityAlert(
            id = UUID.randomUUID().toString(),
            type = type.name.lowercase(),
            latitude = latitude,
            longitude = longitude,
            description = description,
            creationTime = Date().time,
            expirationTime = Date().time + ALERT_EXPIRATION_TIME,
            severity = severity,
            country = "BR",
            reportedBy = if (anonymous) "anonymous" else userPreferences.getUserId(),
            verified = false
        )
        
        return securityAlertService.addAlert(alert)
    }

    /**
     * Reporta um alerta como falso ou incorreto
     */
    suspend fun reportFalseAlert(alertId: String, reason: String) {
        securityAlertService.reportFalseAlert(alertId, reason)
    }

    /**
     * Verifica se um alerta afeta a rota atual
     */
    fun doesAlertAffectRoute(
        alertType: BrazilAlertType,
        alertLatitude: Double,
        alertLongitude: Double, 
        routePoints: List<Pair<Double, Double>>,
        thresholdDistanceKm: Double = 0.5
    ): Boolean {
        // Para tiroteio e sequestro, considerar uma área maior
        val adjustedThreshold = when (alertType) {
            BrazilAlertType.TIROTEIO, BrazilAlertType.SEQUESTRO -> thresholdDistanceKm * 2
            else -> thresholdDistanceKm
        }
        
        return routePoints.any { (lat, lng) ->
            val distance = LocationUtils.calculateDistance(
                lat, lng, alertLatitude, alertLongitude
            )
            distance <= adjustedThreshold
        }
    }

    /**
     * Atualiza as configurações de alerta do usuário
     */
    fun updateAlertSettings(type: BrazilAlertType, enabled: Boolean) {
        val current = alertSettings.value.toMutableMap()
        current[type] = enabled
        alertSettings.value = current
        
        scope.launch {
            userPreferences.saveSecurityAlertSetting(
                "alert_br_${type.name.lowercase()}", 
                enabled
            )
        }
    }

    companion object {
        // Tempo de expiração padrão: 2 horas
        private const val ALERT_EXPIRATION_TIME = 2 * 60 * 60 * 1000L
        
        // Distância padrão para notificações em Km
        private const val DEFAULT_NOTIFICATION_DISTANCE = 10
    }
}