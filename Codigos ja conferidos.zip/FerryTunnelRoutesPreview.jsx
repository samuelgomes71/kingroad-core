import React, { useState } from 'react';
import { Map, Ship, ArrowRightCircle, Settings, Clock, DollarSign, AlertTriangle, Calendar, Info } from 'lucide-react';

const FerryTunnelRoutesPreview = () => {
  // Estados para simular a interação do usuário
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [avoidFerries, setAvoidFerries] = useState(false);
  const [avoidTunnels, setAvoidTunnels] = useState(false);
  const [showRouteDetails, setShowRouteDetails] = useState(false);
  
  // Rotas de exemplo com conexões intermodais
  const routes = [
    {
      id: 1,
      name: "Lisboa → Londres",
      distance: "2.457 km",
      duration: "27h 45min",
      connections: [
        { type: "tunnel", name: "Eurotúnel", location: "Calais-Folkestone", duration: "35min", fee: "€199" }
      ],
      description: "Rota mais rápida passando por Espanha e França, com travessia pelo Eurotúnel"
    },
    {
      id: 2,
      name: "Estocolmo → Helsinque",
      distance: "484 km",
      duration: "17h 30min",
      connections: [
        { type: "ferry", name: "Viking Line", location: "Mar Báltico", duration: "15h 45min", fee: "€120" }
      ],
      description: "Rota marítima com ferry noturno, incluindo acomodações a bordo"
    },
    {
      id: 3,
      name: "Rio de Janeiro → Niterói",
      distance: "22 km",
      duration: "35min",
      connections: [
        { type: "ferry", name: "Travessia da Baía", location: "Baía de Guanabara", duration: "20min", fee: "R$6,90" }
      ],
      description: "Travessia local pela Baía de Guanabara"
    }
  ];
  
  // Cores do sistema KingRoad
  const colors = {
    background: '#E0D3C0',
    textColor: '#5E3C2B',
    accent: '#6B4B3E',
    light: '#F5EEE6',
    warning: '#F57C00',
    info: '#1976D2'
  };
  
  const handleRouteSelect = (route) => {
    setSelectedRoute(route);
    setShowRouteDetails(true);
  };
  
  // Renderiza o ícone baseado no tipo de conexão
  const renderConnectionIcon = (type, size = 16, color) => {
    if (type === 'ferry') {
      return <Ship size={size} color={color} />;
    } else {
      // Ícone para túnel (usando ArrowRightCircle como substituto)
      return <ArrowRightCircle size={size} color={color} />;
    }
  };
  
  return (
    <div className="flex flex-col w-full max-w-4xl mx-auto">
      {/* Cabeçalho */}
      <div 
        className="p-4 flex justify-between items-center"
        style={{ backgroundColor: colors.accent, color: 'white' }}
      >
        <h1 className="text-xl font-bold">KingRoad - Navegação Global</h1>
        <button 
          className="p-2 rounded-full hover:bg-opacity-20 hover:bg-white"
          onClick={() => setShowSettings(!showSettings)}
        >
          <Settings size={20} />
        </button>
      </div>
      
      {/* Painel de configurações */}
      {showSettings && (
        <div 
          className="p-4 border-b"
          style={{ backgroundColor: colors.light, color: colors.textColor }}
        >
          <h2 className="font-bold mb-3">Preferências de Rota</h2>
          
          <div className="flex flex-col gap-3">
            <label className="flex items-center gap-2">
              <input 
                type="checkbox" 
                checked={avoidFerries} 
                onChange={() => setAvoidFerries(!avoidFerries)}
              />
              <Ship size={18} />
              <span>Evitar balsas e ferries</span>
            </label>
            
            <label className="flex items-center gap-2">
              <input 
                type="checkbox" 
                checked={avoidTunnels} 
                onChange={() => setAvoidTunnels(!avoidTunnels)}
              />
              <ArrowRightCircle size={18} />
              <span>Evitar túneis especiais (com tarifas)</span>
            </label>
          </div>
        </div>
      )}
      
      {/* Conteúdo principal */}
      <div className="flex flex-col md:flex-row h-[600px]">
        {/* Simulador de mapa (coluna esquerda) */}
        <div 
          className="w-full md:w-3/5 h-full relative p-4 flex items-center justify-center"
          style={{ backgroundColor: colors.background }}
        >
          <div className="text-center">
            <div className="flex justify-center">
              <Map size={100} color={colors.accent} />
            </div>
            <p 
              className="mt-4 text-lg"
              style={{ color: colors.textColor }}
            >
              Visualização do Mapa
            </p>
            <p 
              className="text-sm mt-2"
              style={{ color: colors.textColor }}
            >
              Mapa interativo com marcação de balsas, ferries e túneis.
            </p>
            
            {/* Indicação de rota selecionada */}
            {selectedRoute && (
              <div 
                className="mt-8 p-3 rounded-lg"
                style={{ backgroundColor: colors.light }}
              >
                <p className="font-bold" style={{ color: colors.textColor }}>
                  Rota: {selectedRoute.name}
                </p>
                <div className="flex gap-3 justify-center mt-2">
                  {selectedRoute.connections.map((connection, index) => (
                    <div 
                      key={index}
                      className="flex items-center gap-1" 
                      style={{ color: colors.accent }}
                    >
                      {renderConnectionIcon(connection.type, 16)}
                      <span className="text-sm">{connection.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Botão de alternância de detalhes (apenas em mobile) */}
          <button
            className="absolute bottom-4 right-4 md:hidden p-3 rounded-full shadow-lg"
            style={{ backgroundColor: colors.accent, color: 'white' }}
            onClick={() => setShowRouteDetails(!showRouteDetails)}
          >
            <Info size={24} />
          </button>
        </div>
        
        {/* Painel de detalhes (coluna direita / modal em mobile) */}
        <div 
          className={`w-full md:w-2/5 h-full overflow-auto ${showRouteDetails ? 'absolute inset-0 z-10 md:relative' : 'hidden md:block'}`}
          style={{ backgroundColor: colors.light, color: colors.textColor }}
        >
          {/* Cabeçalho do painel */}
          <div className="p-4 border-b flex justify-between items-center">
            <h2 className="font-bold">Rotas com Conexões Especiais</h2>
            <button 
              className="md:hidden p-1 rounded-full"
              onClick={() => setShowRouteDetails(false)}
            >
              ✕
            </button>
          </div>
          
          {/* Lista de rotas */}
          <div className="p-4">
            <div className="space-y-4">
              {routes
                .filter(route => {
                  if (avoidFerries && route.connections.some(c => c.type === 'ferry')) return false;
                  if (avoidTunnels && route.connections.some(c => c.type === 'tunnel')) return false;
                  return true;
                })
                .map(route => (
                  <div 
                    key={route.id}
                    className={`p-4 rounded-lg cursor-pointer transition-colors ${selectedRoute?.id === route.id ? 'border-2' : 'border'}`}
                    style={{ 
                      backgroundColor: 'white', 
                      borderColor: selectedRoute?.id === route.id ? colors.accent : 'transparent',
                    }}
                    onClick={() => handleRouteSelect(route)}
                  >
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold">{route.name}</h3>
                      <div className="flex items-center gap-1 text-sm">
                        {route.connections.map((connection, idx) => (
                          <span key={idx}>
                            {renderConnectionIcon(connection.type, 16, colors.info)}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex justify-between mt-2 text-sm">
                      <div className="flex items-center gap-1">
                        <Map size={14} />
                        <span>{route.distance}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock size={14} />
                        <span>{route.duration}</span>
                      </div>
                    </div>
                    
                    <p className="text-sm mt-2">{route.description}</p>
                    
                    {selectedRoute?.id === route.id && (
                      <div className="mt-3 pt-3 border-t">
                        <h4 className="font-medium text-sm">Detalhes da Conexão</h4>
                        
                        {route.connections.map((connection, idx) => (
                          <div key={idx} className="mt-2 bg-gray-50 p-2 rounded">
                            <div className="flex items-center gap-2 mb-1">
                              {renderConnectionIcon(connection.type, 16, colors.info)}
                              <span className="font-medium">{connection.name}</span>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div className="flex items-center gap-1">
                                <Map size={12} />
                                <span>{connection.location}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock size={12} />
                                <span>{connection.duration}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <DollarSign size={12} />
                                <span>{connection.fee}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar size={12} />
                                <span>Diariamente</span>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-1 mt-2 text-xs" style={{ color: colors.warning }}>
                              <AlertTriangle size={12} />
                              <span>Reserva recomendada antecipadamente</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                
              {/* Mensagem se não houver rotas disponíveis com os filtros atuais */}
              {routes.filter(route => {
                if (avoidFerries && route.connections.some(c => c.type === 'ferry')) return false;
                if (avoidTunnels && route.connections.some(c => c.type === 'tunnel')) return false;
                return true;
              }).length === 0 && (
                <div className="py-8 text-center">
                  <AlertTriangle size={48} className="mx-auto mb-4" color={colors.warning} />
                  <p>Não há rotas disponíveis com as preferências selecionadas.</p>
                  <p className="text-sm mt-2">Experimente alterar suas preferências de rota.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Rodapé com informações */}
      <div 
        className="p-3 text-sm"
        style={{ backgroundColor: colors.accent, color: 'white' }}
      >
        <div className="flex justify-between items-center">
          <span>Versão Beta • Março 2025</span>
          <div className="flex items-center gap-3">
            <Ship size={16} />
            <ArrowRightCircle size={16} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FerryTunnelRoutesPreview;