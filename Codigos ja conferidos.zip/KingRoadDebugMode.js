// king-road-debug-mode.js

/**
 * Sistema de modo de depuração para o King Road
 * Adiciona identificadores visíveis para todos os elementos da interface
 */

const KingRoadDebugMode = {
  // Estado do modo de depuração
  active: false,
  
  // Configurações
  config: {
    showIds: true,           // Mostrar IDs numéricos 
    showNames: true,         // Mostrar nomes de componentes
    showBorders: true,       // Mostrar bordas coloridas
    showPaths: true,         // Mostrar caminho do menu
    labelSize: 'medium',     // Tamanho da etiqueta ('small', 'medium', 'large')
    position: 'top-right'    // Posição da etiqueta
  },
  
  // Ativar modo de depuração
  enable: function(options = {}) {
    // Mesclar opções fornecidas com padrões
    this.config = {...this.config, ...options};
    this.active = true;
    
    // Aplicar identificadores a todos os elementos
    this.applyDebugIdentifiers();
    
    console.log("King Road: Modo de depuração ativado");
    return true;
  },
  
  // Desativar modo de depuração
  disable: function() {
    this.active = false;
    
    // Remover identificadores
    this.removeDebugIdentifiers();
    
    console.log("King Road: Modo de depuração desativado");
    return true;
  },
  
  // Aplicar identificadores a todos os elementos
  applyDebugIdentifiers: function() {
    if (!this.active) return;
    
    // Na implementação real, esta função percorreria a árvore de elementos da UI
    // e adicionaria rótulos de depuração a cada elemento
    
    // Este é um exemplo simplificado do que seria feito:
    const menuStructure = this.getMenuStructure();
    let idCounter = 1;
    
    const processMenu = (menu, parentPath = '') => {
      const currentPath = parentPath ? `${parentPath}.${menu.name}` : menu.name;
      
      // Adicionar identificador ao menu atual
      menu.debugId = idCounter++;
      menu.debugPath = currentPath;
      
      // Aplicar identificadores visíveis na interface
      if (menu.ref && typeof menu.ref === 'object') {
        this.applyVisualIdentifier(menu.ref, menu.debugId, menu.name, currentPath);
      }
      
      // Processar itens do menu
      if (menu.items && Array.isArray(menu.items)) {
        menu.items.forEach(item => {
          item.debugId = idCounter++;
          item.debugPath = `${currentPath}.${item.name}`;
          
          // Aplicar identificadores visíveis na interface
          if (item.ref && typeof item.ref === 'object') {
            this.applyVisualIdentifier(item.ref, item.debugId, item.name, item.debugPath);
          }
          
          // Processar recursivamente se for um submenu
          if (item.items && Array.isArray(item.items)) {
            processMenu(item, currentPath);
          }
        });
      }
    };
    
    // Iniciar processamento a partir do menu principal
    menuStructure.forEach(menu => processMenu(menu));
    
    // Gerar e salvar mapa completo de IDs para referência
    this.generateIdMap();
  },
  
  // Remover identificadores de depuração
  removeDebugIdentifiers: function() {
    // Na implementação real, esta função removeria todos os
    // rótulos de depuração adicionados à interface
    
    // Exemplo simplificado:
    document.querySelectorAll('.king-road-debug-label').forEach(el => {
      el.remove();
    });
    
    document.querySelectorAll('[data-kr-debug-id]').forEach(el => {
      el.style.border = null;
      el.removeAttribute('data-kr-debug-id');
      el.removeAttribute('data-kr-debug-path');
    });
  },
  
  // Aplicar identificador visual a um elemento
  applyVisualIdentifier: function(element, id, name, path) {
    // Esta função seria implementada para adicionar rótulos visuais aos elementos
    // Na implementação real, você criaria elementos DOM para mostrar os IDs
    
    // Exemplo conceptual:
    if (!element || typeof element.appendChild !== 'function') return;
    
    // Adicionar atributos de dados
    element.setAttribute('data-kr-debug-id', id);
    element.setAttribute('data-kr-debug-path', path);
    
    // Adicionar borda colorida se configurado
    if (this.config.showBorders) {
      // Gerar cor baseada no ID para facilitar identificação visual
      const hue = (id * 137) % 360; // Distribuição de cores usando número primo
      element.style.border = `2px solid hsl(${hue}, 70%, 60%)`;
    }
    
    // Criar e adicionar etiqueta de depuração
    if (this.config.showIds || this.config.showNames || this.config.showPaths) {
      const label = document.createElement('div');
      label.className = 'king-road-debug-label';
      
      // Estilizar etiqueta
      Object.assign(label.style, {
        position: 'absolute',
        top: this.config.position.includes('top') ? '0' : 'auto',
        bottom: this.config.position.includes('bottom') ? '0' : 'auto',
        left: this.config.position.includes('left') ? '0' : 'auto',
        right: this.config.position.includes('right') ? '0' : 'auto',
        background: `hsl(${(id * 137) % 360}, 70%, 25%)`,
        color: 'white',
        padding: '2px 4px',
        borderRadius: '3px',
        fontSize: {
          small: '10px',
          medium: '12px',
          large: '14px'
        }[this.config.labelSize],
        fontFamily: 'monospace',
        zIndex: 9999,
        pointerEvents: 'none'
      });
      
      // Construir texto da etiqueta
      let labelText = '';
      if (this.config.showIds) {
        labelText += `#${id} `;
      }
      if (this.config.showNames) {
        labelText += name + ' ';
      }
      if (this.config.showPaths) {
        labelText += `(${path})`;
      }
      
      label.textContent = labelText.trim();
      
      // Adicionar a etiqueta ao elemento
      element.style.position = element.style.position || 'relative';
      element.appendChild(label);
    }
  },
  
  // Gerar e salvar mapa completo de IDs para referência
  generateIdMap: function() {
    const idMap = {};
    
    // Coletar todos os elementos com IDs de depuração
    document.querySelectorAll('[data-kr-debug-id]').forEach(el => {
      const id = el.getAttribute('data-kr-debug-id');
      const path = el.getAttribute('data-kr-debug-path');
      
      idMap[id] = {
        path: path,
        element: el // Na versão real, você armazenaria uma referência mais útil
      };
    });
    
    // Salvar o mapa para referência
    this.idMap = idMap;
    
    // Fornecer exportação amigável para não-programadores
    this.exportIdMap();
    
    return idMap;
  },
  
  // Exportar mapa de IDs em formato amigável
  exportIdMap: function() {
    let output = "=== KING ROAD: MAPA DE IDENTIFICAÇÃO ===\n\n";
    
    // Agrupar por menu principal
    const mainMenus = {};
    
    // Processar o mapa de IDs
    Object.entries(this.idMap || {}).forEach(([id, info]) => {
      const parts = info.path.split('.');
      const mainMenu = parts[0];
      
      if (!mainMenus[mainMenu]) {
        mainMenus[mainMenu] = [];
      }
      
      mainMenus[mainMenu].push({
        id: id,
        path: info.path
      });
    });
    
    // Gerar saída organizada por menu
    Object.entries(mainMenus).sort().forEach(([menu, items]) => {
      output += `\n== MENU: ${menu} ==\n\n`;
      
      items.sort((a, b) => a.path.localeCompare(b.path)).forEach(item => {
        output += `ID #${item.id}: ${item.path}\n`;
      });
    });
    
    // Adicionar instruções de uso
    output += "\n\n=== INSTRUÇÕES ===\n";
    output += "Para solicitar modificações, use o número do ID (#123) ou o caminho completo.\n";
    output += "Exemplos:\n";
    output += "- \"Mova o elemento #45 para dentro do menu Configurações\"\n";
    output += "- \"Remova o item 'Ajuda.Tutoriais.Iniciante' do menu\"\n";
    output += "- \"Quero que o elemento #12 apareça antes do elemento #15\"\n";
    
    // Salvar para download ou exibir na UI
    console.log(output);
    
    // Na implementação real, você poderia:
    // 1. Mostrar isso em uma janela de depuração
    // 2. Oferecer um botão para download como arquivo de texto
    // 3. Copiar automaticamente para a área de transferência
    
    return output;
  },
  
  // Obter estrutura de menus (exemplo simplificado)
  getMenuStructure: function() {
    // Esta função obteria a estrutura de menus real da aplicação
    // Aqui está um exemplo simplificado para ilustração
    
    return [
      {
        name: "Navegação",
        ref: null, // Referência ao elemento DOM
        items: [
          { name: "Iniciar rota", ref: null },
          { name: "Destinos recentes", ref: null },
          { name: "Favoritos", ref: null },
          { 
            name: "Opções de rota", 
            ref: null,
            items: [
              { name: "Evitar estradas com portagem", ref: null },
              { name: "Evitar estradas de terra", ref: null },
              { name: "Preferir autoestradas", ref: null }
            ]
          }
        ]
      },
      {
        name: "Mapa",
        ref: null,
        items: [
          { name: "2D/3D", ref: null },
          { name: "Dia/Noite", ref: null },
          { name: "Mostrar POIs", ref: null },
          { name: "Mapas offline", ref: null }
        ]
      },
      {
        name: "Veículo",
        ref: null,
        items: [
          { name: "Perfil", ref: null },
          { name: "Dimensões", ref: null },
          { name: "Peso", ref: null },
          { name: "Combustível", ref: null }
        ]
      },
      {
        name: "Configurações",
        ref: null,
        items: [
          { name: "Idioma", ref: null },
          { name: "Unidades", ref: null },
          { name: "Som", ref: null },
          { name: "Tema", ref: null },
          { 
            name: "Avançado", 
            ref: null,
            items: [
              { name: "Calibração GPS", ref: null },
              { name: "Sincronização", ref: null },
              { name: "Reiniciar aplicação", ref: null }
            ]
          }
        ]
      }
    ];
  }
};

// Exporta o módulo de depuração
export default KingRoadDebugMode;