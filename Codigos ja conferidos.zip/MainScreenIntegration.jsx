import React, { useState, useContext } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { AlertCircle, Layers, Menu, Navigation } from 'lucide-react';
import RerouteButton from '../components/RerouteButton';
import { fetchAlternativeRoutes } from '../services/NavigationService';

// Caminho: web/src/screens/MainScreenIntegration.jsx

// Em um projeto real, isso seria importado do contexto da aplicação
const useAppContext = () => {
  const [currentRoute, setCurrentRoute] = useState(null);
  return { currentRoute, setCurrentRoute };
};

const MainScreenIntegration = () => {
  const { currentRoute, setCurrentRoute } = useAppContext();
  const [isLoading, setIsLoading] = useState(false);

  const handleRerouteRequest = async () => {
    setIsLoading(true);
    try {
      // Em uma implementação real, isso seria chamado com parâmetros relevantes
      // como origem, destino, preferências do motorista, etc.
      const destination = {
        lat: -22.9068,
        lng: -43.1729
      }; // Rio de Janeiro (exemplo)
      
      const alternatives = await fetchAlternativeRoutes({ destination });
      setIsLoading(false);
      return alternatives;
    } catch (error) {
      console.error("Erro ao buscar rotas:", error);
      setIsLoading(false);
      throw error;
    }
  };

  return (
    <div className="relative h-screen w-full bg-gray-900">
      {/* Mapa principal */}
      <MapContainer
        center={[-23.5505, -46.6333]} // São Paulo como exemplo
        zoom={10}
        className="h-full w-full"
        zoomControl={false}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {/* Aqui seriam adicionadas as camadas de rota, POIs, etc. */}
      </MapContainer>

      {/* Controles de interface */}
      <div className="absolute top-4 left-4 z-10 flex flex-col space-y-2">
        <button className="p-3 bg-black border-2 border-yellow-500 rounded-full shadow-lg hover:bg-gray-900">
          <Menu className="w-6 h-6 text-yellow-500" />
        </button>
        <button className="p-3 bg-black border-2 border-yellow-500 rounded-full shadow-lg hover:bg-gray-900">
          <Layers className="w-6 h-6 text-yellow-500" />
        </button>
        <button className="p-3 bg-black border-2 border-yellow-500 rounded-full shadow-lg hover:bg-gray-900">
          <AlertCircle className="w-6 h-6 text-yellow-500" />
        </button>
      </div>

      {/* Controles de navegação */}
      <div className="absolute bottom-8 right-4 z-10 flex flex-col space-y-2">
        <RerouteButton 
          onRerouteRequest={handleRerouteRequest}
          isLoading={isLoading}
        />
        <button className="p-3 bg-black border-2 border-yellow-500 rounded-full shadow-lg hover:bg-gray-900">
          <Navigation className="w-6 h-6 text-yellow-500" />
        </button>
      </div>
    </div>
  );
};

export default MainScreenIntegration;