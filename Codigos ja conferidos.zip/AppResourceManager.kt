package com.kingroad.utils

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.kingroad.BuildConfig
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import kotlin.math.sqrt

/**
 * Gerenciador responsável por carregar e gerenciar os recursos visuais do aplicativo,
 * incluindo splash screens e logos, otimizados para o tamanho do dispositivo.
 */
class AppResourceManager(private val context: Context) {

    companion object {
        private const val TAG = "AppResourceManager"
        
        // Constantes para preferências
        private const val PREFS_NAME = "kingroad_resources"
        private const val KEY_DEVICE_SIZE = "device_size"
        private const val KEY_RESOURCES_INITIALIZED = "resources_initialized"
        private const val KEY_RESOURCES_VERSION = "resources_version"
        
        // Diretórios para recursos
        private const val SPLASH_DIR = "splash_screens"
        private const val LOGO_DIR = "logos"
        
        // Versão atual dos recursos
        private const val CURRENT_RESOURCES_VERSION = "1.0.0"
    }
    
    // Preferências para armazenar o estado
    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Enum que representa as categorias de tamanho de dispositivo
     */
    enum class DeviceSize(val suffix: String, val displayName: String, val minInches: Double, val maxInches: Double) {
        EXTRA_SMALL("xs", "Extra Pequeno", 0.0, 5.0),      // < 5 polegadas
        SMALL("sm", "Pequeno", 5.0, 7.0),                  // 5-7 polegadas
        MEDIUM("md", "Médio", 7.0, 9.0),                   // 7-9 polegadas
        LARGE("lg", "Grande", 9.0, 11.0),                  // 9-11 polegadas
        EXTRA_LARGE("xl", "Extra Grande", 11.0, Double.MAX_VALUE); // 11+ polegadas
        
        companion object {
            /**
             * Determina a categoria de tamanho com base na diagonal da tela
             */
            fun fromDiagonalInches(inches: Double): DeviceSize {
                return values().find { size -> 
                    inches >= size.minInches && inches < size.maxInches 
                } ?: MEDIUM // Padrão para médio em caso de falha
            }
        }
    }

    /**
     * Detecta o tamanho do dispositivo atual
     * @return DeviceSize categoria do dispositivo
     */
    fun detectDeviceSize(): DeviceSize {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
        
        // Usar método apropriado dependendo da versão do Android
        @Suppress("DEPRECATION") // Para manter compatibilidade com versões mais antigas
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val display = context.display
            display?.getRealMetrics(displayMetrics)
        } else {
            windowManager.defaultDisplay.getRealMetrics(displayMetrics)
        }

        val widthPixels = displayMetrics.widthPixels
        val heightPixels = displayMetrics.heightPixels
        
        // Converter pixels para polegadas
        val xdpi = displayMetrics.xdpi
        val ydpi = displayMetrics.ydpi
        
        val widthInches = widthPixels / xdpi
        val heightInches = heightPixels / ydpi
        
        // Calcular diagonal em polegadas
        val diagonalInches = sqrt((widthInches * widthInches + heightInches * heightInches).toDouble())
        
        // Determinar e salvar categoria
        val deviceSize = DeviceSize.fromDiagonalInches(diagonalInches)
        
        // Salvar nas preferências
        prefs.edit().putString(KEY_DEVICE_SIZE, deviceSize.name).apply()
        
        Log.d(TAG, "Dispositivo detectado: ${deviceSize.displayName} (${diagonalInches.toFloat()}\")")
        
        return deviceSize
    }

    /**
     * Retorna o tamanho do dispositivo armazenado ou detecta se necessário
     */
    fun getDeviceSize(): DeviceSize {
        val storedSize = prefs.getString(KEY_DEVICE_SIZE, null)
        
        return if (storedSize != null) {
            try {
                DeviceSize.valueOf(storedSize)
            } catch (e: IllegalArgumentException) {
                detectDeviceSize()
            }
        } else {
            detectDeviceSize()
        }
    }

    /**
     * Inicializa os recursos do aplicativo com base no tamanho do dispositivo
     * @return true se inicializado com sucesso, false caso contrário
     */
    suspend fun initializeResources(): Boolean = withContext(Dispatchers.IO) {
        try {
            val deviceSize = getDeviceSize()
            
            // Verificar ou criar diretórios
            val splashDir = File(context.filesDir, SPLASH_DIR).apply { mkdirs() }
            val logoDir = File(context.filesDir, LOGO_DIR).apply { mkdirs() }
            
            // Nomes dos arquivos para o tamanho atual
            val splashFileName = "splash_${deviceSize.suffix}.png"
            val logoFileName = "logo_${deviceSize.suffix}.png"
            
            // Caminhos completos
            val splashFile = File(splashDir, splashFileName)
            val logoFile = File(logoDir, logoFileName)
            
            // Extrair os recursos do assets ou baixar da internet
            val splashSuccess = ensureResourceFile(splashFile, "splash_screens/$splashFileName")
            val logoSuccess = ensureResourceFile(logoFile, "logos/$logoFileName")
            
            val success = splashSuccess && logoSuccess
            
            if (success) {
                // Atualizar preferências
                prefs.edit()
                    .putBoolean(KEY_RESOURCES_INITIALIZED, true)
                    .putString(KEY_RESOURCES_VERSION, CURRENT_RESOURCES_VERSION)
                    .apply()
                
                // Limpar recursos não utilizados para economizar espaço
                cleanupUnusedResources()
            }
            
            return@withContext success
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao inicializar recursos: ${e.message}")
            return@withContext false
        }
    }
    
    /**
     * Garante que um arquivo de recurso exista
     * Primeiro tenta copiar de assets, depois tenta baixar da rede
     */
    private suspend fun ensureResourceFile(file: File, assetPath: String): Boolean = withContext(Dispatchers.IO) {
        if (file.exists() && file.length() > 0) {
            return@withContext true
        }
        
        try {
            // Primeiro tenta copiar do assets
            val inputStream = context.assets.open(assetPath)
            val outputStream = FileOutputStream(file)
            
            inputStream.copyTo(outputStream)
            
            inputStream.close()
            outputStream.close()
            
            Log.d(TAG, "Recurso copiado com sucesso: ${file.name}")
            return@withContext true
        } catch (e: IOException) {
            Log.w(TAG, "Recurso não encontrado em assets: $assetPath")
            
            // Se não conseguir do assets, tenta baixar da rede (em produção)
            try {
                // Implementação para download da rede seria aqui
                // Por enquanto vamos apenas simular que temos um fallback
                
                // Tentando usar uma versão "md" como fallback
                val fallbackAssetPath = assetPath.replace(Regex("_(xs|sm|lg|xl)\\.(png|jpg)$"), "_md.$2")
                
                if (assetPath != fallbackAssetPath) {
                    val inputStream = context.assets.open(fallbackAssetPath)
                    val outputStream = FileOutputStream(file)
                    
                    inputStream.copyTo(outputStream)
                    
                    inputStream.close()
                    outputStream.close()
                    
                    Log.d(TAG, "Recurso fallback copiado: ${file.name} (usando recurso médio)")
                    return@withContext true
                }
            } catch (e2: IOException) {
                Log.e(TAG, "Falha no fallback: ${e2.message}")
            }
        }
        
        return@withContext false
    }
    
    /**
     * Limpa recursos não utilizados para economizar espaço
     */
    private suspend fun cleanupUnusedResources() = withContext(Dispatchers.IO) {
        if (BuildConfig.DEBUG) {
            // Em debug, mantém todos os recursos para facilitar os testes
            return@withContext
        }
        
        val currentSize = getDeviceSize()
        
        // Limpar splash screens não utilizados
        cleanupDirectory(File(context.filesDir, SPLASH_DIR), currentSize.suffix, "splash_")
        
        // Limpar logos não utilizados
        cleanupDirectory(File(context.filesDir, LOGO_DIR), currentSize.suffix, "logo_")
    }
    
    /**
     * Limpa um diretório de recursos mantendo apenas os arquivos relevantes
     */
    private fun cleanupDirectory(directory: File, keepSuffix: String, prefix: String) {
        if (!directory.exists() || !directory.isDirectory) return
        
        directory.listFiles()?.forEach { file ->
            // Se for um arquivo do tipo especificado (pelo prefixo)
            // e não for para o tamanho atual de dispositivo, excluir
            if (file.name.startsWith(prefix) && !file.name.contains("_$keepSuffix.")) {
                val deleted = file.delete()
                if (deleted) {
                    Log.d(TAG, "Recurso não utilizado removido: ${file.name}")
                }
            }
        }
    }
    
    /**
     * Obtém o Drawable do splash screen otimizado para o dispositivo
     */
    suspend fun getSplashScreenDrawable(): Drawable? = withContext(Dispatchers.IO) {
        try {
            // Garantir que os recursos estejam inicializados
            if (!prefs.getBoolean(KEY_RESOURCES_INITIALIZED, false)) {
                initializeResources()
            }
            
            val deviceSize = getDeviceSize()
            val splashFileName = "splash_${deviceSize.suffix}.png"
            val splashFile = File(File(context.filesDir, SPLASH_DIR), splashFileName)
            
            if (splashFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(splashFile.absolutePath)
                return@withContext BitmapDrawable(context.resources, bitmap)
            } else {
                // Tenta carregar um recurso embutido como fallback
                val drawableId = context.resources.getIdentifier(
                    "splash_default", 
                    "drawable", 
                    context.packageName
                )
                
                if (drawableId != 0) {
                    return@withContext ContextCompat.getDrawable(context, drawableId)
                }
            }
            
            return@withContext null
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar splash screen: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Obtém o Drawable do logo otimizado para o dispositivo
     */
    suspend fun getLogoDrawable(): Drawable? = withContext(Dispatchers.IO) {
        try {
            // Garantir que os recursos estejam inicializados
            if (!prefs.getBoolean(KEY_RESOURCES_INITIALIZED, false)) {
                initializeResources()
            }
            
            val deviceSize = getDeviceSize()
            val logoFileName = "logo_${deviceSize.suffix}.png"
            val logoFile = File(File(context.filesDir, LOGO_DIR), logoFileName)
            
            if (logoFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(logoFile.absolutePath)
                return@withContext BitmapDrawable(context.resources, bitmap)
            } else {
                // Tenta carregar um recurso embutido como fallback
                val drawableId = context.resources.getIdentifier(
                    "logo_default", 
                    "drawable", 
                    context.packageName
                )
                
                if (drawableId != 0) {
                    return@withContext ContextCompat.getDrawable(context, drawableId)
                }
            }
            
            return@withContext null
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar logo: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Obtém o Bitmap do splash screen otimizado para o dispositivo
     */
    suspend fun getSplashScreenBitmap(): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val drawable = getSplashScreenDrawable()
            if (drawable is BitmapDrawable) {
                return@withContext drawable.bitmap
            }
            return@withContext null
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar bitmap do splash screen: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Obtém o Bitmap do logo otimizado para o dispositivo
     */
    suspend fun getLogoBitmap(): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val drawable = getLogoDrawable()
            if (drawable is BitmapDrawable) {
                return@withContext drawable.bitmap
            }
            return@withContext null
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar bitmap do logo: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Verifica se há atualizações disponíveis para os recursos
     */
    suspend fun checkForUpdates(): Boolean = withContext(Dispatchers.IO) {
        // Implementação em produção faria uma chamada de API para verificar
        // a versão mais recente dos recursos
        
        // Por enquanto, apenas verificamos se os recursos estão inicializados
        return@withContext !prefs.getBoolean(KEY_RESOURCES_INITIALIZED, false)
    }
    
    /**
     * Força uma reinicialização dos recursos
     */
    suspend fun forceUpdate(): Boolean = withContext(Dispatchers.IO) {
        // Resetar o flag de inicializado
        prefs.edit()
            .putBoolean(KEY_RESOURCES_INITIALIZED, false)
            .apply()
            
        // Reinicializar
        return@withContext initializeResources()
    }
    
    /**
     * Retorna informações sobre o tamanho do dispositivo atual em formato de mapa
     */
    fun getDeviceInfo(): Map<String, Any> {
        val deviceSize = getDeviceSize()
        
        return mapOf(
            "sizeCategory" to deviceSize.name,
            "displayName" to deviceSize.displayName,
            "suffix" to deviceSize.suffix,
            "minInches" to deviceSize.minInches,
            "maxInches" to deviceSize.maxInches,
            "initialized" to prefs.getBoolean(KEY_RESOURCES_INITIALIZED, false),
            "resourcesVersion" to prefs.getString(KEY_RESOURCES_VERSION, "unknown")!!
        )
    }
}