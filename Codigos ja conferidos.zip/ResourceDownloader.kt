package com.kingfamily.common.utils

import android.content.Context
import android.util.DisplayMetrics
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Utilitário responsável pelo download e gerenciamento de recursos visuais
 * da Família King, incluindo logos, splash screens e outros elementos visuais.
 */
class ResourceDownloader(private val context: Context) {

    companion object {
        private const val TAG = "ResourceDownloader"
        private const val BASE_URL = "https://cdn.king-family.com/assets/"
        private const val TIMEOUT_CONNECTION = 15000 // 15 segundos
        private const val RETRY_COUNT = 3
        
        // Diretório onde os recursos baixados serão armazenados
        private const val RESOURCES_DIR = "king_resources"
        
        // Tipos de recursos que podem ser baixados
        enum class ResourceType {
            LOGO, SPLASH_SCREEN, ICON
        }
        
        // Categorias de tamanho de tela
        enum class ScreenSizeCategory {
            SMALL, MEDIUM, LARGE, XLARGE
        }
    }
    
    // Diretório onde os recursos serão armazenados
    private val resourcesDir: File by lazy {
        File(context.filesDir, RESOURCES_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    /**
     * Determina a categoria de tamanho da tela do dispositivo atual
     */
    fun getScreenSizeCategory(): ScreenSizeCategory {
        val displayMetrics = context.resources.displayMetrics
        val density = displayMetrics.density
        
        // Convertendo pixels para dp
        val widthDp = displayMetrics.widthPixels / density
        val heightDp = displayMetrics.heightPixels / density
        val screenSizeDp = Math.max(widthDp, heightDp)
        
        return when {
            screenSizeDp < 480 -> ScreenSizeCategory.SMALL
            screenSizeDp < 720 -> ScreenSizeCategory.MEDIUM
            screenSizeDp < 1080 -> ScreenSizeCategory.LARGE
            else -> ScreenSizeCategory.XLARGE
        }
    }
    
    /**
     * Download de todos os recursos necessários para o aplicativo
     * com base no tamanho da tela.
     */
    suspend fun downloadAllResources(appName: String) = withContext(Dispatchers.IO) {
        val screenSize = getScreenSizeCategory()
        val resources = listOf(
            Triple(ResourceType.LOGO, appName, screenSize),
            Triple(ResourceType.SPLASH_SCREEN, appName, screenSize)
        )
        
        resources.forEach { (type, app, size) ->
            try {
                downloadResource(type, app, size)
            } catch (e: Exception) {
                Log.e(TAG, "Falha ao baixar recurso: $type para $app", e)
                // Em caso de falha, o app usará o fallback embutido no APK
            }
        }
    }
    
    /**
     * Download de um recurso específico.
     */
    suspend fun downloadResource(
        type: ResourceType,
        appName: String,
        screenSize: ScreenSizeCategory
    ): File? = withContext(Dispatchers.IO) {
        val fileName = getResourceFileName(type, appName, screenSize)
        val localFile = File(resourcesDir, fileName)
        
        // Verifica se o arquivo já existe localmente e está atualizado
        if (localFile.exists() && isResourceUpToDate(localFile)) {
            return@withContext localFile
        }
        
        // Construção da URL para download do recurso
        val resourceUrl = buildResourceUrl(type, appName, screenSize)
        
        var attempts = 0
        var success = false
        
        while (attempts < RETRY_COUNT && !success) {
            attempts++
            try {
                val url = URL(resourceUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = TIMEOUT_CONNECTION
                connection.readTimeout = TIMEOUT_CONNECTION
                
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream.use { input ->
                        FileOutputStream(localFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    success = true
                } else {
                    Log.w(TAG, "Falha no download, HTTP ${connection.responseCode}, tentativa $attempts")
                    delay(1000) // Espera 1 segundo antes da próxima tentativa
                }
                
                connection.disconnect()
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao baixar recurso, tentativa $attempts", e)
                delay(1000)
            }
        }
        
        if (success) {
            // Atualiza o timestamp do arquivo para controle de cache
            updateResourceTimestamp(localFile)
            localFile
        } else {
            null
        }
    }
    
    /**
     * Constrói a URL para o recurso no CDN.
     */
    private fun buildResourceUrl(type: ResourceType, appName: String, screenSize: ScreenSizeCategory): String {
        val resourceName = when (type) {
            ResourceType.LOGO -> "logo_king_family"
            ResourceType.SPLASH_SCREEN -> "splash_screen"
            ResourceType.ICON -> "icon"
        }
        
        val sizeStr = screenSize.name.lowercase()
        val appNameLower = appName.lowercase()
        
        return "${BASE_URL}${appNameLower}/${resourceName}_${sizeStr}.png"
    }
    
    /**
     * Obtém o nome do arquivo local para o recurso.
     */
    private fun getResourceFileName(type: ResourceType, appName: String, screenSize: ScreenSizeCategory): String {
        val resourceName = when (type) {
            ResourceType.LOGO -> "logo_king_family"
            ResourceType.SPLASH_SCREEN -> "splash_screen"
            ResourceType.ICON -> "icon"
        }
        
        val sizeStr = screenSize.name.lowercase()
        val appNameLower = appName.lowercase()
        
        return "${appNameLower}_${resourceName}_${sizeStr}.png"
    }
    
    /**
     * Verifica se o recurso está atualizado ou precisa ser baixado novamente.
     * Por padrão, considera o recurso válido por 7 dias.
     */
    private fun isResourceUpToDate(file: File): Boolean {
        val lastModified = file.lastModified()
        val currentTime = System.currentTimeMillis()
        val diffDays = TimeUnit.MILLISECONDS.toDays(currentTime - lastModified)
        
        // Considera recursos válidos por 7 dias
        return diffDays < 7
    }
    
    /**
     * Atualiza o timestamp do arquivo para controle de cache.
     */
    private fun updateResourceTimestamp(file: File) {
        file.setLastModified(System.currentTimeMillis())
    }
    
    /**
     * Obtém o arquivo para um recurso específico.
     * Se o arquivo não existir localmente, retorna null.
     */
    fun getResourceFile(type: ResourceType, appName: String, screenSize: ScreenSizeCategory): File? {
        val fileName = getResourceFileName(type, appName, screenSize)
        val file = File(resourcesDir, fileName)
        return if (file.exists()) file else null
    }
    
    /**
     * Limpa o cache de recursos.
     */
    suspend fun clearResourceCache() = withContext(Dispatchers.IO) {
        resourcesDir.listFiles()?.forEach { it.delete() }
    }
}