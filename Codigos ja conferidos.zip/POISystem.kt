// Sistema de POIs do King Road
// app/src/main/kotlin/com/kingroad/poi

// Entidades principais
data class POI(
    val id: String,
    val name: String,
    val location: Location,
    val type: POIType,
    val facilities: Facilities,
    val vehicleSupport: VehicleSupport,
    val lastUpdate: Long = System.currentTimeMillis(),
    val verifications: List<Verification> = emptyList()
)

enum class POIType {
    TRUCK_STOP,
    REST_AREA,
    FUEL_STATION,
    RESTAURANT,
    HOTEL,
    CAMPING,
    PARKING_AREA
}

data class Facilities(
    val parking: ParkingFacilities,
    val services: Services,
    val access: AccessInfo
)

data class ParkingFacilities(
    val truckSpots: Int? = null,
    val rvSpots: Int? = null,
    val carSpots: Int? = null,
    val busSpots: Int? = null,
    val secureParking: Boolean = false,
    val overnightParking: Boolean = false,
    val paidParkingOnly: Boolean = false,
    val lastUpdate: Long = System.currentTimeMillis()
)

data class Services(
    val shower: Boolean = false,
    val restaurant: Boolean = false,
    val repair: Boolean = false,
    val restroom: Boolean = false,
    val wifi: Boolean = false,
    val laundry: Boolean = false,
    val fuel: FuelTypes? = null
)

data class AccessInfo(
    val maxHeight: Double? = null,
    val maxWeight: Double? = null,
    val turningRadius: Double? = null,
    val pavementType: PavementType? = null,
    val lighting: Boolean = false,
    val security24h: Boolean = false
)

data class VehicleSupport(
    val trucks: Boolean = false,
    val rvs: Boolean = false,
    val cars: Boolean = true,
    val buses: Boolean = false,
    val motorcycles: Boolean = true
)

// Gerenciador de POIs
class POIManager(
    private val database: LocalDatabase,
    private val poiService: POIService,
    private val locationService: LocationService
) {
    suspend fun getNearbyPOIs(
        location: Location,
        radius: Double,
        vehicleType: VehicleType
    ): List<POI> {
        val allPOIs = database.getNearbyPOIs(location, radius)
        return filterPOIsByVehicleType(allPOIs, vehicleType)
    }
    
    private fun filterPOIsByVehicleType(pois: List<POI>, vehicleType: VehicleType): List<POI> {
        return pois.filter { poi ->
            when (vehicleType) {
                VehicleType.TRUCK -> {
                    poi.vehicleSupport.trucks &&
                    poi.facilities.parking.truckSpots != null &&
                    poi.facilities.parking.truckSpots > 0 &&
                    !poi.facilities.parking.paidParkingOnly
                }
                VehicleType.RV -> {
                    (poi.vehicleSupport.rvs || poi.vehicleSupport.trucks) &&
                    (poi.facilities.parking.rvSpots != null || poi.facilities.parking.truckSpots != null)
                }
                VehicleType.BUS -> {
                    poi.vehicleSupport.buses &&
                    poi.facilities.parking.busSpots != null &&
                    poi.facilities.parking.busSpots > 0
                }
                else -> true // Carros e motos podem acessar todos os POIs
            }
        }
    }
}

// Sistema de verificação de POIs
class POIVerificationSystem(
    private val database: LocalDatabase,
    private val verificationService: VerificationService
) {
    suspend fun submitVerification(
        poiId: String,
        verification: Verification
    ) {
        database.saveVerification(poiId, verification)
        verificationService.sendVerification(verification)
        
        updatePOIStatus(poiId)
    }
    
    private suspend fun updatePOIStatus(poiId: String) {
        val recentVerifications = database.getRecentVerifications(
            poiId,
            timeWindow = 24 * 60 * 60 * 1000 // 24 horas
        )
        
        if (recentVerifications.size >= 3) {
            val consensus = calculateConsensus(recentVerifications)
            database.updatePOIStatus(poiId, consensus)
        }
    }
    
    private fun calculateConsensus(verifications: List<Verification>): POIStatus {
        // Lógica para determinar o status com base nas verificações
        return POIStatus()
    }
}

// Interface de banco de dados para POIs
interface POIDatabase {
    suspend fun getNearbyPOIs(location: Location, radius: Double): List<POI>
    suspend fun savePOI(poi: POI)
    suspend fun saveVerification(poiId: String, verification: Verification)
    suspend fun getRecentVerifications(poiId: String, timeWindow: Long): List<Verification>
    suspend fun updatePOIStatus(poiId: String, status: POIStatus)
}

// Enums auxiliares
enum class PavementType {
    ASPHALT,
    CONCRETE,
    GRAVEL,
    DIRT
}

enum class FuelTypes {
    DIESEL,
    DEF,
    GASOLINE,
    ELECTRIC_CHARGING
}