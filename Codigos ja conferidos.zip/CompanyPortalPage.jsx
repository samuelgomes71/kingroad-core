import React from 'react';
import CompanyPortal from '../components/portal/CompanyPortal';

const CompanyPortalPage = () => {
  return <CompanyPortal />;
};

export default CompanyPortalPage;