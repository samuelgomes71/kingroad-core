import React, { createContext, useContext, useState, useEffect } from 'react';
import StorageService from '../utils/StorageService';
import DatabaseService from '../database/DatabaseService';

/**
 * Contexto central da aplicação para gerenciamento de estado
 */
const AppContext = createContext();

/**
 * Hook personalizado para usar o contexto da aplicação
 * @returns {Object} O contexto da aplicação
 */
export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext deve ser usado dentro de um AppProvider');
  }
  return context;
};

/**
 * Provider do contexto da aplicação
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Componentes filhos
 */
export const AppProvider = ({ children }) => {
  // Estado do mapa
  const [mapData, setMapData] = useState(null);
  
  // Preferências do usuário
  const [userPreferences, setUserPreferences] = useState({
    darkMode: true,
    language: 'pt-BR',
    routePreferences: {
      avoidTolls: false,
      avoidHighways: false,
      preferScenicRoutes: false
    },
    alertPreferences: {
      tiroteio: true,
      sequestro: true,
      roubo_carga: true,
      veiculo_suspeito: true,
      alta_velocidade: true
    },
    mapPreferences: {
      defaultView: 'full', // full, route, simplified
      showPOIs: true,
      showTraffic: true
    }
  });
  
  // Dados offline
  const [offlineData, setOfflineData] = useState({
    blockedRoads: [],
    preferredRoads: [],
    truckStops: [],
    trafficSigns: []
  });
  
  // Alertas de segurança
  const [securityAlerts, setSecurityAlerts] = useState([]);
  
  // Rotas salvas
  const [savedRoutes, setSavedRoutes] = useState([]);
  
  // Estado de carregamento
  const [loading, setLoading] = useState({
    map: false,
    preferences: false,
    alerts: false,
    routes: false
  });
  
  // Estado de erro
  const [errors, setErrors] = useState({
    map: null,
    preferences: null,
    alerts: null,
    routes: null
  });

  // Carregar preferências do usuário
  useEffect(() => {
    const loadUserPreferences = async () => {
      try {
        setLoading(prev => ({ ...prev, preferences: true }));
        const storedPreferences = await StorageService.getData('userPreferences');
        if (storedPreferences) {
          setUserPreferences(prev => ({ ...prev, ...storedPreferences }));
        }
        setLoading(prev => ({ ...prev, preferences: false }));
      } catch (error) {
        console.error('Erro ao carregar preferências:', error);
        setErrors(prev => ({ ...prev, preferences: error.message }));
        setLoading(prev => ({ ...prev, preferences: false }));
      }
    };
    
    loadUserPreferences();
  }, []);
  
  // Salvar preferências do usuário quando alteradas
  useEffect(() => {
    const saveUserPreferences = async () => {
      try {
        await StorageService.saveData('userPreferences', userPreferences);
      } catch (error) {
        console.error('Erro ao salvar preferências:', error);
      }
    };
    
    saveUserPreferences();
  }, [userPreferences]);
  
  // Carregar alertas de segurança
  const loadSecurityAlerts = async () => {
    try {
      setLoading(prev => ({ ...prev, alerts: true }));
      const alerts = await DatabaseService.getSecurityAlerts();
      setSecurityAlerts(alerts);
      setLoading(prev => ({ ...prev, alerts: false }));
    } catch (error) {
      console.error('Erro ao carregar alertas:', error);
      setErrors(prev => ({ ...prev, alerts: error.message }));
      setLoading(prev => ({ ...prev, alerts: false }));
    }
  };
  
  // Carregar rotas salvas
  const loadSavedRoutes = async () => {
    try {
      setLoading(prev => ({ ...prev, routes: true }));
      const routes = await DatabaseService.getSavedRoutes();
      setSavedRoutes(routes);
      setLoading(prev => ({ ...prev, routes: false }));
    } catch (error) {
      console.error('Erro ao carregar rotas:', error);
      setErrors(prev => ({ ...prev, routes: error.message }));
      setLoading(prev => ({ ...prev, routes: false }));
    }
  };
  
  // Adicionar alerta de segurança
  const addSecurityAlert = async (alert) => {
    try {
      const alertId = await DatabaseService.saveSecurityAlert(alert);
      const newAlert = { ...alert, id: alertId, createdAt: Date.now() };
      setSecurityAlerts(prev => [newAlert, ...prev]);
      return alertId;
    } catch (error) {
      console.error('Erro ao adicionar alerta:', error);
      throw error;
    }
  };
  
  // Salvar rota
  const saveRoute = async (route) => {
    try {
      const routeId = await DatabaseService.saveRoute(route);
      const newRoute = { ...route, id: routeId, createdAt: Date.now() };
      setSavedRoutes(prev => [newRoute, ...prev]);
      return routeId;
    } catch (error) {
      console.error('Erro ao salvar rota:', error);
      throw error;
    }
  };
  
  // Atualizar dados do mapa
  const updateMapData = async (data) => {
    try {
      setLoading(prev => ({ ...prev, map: true }));
      setMapData(data);
      await DatabaseService.saveMapData(data);
      setLoading(prev => ({ ...prev, map: false }));
    } catch (error) {
      console.error('Erro ao atualizar dados do mapa:', error);
      setErrors(prev => ({ ...prev, map: error.message }));
      setLoading(prev => ({ ...prev, map: false }));
    }
  };

  return (
    <AppContext.Provider 
      value={{
        // Estado do mapa
        mapData,
        setMapData: updateMapData,
        
        // Preferências do usuário
        userPreferences,
        setUserPreferences,
        
        // Dados offline
        offlineData,
        setOfflineData,
        
        // Alertas de segurança
        securityAlerts,
        loadSecurityAlerts,
        addSecurityAlert,
        
        // Rotas salvas
        savedRoutes,
        loadSavedRoutes,
        saveRoute,
        
        // Estado de carregamento e erros
        loading,
        errors,
        
        // Métodos de utilidade
        clearErrors: () => setErrors({
          map: null,
          preferences: null,
          alerts: null,
          routes: null
        })
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export default AppContext;