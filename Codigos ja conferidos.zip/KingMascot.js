import React, { useState, useEffect } from 'react';
import { MapPin, Flag, MessageSquare, ThumbsUp } from 'lucide-react';

// Componente de mascote animado com variações regionais
// Implementa o componente futuro descrito em globalRecommendations: "KingMascot.js"
// O mascote "Tio Sam" tem variações regionais e pode ser usado no splash e interações

const KingMascot = ({
  country = 'brazil',
  language = 'pt',
  animation = 'idle', // idle, greeting, pointing, celebrating, talking
  message = '',
  autoHide = false,
  position = 'bottom-right', // top-left, top-right, bottom-left, bottom-right
  onInteraction = () => {}
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [currentAnimation, setCurrentAnimation] = useState(animation);
  const [showMessage, setShowMessage] = useState(!!message);
  const [hasInteracted, setHasInteracted] = useState(false);
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      greeting: 'Olá! Como posso ajudar?',
      pointsOfInterest: 'Pontos de interesse próximos',
      routeTip: 'Toque para planejar sua rota',
      welcomeBack: 'Bem-vindo de volta!',
      hide: 'Esconder mascote',
      show: 'Mostrar mascote'
    },
    en: {
      greeting: 'Hello! How can I help?',
      pointsOfInterest: 'Nearby points of interest',
      routeTip: 'Tap to plan your route',
      welcomeBack: 'Welcome back!',
      hide: 'Hide mascot',
      show: 'Show mascot'
    },
    es: {
      greeting: '¡Hola! ¿Cómo puedo ayudar?',
      pointsOfInterest: 'Puntos de interés cercanos',
      routeTip: 'Toca para planificar tu ruta',
      welcomeBack: '¡Bienvenido de vuelta!',
      hide: 'Ocultar mascota',
      show: 'Mostrar mascota'
    }
  };
  
  // Texto conforme o idioma, com fallback para inglês
  const text = translations[language] || translations.en;
  
  // Definição das variações regionais do mascote
  const regionalMascots = {
    brazil: {
      name: 'Tio Sam Carioca',
      primaryColor: '#009c3b', // Verde da bandeira brasileira
      secondaryColor: '#ffdf00', // Amarelo da bandeira brasileira
      hat: 'Panama hat',
      outfit: 'yellow and green',
      accessory: 'sunglasses'
    },
    usa: {
      name: 'Uncle Sam',
      primaryColor: '#3C3B6E', // Azul da bandeira americana
      secondaryColor: '#B22234', // Vermelho da bandeira americana
      hat: 'top hat with stars',
      outfit: 'blue coat and red stripes',
      accessory: 'bow tie'
    },
    mexico: {
      name: 'Tío Samuel',
      primaryColor: '#006847', // Verde da bandeira mexicana
      secondaryColor: '#ce1126', // Vermelho da bandeira mexicana
      hat: 'sombrero',
      outfit: 'traditional Mexican colors',
      accessory: 'mustache'
    },
    argentina: {
      name: 'Tío Samuel Porteño',
      primaryColor: '#75aadb', // Azul claro da bandeira argentina
      secondaryColor: '#fcbf49', // Amarelo/sol da bandeira argentina
      hat: 'boina',
      outfit: 'sky blue and white',
      accessory: 'mate cup'
    }
  };
  
  // Mascote para o país atual, com fallback para Brasil
  const currentMascot = regionalMascots[country] || regionalMascots.brazil;
  
  // Efeito para auto-ocultar o mascote após um tempo
  useEffect(() => {
    if (autoHide && isVisible && !showMessage) {
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 10000); // 10 segundos
      
      return () => clearTimeout(timer);
    }
  }, [autoHide, isVisible, showMessage]);
  
  // Atualiza a animação quando a prop animation muda
  useEffect(() => {
    setCurrentAnimation(animation);
  }, [animation]);
  
  // Atualiza a mensagem quando a prop message muda
  useEffect(() => {
    setShowMessage(!!message);
  }, [message]);
  
  // Função para interagir com o mascote
  const handleInteraction = () => {
    // Alterna entre animações de saudação e apontamento se estiver em idle
    if (currentAnimation === 'idle') {
      setCurrentAnimation('greeting');
      setTimeout(() => setCurrentAnimation('idle'), 2000);
    }
    
    // Exibe uma mensagem se não estiver mostrando uma
    if (!showMessage) {
      setShowMessage(true);
      setTimeout(() => setShowMessage(false), 4000);
    }
    
    setHasInteracted(true);
    onInteraction();
  };
  
  // Função para alternar a visibilidade do mascote
  const toggleVisibility = () => {
    setIsVisible(!isVisible);
  };
  
  // Define classes CSS com base na posição
  const positionClasses = {
    'top-left': 'top-4 left-4',
    'top-right': 'top-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'bottom-right': 'bottom-4 right-4'
  };
  
  // Define estilo de animação com base na animação atual
  const animationStyles = {
    idle: 'animate-bounce-subtle',
    greeting: 'animate-wave',
    pointing: 'animate-point',
    celebrating: 'animate-celebrate',
    talking: 'animate-talk'
  };
  
  // Renderiza o botão para alternar visibilidade do mascote quando ele está oculto
  if (!isVisible) {
    return (
      <button
        onClick={toggleVisibility}
        className={`fixed z-40 ${positionClasses[position]} p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors`}
        aria-label={text.show}
      >
        <div 
          className="w-10 h-10 rounded-full flex items-center justify-center" 
          style={{ backgroundColor: currentMascot.primaryColor }}
        >
          <Flag size={20} className="text-white" />
        </div>
      </button>
    );
  }
  
  // Renderiza o mascote e sua mensagem quando visível
  return (
    <div className={`fixed z-40 ${positionClasses[position]}`}>
      {/* Balão de mensagem */}
      {showMessage && (
        <div 
          className="mb-2 p-3 bg-white rounded-lg shadow-lg max-w-xs animate-fade-in"
          style={{ borderLeft: `4px solid ${currentMascot.primaryColor}` }}
        >
          <p className="text-sm">{message || text.greeting}</p>
          <div 
            className="absolute w-4 h-4 bg-white transform rotate-45"
            style={{ 
              bottom: '-8px', 
              [position.includes('left') ? 'left' : 'right']: '24px' 
            }}
          ></div>
        </div>
      )}
      
      {/* Contêiner do mascote */}
      <div className="flex items-end">
        {/* Botão de esconder */}
        <button
          onClick={toggleVisibility}
          className="mr-2 p-1 rounded-full bg-white shadow-sm hover:bg-gray-100 transition-colors"
          aria-label={text.hide}
        >
          <ThumbsUp size={16} className="text-gray-500" />
        </button>
        
        {/* Mascote interativo */}
        <button
          onClick={handleInteraction}
          className={`relative ${animationStyles[currentAnimation] || 'animate-bounce-subtle'}`}
        >
          {/* Avatar do mascote - Simplificado como uma representação visual básica */}
          <div className="relative">
            {/* Corpo */}
            <div 
              className="w-16 h-16 rounded-full shadow-lg flex items-center justify-center"
              style={{ backgroundColor: currentMascot.primaryColor }}
            >
              {/* Rosto (simplificado) */}
              <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
                <div 
                  className="w-6 h-6 rounded-full"
                  style={{ backgroundColor: currentMascot.secondaryColor }}
                ></div>
              </div>
            </div>
            
            {/* Chapéu (simplificado) */}
            <div 
              className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-12 h-4 rounded-t-full"
              style={{ backgroundColor: currentMascot.secondaryColor }}
            ></div>
            
            {/* Acessório específico do país (simplificado) */}
            {country === 'mexico' && (
              <div 
                className="absolute -top-5 left-1/2 transform -translate-x-1/2 w-20 h-2 rounded-full"
                style={{ backgroundColor: currentMascot.secondaryColor }}
              ></div>
            )}
            
            {country === 'usa' && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-xs">🇺🇸</div>
            )}
            
            {country === 'brazil' && (
              <div className="absolute -top-5 right-1 text-xl">⚽</div>
            )}
            
            {country === 'argentina' && (
              <div className="absolute -top-4 left-0 text-sm">🧉</div>
            )}
            
            {/* Indicador de mensagem */}
            {!showMessage && hasInteracted && (
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 border-2 border-white"></div>
            )}
          </div>
          
          {/* Nome do mascote */}
          <span 
            className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 text-xs font-medium bg-white px-1 rounded whitespace-nowrap"
            style={{ color: currentMascot.primaryColor }}
          >
            {currentMascot.name}
          </span>
        </button>
        
        {/* Botão de ação contextual */}
        <button
          onClick={() => {
            setCurrentAnimation('pointing');
            setShowMessage(true);
            setTimeout(() => {
              setCurrentAnimation('idle');
              setShowMessage(false);
            }, 3000);
            onInteraction('action');
          }}
          className="ml-2 p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors"
        >
          <MessageSquare 
            size={16} 
            style={{ color: currentMascot.primaryColor }} 
          />
        </button>
      </div>
      
      {/* Estilos para animações */}
      <style jsx>{`
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        
        @keyframes wave {
          0% { transform: rotate(0deg); }
          25% { transform: rotate(-15deg); }
          50% { transform: rotate(0deg); }
          75% { transform: rotate(-15deg); }
          100% { transform: rotate(0deg); }
        }
        
        @keyframes point {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-10px) translateX(5px); }
          100% { transform: translateY(0) translateX(0); }
        }
        
        @keyframes celebrate {
          0% { transform: scale(1) rotate(0deg); }
          25% { transform: scale(1.2) rotate(-15deg); }
          50% { transform: scale(1) rotate(0deg); }
          75% { transform: scale(1.2) rotate(15deg); }
          100% { transform: scale(1) rotate(0deg); }
        }
        
        @keyframes talk {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(1.1); }
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-bounce-subtle {
          animation: bounce-subtle 3s ease-in-out infinite;
        }
        
        .animate-wave {
          animation: wave 1s ease-in-out;
        }
        
        .animate-point {
          animation: point 1.5s ease-in-out;
        }
        
        .animate-celebrate {
          animation: celebrate 1s ease-in-out;
        }
        
        .animate-talk {
          animation: talk 0.3s ease-in-out infinite;
        }
        
        .animate-fade-in {
          animation: fade-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default KingMascot;