@Entity(tableName = "data_usage")
data class DataUsageRecord(
    @PrimaryKey val timestamp: Long,
    @ColumnInfo(name = "feature") val feature: String,
    @ColumnInfo(name = "bytes_transferred") val bytesTransferred: Long
)

@Dao
interface DataUsageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: DataUsageRecord)

    @Query("SELECT * FROM data_usage WHERE timestamp BETWEEN :startTime AND :endTime")
    suspend fun getUsageRecords(startTime: Long, endTime: Long): List<DataUsageRecord>
}

@Database(entities = [DataUsageRecord::class], version = 2)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dataUsageDao(): DataUsageDao
}