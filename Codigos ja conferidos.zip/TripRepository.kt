// TripRepository.kt
package com.kingroad.database

import android.content.Context
import com.kingroad.utils.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Repositório para gerenciamento de viagens no King Road
 */
class TripRepository(context: Context) {
    companion object {
        private const val TAG = "TripRepository"
        private const val DAYS_TO_KEEP = 15 // Dias para manter no histórico
    }

    private val database: AppDatabase = AppDatabase.getInstance(context)
    private val tripDao: TripDao = database.tripDao()

    /**
     * Obtém os IDs das últimas viagens
     * @param count Número de viagens para retornar
     * @return Lista de IDs das últimas viagens
     */
    suspend fun getLastTripIds(count: Int): List<Long> = withContext(Dispatchers.IO) {
        return@withContext tripDao.getLastTripIds(count)
    }

    /**
     * Obtém os IDs das viagens dos últimos X dias
     * @param days Número de dias para considerar (padrão: 15)
     * @return Lista de IDs das viagens no período
     */
    suspend fun getTripsFromLastDays(days: Int = DAYS_TO_KEEP): List<Long> = withContext(Dispatchers.IO) {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -days)
        val cutoffDate = calendar.timeInMillis
        
        Logger.d(TAG, "Obtendo viagens posteriores a ${Date(cutoffDate)}")
        return@withContext tripDao.getTripIdsAfterDate(cutoffDate)
    }
    
    /**
     * Obtém todas as viagens após uma data específica
     * @param date Data de referência em milissegundos
     * @return Lista de entidades de viagem
     */
    suspend fun getTripsAfterDate(date: Long): List<TripEntity> = withContext(Dispatchers.IO) {
        return@withContext tripDao.getTripsAfterDate(date)
    }

    /**
     * Exclui todas as viagens exceto as especificadas pelos IDs
     * @param tripIdsToKeep Lista de IDs de viagens para manter
     */
    suspend fun deleteAllExcept(tripIdsToKeep: List<Long>) = withContext(Dispatchers.IO) {
        val excludeIds = if (tripIdsToKeep.isEmpty()) listOf(-1L) else tripIdsToKeep
        tripDao.deleteAllExcept(excludeIds)
    }

    /**
     * Mantém apenas as viagens dos últimos X dias e um número específico de últimas viagens
     * @param daysToKeep Número de dias para manter viagens (padrão: 15)
     * @param minTripsToKeep Número mínimo de viagens para manter, independente da data (padrão: 2)
     */
    suspend fun cleanupTripHistory(daysToKeep: Int = DAYS_TO_KEEP, minTripsToKeep: Int = 2) = withContext(Dispatchers.IO) {
        try {
            // Obter IDs das viagens dos últimos dias
            val recentTripIds = getTripsFromLastDays(daysToKeep)
            
            // Obter IDs das últimas viagens (caso não tenhamos o mínimo no período)
            val lastTripIds = if (recentTripIds.size < minTripsToKeep) {
                getLastTripIds(minTripsToKeep)
            } else {
                emptyList()
            }
            
            // Combinar os conjuntos de IDs para preservar
            val idsToKeep = (recentTripIds + lastTripIds).distinct()
            
            // Excluir o restante
            if (idsToKeep.isNotEmpty()) {
                deleteAllExcept(idsToKeep)
                Logger.d(TAG, "Mantidas ${idsToKeep.size} viagens no histórico")
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Erro ao limpar histórico de viagens: ${e.message}")
        }
    }
}