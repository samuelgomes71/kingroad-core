// GroupAdditionControlScreen.js
// Componente para controle de quem pode adicionar o usuário a grupos

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Switch, Alert } from 'react-native';
import { getContacts, updatePrivacySettings, getPrivacySettings } from '../services/api';
import { Ionicons } from '@expo/vector-icons';

const GroupAdditionControlScreen = () => {
  const [privacyOption, setPrivacyOption] = useState('all'); // 'all', 'selected', 'none'
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch user contacts and current group addition privacy settings
    const fetchData = async () => {
      try {
        setLoading(true);
        const contactsData = await getContacts();
        const privacySettings = await getPrivacySettings();
        
        setContacts(contactsData);
        setPrivacyOption(privacySettings.groupAdditionOption || 'all');
        setSelectedContacts(privacySettings.selectedContactsForGroupAddition || []);
      } catch (error) {
        console.error('Error fetching data:', error);
        Alert.alert('Erro', 'Não foi possível carregar as configurações de privacidade');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handlePrivacyOptionChange = (option) => {
    setPrivacyOption(option);
  };

  const toggleContactSelection = (contactId) => {
    setSelectedContacts(prevSelected => {
      if (prevSelected.includes(contactId)) {
        return prevSelected.filter(id => id !== contactId);
      } else {
        return [...prevSelected, contactId];
      }
    });
  };

  const blockAllGroupAdditions = () => {
    Alert.alert(
      'Bloquear Adições a Grupos',
      'Tem certeza que deseja bloquear todas as adições a grupos?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Confirmar',
          onPress: () => {
            setPrivacyOption('none');
            setSelectedContacts([]);
          },
        },
      ]
    );
  };

  const savePrivacySettings = async () => {
    try {
      setLoading(true);
      await updatePrivacySettings({
        groupAdditionOption: privacyOption,
        selectedContactsForGroupAddition: privacyOption === 'selected' ? selectedContacts : []
      });
      
      Alert.alert('Sucesso', 'Configurações de privacidade atualizadas com sucesso');
    } catch (error) {
      console.error('Error saving privacy settings:', error);
      Alert.alert('Erro', 'Não foi possível atualizar as configurações de privacidade');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Controle de Adição a Grupos</Text>
        <Text style={styles.description}>
          Defina quem pode adicioná-lo a grupos no KingChat
        </Text>
      </View>

      <View style={styles.optionsContainer}>
        <TouchableOpacity 
          style={[styles.option, privacyOption === 'all' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('all')}
        >
          <Text style={styles.optionText}>Todos os Contatos</Text>
          <Text style={styles.optionDescription}>Qualquer contato pode adicioná-lo a grupos</Text>
          {privacyOption === 'all' && <Ionicons name="checkmark-circle" size={24} color="#4285f4" />}
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.option, privacyOption === 'selected' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('selected')}
        >
          <Text style={styles.optionText}>Contatos Selecionados</Text>
          <Text style={styles.optionDescription}>Apenas contatos específicos podem adicioná-lo</Text>
          {privacyOption === 'selected' && <Ionicons name="checkmark-circle" size={24} color="#4285f4" />}
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.option, privacyOption === 'none' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('none')}
        >
          <Text style={styles.optionText}>Ninguém</Text>
          <Text style={styles.optionDescription}>Ninguém pode adicioná-lo a grupos</Text>
          {privacyOption === 'none' && <Ionicons name="checkmark-circle" size={24} color="#4285f4" />}
        </TouchableOpacity>
      </View>

      <TouchableOpacity 
        style={styles.blockButton}
        onPress={blockAllGroupAdditions}
      >
        <Ionicons name="shield" size={20} color="#fff" />
        <Text style={styles.blockButtonText}>Bloquear Todas as Adições</Text>
      </TouchableOpacity>

      {privacyOption === 'selected' && (
        <View style={styles.contactsContainer}>
          <Text style={styles.contactsTitle}>Selecione quem pode adicioná-lo:</Text>
          <FlatList
            data={contacts}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View style={styles.contactItem}>
                <View style={styles.contactInfo}>
                  <View style={styles.avatar}>
                    <Text style={styles.avatarText}>{item.name.charAt(0)}</Text>
                  </View>
                  <Text style={styles.contactName}>{item.name}</Text>
                </View>
                <Switch
                  value={selectedContacts.includes(item.id)}
                  onValueChange={() => toggleContactSelection(item.id)}
                  trackColor={{ false: '#d0d0d0', true: '#a0c8ff' }}
                  thumbColor={selectedContacts.includes(item.id) ? '#4285f4' : '#f4f3f4'}
                />
              </View>
            )}
          />
        </View>
      )}

      <TouchableOpacity 
        style={styles.saveButton}
        onPress={savePrivacySettings}
        disabled={loading}
      >
        <Text style={styles.saveButtonText}>
          {loading ? 'Salvando...' : 'Salvar Configurações'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#666',
  },
  optionsContainer: {
    marginBottom: 16,
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    overflow: 'hidden',
  },
  option: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  selectedOption: {
    backgroundColor: '#f0f8ff',
  },
  optionText: {
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  optionDescription: {
    fontSize: 14,
    color: '#888',
    flex: 2,
    marginTop: 4,
  },
  blockButton: {
    backgroundColor: '#e74c3c',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 24,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  blockButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  contactsContainer: {
    flex: 1,
    marginBottom: 16,
  },
  contactsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  contactItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  contactInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#555',
  },
  contactName: {
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: '#4285f4',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GroupAdditionControlScreen;