/**
 * ReportSyncService.js
 * 
 * Serviço para gerenciar sincronização de reportes offline.
 * Implementa sistema de fila para reportes criados offline, sincronização
 * automática quando a conexão for restaurada, e resolução de conflitos
 * em caso de reportes duplicados.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

// Constantes para status de sincronização
const SYNC_STATUS = {
  PENDING: 'pending',         // Aguardando sincronização
  IN_PROGRESS: 'in_progress', // Sincronização em andamento
  COMPLETED: 'completed',     // Sincronização concluída com sucesso
  FAILED: 'failed',           // Sincronização falhou
  CONFLICT: 'conflict'        // Conflito detectado durante sincronização
};

// Constantes para tipos de armazenamento
const STORAGE_TYPES = {
  LOCAL_STORAGE: 'localStorage',
  ASYNC_STORAGE: 'asyncStorage',
  INDEXED_DB: 'indexedDB',
  SQLITE: 'sqlite'
};

// Constantes para eventos de sincronização
const SYNC_EVENTS = {
  STARTED: 'sync_started',
  COMPLETED: 'sync_completed',
  FAILED: 'sync_failed',
  PROGRESS: 'sync_progress',
  CONFLICT: 'sync_conflict',
  ITEM_SYNCED: 'item_synced',
  QUEUE_UPDATED: 'queue_updated',
  CONNECTION_CHANGE: 'connection_change'
};

/**
 * Serviço para gerenciar sincronização de reportes offline.
 * Permite armazenar reportes localmente quando não há conexão
 * e sincronizar automaticamente quando a conexão for restaurada.
 */
class ReportSyncService {
  /**
   * Inicializa o serviço de sincronização
   * @param {Object} options - Opções de configuração
   * @param {string} options.apiEndpoint - URL base da API de reportes
   * @param {string} options.storageType - Tipo de armazenamento local a ser utilizado
   * @param {number} options.maxRetries - Número máximo de tentativas de sincronização
   * @param {number} options.syncInterval - Intervalo entre tentativas de sincronização (ms)
   * @param {boolean} options.autoSync - Ativa/desativa sincronização automática
   * @param {Function} options.onConflict - Função para resolver conflitos (opcional)
   */
  constructor(options = {}) {
    // Configurações padrão
    this.config = {
      apiEndpoint: options.apiEndpoint || '/api/reports',
      storageType: options.storageType || this.detectStorageType(),
      maxRetries: options.maxRetries || 3,
      syncInterval: options.syncInterval || 60000, // 1 minuto
      autoSync: options.autoSync !== undefined ? options.autoSync : true,
      conflictResolution: options.onConflict || this.defaultConflictResolution
    };

    // Fila de sincronização
    this.syncQueue = [];
    
    // Status de conexão
    this.isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    
    // Fila de eventos
    this.eventListeners = {};
    
    // Timer de sincronização automática
    this.syncTimer = null;
    
    // Bloqueio para evitar sincronizações simultâneas
    this.syncInProgress = false;
    
    // Inicializa o serviço
    this.initialize();
  }
  
  /**
   * Inicializa o serviço de sincronização
   * @private
   */
  async initialize() {
    try {
      // Inicializa o armazenamento local
      await this.initializeStorage();
      
      // Carrega a fila de sincronização
      await this.loadSyncQueue();
      
      // Configura listeners de conexão
      this.setupConnectionListeners();
      
      // Inicia sincronização automática se configurado
      if (this.config.autoSync) {
        this.startAutoSync();
      }
      
      console.log('[ReportSyncService] Serviço inicializado com sucesso');
    } catch (error) {
      console.error('[ReportSyncService] Erro ao inicializar serviço:', error);
    }
  }
  
  /**
   * Detecta o tipo de armazenamento disponível
   * @private
   * @returns {string} Tipo de armazenamento
   */
  detectStorageType() {
    // Verifica se estamos em ambiente React Native
    const isReactNative = typeof navigator !== 'undefined' && navigator.product === 'ReactNative';
    
    if (isReactNative) {
      return STORAGE_TYPES.ASYNC_STORAGE;
    } else if (typeof window !== 'undefined') {
      // Ambiente navegador
      if (window.indexedDB) {
        return STORAGE_TYPES.INDEXED_DB;
      } else if (window.localStorage) {
        return STORAGE_TYPES.LOCAL_STORAGE;
      }
    }
    
    // Fallback para localStorage
    return STORAGE_TYPES.LOCAL_STORAGE;
  }
  
  /**
   * Inicializa o armazenamento local de acordo com o tipo configurado
   * @private
   */
  async initializeStorage() {
    switch (this.config.storageType) {
      case STORAGE_TYPES.LOCAL_STORAGE:
        // Não precisa de inicialização especial
        break;
        
      case STORAGE_TYPES.ASYNC_STORAGE:
        try {
          // Em ambiente React Native, importa AsyncStorage dinamicamente
          const { AsyncStorage } = await import('@react-native-async-storage/async-storage');
          this.storage = AsyncStorage;
        } catch (error) {
          console.error('[ReportSyncService] Erro ao inicializar AsyncStorage:', error);
          // Fallback para um objeto simulando AsyncStorage
          this.storage = {
            getItem: (key) => {
              try { return Promise.resolve(localStorage.getItem(key)); } 
              catch (e) { return Promise.resolve(null); }
            },
            setItem: (key, value) => {
              try { return Promise.resolve(localStorage.setItem(key, value)); } 
              catch (e) { return Promise.resolve(); }
            },
            removeItem: (key) => {
              try { return Promise.resolve(localStorage.removeItem(key)); } 
              catch (e) { return Promise.resolve(); }
            }
          };
        }
        break;
        
      case STORAGE_TYPES.INDEXED_DB:
        // Inicializa IndexedDB
        await this.initializeIndexedDB();
        break;
        
      case STORAGE_TYPES.SQLITE:
        // Inicializa SQLite (só em ambientes específicos)
        await this.initializeSQLite();
        break;
        
      default:
        throw new Error(`[ReportSyncService] Tipo de armazenamento não suportado: ${this.config.storageType}`);
    }
  }
  
  /**
   * Inicializa banco de dados IndexedDB
   * @private
   */
  initializeIndexedDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error('IndexedDB não é suportado neste navegador'));
        return;
      }
      
      const request = window.indexedDB.open('ReportsSyncDB', 1);
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // Cria object store para fila de sincronização
        if (!db.objectStoreNames.contains('syncQueue')) {
          const store = db.createObjectStore('syncQueue', { keyPath: 'localId' });
          store.createIndex('status', 'status', { unique: false });
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
      
      request.onsuccess = (event) => {
        this.db = event.target.result;
        resolve();
      };
      
      request.onerror = (event) => {
        reject(new Error(`Erro ao abrir IndexedDB: ${event.target.error}`));
      };
    });
  }
  
  /**
   * Inicializa banco de dados SQLite (apenas para React Native)
   * @private
   */
  async initializeSQLite() {
    try {
      // Esta é uma implementação simplificada
      // Em uma aplicação real, importaríamos o SQLite específico para a plataforma
      console.warn('[ReportSyncService] Implementação SQLite simplificada, em produção deve ser substituída');
      
      // Simulação de uma API SQLite
      this.sqlite = {
        transaction: async (callback) => {
          const tx = {
            executeSql: async (query, params, successCallback) => {
              try {
                // Simula executar SQL usando localStorage
                if (query.includes('CREATE TABLE')) {
                  // Nada a fazer na simulação
                } else if (query.includes('SELECT')) {
                  const data = localStorage.getItem('syncQueue');
                  const parsedData = data ? JSON.parse(data) : [];
                  successCallback(tx, { rows: { length: parsedData.length, _array: parsedData } });
                } else if (query.includes('INSERT')) {
                  const data = localStorage.getItem('syncQueue');
                  const parsedData = data ? JSON.parse(data) : [];
                  parsedData.push(params[0]);
                  localStorage.setItem('syncQueue', JSON.stringify(parsedData));
                  successCallback(tx, { rowsAffected: 1, insertId: Date.now() });
                } else if (query.includes('UPDATE')) {
                  // Simulação simplificada
                  successCallback(tx, { rowsAffected: 1 });
                } else if (query.includes('DELETE')) {
                  // Simulação simplificada
                  successCallback(tx, { rowsAffected: 1 });
                }
              } catch (error) {
                console.error('SQLite simulation error:', error);
              }
            }
          };
          await callback(tx);
          return Promise.resolve();
        }
      };
      
      // Cria tabela para fila de sincronização
      await this.sqlite.transaction(async (tx) => {
        await tx.executeSql(
          `CREATE TABLE IF NOT EXISTS syncQueue (
            localId TEXT PRIMARY KEY,
            reportData TEXT,
            status TEXT,
            retryCount INTEGER,
            timestamp INTEGER,
            serverResponse TEXT
          )`,
          [],
          () => console.log('[ReportSyncService] Tabela syncQueue criada/verificada'),
          (_, error) => console.error('[ReportSyncService] Erro ao criar tabela:', error)
        );
      });
    } catch (error) {
      console.error('[ReportSyncService] Erro ao inicializar SQLite:', error);
      throw error;
    }
  }
  
  /**
   * Configura listeners para monitorar conexão de rede
   * @private
   */
  setupConnectionListeners() {
    if (typeof window !== 'undefined') {
      // Monitora mudanças na conexão
      window.addEventListener('online', this.handleConnectionChange.bind(this));
      window.addEventListener('offline', this.handleConnectionChange.bind(this));
      
      // Monitora visibilidade do documento (para tentar sincronizar quando retornar)
      document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    } else if (typeof navigator !== 'undefined' && navigator.product === 'ReactNative') {
      // Em React Native, usaríamos NetInfo
      this.setupReactNativeNetInfo();
    }
  }
  
  /**
   * Configura monitoramento de conexão para React Native
   * @private
   */
  async setupReactNativeNetInfo() {
    try {
      // Em uma aplicação real, importaríamos NetInfo
      // Exemplo simplificado:
      // const NetInfo = await import('@react-native-community/netinfo');
      // const unsubscribe = NetInfo.addEventListener(state => {
      //   this.isOnline = state.isConnected && state.isInternetReachable;
      //   this.handleConnectionChange();
      // });
      // this.netInfoUnsubscribe = unsubscribe;
      
      console.log('[ReportSyncService] Monitoramento de rede para React Native configurado');
    } catch (error) {
      console.error('[ReportSyncService] Erro ao configurar NetInfo:', error);
    }
  }
  
  /**
   * Manipula mudanças na conexão de rede
   * @private
   */
  handleConnectionChange() {
    const previousState = this.isOnline;
    this.isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    
    if (previousState !== this.isOnline) {
      console.log(`[ReportSyncService] Estado da conexão alterado: ${this.isOnline ? 'online' : 'offline'}`);
      
      // Dispara evento de mudança de conexão
      this.emitEvent(SYNC_EVENTS.CONNECTION_CHANGE, { isOnline: this.isOnline });
      
      // Se ficou online, tenta sincronizar
      if (this.isOnline && this.config.autoSync && this.syncQueue.length > 0) {
        this.syncReports();
      }
    }
  }
  
  /**
   * Manipula mudanças na visibilidade do documento
   * @private
   */
  handleVisibilityChange() {
    if (document.visibilityState === 'visible' && this.isOnline && this.config.autoSync && this.syncQueue.length > 0) {
      console.log('[ReportSyncService] Documento visível, tentando sincronizar...');
      this.syncReports();
    }
  }
  
  /**
   * Carrega a fila de sincronização do armazenamento local
   * @private
   */
  async loadSyncQueue() {
    try {
      switch (this.config.storageType) {
        case STORAGE_TYPES.LOCAL_STORAGE:
          const queueData = localStorage.getItem('reportSyncQueue');
          this.syncQueue = queueData ? JSON.parse(queueData) : [];
          break;
          
        case STORAGE_TYPES.ASYNC_STORAGE:
          const asyncData = await this.storage.getItem('reportSyncQueue');
          this.syncQueue = asyncData ? JSON.parse(asyncData) : [];
          break;
          
        case STORAGE_TYPES.INDEXED_DB:
          await this.loadQueueFromIndexedDB();
          break;
          
        case STORAGE_TYPES.SQLITE:
          await this.loadQueueFromSQLite();
          break;
      }
      
      console.log(`[ReportSyncService] Fila de sincronização carregada: ${this.syncQueue.length} reportes pendentes`);
      this.emitEvent(SYNC_EVENTS.QUEUE_UPDATED, { queue: this.syncQueue });
    } catch (error) {
      console.error('[ReportSyncService] Erro ao carregar fila de sincronização:', error);
      this.syncQueue = [];
    }
  }
  
  /**
   * Carrega a fila de sincronização do IndexedDB
   * @private
   */
  loadQueueFromIndexedDB() {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error('IndexedDB não foi inicializado'));
        return;
      }
      
      const transaction = this.db.transaction(['syncQueue'], 'readonly');
      const store = transaction.objectStore('syncQueue');
      const request = store.getAll();
      
      request.onsuccess = (event) => {
        this.syncQueue = event.target.result || [];
        resolve();
      };
      
      request.onerror = (event) => {
        reject(new Error(`Erro ao carregar dados do IndexedDB: ${event.target.error}`));
      };
    });
  }
  
  /**
   * Carrega a fila de sincronização do SQLite
   * @private
   */
  async loadQueueFromSQLite() {
    return new Promise((resolve, reject) => {
      if (!this.sqlite) {
        reject(new Error('SQLite não foi inicializado'));
        return;
      }
      
      this.sqlite.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM syncQueue',
          [],
          (_, result) => {
            const rows = result.rows;
            this.syncQueue = [];
            
            for (let i = 0; i < rows.length; i++) {
              const row = rows.item(i);
              this.syncQueue.push({
                ...row,
                reportData: JSON.parse(row.reportData),
                serverResponse: row.serverResponse ? JSON.parse(row.serverResponse) : null
              });
            }
            
            resolve();
          },
          (_, error) => {
            reject(new Error(`Erro ao consultar SQLite: ${error.message}`));
            return false;
          }
        );
      });
    });
  }
  
  /**
   * Salva a fila de sincronização no armazenamento local
   * @private
   */
  async saveSyncQueue() {
    try {
      switch (this.config.storageType) {
        case STORAGE_TYPES.LOCAL_STORAGE:
          localStorage.setItem('reportSyncQueue', JSON.stringify(this.syncQueue));
          break;
          
        case STORAGE_TYPES.ASYNC_STORAGE:
          await this.storage.setItem('reportSyncQueue', JSON.stringify(this.syncQueue));
          break;
          
        case STORAGE_TYPES.INDEXED_DB:
          await this.saveQueueToIndexedDB();
          break;
          
        case STORAGE_TYPES.SQLITE:
          await this.saveQueueToSQLite();
          break;
      }
      
      // Notifica sobre a atualização da fila
      this.emitEvent(SYNC_EVENTS.QUEUE_UPDATED, { queue: this.syncQueue });
    } catch (error) {
      console.error('[ReportSyncService] Erro ao salvar fila de sincronização:', error);
    }
  }
  
  /**
   * Salva a fila de sincronização no IndexedDB
   * @private
   */
  saveQueueToIndexedDB() {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error('IndexedDB não foi inicializado'));
        return;
      }
      
      const transaction = this.db.transaction(['syncQueue'], 'readwrite');
      const store = transaction.objectStore('syncQueue');
      
      // Limpa store
      const clearRequest = store.clear();
      
      clearRequest.onsuccess = () => {
        // Adiciona itens atualizados
        let complete = 0;
        
        if (this.syncQueue.length === 0) {
          resolve();
          return;
        }
        
        this.syncQueue.forEach(item => {
          const request = store.add(item);
          
          request.onsuccess = () => {
            complete++;
            if (complete === this.syncQueue.length) {
              resolve();
            }
          };
          
          request.onerror = (event) => {
            console.error(`Erro ao adicionar item ao IndexedDB: ${event.target.error}`);
            complete++;
            if (complete === this.syncQueue.length) {
              resolve();
            }
          };
        });
      };
      
      clearRequest.onerror = (event) => {
        reject(new Error(`Erro ao limpar IndexedDB: ${event.target.error}`));
      };
    });
  }
  
  /**
   * Salva a fila de sincronização no SQLite
   * @private
   */
  async saveQueueToSQLite() {
    return new Promise((resolve, reject) => {
      if (!this.sqlite) {
        reject(new Error('SQLite não foi inicializado'));
        return;
      }
      
      this.sqlite.transaction(async (tx) => {
        // Limpa a tabela
        await tx.executeSql(
          'DELETE FROM syncQueue',
          [],
          () => {},
          (_, error) => {
            console.error('[ReportSyncService] Erro ao limpar tabela SQLite:', error);
            return false;
          }
        );
        
        // Adiciona itens atuais
        const promises = this.syncQueue.map(item => {
          return new Promise((resolveItem) => {
            tx.executeSql(
              `INSERT INTO syncQueue 
              (localId, reportData, status, retryCount, timestamp, serverResponse) 
              VALUES (?, ?, ?, ?, ?, ?)`,
              [
                item.localId,
                JSON.stringify(item.reportData),
                item.status,
                item.retryCount || 0,
                item.timestamp,
                item.serverResponse ? JSON.stringify(item.serverResponse) : null
              ],
              () => resolveItem(),
              (_, error) => {
                console.error('[ReportSyncService] Erro ao inserir no SQLite:', error);
                resolveItem();
                return false;
              }
            );
          });
        });
        
        await Promise.all(promises);
        resolve();
      });
    });
  }
  
  /**
   * Inicia o timer para sincronização automática
   * @private
   */
  startAutoSync() {
    // Limpa timer existente
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
    }
    
    // Configura novo timer
    this.syncTimer = setInterval(() => {
      if (this.isOnline && this.syncQueue.length > 0 && !this.syncInProgress) {
        this.syncReports();
      }
    }, this.config.syncInterval);
    
    console.log(`[ReportSyncService] Sincronização automática configurada: ${this.config.syncInterval}ms`);
  }
  
  /**
   * Para o timer de sincronização automática
   */
  stopAutoSync() {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
      console.log('[ReportSyncService] Sincronização automática desativada');
    }
  }
  
  /**
   * Adiciona um reporte à fila de sincronização
   * @param {Object} reportData - Dados do reporte
   * @returns {string} ID local do reporte adicionado
   */
  async addReport(reportData) {
    if (!reportData) {
      throw new Error('[ReportSyncService] Dados de reporte inválidos');
    }
    
    // Gera ID local único para o reporte
    const localId = `report_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    
    // Cria item para a fila de sincronização
    const queueItem = {
      localId,
      reportData,
      status: SYNC_STATUS.PENDING,
      timestamp: Date.now(),
      retryCount: 0
    };
    
    // Adiciona à fila
    this.syncQueue.push(queueItem);
    
    // Salva a fila atualizada
    await this.saveSyncQueue();
    
    console.log(`[ReportSyncService] Reporte adicionado à fila: ${localId}`);
    
    // Tenta sincronizar imediatamente se estiver online e autoSync estiver ativado
    if (this.isOnline && this.config.autoSync) {
      this.syncReports();
    }
    
    return localId;
  }
  
  /**
   * Remove um reporte da fila de sincronização
   * @param {string} localId - ID local do reporte
   * @returns {boolean} True se removido com sucesso
   */
  async removeReport(localId) {
    const initialLength = this.syncQueue.length;
    
    // Remove da fila
    this.syncQueue = this.syncQueue.filter(item => item.localId !== localId);
    
    // Verifica se o reporte foi encontrado
    if (this.syncQueue.length === initialLength) {
      console.warn(`[ReportSyncService] Reporte não encontrado: ${localId}`);
      return false;
    }
    
    // Salva a fila atualizada
    await this.saveSyncQueue();
    
    console.log(`[ReportSyncService] Reporte removido da fila: ${localId}`);
    return true;
  }
  
  /**
   * Obtém o status de um reporte específico
   * @param {string} localId - ID local do reporte
   * @returns {Object|null} Status do reporte ou null se não encontrado
   */
  getReportStatus(localId) {
    const report = this.syncQueue.find(item => item.localId === localId);
    
    if (!report) {
      return null;
    }
    
    return {
      localId: report.localId,
      status: report.status,
      timestamp: report.timestamp,
      retryCount: report.retryCount,
      serverResponse: report.serverResponse,
    };
  }
  
  /**
   * Obtém todos os reportes na fila de sincronização
   * @param {string} status - Filtro opcional por status
   * @returns {Array} Lista de reportes
   */
  getQueuedReports(status = null) {
    if (status) {
      return this.syncQueue.filter(item => item.status === status);
    }
    
    return [...this.syncQueue];
  }
  
  /**
   * Inicia processo de sincronização de reportes pendentes
   * @returns {Promise<Object>} Resultado da sincronização
   */
  async syncReports() {
    // Verifica se já há uma sincronização em andamento
    if (this.syncInProgress) {
      console.log('[ReportSyncService] Sincronização já em andamento, aguardando...');
      return { success: false, reason: 'in_progress' };
    }
    
    // Verifica se há reportes para sincronizar
    if (this.syncQueue.length === 0) {
      return { success: true, syncedCount: 0, reason: 'no_reports' };
    }
    
    // Verifica se está online
    if (!this.isOnline) {
      console.log('[ReportSyncService] Dispositivo offline, sincronização adiada');
      return { success: false, reason: 'offline' };
    }
    
    try {
      // Marca sincronização como em progresso
      this.syncInProgress = true;
      
      // Notifica início da sincronização
      this.emitEvent(SYNC_EVENTS.STARTED, { count: this.syncQueue.length });
      
      // Filtra apenas reportes pendentes
      const pendingReports = this.syncQueue.filter(
        item => item.status === SYNC_STATUS.PENDING || item.status === SYNC_STATUS.FAILED
      );
      
      console.log(`[ReportSyncService] Iniciando sincronização: ${pendingReports.length} reportes pendentes`);
      
      // Resultados da sincronização
      const results = {
        total: pendingReports.length,
        success: 0,
        failed: 0,
        conflicts: 0
      };
      
      // Sincroniza reportes um a um
      for (let i = 0; i < pendingReports.length; i++) {
        const report = pendingReports[i];
        
        // Notifica progresso
        this.emitEvent(SYNC_EVENTS.PROGRESS, {
          current: i + 1,
          total: pendingReports.length,
          report: report.localId
        });
        
        try {
          // Atualiza status do reporte
          this.updateReportStatus(report.localId, SYNC_STATUS.IN_PROGRESS);
          
          // Envia reporte para o servidor
          const result = await this.sendReportToServer(report);
          
          // Processa resultado
          if (result.success) {
            // Sincronizado com sucesso
            this.updateReportStatus(report.localId, SYNC_STATUS.COMPLETED, result.data);
            results.success++;
            
            // Notifica item sincronizado
            this.emitEvent(SYNC_EVENTS.ITEM_SYNCED, {
              localId: report.localId,
              serverId: result.data?.id,
              success: true
            });
          } else if (result.conflict) {
            // Conflito detectado
            this.updateReportStatus(report.localId, SYNC_STATUS.CONFLICT, result.data);
            results.conflicts++;
            
            // Notifica conflito
            this.emitEvent(SYNC_EVENTS.CONFLICT, {
              localId: report.localId,
              serverData: result.data,
              localData: report.reportData
            });
            
            // Tenta resolver conflito
            await this.handleConflict(report, result.data);
          } else {
            // Falha na sincronização
            report.retryCount = (report.retryCount || 0) + 1;
            
            if (report.retryCount >= this.config.maxRetries) {
              console.error(`[ReportSyncService] Número máximo de tentativas atingido para ${report.localId}`);
            }
            
            this.updateReportStatus(report.localId, SYNC_STATUS.FAILED, result.error);
            results.failed++;
            
            // Notifica falha do item
            this.emitEvent(SYNC_EVENTS.ITEM_SYNCED, {
              localId: report.localId,
              success: false,
              error: result.error
            });
          }
        } catch (error) {
          console.error(`[ReportSyncService] Erro ao sincronizar reporte ${report.localId}:`, error);
          
          // Atualiza contador de tentativas
          report.retryCount = (report.retryCount || 0) + 1;
          this.updateReportStatus(report.localId, SYNC_STATUS.FAILED, { message: error.message });
          results.failed++;
          
          // Notifica falha do item
          this.emitEvent(SYNC_EVENTS.ITEM_SYNCED, {
            localId: report.localId,
            success: false,
            error: error.message
          });
        }
        
        // Pequena pausa para não sobrecarregar a API
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      // Salva a fila atualizada
      await this.saveSyncQueue();
      
      // Notifica conclusão da sincronização
      this.emitEvent(SYNC_EVENTS.COMPLETED, results);
      
      console.log(`[ReportSyncService] Sincronização concluída: ${results.success} sucesso, ${results.failed} falhas, ${results.conflicts} conflitos`);
      
      // Limpa reportes sincronizados com sucesso após algum tempo
      if (results.success > 0) {
        setTimeout(() => this.cleanupSyncedReports(), 60000); // 1 minuto
      }
      
      return {
        success: true,
        syncedCount: results.success,
        failedCount: results.failed,
        conflictCount: results.conflicts
      };
    } catch (error) {
      console.error('[ReportSyncService] Erro durante sincronização:', error);
      
      // Notifica falha na sincronização
      this.emitEvent(SYNC_EVENTS.FAILED, { error: error.message });
      
      return { success: false, reason: 'error', error: error.message };
    } finally {
      // Marca sincronização como concluída
      this.syncInProgress = false;
    }
  }
  
  /**
   * Atualiza o status de um reporte na fila
   * @private
   * @param {string} localId - ID local do reporte
   * @param {string} status - Novo status
   * @param {Object} data - Dados adicionais (resposta do servidor ou erro)
   */
  updateReportStatus(localId, status, data = null) {
    const reportIndex = this.syncQueue.findIndex(item => item.localId === localId);
    
    if (reportIndex === -1) {
      console.warn(`[ReportSyncService] Reporte não encontrado para atualização: ${localId}`);
      return;
    }
    
    // Atualiza status e adiciona resposta do servidor ou erro
    this.syncQueue[reportIndex].status = status;
    this.syncQueue[reportIndex].serverResponse = data;
    this.syncQueue[reportIndex].lastUpdated = Date.now();
    
    // Não salva imediatamente para melhorar performance durante sincronização em massa
    // O salvamento é feito após processar todos os reportes
  }
  
  /**
   * Envia um reporte para o servidor
   * @private
   * @param {Object} report - Item da fila de sincronização
   * @returns {Promise<Object>} Resultado da requisição
   */
  async sendReportToServer(report) {
    try {
      // Em uma implementação real, usaríamos fetch ou uma biblioteca de HTTP
      // Este é um exemplo simplificado usando fetch
      
      // Prepara URL da API
      const apiUrl = `${this.config.apiEndpoint}`;
      
      // Adiciona data de sincronização
      const reportData = {
        ...report.reportData,
        syncTimestamp: Date.now(),
        syncDevice: this.getDeviceInfo(),
        localId: report.localId
      };
      
      // Configura a requisição
      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Aqui adicionaríamos headers de autenticação se necessário
        },
        body: JSON.stringify(reportData)
      };
      
      console.log(`[ReportSyncService] Enviando reporte para servidor: ${report.localId}`);
      
      // Simula verificação de duplicidade antes de enviar
      const isDuplicate = await this.checkForDuplicateOnServer(reportData);
      
      if (isDuplicate) {
        console.warn(`[ReportSyncService] Reporte possivelmente duplicado: ${report.localId}`);
        return {
          success: false,
          conflict: true,
          data: isDuplicate
        };
      }
      
      // Verifica se devemos simular um erro para testes
      if (reportData._simulateError) {
        throw new Error('Erro simulado para testes');
      }
      
      // Faz a requisição
      // Em um ambiente real:
      // const response = await fetch(apiUrl, requestOptions);
      
      // Simula uma resposta bem-sucedida para testes
      // Em uma implementação real, verificaríamos o status e parseríamos o JSON
      const simulatedResponse = {
        id: `server_${Math.random().toString(36).substring(2, 9)}`,
        timestamp: Date.now(),
        status: 'processed',
        message: 'Reporte processado com sucesso'
      };
      
      return {
        success: true,
        data: simulatedResponse
      };
    } catch (error) {
      console.error(`[ReportSyncService] Erro ao enviar reporte ${report.localId}:`, error);
      
      return {
        success: false,
        error: {
          message: error.message,
          code: error.code || 'unknown_error'
        }
      };
    }
  }
  
  /**
   * Verifica se existe um reporte duplicado no servidor
   * @private
   * @param {Object} reportData - Dados do reporte
   * @returns {Promise<Object|null>} Dados do reporte duplicado ou null se não houver
   */
  async checkForDuplicateOnServer(reportData) {
    // Em uma implementação real, faríamos uma consulta ao servidor
    // Aqui estamos apenas simulando para demonstração
    
    // Simula 5% de chance de encontrar um duplicado para testes
    const shouldSimulateDuplicate = Math.random() < 0.05;
    
    if (shouldSimulateDuplicate) {
      return {
        id: `server_duplicate_${Math.random().toString(36).substring(2, 9)}`,
        timestamp: Date.now() - 60000, // 1 minuto atrás
        location: reportData.location,
        type: reportData.type,
        // Outros dados que seriam retornados pelo servidor
      };
    }
    
    return null;
  }
  
  /**
   * Função padrão para resolução de conflitos
   * @private
   * @param {Object} localReport - Reporte local
   * @param {Object} serverReport - Reporte no servidor
   * @returns {Promise<boolean>} True se o conflito foi resolvido
   */
  async defaultConflictResolution(localReport, serverReport) {
    // Estratégia simples: manter a versão do servidor
    console.log(`[ReportSyncService] Resolvendo conflito usando estratégia padrão para ${localReport.localId}`);
    
    // Atualiza status como resolvido
    this.updateReportStatus(localReport.localId, SYNC_STATUS.COMPLETED, serverReport);
    
    // Salva a fila
    await this.saveSyncQueue();
    
    return true;
  }
  
  /**
   * Manipula conflitos entre reportes locais e do servidor
   * @private
   * @param {Object} report - Item da fila de sincronização
   * @param {Object} serverData - Dados do servidor
   */
  async handleConflict(report, serverData) {
    try {
      // Usa estratégia de resolução de conflitos configurada
      const resolved = await this.config.conflictResolution(report, serverData);
      
      if (resolved) {
        console.log(`[ReportSyncService] Conflito resolvido para ${report.localId}`);
      } else {
        console.warn(`[ReportSyncService] Conflito não resolvido para ${report.localId}`);
      }
    } catch (error) {
      console.error(`[ReportSyncService] Erro ao resolver conflito para ${report.localId}:`, error);
    }
  }
  
  /**
   * Remove reportes já sincronizados da fila
   * @returns {number} Número de reportes removidos
   */
  async cleanupSyncedReports() {
    const initialCount = this.syncQueue.length;
    
    // Filtra apenas reportes não concluídos
    this.syncQueue = this.syncQueue.filter(item => item.status !== SYNC_STATUS.COMPLETED);
    
    const removedCount = initialCount - this.syncQueue.length;
    
    if (removedCount > 0) {
      console.log(`[ReportSyncService] Cleanup: ${removedCount} reportes removidos da fila`);
      await this.saveSyncQueue();
    }
    
    return removedCount;
  }
  
  /**
   * Limpa toda a fila de sincronização
   * @param {boolean} includeInProgress - Se true, limpa inclusive reportes em processo de sincronização
   * @returns {number} Número de reportes removidos
   */
  async clearSyncQueue(includeInProgress = false) {
    const initialCount = this.syncQueue.length;
    
    if (includeInProgress) {
      // Limpa toda a fila
      this.syncQueue = [];
    } else {
      // Preserva reportes em sincronização
      this.syncQueue = this.syncQueue.filter(item => item.status === SYNC_STATUS.IN_PROGRESS);
    }
    
    const removedCount = initialCount - this.syncQueue.length;
    
    console.log(`[ReportSyncService] Fila limpa: ${removedCount} reportes removidos`);
    
    // Salva a fila atualizada
    await this.saveSyncQueue();
    
    return removedCount;
  }
  
  /**
   * Reinicia sincronização de reportes com falha
   * @returns {number} Número de reportes reiniciados
   */
  async retrySyncFailures() {
    let count = 0;
    
    // Redefine status de falha para pendente
    this.syncQueue.forEach(item => {
      if (item.status === SYNC_STATUS.FAILED) {
        item.status = SYNC_STATUS.PENDING;
        item.retryCount = 0; // Reseta contador de tentativas
        count++;
      }
    });
    
    if (count > 0) {
      console.log(`[ReportSyncService] ${count} reportes agendados para nova tentativa`);
      
      // Salva a fila atualizada
      await this.saveSyncQueue();
      
      // Inicia sincronização se estiver online
      if (this.isOnline && this.config.autoSync) {
        this.syncReports();
      }
    }
    
    return count;
  }
  
  /**
   * Obtém informações básicas sobre o dispositivo
   * @private
   * @returns {Object} Informações do dispositivo
   */
  getDeviceInfo() {
    const info = {
      type: 'unknown',
      platform: 'unknown',
      timestamp: Date.now()
    };
    
    if (typeof navigator !== 'undefined') {
      if (navigator.product === 'ReactNative') {
        info.type = 'mobile';
        info.platform = 'react-native';
      } else {
        info.type = /Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : 'desktop';
        info.platform = 'browser';
        info.userAgent = navigator.userAgent;
      }
    } else if (typeof process !== 'undefined') {
      info.type = 'server';
      info.platform = 'node';
    }
    
    return info;
  }
  
  /**
   * Registra um evento de sincronização
   * @param {string} eventType - Tipo de evento
   * @param {Function} callback - Função a ser chamada quando o evento ocorrer
   * @returns {Function} Função para remover o listener
   */
  addEventListener(eventType, callback) {
    if (!this.eventListeners[eventType]) {
      this.eventListeners[eventType] = [];
    }
    
    this.eventListeners[eventType].push(callback);
    
    // Retorna função para remover o listener
    return () => {
      this.removeEventListener(eventType, callback);
    };
  }
  
  /**
   * Remove um listener de evento
   * @param {string} eventType - Tipo de evento
   * @param {Function} callback - Função a ser removida
   */
  removeEventListener(eventType, callback) {
    if (!this.eventListeners[eventType]) {
      return;
    }
    
    this.eventListeners[eventType] = this.eventListeners[eventType].filter(
      listener => listener !== callback
    );
  }
  
  /**
   * Emite um evento para todos os listeners registrados
   * @private
   * @param {string} eventType - Tipo de evento
   * @param {Object} data - Dados do evento
   */
  emitEvent(eventType, data) {
    if (!this.eventListeners[eventType]) {
      return;
    }
    
    const event = {
      type: eventType,
      timestamp: Date.now(),
      data
    };
    
    this.eventListeners[eventType].forEach(callback => {
      try {
        callback(event);
      } catch (error) {
        console.error(`[ReportSyncService] Erro ao processar evento ${eventType}:`, error);
      }
    });
  }
  
  /**
   * Exibe estatísticas da fila de sincronização
   * @returns {Object} Estatísticas da fila
   */
  getQueueStats() {
    const stats = {
      total: this.syncQueue.length,
      pending: 0,
      inProgress: 0,
      completed: 0,
      failed: 0,
      conflict: 0,
      isOnline: this.isOnline,
      autoSyncEnabled: !!this.syncTimer,
      lastSync: null
    };
    
    // Conta reportes por status
    this.syncQueue.forEach(item => {
      stats[item.status]++;
      
      // Encontra data da última sincronização
      if (item.status === SYNC_STATUS.COMPLETED && (!stats.lastSync || item.lastUpdated > stats.lastSync)) {
        stats.lastSync = item.lastUpdated;
      }
    });
    
    return stats;
  }
}

// Exporta constantes úteis junto com a classe
export { SYNC_STATUS, SYNC_EVENTS, STORAGE_TYPES };

export default ReportSyncService;