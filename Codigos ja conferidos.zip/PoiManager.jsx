import React, { useState, useEffect, useContext, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { AlertContext } from './Alert';
import { Map, TileLayer, Marker, Popup, FeatureGroup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { PrimaryButton, SecondaryButton, IconButton } from './commonButtons';

// Tipos de POIs suportados
const POI_TYPES = {
  FUEL_STATION: 'fuelStation',
  REST_AREA: 'restArea',
  RESTAURANT: 'restaurant',
  HOTEL: 'hotel',
  REPAIR_SHOP: 'repairShop',
  PARKING: 'parking',
  WEIGHING_STATION: 'weighingStation',
  DANGEROUS_AREA: 'dangerousArea',
  SCENIC_VIEW: 'scenicView',
  TRUCK_WASH: 'truckWash',
  POLICE: 'police'
};

// Modos de transporte para filtrar POIs
const TRANSPORT_MODES = {
  TRUCK: 'truck',
  CAR: 'car',
  MOTORCYCLE: 'motorcycle',
  ALL: 'all'
};

// Ícones personalizados para cada tipo de POI
const poiIcons = {
  [POI_TYPES.FUEL_STATION]: new L.Icon({
    iconUrl: '/assets/icons/fuel-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.REST_AREA]: new L.Icon({
    iconUrl: '/assets/icons/rest-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.RESTAURANT]: new L.Icon({
    iconUrl: '/assets/icons/food-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.HOTEL]: new L.Icon({
    iconUrl: '/assets/icons/hotel-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.REPAIR_SHOP]: new L.Icon({
    iconUrl: '/assets/icons/repair-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.PARKING]: new L.Icon({
    iconUrl: '/assets/icons/parking-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.WEIGHING_STATION]: new L.Icon({
    iconUrl: '/assets/icons/weighing-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.DANGEROUS_AREA]: new L.Icon({
    iconUrl: '/assets/icons/danger-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.SCENIC_VIEW]: new L.Icon({
    iconUrl: '/assets/icons/scenic-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.TRUCK_WASH]: new L.Icon({
    iconUrl: '/assets/icons/wash-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  [POI_TYPES.POLICE]: new L.Icon({
    iconUrl: '/assets/icons/police-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  }),
  default: new L.Icon({
    iconUrl: '/assets/icons/default-marker.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  })
};

/**
 * Componente principal para gerenciamento de Pontos de Interesse (POIs)
 */
const PoiManager = ({
  userType = 'MotoristaComum',
  transportMode = TRANSPORT_MODES.TRUCK,
  initialLocation = { lat: -23.5505, lng: -46.6333 }, // São Paulo
  offlineMode = false
}) => {
  const { t } = useTranslation();
  const { showAlert } = useContext(AlertContext);
  const mapRef = useRef(null);
  
  // Estados para o gerenciador de POIs
  const [pois, setPois] = useState([]);
  const [filteredPois, setFilteredPois] = useState([]);
  const [selectedPoi, setSelectedPoi] = useState(null);
  const [mapCenter, setMapCenter] = useState(initialLocation);
  const [mapZoom, setMapZoom] = useState(12);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingPoi, setIsAddingPoi] = useState(false);
  const [newPoiLocation, setNewPoiLocation] = useState(null);
  const [newPoiForm, setNewPoiForm] = useState({
    name: '',
    description: '',
    type: POI_TYPES.FUEL_STATION,
    services: [],
    transportModes: [TRANSPORT_MODES.TRUCK],
    images: [],
    ratings: [],
    isVerified: false,
    isCommunityGenerated: true
  });
  const [filters, setFilters] = useState({
    types: Object.values(POI_TYPES),
    onlyVerified: false,
    showCommunityGenerated: true,
    minRating: 0,
    services: [],
    maxDistance: null
  });
  const [userLocation, setUserLocation] = useState(null);
  const [isLoadingPois, setIsLoadingPois] = useState(true);
  const [bounds, setBounds] = useState(null);
  const [pendingReviews, setPendingReviews] = useState([]);
// Carregar POIs iniciais
  useEffect(() => {
    const loadPois = async () => {
      setIsLoadingPois(true);
      
      try {
        // Em modo offline, carregar POIs do armazenamento local
        if (offlineMode) {
          const offlinePois = loadOfflinePois();
          setPois(offlinePois);
          applyFilters(offlinePois);
        } else {
          // Buscar POIs da API
          const response = await fetch('/api/pois');
          
          if (!response.ok) {
            throw new Error(t('poi.errorLoading'));
          }
          
          const data = await response.json();
          setPois(data.pois);
          applyFilters(data.pois);
          
          // Salvar para uso offline
          saveOfflinePois(data.pois);
        }
      } catch (error) {
        console.error('Erro ao carregar POIs:', error);
        showAlert({
          type: 'error',
          message: t('poi.errorLoading'),
          duration: 5000
        });
        
        // Fallback para POIs offline
        const offlinePois = loadOfflinePois();
        setPois(offlinePois);
        applyFilters(offlinePois);
      } finally {
        setIsLoadingPois(false);
      }
    };
    
    loadPois();
  }, [t, showAlert, offlineMode]);
  
  // Buscar a localização do usuário
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ lat: latitude, lng: longitude });
          
          // Centralizar o mapa na posição do usuário
          setMapCenter({ lat: latitude, lng: longitude });
        },
        error => {
          console.error('Erro ao obter localização:', error);
        }
      );
    }
  }, []);
  
  // Carregar POIs específicos do usuário VIP
  useEffect(() => {
    const loadVipPois = async () => {
      if (userType === 'MotoristaVIP' && !offlineMode) {
        try {
          const response = await fetch('/api/pois/vip');
          
          if (!response.ok) {
            throw new Error(t('poi.errorLoadingVip'));
          }
          
          const data = await response.json();
          
          // Mesclar POIs VIP com os regulares
          setPois(prev => {
            const combined = [...prev, ...data.vipPois];
            // Remover duplicados por ID
            const uniquePois = combined.filter((poi, index, self) => 
              index === self.findIndex(p => p.id === poi.id)
            );
            return uniquePois;
          });
        } catch (error) {
          console.error('Erro ao carregar POIs VIP:', error);
        }
      }
    };
    
    loadVipPois();
  }, [userType, t, offlineMode]);
  
  // Carregar reviews pendentes para administradores
  useEffect(() => {
    const loadPendingReviews = async () => {
      if (userType === 'Administrador' && !offlineMode) {
        try {
          const response = await fetch('/api/pois/pending-reviews');
          
          if (!response.ok) {
            throw new Error(t('poi.errorLoadingReviews'));
          }
          
          const data = await response.json();
          setPendingReviews(data.pendingReviews);
        } catch (error) {
          console.error('Erro ao carregar reviews pendentes:', error);
        }
      }
    };
    
    loadPendingReviews();
  }, [userType, t, offlineMode]);
  
  // Aplicar filtros aos POIs
  const applyFilters = useCallback((poisToFilter = pois) => {
    if (poisToFilter.length === 0) return;
    
    let filtered = [...poisToFilter];
    
    // Filtrar por tipo
    if (filters.types.length > 0) {
      filtered = filtered.filter(poi => filters.types.includes(poi.type));
    }
    
    // Filtrar por verificação
    if (filters.onlyVerified) {
      filtered = filtered.filter(poi => poi.isVerified);
    }
    
    // Filtrar POIs gerados pela comunidade
    if (!filters.showCommunityGenerated) {
      filtered = filtered.filter(poi => !poi.isCommunityGenerated);
    }
    
    // Filtrar por avaliação mínima
    if (filters.minRating > 0) {
      filtered = filtered.filter(poi => {
        const avgRating = poi.ratings.length > 0 
          ? poi.ratings.reduce((sum, rating) => sum + rating.value, 0) / poi.ratings.length 
          : 0;
        return avgRating >= filters.minRating;
      });
    }
    
    // Filtrar por serviços
    if (filters.services.length > 0) {
      filtered = filtered.filter(poi => {
        return filters.services.every(service => poi.services.includes(service));
      });
    }
    
    // Filtrar por modo de transporte
    filtered = filtered.filter(poi => 
      poi.transportModes.includes(transportMode) || 
      poi.transportModes.includes(TRANSPORT_MODES.ALL)
    );
    
    // Filtrar por distância máxima (se definida e a localização do usuário estiver disponível)
    if (filters.maxDistance && userLocation) {
      filtered = filtered.filter(poi => {
        const distance = calculateDistance(
          userLocation.lat, 
          userLocation.lng, 
          poi.location.lat, 
          poi.location.lng
        );
        return distance <= filters.maxDistance;
      });
    }
    
    // Filtrar por termo de pesquisa
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      filtered = filtered.filter(poi => 
        poi.name.toLowerCase().includes(term) || 
        poi.description.toLowerCase().includes(term) ||
        poi.services.some(service => service.toLowerCase().includes(term))
      );
    }
    
    // Limitar por bounds do mapa se disponível
    if (bounds) {
      filtered = filtered.filter(poi => 
        poi.location.lat >= bounds.south &&
        poi.location.lat <= bounds.north &&
        poi.location.lng >= bounds.west &&
        poi.location.lng <= bounds.east
      );
    }
    
    setFilteredPois(filtered);
  }, [filters, pois, transportMode, searchTerm, userLocation, bounds]);
  
  // Aplicar filtros quando eles ou os POIs mudarem
  useEffect(() => {
    applyFilters();
  }, [filters, pois, applyFilters]);
  
  // Atualizar os bounds do mapa quando ele for movido ou ampliado
  const handleMapChange = () => {
    if (mapRef.current) {
      const map = mapRef.current.leafletElement;
      const mapBounds = map.getBounds();
      
      setBounds({
        north: mapBounds.getNorth(),
        south: mapBounds.getSouth(),
        east: mapBounds.getEast(),
        west: mapBounds.getWest()
      });
      
      setMapZoom(map.getZoom());
    }
  };
  
  // Calcular distância entre dois pontos (fórmula de Haversine)
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distância em km
    return distance;
  };
  
  // Carregar POIs do armazenamento local
  const loadOfflinePois = () => {
    try {
      const offlinePoisJson = localStorage.getItem('kingroad_offline_pois');
      return offlinePoisJson ? JSON.parse(offlinePoisJson) : [];
    } catch (error) {
      console.error('Erro ao carregar POIs offline:', error);
      return [];
    }
  };
  
  // Salvar POIs no armazenamento local
  const saveOfflinePois = (poisData) => {
    try {
      localStorage.setItem('kingroad_offline_pois', JSON.stringify(poisData));
    } catch (error) {
      console.error('Erro ao salvar POIs offline:', error);
    }
  };
  
  // Iniciar adição de um novo POI
  const startAddPoi = () => {
    setIsAddingPoi(true);
    setNewPoiLocation(mapCenter);
    
    showAlert({
      type: 'info',
      message: t('poi.clickMapToPlace'),
      duration: 5000
    });
  };
  
  // Cancelar adição de POI
  const cancelAddPoi = () => {
    setIsAddingPoi(false);
    setNewPoiLocation(null);
    setNewPoiForm({
      name: '',
      description: '',
      type: POI_TYPES.FUEL_STATION,
      services: [],
      transportModes: [TRANSPORT_MODES.TRUCK],
      images: [],
      ratings: [],
      isVerified: false,
      isCommunityGenerated: true
    });
  };
  
  // Atualizar localização do novo POI
  const handleMapClick = (e) => {
    if (isAddingPoi) {
      setNewPoiLocation({
        lat: e.latlng.lat,
        lng: e.latlng.lng
      });
    }
  };
// Enviar novo POI
  const submitNewPoi = async () => {
    // Validar entradas
    if (!newPoiForm.name.trim()) {
      showAlert({
        type: 'warning',
        message: t('poi.nameRequired'),
        duration: 3000
      });
      return;
    }
    
    if (!newPoiLocation) {
      showAlert({
        type: 'warning',
        message: t('poi.locationRequired'),
        duration: 3000
      });
      return;
    }
    
    const newPoi = {
      id: `temp-${Date.now()}`,
      name: newPoiForm.name,
      description: newPoiForm.description,
      type: newPoiForm.type,
      location: newPoiLocation,
      services: newPoiForm.services,
      transportModes: newPoiForm.transportModes,
      images: newPoiForm.images,
      ratings: [],
      createdBy: userType,
      createdAt: new Date().toISOString(),
      isVerified: userType === 'Administrador', // Verificado automaticamente se for admin
      isCommunityGenerated: userType !== 'Administrador',
      reviewStatus: userType === 'Administrador' ? 'approved' : 'pending'
    };
    
    try {
      if (offlineMode) {
        // Em modo offline, salvar localmente
        const offlinePois = loadOfflinePois();
        const updatedPois = [...offlinePois, newPoi];
        saveOfflinePois(updatedPois);
        
        // Atualizar estado
        setPois(prevPois => [...prevPois, newPoi]);
        
        showAlert({
          type: 'success',
          message: t('poi.addedOffline'),
          duration: 3000
        });
      } else {
        // Enviar para a API
        const response = await fetch('/api/pois', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(newPoi)
        });
        
        if (!response.ok) {
          throw new Error(t('poi.errorAdding'));
        }
        
        const data = await response.json();
        
        // Atualizar estado com o POI retornado (que terá ID real)
        setPois(prevPois => [...prevPois, data.poi]);
        
        showAlert({
          type: 'success',
          message: userType === 'Administrador' 
            ? t('poi.addedSuccess') 
            : t('poi.addedPendingReview'),
          duration: 3000
        });
      }
      
      // Resetar formulário e estado
      cancelAddPoi();
    } catch (error) {
      console.error('Erro ao adicionar POI:', error);
      
      showAlert({
        type: 'error',
        message: t('poi.errorAdding'),
        duration: 5000
      });
    }
  };
  
  // Avaliar um POI
  const ratePoi = async (poiId, rating, comment = '') => {
    if (rating < 1 || rating > 5) {
      showAlert({
        type: 'warning',
        message: t('poi.invalidRating'),
        duration: 3000
      });
      return;
    }
    
    const newRating = {
      userId: 'current-user', // Em produção, usar ID real do usuário
      value: rating,
      comment,
      date: new Date().toISOString()
    };
    
    try {
      if (offlineMode) {
        // Em modo offline, atualizar localmente
        const updatedPois = pois.map(poi => {
          if (poi.id === poiId) {
            return {
              ...poi,
              ratings: [...poi.ratings, newRating]
            };
          }
          return poi;
        });
        
        setPois(updatedPois);
        saveOfflinePois(updatedPois);
        
        showAlert({
          type: 'success',
          message: t('poi.ratingAddedOffline'),
          duration: 3000
        });
      } else {
        // Enviar para a API
        const response = await fetch(`/api/pois/${poiId}/rate`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(newRating)
        });
        
        if (!response.ok) {
          throw new Error(t('poi.errorRating'));
        }
        
        const data = await response.json();
        
        // Atualizar POIs com a avaliação
        setPois(prevPois => prevPois.map(poi => 
          poi.id === poiId ? data.poi : poi
        ));
        
        showAlert({
          type: 'success',
          message: t('poi.ratingAdded'),
          duration: 3000
        });
      }
      
      // Se este for o POI selecionado, atualizar também
      if (selectedPoi && selectedPoi.id === poiId) {
        setSelectedPoi(pois.find(p => p.id === poiId));
      }
    } catch (error) {
      console.error('Erro ao avaliar POI:', error);
      
      showAlert({
        type: 'error',
        message: t('poi.errorRating'),
        duration: 5000
      });
    }
  };
  
  // Aprovar um POI (apenas admin)
  const approvePoi = async (poiId) => {
    if (userType !== 'Administrador') return;
    
    try {
      const response = await fetch(`/api/pois/${poiId}/approve`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(t('poi.errorApproving'));
      }
      
      // Atualizar POIs
      setPois(prevPois => prevPois.map(poi => 
        poi.id === poiId ? { ...poi, isVerified: true, reviewStatus: 'approved' } : poi
      ));
      
      // Remover dos reviews pendentes
      setPendingReviews(prev => prev.filter(review => review.poiId !== poiId));
      
      showAlert({
        type: 'success',
        message: t('poi.approvedSuccess'),
        duration: 3000
      });
    } catch (error) {
      console.error('Erro ao aprovar POI:', error);
      
      showAlert({
        type: 'error',
        message: t('poi.errorApproving'),
        duration: 5000
      });
    }
  };
  
  // Rejeitar um POI (apenas admin)
  const rejectPoi = async (poiId) => {
    if (userType !== 'Administrador') return;
    
    try {
      const response = await fetch(`/api/pois/${poiId}/reject`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(t('poi.errorRejecting'));
      }
      
      // Remover o POI rejeitado
      setPois(prevPois => prevPois.filter(poi => poi.id !== poiId));
      
      // Remover dos reviews pendentes
      setPendingReviews(prev => prev.filter(review => review.poiId !== poiId));
      
      showAlert({
        type: 'success',
        message: t('poi.rejectedSuccess'),
        duration: 3000
      });
    } catch (error) {
      console.error('Erro ao rejeitar POI:', error);
      
      showAlert({
        type: 'error',
        message: t('poi.errorRejecting'),
        duration: 5000
      });
    }
  };
  
  // Calcular avaliação média
  const getAverageRating = (ratings) => {
    if (!ratings || ratings.length === 0) return 0;
    return ratings.reduce((sum, rating) => sum + rating.value, 0) / ratings.length;
  };
  
  // Formatar avaliação para exibição (com estrelas)
  const formatRatingStars = (rating) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    
    let stars = '★'.repeat(fullStars);
    if (hasHalfStar) stars += '½';
    stars += '☆'.repeat(5 - fullStars - (hasHalfStar ? 1 : 0));
    
    return stars;
  };
  
  // Renderizar detalhes do POI selecionado
  const renderPoiDetails = () => {
    if (!selectedPoi) return null;
    
    const avgRating = getAverageRating(selectedPoi.ratings);
    
    return (
      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden max-w-md w-full">
        <div className="relative">
          {selectedPoi.images && selectedPoi.images.length > 0 ? (
            <img 
              src={selectedPoi.images[0]} 
              alt={selectedPoi.name}
              className="w-full h-48 object-cover"
            />
          ) : (
            <div className="w-full h-48 bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
              <span className="text-gray-500 dark:text-gray-400">
                {t('poi.noImage')}
              </span>
            </div>
          )}
          
          <div className="absolute top-2 right-2 flex space-x-1">
            {selectedPoi.isVerified && (
              <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full flex items-center dark:bg-green-800 dark:text-green-100">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                {t('poi.verified')}
              </div>
            )}
            {selectedPoi.isCommunityGenerated && (
              <div className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full dark:bg-blue-800 dark:text-blue-100">
                {t('poi.community')}
              </div>
            )}
          </div>
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">{selectedPoi.name}</h2>
            <div className="flex items-center">
              <span className="text-yellow-500 mr-1">{formatRatingStars(avgRating)}</span>
              <span className="text-sm text-gray-600 dark:text-gray-300">
                {avgRating.toFixed(1)} ({selectedPoi.ratings.length})
              </span>
            </div>
          </div>
          
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">
            {t(`poiTypes.${selectedPoi.type}`)}
          </div>
          
          <p className="text-gray-700 dark:text-gray-300 mb-4">
            {selectedPoi.description || t('poi.noDescription')}
          </p>
          
          {selectedPoi.services && selectedPoi.services.length > 0 && (
            <div className="mb-4">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-2">
                {t('poi.services')}
              </h3>
              <div className="flex flex-wrap gap-1">
                {selectedPoi.services.map((service, index) => (
                  <span 
                    key={index} 
                    className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded dark:bg-gray-700 dark:text-gray-300"
                  >
                    {service}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {userLocation && (
            <div className="mb-4">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-1">
                {t('poi.distance')}
              </h3>
              <p className="text-gray-700 dark:text-gray-300">
                {calculateDistance(
                  userLocation.lat, 
                  userLocation.lng, 
                  selectedPoi.location.lat, 
                  selectedPoi.location.lng
                ).toFixed(1)} km
              </p>
            </div>
          )}
          
          <div className="mb-4">
            <h3 className="font-semibold text-gray-800 dark:text-white mb-2">
              {t('poi.ratings')}
            </h3>
            
            {selectedPoi.ratings.length > 0 ? (
              <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                {selectedPoi.ratings.slice(0, 5).map((rating, index) => (
                  <div key={index} className="border-b border-gray-100 dark:border-gray-700 pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-100 text-xs font-bold rounded-full w-8 h-8 flex items-center justify-center mr-2">
                          {rating.userId.slice(0, 2).toUpperCase()}
                        </div>
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {rating.userId}
                        </span>
                      </div>
                      <div className="text-yellow-500">
                        {formatRatingStars(rating.value)}
                      </div>
                    </div>
                    {rating.comment && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {rating.comment}
                      </p>
                    )}
                    <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                      {new Date(rating.date).toLocaleDateString()}
                    </p>
                  </div>
                ))}
                
                {selectedPoi.ratings.length > 5 && (
                  <p className="text-sm text-blue-600 dark:text-blue-400">
                    {t('poi.moreRatings', { count: selectedPoi.ratings.length - 5 })}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('poi.noRatings')}
              </p>
            )}
          </div>
          
          {/* Adicionar avaliação */}
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-800 dark:text-white mb-2">
              {t('poi.addRating')}
            </h3>
            <RatingForm poiId={selectedPoi.id} onSubmit={ratePoi} />
          </div>
          
          {/* Botões de ação */}
          <div className="flex space-x-2 mt-4">
            <PrimaryButton
              onClick={() => {
                // Abrir navegação para este POI
                // Aqui poderia integrar com o NavigationModule
                showAlert({
                  type: 'info',
                  message: t('poi.navigatingTo', { name: selectedPoi.name }),
                  duration: 3000
                });
              }}
              icon="navigation"
            >
              {t('poi.navigate')}
            </PrimaryButton>
            
            <SecondaryButton
              onClick={() => setSelectedPoi(null)}
              icon="x"
            >
              {t('poi.close')}
            </SecondaryButton>
          </div>
          
          {/* Opções de admin */}
          {userType === 'Administrador' && !selectedPoi.isVerified && (
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-800 dark:text-white mb-2">
                {t('poi.adminActions')}
              </h3>
              <div className="flex space-x-2">
                <PrimaryButton
                  onClick={() => approvePoi(selectedPoi.id)}
                  icon="check"
                >
                  {t('poi.approve')}
                </PrimaryButton>
                
                <SecondaryButton
                  onClick={() => rejectPoi(selectedPoi.id)}
                  icon="trash"
                >
                  {t('poi.reject')}
                </SecondaryButton>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };
  
  // Componente de formulário para adicionar avaliação
  const RatingForm = ({ poiId, onSubmit }) => {
    const [rating, setRating] = useState(5);
    const [comment, setComment] = useState('');
    
    const handleSubmit = (e) => {
      e.preventDefault();
      onSubmit(poiId, rating, comment);
      setRating(5);
      setComment('');
    };
    
    return (
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {t('poi.yourRating')}
          </label>
          <div className="flex items-center space-x-1">
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setRating(value)}
                className={`text-2xl focus:outline-none ${
                  value <= rating ? 'text-yellow-500' : 'text-gray-300 dark:text-gray-600'
                }`}
              >
                ★
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {t('poi.yourComment')}
          </label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            rows="3"
            placeholder={t('poi.commentPlaceholder')}
          ></textarea>
        </div>
        
        <PrimaryButton type="submit" fullWidth>
          {t('poi.submitRating')}
        </PrimaryButton>
      </form>
    );
  };
// Componente de filtros
  const FiltersPanel = () => {
    const [localFilters, setLocalFilters] = useState({...filters});
    
    const applyLocalFilters = () => {
      setFilters(localFilters);
    };
    
    const resetFilters = () => {
      const defaultFilters = {
        types: Object.values(POI_TYPES),
        onlyVerified: false,
        showCommunityGenerated: true,
        minRating: 0,
        services: [],
        maxDistance: null
      };
      
      setLocalFilters(defaultFilters);
      setFilters(defaultFilters);
    };
    
    const togglePoiType = (type) => {
      if (localFilters.types.includes(type)) {
        setLocalFilters({
          ...localFilters,
          types: localFilters.types.filter(t => t !== type)
        });
      } else {
        setLocalFilters({
          ...localFilters,
          types: [...localFilters.types, type]
        });
      }
    };
    
    const toggleService = (service) => {
      if (localFilters.services.includes(service)) {
        setLocalFilters({
          ...localFilters,
          services: localFilters.services.filter(s => s !== service)
        });
      } else {
        setLocalFilters({
          ...localFilters,
          services: [...localFilters.services, service]
        });
      }
    };
    
    // Lista de serviços disponíveis
    const availableServices = [
      'wifi', 'shower', 'restaurant', 'parking', '24h', 
      'fuel_diesel', 'fuel_gasoline', 'fuel_electric', 'repair', 'market'
    ];
    
    return (
      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 max-w-xs w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-gray-800 dark:text-white">
            {t('poi.filters')}
          </h3>
          <button
            onClick={resetFilters}
            className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
          >
            {t('poi.resetFilters')}
          </button>
        </div>
        
        {/* Tipos de POI */}
        <div className="mb-4">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('poi.poiTypes')}
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {Object.values(POI_TYPES).map((type) => (
              <label key={type} className="flex items-center text-sm">
                <input
                  type="checkbox"
                  checked={localFilters.types.includes(type)}
                  onChange={() => togglePoiType(type)}
                  className="mr-2 h-4 w-4 text-blue-600 rounded"
                />
                {t(`poiTypes.${type}`)}
              </label>
            ))}
          </div>
        </div>
        
        {/* Verificação e Comunidade */}
        <div className="mb-4">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('poi.poiSources')}
          </h4>
          <div className="space-y-2">
            <label className="flex items-center text-sm">
              <input
                type="checkbox"
                checked={localFilters.onlyVerified}
                onChange={() => setLocalFilters({...localFilters, onlyVerified: !localFilters.onlyVerified})}
                className="mr-2 h-4 w-4 text-blue-600 rounded"
              />
              {t('poi.onlyVerified')}
            </label>
            <label className="flex items-center text-sm">
              <input
                type="checkbox"
                checked={localFilters.showCommunityGenerated}
                onChange={() => setLocalFilters({...localFilters, showCommunityGenerated: !localFilters.showCommunityGenerated})}
                className="mr-2 h-4 w-4 text-blue-600 rounded"
              />
              {t('poi.showCommunity')}
            </label>
          </div>
        </div>
        
        {/* Classificação mínima */}
        <div className="mb-4">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('poi.minRating')}
          </h4>
          <div className="flex items-center space-x-1">
            {[0, 1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setLocalFilters({...localFilters, minRating: value})}
                className={`text-xl focus:outline-none ${
                  value === 0 && localFilters.minRating === 0 
                    ? 'text-gray-700 dark:text-gray-300 font-medium' 
                    : value <= localFilters.minRating && value > 0
                      ? 'text-yellow-500' 
                      : 'text-gray-300 dark:text-gray-600'
                }`}
              >
                {value === 0 ? t('poi.any') : '★'}
              </button>
            ))}
          </div>
        </div>
        
        {/* Serviços disponíveis */}
        <div className="mb-4">
          <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('poi.services')}
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {availableServices.map((service) => (
              <label key={service} className="flex items-center text-sm">
                <input
                  type="checkbox"
                  checked={localFilters.services.includes(service)}
                  onChange={() => toggleService(service)}
                  className="mr-2 h-4 w-4 text-blue-600 rounded"
                />
                {t(`poiServices.${service}`)}
              </label>
            ))}
          </div>
        </div>
        
        {/* Distância máxima */}
        {userLocation && (
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('poi.maxDistance')} (km)
            </h4>
            <div className="flex items-center space-x-2">
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={localFilters.maxDistance || 0}
                onChange={(e) => setLocalFilters({
                  ...localFilters, 
                  maxDistance: parseInt(e.target.value) || null
                })}
                className="w-full"
              />
              <span className="text-sm text-gray-700 dark:text-gray-300 w-10 text-right">
                {localFilters.maxDistance || t('poi.any')}
              </span>
            </div>
          </div>
        )}
        
        <PrimaryButton
          onClick={applyLocalFilters}
          fullWidth
        >
          {t('poi.applyFilters')}
        </PrimaryButton>
      </div>
    );
  };
  
  // Componente para a barra de pesquisa
  const SearchBar = () => (
    <div className="mb-4 relative">
      <div className="relative">
        <input 
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={t('poi.searchPlaceholder')}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
          >
            <svg className="h-5 w-5 text-gray-400 hover:text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
      
      <div className="absolute right-2 bottom-2 text-xs text-gray-500 dark:text-gray-400">
        {t('poi.resultsCount', { count: filteredPois.length })}
      </div>
    </div>
  );
  
  // Componente para o formulário de novo POI
  const NewPoiForm = () => {
    // Lista de serviços disponíveis
    const availableServices = [
      'wifi', 'shower', 'restaurant', 'parking', '24h', 
      'fuel_diesel', 'fuel_gasoline', 'fuel_electric', 'repair', 'market'
    ];
    
    const toggleService = (service) => {
      if (newPoiForm.services.includes(service)) {
        setNewPoiForm({
          ...newPoiForm,
          services: newPoiForm.services.filter(s => s !== service)
        });
      } else {
        setNewPoiForm({
          ...newPoiForm,
          services: [...newPoiForm.services, service]
        });
      }
    };
    
    const toggleTransportMode = (mode) => {
      if (newPoiForm.transportModes.includes(mode)) {
        setNewPoiForm({
          ...newPoiForm,
          transportModes: newPoiForm.transportModes.filter(m => m !== mode)
        });
      } else {
        setNewPoiForm({
          ...newPoiForm,
          transportModes: [...newPoiForm.transportModes, mode]
        });
      }
    };
    
    return (
      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 max-w-md w-full">
        <h3 className="font-bold text-gray-800 dark:text-white mb-4">
          {t('poi.addNewPoi')}
        </h3>
        
        <form className="space-y-4">
          {/* Nome e tipo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.name')} *
            </label>
            <input
              type="text"
              value={newPoiForm.name}
              onChange={(e) => setNewPoiForm({...newPoiForm, name: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder={t('poi.namePlaceholder')}
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.type')} *
            </label>
            <select
              value={newPoiForm.type}
              onChange={(e) => setNewPoiForm({...newPoiForm, type: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              required
            >
              {Object.values(POI_TYPES).map((type) => (
                <option key={type} value={type}>
                  {t(`poiTypes.${type}`)}
                </option>
              ))}
            </select>
          </div>
          
          {/* Descrição */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.description')}
            </label>
            <textarea
              value={newPoiForm.description}
              onChange={(e) => setNewPoiForm({...newPoiForm, description: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              rows="3"
              placeholder={t('poi.descriptionPlaceholder')}
            ></textarea>
          </div>
          
          {/* Serviços */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.services')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {availableServices.map((service) => (
                <label key={service} className="flex items-center text-sm">
                  <input
                    type="checkbox"
                    checked={newPoiForm.services.includes(service)}
                    onChange={() => toggleService(service)}
                    className="mr-2 h-4 w-4 text-blue-600 rounded"
                  />
                  {t(`poiServices.${service}`)}
                </label>
              ))}
            </div>
          </div>
          
          {/* Modos de transporte */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.transportModes')} *
            </label>
            <div className="flex space-x-3">
              {Object.values(TRANSPORT_MODES).map((mode) => (
                <label key={mode} className="flex items-center text-sm">
                  <input
                    type="checkbox"
                    checked={newPoiForm.transportModes.includes(mode)}
                    onChange={() => toggleTransportMode(mode)}
                    className="mr-1 h-4 w-4 text-blue-600 rounded"
                  />
                  {t(`transportModes.${mode}`)}
                </label>
              ))}
            </div>
          </div>
          
          {/* Localização */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t('poi.location')} *
            </label>
            {newPoiLocation ? (
              <div className="text-sm text-gray-700 dark:text-gray-300">
                Lat: {newPoiLocation.lat.toFixed(6)}, Lng: {newPoiLocation.lng.toFixed(6)}
                <p className="text-xs text-gray-500 mt-1">
                  {t('poi.clickMapToChangeLocation')}
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('poi.noLocationSelected')}
              </p>
            )}
          </div>
        </form>
        
        <div className="flex space-x-2 mt-6">
          <PrimaryButton
            onClick={submitNewPoi}
            disabled={!newPoiForm.name || !newPoiLocation || newPoiForm.transportModes.length === 0}
          >
            {t('poi.submitPoi')}
          </PrimaryButton>
          
          <SecondaryButton
            onClick={cancelAddPoi}
          >
            {t('poi.cancel')}
          </SecondaryButton>
        </div>
      </div>
    );
  };
  
  // Componente para reviews pendentes
  const PendingReviewsList = () => {
    if (userType !== 'Administrador') return null;
    
    return (
      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 max-w-md w-full">
        <h3 className="font-bold text-gray-800 dark:text-white mb-4">
          {t('poi.pendingReviews')} ({pendingReviews.length})
        </h3>
        
        {pendingReviews.length === 0 ? (
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {t('poi.noPendingReviews')}
          </p>
        ) : (
          <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
            {pendingReviews.map((review) => {
              const poi = pois.find(p => p.id === review.poiId);
              if (!poi) return null;
              
              return (
                <div key={review.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">
                        {poi.name}
                      </h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {t(`poiTypes.${poi.type}`)} • {t('poi.addedBy')} {review.createdBy}
                      </p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                        {poi.description || t('poi.noDescription')}
                      </p>
                    </div>
                    <div className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full dark:bg-yellow-900 dark:text-yellow-200">
                      {t('poi.pending')}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 mt-3">
                    <PrimaryButton
                      onClick={() => approvePoi(poi.id)}
                      icon="check"
                      size="sm"
                    >
                      {t('poi.approve')}
                    </PrimaryButton>
                    
                    <SecondaryButton
                      onClick={() => rejectPoi(poi.id)}
                      icon="trash"
                      size="sm"
                    >
                      {t('poi.reject')}
                    </SecondaryButton>
                    
                    <IconButton
                      icon="eye"
                      onClick={() => {
                        setSelectedPoi(poi);
                        setMapCenter(poi.location);
                      }}
                      tooltip={t('poi.view')}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="flex h-full">
      {/* Painel lateral */}
      <div className="w-96 h-full bg-gray-50 dark:bg-gray-900 p-4 overflow-y-auto flex flex-col">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
          {t('poi.managerTitle')}
        </h2>
        
        <SearchBar />
        
        {/* Lista de POIs */}
        <div className="flex-grow overflow-y-auto mb-4">
          {isLoadingPois ? (
            <div className="flex items-center justify-center h-60">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : filteredPois.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm 
                  ? t('poi.noSearchResults') 
                  : t('poi.noPoisFound')}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredPois.map((poi) => {
                const avgRating = getAverageRating(poi.ratings);
                
                return (
                  <div 
                    key={poi.id} 
                    className={`bg-white dark:bg-gray-800 p-3 rounded-lg shadow-sm hover:shadow-md cursor-pointer transition-shadow ${
                      selectedPoi && selectedPoi.id === poi.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => {
                      setSelectedPoi(poi);
                      setMapCenter(poi.location);
                    }}
                  >
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-medium text-gray-800 dark:text-white">
                          {poi.name}
                        </h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {t(`poiTypes.${poi.type}`)}
                          {userLocation && (
                            <span className="ml-2">
                              • {calculateDistance(
                                userLocation.lat, 
                                userLocation.lng, 
                                poi.location.lat, 
                                poi.location.lng
                              ).toFixed(1)} km
                            </span>
                          )}
                        </p>
                      </div>
                      
                      <div className="flex items-center">
                        <span className="text-yellow-500 mr-1">{formatRatingStars(avgRating)}</span>
                        <span className="text-xs text-gray-600 dark:text-gray-300">
                          {poi.ratings.length > 0 ? `(${poi.ratings.length})` : ''}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-1 flex flex-wrap gap-1">
                      {poi.isVerified && (
                        <span className="bg-green-100 text-green-800 text-xxs px-1.5 py-0.5 rounded-full flex items-center dark:bg-green-900 dark:text-green-100">
                          <svg className="w-2 h-2 mr-0.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          {t('poi.verified')}
                        </span>
                      )}
                      
                      {poi.isCommunityGenerated && (
                        <span className="bg-blue-100 text-blue-800 text-xxs px-1.5 py-0.5 rounded-full dark:bg-blue-900 dark:text-blue-100">
                          {t('poi.community')}
                        </span>
                      )}
                      
                      {poi.reviewStatus === 'pending' && (
                        <span className="bg-yellow-100 text-yellow-800 text-xxs px-1.5 py-0.5 rounded-full dark:bg-yellow-900 dark:text-yellow-100">
                          {t('poi.pending')}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        {/* Botões de ação */}
        <div className="flex space-x-2">
          <PrimaryButton
            onClick={startAddPoi}
            icon="plus"
            disabled={isAddingPoi}
          >
            {t('poi.addNew')}
          </PrimaryButton>
          
          <SecondaryButton
            onClick={() => {
              // Centralizar mapa na posição do usuário
              if (userLocation) {
                setMapCenter(userLocation);
              } else {
                showAlert({
                  type: 'warning',
                  message: t('poi.noUserLocation'),
                  duration: 3000
                });
              }
            }}
            icon="location"
          >
            {t('poi.centerMap')}
          </SecondaryButton>
        </div>
      </div>
      
      {/* Mapa principal */}
      <div className="flex-grow relative">
        <Map 
          ref={mapRef}
          center={[mapCenter.lat, mapCenter.lng]} 
          zoom={mapZoom} 
          className="h-full"
          onclick={handleMapClick}
          onmoveend={handleMapChange}
          onzoomend={handleMapChange}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          />
          
          {/* Marcador da posição do usuário */}
          {userLocation && (
            <Marker 
              position={[userLocation.lat, userLocation.lng]}
              icon={new L.Icon({
                iconUrl: '/assets/icons/user-marker.png',
                iconSize: [32, 32],
                iconAnchor: [16, 32],
                popupAnchor: [0, -32]
              })}
            >
              <Popup>
                <div>
                  <h3 className="font-bold">{t('poi.yourLocation')}</h3>
                </div>
              </Popup>
            </Marker>
          )}
          
          {/* Marcadores de POIs */}
          <FeatureGroup>
            {filteredPois.map((poi) => (
              <Marker
                key={poi.id}
                position={[poi.location.lat, poi.location.lng]}
                icon={poiIcons[poi.type] || poiIcons.default}
                eventHandlers={{
                  click: () => {
                    setSelectedPoi(poi);
                  }
                }}
              >
                <Popup>
                  <div>
                    <h3 className="font-bold">{poi.name}</h3>
                    <p className="text-sm">{t(`poiTypes.${poi.type}`)}</p>
                    {poi.description && <p className="mt-1">{poi.description}</p>}
                    <button
                      onClick={() => setSelectedPoi(poi)}
                      className="mt-2 text-blue-600 text-sm hover:underline"
                    >
                      {t('poi.viewDetails')}
                    </button>
                  </div>
                </Popup>
              </Marker>
            ))}
          </FeatureGroup>
          
          {/* Marcador para novo POI */}
          {isAddingPoi && newPoiLocation && (
            <Marker
              position={[newPoiLocation.lat, newPoiLocation.lng]}
              icon={new L.Icon({
                iconUrl: '/assets/icons/new-marker.png',
                iconSize: [32, 32],
                iconAnchor: [16, 32],
                popupAnchor: [0, -32]
              })}
              draggable={true}
              eventHandlers={{
                dragend: (e) => {
                  const marker = e.target;
                  const position = marker.getLatLng();
                  setNewPoiLocation({
                    lat: position.lat,
                    lng: position.lng
                  });
                }
              }}
            >
              <Popup>
                <div>
                  <h3 className="font-bold">{t('poi.newLocation')}</h3>
                  <p>{t('poi.dragToAdjust')}</p>
                </div>
              </Popup>
            </Marker>
          )}
        </Map>
        
        {/* Overlay para detalhes do POI */}
        {selectedPoi && (
          <div className="absolute top-4 right-4 z-1000">
            {renderPoiDetails()}
          </div>
        )}
        
        {/* Overlay para adicionar novo POI */}
        {isAddingPoi && (
          <div className="absolute top-4 right-4 z-1000">
            <NewPoiForm />
          </div>
        )}
        
        {/* Overlay para filtros */}
        <div className="absolute top-4 left-4 z-1000">
          <FiltersPanel />
        </div>
        
        {/* Overlay para reviews pendentes (somente admin) */}
        {userType === 'Administrador' && pendingReviews.length > 0 && (
          <div className="absolute bottom-4 right-4 z-1000">
            <PendingReviewsList />
          </div>
        )}
      </div>
    </div>
  );
};

export default PoiManager;