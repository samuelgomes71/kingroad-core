// Exemplo de como usar o sistema de idiomas em um componente React

import React, { useState, useEffect } from 'react';
import KingRoadLanguage from './king-road-language-system';

const NavigationView = () => {
  // Estado local para forçar re-renderização quando o idioma mudar
  const [languageCode, setLanguageCode] = useState(KingRoadLanguage.currentLanguage);
  
  // Simula um ouvinte para mudanças de idioma (implementação completa dependeria do sistema de eventos)
  useEffect(() => {
    // Função que seria chamada quando o idioma mudasse
    const handleLanguageChange = (newLang) => {
      setLanguageCode(newLang);
    };
    
    // Na implementação real, você adicionaria um listener ao sistema de idiomas
    
    // Este é apenas um timer para simular a mudança de idioma para demonstração
    const demoTimer = setTimeout(() => {
      KingRoadLanguage.setLanguage('pt-BR');
      handleLanguageChange('pt-BR');
    }, 5000);
    
    return () => clearTimeout(demoTimer);
  }, []);
  
  // Exemplos de uso do sistema de tradução
  return (
    <div className="navigation-container">
      <header className="nav-header">
        {/* Tradução simples de termos do sistema */}
        <h1>{KingRoadLanguage.t('system', 'welcome')}</h1>
      </header>
      
      <div className="vehicle-info">
        {/* Tradução do tipo de veículo */}
        <p>Tipo de veículo: {KingRoadLanguage.translate('vehicles', 'truck')}</p>
      </div>
      
      <div className="current-road">
        {/* Tradução do tipo de estrada */}
        <span>{KingRoadLanguage.t('roadTypes', 'highway')}</span>
        <span>A1</span>
      </div>
      
      <div className="next-instruction">
        {/* Tradução de instrução de navegação */}
        <p className="instruction">
          {KingRoadLanguage.t('navigation', 'take_exit')} 10
        </p>
        <p className="distance">500m</p>
      </div>
      
      <div className="nearby-poi">
        <h3>POIs próximos:</h3>
        <ul>
          {/* Tradução de pontos de interesse */}
          <li>{KingRoadLanguage.t('poi', 'gas_station')} - 2km</li>
          <li>{KingRoadLanguage.t('poi', 'rest_area')} - 15km</li>
        </ul>
      </div>
      
      <div className="alerts">
        {/* Tradução de alertas */}
        <div className="alert warning">
          {KingRoadLanguage.t('alerts', 'speed_camera')} - 1.2km
        </div>
      </div>
      
      <div className="fuel-info">
        {/* Tradução de tipos de combustível */}
        <p>
          {KingRoadLanguage.t('fuel', 'diesel')}: €1.65/L
        </p>
      </div>
      
      <footer>
        <p>Idioma atual: {languageCode === 'pt-PT' ? 'Português Europeu' : 'Português Brasileiro'}</p>
      </footer>
    </div>
  );
};

// -----------------
// Em outro componente, exemplo de uso em comandos de voz:
// -----------------

const VoiceNavigationSystem = () => {
  // Configuração para comandos de voz
  const setupVoiceCommands = () => {
    const announceNextTurn = (direction, distance) => {
      // Aqui você usaria a API de voz do sistema
      const message = `${KingRoadLanguage.t('navigation', direction)} em ${distance} metros`;
      speakMessage(message);
    };
    
    const announceBorderCrossing = (country) => {
      const message = `Bem-vindo a ${country}`;
      speakMessage(message);
    };
    
    // Função de exemplo para TTS (Text-to-Speech)
    const speakMessage = (message) => {
      // Na implementação real, você usaria a API de síntese de voz
      console.log(`[VOZ]: ${message}`);
    };
    
    // Simular alguns comandos
    announceNextTurn('turn_right', 200);
    setTimeout(() => announceNextTurn('take_exit', 500), 3000);
    setTimeout(() => announceBorderCrossing('Espanha'), 6000);
  };
  
  // Código exemplificativo apenas
  return null;
};

// Exporta os componentes de exemplo
export { NavigationView, VoiceNavigationSystem };