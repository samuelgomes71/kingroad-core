package com.kingroad.cache

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.LocalQueueDao
import com.kingroad.database.QueuedItem
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Mantém uma fila local de POIs, alertas e feedbacks criados offline.
 * Reenvia automaticamente quando detecta conexão.
 */
class LocalSyncQueue(
    private val context: Context,
    private val localQueueDao: LocalQueueDao,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "LocalSyncQueue"
        
        // Tipos de itens na fila
        const val TYPE_POI = "poi"
        const val TYPE_ALERT = "alert"
        const val TYPE_FEEDBACK = "feedback"
        const val TYPE_RATING = "rating"
        const val TYPE_EDIT = "edit"
        
        // Estados de sincronização
        enum class SyncState {
            IDLE,            // Nenhuma sincronização em andamento
            SYNCING,         // Sincronização em andamento
            CONNECTION_LOST, // Conexão perdida durante sincronização
            COMPLETED,       // Sincronização concluída com sucesso
            FAILED           // Falha durante sincronização
        }
        
        // Modos de sincronização
        enum class SyncMode {
            AUTO,             // Sincronização automática quando conectado
            MANUAL,           // Sincronização apenas quando solicitada
            WIFI_ONLY         // Sincronização automática apenas quando em Wi-Fi
        }
        
        // Políticas de retry
        enum class RetryPolicy {
            EXPONENTIAL_BACKOFF, // Tentativas com tempo crescente entre elas
            FIXED_INTERVAL,      // Tentativas com intervalo fixo
            IMMEDIATE_ONCE       // Tenta apenas uma vez quando conectado
        }
    }

    // Estado atual da sincronização
    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()
    
    // Número de itens pendentes na fila
    private val _pendingItemsCount = MutableLiveData<Int>(0)
    val pendingItemsCount: LiveData<Int> = _pendingItemsCount
    
    // Indica se estamos tentando sincronizar no momento
    private val isSyncInProgress = AtomicBoolean(false)
    
    // Contadores para métricas
    private val successCount = AtomicInteger(0)
    private val failedCount = AtomicInteger(0)
    
    // Modo de sincronização atual
    private var syncMode = SyncMode.AUTO
    
    // Política de retry atual
    private var retryPolicy = RetryPolicy.EXPONENTIAL_BACKOFF
    
    // Tempo entre tentativas de sincronização (em caso de falha)
    private var retryIntervalMs = 30000L // 30 segundos inicial
    
    // Listener do NetworkCallback
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    
    // Job para tentativas periódicas
    private var retryJob: Job? = null

    init {
        // Inicializa o contador de itens pendentes
        scope.launch {
            updatePendingItemsCount()
        }
        
        // Registra listener de conectividade se modo auto
        if (syncMode == SyncMode.AUTO || syncMode == SyncMode.WIFI_ONLY) {
            registerNetworkCallback()
        }
    }

    /**
     * Adiciona um item à fila de sincronização
     * @param type Tipo do item (POI, ALERT, FEEDBACK, etc)
     * @param data Dados do item em formato JSON
     * @param priority Prioridade do item (maior = mais prioritário)
     * @return ID do item na fila
     */
    suspend fun enqueueItem(
        type: String, 
        data: JSONObject, 
        priority: Int = 0,
        attachments: List<String> = emptyList()
    ): Long = withContext(dispatcher) {
        val item = QueuedItem(
            type = type,
            data = data.toString(),
            priority = priority,
            createdAt = System.currentTimeMillis(),
            attachments = attachments.joinToString(","),
            retryCount = 0
        )
        
        val id = localQueueDao.insert(item)
        updatePendingItemsCount()
        
        // Se em modo auto e com conexão, tenta sincronizar imediatamente
        if ((syncMode == SyncMode.AUTO || 
            (syncMode == SyncMode.WIFI_ONLY && NetworkUtils.isWifiConnected(context))) && 
            NetworkUtils.isConnected(context)) {
            startSync()
        }
        
        id
    }
    
    /**
     * Inicia o processo de sincronização
     * @param forceSyncAll Se true, tenta sincronizar todos os itens independente de retry count
     * @return true se o processo foi iniciado, false caso contrário
     */
    fun startSync(forceSyncAll: Boolean = false): Boolean {
        // Se já está sincronizando, ignora
        if (isSyncInProgress.getAndSet(true)) {
            return false
        }
        
        // Cancela job de retry anterior se existir
        retryJob?.cancel()
        retryJob = null
        
        // Reinicia contadores
        successCount.set(0)
        failedCount.set(0)
        
        // Verifica conexão
        if (!NetworkUtils.isConnected(context)) {
            _syncState.value = SyncState.CONNECTION_LOST
            isSyncInProgress.set(false)
            scheduleRetry()
            return false
        }
        
        // Verifica restrição de WiFi
        if (syncMode == SyncMode.WIFI_ONLY && !NetworkUtils.isWifiConnected(context)) {
            _syncState.value = SyncState.IDLE
            isSyncInProgress.set(false)
            return false
        }
        
        // Inicia o processo de sincronização
        _syncState.value = SyncState.SYNCING
        
        scope.launch {
            try {
                syncPendingItems(forceSyncAll)
                _syncState.value = SyncState.COMPLETED
            } catch (e: Exception) {
                Log.e(TAG, "Erro durante sincronização: ${e.message}", e)
                _syncState.value = SyncState.FAILED
                scheduleRetry()
            } finally {
                isSyncInProgress.set(false)
            }
        }
        
        return true
    }
    
    /**
     * Processa a sincronização dos itens pendentes
     */
    private suspend fun syncPendingItems(forceSyncAll: Boolean) = withContext(dispatcher) {
        // Obtém itens pendentes ordenados por prioridade e timestamp
        val pendingItems = if (forceSyncAll) {
            localQueueDao.getAllItemsOrderedByPriorityAndTime()
        } else {
            localQueueDao.getItemsWithRetryLessThan(MAX_RETRY_COUNT)
        }
        
        if (pendingItems.isEmpty()) {
            Log.d(TAG, "Nenhum item pendente para sincronizar")
            return@withContext
        }
        
        Log.d(TAG, "Iniciando sincronização de ${pendingItems.size} itens")
        
        // Processa os itens agrupados por tipo
        val itemsByType = pendingItems.groupBy { it.type }
        
        // Para cada tipo, processa em batch quando possível
        for ((type, items) in itemsByType) {
            try {
                when (type) {
                    TYPE_POI -> syncPOIs(items)
                    TYPE_ALERT -> syncAlerts(items)
                    TYPE_FEEDBACK -> syncFeedbacks(items)
                    TYPE_RATING -> syncRatings(items)
                    TYPE_EDIT -> syncEdits(items)
                    else -> {
                        // Para tipos desconhecidos, processa um a um
                        items.forEach { syncSingleItem(it) }
                    }
                }
                
                // Verifica conexão após cada tipo
                if (!NetworkUtils.isConnected(context)) {
                    throw IOException("Conexão perdida durante sincronização")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar itens do tipo $type: ${e.message}", e)
                // Continua com próximo tipo
            }
        }
        
        updatePendingItemsCount()
        Log.d(TAG, "Sincronização concluída: ${successCount.get()} sucesso, ${failedCount.get()} falhas")
    }
    
    /**
     * Sincroniza POIs em batch
     */
    private suspend fun syncPOIs(items: List<QueuedItem>) = withContext(dispatcher) {
        Log.d(TAG, "Sincronizando ${items.size} POIs")
        
        // Implementação de batch para POIs
        // Divida em lotes menores se necessário
        val batchSize = 10
        val batches = items.chunked(batchSize)
        
        for (batch in batches) {
            try {
                // Prepara os dados para envio em batch
                val poiData = batch.map { item ->
                    JSONObject(item.data)
                }
                
                // Simula envio para a API
                val success = simulateApiCall("poi_batch", poiData)
                
                if (success) {
                    // Remove itens sincronizados com sucesso
                    batch.forEach { item ->
                        localQueueDao.delete(item)
                        successCount.incrementAndGet()
                    }
                } else {
                    // Incrementa retry count para os itens
                    batch.forEach { item ->
                        val updatedItem = item.copy(
                            retryCount = item.retryCount + 1,
                            lastRetry = System.currentTimeMillis()
                        )
                        localQueueDao.update(updatedItem)
                        failedCount.incrementAndGet()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar batch de POIs: ${e.message}", e)
                // Marca batch como falha e incrementa retry
                batch.forEach { item ->
                    val updatedItem = item.copy(
                        retryCount = item.retryCount + 1,
                        lastRetry = System.currentTimeMillis()
                    )
                    localQueueDao.update(updatedItem)
                    failedCount.incrementAndGet()
                }
            }
            
            // Verifica conexão após cada batch
            if (!NetworkUtils.isConnected(context)) {
                throw IOException("Conexão perdida durante sincronização de POIs")
            }
        }
    }
    
    /**
     * Sincroniza Alertas em batch
     */
    private suspend fun syncAlerts(items: List<QueuedItem>) = withContext(dispatcher) {
        Log.d(TAG, "Sincronizando ${items.size} alertas")
        
        // Implementação similar a POIs
        // Alertas são mais urgentes, priorizar envio individual para confirmação rápida
        for (item in items) {
            try {
                val alertData = JSONObject(item.data)
                
                // Simula envio para a API
                val success = simulateApiCall("alert", alertData)
                
                if (success) {
                    localQueueDao.delete(item)
                    successCount.incrementAndGet()
                } else {
                    val updatedItem = item.copy(
                        retryCount = item.retryCount + 1,
                        lastRetry = System.currentTimeMillis()
                    )
                    localQueueDao.update(updatedItem)
                    failedCount.incrementAndGet()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar alerta: ${e.message}", e)
                val updatedItem = item.copy(
                    retryCount = item.retryCount + 1,
                    lastRetry = System.currentTimeMillis()
                )
                localQueueDao.update(updatedItem)
                failedCount.incrementAndGet()
            }
            
            // Verifica conexão após cada alerta
            if (!NetworkUtils.isConnected(context)) {
                throw IOException("Conexão perdida durante sincronização de alertas")
            }
        }
    }
    
    /**
     * Sincroniza Feedbacks em batch
     */
    private suspend fun syncFeedbacks(items: List<QueuedItem>) = withContext(dispatcher) {
        Log.d(TAG, "Sincronizando ${items.size} feedbacks")
        
        // Feedbacks podem ser enviados em batch maior
        val batchSize = 20
        val batches = items.chunked(batchSize)
        
        for (batch in batches) {
            try {
                // Prepara os dados para envio em batch
                val feedbackData = batch.map { item ->
                    JSONObject(item.data)
                }
                
                // Simula envio para a API
                val success = simulateApiCall("feedback_batch", feedbackData)
                
                if (success) {
                    // Remove itens sincronizados com sucesso
                    batch.forEach { item ->
                        localQueueDao.delete(item)
                        successCount.incrementAndGet()
                    }
                } else {
                    // Incrementa retry count para os itens
                    batch.forEach { item ->
                        val updatedItem = item.copy(
                            retryCount = item.retryCount + 1,
                            lastRetry = System.currentTimeMillis()
                        )
                        localQueueDao.update(updatedItem)
                        failedCount.incrementAndGet()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar batch de feedbacks: ${e.message}", e)
                // Marca batch como falha e incrementa retry
                batch.forEach { item ->
                    val updatedItem = item.copy(
                        retryCount = item.retryCount + 1,
                        lastRetry = System.currentTimeMillis()
                    )
                    localQueueDao.update(updatedItem)
                    failedCount.incrementAndGet()
                }
            }
            
            // Verifica conexão após cada batch
            if (!NetworkUtils.isConnected(context)) {
                throw IOException("Conexão perdida durante sincronização de feedbacks")
            }
        }
    }
    
    /**
     * Sincroniza Ratings em batch
     */
    private suspend fun syncRatings(items: List<QueuedItem>) = withContext(dispatcher) {
        Log.d(TAG, "Sincronizando ${items.size} avaliações")
        
        // Ratings podem ser enviados em batch maior
        val batchSize = 30
        val batches = items.chunked(batchSize)
        
        for (batch in batches) {
            try {
                // Prepara os dados para envio em batch
                val ratingData = batch.map { item ->
                    JSONObject(item.data)
                }
                
                // Simula envio para a API
                val success = simulateApiCall("rating_batch", ratingData)
                
                if (success) {
                    // Remove itens sincronizados com sucesso
                    batch.forEach { item ->
                        localQueueDao.delete(item)
                        successCount.incrementAndGet()
                    }
                } else {
                    // Incrementa retry count para os itens
                    batch.forEach { item ->
                        val updatedItem = item.copy(
                            retryCount = item.retryCount + 1,
                            lastRetry = System.currentTimeMillis()
                        )
                        localQueueDao.update(updatedItem)
                        failedCount.incrementAndGet()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar batch de avaliações: ${e.message}", e)
                // Marca batch como falha e incrementa retry
                batch.forEach { item ->
                    val updatedItem = item.copy(
                        retryCount = item.retryCount + 1,
                        lastRetry = System.currentTimeMillis()
                    )
                    localQueueDao.update(updatedItem)
                    failedCount.incrementAndGet()
                }
            }
            
            // Verifica conexão após cada batch
            if (!NetworkUtils.isConnected(context)) {
                throw IOException("Conexão perdida durante sincronização de avaliações")
            }
        }
    }
    
    /**
     * Sincroniza Edições em batch
     */
    private suspend fun syncEdits(items: List<QueuedItem>) = withContext(dispatcher) {
        Log.d(TAG, "Sincronizando ${items.size} edições")
        
        // Edições precisam ser enviadas individualmente para evitar conflitos
        for (item in items) {
            try {
                val editData = JSONObject(item.data)
                
                // Simula envio para a API
                val success = simulateApiCall("edit", editData)
                
                if (success) {
                    localQueueDao.delete(item)
                    successCount.incrementAndGet()
                } else {
                    val updatedItem = item.copy(
                        retryCount = item.retryCount + 1,
                        lastRetry = System.currentTimeMillis()
                    )
                    localQueueDao.update(updatedItem)
                    failedCount.incrementAndGet()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao sincronizar edição: ${e.message}", e)
                val updatedItem = item.copy(
                    retryCount = item.retryCount + 1,
                    lastRetry = System.currentTimeMillis()
                )
                localQueueDao.update(updatedItem)
                failedCount.incrementAndGet()
            }
            
            // Verifica conexão após cada edição
            if (!NetworkUtils.isConnected(context)) {
                throw IOException("Conexão perdida durante sincronização de edições")
            }
        }
    }
    
    /**
     * Sincroniza um item individual
     */
    private suspend fun syncSingleItem(item: QueuedItem) = withContext(dispatcher) {
        try {
            val itemData = JSONObject(item.data)
            
            // Simula envio para a API
            val success = simulateApiCall(item.type, itemData)
            
            if (success) {
                localQueueDao.delete(item)
                successCount.incrementAndGet()
            } else {
                val updatedItem = item.copy(
                    retryCount = item.retryCount + 1,
                    lastRetry = System.currentTimeMillis()
                )
                localQueueDao.update(updatedItem)
                failedCount.incrementAndGet()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar item do tipo ${item.type}: ${e.message}", e)
            val updatedItem = item.copy(
                retryCount = item.retryCount + 1,
                lastRetry = System.currentTimeMillis()
            )
            localQueueDao.update(updatedItem)
            failedCount.incrementAndGet()
        }
    }
    
    /**
     * Simula uma chamada API (substitua por chamadas reais no projeto)
     */
    private suspend fun simulateApiCall(endpoint: String, data: Any): Boolean {
        // Em um projeto real, aqui seria uma chamada HTTP
        // Esta implementação simula 90% de sucesso
        delay(300) // Simula tempo de rede
        return Math.random() > 0.1 // 90% de sucesso
    }
    
    /**
     * Registra callback para mudanças na rede
     */
    private fun registerNetworkCallback() {
        try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            
            if (networkCallback != null) {
                // Já registrado, remove para recriar
                unregisterNetworkCallback()
            }
            
            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // Conexão disponível, tenta sincronizar
                    if (syncMode == SyncMode.AUTO || 
                        (syncMode == SyncMode.WIFI_ONLY && NetworkUtils.isWifiConnected(context))) {
                        scope.launch {
                            delay(1000) // Espera 1s para estabilizar a conexão
                            startSync()
                        }
                    }
                }
                
                override fun onLost(network: Network) {
                    // Conexão perdida, atualiza estado se estiver sincronizando
                    if (_syncState.value == SyncState.SYNCING) {
                        _syncState.value = SyncState.CONNECTION_LOST
                    }
                }
                
                override fun onCapabilitiesChanged(
                    network: Network,
                    networkCapabilities: NetworkCapabilities
                ) {
                    // Se mudou para WiFi e está em modo WIFI_ONLY, tenta sincronizar
                    if (syncMode == SyncMode.WIFI_ONLY && 
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        scope.launch {
                            delay(1000) // Espera 1s para estabilizar a conexão
                            startSync()
                        }
                    }
                }
            }
            
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            
            connectivityManager.registerNetworkCallback(request, networkCallback!!)
            Log.d(TAG, "Network callback registrado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao registrar network callback: ${e.message}", e)
        }
    }
    
    /**
     * Remove callback de rede
     */
    private fun unregisterNetworkCallback() {
        try {
            networkCallback?.let {
                val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                connectivityManager.unregisterNetworkCallback(it)
                networkCallback = null
                Log.d(TAG, "Network callback removido")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao remover network callback: ${e.message}", e)
        }
    }
    
    /**
     * Agenda nova tentativa de sincronização
     */
    private fun scheduleRetry() {
        // Cancela job anterior se existir
        retryJob?.cancel()
        
        retryJob = scope.launch {
            var retryDelay = retryIntervalMs
            
            // Aplica política de retry
            when (retryPolicy) {
                RetryPolicy.EXPONENTIAL_BACKOFF -> {
                    // Aumenta o intervalo exponencialmente, até um máximo
                    val failCount = failedCount.get()
                    if (failCount > 0) {
                        retryDelay = minOf(retryDelay * (1 shl minOf(failCount, 5)), MAX_RETRY_DELAY)
                    }
                }
                RetryPolicy.FIXED_INTERVAL -> {
                    // Mantém o intervalo fixo
                    retryDelay = retryIntervalMs
                }
                RetryPolicy.IMMEDIATE_ONCE -> {
                    // Tenta apenas uma vez quando conectado
                    // Não agenda retentativa
                    return@launch
                }
            }
            
            Log.d(TAG, "Agendando próxima tentativa em ${retryDelay / 1000} segundos")
            delay(retryDelay)
            
            // Verifica se há conexão e tenta novamente
            if (NetworkUtils.isConnected(context)) {
                startSync()
            }
        }
    }
    
    /**
     * Atualiza contador de itens pendentes
     */
    private suspend fun updatePendingItemsCount() {
        val count = localQueueDao.getPendingItemsCount()
        withContext(Dispatchers.Main) {
            _pendingItemsCount.value = count
        }
    }
    
    /**
     * Define o modo de sincronização
     * @param mode Novo modo de sincronização
     */
    fun setSyncMode(mode: SyncMode) {
        if (syncMode == mode) return
        
        syncMode = mode
        
        // Atualiza network callback baseado no modo
        when (mode) {
            SyncMode.AUTO, SyncMode.WIFI_ONLY -> {
                registerNetworkCallback()
            }
            SyncMode.MANUAL -> {
                unregisterNetworkCallback()
            }
        }
        
        // Se mudou para auto e há conexão, tenta sincronizar
        if ((mode == SyncMode.AUTO || 
            (mode == SyncMode.WIFI_ONLY && NetworkUtils.isWifiConnected(context))) && 
            NetworkUtils.isConnected(context)) {
            scope.launch {
                // Verifica se tem itens pendentes
                val hasPendingItems = localQueueDao.getPendingItemsCount() > 0
                if (hasPendingItems) {
                    startSync()
                }
            }
        }
    }
    
    /**
     * Define a política de retry
     * @param policy Nova política de retry
     */
    fun setRetryPolicy(policy: RetryPolicy) {
        retryPolicy = policy
    }
    
    /**
     * Define o intervalo entre tentativas
     * @param intervalMs Intervalo em milissegundos
     */
    fun setRetryInterval(intervalMs: Long) {
        retryIntervalMs = intervalMs
    }
    
    /**
     * Limpa todos os itens da fila
     */
    suspend fun clearQueue() = withContext(dispatcher) {
        localQueueDao.deleteAll()
        updatePendingItemsCount()
    }
    
    /**
     * Remove um item específico da fila
     * @param itemId ID do item a ser removido
     */
    suspend fun removeItem(itemId: Long) = withContext(dispatcher) {
        localQueueDao.deleteById(itemId)
        updatePendingItemsCount()
    }
    
    /**
     * Libera recursos quando o gerenciador não é mais necessário
     */
    fun shutdown() {
        unregisterNetworkCallback()
        retryJob?.cancel()
        scope.cancel()
    }
    
    /**
     * Obtém estatísticas sobre os itens na fila
     * @return Objeto JSON com estatísticas
     */
    suspend fun getQueueStats(): JSONObject = withContext(dispatcher) {
        val totalItems = localQueueDao.getPendingItemsCount()
        val typeStats = localQueueDao.getItemCountByType()
        val oldestItem = localQueueDao.getOldestItem()
        val failedItems = localQueueDao.getItemsWithRetryGreaterThan(0).size
        
        JSONObject().apply {
            put("totalItems", totalItems)
            put("byType", JSONObject().apply {
                typeStats.forEach { (type, count) ->
                    put(type, count)
                }
            })
            put("oldestItemTimestamp", oldestItem?.createdAt ?: 0)
            put("failedItems", failedItems)
            put("successCount", successCount.get())
            put("failedCount", failedCount.get())
        }
    }
    
    companion object {
        private const val MAX_RETRY_COUNT = 5
        private const val MAX_RETRY_DELAY = 3600000L // 1 hora
    }
}