package com.kingroad.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first

/**
 * Multiplatform key-value storage for user preferences
 * Used to store the fixed app selection for KingSplitScreen
 */
class AppPreferences(private val context: Context) {

    companion object {
        private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "app_preferences")
    }

    /**
     * Get a string value from preferences
     * @param key The preference key
     * @param defaultValue Default value if preference doesn't exist
     * @return The stored string value or defaultValue if not found
     */
    suspend fun getString(key: String, defaultValue: String?): String? {
        val preferenceKey = stringPreferencesKey(key)
        val preferences = context.dataStore.data.first()
        return preferences[preferenceKey] ?: defaultValue
    }

    /**
     * Set a string value in preferences
     * @param key The preference key
     * @param value The value to store
     */
    suspend fun putString(key: String, value: String) {
        val preferenceKey = stringPreferencesKey(key)
        context.dataStore.edit { preferences ->
            preferences[preferenceKey] = value
        }
    }

    /**
     * Remove a preference
     * @param key The preference key to remove
     */
    suspend fun remove(key: String) {
        val preferenceKey = stringPreferencesKey(key)
        context.dataStore.edit { preferences ->
            preferences.remove(preferenceKey)
        }
    }

    /**
     * Clear all preferences
     */
    suspend fun clear() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    /**
     * Observe changes to a string preference
     * @param key The preference key to observe
     * @param defaultValue Default value if preference doesn't exist
     * @return Flow of the preference value
     */
    fun observeString(key: String, defaultValue: String?): Flow<String?> {
        val preferenceKey = stringPreferencesKey(key)
        return context.dataStore.data.map { preferences ->
            preferences[preferenceKey] ?: defaultValue
        }
    }
}