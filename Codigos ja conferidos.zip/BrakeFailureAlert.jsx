import React, { useState, useEffect } from 'react';
import { AlertTriangle, ArrowDown, Navigation, ChevronRight } from 'lucide-react';

const BrakeFailureAlert = ({ 
  alert, 
  onClose, 
  escapeAreas = [], 
  userLocation,
  userDirection,
  userSpeed 
}) => {
  const [expanded, setExpanded] = useState(true);
  const [currentDistance, setCurrentDistance] = useState(null);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  
  // Fornecer valores padrão para props que podem estar indefinidas
  const safeAlert = alert || {
    locationName: "Localização não disponível",
    coordinates: null,
    description: "Informações não disponíveis"
  };
  
  const safeUserLocation = userLocation || { latitude: 0, longitude: 0 };
  const safeUserDirection = userDirection || 'same';
  const safeUserSpeed = userSpeed || 0;
  const safeEscapeAreas = escapeAreas || [];
  
  // Efeito para timer
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Calcular distância até o veículo com falha de freios (simulação)
  useEffect(() => {
    if (!safeUserLocation || !safeAlert.coordinates) return;
    
    // Em um app real, isso seria atualizado com base nas coordenadas reais
    const initialDistance = calculateDistance(safeUserLocation, safeAlert.coordinates);
    
    // Atualizar distância com base na velocidade para simulação
    const updateInterval = setInterval(() => {
      if (safeUserDirection === 'same') {
        // Se estiver no mesmo sentido, a distância diminui (se aproximando do veículo)
        setCurrentDistance(prev => prev !== null ? Math.max(0, prev - (safeUserSpeed / 12)) : initialDistance);
      } else {
        // Se estiver em sentido oposto, a distância aumenta
        setCurrentDistance(prev => prev !== null ? prev + (safeUserSpeed / 10) : initialDistance);
      }
    }, 5000);
    
    setCurrentDistance(initialDistance);
    
    return () => clearInterval(updateInterval);
  }, [safeUserLocation, safeAlert.coordinates, safeUserDirection, safeUserSpeed]);
  
  // Calcular distância entre duas coordenadas
  const calculateDistance = (coord1, coord2) => {
    if (!coord1 || !coord2) return 0;
    
    const R = 6371; // Raio da Terra em km
    const dLat = (coord2.latitude - coord1.latitude) * Math.PI / 180;
    const dLon = (coord2.longitude - coord1.longitude) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(coord1.latitude * Math.PI / 180) * Math.cos(coord2.latitude * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    return distance;
  };
  
  // Formatar o tempo decorrido
  const formatElapsedTime = () => {
    const minutes = Math.floor(secondsElapsed / 60);
    const seconds = secondsElapsed % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Estilo de alerta baseado na distância
  const getAlertStyle = () => {
    if (!currentDistance) return 'bg-yellow-600';
    
    if (currentDistance < 0.5) return 'bg-red-600 animate-pulse';
    if (currentDistance < 2) return 'bg-amber-600';
    return 'bg-yellow-600';
  };
  
  // Calcular tempo estimado até a área de escape
  const calculateETA = (escapeArea) => {
    if (!safeUserSpeed || !safeUserLocation) return 'Calculando...';
    
    const distance = calculateDistance(safeUserLocation, escapeArea.coordinates);
    const timeInHours = distance / safeUserSpeed;
    const timeInMinutes = timeInHours * 60;
    
    if (timeInMinutes < 1) {
      return 'Menos de 1 min';
    }
    
    return `${Math.round(timeInMinutes)} min`;
  };
  
  // Classificar áreas de escape por proximidade
  const sortedEscapeAreas = [...safeEscapeAreas].sort((a, b) => {
    if (!safeUserLocation) return 0;
    const distA = calculateDistance(safeUserLocation, a.coordinates);
    const distB = calculateDistance(safeUserLocation, b.coordinates);
    return distA - distB;
  });
  
  // Obter a área de escape mais próxima
  const nearestEscapeArea = sortedEscapeAreas.length > 0 ? sortedEscapeAreas[0] : null;
  
  return (
    <div className={`fixed right-0 top-1/4 max-w-sm z-40 transition-all duration-300 ease-in-out transform ${expanded ? 'translate-x-0' : 'translate-x-11/12'}`}>
      {/* Botão de expansão/contração */}
      <button 
        className="absolute left-0 top-1/2 transform -translate-x-full -translate-y-1/2 bg-red-800 p-2 rounded-l-md"
        onClick={() => setExpanded(!expanded)}
      >
        <ChevronRight 
          size={24} 
          className={`text-white transition-transform duration-300 ${expanded ? 'rotate-180' : 'rotate-0'}`} 
        />
      </button>
      
      {/* Conteúdo principal */}
      <div className={`${getAlertStyle()} text-white shadow-lg rounded-l-lg overflow-hidden`}>
        {/* Cabeçalho */}
        <div className="p-3 border-b border-white border-opacity-20 flex items-center">
          <AlertTriangle size={24} className="mr-2" />
          <div>
            <h3 className="font-bold">CAMINHÃO SEM FREIO</h3>
            <p className="text-xs">Alerta enviado há {formatElapsedTime()}</p>
          </div>
        </div>
        
        {/* Informações da localização */}
        <div className="bg-black bg-opacity-30 p-3">
          <div className="flex items-center">
            <ArrowDown size={20} className="text-red-300 mr-2" />
            <div>
              <p className="font-medium">{safeAlert.locationName}</p>
              {currentDistance !== null && (
                <p className="text-sm">
                  {currentDistance < 0.1 
                    ? 'EXTREMAMENTE PRÓXIMO!' 
                    : `A ${currentDistance.toFixed(1)} km ${safeUserDirection === 'same' ? 'atrás' : 'à frente'} de você`}
                </p>
              )}
            </div>
          </div>
        </div>
        
        {/* Área de escape mais próxima */}
        {nearestEscapeArea && (
          <div className="p-3 bg-green-800">
            <h4 className="font-bold flex items-center">
              <Navigation size={18} className="mr-1" />
              ÁREA DE ESCAPE MAIS PRÓXIMA:
            </h4>
            <div className="flex justify-between items-center mt-1">
              <div>
                <p>{nearestEscapeArea.name}</p>
                <p className="text-xs text-green-200">
                  A {calculateDistance(safeUserLocation, nearestEscapeArea.coordinates).toFixed(1)} km
                </p>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold">{calculateETA(nearestEscapeArea)}</p>
                <p className="text-xs">tempo estimado</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Lista de todas as áreas de escape */}
        <div className="max-h-48 overflow-y-auto bg-opacity-50 bg-black">
          <h4 className="px-3 py-2 font-medium text-sm bg-black bg-opacity-60 sticky top-0">
            TODAS AS ÁREAS DE ESCAPE NESTA ROTA:
          </h4>
          
          {sortedEscapeAreas.length > 0 ? (
            <div className="divide-y divide-gray-700">
              {sortedEscapeAreas.map((area, index) => (
                <div key={index} className="p-2 px-3 hover:bg-black hover:bg-opacity-40">
                  <div className="flex justify-between">
                    <p className="font-medium text-sm">{area.name}</p>
                    <p className="text-sm">{calculateDistance(safeUserLocation, area.coordinates).toFixed(1)} km</p>
                  </div>
                  <p className="text-xs text-gray-300">{area.description}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="p-3 text-gray-400 text-sm">Nenhuma área de escape identificada nesta rota.</p>
          )}
        </div>
        
        {/* Instruções de segurança */}
        <div className="p-3 bg-black bg-opacity-70 text-yellow-300 text-sm">
          <p className="font-bold">INSTRUÇÕES DE SEGURANÇA:</p>
          <ul className="list-disc pl-4 text-xs mt-1 space-y-1">
            <li>Mantenha distância segura do veículo em perigo</li>
            <li>Alerte outros motoristas</li>
            <li>Em caso de risco, procure um local seguro para sair da pista</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default BrakeFailureAlert;