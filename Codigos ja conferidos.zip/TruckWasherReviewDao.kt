package com.kingroad.database.dao

import androidx.room.*
import com.kingroad.poi.TruckWasherReview

/**
 * Interface DAO para acessar a tabela de avaliações de lavagens
 */
@Dao
interface TruckWasherReviewDao {
    
    /**
     * Insere uma nova avaliação
     * @param review Avaliação a ser inserida
     * @return ID da avaliação inserida
     */
    @Insert
    suspend fun insert(review: TruckWasherReview): Long
    
    /**
     * Atualiza uma avaliação existente
     * @param review Avaliação atualizada
     */
    @Update
    suspend fun update(review: TruckWasherReview)
    
    /**
     * Remove uma avaliação
     * @param review Avaliação a ser removida
     */
    @Delete
    suspend fun delete(review: TruckWasherReview)
    
    /**
     * Busca uma avaliação pelo ID
     * @param id ID da avaliação
     * @return A avaliação encontrada ou null
     */
    @Query("SELECT * FROM truck_washer_reviews WHERE id = :id")
    suspend fun findById(id: String): TruckWasherReview?
    
    /**
     * Busca todas as avaliações de um POI
     * @param poiId ID do POI
     * @return Lista de avaliações do POI
     */
    @Query("SELECT * FROM truck_washer_reviews WHERE poiId = :poiId ORDER BY date DESC")
    suspend fun findByPoiId(poiId: String): List<TruckWasherReview>
    
    /**
     * Busca avaliações de um POI com paginação
     * @param poiId ID do POI
     * @param limit Número máximo de resultados
     * @param offset Deslocamento para paginação
     * @return Lista de avaliações paginada
     */
    @Query("SELECT * FROM truck_washer_reviews WHERE poiId = :poiId ORDER BY date DESC LIMIT :limit OFFSET :offset")
    suspend fun findByPoiIdPaginated(poiId: String, limit: Int, offset: Int): List<TruckWasherReview>
    
    /**
     * Busca todas as avaliações feitas por um usuário
     * @param userId ID do usuário
     * @return Lista de avaliações do usuário
     */
    @Query("SELECT * FROM truck_washer_reviews WHERE userId = :userId ORDER BY date DESC")
    suspend fun findByUserId(userId: String): List<TruckWasherReview>
    
    /**
     * Busca uma avaliação específica feita por um usuário para um POI
     * @param poiId ID do POI
     * @param userId ID do usuário
     * @return A avaliação encontrada ou null
     */
    @Query("SELECT * FROM truck_washer_reviews WHERE poiId = :poiId AND userId = :userId")
    suspend fun findByPoiIdAndUserId(poiId: String, userId: String): TruckWasherReview?
    
    /**
     * Conta o número de avaliações para um POI
     * @param poiId ID do POI
     * @return Quantidade de avaliações
     */
    @Query("SELECT COUNT(*) FROM truck_washer_reviews WHERE poiId = :poiId")
    suspend fun getReviewCount(poiId: String): Int
    
    /**
     * Conta o número de avaliações feitas por um usuário
     * @param userId ID do usuário
     * @return Quantidade de avaliações
     */
    @Query("SELECT COUNT(*) FROM truck_washer_reviews WHERE userId = :userId")
    suspend fun getReviewCountByUser(userId: String): Int
    
    /**
     * Calcula a média de avaliações para um POI
     * @param poiId ID do POI
     * @return Média das avaliações ou 0 se não houver avaliações
     */
    @Query("SELECT AVG(rating) FROM truck_washer_reviews WHERE poiId = :poiId")
    suspend fun getAverageRating(poiId: String): Float
    
    /**
     * Incrementa o contador de "Útil" de uma avaliação
     * @param reviewId ID da avaliação
     */
    @Query("UPDATE truck_washer_reviews SET helpful = helpful + 1 WHERE id = :reviewId")
    suspend fun incrementHelpful(reviewId: String)
    
    /**
     * Incrementa o contador de "Não útil" de uma avaliação
     * @param reviewId ID da avaliação
     */
    @Query("UPDATE truck_washer_reviews SET notHelpful = notHelpful + 1 WHERE id = :reviewId")
    suspend fun incrementNotHelpful(reviewId: String)
    
    /**
     * Remove todas as avaliações de um POI
     * @param poiId ID do POI
     */
    @Query("DELETE FROM truck_washer_reviews WHERE poiId = :poiId")
    suspend fun deleteAllByPoiId(poiId: String)
}