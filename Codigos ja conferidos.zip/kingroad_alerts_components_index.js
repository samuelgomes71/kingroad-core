import AlertTriangle from './AlertTriangle';

export {
  AlertTriangle
};