import React, { useState, useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';

// Este componente fornece uma indicação visual clara de que o app está em versão Beta
// Ele mostra um banner na parte superior da tela que pode ser minimizado
// O banner reaparece periodicamente para garantir que o usuário esteja ciente do status beta

const BetaIndicator = ({ 
  daysRemaining = 180, // Período total de 6 meses gratuito conforme definido no status_beta
  language = 'pt' // Usando português como padrão, mas pode ser alterado via TranslationsService
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [lastMinimizedTime, setLastMinimizedTime] = useState(null);

  // Tradução para diferentes idiomas (a ser expandido usando TranslationsService)
  const translations = {
    pt: {
      betaVersion: 'Versão Beta',
      daysRemaining: `${daysRemaining} dias restantes no período gratuito`,
      minimize: 'Minimizar',
      expand: 'Mostrar'
    },
    en: {
      betaVersion: 'Beta Version',
      daysRemaining: `${daysRemaining} days remaining in free period`,
      minimize: 'Minimize',
      expand: 'Show'
    },
    es: {
      betaVersion: 'Versión Beta',
      daysRemaining: `${daysRemaining} días restantes en el período gratuito`,
      minimize: 'Minimizar',
      expand: 'Mostrar'
    }
  };

  // Escolhe o idioma correto, com fallback para inglês
  const text = translations[language] || translations.en;

  // Verifica se o banner deve reaparecer após um tempo
  useEffect(() => {
    if (isMinimized && lastMinimizedTime) {
      const checkTime = setTimeout(() => {
        const hoursPassed = (Date.now() - lastMinimizedTime) / (1000 * 60 * 60);
        if (hoursPassed > 24) { // Reaparece após 24 horas
          setIsMinimized(false);
        }
      }, 60 * 1000); // Verifica a cada minuto
      
      return () => clearTimeout(checkTime);
    }
  }, [isMinimized, lastMinimizedTime]);

  // Maneja o botão de minimizar/expandir
  const toggleMinimized = () => {
    if (!isMinimized) {
      setLastMinimizedTime(Date.now());
    }
    setIsMinimized(!isMinimized);
  };

  // Versão minimizada do banner
  if (isMinimized) {
    return (
      <div className="fixed top-0 right-0 m-2 p-2 bg-amber-400 rounded-full shadow-md cursor-pointer z-50" onClick={toggleMinimized} title={text.betaVersion}>
        <AlertTriangle size={20} className="text-amber-800" />
      </div>
    );
  }

  // Versão expandida do banner
  return (
    <div className="fixed top-0 left-0 right-0 bg-amber-400 text-amber-900 p-3 flex justify-between items-center z-50 shadow-md">
      <div className="flex items-center space-x-2">
        <AlertTriangle size={20} />
        <div>
          <span className="font-bold">{text.betaVersion}</span>
          <span className="ml-2 text-sm">{text.daysRemaining}</span>
        </div>
      </div>
      <button 
        onClick={toggleMinimized}
        className="px-3 py-1 bg-amber-500 hover:bg-amber-600 rounded-md text-white text-sm font-medium transition-colors"
      >
        {text.minimize}
      </button>
    </div>
  );
};

export default BetaIndicator;