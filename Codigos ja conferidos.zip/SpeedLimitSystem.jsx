import React, { useState, useEffect } from 'react';
import { Truck, Car, AlertTriangle, Bus, Navigation } from 'lucide-react';

const SpeedLimitSystem = () => {
  // Estados
  const [currentSpeed, setCurrentSpeed] = useState(78); // Velocidade atual simulada (km/h)
  const [roadType, setRoadType] = useState('highway'); // Tipo de via atual (highway, national, urban)
  const [vehicleType, setVehicleType] = useState('truck'); // Tipo de veículo (truck, car, bus)
  const [isADR, setIsADR] = useState(false); // Transporte de materiais perigosos (ADR)
  const [country, setCountry] = useState('França'); // País atual
  const [isDarkMode, setIsDarkMode] = useState(true); // Tema escuro como padrão
  const [speedUnit, setSpeedUnit] = useState('km/h'); // Unidade de velocidade
  const [isOverSpeedLimit, setIsOverSpeedLimit] = useState(false); // Indicador de excesso de velocidade
  
  // Dados de velocidades por país e tipo de via para diferentes veículos
  const speedLimits = {
    // União Europeia (padrão para países Schengen)
    default: {
      car: {
        highway: 130,
        national: 90,
        urban: 50
      },
      truck: {
        highway: 90,
        national: 80,
        urban: 50,
        weight: {
          // Caminhões acima de 12 toneladas podem ter limites diferentes
          above12t: {
            highway: 80,
            national: 80,
            urban: 50
          }
        },
        adr: {
          // Redução de 10km/h para transporte de materiais perigosos
          highway: 80,
          national: 70,
          urban: 50
        }
      },
      bus: {
        highway: 100,
        national: 80,
        urban: 50
      }
    },
    
    // Exemplos de regras específicas por país
    Alemanha: {
      car: {
        highway: 'sem limite', // Famosas autobahns sem limite em algumas seções
        national: 100,
        urban: 50
      },
      truck: {
        highway: 80,
        national: 80,
        urban: 50,
        adr: {
          highway: 60,
          national: 60,
          urban: 50
        }
      }
    },
    
    França: {
      car: {
        highway: 130,
        national: 90,
        urban: 50
      },
      truck: {
        highway: 90,
        national: 80,
        urban: 50,
        adr: {
          highway: 80,
          national: 70,
          urban: 50
        }
      }
    },
    
    Espanha: {
      car: {
        highway: 120,
        national: 90,
        urban: 50
      },
      truck: {
        highway: 90,
        national: 80,
        urban: 50,
        adr: {
          highway: 80,
          national: 70,
          urban: 50
        }
      }
    },
    
    Itália: {
      car: {
        highway: 130,
        national: 90, 
        urban: 50
      },
      truck: {
        highway: 80,
        national: 70,
        urban: 50,
        adr: {
          highway: 70,
          national: 60,
          urban: 40
        }
      }
    },
    
    Portugal: {
      car: {
        highway: 120,
        national: 90,
        urban: 50
      },
      truck: {
        highway: 90,
        national: 80,
        urban: 50,
        adr: {
          highway: 80,
          national: 70,
          urban: 40
        }
      }
    }
  };
  
  // Cores das placas de trânsito por país (seguindo padrões reais)
  const signColors = {
    default: {
      highway: { bg: '#009ee0', text: 'white' }, // Azul
      national: { bg: 'white', text: 'black', border: '#333' }, // Branco com borda
      urban: { bg: 'white', text: 'black', border: 'red' }, // Branco com borda vermelha para zonas urbanas
      adr: { bg: '#f44336', text: 'white' } // Vermelho para ADR
    },
    Alemanha: {
      highway: { bg: '#009ee0', text: 'white' },
      national: { bg: 'white', text: 'black', border: '#333' },
      urban: { bg: 'white', text: 'black', border: 'red' }
    },
    França: {
      highway: { bg: '#009ee0', text: 'white' },
      national: { bg: 'white', text: 'black', border: 'red' },
      urban: { bg: 'white', text: 'black', border: 'red' }
    },
    // Os outros países seguem o padrão similar
  };
  
  // Determinando cores da placa
  const getSignStyle = () => {
    const countryColors = signColors[country] || signColors.default;
    const colorSet = countryColors[roadType];
    
    if (isADR && vehicleType === 'truck') {
      return {
        backgroundColor: signColors.default.adr.bg,
        color: signColors.default.adr.text,
        border: 'none'
      };
    }
    
    return {
      backgroundColor: colorSet.bg,
      color: colorSet.text,
      border: colorSet.border ? `2px solid ${colorSet.border}` : 'none'
    };
  };

  // Obter o limite de velocidade atual com base no país, tipo de veículo e via
  const getCurrentSpeedLimit = () => {
    // Garante que temos regras para o país selecionado ou usa o padrão
    const countryRules = speedLimits[country] || speedLimits.default;
    let limit;
    
    // Verifica se o tipo de veículo existe nas regras do país
    if (!countryRules[vehicleType]) {
      // Se não existir, usa as regras padrão para esse tipo de veículo
      return speedLimits.default[vehicleType][roadType];
    }
    
    if (vehicleType === 'truck') {
      if (isADR && countryRules.truck && countryRules.truck.adr) {
        // Regras ADR para caminhões com materiais perigosos
        limit = countryRules.truck.adr[roadType];
      } else if (countryRules.truck) {
        // Regras normais para caminhões
        limit = countryRules.truck[roadType];
      } else {
        // Fallback para regras padrão
        limit = speedLimits.default.truck[roadType];
      }
    } else {
      // Outros tipos de veículos
      if (countryRules[vehicleType] && countryRules[vehicleType][roadType] !== undefined) {
        limit = countryRules[vehicleType][roadType];
      } else {
        // Fallback para regras padrão
        limit = speedLimits.default[vehicleType][roadType];
      }
    }
    
    return limit;
  };
  
  // Simula a mudança de velocidade atual
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulação de mudança de velocidade
      const randomChange = Math.floor(Math.random() * 5) - 2; // -2 a +2
      setCurrentSpeed(current => {
        const newSpeed = Math.max(0, current + randomChange);
        return newSpeed;
      });
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Verifica se está acima do limite de velocidade
  useEffect(() => {
    try {
      const speedLimit = getCurrentSpeedLimit();
      if (typeof speedLimit === 'number') {
        setIsOverSpeedLimit(currentSpeed > speedLimit);
      } else {
        setIsOverSpeedLimit(false); // Para o caso de "sem limite" na Alemanha
      }
    } catch (error) {
      console.error("Erro ao verificar limite de velocidade:", error);
      setIsOverSpeedLimit(false); // Em caso de erro, não mostra alerta
    }
  }, [currentSpeed, vehicleType, roadType, country, isADR]);
  
  // Alternar entre tipos de veículo
  const toggleVehicleType = () => {
    const types = ['car', 'truck', 'bus'];
    const currentIndex = types.indexOf(vehicleType);
    const nextIndex = (currentIndex + 1) % types.length;
    setVehicleType(types[nextIndex]);
  };
  
  // Alternar tipo de estrada (para simulação)
  const toggleRoadType = () => {
    const types = ['highway', 'national', 'urban'];
    const currentIndex = types.indexOf(roadType);
    const nextIndex = (currentIndex + 1) % types.length;
    setRoadType(types[nextIndex]);
  };
  
  // Alternar ADR (para caminhões de materiais perigosos)
  const toggleADR = () => {
    setIsADR(!isADR);
  };
  
  // Alternar país (para simulação)
  const toggleCountry = () => {
    const countries = ['França', 'Alemanha', 'Espanha', 'Itália', 'Portugal'];
    const currentIndex = countries.indexOf(country);
    const nextIndex = (currentIndex + 1) % countries.length;
    setCountry(countries[nextIndex]);
  };
  
  // Converter para mph se necessário
  const formatSpeed = (speed) => {
    if (typeof speed !== 'number') return speed; // Para o caso de "sem limite"
    
    if (speedUnit === 'mph') {
      return Math.round(speed * 0.621371);
    }
    return speed;
  };
  
  // Traduzir tipo de estrada para exibição
  const getRoadTypeDisplay = () => {
    const translations = {
      highway: 'Autoestrada',
      national: 'Estrada Nacional',
      urban: 'Zona Urbana'
    };
    
    return translations[roadType] || roadType;
  };

  return (
    <div className={`p-4 ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'} min-h-screen`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-6 border-b border-gray-700 pb-3">
        <div className="flex items-center">
          {vehicleType === 'truck' ? (
            <Truck className="w-6 h-6 mr-2 text-blue-500" />
          ) : vehicleType === 'car' ? (
            <Car className="w-6 h-6 mr-2 text-green-500" />
          ) : (
            <Bus className="w-6 h-6 mr-2 text-yellow-500" />
          )}
          <h1 className="text-xl font-bold">King Road</h1>
        </div>
        <div className="text-sm font-medium">{country}</div>
      </div>
      
      {/* Painel principal de velocidade */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-4`}>
        <div className="flex justify-between items-center mb-3">
          <div className="text-sm text-gray-400">{getRoadTypeDisplay()}</div>
          {isADR && vehicleType === 'truck' && (
            <div className="px-2 py-1 bg-red-800 text-white text-xs rounded-md">ADR</div>
          )}
        </div>
        
        {/* Velocidades */}
        <div className="flex justify-between items-center mb-3">
          {/* Velocidade Atual */}
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Velocidade Atual</div>
            <div 
              className={`text-4xl font-bold ${isOverSpeedLimit ? 'text-red-500 animate-pulse' : 'text-gray-400'}`}
            >
              {formatSpeed(currentSpeed)}
              <span className="text-sm ml-1">{speedUnit}</span>
            </div>
          </div>
          
          {/* Divisor */}
          <div className="h-16 w-px bg-gray-700 mx-2"></div>
          
          {/* Velocidade Máxima */}
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Velocidade Máxima</div>
            <div 
              className="flex justify-center"
              style={{
                minWidth: '90px',
                minHeight: '42px',
              }}
            >
              <div
                className="flex items-center justify-center rounded-full px-3 py-1 font-bold"
                style={{
                  ...getSignStyle(),
                  minWidth: '80px',
                  height: '42px',
                  fontSize: '22px'
                }}
              >
                {formatSpeed(getCurrentSpeedLimit())}
              </div>
            </div>
          </div>
        </div>
        
        {/* Alerta de excesso de velocidade */}
        {isOverSpeedLimit && (
          <div className="flex items-center justify-center p-2 bg-red-900/50 rounded-lg mt-2 animate-pulse">
            <AlertTriangle className="w-4 h-4 text-red-500 mr-2" />
            <span className="text-red-400 text-sm font-medium">Excesso de velocidade!</span>
          </div>
        )}
      </div>
      
      {/* Controles de simulação (apenas para demonstração) */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-4`}>
        <h3 className="text-sm font-medium mb-3">Configurações de Teste</h3>
        
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={toggleVehicleType}
            className="flex items-center justify-center p-2 bg-blue-900/30 rounded-lg"
          >
            {vehicleType === 'truck' ? (
              <Truck className="w-4 h-4 mr-2 text-blue-500" />
            ) : vehicleType === 'car' ? (
              <Car className="w-4 h-4 mr-2 text-green-500" />
            ) : (
              <Bus className="w-4 h-4 mr-2 text-yellow-500" />
            )}
            <span className="text-sm">{vehicleType === 'truck' ? 'Caminhão' : vehicleType === 'car' ? 'Carro' : 'Ônibus'}</span>
          </button>
          
          <button 
            onClick={toggleRoadType}
            className="flex items-center justify-center p-2 bg-blue-900/30 rounded-lg"
          >
            <Navigation className="w-4 h-4 mr-2 text-blue-500" />
            <span className="text-sm truncate">{getRoadTypeDisplay()}</span>
          </button>
          
          <button 
            onClick={toggleCountry}
            className="flex items-center justify-center p-2 bg-blue-900/30 rounded-lg"
          >
            <span className="text-sm">{country}</span>
          </button>
          
          {vehicleType === 'truck' && (
            <button 
              onClick={toggleADR}
              className={`flex items-center justify-center p-2 rounded-lg ${isADR ? 'bg-red-900/30' : 'bg-blue-900/30'}`}
            >
              <span className="text-sm">ADR: {isADR ? 'Ativo' : 'Inativo'}</span>
            </button>
          )}
        </div>
      </div>
      
      {/* Informações adicionais */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4`}>
        <h3 className="text-sm font-medium mb-3">Informações de Velocidade</h3>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Veículo:</span>
            <span>
              {vehicleType === 'truck' ? 'Caminhão' : vehicleType === 'car' ? 'Carro' : 'Ônibus'}
              {isADR && vehicleType === 'truck' ? ' (ADR)' : ''}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-400">Limite em Autoestrada:</span>
            <span>
              {(() => {
                try {
                  if (vehicleType === 'truck' && isADR) {
                    const limit = speedLimits[country]?.truck?.adr?.highway || speedLimits.default.truck.adr.highway;
                    return `${formatSpeed(limit)} ${speedUnit}`;
                  } else {
                    const vehicleRules = speedLimits[country]?.[vehicleType] || speedLimits.default[vehicleType];
                    return `${formatSpeed(vehicleRules.highway)} ${speedUnit}`;
                  }
                } catch (e) {
                  return `-- ${speedUnit}`;
                }
              })()}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-400">Limite em Estrada Nacional:</span>
            <span>
              {(() => {
                try {
                  if (vehicleType === 'truck' && isADR) {
                    const limit = speedLimits[country]?.truck?.adr?.national || speedLimits.default.truck.adr.national;
                    return `${formatSpeed(limit)} ${speedUnit}`;
                  } else {
                    const vehicleRules = speedLimits[country]?.[vehicleType] || speedLimits.default[vehicleType];
                    return `${formatSpeed(vehicleRules.national)} ${speedUnit}`;
                  }
                } catch (e) {
                  return `-- ${speedUnit}`;
                }
              })()}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-400">Limite em Zona Urbana:</span>
            <span>
              {(() => {
                try {
                  if (vehicleType === 'truck' && isADR) {
                    const limit = speedLimits[country]?.truck?.adr?.urban || speedLimits.default.truck.adr.urban;
                    return `${formatSpeed(limit)} ${speedUnit}`;
                  } else {
                    const vehicleRules = speedLimits[country]?.[vehicleType] || speedLimits.default[vehicleType];
                    return `${formatSpeed(vehicleRules.urban)} ${speedUnit}`;
                  }
                } catch (e) {
                  return `-- ${speedUnit}`;
                }
              })()}
            </span>
          </div>
          
          {vehicleType === 'truck' && isADR && (
            <div className="mt-2 p-2 bg-red-900/20 rounded text-xs">
              <span className="font-medium text-red-400">Nota ADR:</span> Veículos transportando materiais perigosos (ADR) devem respeitar limites específicos, geralmente 10 km/h abaixo dos limites normais para caminhões.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SpeedLimitSystem;