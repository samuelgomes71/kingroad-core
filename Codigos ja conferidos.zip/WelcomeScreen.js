// WelcomeScreen.js
// Tela de boas-vindas exibida ao cruzar fronteiras no KingRoad

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Animated,
  Easing,
  TouchableOpacity,
  Share,
  Platform,
  SafeAreaView,
  ImageBackground
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import CountryMascotData from './CountryMascotData';

const WelcomeScreen = ({ route, navigation }) => {
  const {
    welcomeData,
    userQRA,
    displayTime = 5000,
    animationEnabled = true,
    onClose
  } = route.params || {};

  // States
  const [selectedReaction, setSelectedReaction] = useState(null);
  const [showReactions, setShowReactions] = useState(false);
  
  // Refs for animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mascotAnim = useRef(new Animated.Value(0)).current;
  const flagAnim = useRef(new Animated.Value(-100)).current;
  const cityAnim = useRef(new Animated.Value(100)).current;
  const textAnim = useRef(new Animated.Value(0)).current;
  const timer = useRef(null);

  // Set up auto-close timer
  useEffect(() => {
    startCloseTimer();

    return () => {
      if (timer.current) {
        clearTimeout(timer.current);
      }
    };
  }, []);

  // Start animations when screen is focused
  useFocusEffect(
    React.useCallback(() => {
      startAnimations();
      return () => {
        // Cleanup if needed
      };
    }, [])
  );

  // Start the auto-close timer
  const startCloseTimer = () => {
    timer.current = setTimeout(() => {
      closeScreen();
    }, displayTime);
  };

  // Reset the timer when user interacts
  const resetTimer = () => {
    if (timer.current) {
      clearTimeout(timer.current);
    }
    startCloseTimer();
  };

  // Play all entrance animations
  const startAnimations = () => {
    if (!animationEnabled) {
      // If animations disabled, just show everything immediately
      fadeAnim.setValue(1);
      mascotAnim.setValue(1);
      flagAnim.setValue(0);
      cityAnim.setValue(0);
      textAnim.setValue(1);
      return;
    }

    // Main fade in
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    // Mascot animation
    Animated.sequence([
      Animated.delay(200),
      Animated.timing(mascotAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.bounce,
        useNativeDriver: true,
      }),
    ]).start();

    // Flag slide in
    Animated.sequence([
      Animated.delay(400),
      Animated.timing(flagAnim, {
        toValue: 0,
        duration: 500,
        easing: Easing.out(Easing.back(1.5)),
        useNativeDriver: true,
      }),
    ]).start();

    // City sign slide in
    Animated.sequence([
      Animated.delay(600),
      Animated.timing(cityAnim, {
        toValue: 0,
        duration: 500,
        easing: Easing.out(Easing.back(1.5)),
        useNativeDriver: true,
      }),
    ]).start();

    // Welcome text fade in
    Animated.sequence([
      Animated.delay(800),
      Animated.timing(textAnim, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();

    // Start mascot animation loop if enabled
    startMascotAnimation();
  };
  
  // Continuous subtle mascot animation
  const startMascotAnimation = () => {
    if (!animationEnabled) return;
    
    // Create a subtle bobbing animation for the mascot
    Animated.loop(
      Animated.sequence([
        Animated.timing(mascotAnim, {
          toValue: 1.05,
          duration: 1500,
          easing: Easing.inOut(Easing.sine),
          useNativeDriver: true,
        }),
        Animated.timing(mascotAnim, {
          toValue: 0.95,
          duration: 1500,
          easing: Easing.inOut(Easing.sine),
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  // Share current country with others
  const shareArrival = async () => {
    resetTimer();
    
    try {
      const result = await Share.share({
        message: `Acabei de chegar em ${welcomeData.country} com o KingRoad! 🚚🌍`,
        url: 'https://kingroad.app', // Example, replace with your app's URL
      });
      
      if (result.action === Share.sharedAction) {
        console.log('Content shared successfully');
      }
    } catch (error) {
      console.error('Error sharing content:', error);
    }
  };

  // Handle user reaction selection
  const handleReaction = (reactionId) => {
    setSelectedReaction(reactionId);
    setShowReactions(false);
    resetTimer();
    
    // Here you could send the reaction to a server or analytics
    console.log(`User reacted with: ${reactionId}`);
  };

  // Toggle reactions panel
  const toggleReactions = () => {
    setShowReactions(!showReactions);
    resetTimer();
  };

  // Close the welcome screen
  const closeScreen = () => {
    // Play exit animation
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      // Go back after animation
      navigation.goBack();
      
      // Call onClose callback if provided
      if (onClose) {
        onClose();
      }
    });
  };

  // If no welcome data, close immediately
  if (!welcomeData || !welcomeData.country) {
    closeScreen();
    return null;
  }

  // Get personalized speech with QRA if available
  const speech = userQRA 
    ? welcomeData.mascotSpeech.replace('Q.R.A.', userQRA)
    : welcomeData.mascotSpeech;

  return (
    <Animated.View 
      style={[
        styles.container, 
        { opacity: fadeAnim }
      ]}
    >
      <ImageBackground
        source={welcomeData.backgroundImage}
        style={styles.backgroundImage}
        blurRadius={3}
      >
        <SafeAreaView style={styles.safeContainer}>
          {/* Close button */}
          <TouchableOpacity 
            style={styles.closeButton} 
            onPress={closeScreen}
          >
            <Icon name="close" size={24} color="#fff" />
          </TouchableOpacity>
          
          {/* Country flag */}
          <Animated.Image
            source={welcomeData.flagImage}
            style={[
              styles.flag,
              {
                transform: [
                  { translateX: flagAnim }
                ]
              }
            ]}
          />
          
          {/* Welcome message */}
          <Animated.View
            style={[
              styles.welcomeTextContainer,
              {
                opacity: textAnim,
                transform: [
                  { scale: textAnim }
                ]
              }
            ]}
          >
            <Text style={styles.welcomeText}>{welcomeData.greeting}</Text>
          </Animated.View>
          
          {/* Mascot character */}
          <Animated.Image
            source={welcomeData.mascotImage}
            style={[
              styles.mascot,
              {
                transform: [
                  { scale: mascotAnim }
                ]
              }
            ]}
          />
          
          {/* Speech bubble */}
          <Animated.View
            style={[
              styles.speechBubble,
              {
                opacity: textAnim,
                transform: [
                  { scale: textAnim }
                ]
              }
            ]}
          >
            <Text style={styles.speechText}>{speech}</Text>
          </Animated.View>
          
          {/* City sign */}
          <Animated.View
            style={[
              styles.citySign,
              {
                transform: [
                  { translateX: cityAnim }
                ]
              }
            ]}
          >
            <Text style={styles.cityName}>{welcomeData.city}</Text>
          </Animated.View>
          
          {/* Action buttons */}
          <View style={styles.actionsContainer}>
            {/* Reactions button */}
            <TouchableOpacity
              style={styles.actionButton}
              onPress={toggleReactions}
            >
              <Icon 
                name={selectedReaction 
                  ? CountryMascotData.availableReactions.find(r => r.id === selectedReaction)?.emoji 
                  : "emoticon-outline"
                } 
                size={24} 
                color="#fff" 
              />
            </TouchableOpacity>
            
            {/* Share button */}
            <TouchableOpacity
              style={styles.actionButton}
              onPress={shareArrival}
            >
              <Icon name="share-variant" size={24} color="#fff" />
            </TouchableOpacity>
          </View>
          
          {/* Reactions panel */}
          {showReactions && (
            <View style={styles.reactionsPanel}>
              {CountryMascotData.availableReactions.map((reaction) => (
                <TouchableOpacity
                  key={reaction.id}
                  style={styles.reactionButton}
                  onPress={() => handleReaction(reaction.id)}
                >
                  <Text style={styles.reactionEmoji}>{reaction.emoji}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </SafeAreaView>
      </ImageBackground>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  safeContainer: {
    flex: 1,
    position: 'relative',
    padding: 20,
  },
  closeButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 40 : 20,
    right: 20,
    zIndex: 10,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  flag: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 40 : 20,
    left: 20,
    width: 60,
    height: 40,
    resizeMode: 'contain',
  },
  welcomeTextContainer: {
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginTop: Platform.OS === 'ios' ? 100 : 80,
  },
  welcomeText: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  mascot: {
    alignSelf: 'center',
    width: 200,
    height: 200,
    resizeMode: 'contain',
    marginTop: 20,
  },
  speechBubble: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 20,
    marginHorizontal: 30,
    marginTop: 10,
    position: 'relative',
  },
  speechText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  citySign: {
    alignSelf: 'center',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 30,
    paddingVertical: 8,
    borderRadius: 5,
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#fff',
  },
  cityName: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
  },
  actionsContainer: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 40 : 20,
    right: 20,
    flexDirection: 'row',
  },
  actionButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  reactionsPanel: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 100 : 80,
    right: 20,
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 25,
    padding: 5,
  },
  reactionButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  reactionEmoji: {
    fontSize: 24,
  },
});

export default WelcomeScreen;