import React from 'react';
import { View, Text, Switch, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

/**
 * Renderiza as configurações para o modo Hiking (Trilha)
 * 
 * @param {Object} settings - Configurações atuais do modo Hiking
 * @param {Function} updateSetting - Função para atualizar uma configuração específica
 * @param {Object} styles - Estilos a serem aplicados aos componentes
 * @returns {JSX.Element} Componente com as configurações do modo Hiking
 */
export const renderHikingSettings = (settings, updateSetting, styles) => (
  <View style={styles.settingsContainer}>
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="record-rec" size={20} color="#4CAF50" />
        <Text style={styles.settingLabel}>Gravação de Rota</Text>
      </View>
      <Switch
        value={settings.recordingEnabled}
        onValueChange={(value) => updateSetting('recordingEnabled', value)}
        trackColor={{ false: '#D1D1D1', true: '#A5D6A7' }}
        thumbColor={settings.recordingEnabled ? '#4CAF50' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="pause-circle" size={20} color="#4CAF50" />
        <Text style={styles.settingLabel}>Detectar Paradas</Text>
      </View>
      <Switch
        value={settings.autoDetectStops}
        onValueChange={(value) => updateSetting('autoDetectStops', value)}
        trackColor={{ false: '#D1D1D1', true: '#A5D6A7' }}
        thumbColor={settings.autoDetectStops ? '#4CAF50' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="chart-line" size={20} color="#4CAF50" />
        <Text style={styles.settingLabel}>Mostrar Elevação</Text>
      </View>
      <Switch
        value={settings.showElevation}
        onValueChange={(value) => updateSetting('showElevation', value)}
        trackColor={{ false: '#D1D1D1', true: '#A5D6A7' }}
        thumbColor={settings.showElevation ? '#4CAF50' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Filtro de Dificuldade</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyFilter === 'all' && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => updateSetting('difficultyFilter', 'all')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyFilter === 'all' && styles.optionButtonTextActive
        ]}>Todas</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyFilter === 'easy' && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => updateSetting('difficultyFilter', 'easy')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyFilter === 'easy' && styles.optionButtonTextActive
        ]}>Fáceis</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyFilter === 'moderate' && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => updateSetting('difficultyFilter', 'moderate')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyFilter === 'moderate' && styles.optionButtonTextActive
        ]}>Moderadas</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyFilter === 'hard' && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => updateSetting('difficultyFilter', 'hard')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyFilter === 'hard' && styles.optionButtonTextActive
        ]}>Difíceis</Text>
      </TouchableOpacity>
    </View>
    
    <Text style={styles.settingGroupTitle}>Tipos de Terreno</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.terrainTypes.includes('paved') && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => {
          const terrainTypes = settings.terrainTypes.includes('paved')
            ? settings.terrainTypes.filter(t => t !== 'paved')
            : [...settings.terrainTypes, 'paved'];
          updateSetting('terrainTypes', terrainTypes);
        }}
      >
        <Text style={[
          styles.optionButtonText,
          settings.terrainTypes.includes('paved') && styles.optionButtonTextActive
        ]}>Pavimentado</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.terrainTypes.includes('dirt') && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => {
          const terrainTypes = settings.terrainTypes.includes('dirt')
            ? settings.terrainTypes.filter(t => t !== 'dirt')
            : [...settings.terrainTypes, 'dirt'];
          updateSetting('terrainTypes', terrainTypes);
        }}
      >
        <Text style={[
          styles.optionButtonText,
          settings.terrainTypes.includes('dirt') && styles.optionButtonTextActive
        ]}>Terra</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.terrainTypes.includes('rocky') && styles.optionButtonActive,
          { borderColor: '#4CAF50' }
        ]}
        onPress={() => {
          const terrainTypes = settings.terrainTypes.includes('rocky')
            ? settings.terrainTypes.filter(t => t !== 'rocky')
            : [...settings.terrainTypes, 'rocky'];
          updateSetting('terrainTypes', terrainTypes);
        }}
      >
        <Text style={[
          styles.optionButtonText,
          settings.terrainTypes.includes('rocky') && styles.optionButtonTextActive
        ]}>Rochoso</Text>
      </TouchableOpacity>
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="image-filter-hdr" size={20} color="#4CAF50" />
        <Text style={styles.settingLabel}>Preferir Rotas Cênicas</Text>
      </View>
      <Switch
        value={settings.preferScenic}
        onValueChange={(value) => updateSetting('preferScenic', value)}
        trackColor={{ false: '#D1D1D1', true: '#A5D6A7' }}
        thumbColor={settings.preferScenic ? '#4CAF50' : '#F5F5F5'}
      />
    </View>
  </View>
);

/**
 * Renderiza as configurações para o modo Bike (Bicicleta)
 * 
 * @param {Object} settings - Configurações atuais do modo Bike
 * @param {Function} updateSetting - Função para atualizar uma configuração específica
 * @param {Object} styles - Estilos a serem aplicados aos componentes
 * @returns {JSX.Element} Componente com as configurações do modo Bike
 */
export const renderBikeSettings = (settings, updateSetting, styles) => (
  <View style={styles.settingsContainer}>
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="record-rec" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Gravação de Rota</Text>
      </View>
      <Switch
        value={settings.recordingEnabled}
        onValueChange={(value) => updateSetting('recordingEnabled', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.recordingEnabled ? '#FF9800' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="heart-pulse" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Registrar Freq. Cardíaca</Text>
      </View>
      <Switch
        value={settings.recordHeartRate}
        onValueChange={(value) => updateSetting('recordHeartRate', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.recordHeartRate ? '#FF9800' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Tipo de Bicicleta</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.bikeType === 'mountain' && styles.optionButtonActive,
          { borderColor: '#FF9800' }
        ]}
        onPress={() => updateSetting('bikeType', 'mountain')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.bikeType === 'mountain' && styles.optionButtonTextActive
        ]}>Montanha</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.bikeType === 'road' && styles.optionButtonActive,
          { borderColor: '#FF9800' }
        ]}
        onPress={() => updateSetting('bikeType', 'road')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.bikeType === 'road' && styles.optionButtonTextActive
        ]}>Speed</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.bikeType === 'hybrid' && styles.optionButtonActive,
          { borderColor: '#FF9800' }
        ]}
        onPress={() => updateSetting('bikeType', 'hybrid')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.bikeType === 'hybrid' && styles.optionButtonTextActive
        ]}>Híbrida</Text>
      </TouchableOpacity>
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="bike-fast" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Mostrar Trilhas para Bikes</Text>
      </View>
      <Switch
        value={settings.showBikeTrails}
        onValueChange={(value) => updateSetting('showBikeTrails', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.showBikeTrails ? '#FF9800' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="stairs" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Evitar Escadas</Text>
      </View>
      <Switch
        value={settings.avoidSteps}
        onValueChange={(value) => updateSetting('avoidSteps', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.avoidSteps ? '#FF9800' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="road-variant" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Preferir Vias Pavimentadas</Text>
      </View>
      <Switch
        value={settings.preferPaved}
        onValueChange={(value) => updateSetting('preferPaved', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.preferPaved ? '#FF9800' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="signal-variant" size={20} color="#FF9800" />
        <Text style={styles.settingLabel}>Mostrar Dificuldade</Text>
      </View>
      <Switch
        value={settings.showDifficulty}
        onValueChange={(value) => updateSetting('showDifficulty', value)}
        trackColor={{ false: '#D1D1D1', true: '#FFCC80' }}
        thumbColor={settings.showDifficulty ? '#FF9800' : '#F5F5F5'}
      />
    </View>
  </View>
);