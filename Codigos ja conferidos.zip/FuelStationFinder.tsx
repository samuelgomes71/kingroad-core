import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { getCurrentLocation } from '../utils/locationHelper';
import { calculateDistance } from '../utils/distanceCalculator';

// Tipos básicos
interface FuelStation {
  id: string;
  name: string;
  brand: string;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  };
  prices: {
    diesel: number;
    gasoline: number;
    ethanol: number;
  };
  services: string[];
  rating: number;
  lastUpdate: string;
}

const FuelStationFinder = ({ navigation, route }) => {
  const [stations, setStations] = useState<FuelStation[]>([]);
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<{latitude: number, longitude: number} | null>(null);
  const [selectedFuelType, setSelectedFuelType] = useState('diesel');

  // Mock de dados para exemplo
  const mockStations: FuelStation[] = [
    {
      id: '1',
      name: 'Posto Rodovia',
      brand: 'Petrobras',
      location: {
        latitude: -23.5505,
        longitude: -46.6333,
        address: 'Av. Rodovia Principal, km 123'
      },
      prices: {
        diesel: 4.89,
        gasoline: 5.49,
        ethanol: 3.79
      },
      services: ['restaurant', 'shower', 'wifi', 'parking'],
      rating: 4.2,
      lastUpdate: '2025-03-15T14:30:00Z'
    },
    {
      id: '2',
      name: 'Posto do Caminhoneiro',
      brand: 'Shell',
      location: {
        latitude: -23.5605,
        longitude: -46.6433,
        address: 'Rodovia Estadual, km 45'
      },
      prices: {
        diesel: 4.75,
        gasoline: 5.59,
        ethanol: 3.89
      },
      services: ['restaurant', 'shower', 'wifi', 'parking', 'mechanic'],
      rating: 4.5,
      lastUpdate: '2025-03-17T10:15:00Z'
    },
  ];

  useEffect(() => {
    // Carregar localização do usuário
    const loadLocation = async () => {
      try {
        const location = await getCurrentLocation();
        setUserLocation(location);
        
        // Em um app real, aqui faríamos a chamada à API
        // Usando mock para exemplo
        setStations(mockStations);
        setLoading(false);
      } catch (error) {
        console.error('Erro ao obter localização:', error);
        // Mesmo sem a localização, mostrar dados de exemplo
        setStations(mockStations);
        setLoading(false);
      }
    };
    
    loadLocation();
  }, []);

  // Função para calcular distância até o posto
  const getDistance = (station) => {
    if (!userLocation) return '-- km';
    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      station.location.latitude,
      station.location.longitude
    );
    return `${distance.toFixed(1)} km`;
  };

  // Renderizar cada item da lista
  const renderStationItem = ({ item }) => (
    <TouchableOpacity
      style={styles.stationCard}
      onPress={() => navigation.navigate('StationDetails', { stationId: item.id })}
    >
      <View style={styles.stationHeader}>
        <View>
          <Text style={styles.stationName}>{item.name}</Text>
          <Text style={styles.stationBrand}>{item.brand}</Text>
        </View>
        <View style={styles.distanceContainer}>
          <Icon name="map-marker-distance" size={16} color="#666" />
          <Text style={styles.distanceText}>{getDistance(item)}</Text>
        </View>
      </View>
      
      <View style={styles.priceContainer}>
        <View style={styles.priceBox}>
          <Text style={styles.priceLabel}>Diesel</Text>
          <Text style={[
            styles.priceValue,
            selectedFuelType === 'diesel' && styles.highlightedPrice
          ]}>
            R$ {item.prices.diesel.toFixed(2)}
          </Text>
        </View>
        
        <View style={styles.priceBox}>
          <Text style={styles.priceLabel}>Gasolina</Text>
          <Text style={[
            styles.priceValue,
            selectedFuelType === 'gasoline' && styles.highlightedPrice
          ]}>
            R$ {item.prices.gasoline.toFixed(2)}
          </Text>
        </View>
        
        <View style={styles.priceBox}>
          <Text style={styles.priceLabel}>Etanol</Text>
          <Text style={[
            styles.priceValue,
            selectedFuelType === 'ethanol' && styles.highlightedPrice
          ]}>
            R$ {item.prices.ethanol.toFixed(2)}
          </Text>
        </View>
      </View>
      
      <View style={styles.servicesContainer}>
        {item.services.includes('restaurant') && (
          <Icon name="food" size={20} color="#666" style={styles.serviceIcon} />
        )}
        {item.services.includes('shower') && (
          <Icon name="shower" size={20} color="#666" style={styles.serviceIcon} />
        )}
        {item.services.includes('wifi') && (
          <Icon name="wifi" size={20} color="#666" style={styles.serviceIcon} />
        )}
        {item.services.includes('parking') && (
          <Icon name="parking" size={20} color="#666" style={styles.serviceIcon} />
        )}
        {item.services.includes('mechanic') && (
          <Icon name="tools" size={20} color="#666" style={styles.serviceIcon} />
        )}
      </View>
      
      <View style={styles.footer}>
        <View style={styles.ratingContainer}>
          <Icon name="star" size={16} color="#FFD700" />
          <Text style={styles.ratingText}>{item.rating.toFixed(1)}</Text>
        </View>
        
        <Text style={styles.updateText}>
          Atualizado: {new Date(item.lastUpdate).toLocaleDateString()}
        </Text>
      </View>
    </TouchableOpacity>
  );

  // Filtros para tipos de combustível
  const renderFuelTypeFilters = () => (
    <View style={styles.filterContainer}>
      <TouchableOpacity
        style={[
          styles.filterButton,
          selectedFuelType === 'diesel' && styles.selectedFilter
        ]}
        onPress={() => setSelectedFuelType('diesel')}
      >
        <Text style={[
          styles.filterText,
          selectedFuelType === 'diesel' && styles.selectedFilterText
        ]}>
          Diesel
        </Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.filterButton,
          selectedFuelType === 'gasoline' && styles.selectedFilter
        ]}
        onPress={() => setSelectedFuelType('gasoline')}
      >
        <Text style={[
          styles.filterText,
          selectedFuelType === 'gasoline' && styles.selectedFilterText
        ]}>
          Gasolina
        </Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.filterButton,
          selectedFuelType === 'ethanol' && styles.selectedFilter
        ]}
        onPress={() => setSelectedFuelType('ethanol')}
      >
        <Text style={[
          styles.filterText,
          selectedFuelType === 'ethanol' && styles.selectedFilterText
        ]}>
          Etanol
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Postos de Combustível</Text>
        <TouchableOpacity onPress={() => navigation.navigate('FuelSavingsCalculator')}>
          <Icon name="calculator" size={24} color="#333" />
        </TouchableOpacity>
      </View>
      
      {renderFuelTypeFilters()}
      
      {loading ? (
        <View style={styles.loaderContainer}>
          <Text>Carregando postos próximos...</Text>
        </View>
      ) : (
        <FlatList
          data={stations.sort((a, b) => 
            a.prices[selectedFuelType] - b.prices[selectedFuelType]
          )}
          renderItem={renderStationItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
        />
      )}
      
      <TouchableOpacity 
        style={styles.reportPriceButton}
        onPress={() => navigation.navigate('ReportFuelPrice')}
      >
        <Icon name="gas-station" size={20} color="#fff" />
        <Text style={styles.reportButtonText}>Reportar Preço</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  filterContainer: {
    flexDirection: 'row',
    padding: 8,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  filterButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 8,
    backgroundColor: '#f0f0f0',
  },
  selectedFilter: {
    backgroundColor: '#2196F3',
  },
  filterText: {
    color: '#666',
  },
  selectedFilterText: {
    color: '#fff',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    padding: 8,
  },
  stationCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  stationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  stationName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  stationBrand: {
    fontSize: 14,
    color: '#666',
  },
  distanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  distanceText: {
    marginLeft: 4,
    color: '#666',
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  priceBox: {
    alignItems: 'center',
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: '#666',
  },
  priceValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  highlightedPrice: {
    color: '#2196F3',
  },
  servicesContainer: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  serviceIcon: {
    marginRight: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    marginLeft: 4,
    fontWeight: 'bold',
  },
  updateText: {
    fontSize: 12,
    color: '#999',
  },
  reportPriceButton: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    backgroundColor: '#2196F3',
    borderRadius: 24,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    elevation: 4,
  },
  reportButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8,
  },
});

export default FuelStationFinder;