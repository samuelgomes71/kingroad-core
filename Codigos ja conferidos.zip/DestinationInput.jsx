import React, { useState } from 'react';
import { Search, Clock, Star, MapPin, Navigation, Settings, ChevronDown } from 'lucide-react';

const DestinationInput = () => {
  const [selectedInputType, setSelectedInputType] = useState('address');
  const [showRecentLocations, setShowRecentLocations] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  
  return (
    <div className="h-screen bg-[#121212]">
      {/* Barra superior */}
      <div className="bg-[#1E1E1E] p-4">
        <h1 className="text-white text-xl font-bold mb-4">Planejar Rota</h1>
        
        {/* Campos de origem e destino */}
        <div className="space-y-4">
          {/* Campo de origem */}
          <div className="relative">
            <div className="absolute left-3 top-1/2 -translate-y-1/2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            </div>
            <input
              type="text"
              placeholder="Ponto de partida"
              className="w-full bg-[#252525] text-gray-200 pl-10 pr-4 py-3 rounded-lg"
            />
          </div>

          {/* Campo de destino */}
          <div className="relative">
            <div className="absolute left-3 top-1/2 -translate-y-1/2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            </div>
            <input
              type="text"
              placeholder="Digite o destino"
              className="w-full bg-[#252525] text-gray-200 pl-10 pr-4 py-3 rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* Seletor de tipo de entrada */}
      <div className="p-4 bg-[#252525]">
        <div className="flex space-x-2 overflow-x-auto">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg whitespace-nowrap">
            Endereço
          </button>
          <button className="px-4 py-2 bg-[#1E1E1E] text-gray-300 rounded-lg whitespace-nowrap">
            CEP/Código Postal
          </button>
          <button className="px-4 py-2 bg-[#1E1E1E] text-gray-300 rounded-lg whitespace-nowrap">
            Coordenadas
          </button>
          <button className="px-4 py-2 bg-[#1E1E1E] text-gray-300 rounded-lg whitespace-nowrap">
            Favoritos
          </button>
        </div>
      </div>

      {/* Área de conteúdo principal */}
      <div className="p-4">
        {/* Destinos recentes */}
        <div className="mb-6">
          <div 
            className="flex items-center justify-between mb-2"
            onClick={() => setShowRecentLocations(!showRecentLocations)}
          >
            <div className="flex items-center text-gray-200">
              <Clock size={20} className="mr-2" />
              <span>Destinos Recentes</span>
            </div>
            <ChevronDown size={20} className="text-gray-400" />
          </div>

          {showRecentLocations && (
            <div className="space-y-2">
              <div className="bg-[#1E1E1E] p-3 rounded-lg">
                <div className="text-gray-200">São Paulo → Rio de Janeiro</div>
                <div className="text-sm text-gray-400">1.234 km - 14h30min</div>
              </div>
              <div className="bg-[#1E1E1E] p-3 rounded-lg">
                <div className="text-gray-200">Curitiba → Florianópolis</div>
                <div className="text-sm text-gray-400">567 km - 7h15min</div>
              </div>
            </div>
          )}
        </div>

        {/* Favoritos */}
        <div>
          <div 
            className="flex items-center justify-between mb-2"
            onClick={() => setShowFavorites(!showFavorites)}
          >
            <div className="flex items-center text-gray-200">
              <Star size={20} className="mr-2" />
              <span>Favoritos</span>
            </div>
            <ChevronDown size={20} className="text-gray-400" />
          </div>

          {showFavorites && (
            <div className="space-y-2">
              <div className="bg-[#1E1E1E] p-3 rounded-lg">
                <div className="text-gray-200">Base SP</div>
                <div className="text-sm text-gray-400">Rua Example, 123 - São Paulo</div>
              </div>
              <div className="bg-[#1E1E1E] p-3 rounded-lg">
                <div className="text-gray-200">Cliente RJ</div>
                <div className="text-sm text-gray-400">Av. Principal, 456 - Rio de Janeiro</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Resultados da rota (quando calculada) */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#1E1E1E] p-4">
        <div className="bg-[#252525] p-4 rounded-lg mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-200 font-bold">Melhor Rota</span>
            <span className="text-blue-400">14h 30min</span>
          </div>
          <div className="text-gray-400">1.234 km via BR-116</div>
          <div className="mt-2 text-sm text-gray-500">
            Pedágios: R$ 123,45 | 3 paradas sugeridas
          </div>
        </div>

        <button className="w-full bg-blue-600 text-white p-4 rounded-lg flex items-center justify-center">
          <Navigation size={20} className="mr-2" />
          Iniciar Navegação
        </button>
      </div>
    </div>
  );
};

export default DestinationInput;