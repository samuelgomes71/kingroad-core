import { useState } from "react";

const AppLogo = ({ onDeveloperMode }) => {
  const [clickCount, setClickCount] = useState(0);

  const handleClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);

    if (newCount >= 5) {
      onDeveloperMode(); // Ativa o modo desenvolvedor
      setClickCount(0); // Reseta o contador
    }

    setTimeout(() => setClickCount(0), 2000); // Reseta após 2 segundos sem cliques
  };

  return (
    <div className="absolute top-5 left-5">
      <img
        src="/assets/logo.png" // Caminho do logo oval vertical
        alt="King Road Logo"
        className="w-20 h-24 cursor-pointer"
        onClick={handleClick}
      />
    </div>
  );
};

export default AppLogo;
