import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, DollarSign, Star, Phone, MapPin, Calendar, Users, ThumbsUp, ThumbsDown, ChevronLeft, ChevronRight, Truck, Car, Droplet, Shield } from 'lucide-react';

// Componente principal de visualização detalhada
const VehicleWashDetailsView = ({ poiId, vehicleMode = 'truck', onBack }) => {
  // Estados
  const [poi, setPoi] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('info');
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  
  // Efeito para carregar os dados do POI
  useEffect(() => {
    setLoading(true);
    
    // Simulação de carregamento de dados
    setTimeout(() => {
      if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
        setPoi(mockTruckWasherDetails);
      } else {
        setPoi(mockCarWasherDetails);
      }
      setLoading(false);
    }, 1000);
  }, [poiId, vehicleMode]);
  
  // Manipulação da navegação de imagens
  const nextImage = () => {
    setSelectedImageIndex((prevIndex) => 
      prevIndex === (poi?.images.length - 1) ? 0 : prevIndex + 1
    );
  };
  
  const prevImage = () => {
    setSelectedImageIndex((prevIndex) => 
      prevIndex === 0 ? poi?.images.length - 1 : prevIndex - 1
    );
  };
  
  // Renderiza o ícone apropriado para o tipo de veículo
  const renderVehicleIcon = () => {
    if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
      return <Truck className="mr-2" size={24} />;
    }
    return <Car className="mr-2" size={24} />;
  };

  // Componente para o carregamento
  if (loading) {
    return (
      <div className="w-full max-w-4xl bg-gray-900 text-white rounded-lg shadow-lg p-6 flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-400"></div>
      </div>
    );
  }
  
  // Componente para erro de carregamento
  if (!poi) {
    return (
      <div className="w-full max-w-4xl bg-gray-900 text-white rounded-lg shadow-lg p-6">
        <button onClick={onBack} className="flex items-center text-amber-400 hover:text-amber-300 mb-6">
          <ArrowLeft size={20} className="mr-2" />
          <span>Voltar</span>
        </button>
        <div className="text-center py-12">
          <Shield size={64} className="mx-auto mb-4 text-gray-500" />
          <h3 className="text-xl font-bold text-amber-400 mb-2">Informações não disponíveis</h3>
          <p className="text-gray-400">Não foi possível carregar os detalhes deste local.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl bg-gray-900 text-white rounded-lg shadow-lg p-6">
      {/* Cabeçalho com botão de voltar */}
      <div className="flex justify-between items-center mb-6">
        <button onClick={onBack} className="flex items-center text-amber-400 hover:text-amber-300">
          <ArrowLeft size={20} className="mr-2" />
          <span>Voltar</span>
        </button>
        
        <div className="flex items-center">
          {renderVehicleIcon()}
          <h2 className="text-xl font-bold text-amber-400">{vehicleMode === 'truck' ? "Truck Washer" : "Car Wash"}</h2>
        </div>
      </div>
      
      {/* Informações básicas */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">{poi.name}</h1>
        <div className="flex items-center mb-4">
          <div className="flex items-center bg-amber-500 text-black font-bold px-2 py-1 rounded mr-3">
            <Star size={16} className="mr-1" />
            <span>{poi.rating.toFixed(1)}</span>
          </div>
          <span className="text-gray-400">{poi.reviewCount} avaliações</span>
        </div>
        
        <div className="flex items-center text-gray-400 mb-2">
          <MapPin size={16} className="mr-2 text-amber-400" />
          <span>{poi.fullAddress}</span>
        </div>
        
        <div className="flex items-center text-gray-400">
          <Phone size={16} className="mr-2 text-amber-400" />
          <span>{poi.phone}</span>
        </div>
      </div>
      
      {/* Galeria de imagens */}
      <div className="relative mb-6 h-64 bg-gray-800 rounded-lg overflow-hidden">
        <img 
          src={`/api/placeholder/800/400?text=${encodeURIComponent(poi.images[selectedImageIndex].alt)}`} 
          alt={poi.images[selectedImageIndex].alt} 
          className="w-full h-full object-cover"
        />
        
        {poi.images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 rounded-full p-2 transition-colors"
            >
              <ChevronLeft size={24} className="text-white" />
            </button>
            
            <button 
              onClick={nextImage}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 rounded-full p-2 transition-colors"
            >
              <ChevronRight size={24} className="text-white" />
            </button>
            
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
              {poi.images.map((_, index) => (
                <div 
                  key={index} 
                  className={`w-2 h-2 rounded-full ${selectedImageIndex === index ? 'bg-amber-400' : 'bg-gray-400'}`}
                />
              ))}
            </div>
          </>
        )}
      </div>
      
      {/* Abas para Informações e Avaliações */}
      <div className="mb-6">
        <div className="flex border-b border-gray-700">
          <button 
            className={`py-2 px-4 font-medium ${activeTab === 'info' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-gray-400 hover:text-gray-200'}`}
            onClick={() => setActiveTab('info')}
          >
            Informações
          </button>
          
          <button 
            className={`py-2 px-4 font-medium ${activeTab === 'reviews' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-gray-400 hover:text-gray-200'}`}
            onClick={() => setActiveTab('reviews')}
          >
            Avaliações
          </button>
        </div>
      </div>
      
      {/* Conteúdo da aba ativa */}
      <div>
        {activeTab === 'info' ? (
          <InfoTab poi={poi} vehicleMode={vehicleMode} />
        ) : (
          <ReviewsTab reviews={poi.reviews} />
        )}
      </div>
    </div>
  );
};

// Componente para a aba de informações
const InfoTab = ({ poi, vehicleMode }) => {
  return (
    <div>
      {/* Horários de funcionamento */}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-amber-400 mb-3">Horários de Funcionamento</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {poi.operatingHours.map(day => (
            <div key={day.day} className="flex justify-between p-2 bg-gray-800 rounded">
              <span className="font-medium">{day.day}</span>
              <span>{day.hours}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Tabela de preços */}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-amber-400 mb-3">Tabela de Preços</h3>
        <div className="bg-gray-800 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-700">
                <th className="py-2 px-4 text-left">Serviço</th>
                <th className="py-2 px-4 text-right">Preço</th>
              </tr>
            </thead>
            <tbody>
              {poi.prices.map((price, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-gray-800' : 'bg-gray-750'}>
                  <td className="py-2 px-4">{price.service}</td>
                  <td className="py-2 px-4 text-right">{poi.currency} {price.amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-gray-400 mt-2">* Preços sujeitos a alterações. Para veículos especiais, consulte no local.</p>
      </div>
      
      {/* Informações adicionais */}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-amber-400 mb-3">Informações Adicionais</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Serviços Disponíveis</h4>
            <ul className="space-y-1">
              {poi.services.map((service, index) => (
                <li key={index} className="flex items-center">
                  <Droplet size={16} className="mr-2 text-amber-400" />
                  <span>{service}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Comodidades</h4>
            <ul className="space-y-1">
              {poi.amenities.map((amenity, index) => (
                <li key={index} className="flex items-center">
                  <ThumbsUp size={16} className="mr-2 text-amber-400" />
                  <span>{amenity}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      
      {/* Informações específicas para caminhões */}
      {(vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') && (
        <div className="mb-6">
          <h3 className="text-lg font-bold text-amber-400 mb-3">Informações para Veículos Grandes</h3>
          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium mb-2">Tipos de Veículos Aceitos</h4>
                <div className="flex flex-wrap gap-2">
                  {poi.truckInfo.acceptedVehicles.map((vehicle, index) => (
                    <span key={index} className="bg-gray-700 text-sm px-3 py-1 rounded-full">{vehicle}</span>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Dimensões Máximas</h4>
                <ul className="space-y-1 text-sm">
                  <li><strong>Altura:</strong> {poi.truckInfo.maxHeight} metros</li>
                  <li><strong>Comprimento:</strong> {poi.truckInfo.maxLength} metros</li>
                  <li><strong>Peso:</strong> {poi.truckInfo.maxWeight} toneladas</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Botões de ação */}
      <div className="flex justify-between mt-8">
        <button className="text-amber-400 hover:text-amber-300 border border-amber-400 hover:border-amber-300 font-medium py-2 px-4 rounded transition-colors">
          <Star size={16} className="inline mr-2" />
          <span>Adicionar aos Favoritos</span>
        </button>
        
        <button className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-6 rounded transition-colors">
          Traçar Rota
        </button>
      </div>
    </div>
  );
};

// Componente para a aba de avaliações
const ReviewsTab = ({ reviews }) => {
  // Calcula a distribuição de estrelas
  const starDistribution = [5, 4, 3, 2, 1].map(stars => {
    const count = reviews.filter(review => Math.floor(review.rating) === stars).length;
    const percentage = (count / reviews.length) * 100;
    return { stars, count, percentage };
  });
  
  return (
    <div>
      {/* Resumo das avaliações */}
      <div className="mb-6 bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-bold text-amber-400 mb-3">Resumo das Avaliações</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            {starDistribution.map(item => (
              <div key={item.stars} className="flex items-center mb-2">
                <div className="w-16 text-right mr-4">
                  <span className="font-medium">{item.stars} </span>
                  <Star size={14} className="inline text-amber-400" />
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-amber-400 h-3 rounded-full" 
                    style={{ width: `${item.percentage}%` }}
                  ></div>
                </div>
                <div className="w-12 text-right ml-4 text-sm text-gray-400">
                  {item.count}
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex items-center justify-center flex-col">
            <div className="text-4xl font-bold text-amber-400 mb-2">
              {(reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)}
            </div>
            <div className="flex mb-1">
              {[1, 2, 3, 4, 5].map(i => (
                <Star 
                  key={i} 
                  size={20} 
                  className={i <= Math.round(reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length) ? "text-amber-400" : "text-gray-600"} 
                />
              ))}
            </div>
            <div className="text-sm text-gray-400">
              {reviews.length} avaliações
            </div>
          </div>
        </div>
      </div>
      
      {/* Lista de avaliações */}
      <div>
        <h3 className="text-lg font-bold text-amber-400 mb-3">Avaliações dos Usuários</h3>
        
        <div className="space-y-4">
          {reviews.map((review, index) => (
            <div key={index} className="bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium">{review.userName}</h4>
                  <div className="flex items-center text-sm text-gray-400">
                    <Calendar size={14} className="mr-1" />
                    <span>{review.date}</span>
                    {review.vehicleType && (
                      <>
                        <span className="mx-2">•</span>
                        <Truck size={14} className="mr-1" />
                        <span>{review.vehicleType}</span>
                      </>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center bg-amber-500 text-black font-bold px-2 py-1 rounded">
                  <Star size={14} className="mr-1" />
                  <span>{review.rating.toFixed(1)}</span>
                </div>
              </div>
              
              <p className="text-gray-300">{review.comment}</p>
              
              <div className="mt-3 flex items-center text-sm text-gray-400">
                <button className="flex items-center mr-4 hover:text-amber-400">
                  <ThumbsUp size={14} className="mr-1" />
                  <span>{review.helpful} útil</span>
                </button>
                
                <button className="flex items-center hover:text-amber-400">
                  <ThumbsDown size={14} className="mr-1" />
                  <span>Não útil</span>
                </button>
              </div>
            </div>
          ))}
        </div>
        
        {/* Botão para adicionar avaliação */}
        <div className="mt-6 text-center">
          <button className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-6 rounded transition-colors">
            Adicionar Avaliação
          </button>
        </div>
      </div>
    </div>
  );
};

// Dados mockados para visualização detalhada de um Truck Washer
const mockTruckWasherDetails = {
  id: 'tw1',
  name: 'Blue Beacon Truck Wash',
  fullAddress: 'BR-116, km 432, Curitiba - PR',
  phone: '+55 41 3333-4444',
  rating: 4.7,
  reviewCount: 128,
  basePrice: 120,
  currency: 'R$',
  waitTime: 30,
  chain: 'BLUE_BEACON',
  isOpen: true,
  
  // Imagens
  images: [
    { url: 'truck_wash_1.jpg', alt: 'Blue Beacon - Área externa' },
    { url: 'truck_wash_2.jpg', alt: 'Blue Beacon - Área de lavagem' },
    { url: 'truck_wash_3.jpg', alt: 'Blue Beacon - Equipamentos' }
  ],
  
  // Horários
  operatingHours: [
    { day: 'Segunda-feira', hours: '07:00 - 22:00' },
    { day: 'Terça-feira', hours: '07:00 - 22:00' },
    { day: 'Quarta-feira', hours: '07:00 - 22:00' },
    { day: 'Quinta-feira', hours: '07:00 - 22:00' },
    { day: 'Sexta-feira', hours: '07:00 - 23:00' },
    { day: 'Sábado', hours: '08:00 - 23:00' },
    { day: 'Domingo', hours: '08:00 - 20:00' }
  ],
  
  // Preços
  prices: [
    { service: 'Lavagem básica', amount: 120 },
    { service: 'Lavagem completa (exterior)', amount: 180 },
    { service: 'Lavagem + chassis', amount: 220 },
    { service: 'Lavagem completa + interior', amount: 280 },
    { service: 'Polimento', amount: 350 },
    { service: 'Lavagem de motor', amount: 150 }
  ],
  
  // Serviços disponíveis
  services: [
    'Lavagem externa automática',
    'Lavagem manual',
    'Polimento',
    'Limpeza de chassis',
    'Limpeza de motor',
    'Limpeza de tanques',
    'Tratamento de cabine'
  ],
  
  // Comodidades
  amenities: [
    'Sala de espera com Wi-Fi',
    'Café gratuito',
    'Estacionamento amplo',
    'Lanchonete',
    'Chuveiros para motoristas',
    'Área de descanso'
  ],
  
  // Informações para caminhões
  truckInfo: {
    acceptedVehicles: ['Caminhão Pequeno', 'Caminhão Médio', 'Carreta', 'Bitrem', 'Ônibus', 'Motorhome'],
    maxHeight: 4.5,
    maxLength: 30,
    maxWeight: 60
  },
  
  // Avaliações
  reviews: [
    {
      userName: 'Carlos Silva',
      date: '15/02/2025',
      rating: 5.0,
      comment: 'Excelente serviço! Lavagem rápida e eficiente. A equipe é muito atenciosa e cuidadosa com os veículos.',
      vehicleType: 'Carreta',
      helpful: 12
    },
    {
      userName: 'Roberto Almeida',
      date: '03/02/2025',
      rating: 4.5,
      comment: 'Ótimo atendimento e preço justo. A lavagem do chassis ficou perfeita. Único ponto negativo é o tempo de espera em horários de pico.',
      vehicleType: 'Caminhão Médio',
      helpful: 8
    },
    {
      userName: 'Ana Paula Costa',
      date: '28/01/2025',
      rating: 4.0,
      comment: 'Bom custo-benefício. A sala de espera é confortável e tem um bom café. A lavagem foi bem feita, mas faltou um pouco de capricho em alguns detalhes.',
      vehicleType: 'Ônibus',
      helpful: 3
    },
    {
      userName: 'Marcos Oliveira',
      date: '15/01/2025',
      rating: 3.5,
      comment: 'Serviço OK, mas o preço está um pouco acima da média da região. Poderiam melhorar os produtos utilizados na lavagem.',
      vehicleType: 'Bitrem',
      helpful: 5
    }
  ]
};

// Dados mockados para visualização detalhada de um Car Wash
const mockCarWasherDetails = {
  id: 'cw1',
  name: 'Lava Rápido Auto Shine',
  fullAddress: 'Av. Paulista, 1578, São Paulo - SP',
  phone: '+55 11 3333-4444',
  rating: 4.8,
  reviewCount: 246,
  basePrice: 40,
  currency: 'R$',
  waitTime: 20,
  isOpen: true,
  
  // Imagens
  images: [
    { url: 'car_wash_1.jpg', alt: 'Auto Shine - Fachada' },
    { url: 'car_wash_2.jpg', alt: 'Auto Shine - Área de lavagem' },
    { url: 'car_wash_3.jpg', alt: 'Auto Shine - Secagem' }
  ],
  
  // Horários
  operatingHours: [
    { day: 'Segunda-feira', hours: '08:00 - 20:00' },
    { day: 'Terça-feira', hours: '08:00 - 20:00' },
    { day: 'Quarta-feira', hours: '08:00 - 20:00' },
    { day: 'Quinta-feira', hours: '08:00 - 20:00' },
    { day: 'Sexta-feira', hours: '08:00 - 21:00' },
    { day: 'Sábado', hours: '08:00 - 21:00' },
    { day: 'Domingo', hours: '09:00 - 18:00' }
  ],
  
  // Preços
  prices: [
    { service: 'Lavagem simples', amount: 40 },
    { service: 'Lavagem com cera', amount: 60 },
    { service: 'Lavagem completa (int/ext)', amount: 80 },
    { service: 'Lavagem + polimento', amount: 120 },
    { service: 'Lavagem de motor', amount: 50 },
    { service: 'Higienização interna', amount: 180 }
  ],
  
  // Serviços disponíveis
  services: [
    'Lavagem externa',
    'Lavagem interna',
    'Aplicação de cera',
    'Polimento',
    'Cristalização',
    'Limpeza de motor',
    'Higienização'
  ],
  
  // Comodidades
  amenities: [
    'Wi-Fi gratuito',
    'Café expresso',
    'Televisão',
    'Espaço de trabalho',
    'Ar-condicionado'
  ],
  
  // Avaliações
  reviews: [
    {
      userName: 'Mariana Santos',
      date: '25/02/2025',
      rating: 5.0,
      comment: 'Serviço impecável! Meu carro ficou como novo. Adorei o cuidado com os detalhes e a rapidez do atendimento.',
      vehicleType: 'SUV',
      helpful: 15
    },
    {
      userName: 'Thiago Mendes',
      date: '18/02/2025',
      rating: 4.5,
      comment: 'Excelente lavagem e o acabamento é perfeito. A equipe é muito profissional. Recomendo!',
      vehicleType: 'Sedan',
      helpful: 7
    },
    {
      userName: 'Patricia Lima',
      date: '10/02/2025',
      rating: 5.0,
      comment: 'Melhor lava-rápido da região! Sempre trago meu carro aqui e nunca me decepcionou. O café espresso é um diferencial.',
      vehicleType: 'Hatch',
      helpful: 10
    },
    {
      userName: 'Ricardo Gomes',
      date: '02/02/2025',
      rating: 4.0,
      comment: 'Bom serviço, mas o preço está um pouco alto comparado com outros lugares. A qualidade compensa, porém.',
      vehicleType: 'Picape',
      helpful: 3
    }
  ]
};

export default VehicleWashDetailsView;