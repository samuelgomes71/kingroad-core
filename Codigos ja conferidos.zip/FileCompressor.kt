package com.kingroad.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.util.Size
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Classe utilitária para compressão de arquivos de imagem e vídeo antes de
 * anexar a relatórios ou enviar para o servidor.
 *
 * Funcionalidades:
 * - Compressão inteligente de imagens (mantendo aspecto e exif)
 * - Redimensionamento de imagens para tamanhos específicos
 * - Compressão de vídeos para upload
 * - Extração de thumbs de vídeos
 * - Otimização do tamanho de acordo com o contexto de uso
 */
class FileCompressor(private val context: Context) {

    companion object {
        private const val TAG = "FileCompressor"
        
        // Tamanhos pré-definidos para imagens
        enum class ImageSize(val maxWidth: Int, val maxHeight: Int, val quality: Int) {
            THUMBNAIL(300, 300, 75),           // Para miniaturas em listas
            MEDIUM(800, 800, 85),              // Para exibição na interface
            REPORT(1024, 1024, 85),            // Para relatórios e feedbacks
            HIGH(1600, 1600, 90),              // Para visualização detalhada
            ORIGINAL(-1, -1, 100)              // Manter tamanho original (apenas compress)
        }
        
        // Tipos de comprssão para vídeos
        enum class VideoCompression {
            LOW,       // Qualidade baixa, menor tamanho
            MEDIUM,    // Qualidade média, tamanho moderado
            HIGH       // Qualidade alta, maior tamanho
        }
    }

    /**
     * Comprime uma imagem a partir de um arquivo
     * 
     * @param imageFile Arquivo de imagem a ser comprimido
     * @param targetSize Tamanho alvo para compressão
     * @param outputDir Diretório para salvar o resultado (opcional)
     * @param outputFileName Nome do arquivo resultante (opcional)
     * @return Arquivo comprimido ou null em caso de falha
     */
    suspend fun compressImage(
        imageFile: File,
        targetSize: ImageSize = ImageSize.MEDIUM,
        outputDir: File? = null,
        outputFileName: String? = null
    ): File? = withContext(Dispatchers.IO) {
        try {
            // Verificar se o arquivo existe e é uma imagem
            if (!imageFile.exists() || !isImageFile(imageFile)) {
                Log.e(TAG, "Arquivo inválido ou não é uma imagem: ${imageFile.absolutePath}")
                return@withContext null
            }
            
            // Definir diretório de saída
            val destination = outputDir ?: getCacheDirectory()
            if (!destination.exists()) {
                destination.mkdirs()
            }
            
            // Definir nome do arquivo de saída
            val outFileName = outputFileName ?: generateOutputFileName(imageFile.name, "compressed")
            val outputFile = File(destination, outFileName)
            
            // Ler orientação EXIF da imagem original
            val exifRotation = getExifRotation(imageFile.absolutePath)
            
            // Comprimir e redimensionar
            return@withContext compressBitmap(
                imageFile.absolutePath,
                outputFile.absolutePath,
                targetSize.maxWidth,
                targetSize.maxHeight,
                targetSize.quality,
                exifRotation
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao comprimir imagem: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Comprime uma imagem a partir de um Uri
     * 
     * @param imageUri Uri da imagem a ser comprimida
     * @param targetSize Tamanho alvo para compressão
     * @param outputDir Diretório para salvar o resultado (opcional)
     * @param outputFileName Nome do arquivo resultante (opcional)
     * @return Arquivo comprimido ou null em caso de falha
     */
    suspend fun compressImageFromUri(
        imageUri: Uri,
        targetSize: ImageSize = ImageSize.MEDIUM,
        outputDir: File? = null,
        outputFileName: String? = null
    ): File? = withContext(Dispatchers.IO) {
        try {
            // Definir diretório de saída
            val destination = outputDir ?: getCacheDirectory()
            if (!destination.exists()) {
                destination.mkdirs()
            }
            
            // Definir nome do arquivo de saída
            val uriPath = imageUri.path ?: "image"
            val originalName = uriPath.substring(uriPath.lastIndexOf("/") + 1)
            val outFileName = outputFileName ?: generateOutputFileName(originalName, "compressed")
            val outputFile = File(destination, outFileName)
            
            // Obter InputStream do Uri
            val inputStream = context.contentResolver.openInputStream(imageUri)
                ?: throw IOException("Não foi possível abrir o stream de entrada para $imageUri")
            
            // Decodificar apenas as dimensões primeiro para otimizar memória
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()
            
            // Calcular o fator de escala
            val width = options.outWidth
            val height = options.outHeight
            var scale = 1
            
            if (targetSize.maxWidth > 0 && targetSize.maxHeight > 0) {
                // Calcular maior escala possível para caber nas dimensões máximas
                scale = max(
                    width / targetSize.maxWidth,
                    height / targetSize.maxHeight
                ).coerceAtLeast(1)
            }
            
            // Decodificar a bitmap com escala
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = scale
                inJustDecodeBounds = false
            }
            
            val inputStream2 = context.contentResolver.openInputStream(imageUri)
                ?: throw IOException("Não foi possível abrir o segundo stream de entrada")
            
            val bitmap = BitmapFactory.decodeStream(inputStream2, null, decodeOptions)
            inputStream2.close()
            
            if (bitmap == null) {
                Log.e(TAG, "Falha ao decodificar bitmap de $imageUri")
                return@withContext null
            }
            
            // Rotacionar imagem se necessário
            var rotatedBitmap = bitmap
            
            try {
                // Tentar obter a orientação EXIF para Uris de arquivo
                if (imageUri.scheme == "file" || imageUri.scheme == "content") {
                    val pathForExif = if (imageUri.scheme == "content") {
                        val cursor = context.contentResolver.query(imageUri, null, null, null, null)
                        if (cursor != null) {
                            cursor.moveToFirst()
                            val columnIndex = cursor.getColumnIndex("_data")
                            val filePath = if (columnIndex >= 0) cursor.getString(columnIndex) else null
                            cursor.close()
                            filePath
                        } else null
                    } else {
                        imageUri.path
                    }
                    
                    if (pathForExif != null) {
                        val rotation = getExifRotation(pathForExif)
                        if (rotation != 0) {
                            val matrix = Matrix()
                            matrix.postRotate(rotation.toFloat())
                            rotatedBitmap = Bitmap.createBitmap(
                                bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
                            )
                            if (rotatedBitmap != bitmap) {
                                bitmap.recycle()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Não foi possível aplicar a rotação EXIF: ${e.message}")
                // Continuar com a bitmap original
            }
            
            // Redimensionar a bitmap mantendo a proporção
            val finalBitmap = if (targetSize.maxWidth > 0 && targetSize.maxHeight > 0 &&
                    (rotatedBitmap.width > targetSize.maxWidth || rotatedBitmap.height > targetSize.maxHeight)) {
                
                val ratioWidth = targetSize.maxWidth.toFloat() / rotatedBitmap.width
                val ratioHeight = targetSize.maxHeight.toFloat() / rotatedBitmap.height
                val ratio = min(ratioWidth, ratioHeight)
                
                val newWidth = (rotatedBitmap.width * ratio).roundToInt()
                val newHeight = (rotatedBitmap.height * ratio).roundToInt()
                
                Bitmap.createScaledBitmap(rotatedBitmap, newWidth, newHeight, true)
            } else {
                rotatedBitmap
            }
            
            // Salvar a bitmap comprimida para o arquivo de saída
            val out = FileOutputStream(outputFile)
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, targetSize.quality, out)
            out.flush()
            out.close()
            
            // Limpar memória
            if (finalBitmap != rotatedBitmap) {
                rotatedBitmap.recycle()
            }
            if (finalBitmap != bitmap) {
                finalBitmap.recycle()
            }
            
            return@withContext outputFile
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao comprimir imagem a partir do Uri: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Obtém uma versão comprimida adequada para upload de um arquivo de imagem existente
     * 
     * @param imageFile Arquivo original
     * @param maxFileSizeKB Tamanho máximo desejado em KB
     * @return Arquivo comprimido ou null em caso de falha
     */
    suspend fun getCompressedForUpload(
        imageFile: File,
        maxFileSizeKB: Int = 500
    ): File? = withContext(Dispatchers.IO) {
        // Se o arquivo já é menor que o tamanho máximo, retorna o original
        if (imageFile.length() <= maxFileSizeKB * 1024L) {
            return@withContext imageFile
        }
        
        try {
            // Tentar compressão progressiva
            var quality = 90
            var attempt = 0
            var result: File? = null
            
            // Usar tamanhos progressivamente menores em cada tentativa
            val sizes = arrayOf(
                ImageSize.HIGH,
                ImageSize.MEDIUM,
                ImageSize.REPORT,
                ImageSize.THUMBNAIL
            )
            
            while (attempt < sizes.size) {
                val tempFileName = "upload_${System.currentTimeMillis()}.jpg"
                result = compressImage(
                    imageFile,
                    sizes[attempt],
                    outputFileName = tempFileName
                )
                
                if (result != null && result.length() <= maxFileSizeKB * 1024L) {
                    // Tamanho adequado alcançado
                    break
                }
                
                attempt++
            }
            
            // Se ainda não conseguiu o tamanho desejado, tentar reduzir a qualidade
            if (result != null && result.length() > maxFileSizeKB * 1024L) {
                val bitmap = BitmapFactory.decodeFile(result.absolutePath)
                val tempFile = File(getCacheDirectory(), "upload_final_${System.currentTimeMillis()}.jpg")
                
                // Começar com qualidade 80 e ir reduzindo
                quality = 80
                while (quality >= 40) {
                    val out = FileOutputStream(tempFile)
                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
                    out.flush()
                    out.close()
                    
                    if (tempFile.length() <= maxFileSizeKB * 1024L) {
                        result = tempFile
                        break
                    }
                    
                    quality -= 10
                }
                
                bitmap.recycle()
            }
            
            return@withContext result
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao comprimir para upload: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Extrai um frame de um vídeo para usar como thumbnail
     * 
     * @param videoFile Arquivo de vídeo
     * @param frameTimeMs Posição do frame a ser extraído (em ms)
     * @param size Tamanho do thumbnail
     * @return Arquivo de imagem contendo o thumbnail ou null em caso de falha
     */
    suspend fun extractVideoThumbnail(
        videoFile: File,
        frameTimeMs: Long = 1000,
        size: ImageSize = ImageSize.THUMBNAIL
    ): File? = withContext(Dispatchers.IO) {
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(videoFile.absolutePath)
            
            // Extrair frame como bitmap
            val bitmap = retriever.getFrameAtTime(
                frameTimeMs * 1000, // converter para microssegundos
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: throw IOException("Não foi possível extrair frame do vídeo")
            
            // Redimensionar mantendo proporção
            val scaledBitmap = if (size != ImageSize.ORIGINAL) {
                val originalWidth = bitmap.width
                val originalHeight = bitmap.height
                
                val ratioWidth = size.maxWidth.toFloat() / originalWidth
                val ratioHeight = size.maxHeight.toFloat() / originalHeight
                val ratio = min(ratioWidth, ratioHeight)
                
                val newWidth = (originalWidth * ratio).roundToInt()
                val newHeight = (originalHeight * ratio).roundToInt()
                
                Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
            } else {
                bitmap
            }
            
            // Salvar thumbnail em arquivo
            val thumbFileName = "thumb_${System.currentTimeMillis()}.jpg"
            val thumbFile = File(getCacheDirectory(), thumbFileName)
            
            FileOutputStream(thumbFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, size.quality, out)
            }
            
            // Limpar recursos
            retriever.release()
            if (scaledBitmap != bitmap) {
                bitmap.recycle()
            }
            scaledBitmap.recycle()
            
            return@withContext thumbFile
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao extrair thumbnail do vídeo: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Comprime um arquivo de vídeo (não implementado inteiramente aqui -
     * em produção usaria uma biblioteca como FFMpeg ou MediaCodec)
     * 
     * @param videoFile Arquivo de vídeo original
     * @param compression Nível de compressão desejado
     * @return Arquivo de vídeo comprimido ou null em caso de falha
     */
    suspend fun compressVideo(
        videoFile: File,
        compression: VideoCompression = VideoCompression.MEDIUM
    ): File? = withContext(Dispatchers.IO) {
        try {
            Log.i(TAG, "Iniciando compressão de vídeo: ${videoFile.absolutePath}")
            
            // Em um caso real, aqui usaríamos FFmpeg ou MediaCodec 
            // para fazer a transcodificação do vídeo com parâmetros adequados
            
            // Exemplo de configurações com base no nível de compressão
            val (bitrate, resolution, fps) = when (compression) {
                VideoCompression.LOW -> Triple("500k", "640x360", 24)
                VideoCompression.MEDIUM -> Triple("1000k", "1280x720", 30)
                VideoCompression.HIGH -> Triple("2000k", "1920x1080", 30)
            }
            
            // NOTA: Esta implementação é apenas um placeholder.
            // Em uma implementação real, o código abaixo seria substituído pela 
            // chamada à biblioteca de compressão de vídeo escolhida.
            
            // Simulando processo de compressão
            val outputFile = File(
                getCacheDirectory(),
                "compressed_${System.currentTimeMillis()}_${videoFile.name}"
            )
            
            // Apenas copiando o arquivo para simular (em produção, não faça isso!)
            // Isso deve ser substituído por uma compressão real com FFmpeg ou similar
            videoFile.copyTo(outputFile, overwrite = true)
            
            Log.i(TAG, "Compressão de vídeo concluída: ${outputFile.absolutePath}")
            Log.i(TAG, "Configurações usadas: bitrate=$bitrate, resolution=$resolution, fps=$fps")
            
            return@withContext outputFile
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao comprimir vídeo: ${e.message}")
            return@withContext null
        }
    }
    
    /**
     * Retorna o URI compartilhável para um arquivo usando FileProvider
     * 
     * @param file Arquivo para o qual gerar URI
     * @return Uri compartilhável ou null em caso de erro
     */
    fun getShareableUri(file: File): Uri? {
        return try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao criar URI compartilhável: ${e.message}")
            null
        }
    }
    
    /**
     * Cria um arquivo temporário para armazenar uma imagem comprimida
     * 
     * @param prefix Prefixo para o nome do arquivo
     * @param suffix Sufixo para o nome do arquivo
     * @return Arquivo criado
     */
    fun createTempImageFile(prefix: String = "IMG", suffix: String = ".jpg"): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFileName = "${prefix}_${timeStamp}_"
        val storageDir = getCacheDirectory()
        return File.createTempFile(imageFileName, suffix, storageDir)
    }
    
    // ==================== Métodos Auxiliares ====================
    
    /**
     * Comprime e redimensiona um bitmap a partir de um arquivo
     */
    private fun compressBitmap(
        inputPath: String,
        outputPath: String,
        maxWidth: Int,
        maxHeight: Int,
        quality: Int,
        rotation: Int
    ): File {
        // Decodificar apenas as dimensões primeiro
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(inputPath, options)
        
        // Calcular o fator de escala
        var scale = 1
        if (maxWidth > 0 && maxHeight > 0) {
            val photoWidth = options.outWidth
            val photoHeight = options.outHeight
            
            // Calcular qual dimensão reduzir
            val widthRatio = (photoWidth.toFloat() / maxWidth.toFloat()).roundToInt()
            val heightRatio = (photoHeight.toFloat() / maxHeight.toFloat()).roundToInt()
            
            scale = max(widthRatio, heightRatio).coerceAtLeast(1)
        }
        
        // Decodificar a bitmap com escala
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = scale
            inJustDecodeBounds = false
        }
        
        var bitmap = BitmapFactory.decodeFile(inputPath, decodeOptions) ?: throw IOException("Falha ao decodificar imagem")
        
        // Aplicar rotação se necessário
        if (rotation != 0) {
            val matrix = Matrix()
            matrix.postRotate(rotation.toFloat())
            val rotatedBitmap = Bitmap.createBitmap(
                bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
            )
            if (bitmap != rotatedBitmap) {
                bitmap.recycle()
            }
            bitmap = rotatedBitmap
        }
        
        // Redimensionar se ainda for maior que o tamanho máximo
        val finalBitmap = if (maxWidth > 0 && maxHeight > 0 && 
                (bitmap.width > maxWidth || bitmap.height > maxHeight)) {
            
            val ratioWidth = maxWidth.toFloat() / bitmap.width
            val ratioHeight = maxHeight.toFloat() / bitmap.height
            val ratio = min(ratioWidth, ratioHeight)
            
            val newWidth = (bitmap.width * ratio).roundToInt()
            val newHeight = (bitmap.height * ratio).roundToInt()
            
            val scaledBitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
            if (scaledBitmap != bitmap) {
                bitmap.recycle()
            }
            scaledBitmap
        } else {
            bitmap
        }
        
        // Comprimir e salvar
        val outputFile = File(outputPath)
        FileOutputStream(outputFile).use { out ->
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        }
        
        finalBitmap.recycle()
        
        return outputFile
    }
    
    /**
     * Verifica se um arquivo é uma imagem baseado na extensão
     */
    private fun isImageFile(file: File): Boolean {
        val name = file.name.lowercase(Locale.getDefault())
        return name.endsWith(".jpg") || 
               name.endsWith(".jpeg") || 
               name.endsWith(".png") || 
               name.endsWith(".webp")
    }
    
    /**
     * Obtém a rotação da imagem a partir dos dados EXIF
     */
    private fun getExifRotation(imagePath: String): Int {
        try {
            val exif = ExifInterface(imagePath)
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            
            return when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível ler dados EXIF: ${e.message}")
            return 0
        }
    }
    
    /**
     * Gera um nome de arquivo para o arquivo comprimido
     */
    private fun generateOutputFileName(originalName: String, suffix: String): String {
        val baseName = if (originalName.contains(".")) {
            originalName.substring(0, originalName.lastIndexOf("."))
        } else {
            originalName
        }
        
        val extension = if (originalName.contains(".")) {
            originalName.substring(originalName.lastIndexOf("."))
        } else {
            ".jpg"
        }
        
        return "${baseName}_${suffix}${extension}"
    }
    
    /**
     * Obtém o diretório de cache apropriado para arquivos temporários
     */
    private fun getCacheDirectory(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val cacheDir = File(context.cacheDir, "compressed/$timeStamp")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }
        return cacheDir
    }
}