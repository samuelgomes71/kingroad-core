import React, { useState, useEffect, useRef } from 'react';
import { Star, Ban, MapPin, X, Truck, AlertTriangle, Navigation, Flag, TrendingUp, Clock } from 'lucide-react';

/**
 * Menu de contexto que aparece após pressionar e segurar por 2 segundos em um ponto do mapa
 * Oferece opções adaptativas de acordo com o estado da navegação
 */
const MapContextMenu = ({ 
  // Estado da navegação
  navigationStatus = 'idle', // 'idle', 'planned', 'active'
  
  // Callbacks para diferentes ações
  onNavigateTo,         // Navegar para este ponto
  onSetAsStartPoint,    // Definir como ponto de partida
  onSetAsEndPoint,      // Definir como destino
  onAddWaypoint,        // Adicionar ponto de passagem
  onAddFavorite,        // Adicionar às rotas favoritas
  onAddProhibited,      // Adicionar às rotas proibidas
  onAddArticulatedRoute, // Marcar como rota possível para caminhões articulados
  onReportIssue,        // Reportar problema na via
  
  // Elemento do mapa e configurações
  mapElement,
  vehicleMode = 'truck', // 'truck', 'car', 'bus', 'rv'
}) => {
  // Estados
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const [pointInfo, setPointInfo] = useState(null);
  const [pressTimer, setPressTimer] = useState(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successAction, setSuccessAction] = useState(null);
  
  // Referência para o elemento do mapa
  const mapRef = useRef(mapElement);
  
  // Determina o estado atual da navegação/rota
  const isNavigationActive = navigationStatus === 'active';
  const isRoutePlanned = navigationStatus === 'planned';
  const hasRoute = isRoutePlanned || isNavigationActive;
  
  // Configura listeners para detecção de pressionar e segurar
  useEffect(() => {
    // Manipuladores de eventos para touch (dispositivos móveis)
    const handleTouchStart = (e) => {
      // Evita conflitos com outros gestos
      if (e.touches.length > 1) return;
      
      const touch = e.touches[0];
      startPressTimer(touch.clientX, touch.clientY);
    };
    
    const handleTouchEnd = () => {
      cancelPressTimer();
    };
    
    const handleTouchMove = () => {
      // Cancela se o usuário mover o dedo durante o press
      cancelPressTimer();
    };
    
    // Manipuladores de eventos para mouse (desktop)
    const handleMouseDown = (e) => {
      // Apenas para clique principal (geralmente o esquerdo)
      if (e.button !== 0) return;
      
      startPressTimer(e.clientX, e.clientY);
    };
    
    const handleMouseUp = () => {
      cancelPressTimer();
    };
    
    const handleMouseMove = () => {
      // Cancela se o usuário mover o mouse durante o press
      cancelPressTimer();
    };

    // Adiciona event listeners ao elemento do mapa
    const element = mapRef.current || document;
    
    element.addEventListener('touchstart', handleTouchStart);
    element.addEventListener('mousedown', handleMouseDown);
    element.addEventListener('touchend', handleTouchEnd);
    element.addEventListener('mouseup', handleMouseUp);
    element.addEventListener('touchmove', handleTouchMove);
    element.addEventListener('mousemove', handleMouseMove);
    
    // Cleanup: remove os listeners quando o componente é desmontado
    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('mousedown', handleMouseDown);
      element.removeEventListener('touchend', handleTouchEnd);
      element.removeEventListener('mouseup', handleMouseUp);
      element.removeEventListener('touchmove', handleTouchMove);
      element.removeEventListener('mousemove', handleMouseMove);
      
      cancelPressTimer();
    };
  }, [mapElement]);

  // Atualiza a referência do mapElement quando ela muda
  useEffect(() => {
    mapRef.current = mapElement;
  }, [mapElement]);

  // Inicia o timer para detectar pressionar e segurar
  const startPressTimer = (x, y) => {
    // Cancela qualquer timer existente
    cancelPressTimer();
    
    // Define novo timer (2 segundos)
    const timer = setTimeout(() => {
      handleLongPress(x, y);
    }, 2000);
    
    setPressTimer(timer);
  };

  // Cancela o timer de pressionar e segurar
  const cancelPressTimer = () => {
    if (pressTimer) {
      clearTimeout(pressTimer);
      setPressTimer(null);
    }
  };

  // Manipula o evento de pressionar e segurar
  const handleLongPress = (x, y) => {
    // Numa aplicação real, você obteria informações reais sobre o local
    // com base nas coordenadas geográficas. Aqui usamos dados simulados.
    
    // Simula a obtenção de informações sobre o ponto clicado
    // Idealmente, você usaria um service/API de mapa para obter estas informações
    const mockInfo = {
      coords: { lat: -23.550, lng: -46.633 },
      address: 'Av. Paulista, 1578',
      distanceFromCurrentLocation: '15.2 km',
      estimatedTime: '22 min',
      nearestRoad: {
        name: 'Avenida Paulista',
        type: 'Avenida',
        id: 'road-78923'
      }
    };

    setPointInfo(mockInfo);
    setMenuPosition({ x, y });
    setIsMenuOpen(true);
    setShowSuccess(false);
    setSuccessAction(null);
  };

  // Fecha o menu
  const closeMenu = () => {
    setIsMenuOpen(false);
    setTimeout(() => {
      setPointInfo(null);
      setShowSuccess(false);
      setSuccessAction(null);
    }, 300);
  };

  // Executa uma ação e mostra feedback de sucesso
  const executeAction = (action, callback) => {
    if (callback && pointInfo) {
      callback(pointInfo);
      setShowSuccess(true);
      setSuccessAction(action);
      setTimeout(closeMenu, 1500);
    }
  };

  // Se o menu não estiver aberto, não renderiza nada
  if (!isMenuOpen) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 z-50 pointer-events-none"
      style={{ touchAction: 'none' }}
    >
      {/* Overlay para capturar cliques fora do menu */}
      <div 
        className="absolute inset-0 bg-black bg-opacity-50 pointer-events-auto"
        onClick={closeMenu}
      />
      
      {/* Menu de contexto */}
      <div 
        className="absolute bg-gray-900 rounded-lg shadow-xl pointer-events-auto w-72 max-w-[90vw]"
        style={{
          left: Math.min(menuPosition.x, window.innerWidth - 290),
          top: Math.min(menuPosition.y, window.innerHeight - 300)
        }}
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between p-3 border-b border-gray-800">
          <div className="flex items-center">
            <MapPin className="text-amber-400 mr-2" size={20} />
            <div>
              <h3 className="font-bold text-white">{pointInfo?.nearestRoad?.name || 'Local selecionado'}</h3>
              <p className="text-xs text-gray-400">
                {pointInfo?.address || `${pointInfo?.coords.lat.toFixed(5)}, ${pointInfo?.coords.lng.toFixed(5)}`}
              </p>
            </div>
          </div>
          <button 
            onClick={closeMenu}
            className="text-gray-500 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>
        
        {/* Conteúdo */}
        <div className="p-3">
          {showSuccess ? (
            // Mensagem de sucesso após executar uma ação
            <div className="text-center py-4">
              <div className="mx-auto w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h4 className="text-lg font-bold text-white mb-1">
                {successAction === 'navigate' && 'Iniciando navegação...'}
                {successAction === 'start' && 'Definido como ponto de partida'}
                {successAction === 'end' && 'Definido como destino'}
                {successAction === 'waypoint' && 'Ponto de passagem adicionado'}
                {successAction === 'favorite' && 'Adicionado às rotas favoritas'}
                {successAction === 'prohibited' && 'Adicionado às rotas proibidas'}
                {successAction === 'articulated' && 'Marcado como rota possível para caminhões articulados'}
                {successAction === 'report' && 'Problema reportado'}
              </h4>
            </div>
          ) : (
            <>
              {/* Distância e tempo estimado (se disponível) */}
              {pointInfo?.distanceFromCurrentLocation && (
                <div className="bg-gray-800 p-2 rounded-lg mb-3 flex justify-between">
                  <div className="flex items-center text-xs text-gray-300">
                    <TrendingUp size={14} className="mr-1 text-amber-400" />
                    <span>{pointInfo.distanceFromCurrentLocation}</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-300">
                    <Clock size={14} className="mr-1 text-amber-400" />
                    <span>{pointInfo.estimatedTime}</span>
                  </div>
                </div>
              )}
              
              <div className="space-y-2">
                {/* GRUPO 1: Opções sem rota ativa */}
                {!hasRoute && (
                  <>
                    {/* Navegar para este ponto */}
                    <button
                      className="w-full bg-amber-500 hover:bg-amber-600 p-3 rounded-lg flex items-start transition-colors text-left text-black"
                      onClick={() => executeAction('navigate', onNavigateTo)}
                    >
                      <div className="mr-3 mt-0.5">
                        <Navigation size={18} />
                      </div>
                      <div>
                        <div className="font-medium">Navegar para este ponto</div>
                        <div className="text-xs text-black text-opacity-70">Iniciar navegação para esta localização</div>
                      </div>
                    </button>
                    
                    {/* Definir como ponto de partida */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => executeAction('start', onSetAsStartPoint)}
                    >
                      <div className="text-amber-400 mr-3 mt-0.5">
                        <Flag size={18} />
                      </div>
                      <div>
                        <div className="font-medium text-white">Definir como ponto de partida</div>
                        <div className="text-xs text-gray-400">Usar esta localização como ponto A</div>
                      </div>
                    </button>
                    
                    {/* Definir como destino */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => executeAction('end', onSetAsEndPoint)}
                    >
                      <div className="text-amber-400 mr-3 mt-0.5">
                        <MapPin size={18} />
                      </div>
                      <div>
                        <div className="font-medium text-white">Definir como destino</div>
                        <div className="text-xs text-gray-400">Usar esta localização como ponto B</div>
                      </div>
                    </button>
                  </>
                )}
                
                {/* GRUPO 2: Opções com rota planejada ou ativa */}
                {hasRoute && (
                  <>
                    {/* Adicionar ponto de passagem */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => executeAction('waypoint', onAddWaypoint)}
                    >
                      <div className="text-amber-400 mr-3 mt-0.5">
                        <MapPin size={18} />
                      </div>
                      <div>
                        <div className="font-medium text-white">Adicionar ponto de passagem</div>
                        <div className="text-xs text-gray-400">A rota atual será recalculada para passar por este ponto</div>
                      </div>
                    </button>
                    
                    {/* Adicionar às rotas favoritas */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => executeAction('favorite', onAddFavorite)}
                    >
                      <div className="text-amber-400 mr-3 mt-0.5">
                        <Star size={18} />
                      </div>
                      <div>
                        <div className="font-medium text-white">Adicionar às rotas favoritas</div>
                        <div className="text-xs text-gray-400">Esta rota será preferencial para cálculos de navegação</div>
                      </div>
                    </button>
                    
                    {/* Adicionar às rotas proibidas */}
                    <button
                      className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                      onClick={() => executeAction('prohibited', onAddProhibited)}
                    >
                      <div className="text-amber-400 mr-3 mt-0.5">
                        <Ban size={18} />
                      </div>
                      <div>
                        <div className="font-medium text-white">Adicionar às rotas proibidas</div>
                        <div className="text-xs text-gray-400">Esta rota será evitada em cálculos de navegação</div>
                      </div>
                    </button>
                    
                    {/* Rota possível para caminhões articulados (apenas para veículos grandes) */}
                    {(vehicleMode === 'truck' || vehicleMode === 'bus') && (
                      <button
                        className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                        onClick={() => executeAction('articulated', onAddArticulatedRoute)}
                      >
                        <div className="text-amber-400 mr-3 mt-0.5">
                          <Truck size={18} />
                        </div>
                        <div>
                          <div className="font-medium text-white">Rota possível para caminhões articulados</div>
                          <div className="text-xs text-gray-400">Caminhões podem passar, mas não é rota ideal. Será usada apenas se o destino for nesta área.</div>
                        </div>
                      </button>
                    )}
                  </>
                )}
                
                {/* GRUPO 3: Opção comum para todos os estados */}
                <button
                  className="w-full bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-start transition-colors text-left"
                  onClick={() => executeAction('report', onReportIssue)}
                >
                  <div className="text-amber-400 mr-3 mt-0.5">
                    <AlertTriangle size={18} />
                  </div>
                  <div>
                    <div className="font-medium text-white">Reportar problema na via</div>
                    <div className="text-xs text-gray-400">Informar problemas como buracos, bloqueios ou outros obstáculos</div>
                  </div>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MapContextMenu;