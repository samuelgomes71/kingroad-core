import React, { useState, useEffect } from 'react';
import { Minimize2, Maximize2, X, Settings } from 'lucide-react';

// Este componente implementa uma funcionalidade de minimização similar ao Google Maps
// onde a aplicação pode ser minimizada para uma pequena janela flutuante
const FloatingWindowController = ({ 
  children, 
  title = "KingRoad",
  icon = null,
  initialMinimized = false,
  onClose
}) => {
  // Estado para controlar se a janela está minimizada
  const [minimized, setMinimized] = useState(initialMinimized);
  // Estado para posição da janela flutuante (para arrastar)
  const [position, setPosition] = useState({ x: 20, y: window.innerHeight - 200 });
  // Estado para controlar o arrasto
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  // Função para minimizar/maximizar
  const toggleMinimize = () => {
    setMinimized(!minimized);
  };
  
  // Gerencia início do arrasto da janela
  const handleMouseDown = (e) => {
    if (minimized) {
      const rect = e.currentTarget.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      setIsDragging(true);
    }
  };
  
  // Efeito para gerenciar movimento durante arrasto
  useEffect(() => {
    const handleMouseMove = (e) => {
      if (isDragging) {
        // Calcula nova posição mas mantém dentro dos limites da tela
        const newX = Math.max(0, Math.min(window.innerWidth - 150, e.clientX - dragOffset.x));
        const newY = Math.max(0, Math.min(window.innerHeight - 100, e.clientY - dragOffset.y));
        
        setPosition({ x: newX, y: newY });
      }
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
    };
    
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  // Se minimizado, renderiza uma pequena janela flutuante
  if (minimized) {
    return (
      <div 
        className={`fixed rounded-lg overflow-hidden shadow-lg z-50 bg-gray-900 border border-gray-800 ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        style={{ 
          width: '200px', 
          height: '125px',
          left: `${position.x}px`,
          top: `${position.y}px`
        }}
      >
        {/* Barra de controle da janela minimizada */}
        <div 
          className="h-8 bg-gray-800 flex items-center justify-between px-2 text-gray-200"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center truncate">
            {icon && <span className="mr-1">{icon}</span>}
            <span className="text-xs font-medium truncate">{title}</span>
          </div>
          <div className="flex items-center">
            <button 
              onClick={toggleMinimize}
              className="p-1 text-gray-400 hover:text-white"
            >
              <Maximize2 size={14} />
            </button>
            {onClose && (
              <button 
                onClick={onClose}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>
        
        {/* Conteúdo minimizado - previsualização */}
        <div className="h-[calc(100%-32px)] overflow-hidden bg-gray-900">
          <div className="transform scale-[0.3] origin-top-left h-[350%] w-[350%] pointer-events-none">
            {children}
          </div>
        </div>
      </div>
    );
  }
  
  // Se maximizado, renderiza conteúdo normal com botão para minimizar
  return (
    <div className="relative w-full h-full">
      {/* Botão de minimizar - posicionado no canto superior direito */}
      <button 
        onClick={toggleMinimize}
        className="absolute top-4 right-4 z-50 bg-gray-800 hover:bg-gray-700 text-amber-400 p-2 rounded-full shadow-lg transition-colors"
        title="Minimizar"
      >
        <Minimize2 size={20} />
      </button>
      
      {/* Conteúdo normal do app */}
      {children}
    </div>
  );
};

// Componente de exemplo para demonstração
const KingRoadFloatingWindowExample = () => {
  const [showApp, setShowApp] = useState(true);
  
  const handleClose = () => {
    setShowApp(false);
  };
  
  const handleReopen = () => {
    setShowApp(true);
  };
  
  if (!showApp) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-gray-950">
        <button 
          onClick={handleReopen}
          className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-4 rounded"
        >
          Abrir KingRoad
        </button>
      </div>
    );
  }
  
  return (
    <FloatingWindowController
      title="KingRoad GPS" 
      icon={<span className="text-amber-400">🧭</span>}
      onClose={handleClose}
    >
      {/* Aqui viria o conteúdo principal do KingRoad */}
      <div className="bg-gray-950 text-white h-screen p-4">
        <h1 className="text-2xl font-bold text-amber-400 mb-6">KingRoad</h1>
        
        {/* Exemplo de conteúdo do mapa */}
        <div className="bg-gray-900 rounded-lg p-4 h-[calc(100vh-130px)] relative">
          <div className="absolute inset-0 bg-gray-800 rounded-lg overflow-hidden">
            {/* Simulação de mapa */}
            <div className="w-full h-full">
              <div className="absolute top-0 left-0 w-full h-full opacity-30">
                {/* Grid simulando estradas */}
                <div className="absolute inset-0" style={{
                  backgroundImage: 'linear-gradient(to right, #333 1px, transparent 1px), linear-gradient(to bottom, #333 1px, transparent 1px)',
                  backgroundSize: '50px 50px'
                }}></div>
                
                {/* Linhas mais escuras simulando estradas principais */}
                <div className="absolute left-[40%] top-0 h-full w-4 bg-gray-600"></div>
                <div className="absolute top-[60%] left-0 w-full h-4 bg-gray-600"></div>
                
                {/* Marcador de destino */}
                <div className="absolute left-[60%] top-[30%]">
                  <div className="w-6 h-6 bg-amber-500 rounded-full flex items-center justify-center text-black">
                    B
                  </div>
                </div>
                
                {/* Marcador de posição atual */}
                <div className="absolute left-[30%] top-[70%]">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white">
                    A
                  </div>
                </div>
                
                {/* Linha simulando rota */}
                <svg className="absolute inset-0 w-full h-full">
                  <path 
                    d="M30%,70% L40%,70% L40%,30% L60%,30%" 
                    stroke="#3B82F6" 
                    strokeWidth="3" 
                    fill="none" 
                  />
                </svg>
              </div>
            </div>
            
            {/* Informações de navegação na parte inferior */}
            <div className="absolute bottom-0 left-0 right-0 bg-gray-900 bg-opacity-90 p-3">
              <div className="flex items-center text-white">
                <div className="bg-amber-500 text-black rounded-full w-8 h-8 flex items-center justify-center mr-3">
                  ↑
                </div>
                <div>
                  <div className="font-bold">Siga em frente na BR-101</div>
                  <div className="text-sm text-gray-400">12 km - 15 min</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </FloatingWindowController>
  );
};

export { FloatingWindowController, KingRoadFloatingWindowExample };