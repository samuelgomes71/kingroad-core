// Sistema de Gerenciamento de Mapas Offline
// app/src/main/kotlin/com/kingroad/map/offline

import java.time.Duration

class OfflineMapManager(
    private val storageManager: StorageManager,
    private val mapService: MapService,
    private val networkManager: NetworkManager,
    private val preferencesManager: PreferencesManager
) {
    data class MapRegion(
        val id: String,
        val name: String,
        val country: Country,
        val boundingBox: BoundingBox,
        val size: Long,          // tamanho em bytes
        val lastUpdate: Long,    // timestamp
        val lastUsed: Long,      // timestamp da última utilização
        val type: MapType,
        val subRegions: List<MapRegion>? = null
    )

    data class Country(
        val code: String,        // ISO code
        val name: String,
        val continent: Continent,
        val availableTypes: List<MapType>,
        val totalSize: Long,     // tamanho total em bytes
        val lastUpdate: Long     // timestamp
    )

    enum class MapType {
        FULL,           // Mapa completo com todos os detalhes
        NAVIGATION,     // Apenas dados de navegação
        TRUCK,          // Específico para caminhões
        BASIC          // Mapa básico
    }

    enum class Continent {
        NORTH_AMERICA,
        SOUTH_AMERICA,
        EUROPE,
        ASIA,
        AFRICA,
        OCEANIA
    }

    data class DownloadStatus(
        val progress: Float,     // 0.0 a 1.0
        val bytesDownloaded: Long,
        val totalBytes: Long,
        val estimatedTimeRemaining: Duration,
        val currentSpeed: Long   // bytes por segundo
    )

    // Iniciar download de região
    suspend fun downloadRegion(
        region: MapRegion,
        type: MapType = MapType.FULL
    ): kotlinx.coroutines.flow.Flow<DownloadStatus> = kotlinx.coroutines.flow.flow {
        // Verificar espaço disponível
        val availableSpace = storageManager.getAvailableSpace()
        if (availableSpace < region.size) {
            throw InsufficientStorageException(
                required = region.size,
                available = availableSpace
            )
        }

        // Iniciar download
        val downloadJob = mapService.downloadRegion(
            region = region,
            type = type,
            callback = { status -> emit(status) }
        )

        // Processar e validar dados baixados
        val downloadedData = downloadJob.await()
        validateDownloadedData(downloadedData)

        // Armazenar mapa
        storageManager.saveMap(
            region = region,
            data = downloadedData,
            type = type
        )

        // Atualizar metadados
        updateMapMetadata(region, type)
    }

    // Validar dados baixados
    private fun validateDownloadedData(data: ByteArray) {
        // Verificar integridade dos dados
        if (data.isEmpty()) {
            throw InvalidMapDataException("Dados de mapa vazios")
        }
        
        // Verificar assinatura dos dados
        if (!mapService.verifyMapSignature(data)) {
            throw InvalidMapDataException("Assinatura de dados inválida")
        }
    }

    // Validar dados de atualização
    private fun validateUpdateData(data: ByteArray) {
        if (data.isEmpty()) {
            throw InvalidMapDataException("Dados de atualização vazios")
        }
        
        if (!mapService.verifyUpdateSignature(data)) {
            throw InvalidMapDataException("Assinatura de atualização inválida")
        }
    }

    // Atualizar metadados do mapa
    private suspend fun updateMapMetadata(region: MapRegion, type: MapType) {
        val updatedRegion = region.copy(
            lastUpdate = System.currentTimeMillis(),
            lastUsed = System.currentTimeMillis()
        )
        
        storageManager.updateMapMetadata(updatedRegion, type)
    }

    // Obter versão atual do mapa
    private suspend fun getMapVersion(region: MapRegion, type: MapType): Int {
        return storageManager.getMapVersion(region, type)
    }

    // Calcular espaço necessário para novas instalações/atualizações
    private suspend fun calculateRequiredSpace(): Long {
        val plannedDownloads = preferencesManager.getPlannedDownloads()
        return plannedDownloads.sumOf { it.size } + MINIMUM_STORAGE_SPACE
    }

    // Verificar se um mapa foi usado recentemente
    private fun isMapRecentlyUsed(map: MapRegion): Boolean {
        val currentTime = System.currentTimeMillis()
        val lastUsedTime = map.lastUsed
        return (currentTime - lastUsedTime) < MAP_USAGE_THRESHOLD.toMillis()
    }

    // Remover um mapa
    private suspend fun removeMap(map: MapRegion) {
        storageManager.removeMap(map)
    }

    // Atualizar mapa existente
    suspend fun updateRegion(
        region: MapRegion,
        type: MapType = MapType.FULL
    ): kotlinx.coroutines.flow.Flow<DownloadStatus> = kotlinx.coroutines.flow.flow {
        val currentVersion = getMapVersion(region, type)
        val latestVersion = mapService.getLatestVersion(region, type)

        if (currentVersion < latestVersion) {
            val updateJob = mapService.downloadUpdate(
                region = region,
                currentVersion = currentVersion,
                targetVersion = latestVersion,
                callback = { status -> emit(status) }
            )

            val updateData = updateJob.await()
            validateUpdateData(updateData)

            storageManager.applyUpdate(
                region = region,
                updateData = updateData,
                type = type
            )

            updateMapMetadata(region, type)
        }
    }

    // Gerenciar espaço
    suspend fun manageStorage() {
        val installedMaps = storageManager.getInstalledMaps()
        val availableSpace = storageManager.getAvailableSpace()
        val requiredSpace = calculateRequiredSpace()

        if (availableSpace < requiredSpace) {
            // Identificar mapas não utilizados
            val unusedMaps = installedMaps
                .filter { !isMapRecentlyUsed(it) }
                .sortedBy { it.lastUsed }

            // Remover mapas até liberar espaço suficiente
            var spaceToFree = requiredSpace - availableSpace
            unusedMaps.forEach { map ->
                if (spaceToFree > 0) {
                    removeMap(map)
                    spaceToFree -= map.size
                }
            }
        }
    }

    // Obter lista de países disponíveis
    suspend fun getAvailableCountries(): List<Country> {
        return mapService.getAvailableCountries()
            .sortedBy { it.name }
            .filter { it.availableTypes.isNotEmpty() }
    }

    // Obter regiões de um país
    suspend fun getCountryRegions(
        country: Country
    ): List<MapRegion> {
        return mapService.getCountryRegions(country)
            .sortedBy { it.name }
    }

    // Verificar atualizações
    suspend fun checkForUpdates(): List<MapRegion> {
        val installedMaps = storageManager.getInstalledMaps()
        val outdatedMaps = mutableListOf<MapRegion>()

        installedMaps.forEach { map ->
            val currentVersion = getMapVersion(map, map.type)
            val latestVersion = mapService.getLatestVersion(map, map.type)

            if (currentVersion < latestVersion) {
                outdatedMaps.add(map)
            }
        }

        return outdatedMaps
    }

    companion object {
        private val MINIMUM_STORAGE_SPACE = 1024L * 1024L * 1024L // 1GB
        private val UPDATE_CHECK_INTERVAL = Duration.ofDays(7)
        private val MAP_USAGE_THRESHOLD = Duration.ofDays(30)
    }
}

// Exceções
class InsufficientStorageException(
    val required: Long,
    val available: Long
) : Exception(
    "Espaço insuficiente: necessário ${required / 1024 / 1024}MB, " +
    "disponível ${available / 1024 / 1024}MB"
)

class InvalidMapDataException(message: String) : Exception(message)

// Classes de suporte
data class BoundingBox(
    val north: Double,
    val south: Double,
    val east: Double,
    val west: Double
)

// Interface de armazenamento
interface StorageManager {
    suspend fun getAvailableSpace(): Long
    suspend fun saveMap(region: OfflineMapManager.MapRegion, data: ByteArray, type: OfflineMapManager.MapType)
    suspend fun getInstalledMaps(): List<OfflineMapManager.MapRegion>
    suspend fun removeMap(region: OfflineMapManager.MapRegion)
    suspend fun applyUpdate(region: OfflineMapManager.MapRegion, updateData: ByteArray, type: OfflineMapManager.MapType)
    suspend fun updateMapMetadata(region: OfflineMapManager.MapRegion, type: OfflineMapManager.MapType)
    suspend fun getMapVersion(region: OfflineMapManager.MapRegion, type: OfflineMapManager.MapType): Int
}

// Interface de serviço de mapas
interface MapService {
    suspend fun getAvailableCountries(): List<OfflineMapManager.Country>
    suspend fun getCountryRegions(country: OfflineMapManager.Country): List<OfflineMapManager.MapRegion>
    suspend fun getLatestVersion(region: OfflineMapManager.MapRegion, type: OfflineMapManager.MapType): Int
    suspend fun downloadRegion(
        region: OfflineMapManager.MapRegion, 
        type: OfflineMapManager.MapType, 
        callback: (OfflineMapManager.DownloadStatus) -> Unit
    ): kotlinx.coroutines.Deferred<ByteArray>
    suspend fun downloadUpdate(
        region: OfflineMapManager.MapRegion, 
        currentVersion: Int, 
        targetVersion: Int, 
        callback: (OfflineMapManager.DownloadStatus) -> Unit
    ): kotlinx.coroutines.Deferred<ByteArray>
    fun verifyMapSignature(data: ByteArray): Boolean
    fun verifyUpdateSignature(data: ByteArray): Boolean
}

// Interface de gerenciamento de rede
interface NetworkManager {
    fun isNetworkAvailable(): Boolean
    fun getNetworkType(): NetworkType
    fun getDownloadSpeed(): Long // bytes por segundo
    
    enum class NetworkType {
        WIFI,
        MOBILE_FAST,
        MOBILE_SLOW,
        NONE
    }
}

// Interface de preferências
interface PreferencesManager {
    suspend fun getPlannedDownloads(): List<OfflineMapManager.MapRegion>
    suspend fun addPlannedDownload(region: OfflineMapManager.MapRegion)
    suspend fun removePlannedDownload(region: OfflineMapManager.MapRegion)
}