// group.routes.js
// Rotas para gerenciar grupos no KingChat

const express = require('express');
const router = express.Router();
const groupController = require('../controllers/group.controller');
const authMiddleware = require('../middleware/auth');

// Aplicar middleware de autenticação a todas as rotas de grupos
router.use(authMiddleware);

// Criar um novo grupo
router.post('/', groupController.createGroup);

// Obter lista de grupos do usuário atual
router.get('/', async (req, res) => {
  try {
    const userId = req.user.id;
    const groups = await groupController.getUserGroups(userId);
    res.status(200).json(groups);
  } catch (error) {
    console.error('Erro ao buscar grupos do usuário:', error);
    res.status(500).json({ message: 'Falha ao buscar grupos' });
  }
});

// Obter detalhes de um grupo específico
router.get('/:groupId', groupController.getGroupDetails);

// Adicionar usuários a um grupo (com verificação de privacidade)
router.post('/:groupId/members', groupController.addUserToGroup);

// Remover usuário de um grupo
router.delete('/:groupId/members/:userId', groupController.removeUserFromGroup);

// Atualizar detalhes do grupo
router.put('/:groupId', groupController.updateGroup);

// Excluir grupo
router.delete('/:groupId', groupController.deleteGroup);

// Atualizar configurações de privacidade para adição a grupos
router.put('/privacy/group-addition', groupController.updateGroupAdditionPrivacy);

// Buscar grupos por nome
router.get('/search/:query', async (req, res) => {
  try {
    const { query } = req.params;
    const userId = req.user.id;
    
    const groups = await groupController.searchGroups(query, userId);
    res.status(200).json(groups);
  } catch (error) {
    console.error('Erro ao buscar grupos:', error);
    res.status(500).json({ message: 'Falha ao buscar grupos' });
  }
});

// Obter membros de um grupo
router.get('/:groupId/members', async (req, res) => {
  try {
    const { groupId } = req.params;
    const userId = req.user.id;
    
    const members = await groupController.getGroupMembers(groupId, userId);
    res.status(200).json(members);
  } catch (error) {
    console.error('Erro ao buscar membros do grupo:', error);
    res.status(500).json({ message: 'Falha ao buscar membros do grupo' });
  }
});

// Promover membro a administrador
router.post('/:groupId/admins/:userId', async (req, res) => {
  try {
    const { groupId, userId } = req.params;
    const currentUserId = req.user.id;
    
    await groupController.promoteToAdmin(groupId, userId, currentUserId);
    res.status(200).json({ message: 'Usuário promovido a administrador com sucesso' });
  } catch (error) {
    console.error('Erro ao promover usuário a administrador:', error);
    res.status(500).json({ message: 'Falha ao promover usuário' });
  }
});

// Rebaixar administrador a membro comum
router.delete('/:groupId/admins/:userId', async (req, res) => {
  try {
    const { groupId, userId } = req.params;
    const currentUserId = req.user.id;
    
    await groupController.demoteFromAdmin(groupId, userId, currentUserId);
    res.status(200).json({ message: 'Administrador rebaixado com sucesso' });
  } catch (error) {
    console.error('Erro ao rebaixar administrador:', error);
    res.status(500).json({ message: 'Falha ao rebaixar administrador' });
  }
});

// Sair de um grupo
router.post('/:groupId/leave', async (req, res) => {
  try {
    const { groupId } = req.params;
    const userId = req.user.id;
    
    await groupController.leaveGroup(groupId, userId);
    res.status(200).json({ message: 'Você saiu do grupo com sucesso' });
  } catch (error) {
    console.error('Erro ao sair do grupo:', error);
    res.status(500).json({ message: 'Falha ao sair do grupo' });
  }
});

module.exports = router;