import React, { useState } from 'react';
import { Map, Navigation, Truck, Car, Bus, Home, Settings, Search, Menu, AlertTriangle, MapPin, Camera, AlertCircle, X } from 'lucide-react';

// Componente de ícone de denúncia de infraestrutura
const InfrastructureReportIcon = ({ vehicleMode, onOpenReportForm, userLocation }) => {
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);
  
  // Mostrar tooltip ao passar o mouse
  const handleMouseEnter = () => {
    setIsTooltipVisible(true);
  };
  
  // Esconder tooltip ao retirar o mouse
  const handleMouseLeave = () => {
    setIsTooltipVisible(false);
  };
  
  // Abrir o formulário de denúncia
  const handleClick = () => {
    if (onOpenReportForm) {
      onOpenReportForm();
    }
  };
  
  // Determinar texto baseado no tipo de veículo
  const getVehicleSpecificText = () => {
    switch (vehicleMode) {
      case 'truck':
        return "Denunciar problemas para caminhoneiros";
      case 'car':
        return "Denunciar problemas para motoristas";
      case 'motorcycle':
        return "Denunciar problemas para motociclistas";
      case 'bus':
        return "Denunciar problemas para ônibus";
      case 'rv':
        return "Denunciar problemas para motorhomes";
      default:
        return "Denunciar problemas de infraestrutura";
    }
  };
  
  return (
    <div className="relative">
      {/* Botão circular para a tela principal */}
      <button
        className="bg-black text-amber-500 w-14 h-14 rounded-full flex items-center justify-center shadow-lg border-2 border-amber-500 relative"
        onClick={handleClick}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        aria-label="Denunciar problema de infraestrutura"
      >
        <div className="flex flex-col items-center justify-center">
          <AlertTriangle size={24} className="text-amber-500" />
          <span className="text-xs mt-1">Denunciar</span>
        </div>
        
        {/* Indicador de localização ativa - pequeno círculo verde */}
        {userLocation && (
          <div className="absolute top-1 right-1 w-3 h-3 bg-green-500 rounded-full border border-black"></div>
        )}
      </button>
      
      {/* Tooltip que aparece ao passar o mouse */}
      {isTooltipVisible && (
        <div 
          className="absolute bottom-16 left-1/2 transform -translate-x-1/2 bg-gray-900 text-amber-500 px-4 py-2 rounded-lg shadow-lg text-sm border border-amber-500 w-48 z-10"
        >
          <div className="text-center">
            {getVehicleSpecificText()}
          </div>
          <div className="absolute left-1/2 bottom-0 transform -translate-x-1/2 translate-y-1/2 rotate-45 w-3 h-3 bg-gray-900 border-r border-b border-amber-500"></div>
        </div>
      )}
    </div>
  );
};

// Versão estendida para a barra de navegação principal
const MainNavigationInfrastructureButton = ({ vehicleMode, onOpenReportForm, userLocation }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleToggleMenu = () => {
    setIsOpen(!isOpen);
  };
  
  const handleSelectOption = (option) => {
    if (onOpenReportForm) {
      onOpenReportForm(option);
    }
    setIsOpen(false);
  };
  
  const reportOptions = [
    { id: 'POTHOLE', label: 'Buraco na via', icon: '🕳️' },
    { id: 'FALLEN_TREE', label: 'Árvore caída', icon: '🌳' },
    { id: 'WATER_LEAK', label: 'Vazamento de água', icon: '💧' },
    { id: 'ABANDONED_WASTE', label: 'Lixo abandonado', icon: '🚮' },
    { id: 'ILLEGAL_DUMPING', label: 'Descarte irregular', icon: '🗑️' },
  ];
  
  return (
    <div className="relative">
      {/* Botão na barra de navegação principal */}
      <button
        onClick={handleToggleMenu}
        className="flex items-center justify-center flex-col p-2 text-amber-500 hover:bg-gray-800 rounded-lg transition-colors"
      >
        <AlertCircle size={22} />
        <span className="text-xs mt-1">Denunciar</span>
      </button>
      
      {/* Menu dropdown que aparece ao clicar */}
      {isOpen && (
        <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-gray-900 border border-amber-500 rounded-lg shadow-xl w-64 z-20">
          <div className="p-3 border-b border-gray-700">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-amber-500">Denunciar Problema</h3>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>
          </div>
          
          <div className="p-3">
            <div className="flex items-center mb-3 text-sm text-gray-400">
              <MapPin size={14} className="mr-1 text-amber-500" />
              <span>Usando sua localização atual</span>
            </div>
            
            <div className="flex items-center mb-3 text-sm text-gray-400">
              <Camera size={14} className="mr-1 text-amber-500" />
              <span>Adicione fotos para agilizar a resolução</span>
            </div>
            
            <div className="grid grid-cols-1 gap-2 mt-4">
              {reportOptions.map(option => (
                <button
                  key={option.id}
                  className="flex items-center p-3 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                  onClick={() => handleSelectOption(option.id)}
                >
                  <span className="text-xl mr-3">{option.icon}</span>
                  <span className="text-white">{option.label}</span>
                </button>
              ))}
              
              <button
                className="flex items-center p-3 bg-amber-500 hover:bg-amber-600 text-black font-bold rounded-lg transition-colors mt-2"
                onClick={() => handleSelectOption('ALL')}
              >
                <AlertTriangle size={18} className="mr-2" />
                <span>Ver todas as opções</span>
              </button>
            </div>
          </div>
          
          <div className="p-3 border-t border-gray-700 text-xs text-center text-gray-400">
            Ajude a melhorar a infraestrutura urbana para todos os motoristas
          </div>
        </div>
      )}
    </div>
  );
};

// Componente de barra de navegação principal do KingRoad
const MainNavigationBar = ({ 
  currentVehicleMode = 'truck',
  onChangeVehicleMode,
  userLocation,
  onOpenInfrastructureReport
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Manipuladores
  const handleVehicleModeChange = (mode) => {
    if (onChangeVehicleMode) {
      onChangeVehicleMode(mode);
    }
    setIsMenuOpen(false);
  };
  
  const handleOpenInfrastructureReport = (reportType) => {
    if (onOpenInfrastructureReport) {
      onOpenInfrastructureReport(reportType);
    }
  };
  
  // Gerenciamento de modos de veículos
  const vehicleModes = [
    { id: 'truck', label: 'Caminhão', icon: <Truck size={24} /> },
    { id: 'car', label: 'Carro', icon: <Car size={24} /> },
    { id: 'motorcycle', label: 'Moto', icon: <AlertTriangle size={24} /> },
    { id: 'bus', label: 'Ônibus', icon: <Bus size={24} /> },
    { id: 'rv', label: 'Motorhome', icon: <Home size={24} /> }
  ];
  
  // Encontrar o modo de veículo atual
  const activeVehicle = vehicleModes.find(mode => mode.id === currentVehicleMode) || vehicleModes[0];
  
  return (
    <div className="fixed inset-x-0 bottom-0 z-10">
      {/* Container principal da barra de navegação */}
      <div className="bg-gray-900 text-white border-t border-gray-800 shadow-lg">
        {/* Barra de navegação principal com ícones */}
        <div className="flex justify-between items-center px-4 py-2">
          {/* Botão de menu (aparece em mobile) */}
          <button 
            className="md:hidden p-2 rounded-full hover:bg-gray-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu size={24} className="text-amber-500" />
          </button>
          
          {/* Navegação principal - visível em telas maiores */}
          <div className="hidden md:flex items-center space-x-8">
            <button className="flex flex-col items-center text-amber-500">
              <Map size={24} />
              <span className="text-xs mt-1">Mapa</span>
            </button>
            
            <button className="flex flex-col items-center text-gray-400 hover:text-white">
              <Navigation size={24} />
              <span className="text-xs mt-1">Rotas</span>
            </button>
            
            <button className="flex flex-col items-center text-gray-400 hover:text-white">
              <Search size={24} />
              <span className="text-xs mt-1">Buscar</span>
            </button>
          </div>
          
          {/* Botão de denúncia de infraestrutura - Central e destacado */}
          <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/3">
            <InfrastructureReportIcon 
              vehicleMode={currentVehicleMode}
              onOpenReportForm={handleOpenInfrastructureReport}
              userLocation={userLocation}
            />
          </div>
          
          {/* Controles à direita */}
          <div className="flex items-center space-x-4">
            {/* Seletor de modo de veículo */}
            <div className="relative">
              <button 
                className="flex items-center px-3 py-1 bg-gray-800 rounded-full border border-amber-500"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {activeVehicle.icon}
                <span className="ml-2 text-sm hidden md:inline">{activeVehicle.label}</span>
              </button>
              
              {/* Menu dropdown de modos de veículo */}
              {isMenuOpen && (
                <div className="absolute bottom-full right-0 mb-2 bg-gray-900 border border-gray-700 rounded-lg shadow-xl">
                  <div className="p-2">
                    {vehicleModes.map(mode => (
                      <button
                        key={mode.id}
                        className={`flex items-center w-full px-4 py-2 rounded-lg ${
                          mode.id === currentVehicleMode 
                            ? 'bg-amber-500 text-black font-medium' 
                            : 'text-white hover:bg-gray-800'
                        }`}
                        onClick={() => handleVehicleModeChange(mode.id)}
                      >
                        <span className="mr-3">{mode.icon}</span>
                        <span>{mode.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Botão de configurações */}
            <button className="p-2 text-gray-400 hover:text-white">
              <Settings size={24} />
            </button>
          </div>
        </div>
        
        {/* Menu de navegação móvel expandido */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-900 p-4 border-t border-gray-800">
            <div className="grid grid-cols-3 gap-4">
              <button className="flex flex-col items-center p-3 text-amber-500 bg-gray-800 rounded-lg">
                <Map size={24} />
                <span className="text-xs mt-1">Mapa</span>
              </button>
              
              <button className="flex flex-col items-center p-3 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg">
                <Navigation size={24} />
                <span className="text-xs mt-1">Rotas</span>
              </button>
              
              <button className="flex flex-col items-center p-3 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg">
                <Search size={24} />
                <span className="text-xs mt-1">Buscar</span>
              </button>
              
              <MainNavigationInfrastructureButton 
                vehicleMode={currentVehicleMode}
                onOpenReportForm={handleOpenInfrastructureReport}
                userLocation={userLocation}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MainNavigationBar;