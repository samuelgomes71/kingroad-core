/**
 * LocationPicker.js
 * 
 * Componente para seleção e visualização de localização.
 * Implementa componente com mapa interativo para confirmar ou ajustar localização,
 * com suporte a busca de endereços e geocodificação reversa para mostrar o endereço atual.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TextInput,
  TouchableOpacity,
  Platform,
  Keyboard,
  Dimensions,
  FlatList
} from 'react-native';
import PropTypes from 'prop-types';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import { debounce } from 'lodash';

// Componentes personalizados
import Icon, { ICON_SETS, ICON_SIZES, ICON_STATES } from './Icon';
import GeocodingService from './GeocodingService';

// Constantes para modos de seleção
const SELECTION_MODES = {
  CURRENT_LOCATION: 'current_location',
  SEARCH_LOCATION: 'search_location',
  MAP_SELECTION: 'map_selection',
  MANUAL_INPUT: 'manual_input'
};

// Constantes para tipos de mapa
const MAP_TYPES = {
  STANDARD: 'standard',
  SATELLITE: 'satellite',
  HYBRID: 'hybrid',
  TERRAIN: 'terrain'
};

/**
 * Componente LocationPicker para seleção e visualização de localização
 * @param {Object} props - Propriedades do componente
 * @returns {React.Component} Componente LocationPicker
 */
const LocationPicker = ({
  // Propriedades de configuração
  initialLocation = null,
  defaultZoom = 15,
  allowCurrentLocation = true,
  allowSearch = true,
  allowMapSelection = true,
  allowManualInput = true,
  mapType = MAP_TYPES.STANDARD,
  searchDebounceTime = 500,
  maxSearchResults = 5,
  editable = true,
  showMapTypeSelector = true,
  
  // Tamanhos e estilos
  containerStyle = {},
  mapHeight = 250,
  mapWidth = '100%',
  mapStyle = {},
  
  // Handlers
  onLocationSelect = () => {},
  onLocationChange = () => {},
  onError = () => {},
  
  // Textos para traduções
  texts = {
    searchPlaceholder: 'Buscar endereço',
    currentLocationButton: 'Localização atual',
    confirmButton: 'Confirmar localização',
    permissionDeniedTitle: 'Permissão negada',
    permissionDeniedMessage: 'Permissão de localização negada. Por favor, habilite nas configurações do aplicativo.',
    locationErrorTitle: 'Erro de localização',
    locationErrorMessage: 'Não foi possível obter a localização atual',
    addressLabel: 'Endereço:',
    loadingLocation: 'Obtendo localização...',
    loadingAddress: 'Obtendo endereço...',
    noAddressFound: 'Endereço não encontrado',
    searchingAddresses: 'Buscando endereços...',
    noSearchResults: 'Nenhum resultado encontrado',
    latitudeLongitudeFormat: 'Lat: {lat}, Lng: {lng}',
    manualInputButton: 'Entrada manual',
    manualInputTitle: 'Inserir coordenadas',
    manualInputLatitude: 'Latitude',
    manualInputLongitude: 'Longitude',
    manualInputOk: 'OK',
    manualInputCancel: 'Cancelar',
    manualInputError: 'Coordenadas inválidas',
    standardMap: 'Padrão',
    satelliteMap: 'Satélite',
    hybridMap: 'Híbrido',
    terrainMap: 'Terreno'
  }
}) => {
  // Estado do componente
  const [location, setLocation] = useState(initialLocation);
  const [address, setAddress] = useState('');
  const [mode, setMode] = useState(initialLocation ? SELECTION_MODES.MAP_SELECTION : SELECTION_MODES.CURRENT_LOCATION);
  const [loading, setLoading] = useState(false);
  const [loadingAddress, setLoadingAddress] = useState(false);
  const [loadingLocation, setLoadingLocation] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchingAddresses, setSearchingAddresses] = useState(false);
  const [currentMapType, setCurrentMapType] = useState(mapType);
  const [locationPermission, setLocationPermission] = useState(false);
  
  // Referências
  const mapRef = useRef(null);
  const searchInputRef = useRef(null);
  const geocodingService = useRef(new GeocodingService());
  
  // Efeito para carregar a localização inicial
  useEffect(() => {
    if (initialLocation) {
      setLocation(initialLocation);
      getAddressFromLocation(initialLocation);
    } else if (allowCurrentLocation) {
      getCurrentLocation();
    }
    
    // Verifica permissão de localização
    checkLocationPermission();
  }, []);
  
  // Efeito para geocodificar quando a localização muda
  useEffect(() => {
    if (location) {
      getAddressFromLocation(location);
      onLocationChange(location);
    }
  }, [location]);
  
  // Efeito para busca de endereços
  useEffect(() => {
    if (searchQuery.trim().length > 2) {
      debouncedSearch(searchQuery);
    } else {
      setSearchResults([]);
      setSearchingAddresses(false);
    }
  }, [searchQuery]);
  
  /**
   * Debounce para busca de endereços
   */
  const debouncedSearch = useRef(
    debounce(async (query) => {
      if (query.trim().length > 2) {
        await searchAddresses(query);
      }
    }, searchDebounceTime)
  ).current;
  
  /**
   * Verifica permissão de localização
   */
  const checkLocationPermission = async () => {
    try {
      const permission = Platform.OS === 'ios'
        ? PERMISSIONS.IOS.LOCATION_WHEN_IN_USE
        : PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION;
      
      const result = await check(permission);
      
      if (result === RESULTS.GRANTED) {
        setLocationPermission(true);
        return true;
      } else if (result === RESULTS.DENIED) {
        // Solicita permissão se ainda não concedida
        const requestResult = await request(permission);
        const granted = requestResult === RESULTS.GRANTED;
        setLocationPermission(granted);
        return granted;
      } else {
        setLocationPermission(false);
        return false;
      }
    } catch (error) {
      console.error('[LocationPicker] Erro ao verificar permissão de localização:', error);
      setLocationPermission(false);
      return false;
    }
  };
  
  /**
   * Obtém a localização atual do dispositivo
   */
  const getCurrentLocation = async () => {
    try {
      setLoadingLocation(true);
      
      // Verifica permissão primeiro
      if (!locationPermission) {
        const hasPermission = await checkLocationPermission();
        if (!hasPermission) {
          Alert.alert(
            texts.permissionDeniedTitle,
            texts.permissionDeniedMessage
          );
          setLoadingLocation(false);
          onError('location_permission_denied');
          return;
        }
      }
      
      Geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const newLocation = { latitude, longitude };
          
          setLocation(newLocation);
          setMode(SELECTION_MODES.CURRENT_LOCATION);
          setLoadingLocation(false);
          
          // Centraliza o mapa na localização atual
          if (mapRef.current) {
            mapRef.current.animateToRegion({
              ...newLocation,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01
            });
          }
        },
        (error) => {
          console.error('[LocationPicker] Erro ao obter localização atual:', error);
          setLoadingLocation(false);
          Alert.alert(texts.locationErrorTitle, texts.locationErrorMessage);
          onError('get_current_location_failed', error);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );
    } catch (error) {
      console.error('[LocationPicker] Erro ao obter localização atual:', error);
      setLoadingLocation(false);
      onError('get_current_location_failed', error);
    }
  };
  
  /**
   * Obtém o endereço a partir de uma localização (latitude/longitude)
   * @param {Object} location - Objeto com latitude e longitude
   */
  const getAddressFromLocation = async (location) => {
    try {
      if (!location || !location.latitude || !location.longitude) {
        return;
      }
      
      setLoadingAddress(true);
      
      const result = await geocodingService.current.reverseGeocode(
        location.latitude,
        location.longitude
      );
      
      if (result && result.formattedAddress) {
        setAddress(result.formattedAddress);
      } else {
        setAddress(texts.noAddressFound);
      }
      
      setLoadingAddress(false);
    } catch (error) {
      console.error('[LocationPicker] Erro ao obter endereço:', error);
      setAddress(texts.noAddressFound);
      setLoadingAddress(false);
      onError('get_address_failed', error);
    }
  };
  
  /**
   * Busca endereços a partir de um texto
   * @param {string} query - Texto para busca
   */
  const searchAddresses = async (query) => {
    try {
      setSearchingAddresses(true);
      
      const results = await geocodingService.current.geocode(query);
      
      if (results && results.length > 0) {
        // Limita o número de resultados
        setSearchResults(results.slice(0, maxSearchResults));
      } else {
        setSearchResults([]);
      }
      
      setSearchingAddresses(false);
    } catch (error) {
      console.error('[LocationPicker] Erro ao buscar endereços:', error);
      setSearchResults([]);
      setSearchingAddresses(false);
      onError('search_addresses_failed', error);
    }
  };
  
  /**
   * Seleciona um endereço nos resultados da busca
   * @param {Object} item - Item do resultado da busca
   */
  const selectSearchResult = (item) => {
    if (!item || !item.location) return;
    
    // Atualiza localização e endereço
    setLocation(item.location);
    setAddress(item.formattedAddress);
    setMode(SELECTION_MODES.SEARCH_LOCATION);
    
    // Limpa resultados da busca e query
    setSearchResults([]);
    setSearchQuery('');
    
    // Centraliza o mapa na localização selecionada
    if (mapRef.current) {
      mapRef.current.animateToRegion({
        ...item.location,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
      });
    }
    
    // Esconde o teclado
    Keyboard.dismiss();
  };
  
  /**
   * Manipula a mudança de localização no mapa
   * @param {Object} region - Nova região do mapa
   */
  const handleRegionChange = (region) => {
    // Apenas atualiza se estiver no modo de seleção por mapa
    if (mode === SELECTION_MODES.MAP_SELECTION) {
      setLocation({
        latitude: region.latitude,
        longitude: region.longitude
      });
    }
  };
  
  /**
   * Manipula o toque no mapa
   * @param {Object} event - Evento de toque no mapa
   */
  const handleMapPress = (event) => {
    if (!editable || !allowMapSelection) return;
    
    const { coordinate } = event.nativeEvent;
    
    setLocation(coordinate);
    setMode(SELECTION_MODES.MAP_SELECTION);
    
    // Se houver resultados de busca, limpa
    if (searchResults.length > 0) {
      setSearchResults([]);
      setSearchQuery('');
    }
  };
  
  /**
   * Confirma a localização selecionada
   */
  const confirmLocation = () => {
    if (!location) return;
    
    onLocationSelect({
      ...location,
      address,
      mode,
      timestamp: Date.now()
    });
  };
  
  /**
   * Abre diálogo para entrada manual de coordenadas
   */
  const openManualInputDialog = () => {
    // Em uma implementação real, isso seria um modal ou uma tela separada
    // Aqui usamos um alerta simples para demonstração
    Alert.prompt(
      texts.manualInputTitle,
      '',
      [
        {
          text: texts.manualInputCancel,
          style: 'cancel'
        },
        {
          text: texts.manualInputOk,
          onPress: (value) => handleManualInput(value)
        }
      ],
      'plain-text',
      location 
        ? `${location.latitude}, ${location.longitude}`
        : '',
      'default'
    );
  };
  
  /**
   * Processa entrada manual de coordenadas
   * @param {string} value - Valor digitado pelo usuário
   */
  const handleManualInput = (value) => {
    try {
      if (!value) return;
      
      // Tenta extrair latitude e longitude
      const parts = value.split(',').map(part => part.trim());
      
      if (parts.length !== 2) {
        throw new Error('Formato inválido');
      }
      
      const latitude = parseFloat(parts[0]);
      const longitude = parseFloat(parts[1]);
      
      if (isNaN(latitude) || isNaN(longitude)) {
        throw new Error('Valores não numéricos');
      }
      
      // Valida faixas de latitude/longitude
      if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
        throw new Error('Valores fora da faixa válida');
      }
      
      // Define a nova localização
      const newLocation = { latitude, longitude };
      setLocation(newLocation);
      setMode(SELECTION_MODES.MANUAL_INPUT);
      
      // Centraliza o mapa na localização
      if (mapRef.current) {
        mapRef.current.animateToRegion({
          ...newLocation,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01
        });
      }
    } catch (error) {
      console.error('[LocationPicker] Erro na entrada manual:', error);
      Alert.alert(texts.manualInputError);
      onError('manual_input_error', error);
    }
  };
  
  /**
   * Alterna o tipo de mapa
   * @param {string} type - Novo tipo de mapa
   */
  const changeMapType = (type) => {
    setCurrentMapType(type);
  };
  
  /**
   * Renderiza o componente de busca
   * @returns {React.Component} Componente de busca
   */
  const renderSearch = () => {
    if (!allowSearch || !editable) return null;
    
    return (
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <TextInput
            ref={searchInputRef}
            style={styles.searchInput}
            placeholder={texts.searchPlaceholder}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setSearchResults([])}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity
              style={styles.clearSearchButton}
              onPress={() => {
                setSearchQuery('');
                setSearchResults([]);
              }}
            >
              <Icon
                name="x-circle"
                set={ICON_SETS.FEATHER}
                size={ICON_SIZES.SMALL}
                state={ICON_STATES.DEFAULT}
              />
            </TouchableOpacity>
          )}
          {searchingAddresses && (
            <ActivityIndicator size="small" color="#1E88E5" style={styles.searchingIndicator} />
          )}
        </View>
        
        {searchResults.length > 0 && (
          <View style={styles.searchResultsContainer}>
            <FlatList
              data={searchResults}
              keyExtractor={(item, index) => `search_result_${index}`}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.searchResultItem}
                  onPress={() => selectSearchResult(item)}
                >
                  <Icon
                    name="map-pin"
                    set={ICON_SETS.FEATHER}
                    size={ICON_SIZES.SMALL}
                    state={ICON_STATES.DEFAULT}
                    style={styles.searchResultIcon}
                  />
                  <Text style={styles.searchResultText}>{item.formattedAddress}</Text>
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={styles.searchResultSeparator} />}
              keyboardShouldPersistTaps="handled"
            />
          </View>
        )}
        
        {searchQuery.length > 2 && searchResults.length === 0 && !searchingAddresses && (
          <View style={styles.noResultsContainer}>
            <Text style={styles.noResultsText}>{texts.noSearchResults}</Text>
          </View>
        )}
      </View>
    );
  };
  
  /**
   * Renderiza os botões de ações
   * @returns {React.Component} Componente com botões de ações
   */
  const renderActions = () => {
    return (
      <View style={styles.actionsContainer}>
        {allowCurrentLocation && editable && (
          <TouchableOpacity
            style={styles.actionButton}
            onPress={getCurrentLocation}
            disabled={loadingLocation}
          >
            <Icon
              name="navigation"
              set={ICON_SETS.FEATHER}
              size={ICON_SIZES.SMALL}
              state={loadingLocation ? ICON_STATES.DISABLED : ICON_STATES.DEFAULT}
            />
            <Text style={[
              styles.actionButtonText,
              loadingLocation && styles.disabledText
            ]}>
              {loadingLocation ? texts.loadingLocation : texts.currentLocationButton}
            </Text>
          </TouchableOpacity>
        )}
        
        {allowManualInput && editable && (
          <TouchableOpacity
            style={styles.actionButton}
            onPress={openManualInputDialog}
          >
            <Icon
              name="edit-2"
              set={ICON_SETS.FEATHER}
              size={ICON_SIZES.SMALL}
              state={ICON_STATES.DEFAULT}
            />
            <Text style={styles.actionButtonText}>
              {texts.manualInputButton}
            </Text>
          </TouchableOpacity>
        )}
        
        {editable && (
          <TouchableOpacity
            style={[styles.confirmButton, !location && styles.disabledButton]}
            onPress={confirmLocation}
            disabled={!location}
          >
            <Icon
              name="check"
              set={ICON_SETS.FEATHER}
              size={ICON_SIZES.SMALL}
              state={!location ? ICON_STATES.DISABLED : ICON_STATES.SUCCESS}
              color="#fff"
            />
            <Text style={styles.confirmButtonText}>
              {texts.confirmButton}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };
  
  /**
   * Renderiza o seletor de tipo de mapa
   * @returns {React.Component} Componente de seletor de tipo de mapa
   */
  const renderMapTypeSelector = () => {
    if (!showMapTypeSelector) return null;
    
    return (
      <View style={styles.mapTypeContainer}>
        <TouchableOpacity
          style={[
            styles.mapTypeButton,
            currentMapType === MAP_TYPES.STANDARD && styles.mapTypeButtonActive
          ]}
          onPress={() => changeMapType(MAP_TYPES.STANDARD)}
        >
          <Text style={styles.mapTypeButtonText}>{texts.standardMap}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.mapTypeButton,
            currentMapType === MAP_TYPES.SATELLITE && styles.mapTypeButtonActive
          ]}
          onPress={() => changeMapType(MAP_TYPES.SATELLITE)}
        >
          <Text style={styles.mapTypeButtonText}>{texts.satelliteMap}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.mapTypeButton,
            currentMapType === MAP_TYPES.HYBRID && styles.mapTypeButtonActive
          ]}
          onPress={() => changeMapType(MAP_TYPES.HYBRID)}
        >
          <Text style={styles.mapTypeButtonText}>{texts.hybridMap}</Text>
        </TouchableOpacity>
        
        {Platform.OS === 'android' && (
          <TouchableOpacity
            style={[
              styles.mapTypeButton,
              currentMapType === MAP_TYPES.TERRAIN && styles.mapTypeButtonActive
            ]}
            onPress={() => changeMapType(MAP_TYPES.TERRAIN)}
          >
            <Text style={styles.mapTypeButtonText}>{texts.terrainMap}</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };
  
  /**
   * Renderiza o marcador central
   * @returns {React.Component} Componente de marcador central
   */
  const renderCenterMarker = () => {
    if (!editable || !allowMapSelection || !location) return null;
    
    return (
      <View style={styles.centerMarkerContainer}>
        <Icon
          name="map-pin"
          set={ICON_SETS.FEATHER}
          size={ICON_SIZES.MEDIUM}
          state={ICON_STATES.ACTIVE}
        />
      </View>
    );
  };
  
  /**
   * Renderiza informações da localização
   * @returns {React.Component} Componente com informações da localização
   */
  const renderLocationInfo = () => {
    if (!location) return null;
    
    return (
      <View style={styles.locationInfoContainer}>
        <View style={styles.addressContainer}>
          <Text style={styles.addressLabel}>
            {texts.addressLabel}
          </Text>
          {loadingAddress ? (
            <ActivityIndicator size="small" color="#1E88E5" />
          ) : (
            <Text style={styles.addressText}>
              {address || texts.noAddressFound}
            </Text>
          )}
        </View>
        
        <Text style={styles.coordinatesText}>
          {texts.latitudeLongitudeFormat
            .replace('{lat}', location.latitude.toFixed(6))
            .replace('{lng}', location.longitude.toFixed(6))
          }
        </Text>
      </View>
    );
  };
  
  return (
    <View style={[styles.container, containerStyle]}>
      {renderSearch()}
      
      <View style={[styles.mapContainer, { height: mapHeight, width: mapWidth }]}>
        {location ? (
          <MapView
            ref={mapRef}
            style={[styles.map, mapStyle]}
            provider={PROVIDER_GOOGLE}
            initialRegion={{
              ...location,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01
            }}
            mapType={currentMapType}
            onRegionChangeComplete={handleRegionChange}
            onPress={handleMapPress}
            scrollEnabled={editable}
            zoomEnabled={editable}
            rotateEnabled={editable}
            pitchEnabled={editable}
          >
            {mode !== SELECTION_MODES.MAP_SELECTION && (
              <Marker
                coordinate={location}
                draggable={editable}
                onDragEnd={(e) => {
                  setLocation(e.nativeEvent.coordinate);
                  setMode(SELECTION_MODES.MAP_SELECTION);
                }}
              />
            )}
          </MapView>
        ) : (
          <View style={styles.loadingContainer}>
            {loadingLocation ? (
              <>
                <ActivityIndicator size="large" color="#1E88E5" />
                <Text style={styles.loadingText}>{texts.loadingLocation}</Text>
              </>
            ) : (
              <Text style={styles.noLocationText}>
                {allowCurrentLocation ? texts.currentLocationButton : texts.searchPlaceholder}
              </Text>
            )}
          </View>
        )}
        
        {mode === SELECTION_MODES.MAP_SELECTION && renderCenterMarker()}
        {renderMapTypeSelector()}
      </View>
      
      {renderLocationInfo()}
      {renderActions()}
    </View>
  );
};

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    margin: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchContainer: {
    marginBottom: 12,
    zIndex: 10,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 4,
    paddingHorizontal: 8,
    backgroundColor: '#f5f5f5',
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: '#333',
  },
  clearSearchButton: {
    padding: 4,
  },
  searchingIndicator: {
    marginLeft: 8,
  },
  searchResultsContainer: {
    position: 'absolute',
    top: 45,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 4,
    maxHeight: 200,
    zIndex: 100,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  searchResultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  searchResultIcon: {
    marginRight: 8,
  },
  searchResultText: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  searchResultSeparator: {
    height: 1,
    backgroundColor: '#e0e0e0',
  },
  noResultsContainer: {
    padding: 10,
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
    marginTop: 4,
  },
  noResultsText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  mapContainer: {
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#f5f5f5',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  noLocationText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    padding: 20,
  },
  centerMarkerContainer: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginLeft: -12,
    marginTop: -24, // Offset para o pin apontar para o local correto
  },
  mapTypeContainer: {
    position: 'absolute',
    top: 10,
    right: 10,
    flexDirection: 'column',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 4,
    padding: 4,
  },
  mapTypeButton: {
    padding: 6,
    marginVertical: 2,
    borderRadius: 4,
  },
  mapTypeButtonActive: {
    backgroundColor: '#1E88E5',
  },
  mapTypeButtonText: {
    fontSize: 12,
    color: '#333',
    textAlign: 'center',
  },
  locationInfoContainer: {
    marginTop: 12,
    padding: 8,
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
  },
  addressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  addressLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginRight: 6,
  },
  addressText: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  coordinatesText: {
    fontSize: 12,
    color: '#666',
  },
  actionsContainer: {
    marginTop: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: 4,
    backgroundColor: '#f5f5f5',
  },
  actionButtonText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 6,
  },
  confirmButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 4,
    backgroundColor: '#1E88E5',
  },
  confirmButtonText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 6,
    fontWeight: 'bold',
  },
  disabledButton: {
    backgroundColor: '#bdbdbd',
  },
  disabledText: {
    color: '#757575',
  }
});

// Definição de PropTypes para documentação e validação
LocationPicker.propTypes = {
  initialLocation: PropTypes.shape({
    latitude: PropTypes.number.isRequired,
    longitude: PropTypes.number.isRequired
  }),
  defaultZoom: PropTypes.number,
  allowCurrentLocation: PropTypes.bool,
  allowSearch: PropTypes.bool,
  allowMapSelection: PropTypes.bool,
  allowManualInput: PropTypes.bool,
  mapType: PropTypes.oneOf(Object.values(MAP_TYPES)),
  searchDebounceTime: PropTypes.number,
  maxSearchResults: PropTypes.number,
  editable: PropTypes.bool,
  showMapTypeSelector: PropTypes.bool,
  containerStyle: PropTypes.object,
  mapHeight: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  mapWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  mapStyle: PropTypes.object,
  onLocationSelect: PropTypes.func,
  onLocationChange: PropTypes.func,
  onError: PropTypes.func,
  texts: PropTypes.object
};

// Exporta o componente e constantes
export { SELECTION_MODES, MAP_TYPES };
export default LocationPicker;