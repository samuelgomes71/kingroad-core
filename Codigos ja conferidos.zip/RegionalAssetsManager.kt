package com.kingfamily.common.utils

import android.content.Context
import android.os.Build
import android.telephony.TelephonyManager
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*

/**
 * Gerenciador de recursos visuais regionais para a família King.
 * Este gerenciador é responsável por detectar a região do usuário e fornecer
 * os caminhos corretos para os recursos regionais.
 */
class RegionalAssetsManager(private val context: Context) {

    companion object {
        private const val TAG = "RegionalAssetsManager"
        private const val CONFIG_FILE = "cdn_config.json"
        private const val DEFAULT_REGION = "global"
    }

    // Configurações regionais carregadas do arquivo JSON
    private var regionalSettings: JSONObject? = null
    
    // Região atual detectada ou definida
    private var currentRegion: String = DEFAULT_REGION

    /**
     * Inicializa o gerenciador de recursos regionais
     */
    init {
        try {
            loadConfig()
            if (isRegionalAssetsEnabled()) {
                if (shouldDetectRegionAutomatically()) {
                    detectRegion()
                } else {
                    currentRegion = getDefaultRegion()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao inicializar o gerenciador regional", e)
            currentRegion = DEFAULT_REGION
        }
    }

    /**
     * Carrega o arquivo de configuração do CDN
     */
    private fun loadConfig() {
        try {
            val inputStream = context.assets.open(CONFIG_FILE)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            reader.close()
            
            val config = JSONObject(jsonString)
            regionalSettings = config.optJSONObject("regional_settings")
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao carregar configuração regional", e)
            // Se falhar, inicializa com objeto vazio
            regionalSettings = JSONObject()
        }
    }

    /**
     * Verifica se os recursos regionais estão habilitados
     */
    private fun isRegionalAssetsEnabled(): Boolean {
        return regionalSettings?.optBoolean("enabled", false) ?: false
    }

    /**
     * Verifica se a detecção automática de região está habilitada
     */
    private fun shouldDetectRegionAutomatically(): Boolean {
        return regionalSettings?.optBoolean("detect_automatically", false) ?: false
    }

    /**
     * Obtém a região padrão configurada
     */
    private fun getDefaultRegion(): String {
        return regionalSettings?.optString("default_region", DEFAULT_REGION) ?: DEFAULT_REGION
    }

    /**
     * Detecta a região do usuário com base nas configurações do dispositivo
     */
    private fun detectRegion() {
        try {
            // Tenta obter a região com base no país da operadora
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            var countryCode = tm.networkCountryIso
            
            // Se não conseguir, tenta obter com base na localidade
            if (countryCode.isNullOrEmpty()) {
                countryCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    context.resources.configuration.locales[0].country
                } else {
                    @Suppress("DEPRECATION")
                    context.resources.configuration.locale.country
                }
            }
            
            // Se ainda não conseguir, usa o padrão
            if (countryCode.isNullOrEmpty()) {
                currentRegion = getDefaultRegion()
                return
            }
            
            // Converte o código do país para a região configurada
            currentRegion = mapCountryCodeToRegion(countryCode.lowercase(Locale.getDefault()))
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao detectar região", e)
            currentRegion = getDefaultRegion()
        }
    }

    /**
     * Mapeia um código de país para uma região configurada
     */
    private fun mapCountryCodeToRegion(countryCode: String): String {
        try {
            val regions = regionalSettings?.optJSONArray("regions")
            if (regions != null) {
                for (i in 0 until regions.length()) {
                    val region = regions.getJSONObject(i)
                    val code = region.optString("code", "")
                    
                    // Verifica se o código de país corresponde diretamente à região
                    if (code.equals(countryCode, ignoreCase = true)) {
                        return code
                    }
                    
                    // Para Europa e Ásia, verifica listas de países
                    when (code) {
                        "eu" -> {
                            val euCountries = arrayOf("at", "be", "bg", "hr", "cy", "cz", "dk", "ee", "fi", "fr", 
                                                     "de", "gr", "hu", "ie", "it", "lv", "lt", "lu", "mt", "nl", 
                                                     "pl", "pt", "ro", "sk", "si", "es", "se")
                            if (euCountries.contains(countryCode)) {
                                return "eu"
                            }
                        }
                        "asia" -> {
                            val asiaCountries = arrayOf("jp", "cn", "kr", "in", "id", "my", "ph", "sg", "th", "vn")
                            if (asiaCountries.contains(countryCode)) {
                                return "asia"
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao mapear código de país para região", e)
        }
        
        // Se não encontrar correspondência, retorna a região padrão
        return getDefaultRegion()
    }

    /**
     * Obtém o prefixo do caminho para a região atual
     */
    fun getRegionalPathPrefix(): String {
        try {
            val regions = regionalSettings?.optJSONArray("regions")
            if (regions != null) {
                for (i in 0 until regions.length()) {
                    val region = regions.getJSONObject(i)
                    val code = region.optString("code", "")
                    
                    if (code.equals(currentRegion, ignoreCase = true)) {
                        return region.optString("path_prefix", "global")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao obter prefixo de caminho regional", e)
        }
        
        return "global"
    }

    /**
     * Obtém o código da região atual
     */
    fun getCurrentRegion(): String {
        return currentRegion
    }

    /**
     * Define manualmente a região
     */
    fun setRegion(regionCode: String) {
        try {
            val regions = regionalSettings?.optJSONArray("regions")
            if (regions != null) {
                for (i in 0 until regions.length()) {
                    val region = regions.getJSONObject(i)
                    val code = region.optString("code", "")
                    
                    if (code.equals(regionCode, ignoreCase = true)) {
                        currentRegion = code
                        return
                    }
                }
            }
            
            // Se a região não for encontrada, mantém a atual
            Log.w(TAG, "Região não encontrada: $regionCode")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao definir região", e)
        }
    }

    /**
     * Constrói o caminho regional para um recurso
     */
    fun buildRegionalResourcePath(basePath: String): String {
        if (!isRegionalAssetsEnabled()) {
            return basePath
        }
        
        val regionalPrefix = getRegionalPathPrefix()
        return "$regionalPrefix/$basePath"
    }
}