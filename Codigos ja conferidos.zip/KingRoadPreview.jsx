// Modificação para o KingRoadPreview.jsx
// Adicionar no início da função do componente:

const KingRoadPreview = ({ 
  destinationData, 
  customerID, 
  searchMethod = 'customerid',
  onConfirm,
  onCancel
}) => {
  // ... código existente ...
  
  // Inicializar o searchInput com o customerID se fornecido
  const [searchInput, setSearchInput] = useState(customerID || '');
  
  // Inicializar dados do destino se fornecidos
  useEffect(() => {
    if (destinationData) {
      setDestinationSelected(true);
      // Se há coordenadas ajustadas, usar como posição inicial
      if (destinationData.adjustedCoordinates) {
        setAdjustedMarker(destinationData.adjustedCoordinates);
        setIsAdjusting(true);
      }
    }
  }, [destinationData]);
  
  // Modifique as funções de confirmação/cancelamento para chamar os callbacks
  const handleConfirmRoute = () => {
    if (onConfirm) {
      onConfirm(adjustedMarker);
    }
  };
  
  const handleCancelRoute = () => {
    if (onCancel) {
      onCancel();
    }
  };
  
  // No JSX do botão de confirmação, substitua o onClick por:
  // onClick={handleConfirmRoute}
  
  // No JSX do botão de cancelamento, substitua o onClick por:
  // onClick={handleCancelRoute}
}
Agora, para integrar isso ao fluxo de navegação, você precisa atualizar o arquivo de rotas ou navegação principal para direcionar para esta tela quando um destino for selecionado:
jsxCopy// Em seu arquivo de navegação (por exemplo, Navigator.jsx)
// Importe a nova tela
import RouteConfirmationScreen from './screens/RouteConfirmationScreen';

// Adicione a rota ao navegador
<Stack.Navigator>
  {/* Outras rotas */}
  <Stack.Screen 
    name="RouteConfirmation" 
    component={RouteConfirmationScreen} 
    options={{ headerShown: false }}
  />
  {/* Rota de navegação */}
  <Stack.Screen 
    name="NavigationScreen" 
    component={NavigationScreen} 
    options={{ headerShown: false }}
  />
</Stack.Navigator>

// Nos componentes que iniciam a navegação (busca, seleção de destino, etc.)
// Redirecione para a tela de confirmação em vez de ir direto para navegação
navigation.navigate('RouteConfirmation', {
  destination: {
    name: 'Nome do destino',
    address: 'Endereço completo',
    coordinates: { latitude: 12.3456, longitude: -65.4321 }
  },
  customerID: 'KELMON',
  searchMethod: 'customerid' // ou 'address', 'map', etc.
});