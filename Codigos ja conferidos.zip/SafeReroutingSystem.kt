// Sistema de Recálculo Seguro de Rotas
// app/src/main/kotlin/com/kingroad/routing/safe

class SafeReroutingManager(
    private val routeService: RouteService,
    private val restrictionService: RestrictionService,
    private val infrastructureService: InfrastructureService,
    private val emergencyService: EmergencyService
) {
    data class RouteDeviation(
        val currentLocation: Location,
        val originalRoute: Route,
        val vehicle: Vehicle,
        val cargo: CargoType,
        val deviationTimestamp: Long
    )

    // Configurações de segurança
    data class SafetyConfig(
        val minRoadWidth: Double,           // Largura mínima da via
        val minHeight: Double,              // Altura mínima segura
        val minTurningRadius: Double,       // Raio mínimo de curva
        val maxIncline: Double,             // Inclinação máxima
        val requiresHazmatRoute: Boolean,   // Rota para produtos perigosos
        val requiresWideLoad: Boolean       // Rota para carga excedente
    )

    suspend fun handleRouteDeviation(deviation: RouteDeviation): Route {
        // Iniciar protocolo de segurança
        val safetyConfig = createSafetyConfig(deviation.vehicle, deviation.cargo)
        
        // Identificar zona de risco imediato
        val dangerZone = assessImmediateSurroundings(
            location = deviation.currentLocation,
            vehicle = deviation.vehicle
        )
        
        // Se estiver em zona de risco, calcular rota de escape
        if (dangerZone.isUnsafe) {
            return calculateEscapeRoute(
                from = deviation.currentLocation,
                dangerZone = dangerZone,
                safetyConfig = safetyConfig
            )
        }

        // Calcular nova rota segura
        return calculateSafeRoute(
            from = deviation.currentLocation,
            to = deviation.originalRoute.destination,
            safetyConfig = safetyConfig
        )
    }

    private suspend fun calculateSafeRoute(
        from: Location,
        to: Location,
        safetyConfig: SafetyConfig
    ): Route {
        // Lista de vias seguras principais
        val mainRoads = infrastructureService.findMainRoads(
            area = calculateSearchArea(from, to),
            minWidth = safetyConfig.minRoadWidth,
            minHeight = safetyConfig.minHeight
        )

        // Calcular rota usando apenas vias seguras
        return routeService.calculateRoute(
            start = from,
            end = to,
            restrictions = createRestrictions(safetyConfig),
            preferences = RoutePreferences(
                preferHighways = true,
                avoidResidentialAreas = true,
                prioritizeTruckRoutes = true,
                allowedRoads = mainRoads
            )
        )
    }

    private suspend fun calculateEscapeRoute(
        from: Location,
        dangerZone: DangerZone,
        safetyConfig: SafetyConfig
    ): Route {
        // Encontrar ponto seguro mais próximo
        val safePoint = findNearestSafePoint(
            from = from,
            dangerZone = dangerZone,
            safetyConfig = safetyConfig
        )

        // Criar rota de emergência para ponto seguro
        return routeService.calculateEmergencyRoute(
            start = from,
            end = safePoint,
            restrictions = createRestrictions(safetyConfig),
            priority = RoutePriority.SAFETY_FIRST
        )
    }

    private suspend fun assessImmediateSurroundings(
        location: Location,
        vehicle: Vehicle
    ): DangerZone {
        val hazards = infrastructureService.scanArea(
            center = location,
            radius = 500.0 // metros
        )

        return DangerZone(
            isUnsafe = hazards.any { it.isCritical(vehicle) },
            hazards = hazards,
            safeExits = findSafeExits(location, hazards, vehicle)
        )
    }

    private fun createSafetyConfig(vehicle: Vehicle, cargo: CargoType): SafetyConfig {
        return SafetyConfig(
            minRoadWidth = vehicle.width * 2.0,
            minHeight = vehicle.height + SAFETY_MARGIN_HEIGHT,
            minTurningRadius = vehicle.turningRadius * 1.2,
            maxIncline = if (cargo == CargoType.HEAVY) 5.0 else 8.0,
            requiresHazmatRoute = cargo == CargoType.HAZARDOUS,
            requiresWideLoad = cargo == CargoType.OVERSIZED
        )
    }

    private fun createRestrictions(config: SafetyConfig): List<Restriction> {
        return listOf(
            HeightRestriction(config.minHeight),
            WidthRestriction(config.minRoadWidth),
            TurningRadiusRestriction(config.minTurningRadius),
            InclineRestriction(config.maxIncline),
            ResidentialAreaRestriction(false),
            if (config.requiresHazmatRoute) HazmatRestriction() else null,
            if (config.requiresWideLoad) WideLoadRestriction() else null
        ).filterNotNull()
    }

    companion object {
        const val SAFETY_MARGIN_HEIGHT = 0.5 // metros
        const val MINIMUM_SAFE_WIDTH = 3.5 // metros
        const val EMERGENCY_RADIUS = 5000.0 // metros
    }
}

// Classes de suporte
data class DangerZone(
    val isUnsafe: Boolean,
    val hazards: List<Hazard>,
    val safeExits: List<SafeExit>
)

data class Hazard(
    val type: HazardType,
    val location: Location,
    val severity: Severity
) {
    fun isCritical(vehicle: Vehicle): Boolean {
        return when (type) {
            HazardType.LOW_CLEARANCE -> height < vehicle.height
            HazardType.NARROW_ROAD -> width < vehicle.width * 1.5
            HazardType.TIGHT_TURN -> radius < vehicle.turningRadius
            HazardType.POWER_LINES -> height < vehicle.height + 1.0
            HazardType.DEAD_END -> true
        }
    }
}

enum class HazardType {
    LOW_CLEARANCE,
    NARROW_ROAD,
    TIGHT_TURN,
    POWER_LINES,
    DEAD_END
}

enum class Severity {
    CRITICAL,    // Risco imediato
    HIGH,        // Risco significativo
    MODERATE,    // Requer atenção
    LOW          // Monitorar
}