/**
 * FeedbackLogService.js
 * 
 * Service to manage user feedback and application logs in the KingRoad app.
 * Handles collecting, storing, and uploading user feedback and system logs.
 * Supports automatic upload and synchronization when connectivity is available.
 * 
 * @author KingRoad Development Team
 * @version 1.0.0
 */

import { Platform, DeviceInfo, AppState } from 'react-native';
import ApiService from './ApiService';
import OfflineCacheManager from './OfflineCacheManager';
import LogService from './LogService';
import UserService from './UserService';
import { TranslationsService } from './TranslationsService';

// Singleton instance
let instance = null;

class FeedbackLogService {
  constructor() {
    if (instance) {
      return instance;
    }
    
    // Feedback and logs state
    this.state = {
      pendingFeedback: [],     // User feedback waiting to be uploaded
      pendingLogs: [],         // System logs waiting to be uploaded
      isUploading: false,      // If currently uploading
      lastUploadAttempt: null, // Timestamp of last upload attempt
      lastSuccessfulUpload: null, // Timestamp of last successful upload
      uploadScheduled: false,  // If an upload is scheduled
      appStateListener: null,  // App state listener
    };
    
    // Feedback and logs configuration
    this.config = {
      autoUploadEnabled: true,         // Automatically upload when online
      logUploadEnabled: true,          // Upload system logs
      uploadInterval: 30 * 60 * 1000,  // 30 minutes between uploads
      maxPendingFeedback: 50,          // Maximum number of feedback items to store
      maxPendingLogs: 1000,            // Maximum number of log entries to store
      logCategories: [                 // Log categories to capture
        'error',
        'warning',
        'navigation',
        'api',
        'performance',
        'user_action'
      ],
      criticalLogCategories: [         // Log categories that trigger immediate upload
        'error',
        'crash'
      ],
      deviceInfoToCollect: [           // Device information to include with uploads
        'brand',
        'model',
        'systemVersion',
        'appVersion',
        'screenResolution',
        'batteryLevel',
        'totalMemory',
        'availableStorage'
      ],
    };
    
    // Connection listener
    this.connectionListener = null;
    
    // Initialize
    this.init();
    
    instance = this;
  }
  
  /**
   * Initialize the service
   */
  async init() {
    try {
      // Load saved state
      const pendingFeedback = await OfflineCacheManager.getItem('pending_feedback');
      if (pendingFeedback) {
        this.state.pendingFeedback = JSON.parse(pendingFeedback);
      }
      
      const pendingLogs = await OfflineCacheManager.getItem('pending_logs');
      if (pendingLogs) {
        this.state.pendingLogs = JSON.parse(pendingLogs);
      }
      
      // Load saved configuration
      const savedConfig = await OfflineCacheManager.getItem('feedback_log_config');
      if (savedConfig) {
        this.config = { ...this.config, ...JSON.parse(savedConfig) };
      }
      
      // Register listeners
      this.registerListeners();
      
      // Schedule automatic upload if enabled
      if (this.config.autoUploadEnabled) {
        this.scheduleUpload();
      }
      
      // Subscribe to log service
      LogService.subscribe(this.onLogEntry.bind(this));
      
      LogService.debug('FeedbackLogService initialized');
    } catch (error) {
      LogService.error('Error initializing FeedbackLogService:', error);
    }
  }
  
  /**
   * Register event listeners
   */
  registerListeners() {
    // Listen for connectivity changes
    this.connectionListener = OfflineCacheManager.addConnectionListener(
      async (connected) => {
        if (connected && this.config.autoUploadEnabled) {
          // Try to upload when connection is restored
          if (this.hasPendingData()) {
            await this.uploadPendingData();
          }
        }
      }
    );
    
    // Listen for app state changes
    this.state.appStateListener = AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'active') {
        // App has come to the foreground
        // Check if we need to upload data
        if (
          this.config.autoUploadEnabled &&
          this.hasPendingData() &&
          !this.state.isUploading &&
          !this.state.uploadScheduled
        ) {
          this.scheduleUpload();
        }
      }
    });
  }
  
  /**
   * Unregister event listeners
   */
  unregisterListeners() {
    if (this.connectionListener) {
      OfflineCacheManager.removeConnectionListener(this.connectionListener);
    }
    
    if (this.state.appStateListener) {
      this.state.appStateListener.remove();
    }
    
    // Unsubscribe from log service
    LogService.unsubscribe(this.onLogEntry.bind(this));
  }
  
  /**
   * Save pending feedback to storage
   */
  async savePendingFeedback() {
    try {
      await OfflineCacheManager.setItem(
        'pending_feedback',
        JSON.stringify(this.state.pendingFeedback)
      );
    } catch (error) {
      LogService.error('Error saving pending feedback:', error);
    }
  }
  
  /**
   * Save pending logs to storage
   */
  async savePendingLogs() {
    try {
      await OfflineCacheManager.setItem(
        'pending_logs',
        JSON.stringify(this.state.pendingLogs)
      );
    } catch (error) {
      LogService.error('Error saving pending logs:', error);
    }
  }
  
  /**
   * Save configuration to storage
   */
  async saveConfig() {
    try {
      await OfflineCacheManager.setItem(
        'feedback_log_config',
        JSON.stringify(this.config)
      );
    } catch (error) {
      LogService.error('Error saving feedback and logs config:', error);
    }
  }
  
  /**
   * Update configuration
   * @param {Object} newConfig - New configuration values
   * @returns {Object} Updated configuration
   */
  async updateConfig(newConfig) {
    this.config = {
      ...this.config,
      ...newConfig,
    };
    
    // Apply new configuration
    if (newConfig.autoUploadEnabled && this.hasPendingData() && !this.state.uploadScheduled) {
      this.scheduleUpload();
    }
    
    await this.saveConfig();
    return this.config;
  }
  
  /**
   * Get configuration
   * @returns {Object} Current configuration
   */
  getConfig() {
    return { ...this.config };
  }
  
  /**
   * Submit user feedback
   * @param {Object} feedback - Feedback data
   * @returns {Object} Submitted feedback with status
   */
  async submitFeedback(feedback) {
    try {
      // Create feedback object
      const feedbackItem = {
        id: `feedback_${Date.now()}`,
        timestamp: Date.now(),
        type: feedback.type || 'general',
        category: feedback.category || 'other',
        rating: feedback.rating || null,
        message: feedback.message || '',
        email: feedback.email || '',
        screenshots: feedback.screenshots || [],
        metadata: feedback.metadata || {},
        deviceInfo: await this.collectDeviceInfo(),
        status: 'pending',
        uploaded: false,
      };
      
      // Add to pending feedback
      this.addToPendingFeedback(feedbackItem);
      
      // Try to upload immediately if online
      if (this.config.autoUploadEnabled && await OfflineCacheManager.isConnected()) {
        this.uploadPendingData();
      } else if (this.config.autoUploadEnabled) {
        this.scheduleUpload();
      }
      
      return feedbackItem;
    } catch (error) {
      LogService.error('Error submitting feedback:', error);
      throw error;
    }
  }
  
  /**
   * Add feedback to pending list
   * @param {Object} feedback - Feedback item
   */
  addToPendingFeedback(feedback) {
    this.state.pendingFeedback.push(feedback);
    
    // Limit size
    if (this.state.pendingFeedback.length > this.config.maxPendingFeedback) {
      this.state.pendingFeedback = this.state.pendingFeedback.slice(
        this.state.pendingFeedback.length - this.config.maxPendingFeedback
      );
    }
    
    this.savePendingFeedback();
  }
  
  /**
   * Handle log entry from LogService
   * @param {Object} logEntry - Log entry
   */
  onLogEntry(logEntry) {
    // Skip if log uploads are disabled
    if (!this.config.logUploadEnabled) {
      return;
    }
    
    // Check if this category should be captured
    if (this.config.logCategories.includes(logEntry.category)) {
      this.addToPendingLogs(logEntry);
      
      // Check if this is a critical log
      if (
        this.config.criticalLogCategories.includes(logEntry.category) &&
        this.config.autoUploadEnabled
      ) {
        // Try to upload immediately or schedule for later
        if (this.state.isUploading) {
          // Already uploading, will be included
        } else if (this.state.uploadScheduled) {
          // Already scheduled, but let's expedite it
          this.cancelScheduledUpload();
          this.scheduleUpload(true); // Immediate upload
        } else {
          this.scheduleUpload(true); // Immediate upload
        }
      }
    }
  }

  /**
   * Add log entry to pending logs
   * @param {Object} logEntry - Log entry
   */
  addToPendingLogs(logEntry) {
    this.state.pendingLogs.push(logEntry);
    
    // Limit size
    if (this.state.pendingLogs.length > this.config.maxPendingLogs) {
      this.state.pendingLogs = this.state.pendingLogs.slice(
        this.state.pendingLogs.length - this.config.maxPendingLogs
      );
    }
    
    this.savePendingLogs();
  }
  
  /**
   * Check if there is any pending data to upload
   * @returns {boolean} True if there is pending data
   */
  hasPendingData() {
    return this.state.pendingFeedback.length > 0 || this.state.pendingLogs.length > 0;
  }
  
  /**
   * Schedule an upload of pending data
   * @param {boolean} immediate - If true, upload immediately instead of using interval
   */
  scheduleUpload(immediate = false) {
    if (this.state.uploadScheduled) {
      return;
    }
    
    if (immediate) {
      this.state.uploadScheduled = true;
      setTimeout(() => {
        this.uploadPendingData();
      }, 0);
    } else {
      this.state.uploadScheduled = true;
      setTimeout(() => {
        this.uploadPendingData();
      }, this.config.uploadInterval);
    }
  }
  
  /**
   * Cancel any scheduled upload
   */
  cancelScheduledUpload() {
    this.state.uploadScheduled = false;
  }
  
  /**
   * Upload all pending feedback and logs
   * @returns {Object} Upload results
   */
  async uploadPendingData() {
    if (this.state.isUploading || !this.hasPendingData()) {
      return {
        success: false,
        message: this.state.isUploading 
          ? 'Upload already in progress' 
          : 'No pending data to upload',
      };
    }
    
    // Reset scheduled flag
    this.state.uploadScheduled = false;
    
    // Check connectivity
    const isConnected = await OfflineCacheManager.isConnected();
    if (!isConnected) {
      // Reschedule for later
      this.scheduleUpload();
      
      return {
        success: false,
        message: 'No internet connection available',
      };
    }
    
    try {
      this.state.isUploading = true;
      this.state.lastUploadAttempt = Date.now();
      
      const results = {
        success: true,
        feedbackUploaded: 0,
        logsUploaded: 0,
        feedbackFailed: 0,
        logsFailed: 0,
        errors: [],
      };
      
      // Upload feedback
      if (this.state.pendingFeedback.length > 0) {
        const feedbackResults = await this.uploadFeedback();
        results.feedbackUploaded = feedbackResults.uploaded;
        results.feedbackFailed = feedbackResults.failed;
        results.errors = results.errors.concat(feedbackResults.errors);
      }
      
      // Upload logs
      if (this.state.pendingLogs.length > 0 && this.config.logUploadEnabled) {
        const logResults = await this.uploadLogs();
        results.logsUploaded = logResults.uploaded;
        results.logsFailed = logResults.failed;
        results.errors = results.errors.concat(logResults.errors);
      }
      
      // Update last successful upload time if any data was uploaded
      if (results.feedbackUploaded > 0 || results.logsUploaded > 0) {
        this.state.lastSuccessfulUpload = Date.now();
      }
      
      this.state.isUploading = false;
      
      // Schedule next upload if we still have pending data
      if (this.hasPendingData() && this.config.autoUploadEnabled) {
        this.scheduleUpload();
      }
      
      return results;
    } catch (error) {
      this.state.isUploading = false;
      
      // Schedule retry
      if (this.config.autoUploadEnabled) {
        this.scheduleUpload();
      }
      
      LogService.error('Error uploading feedback and logs:', error);
      
      return {
        success: false,
        message: error.message,
        error: error,
      };
    }
  }
  
  /**
   * Upload pending feedback
   * @returns {Object} Upload results
   */
  async uploadFeedback() {
    const results = {
      uploaded: 0,
      failed: 0,
      errors: [],
    };
    
    const remainingFeedback = [];
    
    for (const feedback of this.state.pendingFeedback) {
      try {
        // Upload any screenshots first
        const screenshotUrls = [];
        if (feedback.screenshots && feedback.screenshots.length > 0) {
          for (const screenshot of feedback.screenshots) {
            try {
              const response = await ApiService.uploadImage('/feedback/screenshots', screenshot);
              screenshotUrls.push(response.url);
            } catch (error) {
              LogService.error('Error uploading feedback screenshot:', error);
              // Continue with other screenshots
            }
          }
        }
        
        // Upload feedback with screenshot URLs
        const feedbackToUpload = {
          ...feedback,
          screenshots: screenshotUrls,
        };
        
        const response = await ApiService.post('/feedback', feedbackToUpload);
        
        results.uploaded++;
      } catch (error) {
        results.failed++;
        results.errors.push({
          id: feedback.id,
          error: error.message,
        });
        
        // Keep in the pending list
        remainingFeedback.push(feedback);
      }
    }
    
    // Update pending feedback
    this.state.pendingFeedback = remainingFeedback;
    await this.savePendingFeedback();
    
    return results;
  }
  
  /**
   * Upload pending logs
   * @returns {Object} Upload results
   */
  async uploadLogs() {
    const results = {
      uploaded: 0,
      failed: 0,
      errors: [],
    };
    
    try {
      // Group logs into batches
      const batchSize = 100;
      const batches = [];
      
      for (let i = 0; i < this.state.pendingLogs.length; i += batchSize) {
        batches.push(this.state.pendingLogs.slice(i, i + batchSize));
      }
      
      // Upload each batch
      for (const batch of batches) {
        try {
          const response = await ApiService.post('/logs', {
            logs: batch,
            deviceInfo: await this.collectDeviceInfo(),
            appInfo: {
              version: DeviceInfo.getVersion(),
              buildNumber: DeviceInfo.getBuildNumber(),
            },
          });
          
          results.uploaded += batch.length;
        } catch (error) {
          results.failed += batch.length;
          results.errors.push({
            batchSize: batch.length,
            error: error.message,
          });
          
          // Keep these logs in the pending list
          throw error; // Re-throw to stop processing batches
        }
      }
      
      // Clear uploaded logs
      this.state.pendingLogs = [];
      await this.savePendingLogs();
    } catch (error) {
      // Keep remaining logs (those not in successful batches)
      this.state.pendingLogs = this.state.pendingLogs.slice(results.uploaded);
      await this.savePendingLogs();
    }
    
    return results;
  }
  
  /**
   * Collect device information
   * @returns {Object} Device information
   */
  async collectDeviceInfo() {
    const deviceInfo = {
      platform: Platform.OS,
      version: Platform.Version,
      brand: DeviceInfo.getBrand(),
      model: DeviceInfo.getModel(),
      appVersion: DeviceInfo.getVersion(),
      buildNumber: DeviceInfo.getBuildNumber(),
      uniqueId: DeviceInfo.getUniqueId(),
      timestamp: Date.now(),
    };
    
    // Additional information if available
    try {
      if (this.config.deviceInfoToCollect.includes('batteryLevel')) {
        deviceInfo.batteryLevel = await DeviceInfo.getBatteryLevel();
      }
      
      if (this.config.deviceInfoToCollect.includes('totalMemory')) {
        deviceInfo.totalMemory = await DeviceInfo.getTotalMemory();
      }
      
      if (this.config.deviceInfoToCollect.includes('availableStorage')) {
        deviceInfo.availableStorage = await DeviceInfo.getFreeDiskStorage();
      }
      
      if (this.config.deviceInfoToCollect.includes('screenResolution')) {
        deviceInfo.screenWidth = DeviceInfo.getWindowWidth();
        deviceInfo.screenHeight = DeviceInfo.getWindowHeight();
      }
    } catch (error) {
      LogService.error('Error collecting device info:', error);
    }
    
    return deviceInfo;
  }
  
  /**
   * Get pending feedback
   * @returns {Array} Pending feedback
   */
  getPendingFeedback() {
    return [...this.state.pendingFeedback];
  }
  
  /**
   * Get pending logs
   * @returns {Array} Pending logs
   */
  getPendingLogs() {
    return [...this.state.pendingLogs];
  }
  
  /**
   * Get upload status
   * @returns {Object} Upload status
   */
  getUploadStatus() {
    return {
      isUploading: this.state.isUploading,
      lastUploadAttempt: this.state.lastUploadAttempt,
      lastSuccessfulUpload: this.state.lastSuccessfulUpload,
      uploadScheduled: this.state.uploadScheduled,
      pendingFeedbackCount: this.state.pendingFeedback.length,
      pendingLogsCount: this.state.pendingLogs.length,
    };
  }
  
  /**
   * Force upload of pending data
   * @returns {Object} Upload results
   */
  forceUpload() {
    this.cancelScheduledUpload();
    return this.uploadPendingData();
  }
  
  /**
   * Clear all pending feedback
   */
  async clearPendingFeedback() {
    this.state.pendingFeedback = [];
    await this.savePendingFeedback();
  }
  
  /**
   * Clear all pending logs
   */
  async clearPendingLogs() {
    this.state.pendingLogs = [];
    await this.savePendingLogs();
  }
  
  /**
   * Clean up resources
   */
  destroy() {
    this.unregisterListeners();
    this.cancelScheduledUpload();
  }
}

export default new FeedbackLogService();