import React, { useState } from 'react';
import { AlertTriangle, ChevronUp, ChevronDown, CornerUpRight, Map } from 'lucide-react';

const RouteWarningDialog = ({ analysis = { hazards: [] }, onConfirm, onReject, country, region }) => {
  const [showDetails, setShowDetails] = useState(false);

  // Verifica se analysis existe e tem hazards
  if (!analysis || !analysis.hazards) {
    return null;
  }

  const getRegionalMaxGrade = (country, region) => {
    if (country === 'CH') return 12.0;  // Suíça
    if (country === 'CA' && region === 'QC') return 14.0;  // Quebec
    if (country === 'CA') return 11.0;  // Resto do Canadá
    return 10.0;  // Outros países
  };

  const getHazardIcon = (type) => {
    switch (type) {
      case 'STEEP_ASCENT': return <ChevronUp className="w-6 h-6 text-red-500" />;
      case 'STEEP_DESCENT': return <ChevronDown className="w-6 h-6 text-red-500" />;
      case 'HAIRPIN_TURN': return <CornerUpRight className="w-6 h-6 text-red-500" />;
      case 'SHARP_TURN': return <Map className="w-6 h-6 text-yellow-500" />;
      default: return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
    }
  };

  const getHazardClass = (type) => {
    switch (type) {
      case 'STEEP_ASCENT':
      case 'STEEP_DESCENT':
      case 'HAIRPIN_TURN':
        return 'border-l-4 border-red-500';
      case 'SHARP_TURN':
        return 'border-l-4 border-yellow-500';
      default:
        return 'border-l-4 border-gray-300';
    }
  };

  // Contagem segura de hazards
  const hazardCounts = {
    steepAscents: analysis.hazards.filter(h => h.type === 'STEEP_ASCENT').length || 0,
    steepDescents: analysis.hazards.filter(h => h.type === 'STEEP_DESCENT').length || 0,
    hairpinTurns: analysis.hazards.filter(h => h.type === 'HAIRPIN_TURN').length || 0,
    sharpTurns: analysis.hazards.filter(h => h.type === 'SHARP_TURN').length || 0
  };

  const maxGrade = getRegionalMaxGrade(country, region);
  const regionName = region ? `${country} - ${region}` : country;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6">
        <div className="flex items-center space-x-2 mb-4 border-b pb-4">
          <AlertTriangle className="w-8 h-8 text-red-500" />
          <h2 className="text-xl font-bold">Atenção: Rota com Trechos Perigosos</h2>
        </div>

        <div className="text-sm text-gray-600 mb-4">
          <p>Limite de inclinação para {regionName}: {maxGrade}%</p>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <span className="font-medium text-lg">Resumo dos riscos:</span>
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              {showDetails ? 'Ocultar Detalhes' : 'Ver Detalhes'}
            </button>
          </div>

          {showDetails ? (
            <div className="space-y-3 mt-4 max-h-96 overflow-y-auto">
              {analysis.hazards.map((hazard, index) => (
                <div 
                  key={index}
                  className={`flex items-start space-x-3 p-3 bg-gray-50 rounded ${getHazardClass(hazard.type)}`}
                >
                  {getHazardIcon(hazard.type)}
                  <div className="flex-1">
                    <p className="font-medium">{hazard.description || 'Trecho perigoso'}</p>
                    <p className="text-sm text-gray-600">
                      Localização: km {hazard.location ? (hazard.location.distance / 1000).toFixed(1) : '?'}
                    </p>
                    {hazard.severity > 0 && (
                      <div className="mt-1 w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            hazard.severity > 120 ? 'bg-red-500' :
                            hazard.severity > 100 ? 'bg-orange-500' : 'bg-yellow-500'
                          }`}
                          style={{ width: `${Math.min(100, hazard.severity)}%` }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-2 bg-gray-50 p-4 rounded">
              {hazardCounts.steepAscents > 0 && (
                <div className="flex items-center space-x-2">
                  <ChevronUp className="w-5 h-5 text-red-500" />
                  <p>{hazardCounts.steepAscents} subida{hazardCounts.steepAscents > 1 ? 's' : ''} íngreme{hazardCounts.steepAscents > 1 ? 's' : ''}</p>
                </div>
              )}
              {hazardCounts.steepDescents > 0 && (
                <div className="flex items-center space-x-2">
                  <ChevronDown className="w-5 h-5 text-red-500" />
                  <p>{hazardCounts.steepDescents} descida{hazardCounts.steepDescents > 1 ? 's' : ''} íngreme{hazardCounts.steepDescents > 1 ? 's' : ''}</p>
                </div>
              )}
              {hazardCounts.hairpinTurns > 0 && (
                <div className="flex items-center space-x-2">
                  <CornerUpRight className="w-5 h-5 text-red-500" />
                  <p>{hazardCounts.hairpinTurns} curva{hazardCounts.hairpinTurns > 1 ? 's' : ''} cotovelo</p>
                </div>
              )}
              {hazardCounts.sharpTurns > 0 && (
                <div className="flex items-center space-x-2">
                  <Map className="w-5 h-5 text-yellow-500" />
                  <p>{hazardCounts.sharpTurns} curva{hazardCounts.sharpTurns > 1 ? 's' : ''} fechada{hazardCounts.sharpTurns > 1 ? 's' : ''}</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-4 pt-4 border-t">
          <button
            onClick={onReject}
            className="px-6 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
          >
            Calcular Nova Rota
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition-colors"
          >
            Prosseguir Mesmo Assim
          </button>
        </div>
      </div>
    </div>
  );
};

// Valores padrão para as props
RouteWarningDialog.defaultProps = {
  analysis: {
    hazards: []
  },
  onConfirm: () => {},
  onReject: () => {},
  country: 'DEFAULT',
  region: null
};

export default RouteWarningDialog;