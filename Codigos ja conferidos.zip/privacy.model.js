// privacy.model.js
// Modelo de dados para configurações de privacidade no KingChat

const mongoose = require('mongoose');

const PrivacySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  readReceiptOption: {
    type: String,
    enum: ['all', 'selected', 'none'],
    default: 'all'
  },
  selectedContactsForReadReceipts: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  groupAdditionOption: {
    type: String,
    enum: ['all', 'selected', 'none'],
    default: 'all'
  },
  selectedContactsForGroupAddition: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }]
}, {
  timestamps: true
});

// Índice para melhorar performance em buscas por userId
PrivacySchema.index({ userId: 1 });

module.exports = mongoose.model('Privacy', PrivacySchema);