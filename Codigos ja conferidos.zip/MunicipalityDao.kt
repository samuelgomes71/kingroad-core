package com.kingroad.database.dao

import androidx.room.*
import com.kingroad.reports.Municipality
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Interface DAO para acessar a tabela de municípios
 */
@Dao
interface MunicipalityDao {
    
    /**
     * Insere um novo município
     * @param municipality Município a ser inserido
     * @return ID do município inserido
     */
    @Insert
    suspend fun insert(municipality: Municipality): Long
    
    /**
     * Insere vários municípios de uma vez
     * @param municipalities Lista de municípios a serem inseridos
     */
    @Insert
    suspend fun insertAll(municipalities: List<Municipality>)
    
    /**
     * Atualiza um município existente
     * @param municipality O município atualizado
     */
    @Update
    suspend fun update(municipality: Municipality)
    
    /**
     * Remove um município
     * @param municipality O município a ser removido
     */
    @Delete
    suspend fun delete(municipality: Municipality)
    
    /**
     * Busca um município pelo ID
     * @param id ID do município
     * @return O município encontrado ou null
     */
    @Query("SELECT * FROM municipalities WHERE id = :id")
    suspend fun findById(id: String): Municipality?
    
    /**
     * Busca um município pelo nome
     * @param name Nome do município
     * @param country País do município (opcional)
     * @return Lista de municípios com o nome especificado
     */
    @Query("SELECT * FROM municipalities WHERE name LIKE :name || '%' AND (:country IS NULL OR country = :country)")
    suspend fun findByName(name: String, country: String? = null): List<Municipality>
    
    /**
     * Busca municípios por país
     * @param country País
     * @return Lista de municípios do país especificado
     */
    @Query("SELECT * FROM municipalities WHERE country = :country")
    suspend fun findByCountry(country: String): List<Municipality>
    
    /**
     * Busca um município baseado na localização (coordenadas)
     * Este é um método simplificado. Em um sistema real, seria necessário
     * um algoritmo mais complexo usando polígonos para fronteiras.
     * 
     * @param latitude Latitude
     * @param longitude Longitude
     * @return O município correspondente ou null
     */
    @Query("""
        SELECT * FROM municipalities 
        WHERE (EXISTS (
            SELECT 1 FROM municipality_boundaries 
            WHERE municipality_id = municipalities.id 
            AND contains_point(:latitude, :longitude)
        ))
        LIMIT 1
    """)
    suspend fun findByLocation(latitude: Double, longitude: Double): Municipality?
    
    /**
     * Busca municípios com integração de API
     * @return Lista de municípios com endpoint de API configurado
     */
    @Query("SELECT * FROM municipalities WHERE api_endpoint IS NOT NULL AND api_endpoint != ''")
    suspend fun findWithApiIntegration(): List<Municipality>
    
    /**
     * Busca municípios com integração de redes sociais
     * @return Lista de municípios com redes sociais configuradas
     */
    @Query("SELECT * FROM municipalities WHERE social_media_handles IS NOT NULL AND social_media_handles != '{}'")
    suspend fun findWithSocialMedia(): List<Municipality>
    
    /**
     * Conta o número de municípios por país
     * @return Map de país para contagem
     */
    @Query("SELECT country, COUNT(*) as count FROM municipalities GROUP BY country")
    suspend fun countByCountry(): Map<String, Int>
    
    /**
     * Atualiza o endpoint da API de um município
     * @param municipalityId ID do município
     * @param apiEndpoint Novo endpoint de API
     */
    @Query("UPDATE municipalities SET api_endpoint = :apiEndpoint WHERE id = :municipalityId")
    suspend fun updateApiEndpoint(municipalityId: String, apiEndpoint: String)
    
    /**
     * Atualiza as redes sociais de um município
     * @param municipalityId ID do município
     * @param socialMediaHandles Novas redes sociais
     */
    @Query("UPDATE municipalities SET social_media_handles = :socialMediaHandles WHERE id = :municipalityId")
    suspend fun updateSocialMediaHandles(municipalityId: String, socialMediaHandles: String)
}

/**
 * Função para verificar se um polígono contém um ponto
 * Esta é uma função SQLite personalizada que seria implementada
 * em um sistema real para verificar se um ponto está dentro 
 * de um polígono (fronteira municipal)
 */
class ContainsPointFunction : SQLiteFunction {
    override fun name(): String = "contains_point"
    
    override fun behavior(): Int = SQLiteFunction.Behavior.DETERMINISTIC
    
    override fun arguments(): Int = 2
    
    override fun apply(args: Array<Any?>): Any? {
        if (args.size != 2 || args[0] == null || args[1] == null) {
            return false
        }
        
        val latitude = (args[0] as Double)
        val longitude = (args[1] as Double)
        
        // Em uma implementação real, aqui teríamos um algoritmo para verificar
        // se um ponto está dentro de um polígono (algoritmo ray-casting ou similar)
        
        // Para o mock, sempre retorna true
        return true
    }
}

/**
 * Conversores para tipos complexos
 */
class MunicipalityConverters {
    private val json = Json { ignoreUnknownKeys = true }
    
    @TypeConverter
    fun fromPolygonPoints(points: List<Pair<Double, Double>>): String = json.encodeToString(points)
    
    @TypeConverter
    fun toPolygonPoints(value: String): List<Pair<Double, Double>> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)
    
    @TypeConverter
    fun fromMapStringString(map: Map<String, String>): String = json.encodeToString(map)
    
    @TypeConverter
    fun toMapStringString(value: String): Map<String, String> = 
        if (value.isBlank()) emptyMap() else json.decodeFromString(value)
}