// AddBrazilSecurityAlert.jsx
import React, { useState } from 'react';
import { XCircle, Send, MapPin } from 'lucide-react';
import { Button, Select, MenuItem, TextField, FormControl, InputLabel, FormGroup, FormControlLabel, Checkbox, Radio, RadioGroup } from '@/components/ui';

/**
 * Componente para adicionar um novo alerta de segurança específico para o Brasil
 */
const AddBrazilSecurityAlert = ({ onClose, onSubmit, userLocation }) => {
  // Estado do formulário
  const [alertType, setAlertType] = useState('');
  const [description, setDescription] = useState('');
  const [formData, setFormData] = useState({
    // Campos para tiroteio
    shootingIntensity: 'MEDIUM',
    involvedGroups: '',
    estimatedDuration: '',
    
    // Campos para sequestro/arrastão
    kidnapType: 'MASS_ROBBERY',
    vehiclesCount: '',
    victimsCount: '',
    
    // Campos para roubo de carga
    isBlockingRoad: false,
    weaponsPresent: false,
    cargoVehiclesCount: '',
    isTargetingSpecificCargo: false,
    targetedCargoType: '',
    
    // Campos para veículo suspeito
    vehicleModel: '',
    vehicleColor: '',
    licensePlate: '',
    suspiciousActivity: 'FOLLOWING_TRUCKS',
    occupantsCount: '',
    direction: '',
    
    // Campos para veículo em alta velocidade
    speedingVehicleModel: '',
    speedingVehicleColor: '',
    speedingLicensePlate: '',
    estimatedSpeed: '',
    isDrivingDangerously: false,
    speedingDirection: '',
    dangerousManeuvers: []
  });
  
  // Manipula mudança no tipo de alerta
  const handleAlertTypeChange = (e) => {
    setAlertType(e.target.value);
  };
  
  // Manipula mudanças nos campos do formulário
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (type === 'checkbox') {
      setFormData({
        ...formData,
        [name]: checked
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };
  
  // Manipula seleção/deseleção de manobras perigosas
  const handleManeuverChange = (maneuver) => {
    const currentManeuvers = formData.dangerousManeuvers;
    
    if (currentManeuvers.includes(maneuver)) {
      setFormData({
        ...formData,
        dangerousManeuvers: currentManeuvers.filter(m => m !== maneuver)
      });
    } else {
      setFormData({
        ...formData,
        dangerousManeuvers: [...currentManeuvers, maneuver]
      });
    }
  };
  
  // Manipula envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Construir objeto de alerta com base no tipo
    let alertData = {
      type: alertType,
      description: description,
      timestamp: new Date().toISOString()
    };
    
    // Adicionar campos específicos dependendo do tipo de alerta
    switch (alertType) {
      case 'SHOOTING':
        alertData.shootingInfo = {
          intensity: formData.shootingIntensity,
          isOngoing: true,
          involvedGroups: formData.involvedGroups ? formData.involvedGroups.split(',').map(g => g.trim()) : [],
          estimatedDuration: formData.estimatedDuration ? parseInt(formData.estimatedDuration) : null
        };
        break;
        
      case 'KIDNAPPING':
        alertData.kidnappingInfo = {
          kidnapType: formData.kidnapType,
          isOngoing: true,
          vehiclesCount: formData.vehiclesCount ? parseInt(formData.vehiclesCount) : null,
          victimsCount: formData.victimsCount ? parseInt(formData.victimsCount) : null
        };
        break;
        
      case 'CARGO_THEFT':
        alertData.cargoTheftInfo = {
          isBlockingRoad: formData.isBlockingRoad,
          weaponsPresent: formData.weaponsPresent,
          vehiclesCount: formData.cargoVehiclesCount ? parseInt(formData.cargoVehiclesCount) : null,
          isTargetingSpecificCargo: formData.isTargetingSpecificCargo,
          targetedCargoType: formData.targetedCargoType || null
        };
        break;
        
      case 'SUSPICIOUS_VEHICLE':
        alertData.suspiciousVehicleInfo = {
          vehicleModel: formData.vehicleModel || null,
          vehicleColor: formData.vehicleColor || null,
          licensePlate: formData.licensePlate || null,
          suspiciousActivity: formData.suspiciousActivity,
          occupantsCount: formData.occupantsCount ? parseInt(formData.occupantsCount) : null,
          direction: formData.direction || null
        };
        break;
        
      case 'SPEEDING_VEHICLE':
        alertData.speedingVehicleInfo = {
          vehicleModel: formData.speedingVehicleModel || null,
          vehicleColor: formData.speedingVehicleColor || null,
          licensePlate: formData.speedingLicensePlate || null,
          estimatedSpeed: formData.estimatedSpeed ? parseInt(formData.estimatedSpeed) : null,
          isDrivingDangerously: formData.isDrivingDangerously,
          direction: formData.speedingDirection || null,
          dangerousManeuvers: formData.dangerousManeuvers.length > 0 ? formData.dangerousManeuvers : null
        };
        break;
    }
    
    // Enviar para o componente pai
    onSubmit(alertData);
  };
  
  // Renderiza campos específicos baseados no tipo de alerta selecionado
  const renderTypeSpecificFields = () => {
    switch (alertType) {
      case 'SHOOTING':
        return (
          <div className="shooting-fields">
            <FormControl fullWidth margin="normal">
              <InputLabel>Intensidade</InputLabel>
              <Select
                name="shootingIntensity"
                value={formData.shootingIntensity}
                onChange={handleInputChange}
              >
                <MenuItem value="LOW">Baixa (poucos disparos)</MenuItem>
                <MenuItem value="MEDIUM">Média (troca de tiros intensa)</MenuItem>
                <MenuItem value="HIGH">Alta (confronto generalizado)</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              fullWidth
              margin="normal"
              name="involvedGroups"
              label="Grupos envolvidos (separados por vírgula)"
              value={formData.involvedGroups}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="estimatedDuration"
              label="Duração estimada (em minutos)"
              type="number"
              value={formData.estimatedDuration}
              onChange={handleInputChange}
            />
          </div>
        );
        
      case 'KIDNAPPING':
        return (
          <div className="kidnapping-fields">
            <FormControl fullWidth margin="normal">
              <InputLabel>Tipo de Ocorrência</InputLabel>
              <Select
                name="kidnapType"
                value={formData.kidnapType}
                onChange={handleInputChange}
              >
                <MenuItem value="KIDNAPPING">Sequestro</MenuItem>
                <MenuItem value="FLASH_KIDNAP">Sequestro Relâmpago</MenuItem>
                <MenuItem value="MASS_ROBBERY">Arrastão</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              fullWidth
              margin="normal"
              name="vehiclesCount"
              label="Quantidade de veículos"
              type="number"
              value={formData.vehiclesCount}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="victimsCount"
              label="Quantidade de vítimas (estimada)"
              type="number"
              value={formData.victimsCount}
              onChange={handleInputChange}
            />
          </div>
        );
        
      case 'CARGO_THEFT':
        return (
          <div className="cargo-theft-fields">
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    name="isBlockingRoad"
                    checked={formData.isBlockingRoad}
                    onChange={handleInputChange}
                  />
                }
                label="Está bloqueando a rodovia"
              />
              
              <FormControlLabel
                control={
                  <Checkbox
                    name="weaponsPresent"
                    checked={formData.weaponsPresent}
                    onChange={handleInputChange}
                  />
                }
                label="Presença de armamento"
              />
              
              <FormControlLabel
                control={
                  <Checkbox
                    name="isTargetingSpecificCargo"
                    checked={formData.isTargetingSpecificCargo}
                    onChange={handleInputChange}
                  />
                }
                label="Alvo específico de carga"
              />
            </FormGroup>
            
            <TextField
              fullWidth
              margin="normal"
              name="cargoVehiclesCount"
              label="Quantidade de veículos"
              type="number"
              value={formData.cargoVehiclesCount}
              onChange={handleInputChange}
            />
            
            {formData.isTargetingSpecificCargo && (
              <TextField
                fullWidth
                margin="normal"
                name="targetedCargoType"
                label="Tipo de carga alvo"
                value={formData.targetedCargoType}
                onChange={handleInputChange}
              />
            )}
          </div>
        );
        
      case 'SUSPICIOUS_VEHICLE':
        return (
          <div className="suspicious-vehicle-fields">
            <TextField
              fullWidth
              margin="normal"
              name="vehicleModel"
              label="Modelo do veículo"
              value={formData.vehicleModel}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="vehicleColor"
              label="Cor do veículo"
              value={formData.vehicleColor}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="licensePlate"
              label="Placa (se visível)"
              value={formData.licensePlate}
              onChange={handleInputChange}
            />
            
            <FormControl fullWidth margin="normal">
              <InputLabel>Atividade Suspeita</InputLabel>
              <Select
                name="suspiciousActivity"
                value={formData.suspiciousActivity}
                onChange={handleInputChange}
              >
                <MenuItem value="FOLLOWING_TRUCKS">Seguindo caminhões</MenuItem>
                <MenuItem value="MONITORING_ROAD">Monitorando a estrada</MenuItem>
                <MenuItem value="SUSPICIOUS_STOPS">Paradas suspeitas</MenuItem>
                <MenuItem value="FAKE_POLICE">Falsa blitz/polícia</MenuItem>
                <MenuItem value="SUSPICIOUS_COMMUNICATION">Comunicações suspeitas</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              fullWidth
              margin="normal"
              name="occupantsCount"
              label="Número de ocupantes"
              type="number"
              value={formData.occupantsCount}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="direction"
              label="Direção (ex: sentido norte, sul, etc.)"
              value={formData.direction}
              onChange={handleInputChange}
            />
          </div>
        );
        
      case 'SPEEDING_VEHICLE':
        return (
          <div className="speeding-vehicle-fields">
            <TextField
              fullWidth
              margin="normal"
              name="speedingVehicleModel"
              label="Modelo do veículo"
              value={formData.speedingVehicleModel}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="speedingVehicleColor"
              label="Cor do veículo"
              value={formData.speedingVehicleColor}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="speedingLicensePlate"
              label="Placa (se visível)"
              value={formData.speedingLicensePlate}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="estimatedSpeed"
              label="Velocidade estimada (km/h)"
              type="number"
              value={formData.estimatedSpeed}
              onChange={handleInputChange}
            />
            
            <TextField
              fullWidth
              margin="normal"
              name="speedingDirection"
              label="Direção (ex: sentido norte, sul, etc.)"
              value={formData.speedingDirection}
              onChange={handleInputChange}
            />
            
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    name="isDrivingDangerously"
                    checked={formData.isDrivingDangerously}
                    onChange={handleInputChange}
                  />
                }
                label="Dirigindo perigosamente"
              />
            </FormGroup>
            
            {formData.isDrivingDangerously && (
              <div className="mt-3">
                <p className="font-medium mb-2">Manobras perigosas:</p>
                <FormGroup>
                  {[
                    { value: 'ZIGZAGGING', label: 'Ziguezague entre veículos' },
                    { value: 'TAILGATING', label: 'Cola na traseira' },
                    { value: 'HARD_BRAKING', label: 'Freadas bruscas' },
                    { value: 'WRONG_WAY', label: 'Contramão' },
                    { value: 'SHOULDER_DRIVING', label: 'Dirigindo pelo acostamento' },
                    { value: 'RACING', label: 'Correndo/fazendo racha' }
                  ].map(maneuver => (
                    <FormControlLabel
                      key={maneuver.value}
                      control={
                        <Checkbox
                          checked={formData.dangerousManeuvers.includes(maneuver.value)}
                          onChange={() => handleManeuverChange(maneuver.value)}
                        />
                      }
                      label={maneuver.label}
                    />
                  ))}
                </FormGroup>
              </div>
            )}
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="add-alert-modal fixed inset-0 z-40 flex items-center justify-center">
      {/* Overlay escuro */}
      <div className="fixed inset-0 bg-black bg-opacity-75" onClick={onClose}></div>
      
      {/* Formulário */}
      <div className="add-alert-content relative w-full max-w-lg bg-gray-900 text-white p-6 rounded-lg shadow-lg z-10 mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Reportar Incidente</h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <XCircle size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit}>
          {/* Localização atual */}
          <div className="location-info flex items-center mb-4 p-3 bg-gray-800 rounded">
            <MapPin className="text-amber-500 mr-2" />
            <div>
              <p className="text-sm text-gray-300">Sua localização atual:</p>
              <p>
                {userLocation.lat.toFixed(5)}, {userLocation.lng.toFixed(5)}
              </p>
            </div>
          </div>
          
          {/* Tipo de alerta */}
          <FormControl fullWidth margin="normal" required>
            <InputLabel>Tipo de Incidente</InputLabel>
            <Select
              value={alertType}
              onChange={handleAlertTypeChange}
            >
              <MenuItem value="SHOOTING">Tiroteio</MenuItem>
              <MenuItem value="KIDNAPPING">Sequestro/Arrastão</MenuItem>
              <MenuItem value="CARGO_THEFT">Roubo de Carga</MenuItem>
              <MenuItem value="SUSPICIOUS_VEHICLE">Veículo Suspeito</MenuItem>
              <MenuItem value="SPEEDING_VEHICLE">Veículo em Alta Velocidade</MenuItem>
            </Select>
          </FormControl>
          
          {/* Descrição geral */}
          <TextField
            fullWidth
            margin="normal"
            label="Descrição (opcional)"
            multiline
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          
          {/* Campos específicos baseados no tipo selecionado */}
          {alertType && renderTypeSpecificFields()}
          
          {/* Botões de ação */}
          <div className="flex justify-end mt-6 space-x-3">
            <Button 
              onClick={onClose}
              type="button"
              className="bg-gray-700 hover:bg-gray-600"
            >
              Cancelar
            </Button>
            
            <Button 
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-black font-bold"
              disabled={!alertType}
            >
              <Send size={16} className="mr-2" />
              Reportar
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddBrazilSecurityAlert;