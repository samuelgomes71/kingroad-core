import React, { useState, useEffect } from 'react';

// Enum interno para categorias de tamanho de dispositivo
const DeviceSize = {
  EXTRA_SMALL: 'xs', // ~6 polegadas
  SMALL: 'sm',       // ~7-8 polegadas
  MEDIUM: 'md',      // ~9-10 polegadas
  LARGE: 'lg'        // ~11-12 polegadas
};

const AppDownloadSection = () => {
  const [deviceSize, setDeviceSize] = useState(null);
  const [downloadInfo, setDownloadInfo] = useState(null);
  const [showAdvancedInfo, setShowAdvancedInfo] = useState(false);
  
  // Detecta o tamanho do dispositivo com base na largura da tela
  const detectDeviceSize = () => {
    const width = window.innerWidth;
    
    if (width < 600) return DeviceSize.EXTRA_SMALL;
    if (width < 900) return DeviceSize.SMALL;
    if (width < 1200) return DeviceSize.MEDIUM;
    return DeviceSize.LARGE;
  };
  
  // Calcula o tamanho aproximado de download do aplicativo
  const getAppDownloadSize = (size) => {
    // Tamanhos de download aproximados para cada categoria de dispositivo
    const baseSizeInMB = 25; // Tamanho base do aplicativo sem recursos específicos
    
    const additionalSizeMap = {
      [DeviceSize.EXTRA_SMALL]: 5,  // +5MB para recursos de tela pequena
      [DeviceSize.SMALL]: 8,        // +8MB para recursos de tela média-pequena
      [DeviceSize.MEDIUM]: 12,      // +12MB para recursos de tela média
      [DeviceSize.LARGE]: 15        // +15MB para recursos de alta resolução
    };
    
    const totalSizeInMB = baseSizeInMB + additionalSizeMap[size];
    
    return {
      deviceSize: size,
      baseSizeInMB,
      additionalResourcesInMB: additionalSizeMap[size],
      totalSizeInMB,
      formattedSize: `${totalSizeInMB} MB`
    };
  };
  
  // Gera a URL de download para a versão correta do aplicativo
  const getAppDownloadUrl = (size) => {
    const baseUrl = 'https://download.kingroad.app';
    return `${baseUrl}/kingroad-${size}-latest.apk`;
  };
  
  // Coleta informações sobre o dispositivo
  const getDeviceInfo = () => {
    return {
      size: detectDeviceSize(),
      width: window.innerWidth,
      height: window.innerHeight,
      pixelRatio: window.devicePixelRatio || 1,
      userAgent: navigator.userAgent,
      isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
      isAndroid: /Android/i.test(navigator.userAgent),
      isIOS: /iPhone|iPad|iPod/i.test(navigator.userAgent)
    };
  };
  
  useEffect(() => {
    // Detecta o tamanho do dispositivo ao carregar o componente
    const size = detectDeviceSize();
    setDeviceSize(size);
    setDownloadInfo(getAppDownloadSize(size));
    
    // Adiciona um listener para atualizar em caso de redimensionamento
    const handleResize = () => {
      const newSize = detectDeviceSize();
      if (newSize !== deviceSize) {
        setDeviceSize(newSize);
        setDownloadInfo(getAppDownloadSize(newSize));
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [deviceSize]);
  
  // Só renderiza quando as informações estiverem disponíveis
  if (!deviceSize || !downloadInfo) return null;
  
  // Mapeia o tamanho do dispositivo para um texto amigável
  const deviceSizeText = {
    [DeviceSize.EXTRA_SMALL]: 'smartphone compacto',
    [DeviceSize.SMALL]: 'smartphone grande',
    [DeviceSize.MEDIUM]: 'tablet médio',
    [DeviceSize.LARGE]: 'tablet grande'
  };
  
  // Mapeia o tamanho do dispositivo para o caminho do logo correto
  const logoPath = {
    [DeviceSize.EXTRA_SMALL]: '/assets/logos/kingroad-logo-xs.png',
    [DeviceSize.SMALL]: '/assets/logos/kingroad-logo-sm.png',
    [DeviceSize.MEDIUM]: '/assets/logos/kingroad-logo-md.png',
    [DeviceSize.LARGE]: '/assets/logos/kingroad-logo-lg.png'
  };

  return (
    <div className="bg-gray-900 rounded-lg p-6 max-w-3xl mx-auto shadow-lg border border-gray-800">
      <div className="flex flex-col md:flex-row items-center mb-6">
        <div className="md:mr-6 mb-4 md:mb-0 flex-shrink-0">
          <img 
            src={logoPath[deviceSize]} 
            alt="KingRoad Logo" 
            className="w-32 h-32 object-contain"
          />
        </div>
        
        <div>
          <h2 className="text-2xl font-bold text-yellow-500 mb-2">
            KingRoad - Navegação GPS para Caminhoneiros
          </h2>
          
          <p className="text-gray-300 mb-3">
            Identificamos que você está usando um <strong>{deviceSizeText[deviceSize]}</strong>. 
            Oferecemos um download otimizado para seu dispositivo!
          </p>
          
          <div className="bg-gray-800 p-3 rounded-md mb-4">
            <div className="flex items-center mb-2">
              <svg className="w-5 h-5 text-yellow-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
              <span className="text-gray-300 text-sm">
                Tamanho do download: <strong>{downloadInfo.formattedSize}</strong>
              </span>
            </div>
            
            <div className="flex items-center">
              <svg className="w-5 h-5 text-yellow-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
              </svg>
              <span className="text-gray-300 text-sm">
                Versão otimizada para <strong>{deviceSizeText[deviceSize]}</strong>
              </span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col items-center">
        <button 
          className="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-3 px-8 rounded-md shadow-lg mb-4 w-full md:w-auto transition-colors duration-200 flex items-center justify-center"
          onClick={() => window.location.href = getAppDownloadUrl(deviceSize)}
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
          </svg>
          Baixar KingRoad para {deviceSizeText[deviceSize]}
        </button>
        
        <button 
          className="text-gray-400 text-sm hover:text-yellow-500 underline"
          onClick={() => setShowAdvancedInfo(!showAdvancedInfo)}
        >
          {showAdvancedInfo ? 'Ocultar detalhes técnicos' : 'Mostrar detalhes técnicos'}
        </button>
      </div>
      
      {/* Informações técnicas avançadas */}
      {showAdvancedInfo && (
        <div className="mt-6 bg-gray-800 rounded-md p-4 text-sm text-gray-300">
          <h3 className="text-yellow-500 font-bold mb-2">Detalhes técnicos:</h3>
          <pre className="bg-gray-900 p-3 rounded overflow-x-auto">
            {JSON.stringify(getDeviceInfo(), null, 2)}
          </pre>
          <p className="mt-2 text-xs text-gray-400">
            Estas informações ajudam a garantir que você receba a versão do KingRoad
            mais otimizada para seu dispositivo.
          </p>
        </div>
      )}
    </div>
  );
};

export default AppDownloadSection;