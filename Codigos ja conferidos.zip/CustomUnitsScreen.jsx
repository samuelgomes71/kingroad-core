import React, { useState } from 'react';
import { ChevronLeft, Check } from 'lucide-react';

// Valores padrão para preferências
const defaultPreferences = {
  speed: 'KPH',
  distance: 'KILOMETERS',
  exitDistance: 'METERS',
  weight: 'METRIC',
  height: 'METERS'
};

const CustomUnitsScreen = ({ 
  onBack = () => {}, 
  onSave = () => {}, 
  currentPreferences = defaultPreferences 
}) => {
  const [preferences, setPreferences] = useState(currentPreferences);

  const unitOptions = {
    speed: [
      { value: 'KPH', label: 'Kilometers per hour (km/h)' },
      { value: 'MPH', label: 'Miles per hour (mph)' }
    ],
    distance: [
      { value: 'KILOMETERS', label: 'Kilometers (km)' },
      { value: 'MILES', label: 'Miles (mi)' },
      { value: 'YARDS', label: 'Yards (yd)' }
    ],
    exitDistance: [
      { value: 'METERS', label: 'Meters (m)' },
      { value: 'YARDS', label: 'Yards (yd)' },
      { value: 'FEET', label: 'Feet (ft)' }
    ]
  };

  const UnitSelector = ({ 
    title, 
    options, 
    value, 
    onChange,
    description 
  }) => (
    <div className="mb-6">
      <h3 className="text-white text-lg mb-2">{title}</h3>
      {description && (
        <p className="text-gray-400 text-sm mb-3">{description}</p>
      )}
      <div className="space-y-2">
        {options.map(option => (
          <button
            key={option.value}
            className={`w-full p-4 flex items-center justify-between rounded-lg ${
              value === option.value ? 'bg-blue-600' : 'bg-[#1E1E1E]'
            }`}
            onClick={() => onChange(option.value)}
          >
            <span className="text-white">{option.label}</span>
            {value === option.value && (
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <Check size={16} className="text-blue-600" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );

  // Funções de formatação com verificação de valores
  const formatSpeed = (value, unit = 'KPH') => {
    const numValue = Number(value) || 0;
    switch (unit) {
      case 'MPH':
        return `${Math.round(numValue * 0.621371)} mph`;
      default:
        return `${numValue} km/h`;
    }
  };

  const formatDistance = (value, unit = 'KILOMETERS') => {
    const numValue = Number(value) || 0;
    switch (unit) {
      case 'MILES':
        return `${Math.round(numValue * 0.621371)} mi`;
      case 'YARDS':
        return `${Math.round(numValue * 1093.61)} yd`;
      default:
        return `${numValue} km`;
    }
  };

  const formatExitDistance = (value, unit = 'METERS') => {
    const numValue = Number(value) || 0;
    switch (unit) {
      case 'YARDS':
        return `${Math.round(numValue * 1.09361)} yd`;
      case 'FEET':
        return `${Math.round(numValue * 3.28084)} ft`;
      default:
        return `${numValue} m`;
    }
  };

  return (
    <div className="h-screen bg-[#121212]">
      {/* Header */}
      <div className="flex items-center p-4 bg-[#1E1E1E]">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="text-white" size={24} />
        </button>
        <h1 className="text-white text-xl ml-2">Custom Units</h1>
      </div>

      {/* Content */}
      <div className="p-4 overflow-y-auto">
        <UnitSelector
          title="Speed Display"
          description="Choose how speed will be shown"
          options={unitOptions.speed}
          value={preferences.speed}
          onChange={(value) => setPreferences({
            ...preferences,
            speed: value
          })}
        />

        <UnitSelector
          title="Distance Display"
          description="Choose how route distances will be shown"
          options={unitOptions.distance}
          value={preferences.distance}
          onChange={(value) => setPreferences({
            ...preferences,
            distance: value
          })}
        />

        <UnitSelector
          title="Exit Distance Display"
          description="Choose how exit distances will be shown"
          options={unitOptions.exitDistance}
          value={preferences.exitDistance}
          onChange={(value) => setPreferences({
            ...preferences,
            exitDistance: value
          })}
        />

        {/* Preview */}
        <div className="mt-6 p-4 bg-[#1E1E1E] rounded-lg">
          <h3 className="text-white font-medium mb-3">Preview</h3>
          <div className="space-y-2 text-gray-300">
            <div>Speed: {formatSpeed(80, preferences.speed)}</div>
            <div>Route Distance: {formatDistance(150, preferences.distance)}</div>
            <div>Next Exit: {formatExitDistance(500, preferences.exitDistance)}</div>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#1E1E1E]">
        <button
          onClick={() => onSave(preferences)}
          className="w-full bg-blue-600 text-white p-4 rounded-lg font-bold"
        >
          Save Preferences
        </button>
      </div>
    </div>
  );
};

export default CustomUnitsScreen;