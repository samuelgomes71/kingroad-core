import React, { useState } from 'react';

const FacilityFeaturesSelector = () => {
  const [selectedFeatures, setSelectedFeatures] = useState(['RESTROOMS', 'FUEL', 'SECURITY_SURVEILLANCE']);
  const [activeCategory, setActiveCategory] = useState('BASIC');
  
  // Categorias de recursos
  const categories = [
    { id: 'BASIC', label: 'Básico', icon: '🏠' },
    { id: 'SERVICES', label: 'Serviços', icon: '🔧' },
    { id: 'SECURITY', label: 'Segurança', icon: '🔒' },
    { id: 'AMENITIES', label: 'Comodidades', icon: '☕' }
  ];
  
  // Recursos por categoria
  const featuresByCategory = {
    BASIC: [
      { value: 'RESTROOMS', label: 'Banheiros', icon: '🚻' },
      { value: 'SHOWERS', label: 'Chuveiros', icon: '🚿' },
      { value: 'WATER_SUPPLY', label: 'Abastecimento de Água', icon: '💧' },
      { value: 'TRASH_DISPOSAL', label: 'Descarte de Lixo', icon: '🗑️' },
      { value: 'WIFI', label: 'Wi-Fi', icon: '📶' }
    ],
    SERVICES: [
      { value: 'FUEL', label: 'Combustível', icon: '⛽' },
      { value: 'ELECTRIC_CHARGING', label: 'Carregamento Elétrico', icon: '🔌' },
      { value: 'TRUCK_WASH', label: 'Lavagem', icon: '🚿' },
      { value: 'REPAIR_SERVICE', label: 'Oficina', icon: '🔧' },
      { value: 'TRUCK_SCALES', label: 'Balança', icon: '⚖️' }
    ],
    SECURITY: [
      { value: 'SECURITY_SURVEILLANCE', label: 'Vigilância', icon: '📹' },
      { value: 'SECURITY_PERSONNEL', label: 'Segurança', icon: '👮' },
      { value: 'FENCED_AREA', label: 'Área Cercada', icon: '🔒' },
      { value: 'LIGHTED_AREA', label: 'Área Iluminada', icon: '💡' }
    ],
    AMENITIES: [
      { value: 'RESTAURANT', label: 'Restaurante', icon: '🍽️' },
      { value: 'CONVENIENCE_STORE', label: 'Loja', icon: '🏪' },
      { value: 'ATM', label: 'Caixa Eletrônico', icon: '💰' },
      { value: 'LAUNDRY', label: 'Lavanderia', icon: '👕' },
      { value: 'LOUNGE', label: 'Sala de Descanso', icon: '🛋️' },
      { value: 'HOTEL_NEARBY', label: 'Hotel Próximo', icon: '🏨' }
    ]
  };
  
  // Alternar a seleção de um recurso
  const toggleFeature = (feature) => {
    if (selectedFeatures.includes(feature)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== feature));
    } else {
      setSelectedFeatures([...selectedFeatures, feature]);
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto bg-gray-50 rounded-lg">
      <h3 className="font-semibold mb-3">Recursos Disponíveis</h3>
      
      {/* Seleção de categoria */}
      <div className="flex mb-4 border-b border-gray-200">
        {categories.map(category => (
          <button
            key={category.id}
            className={`flex items-center px-3 py-2 mr-2 ${
              activeCategory === category.id 
                ? 'border-b-2 border-blue-500 text-blue-600' 
                : 'text-gray-500'
            }`}
            onClick={() => setActiveCategory(category.id)}
          >
            <span className="mr-1">{category.icon}</span>
            <span>{category.label}</span>
          </button>
        ))}
      </div>
      
      {/* Features da categoria selecionada */}
      <div className="flex flex-wrap mb-6">
        {featuresByCategory[activeCategory].map(feature => (
          <button
            key={feature.value}
            className={`flex items-center p-2 m-1 rounded-lg ${
              selectedFeatures.includes(feature.value)
                ? 'bg-blue-100 border border-blue-500 text-blue-700'
                : 'bg-white border border-gray-200 text-gray-700'
            }`}
            onClick={() => toggleFeature(feature.value)}
          >
            <span className="mr-2">{feature.icon}</span>
            <span className="text-sm">{feature.label}</span>
          </button>
        ))}
      </div>
      
      {/* Recursos selecionados */}
      {selectedFeatures.length > 0 && (
        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">
            Recursos selecionados ({selectedFeatures.length})
          </h4>
          <div className="flex flex-wrap bg-white p-3 rounded-lg border border-gray-200">
            {selectedFeatures.map(feature => {
              // Encontra o recurso em todas as categorias
              let featureInfo = null;
              for (const categoryId in featuresByCategory) {
                const found = featuresByCategory[categoryId].find(f => f.value === feature);
                if (found) {
                  featureInfo = found;
                  break;
                }
              }
              
              return featureInfo ? (
                <div 
                  key={feature}
                  className="flex items-center bg-blue-50 text-blue-600 rounded-full px-3 py-1 text-sm m-1"
                >
                  <span className="mr-1">{featureInfo.icon}</span>
                  <span>{featureInfo.label}</span>
                  <button 
                    className="ml-2 text-xs text-blue-700 hover:text-blue-900"
                    onClick={() => toggleFeature(feature)}
                  >
                    ✕
                  </button>
                </div>
              ) : null;
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default FacilityFeaturesSelector;