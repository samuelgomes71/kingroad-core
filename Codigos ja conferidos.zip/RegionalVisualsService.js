/**
 * RegionalVisualsService.js
 * 
 * Serviço para gerenciar visuais regionais no sistema KingRoad.
 * Responsável por gerenciar splash screens regionais, ícones SVG e temas conforme mencionado no relatório.
 */

import { TranslationsService } from './TranslationsService';
import { NavigationService } from './NavigationService';

class RegionalVisualsService {
  constructor() {
    this.translations = TranslationsService.getInstance();
    this.navigationService = NavigationService.getInstance();
    this.currentRegion = null;
    this.currentTheme = 'light'; // padrão: tema claro
    this.lastLocationCheck = 0;
    this.regionChangeListeners = [];
    this.themeChangeListeners = [];
    
    // Mapear regiões para códigos de país
    this.regions = {
      'BR': {
        name: 'Brasil',
        splashScreens: [
          { id: 'br_truck', path: '/assets/images/splash/br_truck.png' },
          { id: 'br_mascot', path: '/assets/images/splash/br_mascot.png' }
        ],
        icons: {
          baseFolder: '/assets/icons/regions/br/',
          suffix: '_br'
        },
        defaultVoice: 'pt-BR-AntonioNeural'
      },
      'AR': {
        name: 'Argentina',
        splashScreens: [
          { id: 'ar_truck', path: '/assets/images/splash/ar_truck.png' },
          { id: 'ar_mascot', path: '/assets/images/splash/ar_mascot.png' }
        ],
        icons: {
          baseFolder: '/assets/icons/regions/ar/',
          suffix: '_ar'
        },
        defaultVoice: 'es-AR-ElenaNeural'
      },
      'US': {
        name: 'Estados Unidos',
        splashScreens: [
          { id: 'us_truck', path: '/assets/images/splash/us_truck.png' },
          { id: 'us_mascot', path: '/assets/images/splash/us_mascot.png' }
        ],
        icons: {
          baseFolder: '/assets/icons/regions/us/',
          suffix: '_us'
        },
        defaultVoice: 'en-US-JennyNeural'
      },
      // Adicionar outras regiões conforme necessário
    };
    
    // Definir temas disponíveis
    this.themes = {
      'light': {
        name: 'Tema Claro',
        colors: {
          primary: '#0077CC',
          secondary: '#6C757D',
          background: '#FFFFFF',
          surface: '#F8F9FA',
          text: '#212529',
          textSecondary: '#6C757D',
          accent: '#FFC107'
        },
        isDark: false
      },
      'dark': {
        name: 'Tema Escuro',
        colors: {
          primary: '#0A84FF',
          secondary: '#6C757D',
          background: '#121212',
          surface: '#1E1E1E',
          text: '#FFFFFF',
          textSecondary: '#BBBBBB',
          accent: '#FFC107'
        },
        isDark: true
      },
      'truck': {
        name: 'Tema Caminhoneiro',
        colors: {
          primary: '#FF5722',
          secondary: '#607D8B',
          background: '#EFEFEF',
          surface: '#FFFFFF',
          text: '#333333',
          textSecondary: '#666666',
          accent: '#FFA000'
        },
        isDark: false
      }
    };
  }

  /**
   * Instância singleton do serviço
   */
  static instance = null;
  
  /**
   * Obtém a instância do serviço, criando-a se necessário
   */
  static getInstance() {
    if (!RegionalVisualsService.instance) {
      RegionalVisualsService.instance = new RegionalVisualsService();
    }
    return RegionalVisualsService.instance;
  }

  /**
   * Inicializa o serviço, configurando listeners para mudanças de localização
   */
  initialize() {
    // Obter a região atual com base na localização do dispositivo ou configurações
    this.detectCurrentRegion();
    
    // Carregar tema salvo nas preferências
    this.loadSavedTheme();
    
    // Configurar verificação periódica de região (a cada 30 minutos ou ao cruzar fronteiras)
    this.setupRegionTracking();
    
    // Configurar listener para mudanças de tema do sistema
    this.setupSystemThemeListener();
    
    console.log('RegionalVisualsService inicializado');
  }

  /**
   * Detecta a região atual com base na localização ou configurações do usuário
   */
  async detectCurrentRegion() {
    try {
      // Prioridade 1: Verificar configurações do usuário
      const userPreferredRegion = await this.getUserPreferredRegion();
      if (userPreferredRegion) {
        this.setCurrentRegion(userPreferredRegion);
        return;
      }
      
      // Prioridade 2: Usar o NavigationService para obter a localização atual
      const location = await this.navigationService.getCurrentLocation();
      if (location) {
        // Obter o código do país a partir das coordenadas
        const countryCode = await this.getCountryCodeFromCoordinates(location);
        if (countryCode && this.regions[countryCode]) {
          this.setCurrentRegion(countryCode);
          return;
        }
      }
      
      // Prioridade 3: Usar o idioma do dispositivo
      const deviceLanguage = this.translations.getCurrentLanguage();
      if (deviceLanguage) {
        const languagePrefix = deviceLanguage.split('-')[0];
        const region = this.findRegionByLanguage(languagePrefix);
        if (region) {
          this.setCurrentRegion(region);
          return;
        }
      }
      
      // Fallback: Definir região padrão (Brasil)
      this.setCurrentRegion('BR');
      
    } catch (error) {
      console.error('Erro ao detectar região atual:', error);
      // Fallback: Definir região padrão (Brasil)
      this.setCurrentRegion('BR');
    }
  }

  /**
   * Obtém a região preferida do usuário a partir das configurações salvas
   */
  async getUserPreferredRegion() {
    try {
      // Verificar localStorage ou outro mecanismo de armazenamento
      const savedRegion = localStorage.getItem('kingroad_preferred_region');
      if (savedRegion && this.regions[savedRegion]) {
        return savedRegion;
      }
      return null;
    } catch (error) {
      console.error('Erro ao obter região preferida do usuário:', error);
      return null;
    }
  }
  
  /**
   * Obtém o código do país a partir de coordenadas GPS
   */
  async getCountryCodeFromCoordinates(location) {
    try {
      // Verificar se há conexão com a internet
      if (!navigator.onLine) {
        console.log('Dispositivo offline. Usando região salva anteriormente.');
        return null;
      }
      
      // Usar API de geolocalização reversa
      const { latitude, longitude } = location;
      const response = await fetch(`https://api.kingroad.app/geocoding/reverse?lat=${latitude}&lon=${longitude}`);
      const data = await response.json();
      
      if (data && data.countryCode) {
        return data.countryCode;
      }
      
      return null;
    } catch (error) {
      console.error('Erro ao obter código do país:', error);
      return null;
    }
  }
  
  /**
   * Encontra uma região com base no código de idioma
   */
  findRegionByLanguage(languageCode) {
    // Mapear códigos de idioma para regiões
    const languageMap = {
      'pt': 'BR',
      'es': 'AR',
      'en': 'US',
      // Adicionar outros mapeamentos conforme necessário
    };
    
    return languageMap[languageCode] || null;
  }
  
  /**
   * Define a região atual e notifica os ouvintes
   */
  setCurrentRegion(regionCode) {
    if (this.currentRegion === regionCode) {
      return; // Evitar processamento desnecessário
    }
    
    const previousRegion = this.currentRegion;
    this.currentRegion = regionCode;
    
    // Salvar a região nas preferências
    try {
      localStorage.setItem('kingroad_last_region', regionCode);
    } catch (error) {
      console.error('Erro ao salvar região nas preferências:', error);
    }
    
    console.log(`Região alterada: ${previousRegion || 'Nenhuma'} -> ${regionCode}`);
    
    // Notificar ouvintes sobre a mudança de região
    this.notifyRegionChange(previousRegion, regionCode);
    
    // Verificar se deve mostrar splash screen de região
    if (previousRegion && previousRegion !== regionCode) {
      this.showRegionalSplashScreen(regionCode);
    }
  }
  
  /**
   * Configura o rastreamento de região com base na localização
   */
  setupRegionTracking() {
    // Verificar a região periodicamente (a cada 30 minutos)
    setInterval(() => {
      const now = Date.now();
      // Evitar verificações muito frequentes
      if (now - this.lastLocationCheck > 30 * 60 * 1000) {
        this.detectCurrentRegion();
        this.lastLocationCheck = now;
      }
    }, 30 * 60 * 1000);
    
    // Escutar eventos de cruzamento de fronteira do NavigationService
    document.addEventListener('borderCrossing', (event) => {
      const { fromCountry, toCountry } = event.detail;
      if (toCountry && this.regions[toCountry]) {
        this.setCurrentRegion(toCountry);
        // Mostrar splash screen específico para cruzamento de fronteira
        this.showRegionalSplashScreen(toCountry, true);
      }
    });
  }
  
  /**
   * Configura um listener para mudanças no tema do sistema (claro/escuro)
   */
  setupSystemThemeListener() {
    // Verificar se o navegador suporta matchMedia
    if (window.matchMedia) {
      const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      
      // Listener para mudanças no tema do sistema
      const handleThemeChange = (e) => {
        const systemTheme = e.matches ? 'dark' : 'light';
        // Verificar se devemos seguir o tema do sistema (configuração do usuário)
        if (this.shouldFollowSystemTheme()) {
          this.setTheme(systemTheme);
        }
      };
      
      // Registrar o listener
      if (darkModeMediaQuery.addEventListener) {
        darkModeMediaQuery.addEventListener('change', handleThemeChange);
      } else if (darkModeMediaQuery.addListener) {
        // Fallback para navegadores mais antigos
        darkModeMediaQuery.addListener(handleThemeChange);
      }
      
      // Verificar tema inicial se estiver seguindo o sistema
      if (this.shouldFollowSystemTheme()) {
        const initialSystemTheme = darkModeMediaQuery.matches ? 'dark' : 'light';
        this.setTheme(initialSystemTheme);
      }
    }
  }
  
  /**
   * Verifica se o usuário prefere seguir o tema do sistema
   */
  shouldFollowSystemTheme() {
    try {
      return localStorage.getItem('kingroad_follow_system_theme') === 'true';
    } catch (error) {
      return true; // Valor padrão
    }
  }
  
  /**
   * Carrega o tema salvo nas preferências do usuário
   */
  loadSavedTheme() {
    try {
      const savedTheme = localStorage.getItem('kingroad_theme');
      if (savedTheme && this.themes[savedTheme]) {
        this.setTheme(savedTheme);
      } else if (this.shouldFollowSystemTheme() && window.matchMedia) {
        // Seguir o tema do sistema
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        this.setTheme(systemTheme);
      } else {
        // Tema padrão
        this.setTheme('light');
      }
    } catch (error) {
      console.error('Erro ao carregar tema salvo:', error);
      this.setTheme('light');
    }
  }
  
  /**
   * Define o tema atual e notifica os ouvintes
   */
  setTheme(themeName) {
    if (!this.themes[themeName]) {
      console.error(`Tema "${themeName}" não encontrado`);
      return false;
    }
    
    if (this.currentTheme === themeName) {
      return true; // Evitar processamento desnecessário
    }
    
    const previousTheme = this.currentTheme;
    this.currentTheme = themeName;
    
    // Salvar o tema nas preferências
    try {
      localStorage.setItem('kingroad_theme', themeName);
    } catch (error) {
      console.error('Erro ao salvar tema nas preferências:', error);
    }
    
    console.log(`Tema alterado: ${previousTheme} -> ${themeName}`);
    
    // Notificar ouvintes sobre a mudança de tema
    this.notifyThemeChange(previousTheme, themeName);
    
    // Aplicar o tema na interface (classes CSS, variáveis, etc.)
    this.applyThemeToInterface(themeName);
    
    return true;
  }
  
  /**
   * Aplica o tema atual na interface
   */
  applyThemeToInterface(themeName) {
    const theme = this.themes[themeName];
    
    // Remover classes de tema anteriores
    document.body.classList.remove('theme-light', 'theme-dark', 'theme-truck');
    
    // Adicionar classe do tema atual
    document.body.classList.add(`theme-${themeName}`);
    
    // Aplicar variáveis CSS do tema
    for (const [key, value] of Object.entries(theme.colors)) {
      document.documentElement.style.setProperty(`--color-${key}`, value);
    }
    
    // Definir meta tag de cor do tema para dispositivos móveis
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', theme.colors.primary);
    }
  }
  
  /**
   * Adiciona um listener para mudanças de região
   */
  addRegionChangeListener(listener) {
    if (typeof listener === 'function' && !this.regionChangeListeners.includes(listener)) {
      this.regionChangeListeners.push(listener);
      return true;
    }
    return false;
  }
  
  /**
   * Remove um listener de mudanças de região
   */
  removeRegionChangeListener(listener) {
    const index = this.regionChangeListeners.indexOf(listener);
    if (index !== -1) {
      this.regionChangeListeners.splice(index, 1);
      return true;
    }
    return false;
  }
  
  /**
   * Notifica os listeners sobre uma mudança de região
   */
  notifyRegionChange(previousRegion, newRegion) {
    this.regionChangeListeners.forEach(listener => {
      try {
        listener(previousRegion, newRegion);
      } catch (error) {
        console.error('Erro em listener de mudança de região:', error);
      }
    });
    
    // Disparar evento para o documento
    const event = new CustomEvent('regionChange', {
      detail: { previousRegion, newRegion }
    });
    document.dispatchEvent(event);
  }
  
  /**
   * Adiciona um listener para mudanças de tema
   */
  addThemeChangeListener(listener) {
    if (typeof listener === 'function' && !this.themeChangeListeners.includes(listener)) {
      this.themeChangeListeners.push(listener);
      return true;
    }
    return false;
  }
  
  /**
   * Remove um listener de mudanças de tema
   */
  removeThemeChangeListener(listener) {
    const index = this.themeChangeListeners.indexOf(listener);
    if (index !== -1) {
      this.themeChangeListeners.splice(index, 1);
      return true;
    }
    return false;
  }
  
  /**
   * Notifica os listeners sobre uma mudança de tema
   */
  notifyThemeChange(previousTheme, newTheme) {
    this.themeChangeListeners.forEach(listener => {
      try {
        listener(previousTheme, newTheme);
      } catch (error) {
        console.error('Erro em listener de mudança de tema:', error);
      }
    });
    
    // Disparar evento para o documento
    const event = new CustomEvent('themeChange', {
      detail: { previousTheme, newTheme }
    });
    document.dispatchEvent(event);
  }
  
  /**
   * Mostra a splash screen regional quando o usuário entra em uma nova região
   */
  showRegionalSplashScreen(regionCode, isBorderCrossing = false) {
    const region = this.regions[regionCode];
    if (!region || !region.splashScreens || region.splashScreens.length === 0) {
      return false;
    }
    
    // Escolher a splash screen apropriada
    let splashScreen;
    if (isBorderCrossing) {
      // Usar splash screen com mascote para cruzamento de fronteira
      splashScreen = region.splashScreens.find(s => s.id.includes('mascot'));
    }
    
    // Fallback para a primeira splash screen se não encontrou específica
    if (!splashScreen) {
      splashScreen = region.splashScreens[0];
    }
    
    // Disparar evento para mostrar splash screen
    const event = new CustomEvent('showRegionalSplash', {
      detail: {
        region: regionCode,
        splashScreen: splashScreen,
        isBorderCrossing: isBorderCrossing
      }
    });
    document.dispatchEvent(event);
    
    console.log(`Mostrando splash screen regional para ${regionCode}: ${splashScreen.id}`);
    return true;
  }
  
  /**
   * Retorna o caminho para um ícone regional
   */
  getRegionalIconPath(iconName) {
    if (!this.currentRegion || !this.regions[this.currentRegion]) {
      // Usar ícone padrão (global)
      return `/assets/icons/global/${iconName}.svg`;
    }
    
    const region = this.regions[this.currentRegion];
    const regionalPath = `${region.icons.baseFolder}${iconName}${region.icons.suffix}.svg`;
    
    // Verificar se o ícone regional existe (implementação depende da estrutura do app)
    // Por simplicidade, apenas retornamos o caminho regional
    return regionalPath;
  }
  
  /**
   * Retorna o tema atual
   */
  getCurrentTheme() {
    return {
      name: this.currentTheme,
      ...this.themes[this.currentTheme]
    };
  }
  
  /**
   * Retorna a região atual
   */
  getCurrentRegion() {
    if (!this.currentRegion || !this.regions[this.currentRegion]) {
      return null;
    }
    
    return {
      code: this.currentRegion,
      ...this.regions[this.currentRegion]
    };
  }
  
  /**
   * Retorna todos os temas disponíveis
   */
  getAvailableThemes() {
    return Object.keys(this.themes).map(key => ({
      id: key,
      name: this.themes[key].name,
      isDark: this.themes[key].isDark
    }));
  }
  
  /**
   * Retorna todas as regiões disponíveis
   */
  getAvailableRegions() {
    return Object.keys(this.regions).map(key => ({
      code: key,
      name: this.regions[key].name
    }));
  }
}

export { RegionalVisualsService };