interface LocationService {
    fun getLocationUpdates(): Flow<Location>
    suspend fun getLastKnownLocation(): Location?
    fun startNavigationTracking()
    fun stopNavigationTracking()
    
    data class NavigationState(
        val location: Location,
        val bearing: Float,
        val speed: Float,
        val accuracy: Float
    )
}