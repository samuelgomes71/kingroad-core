import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class SpecialClassMenuFragment : Fragment() {

    private val specialClasses = listOf(
        SpecialClass("pf", "Polícia Federal"),
        SpecialClass("prf", "Polícia Rodoviária Federal"),
        SpecialClass("pm", "Polícia Militar"),
        SpecialClass("pc", "Polícia Civil"),
        SpecialClass("amb", "Ambulâncias"),
        SpecialClass("para", "Paramédicos"),
        SpecialClass("bomb", "Bombeiros")
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_special_class_menu, container, false)

        val buttonContainer = view.findViewById<ViewGroup>(R.id.button_container)
        specialClasses.forEach { specialClass ->
            val button = Button(requireContext())
            button.text = specialClass.name
            button.setOnClickListener {
                val intent = Intent(requireContext(), RegistrationActivity::class.java)
                intent.putExtra("classId", specialClass.id)
                startActivity(intent)
            }
            buttonContainer.addView(button)
        }

        return view
    }

    data class SpecialClass(val id: String, val name: String)
}