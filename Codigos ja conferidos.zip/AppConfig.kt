package com.kingroad.config

/**
 * Configurações globais do aplicativo KingRoad
 * Salvar em: app/src/main/kotlin/com/kingroad/config/AppConfig.kt
 */
object AppConfig {
    // Informações do aplicativo
    const val APP_NAME = "KingRoad"
    const val APP_VERSION = "1.0.0"
    const val APP_PACKAGE = "com.kingroad"
    
    // Configurações de rede
    const val API_BASE_URL = "https://api.kingroad.com/v1/"
    const val MAP_TILE_SERVER = "https://tiles.kingroad.com/{z}/{x}/{y}.png"
    const val OSM_API_BASE_URL = "https://api.openstreetmap.org/"
    
    // Paths para armazenamento local
    const val OFFLINE_MAPS_DIRECTORY = "KingRoad/maps"
    const val ROUTE_CACHE_DIRECTORY = "KingRoad/routes"
    const val USER_DATA_DIRECTORY = "KingRoad/user"
    
    // Configurações de interface
    const val DEV_MODE_CLICK_COUNT = 5  // Ativar modo desenvolvedor com 5 cliques no logo
    
    // IDs para componentes da interface
    object UIComponents {
        const val MAIN_MENU = 1001
        const val MAP_VIEW = 1002
        const val ROUTE_PANEL = 1003
        const val NAVIGATION_PANEL = 1004
        const val SETTINGS_PANEL = 1005
    }
    
    // Família King - Integração
    object KingFamily {
        const val KINGCHAT_PACKAGE = "com.kingchat"
        const val KINGLOC_PACKAGE = "com.kingloc"
        const val KINGSMS_PACKAGE = "com.kingsms"
        
        // Deep links
        const val KINGCHAT_DEEPLINK = "kingchat://"
        const val KINGLOC_DEEPLINK = "kingloc://"
        const val KINGSMS_DEEPLINK = "kingsms://"
    }
    
    // Temas disponíveis
    object Themes {
        const val DEFAULT = "default"  // Preto com detalhes dourados
        const val DARK = "dark"
        const val LIGHT = "light"
        const val BLUE = "blue"
        const val GREEN = "green"
        const val RED = "red"
    }
}