package com.kingroad.reports

import android.content.Context
import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.AppDatabase
import com.kingroad.utils.LocationUtils
import com.kingroad.utils.SocialMediaUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Gerenciador para denúncias de problemas de infraestrutura pública
 * Permite aos usuários reportar problemas urbanos para autoridades locais
 */
class PublicInfrastructureReportManager(private val context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val reportDao = database.publicInfrastructureReportDao()
    private val municipalityDao = database.municipalityDao()
    
    private val coroutineScope = CoroutineScope(Job() + Dispatchers.Main)
    
    /**
     * Envia uma denúncia de problema de infraestrutura
     * 
     * @param latitude Latitude da ocorrência
     * @param longitude Longitude da ocorrência
     * @param reportType Tipo de denúncia (POTHOLE, FALLEN_TREE, etc)
     * @param description Descrição do problema
     * @param photoUris Lista de URIs das fotos capturadas
     * @param userId ID do usuário que está reportando
     * @param sendToSocialMedia Se true, também publica nas redes sociais oficiais
     * @return ID da denúncia criada, ou null em caso de erro
     */
    fun submitInfrastructureReport(
        latitude: Double,
        longitude: Double,
        reportType: InfrastructureReportType,
        description: String,
        photoUris: List<Uri>,
        userId: String,
        sendToSocialMedia: Boolean = false
    ): LiveData<ReportSubmissionResult> {
        val result = MutableLiveData<ReportSubmissionResult>()
        
        coroutineScope.launch {
            try {
                val reportResult = withContext(Dispatchers.IO) {
                    // Obter informações da municipalidade baseado na localização
                    val municipality = municipalityDao.findByLocation(latitude, longitude)
                        ?: return@withContext ReportSubmissionResult.Error(
                            "Não foi possível identificar a municipalidade para esta localização"
                        )
                    
                    // Criar a denúncia
                    val newReport = InfrastructureReport(
                        id = UUID.randomUUID().toString(),
                        userId = userId,
                        latitude = latitude,
                        longitude = longitude,
                        municipalityId = municipality.id,
                        municipalityName = municipality.name,
                        reportType = reportType,
                        description = description,
                        status = ReportStatus.SUBMITTED,
                        photoUrls = savePhotos(photoUris),
                        createdAt = System.currentTimeMillis(),
                        lastUpdatedAt = System.currentTimeMillis()
                    )
                    
                    // Salvar no banco de dados
                    val reportId = reportDao.insert(newReport)
                    
                    // Enviar para o sistema da prefeitura via API
                    val apiResult = sendToMunicipalityApi(newReport, municipality)
                    
                    // Se solicitado, publicar em redes sociais
                    var socialMediaResult: SocialMediaPostResult? = null
                    if (sendToSocialMedia && apiResult is MunicipalityApiResult.Success) {
                        socialMediaResult = postToSocialMedia(newReport, municipality, photoUris)
                    }
                    
                    // Retornar resultado final
                    when {
                        apiResult is MunicipalityApiResult.Success -> {
                            // Atualizar protocolo no banco
                            reportDao.updateProtocolNumber(
                                reportId = newReport.id,
                                protocolNumber = apiResult.protocolNumber
                            )
                            
                            ReportSubmissionResult.Success(
                                reportId = newReport.id,
                                protocolNumber = apiResult.protocolNumber,
                                socialMediaPostId = socialMediaResult?.postId
                            )
                        }
                        else -> {
                            // Denúncia salva localmente, mas falhou ao enviar para API
                            ReportSubmissionResult.PartialSuccess(
                                reportId = newReport.id,
                                errorMessage = (apiResult as MunicipalityApiResult.Error).message
                            )
                        }
                    }
                }
                
                result.value = reportResult
                
            } catch (e: Exception) {
                result.value = ReportSubmissionResult.Error(
                    "Erro ao processar a denúncia: ${e.localizedMessage}"
                )
            }
        }
        
        return result
    }
    
    /**
     * Salva as fotos no armazenamento e retorna as URLs
     */
    private suspend fun savePhotos(photoUris: List<Uri>): List<String> {
        return withContext(Dispatchers.IO) {
            // Implementação real salvaria as fotos no armazenamento local ou na nuvem
            // Para o mock, simplesmente convertemos as URIs em strings
            photoUris.map { it.toString() }
        }
    }
    
    /**
     * Envia a denúncia para a API da municipalidade
     */
    private suspend fun sendToMunicipalityApi(
        report: InfrastructureReport,
        municipality: Municipality
    ): MunicipalityApiResult {
        return withContext(Dispatchers.IO) {
            try {
                // Implementação real faria uma chamada de API para o sistema da prefeitura
                // Para o mock, simulamos um sucesso com um número de protocolo fictício
                
                val apiEndpoint = municipality.apiEndpoint
                if (apiEndpoint.isNullOrEmpty()) {
                    // Municipalidade não tem API configurada
                    return@withContext MunicipalityApiResult.Error(
                        "Esta municipalidade não possui integração com o KingRoad"
                    )
                }
                
                // Simular chamada de API bem-sucedida
                val protocolNumber = "KING${System.currentTimeMillis() % 1000000}"
                
                MunicipalityApiResult.Success(protocolNumber)
                
            } catch (e: Exception) {
                MunicipalityApiResult.Error(
                    "Falha ao enviar para a API da municipalidade: ${e.localizedMessage}"
                )
            }
        }
    }
    
    /**
     * Publica a denúncia nas redes sociais oficiais da prefeitura
     */
    private suspend fun postToSocialMedia(
        report: InfrastructureReport,
        municipality: Municipality,
        photoUris: List<Uri>
    ): SocialMediaPostResult {
        return withContext(Dispatchers.IO) {
            try {
                // Implementação real usaria a API oficial das redes sociais
                // Para o mock, simulamos um post bem-sucedido
                
                // Verificar se a municipalidade tem redes sociais configuradas
                if (municipality.socialMediaHandles.isNullOrEmpty()) {
                    return@withContext SocialMediaPostResult(
                        success = false,
                        postId = null,
                        error = "Esta municipalidade não possui redes sociais configuradas"
                    )
                }
                
                // Construir mensagem para redes sociais
                val message = buildSocialMediaMessage(report, municipality)
                
                // Simular post nas redes sociais
                val postId = "SM${System.currentTimeMillis() % 1000000}"
                
                SocialMediaPostResult(
                    success = true,
                    postId = postId,
                    error = null
                )
                
            } catch (e: Exception) {
                SocialMediaPostResult(
                    success = false,
                    postId = null,
                    error = "Falha ao publicar nas redes sociais: ${e.localizedMessage}"
                )
            }
        }
    }
    
    /**
     * Constrói a mensagem para redes sociais
     */
    private fun buildSocialMediaMessage(
        report: InfrastructureReport,
        municipality: Municipality
    ): String {
        val reportTypeStr = when (report.reportType) {
            InfrastructureReportType.POTHOLE -> "Buraco na via"
            InfrastructureReportType.FALLEN_TREE -> "Árvore caída"
            InfrastructureReportType.BROKEN_TRAFFIC_LIGHT -> "Semáforo quebrado"
            InfrastructureReportType.WATER_LEAK -> "Vazamento de água"
            InfrastructureReportType.DAMAGED_BRIDGE -> "Ponte danificada"
            InfrastructureReportType.STREET_LIGHT_OUTAGE -> "Iluminação pública defeituosa"
            InfrastructureReportType.ILLEGAL_DUMPING -> "Descarte irregular de lixo"
            InfrastructureReportType.FLOODING -> "Alagamento"
            InfrastructureReportType.OTHER -> "Problema de infraestrutura"
        }
        
        return """
            #DenúnciaCidadã #${municipality.name.replace(" ", "")}
            
            ${reportTypeStr} reportado via aplicativo KingRoad.
            
            Localização: ${LocationUtils.formatCoordinates(report.latitude, report.longitude)}
            ${if (report.description.isNotEmpty()) "Descrição: ${report.description}" else ""}
            
            Protocolo: ${report.protocolNumber ?: "Em processamento"}
            
            Esta é uma publicação automática. Para acompanhar o status da solicitação, acesse o portal da prefeitura.
        """.trimIndent()
    }
    
    /**
     * Obtém denúncias do usuário atual
     * 
     * @param userId ID do usuário
     * @return LiveData com lista de denúncias
     */
    fun getUserReports(userId: String): LiveData<List<InfrastructureReport>> {
        val result = MutableLiveData<List<InfrastructureReport>>()
        
        coroutineScope.launch {
            try {
                val reports = withContext(Dispatchers.IO) {
                    reportDao.findByUserId(userId)
                }
                
                result.value = reports
            } catch (e: Exception) {
                result.value = emptyList()
            }
        }
        
        return result
    }
    
    /**
     * Obtém denúncias próximas à localização atual do usuário
     * 
     * @param latitude Latitude atual
     * @param longitude Longitude atual
     * @param radiusKm Raio de busca em km
     * @return LiveData com lista de denúncias
     */
    fun getNearbyReports(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 5.0
    ): LiveData<List<InfrastructureReport>> {
        val result = MutableLiveData<List<InfrastructureReport>>()
        
        coroutineScope.launch {
            try {
                val reports = withContext(Dispatchers.IO) {
                    // Converte raio de km para graus (aproximação simples)
                    val radiusDegrees = radiusKm / 111.0 // ~111km por grau na latitude
                    
                    reportDao.findNearby(latitude, longitude, radiusDegrees)
                }
                
                result.value = reports
            } catch (e: Exception) {
                result.value = emptyList()
            }
        }
        
        return result
    }
    
    /**
     * Atualiza o status de uma denúncia
     * 
     * @param reportId ID da denúncia
     * @param newStatus Novo status
     * @param comment Comentário opcional
     * @return True se a atualização foi bem-sucedida
     */
    fun updateReportStatus(
        reportId: String,
        newStatus: ReportStatus,
        comment: String = ""
    ): LiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        
        coroutineScope.launch {
            try {
                val success = withContext(Dispatchers.IO) {
                    val report = reportDao.findById(reportId) ?: return@withContext false
                    
                    // Criar um histórico de status
                    val statusHistory = StatusHistoryEntry(
                        oldStatus = report.status,
                        newStatus = newStatus,
                        timestamp = System.currentTimeMillis(),
                        comment = comment
                    )
                    
                    // Atualizar o status e histórico no banco
                    reportDao.updateStatus(
                        reportId = reportId,
                        status = newStatus,
                        lastUpdatedAt = System.currentTimeMillis()
                    )
                    
                    reportDao.addStatusHistoryEntry(reportId, statusHistory)
                    
                    true
                }
                
                result.value = success
            } catch (e: Exception) {
                result.value = false
            }
        }
        
        return result
    }
}

/**
 * Tipos de problemas de infraestrutura que podem ser reportados
 */
enum class InfrastructureReportType {
    POTHOLE,             // Buraco na via
    FALLEN_TREE,         // Árvore caída
    BROKEN_TRAFFIC_LIGHT,// Semáforo quebrado
    WATER_LEAK,          // Vazamento de água
    DAMAGED_BRIDGE,      // Ponte danificada
    STREET_LIGHT_OUTAGE, // Iluminação pública defeituosa
    ILLEGAL_DUMPING,     // Descarte irregular de lixo
    FLOODING,            // Alagamento
    OTHER                // Outros problemas
}

/**
 * Status possíveis para uma denúncia
 */
enum class ReportStatus {
    SUBMITTED,     // Enviada
    RECEIVED,      // Recebida pela prefeitura
    IN_ANALYSIS,   // Em análise
    IN_PROGRESS,   // Em andamento
    RESOLVED,      // Resolvida
    REJECTED,      // Rejeitada
    DUPLICATE      // Duplicada (já reportada)
}

/**
 * Modelo para denúncias de problemas de infraestrutura
 */
data class InfrastructureReport(
    val id: String,
    val userId: String,
    val latitude: Double,
    val longitude: Double,
    val municipalityId: String,
    val municipalityName: String,
    val reportType: InfrastructureReportType,
    val description: String,
    val status: ReportStatus,
    val photoUrls: List<String>,
    val protocolNumber: String? = null,
    val createdAt: Long,
    val lastUpdatedAt: Long,
    val statusHistory: List<StatusHistoryEntry> = emptyList()
)

/**
 * Entrada no histórico de status de uma denúncia
 */
data class StatusHistoryEntry(
    val oldStatus: ReportStatus,
    val newStatus: ReportStatus,
    val timestamp: Long,
    val comment: String
)

/**
 * Modelo para municipalidades (prefeituras)
 */
data class Municipality(
    val id: String,
    val name: String,
    val country: String,
    val adminLevel: String,  // city, county, state, etc.
    val apiEndpoint: String? = null,
    val contactEmail: String? = null,
    val contactPhone: String? = null,
    val website: String? = null,
    val socialMediaHandles: Map<String, String>? = null, // platform -> handle
    val boundaryPolygon: List<Pair<Double, Double>>? = null // Pontos do polígono da fronteira
)

/**
 * Resultado da submissão de uma denúncia
 */
sealed class ReportSubmissionResult {
    data class Success(
        val reportId: String,
        val protocolNumber: String,
        val socialMediaPostId: String? = null
    ) : ReportSubmissionResult()
    
    data class PartialSuccess(
        val reportId: String,
        val errorMessage: String
    ) : ReportSubmissionResult()
    
    data class Error(val message: String) : ReportSubmissionResult()
}

/**
 * Resultado da chamada à API da municipalidade
 */
sealed class MunicipalityApiResult {
    data class Success(val protocolNumber: String) : MunicipalityApiResult()
    data class Error(val message: String) : MunicipalityApiResult()
}

/**
 * Resultado da publicação em redes sociais
 */
data class SocialMediaPostResult(
    val success: Boolean,
    val postId: String?,
    val error: String?
)