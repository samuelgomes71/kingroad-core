import React, { useState, useEffect, useContext, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { AuthContext } from '../contexts/AuthContext';
import { AlertContext } from '../contexts/AlertContext';
import CommonButtons from './commonButtons';
import { getDriverData, updateDriverProfile, getDrivingHistory } from '../services/driverService';
import { getBehavioralAnalysis } from '../services/analyticsService';
import { getRestPeriods } from '../services/regulationService';
import { getAchievements, unlockAchievement } from '../services/gamificationService';

// Componentes internos
import ProfileHeader from './profile/ProfileHeader';
import DrivingHistoryChart from './profile/DrivingHistoryChart';
import BehavioralAnalysisCard from './profile/BehavioralAnalysisCard';
import RestTrackerWidget from './profile/RestTrackerWidget';
import AchievementsPanel from './profile/AchievementsPanel';

const DriverProfile = () => {
  const { t } = useTranslation();
  const { currentUser, userType } = useContext(AuthContext);
  const { showAlert } = useContext(AlertContext);
  
  // Estados para gerenciar os dados do perfil
  const [loading, setLoading] = useState(true);
  const [profileData, setProfileData] = useState(null);
  const [drivingHistory, setDrivingHistory] = useState([]);
  const [behavioralData, setBehavioralData] = useState(null);
  const [restPeriods, setRestPeriods] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [editMode, setEditMode] = useState(false);
  const [updatedProfile, setUpdatedProfile] = useState({});

  // Determinar se o usuário é VIP
  const isVIP = useMemo(() => userType === 'MotoristaVIP', [userType]);
// Carregar dados do perfil
  useEffect(() => {
    const loadProfileData = async () => {
      try {
        setLoading(true);
        
        // Carregar dados do motorista
        const driver = await getDriverData(currentUser.uid);
        setProfileData(driver);
        setUpdatedProfile(driver);
        
        // Carregar histórico de direção
        const history = await getDrivingHistory(currentUser.uid, { 
          limit: isVIP ? 90 : 30 
        });
        setDrivingHistory(history);
        
        // Carregar análise comportamental
        const analysis = await getBehavioralAnalysis(currentUser.uid);
        setBehavioralData(analysis);
        
        // Carregar períodos de descanso
        const rest = await getRestPeriods(currentUser.uid, driver.countryCode);
        setRestPeriods(rest);
        
        // Carregar conquistas
        const userAchievements = await getAchievements(currentUser.uid);
        setAchievements(userAchievements);
        
        // Verificar conquistas novas
        checkForNewAchievements(history, analysis, userAchievements);
        
      } catch (error) {
        console.error("Erro ao carregar dados do perfil:", error);
        showAlert({
          type: 'error',
          message: t('profile.errors.loadFailed'),
          timeout: 5000
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadProfileData();
  }, [currentUser, isVIP, t, showAlert]);
  
  // Verificar e desbloquear novas conquistas
  const checkForNewAchievements = (history, analysis, currentAchievements) => {
    // Conquista de quilometragem
    const totalDistance = history.reduce((sum, record) => sum + record.distance, 0);
    const milestones = [1000, 5000, 10000, 50000, 100000]; // km
    
    milestones.forEach(milestone => {
      const achievementId = `distance_${milestone}`;
      if (totalDistance >= milestone && !currentAchievements.find(a => a.id === achievementId)) {
        unlockAchievement(currentUser.uid, achievementId);
        showAlert({
          type: 'success',
          message: t('achievements.unlocked', { name: t(`achievements.${achievementId}`) }),
          timeout: 5000
        });
      }
    });
    
    // Conquista de direção segura
    if (analysis && analysis.safetyScore >= 90 && !currentAchievements.find(a => a.id === 'safety_expert')) {
      unlockAchievement(currentUser.uid, 'safety_expert');
      showAlert({
        type: 'success',
        message: t('achievements.unlocked', { name: t('achievements.safety_expert') }),
        timeout: 5000
      });
    }
  };
  
  // Salvar alterações do perfil
  const handleSaveProfile = async () => {
    try {
      setLoading(true);
      await updateDriverProfile(currentUser.uid, updatedProfile);
      setProfileData(updatedProfile);
      setEditMode(false);
      showAlert({
        type: 'success',
        message: t('profile.updateSuccess'),
        timeout: 3000
      });
    } catch (error) {
      console.error("Erro ao atualizar perfil:", error);
      showAlert({
        type: 'error',
        message: t('profile.errors.updateFailed'),
        timeout: 5000
      });
    } finally {
      setLoading(false);
    }
  };
// Lidar com mudanças nos campos do perfil
  const handleProfileChange = (field, value) => {
    setUpdatedProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Renderização condicional dos dados do perfil
  if (loading && !profileData) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Cabeçalho do perfil com informações básicas e foto */}
      <ProfileHeader 
        profile={profileData}
        isEditing={editMode}
        onChange={handleProfileChange}
        isVIP={isVIP}
      />
      
      {/* Barra de navegação entre abas */}
      <div className="flex border-b border-gray-200 mb-6 dark:border-gray-700">
        <button
          className={`py-2 px-4 font-medium ${activeTab === 'overview' 
            ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-400 dark:border-blue-400' 
            : 'text-gray-500 hover:text-blue-500 dark:text-gray-400 dark:hover:text-blue-300'}`}
          onClick={() => setActiveTab('overview')}
        >
          {t('profile.tabs.overview')}
        </button>
        <button
          className={`py-2 px-4 font-medium ${activeTab === 'history' 
            ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-400 dark:border-blue-400' 
            : 'text-gray-500 hover:text-blue-500 dark:text-gray-400 dark:hover:text-blue-300'}`}
          onClick={() => setActiveTab('history')}
        >
          {t('profile.tabs.history')}
        </button>
        <button
          className={`py-2 px-4 font-medium ${activeTab === 'achievements' 
            ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-400 dark:border-blue-400' 
            : 'text-gray-500 hover:text-blue-500 dark:text-gray-400 dark:hover:text-blue-300'}`}
          onClick={() => setActiveTab('achievements')}
        >
          {t('profile.tabs.achievements')}
        </button>
      </div>
      
      {/* Conteúdo das abas */}
      <div className="space-y-6">
        {activeTab === 'overview' && (
          <>
            {/* Rastreador de tempo de descanso */}
            <RestTrackerWidget 
              restPeriods={restPeriods} 
              countryCode={profileData.countryCode}
            />
            
            {/* Análise comportamental */}
            <BehavioralAnalysisCard data={behavioralData} />
          </>
        )}
        
        {activeTab === 'history' && (
          <DrivingHistoryChart history={drivingHistory} isVIP={isVIP} />
        )}
        
        {activeTab === 'achievements' && (
          <AchievementsPanel achievements={achievements} />
        )}
      </div>
      
      {/* Botões de ação */}
      <div className="flex justify-end mt-6 space-x-4">
        {editMode ? (
          <>
            <CommonButtons.Secondary 
              label={t('common.cancel')} 
              onClick={() => {
                setEditMode(false);
                setUpdatedProfile(profileData);
              }} 
            />
            <CommonButtons.Primary 
              label={t('common.save')} 
              onClick={handleSaveProfile} 
              loading={loading} 
            />
          </>
        ) : (
          <CommonButtons.Primary 
            label={t('profile.editProfile')} 
            onClick={() => setEditMode(true)} 
          />
        )}
      </div>
    </div>
  );
};

export default DriverProfile;