// PulsatingLocationMarker.kt
package com.kingroad.map

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.kingroad.utils.DimensionUtils

/**
 * Marcador pulsante para mostrar a localização atual no mapa
 */
class PulsatingLocationMarker @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Cores
    private val centerColor = Color.WHITE
    private val markerColor = Color.rgb(59, 130, 246) // Azul (tailwind blue-500)
    private val pulseColor = Color.rgb(59, 130, 246) // Mesma cor com transparência
    
    // Tamanhos
    private val markerRadius = DimensionUtils.dpToPx(context, 16f) // Raio do círculo principal
    private val centerRadius = DimensionUtils.dpToPx(context, 6f)  // Raio do círculo interno branco
    private val pulseMaxScale = 1.8f // Escala máxima da expansão do pulso
    
    // Animação
    private var pulseScale = 1.0f
    private var pulseAlpha = 0.7f
    private var secondPulseScale = 1.0f
    private var secondPulseAlpha = 0.4f
    
    // Objetos de desenho
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val secondPulsePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    
    // Posição no mapa e na tela
    private var mapView: KingRoadMapView? = null
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private val screenPosition = PointF(0f, 0f)
    
    init {
        // Configurar pinturas
        markerPaint.color = markerColor
        markerPaint.style = Paint.Style.FILL
        
        centerPaint.color = centerColor
        centerPaint.style = Paint.Style.FILL
        
        pulsePaint.color = pulseColor
        pulsePaint.style = Paint.Style.FILL
        pulsePaint.alpha = (pulseAlpha * 255).toInt()
        
        secondPulsePaint.color = pulseColor
        secondPulsePaint.style = Paint.Style.FILL
        secondPulsePaint.alpha = (secondPulseAlpha * 255).toInt()
        
        // Iniciar animação
        startPulseAnimation()
    }
    
    /**
     * Define o MapView associado a este marcador
     */
    fun setMapView(mapView: KingRoadMapView) {
        this.mapView = mapView
    }
    
    /**
     * Define a localização do marcador
     */
    fun setLocation(latitude: Double, longitude: Double) {
        this.latitude = latitude
        this.longitude = longitude
        updateScreenPosition()
    }
    
    /**
     * Atualiza a posição na tela de acordo com as coordenadas do mapa
     */
    private fun updateScreenPosition() {
        mapView?.let { mapView ->
            val point = mapView.convertLatLngToScreenPoint(latitude, longitude)
            screenPosition.set(point.x, point.y)
            invalidate()
        }
    }
    
    /**
     * Inicia a animação de pulso
     */
    private fun startPulseAnimation() {
        // Animação do primeiro pulso
        val pulseScaleAnim = ObjectAnimator.ofFloat(this, "pulseScale", 1.0f, pulseMaxScale).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = DecelerateInterpolator()
        }
        
        val pulseAlphaAnim = ObjectAnimator.ofFloat(this, "pulseAlpha", 0.7f, 0.0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = DecelerateInterpolator()
        }
        
        // Animação do segundo pulso (com delay)
        val secondPulseScaleAnim = ObjectAnimator.ofFloat(this, "secondPulseScale", 1.0f, pulseMaxScale * 0.9f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = DecelerateInterpolator()
            startDelay = 750 // Meio ciclo de delay
        }
        
        val secondPulseAlphaAnim = ObjectAnimator.ofFloat(this, "secondPulseAlpha", 0.4f, 0.0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = DecelerateInterpolator()
            startDelay = 750 // Meio ciclo de delay
        }
        
        // Combinar animações
        val animSet = AnimatorSet()
        animSet.playTogether(pulseScaleAnim, pulseAlphaAnim, secondPulseScaleAnim, secondPulseAlphaAnim)
        animSet.start()
    }
    
    // Propriedades para animação
    
    fun setPulseScale(scale: Float) {
        this.pulseScale = scale
        invalidate()
    }
    
    fun setPulseAlpha(alpha: Float) {
        this.pulseAlpha = alpha
        pulsePaint.alpha = (alpha * 255).toInt()
        invalidate()
    }
    
    fun setSecondPulseScale(scale: Float) {
        this.secondPulseScale = scale
        invalidate()
    }
    
    fun setSecondPulseAlpha(alpha: Float) {
        this.secondPulseAlpha = alpha
        secondPulsePaint.alpha = (alpha * 255).toInt()
        invalidate()
    }
    
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        val centerX = width / 2f
        val centerY = height / 2f
        
        // Desenhar círculos de pulso
        canvas.drawCircle(centerX, centerY, markerRadius * secondPulseScale, secondPulsePaint)
        canvas.drawCircle(centerX, centerY, markerRadius * pulseScale, pulsePaint)
        
        // Desenhar marcador principal
        canvas.drawCircle(centerX, centerY, markerRadius, markerPaint)
        
        // Desenhar círculo central
        canvas.drawCircle(centerX, centerY, centerRadius, centerPaint)
    }
    
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Calcular tamanho necessário com base no raio do pulso máximo
        val size = (markerRadius * pulseMaxScale * 2).toInt() + 20 // Um pouco de padding
        setMeasuredDimension(size, size)
    }
}