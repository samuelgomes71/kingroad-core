// modules/kingroad/navigation/index.js
// Arquivo principal que exporta a API pública do módulo de navegação

import routeService from './services/routeService';
import alternativeRoutesService from './services/alternativeRoutesService';
import navigationInstructionService from './services/navigationInstructionService';
import reverseRouteService from './services/reverseRouteService';
import poiService from './services/poiService';

// API pública do módulo
export default {
  // Cálculo de rota básico
  calculateRoute: routeService.calculateRoute,
  
  // Rotas alternativas
  fetchAlternativeRoutes: alternativeRoutesService.fetchAlternativeRoutes,
  
  // Instruções de navegação
  getRouteInstructions: navigationInstructionService.getRouteInstructions,
  setCurrentRoute: navigationInstructionService.setCurrentRoute,
  stopNavigation: navigationInstructionService.stopNavigation,
  
  // Rota inversa (volta)
  calculateReverseRoute: reverseRouteService.calculateReverseRoute,
  
  // Pontos de interesse
  getPOIsAlongRoute: poiService.getPOIsAlongRoute
};