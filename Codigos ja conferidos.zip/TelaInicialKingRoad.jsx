import React from "react";
import { View, Image, Text, TouchableOpacity } from "react-native";

const HomeScreen = () => {
  return (
    <View className="flex-1 bg-black items-center justify-center">
      {/* Logo */}
      <Image
        source={require("./assets/king_road_logo.png")}
        className="w-48 h-48"
        resizeMode="contain"
      />
      
      {/* Botões principais */}
      <View className="mt-6 w-full px-6">
        <TouchableOpacity className="bg-gold py-3 rounded-2xl mb-4">
          <Text className="text-black text-center text-lg font-bold">Iniciar Navegação</Text>
        </TouchableOpacity>
        <TouchableOpacity className="border border-gold py-3 rounded-2xl mb-4">
          <Text className="text-gold text-center text-lg font-bold">Meus Destinos</Text>
        </TouchableOpacity>
        <TouchableOpacity className="border border-gold py-3 rounded-2xl mb-4">
          <Text className="text-gold text-center text-lg font-bold">Configurações</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default HomeScreen;