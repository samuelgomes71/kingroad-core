package com.kingroad.database

import android.content.Context
import androidx.room.*

@Entity(tableName = "customer_ids")
data class CustomerID(
    @PrimaryKey val id: String,
    val companyName: String,
    val city: String,
    val state: String,
    val latitude: Double,
    val longitude: Double
)

@Dao
interface CustomerIDDao {
    @Query("SELECT * FROM customer_ids WHERE id = :customerID LIMIT 1")
    fun getCustomerByID(customerID: String): CustomerID?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCustomer(customer: CustomerID)
}

@Database(entities = [CustomerID::class], version = 1)
abstract class CustomerIDDatabase : RoomDatabase() {
    abstract fun customerIDDao(): CustomerIDDao

    companion object {
        @Volatile
        private var INSTANCE: CustomerIDDatabase? = null

        fun getDatabase(context: Context): CustomerIDDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CustomerIDDatabase::class.java,
                    "customer_id_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
