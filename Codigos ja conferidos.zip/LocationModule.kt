// LocationModule.kt
package com.kingroad.native

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.provider.Settings
import androidx.core.app.ActivityCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.kingroad.activities.MapActivity
import com.kingroad.utils.Logger

/**
 * Módulo nativo para gerenciamento de localização do usuário
 */
class LocationModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    companion object {
        private const val MODULE_NAME = "LocationModule"
        private const val TAG = "LocationModule"
        private const val LOCATION_UPDATE_EVENT = "onLocationUpdate"
        private const val LOCATION_PERMISSION_REQUEST = 1001
    }
    
    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var locationCallback: LocationCallback? = null
    private var isTracking = false
    
    init {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(reactContext)
    }
    
    override fun getName(): String = MODULE_NAME
    
    /**
     * Verifica se a permissão de localização está concedida
     * @return true se a permissão está concedida, false caso contrário
     */
    private fun hasLocationPermission(): Boolean {
        val fineLocation = ActivityCompat.checkSelfPermission(
            reactContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        return fineLocation == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Solicita permissão de localização
     * @param promise Promise para retornar o resultado
     */
    @ReactMethod
    fun requestLocationPermission(promise: Promise) {
        val currentActivity = currentActivity
        
        if (currentActivity == null) {
            promise.reject("ACTIVITY_NULL", "Atividade atual é nula")
            return
        }
        
        if (hasLocationPermission()) {
            promise.resolve(true)
            return
        }
        
        try {
            ActivityCompat.requestPermissions(
                currentActivity,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
            
            // Aqui só informamos que a solicitação foi feita
            // O resultado real seria tratado no callback onRequestPermissionsResult da Activity
            promise.resolve(null)
        } catch (e: Exception) {
            Logger.e(TAG, "Erro ao solicitar permissão: ${e.message}")
            promise.reject("PERMISSION_ERROR", e.message, e)
        }
    }
    
    /**
     * Abre as configurações de localização do dispositivo
     */
    @ReactMethod
    fun openLocationSettings() {
        val currentActivity = currentActivity ?: return
        
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        currentActivity.startActivity(intent)
    }
    
    /**
     * Obtém a localização atual
     * @param promise Promise para retornar o resultado
     */
    @ReactMethod
    fun getCurrentLocation(promise: Promise) {
        if (!hasLocationPermission()) {
            promise.reject("PERMISSION_DENIED", "Permissão de localização não concedida")
            return
        }
        
        try {
            fusedLocationClient?.lastLocation
                ?.addOnSuccessListener { location ->
                    if (location != null) {
                        val locationMap = convertLocationToMap(location)
                        promise.resolve(locationMap)
                    } else {
                        promise.reject("LOCATION_NULL", "Não foi possível obter a localização atual")
                    }
                }
                ?.addOnFailureListener { e ->
                    Logger.e(TAG, "Erro ao obter localização: ${e.message}")
                    promise.reject("LOCATION_ERROR", e.message, e)
                }
        } catch (e: Exception) {
            Logger.e(TAG, "Exceção ao obter localização: ${e.message}")
            promise.reject("LOCATION_EXCEPTION", e.message, e)
        }
    }
    
    /**
     * Inicia o rastreamento de localização
     * @param intervalMs Intervalo de atualização em milissegundos
     * @param promise Promise para retornar o resultado
     */
    @ReactMethod
    fun startLocationTracking(intervalMs: Int, promise: Promise) {
        if (isTracking) {
            promise.resolve(true)
            return
        }
        
        if (!hasLocationPermission()) {
            promise.reject("PERMISSION_DENIED", "Permissão de localização não concedida")
            return
        }
        
        try {
            val locationRequest = LocationRequest.create().apply {
                interval = intervalMs.toLong()
                fastestInterval = (intervalMs / 2).toLong()
                priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            }
            
            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    locationResult.lastLocation?.let { location ->
                        val locationMap = convertLocationToMap(location)
                        sendLocationUpdateEvent(locationMap)
                    }
                }
            }
            
            fusedLocationClient?.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                reactContext.mainLooper
            )
            
            isTracking = true
            promise.resolve(true)
        } catch (e: Exception) {
            Logger.e(TAG, "Erro ao iniciar rastreamento: ${e.message}")
            promise.reject("TRACKING_ERROR", e.message, e)
        }
    }
    
    /**
     * Para o rastreamento de localização
     */
    @ReactMethod
    fun stopLocationTracking(promise: Promise) {
        if (!isTracking) {
            promise.resolve(true)
            return
        }
        
        try {
            locationCallback?.let { callback ->
                fusedLocationClient?.removeLocationUpdates(callback)
            }
            
            locationCallback = null
            isTracking = false
            promise.resolve(true)
        } catch (e: Exception) {
            Logger.e(TAG, "Erro ao parar rastreamento: ${e.message}")
            promise.reject("TRACKING_ERROR", e.message, e)
        }
    }
    
    /**
     * Abre o mapa na localização atual
     */
    @ReactMethod
    fun openMapAtCurrentLocation() {
        val currentActivity = currentActivity ?: return
        
        val intent = Intent(currentActivity, MapActivity::class.java)
        intent.putExtra("SHOW_CURRENT_LOCATION", true)
        currentActivity.startActivity(intent)
    }
    
    /**
     * Converte um objeto Location para um WritableMap
     * @param location Objeto Location a ser convertido
     * @return WritableMap com os dados da localização
     */
    private fun convertLocationToMap(location: Location): WritableMap {
        return Arguments.createMap().apply {
            putDouble("latitude", location.latitude)
            putDouble("longitude", location.longitude)
            putDouble("altitude", location.altitude)
            putDouble("accuracy", location.accuracy.toDouble())
            putDouble("speed", location.speed.toDouble())
            putDouble("bearing", location.bearing.toDouble())
            putDouble("time", location.time.toDouble())
        }
    }
    
    /**
     * Envia evento de atualização de localização para o React Native
     * @param locationMap Mapa com os dados da localização
     */
    private fun sendLocationUpdateEvent(locationMap: WritableMap) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(LOCATION_UPDATE_EVENT, locationMap)
    }
}