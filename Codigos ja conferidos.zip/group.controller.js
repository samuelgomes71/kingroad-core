// group.controller.js
// Controlador para gerenciar grupos e permissões de adição no KingChat

const GroupModel = require('../models/group.model');
const PrivacyModel = require('../models/privacy.model');
const UserModel = require('../models/user.model');
const NotificationService = require('../services/notification.service');

/**
 * Add user to group - with privacy check
 */
exports.addUserToGroup = async (req, res) => {
  try {
    const { groupId, userIds } = req.body;
    const adderId = req.user.id; // The user who is adding others to the group
    
    // Validate inputs
    if (!groupId || !userIds || !Array.isArray(userIds)) {
      return res.status(400).json({ message: 'Parâmetros de requisição inválidos' });
    }
    
    // Check if group exists
    const group = await GroupModel.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Grupo não encontrado' });
    }
    
    // Check if adder is a member of the group
    const isAdderMember = group.members.includes(adderId);
    if (!isAdderMember && adderId !== group.createdBy.toString()) {
      return res.status(403).json({ message: 'Você deve ser membro do grupo para adicionar usuários' });
    }
    
    // Process each user
    const results = {
      added: [],
      alreadyMember: [],
      blocked: []
    };
    
    for (const userId of userIds) {
      // Skip if user is already a member
      if (group.members.includes(userId)) {
        results.alreadyMember.push(userId);
        continue;
      }
      
      // Check if user has given permission to be added
      const canBeAdded = await checkGroupAdditionPermission(adderId, userId);
      
      if (canBeAdded) {
        // Add user to group
        group.members.push(userId);
        
        // Notify user about being added to the group
        await NotificationService.sendGroupAdditionNotification(userId, adderId, groupId);
        
        results.added.push(userId);
      } else {
        results.blocked.push(userId);
      }
    }
    
    // Save group updates
    if (results.added.length > 0) {
      await group.save();
    }
    
    res.status(200).json({ 
      message: 'Processo de adição ao grupo concluído',
      results
    });
  } catch (error) {
    console.error('Erro ao adicionar usuários ao grupo:', error);
    res.status(500).json({ message: 'Falha ao adicionar usuários ao grupo' });
  }
};

/**
 * Create a new group
 */
exports.createGroup = async (req, res) => {
  try {
    const { name, description, members } = req.body;
    const creatorId = req.user.id;
    
    // Validate input
    if (!name) {
      return res.status(400).json({ message: 'Nome do grupo é obrigatório' });
    }
    
    // Create new group
    const newGroup = new GroupModel({
      name,
      description: description || '',
      createdBy: creatorId,
      members: [creatorId, ...(members || [])]
    });
    
    await newGroup.save();
    
    res.status(201).json(newGroup);
  } catch (error) {
    console.error('Erro ao criar grupo:', error);
    res.status(500).json({ message: 'Falha ao criar grupo' });
  }
};

/**
 * Get group details
 */
exports.getGroupDetails = async (req, res) => {
  try {
    const { groupId } = req.params;
    const userId = req.user.id;
    
    const group = await GroupModel.findById(groupId)
      .populate('members', 'name profileImage')
      .populate('createdBy', 'name');
    
    if (!group) {
      return res.status(404).json({ message: 'Grupo não encontrado' });
    }
    
    // Check if user is a member of the group
    if (!group.members.some(member => member._id.toString() === userId)) {
      return res.status(403).json({ message: 'Você não tem permissão para ver este grupo' });
    }
    
    res.status(200).json(group);
  } catch (error) {
    console.error('Erro ao buscar detalhes do grupo:', error);
    res.status(500).json({ message: 'Falha ao buscar detalhes do grupo' });
  }
};

/**
 * Update group addition privacy settings
 */
exports.updateGroupAdditionPrivacy = async (req, res) => {
  try {
    const userId = req.user.id;
    const { groupAdditionOption, selectedContactsForGroupAddition } = req.body;
    
    // Validate input data
    if (!['all', 'selected', 'none'].includes(groupAdditionOption)) {
      return res.status(400).json({ message: 'Opção de adição a grupo inválida' });
    }
    
    // Update or create privacy settings
    const updatedSettings = await PrivacyModel.findOneAndUpdate(
      { userId },
      { 
        $set: {
          groupAdditionOption,
          selectedContactsForGroupAddition: groupAdditionOption === 'selected' 
            ? selectedContactsForGroupAddition 
            : []
        }
      },
      { new: true, upsert: true }
    );
    
    res.status(200).json(updatedSettings);
  } catch (error) {
    console.error('Erro ao atualizar configurações de privacidade de adição a grupos:', error);
    res.status(500).json({ message: 'Falha ao atualizar configurações de privacidade' });
  }
};

/**
 * Remove user from group
 */
exports.removeUserFromGroup = async (req, res) => {
  try {
    const { groupId, userId } = req.params;
    const currentUserId = req.user.id;
    
    const group = await GroupModel.findById(groupId);
    
    if (!group) {
      return res.status(404).json({ message: 'Grupo não encontrado' });
    }
    
    // Check permissions - only admin or self can remove
    const isAdmin = group.createdBy.toString() === currentUserId;
    const isSelf = userId === currentUserId;
    
    if (!isAdmin && !isSelf) {
      return res.status(403).json({ 
        message: 'Você não tem permissão para remover este usuário do grupo' 
      });
    }
    
    // Remove user from group
    group.members = group.members.filter(
      member => member.toString() !== userId
    );
    
    await group.save();
    
    res.status(200).json({ message: 'Usuário removido do grupo com sucesso' });
  } catch (error) {
    console.error('Erro ao remover usuário do grupo:', error);
    res.status(500).json({ message: 'Falha ao remover usuário do grupo' });
  }
};

/**
 * Update group details
 */
exports.updateGroup = async (req, res) => {
  try {
    const { groupId } = req.params;
    const { name, description } = req.body;
    const userId = req.user.id;
    
    const group = await GroupModel.findById(groupId);
    
    if (!group) {
      return res.status(404).json({ message: 'Grupo não encontrado' });
    }
    
    // Only creator can update group details
    if (group.createdBy.toString() !== userId) {
      return res.status(403).json({ 
        message: 'Apenas o criador do grupo pode atualizar seus detalhes' 
      });
    }
    
    // Update group
    if (name) group.name = name;
    if (description !== undefined) group.description = description;
    
    await group.save();
    
    res.status(200).json(group);
  } catch (error) {
    console.error('Erro ao atualizar grupo:', error);
    res.status(500).json({ message: 'Falha ao atualizar grupo' });
  }
};

/**
 * Delete group
 */
exports.deleteGroup = async (req, res) => {
  try {
    const { groupId } = req.params;
    const userId = req.user.id;
    
    const group = await GroupModel.findById(groupId);
    
    if (!group) {
      return res.status(404).json({ message: 'Grupo não encontrado' });
    }
    
    // Only creator can delete group
    if (group.createdBy.toString() !== userId) {
      return res.status(403).json({ 
        message: 'Apenas o criador do grupo pode excluí-lo' 
      });
    }
    
    await GroupModel.findByIdAndDelete(groupId);
    
    res.status(200).json({ message: 'Grupo excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir grupo:', error);
    res.status(500).json({ message: 'Falha ao excluir grupo' });
  }
};

/**
 * Helper function to check if a user can be added to a group by another user
 * @param {String} adderId - The ID of the user trying to add
 * @param {String} targetUserId - The ID of the user being added
 * @returns {Promise<Boolean>} Whether the target user allows being added
 */
const checkGroupAdditionPermission = async (adderId, targetUserId) => {
  try {
    // Get target user's privacy settings
    const targetPrivacy = await PrivacyModel.findOne({ userId: targetUserId });
    
    // If no settings found, default to 'all' (anyone can add)
    if (!targetPrivacy) return true;
    
    const { groupAdditionOption, selectedContactsForGroupAddition } = targetPrivacy;
    
    // Check based on privacy option
    switch (groupAdditionOption) {
      case 'all':
        return true;
      case 'selected':
        return selectedContactsForGroupAddition.includes(adderId);
      case 'none':
        return false;
      default:
        return true;
    }
  } catch (error) {
    console.error('Erro ao verificar permissões de adição a grupo:', error);
    // Default to more private option in case of error
    return false;
  }
};