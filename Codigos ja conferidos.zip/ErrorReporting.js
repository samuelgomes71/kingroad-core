import StorageService from '../utils/StorageService';

/**
 * Serviço para gerenciamento de relatórios de erro
 * Fornece funcionalidades para registrar, armazenar e analisar erros do sistema
 */
class ErrorReporting {
  // Constantes
  static MAX_LOGS = 100;
  static ERROR_LOGS_KEY = 'error_logs';

  /**
   * Registra um novo erro no sistema
   * @param {string} context - Contexto onde o erro ocorreu
   * @param {Error|Object|string} error - Objeto de erro ou mensagem
   * @returns {Promise<Object>} O log de erro criado
   */
  static async logError(context, error) {
    try {
      const newLog = {
        id: Date.now().toString(),
        context: context || 'Unknown Context',
        message: error instanceof Error ? error.message : (error.toString ? error.toString() : 'Unknown Error'),
        stack: error instanceof Error ? error.stack : null,
        timestamp: new Date().toISOString(),
        appVersion: '1.0.0', // Versão do aplicativo
        userAgent: navigator.userAgent
      };
      
      // Recuperar logs existentes
      const currentLogs = await this.getErrorLogs();
      
      // Adicionar novo log no início e limitar quantidade
      const updatedLogs = [newLog, ...currentLogs].slice(0, this.MAX_LOGS);
      
      // Salvar logs atualizados
      await this.saveErrorLogs(updatedLogs);
      
      // Se o erro for crítico, tentar enviar para o servidor
      if (this.isCriticalError(error)) {
        this.sendErrorToServer(newLog).catch(e => 
          console.warn('Falha ao enviar erro para o servidor:', e)
        );
      }
      
      return newLog;
    } catch (savingError) {
      console.error('Erro ao registrar erro:', savingError);
      return {
        id: Date.now().toString(),
        context,
        message: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
        note: 'Erro não pôde ser salvo corretamente'
      };
    }
  }

  /**
   * Recupera todos os logs de erro armazenados
   * @returns {Promise<Array>} Array de logs de erro
   */
  static async getErrorLogs() {
    try {
      const logs = await StorageService.getData(this.ERROR_LOGS_KEY);
      return Array.isArray(logs) ? logs : [];
    } catch (error) {
      console.error('Erro ao recuperar logs:', error);
      return [];
    }
  }

  /**
   * Salva logs de erro no armazenamento
   * @param {Array} logs - Array de logs para salvar
   * @returns {Promise<boolean>} Sucesso da operação
   */
  static async saveErrorLogs(logs) {
    try {
      await StorageService.saveData(this.ERROR_LOGS_KEY, logs);
      return true;
    } catch (error) {
      console.error('Erro ao salvar logs:', error);
      return false;
    }
  }

  /**
   * Limpa todos os logs de erro
   * @returns {Promise<boolean>} Sucesso da operação
   */
  static async clearErrorLogs() {
    try {
      await StorageService.saveData(this.ERROR_LOGS_KEY, []);
      return true;
    } catch (error) {
      console.error('Erro ao limpar logs:', error);
      return false;
    }
  }

  /**
   * Exporta logs de erro como arquivo JSON
   * @returns {Promise<Blob>} Blob contendo logs em formato JSON
   */
  static async exportErrorLogs() {
    try {
      const logs = await this.getErrorLogs();
      const data = JSON.stringify(logs, null, 2);
      return new Blob([data], { type: 'application/json' });
    } catch (error) {
      console.error('Erro ao exportar logs:', error);
      throw error;
    }
  }

  /**
   * Verifica se um erro é crítico
   * @param {Error|Object|string} error - Erro a ser verificado
   * @returns {boolean} Verdadeiro se o erro for crítico
   */
  static isCriticalError(error) {
    // Implementação simples - poderia ser mais sofisticada em produção
    if (error instanceof Error) {
      // Erros de rede são críticos
      if (error.name === 'NetworkError' || error.message.includes('network')) {
        return true;
      }
      
      // Erros de permissão são críticos
      if (error.name === 'SecurityError' || error.message.includes('permission')) {
        return true;
      }
      
      // Erros de armazenamento são críticos
      if (error.message.includes('storage') || error.message.includes('quota')) {
        return true;
      }
    }
    
    return false;
  }

  /**
   * Envia um erro para o servidor (simulado)
   * @param {Object} errorLog - Log de erro a enviar
   * @returns {Promise<Object>} Resposta do servidor
   */
  static async sendErrorToServer(errorLog) {
    // Em um ambiente real, isso enviaria o erro para um backend
    // Simulação de envio para API
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('Erro crítico enviado para o servidor:', errorLog);
        resolve({ success: true, id: errorLog.id });
      }, 500);
    });
  }

  /**
   * Analisa logs para detectar padrões de erro
   * @returns {Promise<Object>} Análise de erros por contexto e tipo
   */
  static async analyzeErrorPatterns() {
    try {
      const logs = await this.getErrorLogs();
      
      // Contagem por contexto
      const contextCounts = {};
      // Contagem por tipo de erro
      const errorTypes = {};
      // Análise temporal - últimas 24 horas
      const last24Hours = [];
      
      const now = new Date();
      const oneDayAgo = new Date(now.getTime() - (24 * 60 * 60 * 1000));
      
      logs.forEach(log => {
        // Contagem por contexto
        contextCounts[log.context] = (contextCounts[log.context] || 0) + 1;
        
        // Análise de tipo de erro
        let errorType = 'Unknown';
        if (log.message) {
          if (log.message.includes('network')) errorType = 'Network';
          else if (log.message.includes('permission')) errorType = 'Permission';
          else if (log.message.includes('storage')) errorType = 'Storage';
          else if (log.message.includes('timeout')) errorType = 'Timeout';
        }
        
        errorTypes[errorType] = (errorTypes[errorType] || 0) + 1;
        
        // Verificar se o erro ocorreu nas últimas 24 horas
        const logDate = new Date(log.timestamp);
        if (logDate >= oneDayAgo) {
          last24Hours.push(log);
        }
      });
      
      return {
        total: logs.length,
        byContext: contextCounts,
        byType: errorTypes,
        last24Hours: last24Hours.length,
        mostCommonContext: Object.entries(contextCounts)
          .sort((a, b) => b[1] - a[1])[0]?.[0] || 'None'
      };
    } catch (error) {
      console.error('Erro ao analisar padrões:', error);
      return {
        total: 0,
        byContext: {},
        byType: {},
        last24Hours: 0,
        mostCommonContext: 'None'
      };
    }
  }
}

export default ErrorReporting;