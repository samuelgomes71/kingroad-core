import React, { useState } from 'react';
import { ChevronLeft, Truck, Scale } from 'lucide-react';

const VehicleProfileScreen = ({ onBack, onSave }) => {
  const [vehicle, setVehicle] = useState({
    type: 'truck',
    weight: 17,
    height: 4.5,
    width: 2.6,
    length: 16.5,
    axles: 5,
    hazmat: false
  });

  return (
    <div className="h-screen bg-[#121212]">
      {/* Header */}
      <div className="flex items-center p-4 bg-[#1E1E1E]">
        <button onClick={onBack} className="p-2">
          <ChevronLeft className="text-white" size={24} />
        </button>
        <h1 className="text-white text-xl ml-2">Vehicle Profile</h1>
      </div>

      {/* Vehicle Info */}
      <div className="p-4">
        <div className="bg-[#1E1E1E] rounded-lg p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Truck size={24} className="text-blue-500 mr-2" />
              <span className="text-white font-bold">Vehicle Dimensions</span>
            </div>
          </div>

          {/* Dimensions */}
          <div className="space-y-4">
            <div>
              <label className="text-gray-400 block mb-1">Weight (t)</label>
              <input
                type="number"
                value={vehicle.weight}
                onChange={(e) => setVehicle({...vehicle, weight: e.target.value})}
                className="w-full bg-[#252525] text-white p-2 rounded"
              />
            </div>
            <div>
              <label className="text-gray-400 block mb-1">Height (m)</label>
              <input
                type="number"
                value={vehicle.height}
                onChange={(e) => setVehicle({...vehicle, height: e.target.value})}
                className="w-full bg-[#252525] text-white p-2 rounded"
              />
            </div>
            {/* Outros campos... */}
          </div>
        </div>

        {/* Cargo Type */}
        <div className="bg-[#1E1E1E] rounded-lg p-4">
          <div className="flex items-center mb-4">
            <Scale size={24} className="text-yellow-500 mr-2" />
            <span className="text-white font-bold">Cargo Type</span>
          </div>
          
          <div className="space-y-2">
            <label className="flex items-center text-white">
              <input
                type="checkbox"
                checked={vehicle.hazmat}
                onChange={(e) => setVehicle({...vehicle, hazmat: e.target.checked})}
                className="mr-2"
              />
              Hazardous Materials
            </label>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#1E1E1E]">
        <button
          onClick={() => onSave(vehicle)}
          className="w-full bg-blue-600 text-white p-4 rounded-lg font-bold"
        >
          Save Profile
        </button>
      </div>
    </div>
  );
};

export default VehicleProfileScreen;