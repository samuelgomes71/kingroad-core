data class OperatingHours(
    val loadingHours: Schedule,
    val securityOfficeHours: Schedule,
    val specialInstructions: String? = null
)

data class Schedule(
    val weekday: TimeRange,
    val saturday: TimeRange?,
    val sunday: TimeRange?,
    val holidays: TimeRange?
)

data class TimeRange(
    val start: String,  // formato "HH:mm"
    val end: String     // formato "HH:mm"
)