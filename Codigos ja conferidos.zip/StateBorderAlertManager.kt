// Sistema de Alerta de Divisas
// app/src/main/kotlin/com/kingroad/alerts/borders

class StateBorderAlertManager(
    private val locationService: LocationService,
    private val borderService: BorderService,
    private val audioManager: AudioManager,
    private val preferencesManager: PreferencesManager
) {
    data class BorderAlert(
        val fromState: State,
        val toState: State,
        val distance: Double,
        val borderPoint: Location,
        val roadInfo: RoadInfo?
    )

    data class State(
        val name: String,
        val abbreviation: String,
        val region: Region
    )

    data class RoadInfo(
        val roadNumber: String,
        val hasInspection: Boolean,
        val hasTollBooth: Boolean,
        val hasWeightStation: Boolean
    )

    // Monitorar aproximação de divisas
    suspend fun startBorderMonitoring() {
        locationService.startLocationUpdates { currentLocation ->
            checkNearbyBorders(currentLocation)
        }
    }

    // Verificar divisas próximas
    private suspend fun checkNearbyBorders(location: Location) {
        val nearbyBorders = borderService.findNearbyBorders(
            location = location,
            radius = ALERT_RADIUS
        )

        nearbyBorders.forEach { border ->
            val distance = calculateDistance(location, border.borderPoint)
            
            if (distance <= ALERT_DISTANCE && !hasAlertedRecently(border)) {
                playBorderAlert(border)
                markAlertAsShown(border)
            }
        }
    }

    // Reproduzir alerta sonoro
    private suspend fun playBorderAlert(border: BorderAlert) {
        val message = buildAlertMessage(border)
        
        audioManager.playAlert(
            message = message,
            priority = AlertPriority.MEDIUM,
            volume = calculateAlertVolume()
        )
    }

    // Construir mensagem de alerta
    private fun buildAlertMessage(border: BorderAlert): String {
        return buildString {
            append("Atenção! ")
            append("Divisa de ${border.fromState.name} com ${border.toState.name} a ${formatDistance(border.distance)}. ")
            
            // Adicionar informações relevantes
            border.roadInfo?.let { info ->
                if (info.hasInspection) {
                    append("Posto de fiscalização na divisa. ")
                }
                if (info.hasTollBooth) {
                    append("Pedágio na divisa. ")
                }
                if (info.hasWeightStation) {
                    append("Balança na divisa. ")
                }
            }
        }
    }

    // Verificar se já alertou recentemente
    private fun hasAlertedRecently(border: BorderAlert): Boolean {
        val lastAlert = recentAlerts[border.borderPoint]
        if (lastAlert == null) return false
        
        return (System.currentTimeMillis() - lastAlert) < MIN_ALERT_INTERVAL
    }

    // Marcar alerta como exibido
    private fun markAlertAsShown(border: BorderAlert) {
        recentAlerts[border.borderPoint] = System.currentTimeMillis()
    }

    // Calcular volume do alerta baseado nas condições
    private fun calculateAlertVolume(): Float {
        val baseVolume = preferencesManager.getAlertVolume()
        val timeOfDay = getCurrentTimeOfDay()
        
        return when (timeOfDay) {
            TimeOfDay.NIGHT -> baseVolume * 0.7f
            TimeOfDay.DAWN, TimeOfDay.DUSK -> baseVolume * 0.8f
            else -> baseVolume
        }
    }

    private val recentAlerts = mutableMapOf<Location, Long>()

    companion object {
        const val ALERT_RADIUS = 5000.0 // 5km
        const val ALERT_DISTANCE = 1000.0 // 1km
        const val MIN_ALERT_INTERVAL = 5 * 60 * 1000L // 5 minutos
    }
}

// Gerenciador de áudio
interface AudioManager {
    suspend fun playAlert(
        message: String,
        priority: AlertPriority,
        volume: Float
    )

    fun setDefaultVolume(volume: Float)
    fun enableNightMode(enabled: Boolean)
}

enum class AlertPriority {
    HIGH,
    MEDIUM,
    LOW
}

enum class TimeOfDay {
    DAWN,
    MORNING,
    AFTERNOON,
    DUSK,
    NIGHT
}

// Utilitários
fun formatDistance(meters: Double): String {
    return when {
        meters < 1000 -> "${meters.toInt()} metros"
        else -> "${(meters / 1000).toInt()} quilômetros"
    }
}