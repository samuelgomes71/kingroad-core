// Configurações para Moto
  const renderMotoSettings = (settings) => (
    <View style={styles.settingsContainer}>
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="record-rec" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Gravação de Rota</Text>
        </View>
        <Switch
          value={settings.recordingEnabled}
          onValueChange={(value) => updateSetting('recordingEnabled', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.recordingEnabled ? '#E91E63' : '#F5F5F5'}
        />
      </View>
      
      <Text style={styles.settingGroupTitle}>Tipo de Motocicleta</Text>
      <View style={styles.optionButtonsRow}>
        <TouchableOpacity
          style={[
            styles.optionButton,
            settings.motoType === 'urban' && styles.optionButtonActive,
            { borderColor: '#E91E63' }
          ]}
          onPress={() => updateSetting('motoType', 'urban')}
        >
          <Text style={[
            styles.optionButtonText,
            settings.motoType === 'urban' && styles.optionButtonTextActive
          ]}>Urbana</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.optionButton,
            settings.motoType === 'road' && styles.optionButtonActive,
            { borderColor: '#E91E63' }
          ]}
          onPress={() => updateSetting('motoType', 'road')}
        >
          <Text style={[
            styles.optionButtonText,
            settings.motoType === 'road' && styles.optionButtonTextActive
          ]}>Estrada</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.optionButton,
            settings.motoType === 'trail' && styles.optionButtonActive,
            { borderColor: '#E91E63' }
          ]}
          onPress={() => updateSetting('motoType', 'trail')}
        >
          <Text style={[
            styles.optionButtonText,
            settings.motoType === 'trail' && styles.optionButtonTextActive
          ]}>Trilha</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="gas-station" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Mostrar Postos de Combustível</Text>
        </View>
        <Switch
          value={settings.showGasStations}
          onValueChange={(value) => updateSetting('showGasStations', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.showGasStations ? '#E91E63' : '#F5F5F5'}
        />
      </View>
      
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="image-filter-hdr" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Preferir Rotas Cênicas</Text>
        </View>
        <Switch
          value={settings.preferScenic}
          onValueChange={(value) => updateSetting('preferScenic', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.preferScenic ? '#E91E63' : '#F5F5F5'}
        />
      </View>
      
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="highway" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Evitar Autoestradas</Text>
        </View>
        <Switch
          value={settings.avoidHighways}
          onValueChange={(value) => updateSetting('avoidHighways', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.avoidHighways ? '#E91E63' : '#F5F5F5'}
        />
      </View>
      
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="road-variant" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Mostrar Condições da Trilha</Text>
        </View>
        <Switch
          value={settings.showTrailConditions}
          onValueChange={(value) => updateSetting('showTrailConditions', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.showTrailConditions ? '#E91E63' : '#F5F5F5'}
        />
      </View>
      
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Icon name="altimeter" size={20} color="#E91E63" />
          <Text style={styles.settingLabel}>Registrar Altitude</Text>
        </View>
        <Switch
          value={settings.recordAltitude}
          onValueChange={(value) => updateSetting('recordAltitude', value)}
          trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
          thumbColor={settings.recordAltitude ? '#E91E63' : '#F5F5F5'}
        />
      </View>
    </View>
  );
  
  // Configurações para 4x4
  const render4x4Settings = (settings) => (
    <View style={styles.settingsContainer}>
      <View style={styles.settingRow}>
        <View style={