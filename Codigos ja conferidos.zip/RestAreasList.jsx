// RestAreasList.jsx
import React from 'react';
import { Shield, Users } from 'lucide-react';
import { getParkingStatusColor } from '../utils/uiHelpers';

const RestAreasList = ({ areas, onSelectPOI }) => {
  return (
    <div className="space-y-2">
      {areas.map((area) => (
        <div 
          key={area.id} 
          className="bg-stone-800 rounded-lg p-3 cursor-pointer"
          onClick={() => onSelectPOI(area)}
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-white font-bold text-lg">{area.name}</h3>
              <p className="text-stone-300 text-sm">{area.highway}</p>
              <div className="flex items-center mt-1">
                <Shield size={14} className={`mr-1 ${
                  area.security === 'high' ? 'text-emerald-500' : 
                  area.security === 'medium' ? 'text-amber-500' : 'text-red-500'
                }`} />
                <span className="text-stone-400 text-xs">
                  {area.security === 'high' ? 'Alta segurança' : 
                   area.security === 'medium' ? 'Segurança média' : 'Baixa segurança'}
                </span>
                <div className="ml-3 flex items-center">
                  <Users size={14} className="text-stone-400 mr-1" />
                  <span className="text-stone-400 text-xs">{area.reports} relatos</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-amber-300 font-bold text-lg">{area.distance}</span>
              <span className="text-stone-400 text-xs">km</span>
              <div className={`mt-2 px-2 py-1 rounded-md text-xs text-white ${getParkingStatusColor(area.parking)}`}>
                {area.parking === 'many' ? 'VAGAS DISPONÍVEIS' : 
                 area.parking === 'some' ? 'POUCAS VAGAS' : 'LOTADO'}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RestAreasList;