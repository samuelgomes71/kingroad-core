import React, { useState, useEffect, useRef } from 'react';

const RouteSimulator = () => {
  const [speed, setSpeed] = useState(100);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [routePoints, setRoutePoints] = useState([]);
  const [currentPosition, setCurrentPosition] = useState(null);
  const mapRef = useRef(null);
  const animationRef = useRef(null);
  
  // Rota simulada para King Road
  // Em uma implementação real, estes pontos viriam de uma API
  useEffect(() => {
    // Simula uma rota com pontos
    const generateRoutePoints = () => {
      const points = [];
      // Cria uma rota simulada com 100 pontos
      for (let i = 0; i < 100; i++) {
        points.push({
          id: i,
          lat: -23.55 + (Math.random() * 0.1 - 0.05),
          lng: -46.63 + (Math.random() * 0.1 - 0.05),
          // Adiciona dados simulados de tráfego
          speed: Math.floor(Math.random() * 80) + 20,
          congestion: Math.random() > 0.7 ? 'alto' : Math.random() > 0.4 ? 'médio' : 'baixo'
        });
      }
      return points;
    };

    setRoutePoints(generateRoutePoints());
  }, []);

  // Função para iniciar/pausar a simulação
  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  // Reset da simulação
  const resetSimulation = () => {
    setIsPlaying(false);
    setProgress(0);
    setCurrentPosition(null);
  };

  // Efeito para animar a rota com base na velocidade
  useEffect(() => {
    if (!routePoints.length) return;
    
    if (isPlaying) {
      const animate = () => {
        setProgress(prev => {
          const newProgress = prev + (0.2 * (speed / 100));
          
          if (newProgress >= 100) {
            setIsPlaying(false);
            return 100;
          }
          
          // Calcula a posição atual na rota
          const pointIndex = Math.min(
            Math.floor((newProgress / 100) * (routePoints.length - 1)),
            routePoints.length - 1
          );
          
          setCurrentPosition(routePoints[pointIndex]);
          
          return newProgress;
        });
        
        animationRef.current = requestAnimationFrame(animate);
      };
      
      animationRef.current = requestAnimationFrame(animate);
    } else if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, speed, routePoints]);

  // Renderiza a condição do tráfego com cores
  const getTrafficColor = (congestion) => {
    switch(congestion) {
      case 'alto': return 'bg-red-500';
      case 'médio': return 'bg-yellow-500';
      case 'baixo': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Simulador de Rota - King Road (Atualizado)</h2>
      
      {/* Mapa simulado */}
      <div 
        ref={mapRef}
        className="w-full h-64 bg-gray-200 rounded-lg mb-4 relative overflow-hidden"
      >
        {/* Rota desenhada */}
        <svg className="absolute inset-0 w-full h-full">
          <path 
            d={routePoints.map((point, i) => 
              `${i === 0 ? 'M' : 'L'} ${(point.lng + 46.63) * 500} ${(point.lat + 23.55) * 500}`
            ).join(' ')}
            stroke="#3b82f6"
            strokeWidth="3"
            fill="none"
          />
          
          {/* Pontos de rota com indicador de tráfego */}
          {routePoints.map((point, index) => (
            <circle 
              key={point.id}
              cx={(point.lng + 46.63) * 500}
              cy={(point.lat + 23.55) * 500}
              r="2"
              className={getTrafficColor(point.congestion)}
            />
          ))}
          
          {/* Posição atual do veículo */}
          {currentPosition && (
            <circle 
              cx={(currentPosition.lng + 46.63) * 500}
              cy={(currentPosition.lat + 23.55) * 500}
              r="5"
              fill="blue"
              stroke="white"
              strokeWidth="2"
            />
          )}
        </svg>
        
        {/* Legenda */}
        <div className="absolute bottom-2 right-2 bg-white p-2 rounded shadow text-xs">
          <div className="flex items-center mb-1">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
            <span>Tráfego leve</span>
          </div>
          <div className="flex items-center mb-1">
            <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
            <span>Tráfego moderado</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
            <span>Tráfego intenso</span>
          </div>
        </div>
      </div>
      
      {/* Informações da posição atual */}
      <div className="mb-4 p-3 bg-gray-100 rounded">
        {currentPosition ? (
          <div>
            <h3 className="font-bold">Informações atuais:</h3>
            <p>Velocidade: {currentPosition.speed} km/h</p>
            <p>Congestionamento: {currentPosition.congestion}</p>
            <p>Progresso: {Math.round(progress)}%</p>
            <p>Tempo estimado: {Math.ceil((100 - progress) / (speed/100))} segundos</p>
          </div>
        ) : (
          <p className="text-center text-gray-600">Inicie a simulação para ver detalhes da rota</p>
        )}
      </div>
      
      {/* Controles de velocidade */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Velocidade da simulação: {speed}%
        </label>
        <input
          type="range"
          min="1"
          max="300"
          value={speed}
          onChange={(e) => setSpeed(parseInt(e.target.value))}
          className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500">
          <span>1%</span>
          <span>100%</span>
          <span>300%</span>
        </div>
      </div>
      
      {/* Botões de controle */}
      <div className="flex justify-center space-x-4">
        <button
          onClick={togglePlay}
          className={`px-4 py-2 rounded-lg font-medium ${
            isPlaying ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-green-500 hover:bg-green-600'
          } text-white focus:outline-none`}
        >
          {isPlaying ? 'Pausar' : 'Iniciar'}
        </button>
        <button
          onClick={resetSimulation}
          className="px-4 py-2 rounded-lg font-medium bg-gray-500 hover:bg-gray-600 text-white focus:outline-none"
        >
          Reiniciar
        </button>
      </div>
    </div>
  );
};

export default RouteSimulator;