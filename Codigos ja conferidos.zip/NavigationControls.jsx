import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
  faVolumeUp,
  faVolumeMute,
  faCompass,
  faTruck,
  faCar,
  faExclamationTriangle,
  faCog
} from '@fortawesome/free-solid-svg-icons';

/**
 * NavigationControls - Botões principais da interface de navegação do KingRoad
 */
const NavigationControls = ({
  isDarkMode,
  audioEnabled,
  toggleAudio,
  voiceCommandActive,
  startVoiceCommand,
  vehicleSpecs,
  setVehicleSpecs,
  setEmergencyMode,
  setShowSettings
}) => {
  return (
    <View style={styles.controlButtons}>
      {/* Áudio on/off */}
      <TouchableOpacity style={styles.controlButton} onPress={toggleAudio}>
        <FontAwesomeIcon
          icon={audioEnabled ? faVolumeUp : faVolumeMute}
          color={isDarkMode ? '#FFF' : '#000'}
          size={24}
        />
      </TouchableOpacity>

      {/* Comando de voz */}
      <TouchableOpacity
        style={[styles.controlButton, voiceCommandActive && styles.activeVoiceCommand]}
        onPress={startVoiceCommand}
        disabled={voiceCommandActive}
      >
        <FontAwesomeIcon
          icon={faCompass}
          color={isDarkMode ? '#FFF' : '#000'}
          size={24}
        />
      </TouchableOpacity>

      {/* Alternar modo caminhão/carro */}
      <TouchableOpacity
        style={styles.controlButton}
        onPress={() => setVehicleSpecs({
          ...vehicleSpecs,
          type: vehicleSpecs.type === 'truck' ? 'car' : 'truck'
        })}
      >
        <FontAwesomeIcon
          icon={vehicleSpecs.type === 'truck' ? faTruck : faCar}
          color={isDarkMode ? '#FFF' : '#000'}
          size={24}
        />
      </TouchableOpacity>

      {/* Modo emergência */}
      <TouchableOpacity
        style={[styles.controlButton, styles.emergencyButton]}
        onPress={() => setEmergencyMode(true)}
      >
        <FontAwesomeIcon icon={faExclamationTriangle} color="#FFF" size={24} />
      </TouchableOpacity>

      {/* Configurações */}
      <TouchableOpacity
        style={styles.controlButton}
        onPress={() => setShowSettings(true)}
      >
        <FontAwesomeIcon icon={faCog} color={isDarkMode ? '#FFF' : '#000'} size={24} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  controlButtons: {
    position: 'absolute',
    right: 20,
    bottom: 150,
    alignItems: 'center',
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  activeVoiceCommand: {
    backgroundColor: '#4CAF50',
  },
  emergencyButton: {
    backgroundColor: '#CC0000',
  },
});

export default NavigationControls;