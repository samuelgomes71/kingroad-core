/**
 * SplashScreen.js
 * 
 * Tela de splash exibida durante o carregamento do aplicativo
 * Mostra o logo e o status de carregamento
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ActivityIndicator,
  Animated,
  Dimensions
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';

// Importa serviços
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import ResourceLoaderService from '../services/ResourceLoaderService';

const { width, height } = Dimensions.get('window');

const SplashScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const [loadingText, setLoadingText] = useState('');
  const [progress, setProgress] = useState(0);
  const [fadeAnim] = useState(new Animated.Value(0));
  const [scaleAnim] = useState(new Animated.Value(0.8));
  
  useEffect(() => {
    // Iniciar animações
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true
      })
    ]).start();
    
    // Iniciar carregamento da aplicação
    initializeApp();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Atualiza texto de carregamento ao mudar o idioma
      updateLoadingText(progress);
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);
  
  // Atualiza o texto de carregamento baseado no progresso
  const updateLoadingText = (currentProgress) => {
    if (currentProgress < 0.3) {
      setLoadingText(t('screen.splash.loading_resources'));
    } else if (currentProgress < 0.6) {
      setLoadingText(t('screen.splash.initializing_services'));
    } else if (currentProgress < 0.9) {
      setLoadingText(t('screen.splash.preparing_map'));
    } else {
      setLoadingText(t('screen.splash.almost_ready'));
    }
  };
  
  // Inicializa a aplicação
  const initializeApp = async () => {
    try {
      // Carrega recursos
      setProgress(0.1);
      updateLoadingText(0.1);
      await ResourceLoaderService.loadInitialResources();
      
      // Inicializa serviços
      setProgress(0.4);
      updateLoadingText(0.4);
      await TranslationsService.initialize();
      await RegionalSettingsService.initialize();
      
      // Prepara mapa e dados
      setProgress(0.7);
      updateLoadingText(0.7);
      await new Promise(resolve => setTimeout(resolve, 500)); // Simula carregamento
      
      // Finaliza carregamento
      setProgress(1);
      updateLoadingText(1);
      
      // Navega para a tela principal
      setTimeout(() => {
        navigation.replace('Main');
      }, 1000);
    } catch (error) {
      console.error('Erro ao inicializar aplicativo:', error);
      setLoadingText(t('screen.splash.error_loading'));
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.primary }]}>
      <Animated.View 
        style={[
          styles.logoContainer, 
          { 
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }]
          }
        ]}
      >
        <Image 
          source={require('../assets/logo.png')} 
          style={styles.logo}
          resizeMode="contain"
        />
        
        <View style={styles.betaContainer}>
          <Text style={styles.betaText}>
            {t('screen.splash.beta')}
          </Text>
        </View>
      </Animated.View>
      
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="white" />
        <Text style={styles.loadingText}>
          {loadingText}
        </Text>
        
        <View style={styles.progressBarContainer}>
          <View 
            style={[
              styles.progressBar, 
              { width: `${progress * 100}%` }
            ]} 
          />
        </View>
        
        <Text style={styles.versionText}>
          {t('screen.splash.version', { version: '1.0.0' })}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40
  },
  logo: {
    width: width * 0.6,
    height: width * 0.3,
  },
  betaContainer: {
    position: 'absolute',
    top: -10,
    right: -10,
    backgroundColor: '#FFC107',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4
  },
  betaText: {
    color: '#000',
    fontSize: 12,
    fontWeight: 'bold'
  },
  loadingContainer: {
    alignItems: 'center',
    width: '80%'
  },
  loadingText: {
    color: 'white',
    marginTop: 12,
    fontSize: 16,
    textAlign: 'center'
  },
  progressBarContainer: {
    height: 4,
    width: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginTop: 20,
    overflow: 'hidden'
  },
  progressBar: {
    height: '100%',
    backgroundColor: 'white',
    borderRadius: 2
  },
  versionText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
    marginTop: 20
  }
});

export default SplashScreen;