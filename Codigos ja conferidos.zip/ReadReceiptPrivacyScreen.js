// ReadReceiptPrivacyScreen.js
// Componente para controle de privacidade das confirmações de leitura

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Switch } from 'react-native';
import { getContacts, updatePrivacySettings } from '../services/api';

const ReadReceiptPrivacyScreen = () => {
  const [privacyOption, setPrivacyOption] = useState('all'); // 'all', 'selected', 'none'
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch user contacts and current privacy settings
    const fetchData = async () => {
      try {
        setLoading(true);
        const contactsData = await getContacts();
        const currentSettings = await getUserPrivacySettings();
        
        setContacts(contactsData);
        setPrivacyOption(currentSettings.readReceiptOption || 'all');
        setSelectedContacts(currentSettings.selectedContactsForReadReceipts || []);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handlePrivacyOptionChange = (option) => {
    setPrivacyOption(option);
  };

  const toggleContactSelection = (contactId) => {
    setSelectedContacts(prevSelected => {
      if (prevSelected.includes(contactId)) {
        return prevSelected.filter(id => id !== contactId);
      } else {
        return [...prevSelected, contactId];
      }
    });
  };

  const savePrivacySettings = async () => {
    try {
      setLoading(true);
      await updatePrivacySettings({
        readReceiptOption: privacyOption,
        selectedContactsForReadReceipts: privacyOption === 'selected' ? selectedContacts : []
      });
      
      // Show success message
      alert('Privacy settings updated successfully');
    } catch (error) {
      console.error('Error saving privacy settings:', error);
      alert('Failed to update privacy settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Confirmações de Leitura</Text>
      <Text style={styles.description}>
        Escolha quem pode ver quando você leu uma mensagem
      </Text>

      <View style={styles.optionsContainer}>
        <TouchableOpacity 
          style={[styles.option, privacyOption === 'all' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('all')}
        >
          <Text style={styles.optionText}>Todos os Contatos</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.option, privacyOption === 'selected' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('selected')}
        >
          <Text style={styles.optionText}>Contatos Selecionados</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.option, privacyOption === 'none' && styles.selectedOption]}
          onPress={() => handlePrivacyOptionChange('none')}
        >
          <Text style={styles.optionText}>Nenhum Contato</Text>
        </TouchableOpacity>
      </View>

      {privacyOption === 'selected' && (
        <View style={styles.contactsContainer}>
          <Text style={styles.contactsTitle}>Selecione os contatos:</Text>
          <FlatList
            data={contacts}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View style={styles.contactItem}>
                <Text style={styles.contactName}>{item.name}</Text>
                <Switch
                  value={selectedContacts.includes(item.id)}
                  onValueChange={() => toggleContactSelection(item.id)}
                />
              </View>
            )}
          />
        </View>
      )}

      <TouchableOpacity 
        style={styles.saveButton}
        onPress={savePrivacySettings}
        disabled={loading}
      >
        <Text style={styles.saveButtonText}>
          {loading ? 'Salvando...' : 'Salvar Configurações'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#666',
    marginBottom: 24,
  },
  optionsContainer: {
    marginBottom: 24,
  },
  option: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  selectedOption: {
    backgroundColor: '#f0f8ff',
  },
  optionText: {
    fontSize: 16,
  },
  contactsContainer: {
    flex: 1,
    marginBottom: 16,
  },
  contactsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  contactItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  contactName: {
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: '#4285f4',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ReadReceiptPrivacyScreen;