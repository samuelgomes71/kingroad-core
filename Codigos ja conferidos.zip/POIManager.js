/**
 * POIManager.js
 * Gerenciador de Pontos de Interesse (POI) para o sistema KingRoad
 * Implementa buscas, filtros e organização por categorias e regiões
 */

import translationsService from './TranslationsService';

class POIManager {
  constructor() {
    this.categories = {
      // Categorias principais
      fuel: {
        icon: 'fuel_station',
        importance: 100,
        subcategories: ['diesel', 'gasoline', 'electric', 'natural_gas']
      },
      rest: {
        icon: 'rest_area',
        importance: 90,
        subcategories: ['truck_stop', 'hotel', 'parking']
      },
      food: {
        icon: 'restaurant',
        importance: 80,
        subcategories: ['restaurant', 'fast_food', 'coffee']
      },
      service: {
        icon: 'service',
        importance: 70,
        subcategories: ['truck_repair', 'tire_shop', 'car_wash']
      },
      shopping: {
        icon: 'shopping',
        importance: 50,
        subcategories: ['mall', 'supermarket', 'convenience']
      },
      tourist: {
        icon: 'tourist',
        importance: 40,
        subcategories: ['sight', 'museum', 'park']
      },
      emergency: {
        icon: 'emergency',
        importance: 110,
        subcategories: ['hospital', 'police', 'mechanic']
      }
    };
    
    this.regionalSettings = new Map();
    this.currentRegion = 'GLOBAL';
    this.cachedPOIs = new Map();
    this.favoritesPOIs = [];
    this.recentPOIs = [];
    this.maxRecentPOIs = 20;
    
    // Inicialização
    this._initializeRegionalSettings();
  }
  
  /**
   * Inicializa configurações regionais
   * @private
   */
  _initializeRegionalSettings() {
    // Configurações globais (padrão)
    this.regionalSettings.set('GLOBAL', {
      distanceUnit: 'km',
      fuelTypes: ['diesel', 'gasoline', 'electric'],
      priorityCategories: ['fuel', 'rest', 'emergency'],
      showByDefault: ['fuel', 'rest', 'emergency'],
      icons: 'standard'
    });
    
    // Configurações para EUA
    this.regionalSettings.set('US', {
      distanceUnit: 'mi',
      fuelTypes: ['diesel', 'gasoline', 'electric', 'natural_gas'],
      priorityCategories: ['fuel', 'rest', 'food'],
      showByDefault: ['fuel', 'rest', 'food', 'emergency'],
      icons: 'us_style'
    });
    
    // Configurações para Brasil
    this.regionalSettings.set('BR', {
      distanceUnit: 'km',
      fuelTypes: ['diesel', 'gasoline', 'ethanol', 'electric'],
      priorityCategories: ['fuel', 'rest', 'food', 'service'],
      showByDefault: ['fuel', 'rest', 'service', 'emergency'],
      icons: 'br_style'
    });
    
    // Configurações para Europa
    this.regionalSettings.set('EU', {
      distanceUnit: 'km',
      fuelTypes: ['diesel', 'gasoline', 'electric'],
      priorityCategories: ['fuel', 'rest', 'service'],
      showByDefault: ['fuel', 'rest', 'emergency'],
      icons: 'eu_style'
    });
  }
  
  /**
   * Define a região atual e atualiza configurações
   * @param {string} regionCode - Código da região (US, BR, EU, etc)
   */
  setRegion(regionCode) {
    if (!regionCode || !this.regionalSettings.has(regionCode)) {
      console.warn(`Região ${regionCode} não encontrada, usando configurações globais`);
      this.currentRegion = 'GLOBAL';
    } else {
      this.currentRegion = regionCode;
    }
    
    // Limpa cache para forçar nova busca com configurações regionais
    this.cachedPOIs.clear();
    
    return this.getRegionalSettings();
  }
  
  /**
   * Obtém as configurações regionais atuais
   * @returns {Object} Configurações da região atual
   */
  getRegionalSettings() {
    return { ...this.regionalSettings.get(this.currentRegion) };
  }
  
  /**
   * Busca POIs próximos a uma localização
   * @param {Object} position - Posição atual {lat, lng}
   * @param {Object} options - Opções de busca
   * @returns {Promise<Array>} Lista de POIs encontrados
   */
  async searchNearbyPOIs(position, options = {}) {
    // Valores padrão para as opções
    const defaultOptions = {
      radius: 5000,  // 5km de raio
      limit: 50,     // Máximo de 50 resultados
      categories: this.regionalSettings.get(this.currentRegion).showByDefault,
      includeSubcategories: true,
      sortBy: 'distance' // Opções: distance, importance, rating
    };
    
    const searchOptions = { ...defaultOptions, ...options };
    
    // Cria chave para cache
    const cacheKey = this._generateCacheKey(position, searchOptions);
    
    // Verifica se tem em cache
    if (this.cachedPOIs.has(cacheKey)) {
      return this.cachedPOIs.get(cacheKey);
    }
    
    // Busca de POIs (simulação)
    const results = await this._fetchPOIs(position, searchOptions);
    
    // Armazena em cache por 1 hora (exceto se for busca offline)
    if (!options.offlineOnly) {
      this.cachedPOIs.set(cacheKey, results);
      setTimeout(() => {
        this.cachedPOIs.delete(cacheKey);
      }, 60 * 60 * 1000); // 1 hora
    }
    
    return results;
  }
  
  /**
   * Busca POIs específicos por nome ou palavra-chave
   * @param {string} query - Termo de busca
   * @param {Object} position - Posição atual (opcional)
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Array>} Lista de POIs encontrados
   */
  async searchPOIsByKeyword(query, position = null, options = {}) {
    // Opções padrão
    const defaultOptions = {
      radius: position ? 50000 : null, // 50km se tiver posição, sem limite caso contrário
      limit: 20,
      includeSubcategories: true,
      sortBy: position ? 'distance' : 'relevance'
    };
    
    const searchOptions = { ...defaultOptions, ...options, query };
    
    // Cria chave para cache
    const cacheKey = `keyword_${query}_${position ? `${position.lat}_${position.lng}` : 'global'}_${JSON.stringify(searchOptions)}`;
    
    // Verifica se tem em cache
    if (this.cachedPOIs.has(cacheKey)) {
      return this.cachedPOIs.get(cacheKey);
    }
    
    // Busca de POIs por palavra-chave
    const results = await this._fetchPOIsByKeyword(query, position, searchOptions);
    
    // Armazena em cache por 1 hora (exceto se for busca offline)
    if (!options.offlineOnly) {
      this.cachedPOIs.set(cacheKey, results);
      setTimeout(() => {
        this.cachedPOIs.delete(cacheKey);
      }, 60 * 60 * 1000); // 1 hora
    }
    
    return results;
  }
  
  /**
   * Gera chave para armazenamento em cache
   * @private
   * @param {Object} position - Posição
   * @param {Object} options - Opções de busca
   * @returns {string} Chave para cache
   */
  _generateCacheKey(position, options) {
    // Arredonda coordenadas para reduzir variações pequenas
    const roundedLat = Math.round(position.lat * 1000) / 1000;
    const roundedLng = Math.round(position.lng * 1000) / 1000;
    
    return `${roundedLat}_${roundedLng}_${options.radius}_${options.categories.join(',')}_${options.limit}_${options.sortBy}`;
  }
  
  /**
   * Busca POIs no servidor ou localmente
   * @private
   * @param {Object} position - Posição central da busca
   * @param {Object} options - Opções de busca
   * @returns {Promise<Array>} Lista de POIs
   */
  async _fetchPOIs(position, options) {
    // Verifica primeiro se deve buscar offline
    if (options.offlineOnly) {
      return this._fetchOfflinePOIs(position, options);
    }
    
    try {
      // Tenta buscar online
      const response = await fetch(`https://api.kingroad.com/pois/nearby`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          lat: position.lat,
          lng: position.lng,
          radius: options.radius,
          limit: options.limit,
          categories: options.categories,
          subcategories: options.includeSubcategories ? this._getAllSubcategories(options.categories) : [],
          region: this.currentRegion,
          sortBy: options.sortBy
        })
      });
      
      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Processa e formata os POIs
      return this._processPOIs(data.pois, position);
    } catch (error) {
      console.error('Erro ao buscar POIs online, tentando offline:', error);
      // Fallback para busca offline se falhar
      return this._fetchOfflinePOIs(position, options);
    }
  }
  
  /**
   * Busca POIs armazenados offline
   * @private
   * @param {Object} position - Posição central da busca
   * @param {Object} options - Opções de busca
   * @returns {Promise<Array>} Lista de POIs
   */
  async _fetchOfflinePOIs(position, options) {
    // Simulação - em um sistema real, buscaria do IndexedDB ou outro armazenamento local
    return new Promise(resolve => {
      setTimeout(() => {
        // Gera POIs fictícios para demonstração
        const pois = this._generateFakePOIs(position, options);
        resolve(this._processPOIs(pois, position));
      }, 100);
    });
  }
  
  /**
   * Busca POIs por palavra-chave
   * @private
   * @param {string} query - Termo de busca
   * @param {Object} position - Posição atual (opcional)
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Array>} Lista de POIs
   */
  async _fetchPOIsByKeyword(query, position, options) {
    // Verifica primeiro se deve buscar offline
    if (options.offlineOnly) {
      return this._fetchOfflineKeywordPOIs(query, position, options);
    }
    
    try {
      // Tenta buscar online
      const response = await fetch(`https://api.kingroad.com/pois/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query,
          lat: position?.lat,
          lng: position?.lng,
          radius: options.radius,
          limit: options.limit,
          region: this.currentRegion,
          sortBy: options.sortBy
        })
      });
      
      if (!response.ok) {
        throw new Error(`Erro na API de busca: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Processa e formata os POIs
      return this._processPOIs(data.pois, position);
    } catch (error) {
      console.error('Erro ao buscar POIs por palavra-chave, tentando offline:', error);
      // Fallback para busca offline se falhar
      return this._fetchOfflineKeywordPOIs(query, position, options);
    }
  }
  
  /**
   * Busca POIs por palavra-chave em modo offline
   * @private
   * @param {string} query - Termo de busca
   * @param {Object} position - Posição atual (opcional)
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Array>} Lista de POIs
   */
  async _fetchOfflineKeywordPOIs(query, position, options) {
    // Simulação - em um sistema real, buscaria do IndexedDB ou outro armazenamento local
    return new Promise(resolve => {
      setTimeout(() => {
        // Gera POIs fictícios para demonstração com base na palavra-chave
        const lowercaseQuery = query.toLowerCase();
        
        // Lista de palavras-chave comuns para cada categoria para simulação
        const categoryKeywords = {
          fuel: ['posto', 'combustível', 'gasolina', 'diesel', 'gas', 'fuel'],
          rest: ['hotel', 'descanso', 'parada', 'pernoite', 'rest', 'sleep'],
          food: ['comida', 'restaurante', 'lanche', 'café', 'food', 'eat'],
          service: ['oficina', 'mecânico', 'borracharia', 'service', 'repair'],
          emergency: ['hospital', 'pronto-socorro', 'polícia', 'ambulância', 'emergency']
        };
        
        // Identifica categorias que combinam com a palavra-chave
        const matchingCategories = [];
        for (const [category, keywords] of Object.entries(categoryKeywords)) {
          if (keywords.some(keyword => lowercaseQuery.includes(keyword))) {
            matchingCategories.push(category);
          }
        }
        
        // Se nenhuma categoria for identificada, usa todas
        const categoriesToSearch = matchingCategories.length > 0 ? 
          matchingCategories : Object.keys(this.categories);
        
        // Novas opções incluindo as categorias filtradas
        const searchOptions = {
          ...options,
          categories: categoriesToSearch
        };
        
        // Gera POIs fictícios nas categorias identificadas
        const pois = this._generateFakePOIs(position, searchOptions);
        
        // Filtra ainda mais com base no nome
        const filteredPois = pois.filter(poi => 
          poi.name.toLowerCase().includes(lowercaseQuery) || 
          (poi.description && poi.description.toLowerCase().includes(lowercaseQuery))
        );
        
        resolve(this._processPOIs(filteredPois, position));
      }, 200);
    });
  }
  
  /**
   * Gera POIs fictícios para demonstração
   * @private
   * @param {Object} position - Posição central
   * @param {Object} options - Opções de busca
   * @returns {Array} Lista de POIs fictícios
   */
  _generateFakePOIs(position, options) {
    const pois = [];
    const categories = options.categories || Object.keys(this.categories);
    const subcategories = options.includeSubcategories ? 
      this._getAllSubcategories(categories) : [];
    const count = Math.min(options.limit || 50, 50);
    
    // Tipos de POIs específicos por categoria
    const poiTypesByCategory = {
      fuel: [
        { name: 'Posto Shell', brand: 'Shell' },
        { name: 'Posto Petrobras', brand: 'Petrobras' },
        { name: 'Posto Ipiranga', brand: 'Ipiranga' },
        { name: 'Posto BR', brand: 'BR' },
        { name: 'Posto Texaco', brand: 'Texaco' }
      ],
      rest: [
        { name: 'Hotel Rodoviário' },
        { name: 'Área de Descanso' },
        { name: 'Parada Segura' },
        { name: 'Ponto de Pernoite' },
        { name: 'Truck Stop' }
      ],
      food: [
        { name: 'Restaurante Bom Caminho' },
        { name: 'Lanchonete da Estrada' },
        { name: 'Café do Viajante' },
        { name: 'Restaurante Parada Obrigatória' },
        { name: 'Fast Food 24h' }
      ],
      service: [
        { name: 'Oficina Freio Seguro' },
        { name: 'Borracharia 24h' },
        { name: 'Auto Elétrica Estradão' },
        { name: 'Mecânica Diesel Pesado' },
        { name: 'Lava Rápido Estrada Limpa' }
      ],
      emergency: [
        { name: 'Hospital Regional' },
        { name: 'Pronto Socorro' },
        { name: 'Posto Policial Rodoviário' },
        { name: 'Socorro Mecânico 24h' },
        { name: 'Ambulância Rodoviária' }
      ],
      shopping: [
        { name: 'Conveniência 24h' },
        { name: 'Loja de Acessórios' },
        { name: 'Mercado do Caminhoneiro' },
        { name: 'Shopping da Estrada' },
        { name: 'Outlet Rodoviário' }
      ],
      tourist: [
        { name: 'Mirante Vista Panorâmica' },
        { name: 'Parque Natural' },
        { name: 'Museu da Rodovia' },
        { name: 'Centro Histórico' },
        { name: 'Monumento da Estrada' }
      ]
    };
    
    // Gera POIs para cada categoria solicitada
    for (let i = 0; i < count; i++) {
      // Distribui proporcionalmente entre as categorias
      const categoryIndex = i % categories.length;
      const category = categories[categoryIndex];
      
      // Pega um tipo aleatório para esta categoria
      const poiTypes = poiTypesByCategory[category];
      const poiType = poiTypes[Math.floor(Math.random() * poiTypes.length)];
      
      // Seleciona uma subcategoria, se disponível
      const categorySubcategories = this.categories[category].subcategories;
      const subcategory = categorySubcategories[Math.floor(Math.random() * categorySubcategories.length)];
      
      // Gera coordenadas aleatórias dentro do raio
      const radius = options.radius / 1000; // Converte para km
      const randomDistance = Math.random() * radius;
      const randomAngle = Math.random() * Math.PI * 2;
      
      // Conversão aproximada de graus para km (simplificada)
      const latOffset = randomDistance * Math.cos(randomAngle) / 111;
      const lngOffset = randomDistance * Math.sin(randomAngle) / (111 * Math.cos(position.lat * Math.PI / 180));
      
      // Cria o POI
      pois.push({
        id: `poi_${category}_${i}`,
        name: `${poiType.name} ${i + 1}`,
        brand: poiType.brand || null,
        category,
        subcategory,
        position: {
          lat: position.lat + latOffset,
          lng: position.lng + lngOffset
        },
        rating: Math.floor(Math.random() * 5) + 1,
        reviews: Math.floor(Math.random() * 100),
        openNow: Math.random() > 0.3, // 70% de chance de estar aberto
        address: `Rodovia BR-${100 + Math.floor(Math.random() * 400)}, km ${Math.floor(Math.random() * 500)}`,
        phone: `+55 11 ${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`,
        facilities: this._generateFacilities(category),
        lastUpdated: Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000) // Até 30 dias atrás
      });
    }
    
    return pois;
  }
  
  /**
   * Gera facilidades fictícias com base na categoria
   * @private
   * @param {string} category - Categoria do POI
   * @returns {Array} Lista de facilidades
   */
  _generateFacilities(category) {
    const commonFacilities = ['wifi', 'bathroom', 'parking'];
    
    const facilitiesByCategory = {
      fuel: ['diesel', 'gasoline', 'convenience_store', 'air_pump', 'car_wash'],
      rest: ['shower', 'beds', 'security', 'truck_parking', 'restaurant'],
      food: ['takeout', 'delivery', 'outdoor_seating', 'alcohol', 'breakfast'],
      service: ['tires', 'oil_change', 'mechanic', 'truck_service', 'towing'],
      emergency: ['24h', 'ambulance', 'pharmacy', 'emergency_room', 'police'],
      shopping: ['atm', 'credit_cards', 'souvenirs', 'groceries', 'electronics'],
      tourist: ['guided_tours', 'information', 'scenic_view', 'picnic', 'photos']
    };
    
    // Junta facilidades comuns com específicas da categoria
    const availableFacilities = [...commonFacilities, ...(facilitiesByCategory[category] || [])];
    
    // Seleciona um número aleatório de facilidades
    const numFacilities = Math.floor(Math.random() * 5) + 2; // 2-6 facilidades
    const selected = new Set();
    
    while (selected.size < numFacilities && selected.size < availableFacilities.length) {
      const index = Math.floor(Math.random() * availableFacilities.length);
      selected.add(availableFacilities[index]);
    }
    
    return Array.from(selected);
  }
  
  /**
   * Obtém todas as subcategorias para as categorias especificadas
   * @private
   * @param {Array} categories - Lista de categorias
   * @returns {Array} Lista de subcategorias
   */
  _getAllSubcategories(categories) {
    const subcategories = [];
    
    for (const category of categories) {
      if (this.categories[category] && this.categories[category].subcategories) {
        subcategories.push(...this.categories[category].subcategories);
      }
    }
    
    return subcategories;
  }
  
  /**
   * Processa lista de POIs para adicionar dados extras
   * @private
   * @param {Array} pois - Lista de POIs
   * @param {Object} position - Posição de referência
   * @returns {Array} POIs processados
   */
  _processPOIs(pois, position) {
    return pois.map(poi => {
      // Calcula distância se tiver posição de referência
      let distance = null;
      if (position) {
        distance = this._calculateDistance(position, poi.position);
      }
      
      // Verifica se está nos favoritos
      const isFavorite = this.favoritesPOIs.some(fav => fav.id === poi.id);
      
      // Traduz categorias e subcategorias
      const categoryName = translationsService.translate(`poi.categories.${poi.category}`);
      const subcategoryName = poi.subcategory ? 
        translationsService.translate(`poi.subcategories.${poi.subcategory}`) : null;
      
      // Obtém ícone conforme configuração regional
      const iconStyle = this.regionalSettings.get(this.currentRegion).icons;
      const icon = poi.category ? this._getIconPath(poi.category, iconStyle) : null;
      
      // Returna POI com dados adicionais
      return {
        ...poi,
        distance,
        isFavorite,
        categoryName,
        subcategoryName,
        icon,
        importance: this.categories[poi.category]?.importance || 0
      };
    });
  }
  
  /**
   * Calcula distância entre dois pontos (Haversine)
   * @private
   * @param {Object} point1 - Ponto 1 {lat, lng}
   * @param {Object} point2 - Ponto 2 {lat, lng}
   * @returns {number} Distância em metros
   */
  _calculateDistance(point1, point2) {
    const R = 6371e3; // Raio da Terra em metros
    const φ1 = point1.lat * Math.PI / 180;
    const φ2 = point2.lat * Math.PI / 180;
    const Δφ = (point2.lat - point1.lat) * Math.PI / 180;
    const Δλ = (point2.lng - point1.lng) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distância em metros
  }
  
  /**
   * Obtém caminho do ícone para uma categoria
   * @private
   * @param {string} category - Categoria
   * @param {string} style - Estilo do ícone
   * @returns {string} Caminho para o ícone
   */
  _getIconPath(category, style) {
    const iconName = this.categories[category]?.icon || 'default';
    return `assets/icons/${style}/${iconName}.svg`;
  }
  
  /**
   * Adiciona um POI aos favoritos
   * @param {Object} poi - POI a ser adicionado
   * @returns {boolean} Sucesso da operação
   */
  addToFavorites(poi) {
    if (!poi || !poi.id) {
      return false;
    }
    
    // Verifica se já está nos favoritos
    if (this.favoritesPOIs.some(fav => fav.id === poi.id)) {
      return true; // Já está nos favoritos
    }
    
    // Adiciona aos favoritos
    this.favoritesPOIs.push({
      ...poi,
      favoriteAddedAt: Date.now()
    });
    
    // Salva favoritos no armazenamento local
    this._saveFavorites();
    
    return true;
  }
  
  /**
   * Remove um POI dos favoritos
   * @param {string} poiId - ID do POI
   * @returns {boolean} Sucesso da operação
   */
  removeFromFavorites(poiId) {
    const initialLength = this.favoritesPOIs.length;
    this.favoritesPOIs = this.favoritesPOIs.filter(poi => poi.id !== poiId);
    
    // Se o tamanho mudou, algo foi removido
    if (initialLength !== this.favoritesPOIs.length) {
      this._saveFavorites();
      return true;
    }
    
    return false;
  }
  
  /**
   * Salva favoritos no armazenamento local
   * @private
   */
  _saveFavorites() {
    try {
      localStorage.setItem('kingroad_favorites', JSON.stringify(this.favoritesPOIs));
    } catch (error) {
      console.error('Erro ao salvar favoritos:', error);
    }
  }
  
  /**
   * Carrega favoritos do armazenamento local
   */
  loadFavorites() {
    try {
      const storedFavorites = localStorage.getItem('kingroad_favorites');
      if (storedFavorites) {
        this.favoritesPOIs = JSON.parse(storedFavorites);
      }
    } catch (error) {
      console.error('Erro ao carregar favoritos:', error);
    }
  }
  
  /**
   * Obtém lista de POIs favoritos
   * @returns {Array} Lista de favoritos
   */
  getFavorites() {
    return [...this.favoritesPOIs];
  }
  
  /**
   * Adiciona um POI aos recentes
   * @param {Object} poi - POI a ser adicionado
   */
  addToRecent(poi) {
    if (!poi || !poi.id) {
      return false;
    }
    
    // Remove o POI da lista atual se já existir
    this.recentPOIs = this.recentPOIs.filter(p => p.id !== poi.id);
    
    // Adiciona ao início da lista
    this.recentPOIs.unshift({
      ...poi,
      recentViewedAt: Date.now()
    });
    
    // Mantém apenas os últimos N recentes
    if (this.recentPOIs.length > this.maxRecentPOIs) {
      this.recentPOIs = this.recentPOIs.slice(0, this.maxRecentPOIs);
    }
    
    // Salva recentes no armazenamento local
    this._saveRecents();
    
    return true;
  }
  
  /**
   * Salva recentes no armazenamento local
   * @private
   */
  _saveRecents() {
    try {
      localStorage.setItem('kingroad_recent_pois', JSON.stringify(this.recentPOIs));
    } catch (error) {
      console.error('Erro ao salvar POIs recentes:', error);
    }
  }
  
  /**
   * Carrega recentes do armazenamento local
   */
  loadRecents() {
    try {
      const storedRecents = localStorage.getItem('kingroad_recent_pois');
      if (storedRecents) {
        this.recentPOIs = JSON.parse(storedRecents);
      }
    } catch (error) {
      console.error('Erro ao carregar POIs recentes:', error);
    }
  }
  
  /**
   * Obtém lista de POIs recentes
   * @returns {Array} Lista de recentes
   */
  getRecents() {
    return [...this.recentPOIs];
  }
  
  /**
   * Limpa a lista de POIs recentes
   */
  clearRecents() {
    this.recentPOIs = [];
    this._saveRecents();
  }
  
  /**
   * Baixa POIs para uso offline
   * @param {Object} region - Região geográfica {center, radius}
   * @param {Array} categories - Categorias a serem baixadas
   * @returns {Promise<Object>} Resultado da operação
   */
  async downloadOfflinePOIs(region, categories = []) {
    if (!region || !region.center) {
      throw new Error('Região inválida para download');
    }
    
    // Usa todas as categorias se não especificado
    const categoriesToDownload = categories.length > 0 ? 
      categories : Object.keys(this.categories);
    
    try {
      // Em uma implementação real, buscaria os POIs e salvaria no IndexedDB
      // Simulação para demonstração
      return new Promise((resolve) => {
        setTimeout(() => {
          const downloadStats = {
            region: {
              center: region.center,
              radius: region.radius || 50000, // 50km padrão
              description: this._getRegionDescription(region.center)
            },
            categories: categoriesToDownload,
            count: Math.floor(Math.random() * 1000) + 500, // 500-1500 POIs
            sizeKB: Math.floor(Math.random() * 5000) + 1000, // 1-6MB
            timestamp: Date.now()
          };
          
          // Simula salvamento no armazenamento local
          try {
            localStorage.setItem('kingroad_offline_pois_info', JSON.stringify(downloadStats));
          } catch (e) {
            console.warn('Erro ao salvar informações de POIs offline', e);
          }
          
          resolve({
            success: true,
            stats: downloadStats
          });
        }, 2000); // Simula tempo de download
      });
    } catch (error) {
      console.error('Erro ao baixar POIs para uso offline:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Obtém descrição de uma região geográfica
   * @private
   * @param {Object} center - Centro da região {lat, lng}
   * @returns {string} Descrição da região
   */
  _getRegionDescription(center) {
    // Em uma implementação real, faria geocoding reverso
    // Simulação para demonstração
    const regionDescriptions = [
      'São Paulo e arredores',
      'Rio de Janeiro - Área metropolitana',
      'Belo Horizonte e região',
      'Brasília - DF',
      'Porto Alegre e Grande Porto Alegre',
      'Recife e litoral',
      'Curitiba e arredores',
      'Salvador e Região Metropolitana',
      'Fortaleza e arredores',
      'Região de Campinas'
    ];
    
    // Usa as coordenadas para selecionar uma descrição
    const seed = Math.abs(Math.round((center.lat * 100 + center.lng * 100)));
    const index = seed % regionDescriptions.length;
    
    return regionDescriptions[index];
  }
  
  /**
   * Obtém informações sobre POIs offline salvos
   * @returns {Object|null} Informações ou null se não houver dados
   */
  getOfflinePOIsInfo() {
    try {
      const info = localStorage.getItem('kingroad_offline_pois_info');
      return info ? JSON.parse(info) : null;
    } catch (error) {
      console.error('Erro ao ler informações de POIs offline:', error);
      return null;
    }
  }
  
  /**
   * Remove POIs offline
   * @returns {boolean} Sucesso da operação
   */
  removeOfflinePOIs() {
    try {
      // Em uma implementação real, limparia o IndexedDB
      // Simulação para demonstração
      localStorage.removeItem('kingroad_offline_pois_info');
      return true;
    } catch (error) {
      console.error('Erro ao remover POIs offline:', error);
      return false;
    }
  }
  
  /**
   * Obtém POIs ao longo de uma rota
   * @param {Array} routePoints - Pontos da rota
   * @param {Array} categories - Categorias desejadas
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Array>} Lista de POIs
   */
  async getPOIsAlongRoute(routePoints, categories = [], options = {}) {
    if (!routePoints || routePoints.length < 2) {
      throw new Error('Rota inválida');
    }
    
    // Opções padrão
    const defaultOptions = {
      maxDistance: 2000, // 2km de distância máxima da rota
      limit: 50,        // Máximo de 50 POIs
      priorityCategories: this.regionalSettings.get(this.currentRegion).priorityCategories,
      sortBy: 'route_order' // Ordena por ordem na rota
    };
    
    const searchOptions = { ...defaultOptions, ...options };
    
    // Usa categorias prioritárias se não especificado
    const categoriesToSearch = categories.length > 0 ? 
      categories : searchOptions.priorityCategories;
    
    try {
      // Em uma implementação real, faria uma chamada à API
      // Simulação para demonstração
      return new Promise((resolve) => {
        setTimeout(() => {
          // Gera POIs fictícios ao longo da rota
          const pois = this._generatePOIsAlongRoute(
            routePoints, 
            categoriesToSearch,
            searchOptions.maxDistance,
            searchOptions.limit
          );
          
          // Processa os POIs
          const processedPois = this._processRoutePOIs(pois, routePoints, searchOptions.sortBy);
          
          resolve(processedPois);
        }, 500);
      });
    } catch (error) {
      console.error('Erro ao buscar POIs ao longo da rota:', error);
      return [];
    }
  }
  
  /**
   * Gera POIs fictícios ao longo de uma rota
   * @private
   * @param {Array} routePoints - Pontos da rota
   * @param {Array} categories - Categorias
   * @param {number} maxDistance - Distância máxima da rota
   * @param {number} limit - Limite de POIs
   * @returns {Array} POIs gerados
   */
  _generatePOIsAlongRoute(routePoints, categories, maxDistance, limit) {
    const pois = [];
    const count = Math.min(limit, 50);
    
    // Divide a rota em segmentos para distribuir os POIs
    const segments = routePoints.length - 1;
    const poisPerSegment = Math.ceil(count / segments);
    
    // Para cada segmento da rota
    for (let i = 0; i < segments; i++) {
      const startPoint = routePoints[i];
      const endPoint = routePoints[i + 1];
      
      // Gera POIs para este segmento
      for (let j = 0; j < poisPerSegment && pois.length < count; j++) {
        // Posição aleatória entre os pontos do segmento
        const progress = Math.random();
        const position = {
          lat: startPoint.lat + (endPoint.lat - startPoint.lat) * progress,
          lng: startPoint.lng + (endPoint.lng - startPoint.lng) * progress
        };
        
        // Distância aleatória da rota (até o máximo especificado)
        const distanceFromRoute = Math.random() * maxDistance;
        const angle = Math.random() * Math.PI * 2;
        
        // Conversão aproximada de graus para metros
        const latOffset = (distanceFromRoute / 111000) * Math.cos(angle);
        const lngOffset = (distanceFromRoute / (111000 * Math.cos(position.lat * Math.PI / 180))) * Math.sin(angle);
        
        // Posição final com offset
        const finalPosition = {
          lat: position.lat + latOffset,
          lng: position.lng + lngOffset
        };
        
        // Seleciona uma categoria aleatória
        const category = categories[Math.floor(Math.random() * categories.length)];
        
        // Cria o POI
        const poiTemplate = this._generateFakePOIs(finalPosition, { 
          categories: [category], 
          limit: 1 
        })[0];
        
        if (poiTemplate) {
          // Adiciona informações específicas da rota
          pois.push({
            ...poiTemplate,
            routeSegment: i,
            routeProgress: progress,
            distanceFromRoute: distanceFromRoute
          });
        }
      }
    }
    
    return pois;
  }
  
  /**
   * Processa POIs de rota adicionando dados específicos
   * @private
   * @param {Array} pois - Lista de POIs
   * @param {Array} routePoints - Pontos da rota
   * @param {string} sortBy - Critério de ordenação
   * @returns {Array} POIs processados
   */
  _processRoutePOIs(pois, routePoints, sortBy) {
    // Processa os POIs básicos primeiro
    const processed = this._processPOIs(pois, routePoints[0]);
    
    // Adiciona informações específicas da rota
    const withRouteInfo = processed.map(poi => {
      // Calcula distância até o final da rota
      let distanceToEnd = 0;
      
      // Soma as distâncias dos segmentos após o POI
      const segment = poi.routeSegment;
      for (let i = segment; i < routePoints.length - 1; i++) {
        distanceToEnd += this._calculateDistance(routePoints[i], routePoints[i + 1]);
      }
      
      // Estima tempo até o POI na rota (60 km/h em média)
      const distanceFromStart = this._calculateRouteDistanceTo(routePoints, segment, poi.routeProgress);
      const timeToReachMinutes = Math.round((distanceFromStart / 1000) / 60);
      
      return {
        ...poi,
        distanceToEnd,
        distanceFromStart,
        timeToReachMinutes,
        // Calculado para exibição na UI
        displayInfo: {
          distance: this._formatDistance(poi.distanceFromRoute),
          timeToReach: this._formatTime(timeToReachMinutes)
        }
      };
    });
    
    // Ordena conforme solicitado
    let sorted = [...withRouteInfo];
    
    switch (sortBy) {
      case 'route_order':
        sorted.sort((a, b) => a.routeSegment - b.routeSegment || a.routeProgress - b.routeProgress);
        break;
      case 'distance_from_route':
        sorted.sort((a, b) => a.distanceFromRoute - b.distanceFromRoute);
        break;
      case 'importance':
        sorted.sort((a, b) => b.importance - a.importance);
        break;
      case 'rating':
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      default:
        // Mantém ordem original
        break;
    }
    
    return sorted;
  }
  
  /**
   * Calcula a distância percorrida na rota até um ponto específico
   * @private
   * @param {Array} routePoints - Pontos da rota
   * @param {number} segment - Índice do segmento
   * @param {number} progress - Progresso no segmento (0-1)
   * @returns {number} Distância em metros
   */
  _calculateRouteDistanceTo(routePoints, segment, progress) {
    let distance = 0;
    
    // Soma distâncias dos segmentos completos
    for (let i = 0; i < segment; i++) {
      distance += this._calculateDistance(routePoints[i], routePoints[i + 1]);
    }
    
    // Adiciona distância parcial do último segmento
    if (segment < routePoints.length - 1) {
      const segmentDistance = this._calculateDistance(routePoints[segment], routePoints[segment + 1]);
      distance += segmentDistance * progress;
    }
    
    return distance;
  }
  
  /**
   * Formata distância conforme unidade regional
   * @private
   * @param {number} meters - Distância em metros
   * @returns {string} Distância formatada
   */
  _formatDistance(meters) {
    const unit = this.regionalSettings.get(this.currentRegion).distanceUnit;
    
    if (unit === 'mi') {
      // Converte para milhas
      const miles = meters / 1609.34;
      
      if (miles < 0.1) {
        return `${Math.round(miles * 5280)} pés`;
      } else if (miles < 10) {
        return `${miles.toFixed(1)} mi`;
      } else {
        return `${Math.round(miles)} mi`;
      }
    } else {
      // Usa quilômetros
      if (meters < 1000) {
        return `${Math.round(meters)} m`;
      } else {
        const km = meters / 1000;
        if (km < 10) {
          return `${km.toFixed(1)} km`;
        } else {
          return `${Math.round(km)} km`;
        }
      }
    }
  }
  
  /**
   * Formata tempo em minutos
   * @private
   * @param {number} minutes - Tempo em minutos
   * @returns {string} Tempo formatado
   */
  _formatTime(minutes) {
    if (minutes < 1) {
      return translationsService.translate('poi.time.lessThanOneMinute');
    } else if (minutes < 60) {
      return translationsService.translate('poi.time.minutes', { minutes });
    } else {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      
      if (remainingMinutes === 0) {
        return translationsService.translate('poi.time.hours', { hours });
      } else {
        return translationsService.translate('poi.time.hoursAndMinutes', { 
          hours, 
          minutes: remainingMinutes 
        });
      }
    }
  }
  
  /**
   * Obtém informações detalhadas de um POI
   * @param {string} poiId - ID do POI
   * @param {Object} options - Opções adicionais
   * @returns {Promise<Object>} Detalhes do POI
   */
  async getPOIDetails(poiId, options = {}) {
    if (!poiId) {
      throw new Error('ID do POI é obrigatório');
    }
    
    try {
      // Em uma implementação real, buscaria da API
      // Simulação para demonstração
      return new Promise((resolve) => {
        setTimeout(() => {
          // Busca favoritos e recentes primeiro
          const fromFavorites = this.favoritesPOIs.find(p => p.id === poiId);
          const fromRecents = this.recentPOIs.find(p => p.id === poiId);
          
          // Base para o POI
          let poi = fromFavorites || fromRecents;
          
          if (!poi) {
            // Gera um POI fictício se não encontrar
            poi = this._generateFakePOIs({ lat: 0, lng: 0 }, { limit: 1 })[0];
            poi.id = poiId;
          }
          
          // Adiciona detalhes extras
          const details = {
            ...poi,
            website: poi.website || `https://www.exemplo.com/${poiId}`,
            email: poi.email || `contato@${poiId.replace(/[^a-z0-9]/gi, '')}.com`,
            hours: this._generateBusinessHours(),
            photos: this._generatePhotos(poi.category),
            reviews: this._generateReviews(poi.rating || 3, poi.reviews || 5),
            amenities: this._generateAmenities(poi.category),
            fuelPrices: poi.category === 'fuel' ? this._generateFuelPrices() : null,
            lastUpdated: Date.now() - Math.floor(Math.random() * 7 * 24 * 60 * 60 * 1000) // Até 7 dias atrás
          };
          
          // Adiciona aos recentes
          this.addToRecent(details);
          
          resolve(details);
        }, 300);
      });
    } catch (error) {
      console.error('Erro ao buscar detalhes do POI:', error);
      throw error;
    }
  }
  
  /**
   * Gera horários de funcionamento fictícios
   * @private
   * @returns {Object} Horários de funcionamento
   */
  _generateBusinessHours() {
    const is24h = Math.random() > 0.7; // 30% de chance de ser 24h
    
    if (is24h) {
      return {
        is24h: true,
        days: {
          monday: { open: '00:00', close: '00:00' },
          tuesday: { open: '00:00', close: '00:00' },
          wednesday: { open: '00:00', close: '00:00' },
          thursday: { open: '00:00', close: '00:00' },
          friday: { open: '00:00', close: '00:00' },
          saturday: { open: '00:00', close: '00:00' },
          sunday: { open: '00:00', close: '00:00' }
        }
      };
    }
    
    // Horários para dias da semana (seg-sex)
    const weekdayOpen = `0${6 + Math.floor(Math.random() * 4)}:00`; // 06:00-09:00
    const weekdayClose = `${18 + Math.floor(Math.random() * 4)}:00`; // 18:00-21:00
    
    // Horários para fim de semana (diferente para 30% dos lugares)
    const weekendDifferent = Math.random() > 0.7;
    const weekendOpen = weekendDifferent ? 
      `0${7 + Math.floor(Math.random() * 4)}:00` : weekdayOpen; // 07:00-10:00
    const weekendClose = weekendDifferent ? 
      `${16 + Math.floor(Math.random() * 4)}:00` : weekdayClose; // 16:00-19:00
    
    // Fechado aos domingos para 20% dos lugares
    const sundayClosed = Math.random() > 0.8;
    
    return {
      is24h: false,
      days: {
        monday: { open: weekdayOpen, close: weekdayClose },
        tuesday: { open: weekdayOpen, close: weekdayClose },
        wednesday: { open: weekdayOpen, close: weekdayClose },
        thursday: { open: weekdayOpen, close: weekdayClose },
        friday: { open: weekdayOpen, close: weekdayClose },
        saturday: { open: weekendOpen, close: weekendClose },
        sunday: sundayClosed ? 
          { closed: true } : 
          { open: weekendOpen, close: weekendClose }
      }
    };
  }
  
  /**
   * Gera fotos fictícias
   * @private
   * @param {string} category - Categoria do POI
   * @returns {Array} Lista de fotos
   */
  _generatePhotos(category) {
    const count = Math.floor(Math.random() * 5) + 2; // 2-6 fotos
    const photos = [];
    
    for (let i = 0; i < count; i++) {
      photos.push({
        id: `photo_${category}_${i}`,
        url: `/assets/images/pois/${category}/sample_${i + 1}.jpg`,
        thumbnail: `/assets/images/pois/${category}/thumb_${i + 1}.jpg`,
        width: 800 + Math.floor(Math.random() * 400), // 800-1200px
        height: 600 + Math.floor(Math.random() * 400), // 600-1000px
        description: null
      });
    }
    
    return photos;
  }
  
  /**
   * Gera avaliações fictícias
   * @private
   * @param {number} avgRating - Avaliação média
   * @param {number} count - Número de avaliações
   * @returns {Array} Lista de avaliações
   */
  _generateReviews(avgRating, count) {
    const reviewTexts = [
      "Ótimo lugar para parar durante a viagem. Recomendo!",
      "Atendimento bom, preços razoáveis.",
      "Lugar limpo e organizado. Vale a pena a parada.",
      "Bom para uma pausa rápida, mas nada excepcional.",
      "Equipe atenciosa. Voltarei quando passar por aqui.",
      "Preços um pouco altos, mas a qualidade compensa.",
      "Instalações bem mantidas. Recomendo para outros caminhoneiros.",
      "Parada obrigatória nesta estrada. Não decepcionou.",
      "Tem tudo o que é necessário para uma boa parada.",
      "Faltam algumas opções, mas atende bem no geral."
    ];
    
    const reviews = [];
    const realCount = Math.min(count, 10); // Limita a 10 para a demo
    
    // Nomes de autores
    const firstNames = ["João", "Maria", "Carlos", "Ana", "Pedro", "Lúcia", "Roberto", "Fernanda", "José", "Camila"];
    const lastNames = ["Silva", "Santos", "Oliveira", "Souza", "Lima", "Pereira", "Costa", "Rodrigues", "Almeida", "Ferreira"];
    
    for (let i = 0; i < realCount; i++) {
      // Desvio da avaliação média
      let deviation = (Math.random() * 2 - 1); // -1 a +1
      if (Math.abs(deviation) > 0.5) {
        deviation = deviation * 2; // Aumenta variação para alguns reviews
      }
      
      // Rating final com limitação
      let rating = avgRating + deviation;
      rating = Math.max(1, Math.min(5, Math.round(rating)));
      
      // Gera autor
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const author = `${firstName} ${lastName.charAt(0)}.`;
      
      // Seleciona texto de review
      const textIndex = Math.floor(Math.random() * reviewTexts.length);
      
      // Data do review
      const daysAgo = Math.floor(Math.random() * 365); // Até 1 ano atrás
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      
      reviews.push({
        id: `review_${i}`,
        author,
        rating,
        text: reviewTexts[textIndex],
        date: date.toISOString(),
        daysAgo
      });
    }
    
    return reviews;
  }
  
  /**
   * Gera amenidades fictícias
   * @private
   * @param {string} category - Categoria do POI
   * @returns {Array} Lista de amenidades
   */
  _generateAmenities(category) {
    // Usa mesma função do _generateFacilities, mas adiciona mais informações
    const facilities = this._generateFacilities(category);
    
    // Mapeia para o formato de amenidades
    return facilities.map(facility => {
      return {
        id: facility,
        name: translationsService.translate(`poi.amenities.${facility}`),
        icon: `/assets/icons/amenities/${facility}.svg`,
        available: true
      };
    });
  }
  
  /**
   * Gera preços de combustível fictícios
   * @private
   * @returns {Object} Preços de combustível
   */
  _generateFuelPrices() {
    const fuelTypes = {
      diesel: {
        common: 4.5 + (Math.random() * 1.5),
        s10: 4.7 + (Math.random() * 1.5),
        adblue: 3.0 + (Math.random() * 1.0)
      },
      gasoline: {
        common: 5.5 + (Math.random() * 1.5),
        premium: 6.0 + (Math.random() * 1.5)
      },
      ethanol: 4.0 + (Math.random() * 1.0),
      natural_gas: 3.5 + (Math.random() * 0.5)
    };
    
    // Data da última atualização
    const daysAgo = Math.floor(Math.random() * 7); // Até 7 dias atrás
    const lastUpdate = new Date();
    lastUpdate.setDate(lastUpdate.getDate() - daysAgo);
    
    return {
      prices: fuelTypes,
      lastUpdate: lastUpdate.toISOString(),
      reportedBy: "KingRoad"
    };
  }
}

// Exporta o gerenciador como um singleton
const poiManager = new POIManager();
export default poiManager;