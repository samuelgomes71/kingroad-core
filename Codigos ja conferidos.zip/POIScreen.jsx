/**
 * POIScreen.jsx
 * 
 * Componente React Native para a tela de Pontos de Interesse (POIs) do sistema KingRoad.
 * Implementa visualização, busca e interação com POIs conforme mencionado no relatório.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  TextInput,
  StatusBar,
  ActivityIndicator,
  Animated,
  Platform,
  Dimensions,
  SafeAreaView,
  Alert,
  ScrollView
} from 'react-native';

// Serviços do sistema KingRoad
import { POIService } from '../services/POIService';
import { NavigationService } from '../services/NavigationService';
import { TranslationsService } from '../services/TranslationsService';
import { RegionalVisualsService } from '../services/RegionalVisualsService';
import { OfflineCacheManager } from '../services/OfflineCacheManager';

// Componentes do sistema KingRoad
import POIMap from '../components/POIMap';
import POICard from '../components/POICard';
import CategorySelector from '../components/CategorySelector';
import FilterControls from '../components/FilterControls';
import LoadingOverlay from '../components/LoadingOverlay';
import NoResultsView from '../components/NoResultsView';
import ConnectionBanner from '../components/ConnectionBanner';

// Ícones e assets
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width, height } = Dimensions.get('window');

const POIScreen = ({ route, navigation }) => {
  // Parâmetros de navegação
  const initialCategory = route.params?.category || 'all';
  const initialSearchQuery = route.params?.searchQuery || '';
  const initialLocation = route.params?.location || null;
  const highlightedPOI = route.params?.highlightedPOI || null;
  
  // Serviços
  const poiService = useRef(POIService.getInstance());
  const navigationService = useRef(NavigationService.getInstance());
  const translationsService = useRef(TranslationsService.getInstance());
  const visualsService = useRef(RegionalVisualsService.getInstance());
  const offlineCacheManager = useRef(OfflineCacheManager.getInstance());
  
  // Estados do componente
  const [pois, setPois] = useState([]);
  const [filteredPois, setFilteredPois] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [currentLocation, setCurrentLocation] = useState(initialLocation);
  const [viewMode, setViewMode] = useState('list'); // 'list' ou 'map'
  const [selectedPOI, setSelectedPOI] = useState(highlightedPOI);
  const [favoritePOIs, setFavoritePOIs] = useState([]);
  const [recentPOIs, setRecentPOIs] = useState([]);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [sortingOption, setSortingOption] = useState('distance'); // 'distance', 'rating', 'name'
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [activeFilters, setActiveFilters] = useState({
    openNow: false,
    hasParking: false,
    favorites: false,
    minimumRating: 0,
    maxDistance: 50, // km
    amenities: []
  });
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isNightMode, setIsNightMode] = useState(false);
  const [availableCategories, setAvailableCategories] = useState([]);
  const [isTruckMode, setIsTruckMode] = useState(true);
  
  // Refs
  const searchInputRef = useRef(null);
  const mapRef = useRef(null);
  const listRef = useRef(null);
  const filtersAnimation = useRef(new Animated.Value(0)).current;
  
  // Safe area insets
  const insets = useSafeAreaInsets();
  
  // Efeito para inicialização
  useEffect(() => {
    initializeScreen();
    
    // Cleanup
    return () => {
      // Limpar qualquer recurso se necessário
    };
  }, []);
  
  // Efeito para reagir a mudanças de categoria
  useEffect(() => {
    if (selectedCategory && !loading) {
      loadPOIsByCategory(selectedCategory);
    }
  }, [selectedCategory]);
  
  // Efeito para reagir a mudanças de localização
  useEffect(() => {
    if (currentLocation && !loading) {
      loadPOIsByCurrentLocation();
    }
  }, [currentLocation]);
  
  // Efeito para aplicar filtros e ordenação
  useEffect(() => {
    applyFiltersAndSorting();
  }, [pois, activeFilters, sortingOption, currentLocation]);
  
  // Efeito para verificar tema atual
  useEffect(() => {
    const currentTheme = visualsService.current.getCurrentTheme();
    setIsNightMode(currentTheme.isDark);
  }, []);
  
  // Efeito para verificar modo online/offline
  useEffect(() => {
    const checkConnectionStatus = async () => {
      const status = await offlineCacheManager.current.checkConnectionStatus();
      setIsOfflineMode(!status.online);
    };
    
    checkConnectionStatus();
    
    // Adicionar listener para mudanças de conexão
    const connectionListener = (event, data) => {
      if (event === 'connectionChange') {
        setIsOfflineMode(!data.to.online);
      }
    };
    
    offlineCacheManager.current.addObserver(connectionListener);
    
    return () => {
      offlineCacheManager.current.removeObserver(connectionListener);
    };
  }, []);
  
  /**
   * Inicializa a tela
   */
  const initializeScreen = async () => {
    setLoading(true);
    
    try {
      // Obter localização atual se não fornecida
      let location = currentLocation;
      if (!location) {
        location = await navigationService.current.getCurrentLocation();
        setCurrentLocation(location);
      }
      
      // Carregar categorias disponíveis
      const categories = await poiService.current.getAvailableCategories();
      setAvailableCategories(categories);
      
      // Carregar POIs favoritos
      const favorites = await poiService.current.getFavoritePOIs();
      setFavoritePOIs(favorites.map(poi => poi.id));
      
      // Carregar POIs recentes
      const recents = await poiService.current.getRecentPOIs();
      setRecentPOIs(recents);
      
      // Verificar se está em modo caminhão
      const vehicleMode = await localStorage.getItem('kingroad_vehicle_mode');
      setIsTruckMode(vehicleMode !== 'car');
      
      // Carregar POIs iniciais
      if (highlightedPOI) {
        // Se um POI específico foi destacado, mostrar detalhes
        setSelectedPOI(highlightedPOI);
        await loadPOIsByCategory(highlightedPOI.category || 'all');
      } else if (initialSearchQuery) {
        // Se uma busca inicial foi fornecida, realizar busca
        await searchPOIs(initialSearchQuery);
      } else {
        // Caso contrário, carregar por categoria
        await loadPOIsByCategory(selectedCategory);
      }
    } catch (error) {
      console.error('Erro ao inicializar POIScreen:', error);
      Alert.alert(
        'Erro',
        'Não foi possível carregar os pontos de interesse. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Carrega POIs por categoria
   */
  const loadPOIsByCategory = async (category) => {
    setLoading(true);
    
    try {
      let results;
      if (isOfflineMode) {
        // Buscar do cache offline
        results = await loadPOIsOffline(category);
      } else {
        // Buscar do servidor
        results = await poiService.current.findPOIsByCategory(
          currentLocation,
          category,
          activeFilters.maxDistance,
          isTruckMode
        );
      }
      
      setPois(results);
      
      // Se um POI foi destacado, selecioná-lo na lista
      if (highlightedPOI) {
        const found = results.find(poi => poi.id === highlightedPOI.id);
        if (found) {
          setSelectedPOI(found);
        }
      }
    } catch (error) {
      console.error('Erro ao carregar POIs por categoria:', error);
      if (!isOfflineMode) {
        // Tentar carregar do cache como fallback
        try {
          const cachedResults = await loadPOIsOffline(category);
          setPois(cachedResults);
          setIsOfflineMode(true);
        } catch (cacheError) {
          console.error('Erro ao carregar POIs do cache:', cacheError);
          setPois([]);
        }
      } else {
        setPois([]);
      }
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Carrega POIs do cache offline
   */
  const loadPOIsOffline = async (category) => {
    const area = {
      latitude: currentLocation.latitude,
      longitude: currentLocation.longitude,
      radius: activeFilters.maxDistance
    };
    
    const categories = category === 'all' ? null : [category];
    
    return await offlineCacheManager.current.getCachedPOIsInArea(area, categories);
  };
  
  /**
   * Carrega POIs com base na localização atual
   */
  const loadPOIsByCurrentLocation = async () => {
    if (selectedCategory) {
      await loadPOIsByCategory(selectedCategory);
    }
  };
  
  /**
   * Busca POIs por termo de busca
   */
  const searchPOIs = async (query = searchQuery) => {
    if (!query || query.trim().length === 0) {
      // Se a busca estiver vazia, voltar para a exibição por categoria
      return loadPOIsByCategory(selectedCategory);
    }
    
    setLoading(true);
    setSearchQuery(query);
    
    try {
      let results;
      if (isOfflineMode) {
        // Buscar no cache offline (implementação simplificada)
        const allPOIs = await loadPOIsOffline('all');
        results = allPOIs.filter(poi => {
          const normalizedQuery = query.toLowerCase();
          const normalizedName = (poi.name || '').toLowerCase();
          const normalizedDescription = (poi.description || '').toLowerCase();
          
          return normalizedName.includes(normalizedQuery) || 
                 normalizedDescription.includes(normalizedQuery);
        });
      } else {
        // Buscar no servidor
        results = await poiService.current.searchPOIs(
          query,
          currentLocation,
          activeFilters.maxDistance,
          isTruckMode
        );
      }
      
      setPois(results);
    } catch (error) {
      console.error('Erro ao buscar POIs:', error);
      setPois([]);
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Aplica filtros e ordenação aos POIs
   */
  const applyFiltersAndSorting = () => {
    let filtered = [...pois];
    
    // Aplicar filtros
    if (activeFilters.openNow) {
      const now = new Date();
      filtered = filtered.filter(poi => isOpenNow(poi, now));
    }
    
    if (activeFilters.hasParking) {
      filtered = filtered.filter(poi => poi.hasParking || poi.truckParking);
    }
    
    if (activeFilters.favorites) {
      filtered = filtered.filter(poi => favoritePOIs.includes(poi.id));
    }
    
    if (activeFilters.minimumRating > 0) {
      filtered = filtered.filter(poi => (poi.rating || 0) >= activeFilters.minimumRating);
    }
    
    if (activeFilters.amenities && activeFilters.amenities.length > 0) {
      filtered = filtered.filter(poi => {
        if (!poi.amenities) return false;
        
        return activeFilters.amenities.every(amenity => 
          poi.amenities.includes(amenity)
        );
      });
    }
    
    // Aplicar ordenação
    switch (sortingOption) {
      case 'distance':
        filtered.sort((a, b) => {
          const distA = calculateDistance(currentLocation, a);
          const distB = calculateDistance(currentLocation, b);
          return distA - distB;
        });
        break;
        
      case 'rating':
        filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
        
      case 'name':
        filtered.sort((a, b) => {
          const nameA = (a.name || '').toUpperCase();
          const nameB = (b.name || '').toUpperCase();
          return nameA.localeCompare(nameB);
        });
        break;
    }
    
    setFilteredPois(filtered);
  };
  
  /**
   * Verifica se um POI está aberto no momento atual
   */
  const isOpenNow = (poi, now) => {
    if (!poi.openingHours) return false;
    
    const day = now.getDay(); // 0-6, onde 0 é domingo
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const currentTime = hours * 60 + minutes; // Minutos desde a meia-noite
    
    const todayHours = poi.openingHours[day];
    if (!todayHours || todayHours === 'closed') return false;
    
    if (todayHours === '24h') return true;
    
    // Formato esperado: "08:00-22:00" ou "08:00-12:00,14:00-22:00"
    const timeRanges = todayHours.split(',');
    
    for (const range of timeRanges) {
      const [start, end] = range.split('-');
      
      if (!start || !end) continue;
      
      const [startHours, startMinutes] = start.split(':').map(Number);
      const [endHours, endMinutes] = end.split(':').map(Number);
      
      const startTime = startHours * 60 + startMinutes;
      const endTime = endHours * 60 + endMinutes;
      
      if (currentTime >= startTime && currentTime <= endTime) {
        return true;
      }
    }
    
    return false;
  };
  
  /**
   * Calcula a distância entre a localização atual e um POI
   */
  const calculateDistance = (location, poi) => {
    if (!location || !poi.latitude || !poi.longitude) return Infinity;
    
    // Haversine formula
    const R = 6371; // Raio da Terra em km
    const dLat = toRad(poi.latitude - location.latitude);
    const dLon = toRad(poi.longitude - location.longitude);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(toRad(location.latitude)) * Math.cos(toRad(poi.latitude)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c;
  };
  
  /**
   * Converte graus para radianos
   */
  const toRad = (value) => {
    return value * Math.PI / 180;
  };
  
  /**
   * Formata a distância para exibição
   */
  const formatDistance = (distance) => {
    if (distance === Infinity || distance === undefined) return '';
    
    if (distance < 1) {
      // Menos de 1km, mostrar em metros
      return `${Math.round(distance * 1000)}m`;
    } else {
      // 1km ou mais, mostrar em km com 1 casa decimal
      return `${distance.toFixed(1)}km`;
    }
  };
  
  /**
   * Manipula a seleção de um POI
   */
  const handleSelectPOI = (poi) => {
    setSelectedPOI(poi);
    
    // Centralizar no mapa se estiver no modo mapa
    if (viewMode === 'map' && mapRef.current) {
      mapRef.current.animateToLocation({
        latitude: poi.latitude,
        longitude: poi.longitude
      });
    }
    
    // Adicionar aos POIs recentes
    addToRecentPOIs(poi);
  };
  
  /**
   * Adiciona um POI à lista de recentes
   */
  const addToRecentPOIs = async (poi) => {
    try {
      await poiService.current.addToRecentPOIs(poi);
      
      // Atualizar lista de recentes no estado
      const recents = await poiService.current.getRecentPOIs();
      setRecentPOIs(recents);
    } catch (error) {
      console.error('Erro ao adicionar POI aos recentes:', error);
    }
  };
  
  /**
   * Manipula favoritar/desfavoritar um POI
   */
  const handleToggleFavorite = async (poi) => {
    try {
      const isFavorite = favoritePOIs.includes(poi.id);
      
      if (isFavorite) {
        // Remover dos favoritos
        await poiService.current.removeFromFavorites(poi.id);
        setFavoritePOIs(prevFavorites => 
          prevFavorites.filter(id => id !== poi.id)
        );
      } else {
        // Adicionar aos favoritos
        await poiService.current.addToFavorites(poi);
        setFavoritePOIs(prevFavorites => [...prevFavorites, poi.id]);
      }
      
      // Reaplicar filtros, caso o filtro de favoritos esteja ativo
      if (activeFilters.favorites) {
        applyFiltersAndSorting();
      }
    } catch (error) {
      console.error('Erro ao alterar status de favorito:', error);
    }
  };
  
  /**
   * Manipula a navegação para um POI
   */
  const handleNavigateToPOI = (poi) => {
    navigation.navigate('Navigation', {
      destination: {
        latitude: poi.latitude,
        longitude: poi.longitude,
        name: poi.name
      }
    });
  };
  
  /**
   * Manipula a visualização de detalhes de um POI
   */
  const handleViewPOIDetails = (poi) => {
    navigation.navigate('POIDetails', { poi });
  };
  
  /**
   * Manipula a alteração do modo de visualização
   */
  const toggleViewMode = () => {
    const newMode = viewMode === 'list' ? 'map' : 'list';
    setViewMode(newMode);
    
    // Se mudar para o modo de mapa e houver um POI selecionado, centralizar nele
    if (newMode === 'map' && selectedPOI && mapRef.current) {
      setTimeout(() => {
        mapRef.current.animateToLocation({
          latitude: selectedPOI.latitude,
          longitude: selectedPOI.longitude
        });
      }, 300);
    }
  };
  
  /**
   * Manipula o refresh da lista
   */
  const handleRefresh = async () => {
    setRefreshing(true);
    
    try {
      // Recarregar localização atual
      const location = await navigationService.current.getCurrentLocation();
      setCurrentLocation(location);
      
      // Recarregar POIs
      if (searchQuery) {
        await searchPOIs(searchQuery);
      } else {
        await loadPOIsByCategory(selectedCategory);
      }
    } catch (error) {
      console.error('Erro ao atualizar dados:', error);
    } finally {
      setRefreshing(false);
    }
  };
  
  /**
   * Manipula a alteração da categoria selecionada
   */
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setSearchQuery(''); // Limpar busca ao mudar de categoria
    
    if (searchInputRef.current) {
      searchInputRef.current.clear();
    }
  };
  
  /**
   * Manipula a submissão da busca
   */
  const handleSearch = () => {
    searchPOIs(searchQuery);
    setIsSearchFocused(false);
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      Keyboard.dismiss();
    }
  };
  
  /**
   * Manipula a limpeza da busca
   */
  const handleClearSearch = () => {
    setSearchQuery('');
    
    if (searchInputRef.current) {
      searchInputRef.current.clear();
    }
    
    loadPOIsByCategory(selectedCategory);
  };
  
  /**
   * Abre o painel de filtros
   */
  const openFilters = () => {
    setFiltersVisible(true);
    
    Animated.timing(filtersAnimation, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true
    }).start();
  };
  
  /**
   * Fecha o painel de filtros
   */
  const closeFilters = () => {
    Animated.timing(filtersAnimation, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true
    }).start(() => {
      setFiltersVisible(false);
    });
  };
  
  /**
   * Aplica os filtros selecionados
   */
  const applyFilters = (filters) => {
    setActiveFilters(filters);
    closeFilters();
  };
  
  /**
   * Limpa todos os filtros
   */
  const clearFilters = () => {
    setActiveFilters({
      openNow: false,
      hasParking: false,
      favorites: false,
      minimumRating: 0,
      maxDistance: 50,
      amenities: []
    });
    
    closeFilters();
  };
  
  /**
   * Altera a opção de ordenação
   */
  const changeSortingOption = (option) => {
    setSortingOption(option);
  };
  
  /**
   * Renderiza um item da lista de POIs
   */
  const renderPOIItem = ({ item }) => {
    const distance = calculateDistance(currentLocation, item);
    const isFavorite = favoritePOIs.includes(item.id);
    const isSelected = selectedPOI && selectedPOI.id === item.id;
    
    return (
      <POICard
        poi={item}
        distance={formatDistance(distance)}
        isFavorite={isFavorite}
        isSelected={isSelected}
        isNightMode={isNightMode}
        onPress={() => handleSelectPOI(item)}
        onFavoritePress={() => handleToggleFavorite(item)}
        onNavigatePress={() => handleNavigateToPOI(item)}
        onDetailsPress={() => handleViewPOIDetails(item)}
      />
    );
  };
  
  /**
   * Renderiza o cabeçalho da lista de POIs
   */
  const renderListHeader = () => {
    // Verificar se há algum filtro ativo
    const hasActiveFilters = 
      activeFilters.openNow || 
      activeFilters.hasParking || 
      activeFilters.favorites || 
      activeFilters.minimumRating > 0 || 
      activeFilters.amenities.length > 0 ||
      activeFilters.maxDistance !== 50;
    
    return (
      <View style={styles.listHeader}>
        <View style={styles.resultsHeader}>
          <Text style={[
            styles.resultsText,
            isNightMode && styles.textNight
          ]}>
            {filteredPois.length} {filteredPois.length === 1 ? 'resultado' : 'resultados'}
          </Text>
          
          <View style={styles.sortFilterControls}>
            <TouchableOpacity 
              style={[styles.sortButton, isNightMode && styles.buttonNight]} 
              onPress={() => {
                // Mostrar opções de ordenação
                Alert.alert(
                  'Ordenar por',
                  null,
                  [
                    { 
                      text: 'Distância', 
                      onPress: () => changeSortingOption('distance') 
                    },
                    { 
                      text: 'Avaliação', 
                      onPress: () => changeSortingOption('rating') 
                    },
                    { 
                      text: 'Nome', 
                      onPress: () => changeSortingOption('name') 
                    },
                    { 
                      text: 'Cancelar',
                      style: 'cancel'
                    }
                  ]
                );
              }}
            >
              <Icon name="sort" size={20} color={isNightMode ? "#FFFFFF" : "#000000"} />
              <Text style={[styles.buttonText, isNightMode && styles.textNight]}>
                {
                  sortingOption === 'distance' ? 'Distância' :
                  sortingOption === 'rating' ? 'Avaliação' : 'Nome'
                }
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[
                styles.filterButton, 
                hasActiveFilters && styles.activeFilterButton,
                isNightMode && styles.buttonNight
              ]} 
              onPress={openFilters}
            >
              <Icon 
                name="filter" 
                size={20} 
                color={
                  hasActiveFilters 
                    ? (isNightMode ? "#FFC107" : "#FF5722") 
                    : (isNightMode ? "#FFFFFF" : "#000000")
                } 
              />
              <Text 
                style={[
                  styles.buttonText, 
                  hasActiveFilters && styles.activeFilterText,
                  isNightMode && styles.textNight
                ]}
              >
                Filtros
                {hasActiveFilters ? ' (Ativos)' : ''}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {isOfflineMode && (
          <ConnectionBanner 
            message="Você está no modo offline. Alguns dados podem estar desatualizados."
            type="warning"
          />
        )}
      </View>
    );
  };
  
  /**
   * Renderiza conteúdo quando não há resultados
   */
  const renderEmptyList = () => {
    if (loading) return null;
    
    return (
      <NoResultsView
        message={
          searchQuery 
            ? `Nenhum resultado encontrado para "${searchQuery}".` 
            : "Nenhum ponto de interesse encontrado nesta categoria."
        }
        suggestion={
          searchQuery 
            ? "Tente mudar os termos da busca ou remover filtros." 
            : "Tente selecionar outra categoria ou remover filtros."
        }
        isNightMode={isNightMode}
        onReset={() => {
          if (searchQuery) {
            handleClearSearch();
          } else {
            handleCategoryChange('all');
            clearFilters();
          }
        }}
      />
    );
  };
  
  /**
   * Renderiza a visão de lista
   */
  const renderListView = () => {
    return (
      <FlatList
        ref={listRef}
        data={filteredPois}
        renderItem={renderPOIItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={renderListHeader}
        ListEmptyComponent={renderEmptyList}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        initialNumToRender={10}
        maxToRenderPerBatch={20}
        windowSize={10}
        removeClippedSubviews={Platform.OS !== 'web'}
        getItemLayout={(data, index) => ({
          length: 140, // altura aproximada de cada item
          offset: 140 * index,
          index
        })}
      />
    );
  };
  
  /**
   * Renderiza a visão de mapa
   */
  const renderMapView = () => {
    return (
      <View style={styles.mapContainer}>
        <POIMap
          ref={mapRef}
          style={styles.map}
          pois={filteredPois}
          currentLocation={currentLocation}
          selectedPOI={selectedPOI}
          isNightMode={isNightMode}
          onPOISelect={handleSelectPOI}
        />
        
        {/* Card do POI selecionado */}
        {selectedPOI && (
          <View style={[
            styles.selectedPOICard,
            isNightMode && styles.selectedPOICardNight,
            { bottom: insets.bottom + 16 }
          ]}>
            {renderPOIItem({ item: selectedPOI })}
          </View>
        )}
      </View>
    );
  };
  
  return (
    <SafeAreaView style={[
      styles.container,
      isNightMode && styles.containerNight
    ]}>
      <StatusBar
        barStyle={isNightMode ? 'light-content' : 'dark-content'}
        backgroundColor={isNightMode ? '#121212' : '#FFFFFF'}
      />
      
      {/* Cabeçalho */}
      <View style={[
        styles.header,
        isNightMode && styles.headerNight,
        { paddingTop: Platform.OS === 'ios' ? 0 : insets.top }
      ]}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-left" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
        </TouchableOpacity>
        
        <View style={styles.searchContainer}>
          <TextInput
            ref={searchInputRef}
            style={[
              styles.searchInput,
              isNightMode && styles.searchInputNight,
              isSearchFocused && styles.searchInputFocused
            ]}
            placeholder="Buscar pontos de interesse..."
            placeholderTextColor={isNightMode ? "#999999" : "#777777"}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          
          {searchQuery.length > 0 && (
            <TouchableOpacity
              style={styles.clearSearchButton}
              onPress={handleClearSearch}
            >
              <Icon name="close-circle" size={20} color={isNightMode ? "#CCCCCC" : "#777777"} />
            </TouchableOpacity>
          )}
          
          <TouchableOpacity
            style={styles.searchButton}
            onPress={handleSearch}
          >
            <Icon name="magnify" size={22} color={isNightMode ? "#FFFFFF" : "#000000"} />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity
          style={styles.viewModeButton}
          onPress={toggleViewMode}
        >
          <Icon 
            name={viewMode === 'list' ? 'map' : 'format-list-bulleted'} 
            size={24} 
            color={isNightMode ? "#FFFFFF" : "#000000"} 
          />
        </TouchableOpacity>
      </View>
      
      {/* Seletor de categorias */}
      <CategorySelector
        categories={availableCategories}
        selectedCategory={selectedCategory}
        onSelectCategory={handleCategoryChange}
        isNightMode={isNightMode}
        isTruckMode={isTruckMode}
        style={styles.categorySelector}
      />
      
      {/* Conteúdo principal */}
      <View style={styles.content}>
        {viewMode === 'list' ? renderListView() : renderMapView()}
      </View>
      
      {/* Painel de Filtros */}
      {filtersVisible && (
        <Animated.View
          style={[
            styles.filtersOverlay,
            {
              opacity: filtersAnimation,
              transform: [
                {
                  translateY: filtersAnimation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [300, 0]
                  })
                }
              ]
            }
          ]}
        >
          <View style={[
            styles.filtersPanel,
            isNightMode && styles.filtersPanelNight,
            { paddingBottom: insets.bottom }
          ]}>
            <View style={styles.filtersPanelHeader}>
              <Text style={[styles.filtersPanelTitle, isNightMode && styles.textNight]}>
                Filtros
              </Text>
              <TouchableOpacity onPress={closeFilters}>
                <Icon name="close" size={24} color={isNightMode ? "#FFFFFF" : "#000000"} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.filtersPanelContent}>
              <FilterControls
                filters={activeFilters}
                onApplyFilters={applyFilters}
                onClearFilters={clearFilters}
                isNightMode={isNightMode}
                isTruckMode={isTruckMode}
              />
            </ScrollView>
          </View>
        </Animated.View>
      )}
      
      {/* Indicador de carregamento */}
      {loading && <LoadingOverlay />}
    </SafeAreaView>
  );
};

// Estilos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  containerNight: {
    backgroundColor: '#121212'
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE'
  },
  headerNight: {
    backgroundColor: '#121212',
    borderBottomColor: '#333333'
  },
  backButton: {
    padding: 8
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 8,
    position: 'relative'
  },
  searchInput: {
    flex: 1,
    height: 40,
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingRight: 40,
    fontSize: 16,
    color: '#333333'
  },
  searchInputNight: {
    backgroundColor: '#333333',
    color: '#FFFFFF'
  },
  searchInputFocused: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#0077CC'
  },
  clearSearchButton: {
    position: 'absolute',
    right: 40,
    padding: 8
  },
  searchButton: {
    position: 'absolute',
    right: 4,
    padding: 8
  },
  viewModeButton: {
    padding: 8
  },
  categorySelector: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    zIndex: 1
  },
  content: {
    flex: 1
  },
  listContent: {
    flexGrow: 1,
    paddingBottom: 16
  },
  listHeader: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8
  },
  resultsText: {
    fontSize: 14,
    color: '#666666'
  },
  sortFilterControls: {
    flexDirection: 'row'
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16
  },
  buttonNight: {
    backgroundColor: '#333333'
  },
  activeFilterButton: {
    backgroundColor: '#FFF8E1',
    borderWidth: 1,
    borderColor: '#FFC107'
  },
  buttonText: {
    fontSize: 14,
    marginLeft: 4,
    color: '#333333'
  },
  activeFilterText: {
    color: '#FF5722',
    fontWeight: '500'
  },
  mapContainer: {
    flex: 1,
    position: 'relative'
  },
  map: {
    ...StyleSheet.absoluteFillObject
  },
  selectedPOICard: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4
  },
  selectedPOICardNight: {
    backgroundColor: '#1E1E1E'
  },
  filtersOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end'
  },
  filtersPanel: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '80%'
  },
  filtersPanelNight: {
    backgroundColor: '#1E1E1E'
  },
  filtersPanelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE'
  },
  filtersPanelTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333333'
  },
  filtersPanelContent: {
    padding: 16
  },
  textNight: {
    color: '#FFFFFF'
  }
});

export default POIScreen;