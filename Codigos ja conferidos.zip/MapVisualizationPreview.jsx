import React, { useState } from 'react';
import { Map, Eye, LayoutGrid, AlertTriangle, Check, X } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Este é um componente de demonstração para preview
const MapVisualizationPreview = () => {
  const [selectedMode, setSelectedMode] = useState('full');
  const [showModeSelector, setShowModeSelector] = useState(true);
  
  // Dados simulados para preview
  const alertsData = [
    { id: 1, type: 'tiroteio', description: 'Conflito armado na região' },
    { id: 2, type: 'sequestro', description: 'Tentativa de sequestro reportada' },
    { id: 3, type: 'roubo_carga', description: 'Roubo de carga na rodovia BR-116' }
  ];

  return (
    <div className="relative w-full h-screen bg-gray-900 overflow-hidden">
      {/* Simulação da área do mapa */}
      <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
        <div className="absolute inset-0" style={{
          backgroundImage: `url('/api/placeholder/800/600')`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
          opacity: 0.3
        }} />
        
        {/* Simulação dos alertas no mapa */}
        <div className="absolute top-1/3 left-1/4">
          <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center animate-pulse">
            <AlertTriangle size={14} className="text-white" />
          </div>
        </div>
        
        <div className="absolute top-2/3 left-2/3">
          <div className="w-6 h-6 bg-amber-500 rounded-full flex items-center justify-center animate-pulse">
            <AlertTriangle size={14} className="text-white" />
          </div>
        </div>
        
        <div className="absolute top-1/2 left-3/4">
          <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center animate-pulse">
            <AlertTriangle size={14} className="text-white" />
          </div>
        </div>
        
        {/* Rota simulada */}
        {selectedMode === 'route' && (
          <div className="absolute inset-0">
            <svg width="100%" height="100%" style={{ position: 'absolute' }}>
              <path 
                d="M100,100 C200,150 300,200 400,150 C500,100 600,200 700,300" 
                stroke="#3B82F6" 
                strokeWidth="6" 
                fill="none" 
                strokeLinecap="round"
                strokeDasharray={selectedMode === 'route' ? "0" : "10,10"}
              />
            </svg>
          </div>
        )}
      </div>

      {/* Interface do usuário */}
      {showModeSelector && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-gray-900 rounded-lg shadow-lg p-4 w-[600px] z-10">
          <div className="grid grid-cols-3 gap-4">
            {/* Modo Rota */}
            <button
              onClick={() => setSelectedMode('route')}
              className={`p-4 rounded-lg flex flex-col items-center ${
                selectedMode === 'route' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <Map size={24} className="text-white mb-2" />
              <h3 className="text-white font-medium">Rota Detalhada</h3>
              <p className="text-sm text-gray-400 text-center mt-2">
                Visualize a rota completa com números de trechos
              </p>
            </button>

            {/* Modo Mapa Completo */}
            <button
              onClick={() => setSelectedMode('full')}
              className={`p-4 rounded-lg flex flex-col items-center ${
                selectedMode === 'full' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <Eye size={24} className="text-white mb-2" />
              <h3 className="text-white font-medium">Mapa Completo</h3>
              <p className="text-sm text-gray-400 text-center mt-2">
                Visualize todas as vias e detalhes da região
              </p>
            </button>

            {/* Modo Simplificado */}
            <button
              onClick={() => setSelectedMode('simplified')}
              className={`p-4 rounded-lg flex flex-col items-center ${
                selectedMode === 'simplified' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <LayoutGrid size={24} className="text-white mb-2" />
              <h3 className="text-white font-medium">Mapa Simplificado</h3>
              <p className="text-sm text-gray-400 text-center mt-2">
                Apenas vias principais para caminhões
              </p>
            </button>
          </div>
        </div>
      )}

      {/* Indicador de modo atual */}
      <div 
        className="absolute top-4 right-4 bg-gray-900 rounded-lg p-2 flex items-center cursor-pointer hover:bg-gray-800 z-10"
        onClick={() => setShowModeSelector(true)}
      >
        <div className="flex items-center space-x-2">
          {selectedMode === 'route' && <Map size={16} className="text-white" />}
          {selectedMode === 'full' && <Eye size={16} className="text-white" />}
          {selectedMode === 'simplified' && <LayoutGrid size={16} className="text-white" />}
          <span className="text-white">
            {selectedMode === 'route' && 'Rota Detalhada'}
            {selectedMode === 'full' && 'Mapa Completo'}
            {selectedMode === 'simplified' && 'Mapa Simplificado'}
          </span>
        </div>
      </div>

      {/* Elementos específicos de cada modo */}
      {selectedMode === 'route' && (
        <>
          {/* Legenda de rota */}
          <div className="absolute bottom-4 left-4 bg-gray-900 rounded-lg p-4 z-10">
            <h4 className="text-white font-medium mb-2">Legenda de Trechos</h4>
            <div className="space-y-2">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-blue-500 rounded mr-2" />
                <span className="text-gray-300">Autoestradas</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-500 rounded mr-2" />
                <span className="text-gray-300">Estradas Nacionais</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-500 rounded mr-2" />
                <span className="text-gray-300">Estradas Departamentais</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded mr-2" />
                <span className="text-gray-300">Alertas de Segurança</span>
              </div>
            </div>
          </div>

          {/* Informações da rota */}
          <div className="absolute top-20 right-4 bg-gray-900 rounded-lg p-4 w-64 z-10">
            <h4 className="text-white font-medium mb-2">Informações da Rota</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Distância:</span>
                <span className="text-white">487 km</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Tempo Estimado:</span>
                <span className="text-white">5h 45min</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Pedágios:</span>
                <span className="text-white">4</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Alertas na Rota:</span>
                <span className="text-white font-bold text-amber-500">3</span>
              </div>
            </div>
          </div>

          {/* Botões de confirmação */}
          <div className="absolute bottom-4 right-4 bg-gray-900 rounded-lg p-4 z-10">
            <div className="flex items-center space-x-4">
              <button 
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded flex items-center"
              >
                <Check size={16} className="mr-2" />
                Confirmar Rota
              </button>
              <button 
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded flex items-center"
              >
                <X size={16} className="mr-2" />
                Cancelar
              </button>
            </div>
          </div>
        </>
      )}

      {selectedMode === 'simplified' && (
        <div className="absolute top-20 left-4 bg-gray-900 rounded-lg p-4 z-10">
          <h4 className="text-white font-medium mb-2">Filtros de Vias</h4>
          <div className="space-y-2">
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Autoestradas</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Estradas Nacionais</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Estradas Departamentais</span>
            </label>
          </div>
          
          <h4 className="text-white font-medium mt-4 mb-2">Filtros de Alertas</h4>
          <div className="space-y-2">
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Tiroteio</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Sequestro</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Roubo de Carga</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Veículo Suspeito</span>
            </label>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" defaultChecked />
              <span className="text-gray-300">Alta Velocidade</span>
            </label>
          </div>
        </div>
      )}

      {/* Painel de alertas (presente apenas no modo full) */}
      {selectedMode === 'full' && (
        <div className="absolute top-20 right-4 bg-gray-900 rounded-lg p-4 w-80 z-10">
          <h4 className="text-white font-medium mb-4 flex items-center">
            <AlertTriangle size={18} className="text-amber-500 mr-2" />
            Alertas de Segurança
          </h4>
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {alertsData.map(alert => (
              <Alert key={alert.id} className="mb-2 bg-gray-800 border-amber-600">
                <div className="flex items-center">
                  <AlertTriangle size={16} className={
                    alert.type === 'tiroteio' ? "text-red-500" : 
                    alert.type === 'sequestro' ? "text-amber-500" : 
                    "text-orange-500"
                  } />
                  <AlertTitle className="ml-2 text-white">
                    {alert.type === 'tiroteio' && 'Alerta de Tiroteio'}
                    {alert.type === 'sequestro' && 'Alerta de Sequestro'}
                    {alert.type === 'roubo_carga' && 'Alerta de Roubo de Carga'}
                  </AlertTitle>
                </div>
                <AlertDescription className="text-gray-300 mt-1">
                  {alert.description}
                </AlertDescription>
              </Alert>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MapVisualizationPreview;