import React, { useState, useEffect } from 'react';
import { AlertTriangle, Truck, TrendingDown, ArrowRight, Thermometer, Check, X } from 'lucide-react';

const SerraAlertSystemComplete = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [simulationStage, setSimulationStage] = useState(0);
  const [isLoaded, setIsLoaded] = useState(null);
  const [currentSpeed, setCurrentSpeed] = useState(60);
  const [currentPosition, setCurrentPosition] = useState(0); // km percorridos na serra
  const [showTriangle, setShowTriangle] = useState(false);
  const [triangleType, setTriangleType] = useState('warning');
  const [alertMessage, setAlertMessage] = useState('');
  const [showEscapeInfo, setShowEscapeInfo] = useState(false);
  const [showPostDescentWarning, setShowPostDescentWarning] = useState(false);
  
  // Informações da serra completa
  const serraInfo = {
    name: "Serra da Cantareira - SP",
    length: 12, // km
    avgDeclive: "8%",
    maxDeclive: "12%",
    dangerPoints: 5,
    flatEndPosition: 10.5, // km onde começa a área plana
    hasEscapeRamps: true,
    escapeRamps: [
      { position: 3.2, name: "Saída de Emergência 1", condition: "Bom estado" },
      { position: 6.8, name: "Saída de Emergência 2", condition: "Manutenção recente" },
      { position: 9.1, name: "Saída de Emergência Final", condition: "Ótimo estado" }
    ]
  };
  
  // Simular progresso na descida da serra para demonstração
  useEffect(() => {
    if (simulationStage >= 5 && simulationStage < 9) {
      const progressTimer = setInterval(() => {
        setCurrentPosition(prev => {
          // Avançar gradualmente pela serra
          const newPosition = prev + 0.1;
          
          // Verificar se chegou ao final da serra
          if (newPosition >= serraInfo.length) {
            clearInterval(progressTimer);
            setSimulationStage(9); // Estágio de pós-descida
            return serraInfo.length;
          }
          
          return newPosition;
        });
      }, 500);
      
      return () => clearInterval(progressTimer);
    }
  }, [simulationStage, serraInfo.length]);
  
  // Controlar fluxo da simulação
  useEffect(() => {
    const handleStageChange = () => {
      switch (simulationStage) {
        case 1: // 200m antes da descida - Mostrar triângulo amarelo por 3 segundos
          setShowTriangle(true);
          setTriangleType('warning');
          setAlertMessage('ATENÇÃO! DESCIDA DE SERRA À FRENTE');
          setTimeout(() => {
            setShowTriangle(false);
            setSimulationStage(2);
          }, 3000);
          break;
          
        case 2: // Informação sobre saídas de escape
          setShowEscapeInfo(true);
          setTimeout(() => {
            setShowEscapeInfo(false);
            setSimulationStage(3);
          }, 5000);
          break;
          
        case 9: // Avisos pós-descida
          setShowPostDescentWarning(true);
          break;
          
        default:
          break;
      }
    };
    
    handleStageChange();
  }, [simulationStage]);
  
  // Encontrar a próxima saída de escape com base na posição atual
  const findNextEscapeRamp = () => {
    const nextRamps = serraInfo.escapeRamps
      .filter(ramp => ramp.position > currentPosition)
      .sort((a, b) => a.position - b.position);
    
    return nextRamps.length > 0 ? nextRamps[0] : null;
  };
  
  // Calcular distâncias relevantes
  const calculateDistances = () => {
    // Distância para o final da serra
    const distanceToEnd = (serraInfo.length - currentPosition).toFixed(1);
    
    // Distância para o final do trecho de declive (início da área plana)
    const distanceToFlatArea = Math.max(0, (serraInfo.flatEndPosition - currentPosition)).toFixed(1);
    
    // Próxima saída de escape
    const nextRamp = findNextEscapeRamp();
    const distanceToNextRamp = nextRamp ? (nextRamp.position - currentPosition).toFixed(1) : "N/A";
    
    return {
      distanceToEnd,
      distanceToFlatArea,
      distanceToNextRamp,
      nextRamp
    };
  };
  
  // Renderização do triângulo de alerta
  const renderTriangle = () => {
    if (!showTriangle) return null;
    
    const colors = {
      warning: {
        background: '#ffee00',
        triangle: '#111111',
        text: '#111111'
      },
      danger: {
        background: '#ff5500',
        triangle: '#331111',
        text: '#ffffff'
      }
    };
    
    const selectedColors = colors[triangleType] || colors.warning;
    
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center flex-col"
        style={{ backgroundColor: selectedColors.background }}
      >
        <div className="w-64 h-64 mb-8">
          <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
            <path 
              d="M50,10 L90,90 L10,90 Z" 
              fill={selectedColors.triangle} 
            />
            <path 
              d="M50,30 L50,60 L50,60 Z" 
              fill={selectedColors.background} 
              stroke={selectedColors.background} 
              strokeWidth="10" 
              strokeLinecap="round" 
            />
            <circle 
              cx="50" 
              cy="75" 
              r="5" 
              fill={selectedColors.background} 
            />
          </svg>
        </div>
        
        <div 
          className="text-center text-2xl font-bold max-w-xl px-6"
          style={{ color: selectedColors.text }}
        >
          {alertMessage}
        </div>
      </div>
    );
  };
  
  // Renderização da informação sobre saídas de escape
  const renderEscapeRampInfo = () => {
    if (!showEscapeInfo) return null;
    
    return (
      <div className="fixed inset-0 bg-blue-900 bg-opacity-95 flex items-center justify-center z-50 p-4">
        <div className="bg-gray-800 rounded-lg shadow-lg max-w-md w-full p-6">
          <h2 className="text-2xl font-bold text-center text-white mb-6">
            INFORMAÇÃO DE SEGURANÇA
          </h2>
          
          <div className="text-center mb-6">
            {serraInfo.hasEscapeRamps ? (
              <div className="text-green-400 text-xl mb-2">
                ✓ ESTA SERRA POSSUI SAÍDAS DE ESCAPE
              </div>
            ) : (
              <div className="text-red-400 text-xl mb-2">
                ✗ ESTA SERRA NÃO POSSUI SAÍDAS DE ESCAPE
              </div>
            )}
            
            <p className="text-white text-lg">
              {serraInfo.name} - {serraInfo.length}km
            </p>
          </div>
          
          {serraInfo.hasEscapeRamps && (
            <div className="mb-4">
              <h3 className="text-blue-300 font-medium mb-2">Saídas de Emergência Disponíveis:</h3>
              <ul className="space-y-2">
                {serraInfo.escapeRamps.map((ramp, index) => (
                  <li key={index} className="flex items-center text-white">
                    <ArrowRight className="w-5 h-5 mr-2 text-green-400" />
                    <div>
                      <div>{ramp.name}</div>
                      <div className="text-sm text-gray-300">
                        Posição: Km {ramp.position} • {ramp.condition}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          <p className="text-yellow-200 text-center mt-6">
            Estas informações permanecerão visíveis durante toda a descida
          </p>
          
          <button
            onClick={() => setShowEscapeInfo(false)}
            className="mt-4 w-full py-3 bg-blue-700 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
          >
            Entendi
          </button>
        </div>
      </div>
    );
  };
  
  // Renderização do aviso pós-descida
  const renderPostDescentWarning = () => {
    if (!showPostDescentWarning) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
        <div className="bg-red-900 rounded-lg shadow-lg max-w-md w-full p-6">
          <div className="flex items-center justify-center mb-4">
            <Thermometer className="w-16 h-16 text-red-400" />
          </div>
          
          <h2 className="text-2xl font-bold text-center text-white mb-4">
            ALERTA DE FREIOS SUPERAQUECIDOS
          </h2>
          
          <div className="p-4 bg-black bg-opacity-30 rounded-lg mb-4">
            <p className="text-white text-lg mb-3">
              <span className="font-bold text-yellow-300">NÃO PARE IMEDIATAMENTE!</span> Se seus freios estão fumaceando, continue dirigindo em baixa velocidade.
            </p>
            
            <div className="flex items-start mb-3">
              <AlertTriangle className="w-5 h-5 text-red-400 mr-2 flex-shrink-0 mt-1" />
              <p className="text-white text-sm">
                Quando você para, interrompe a refrigeração pelo fluxo de ar, aumentando o risco de incêndio.
              </p>
            </div>
            
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 text-red-400 mr-2 flex-shrink-0 mt-1" />
              <p className="text-white text-sm">
                Ao acionar o freio estacionário, as lonas quentes encostam nas campanas superaquecidas, podendo iniciar um incêndio.
              </p>
            </div>
          </div>
          
          <div className="mb-6 p-3 bg-yellow-900 rounded-lg">
            <h3 className="font-medium text-yellow-300 mb-1">PROCEDIMENTO CORRETO:</h3>
            <ol className="space-y-2 text-white text-sm pl-5 list-decimal">
              <li>Continue dirigindo em baixa velocidade por mais 5-10 minutos para resfriar os freios gradualmente</li>
              <li>Evite usar os freios durante este período</li>
              <li>Procure uma área segura e ampla para parar</li>
              <li>Após parar, não acione o freio estacionário imediatamente</li>
              <li>Monitore os freios por sinais de superaquecimento excessivo</li>
            </ol>
          </div>
          
          <button
            onClick={() => setShowPostDescentWarning(false)}
            className="w-full py-3 bg-yellow-600 hover:bg-yellow-500 text-white rounded-lg font-medium transition-colors"
          >
            Entendi e Seguirei as Instruções
          </button>
        </div>
      </div>
    );
  };
  
  // Painel de informações para exibição durante a descida
  const renderDescentInfoPanel = () => {
    if (simulationStage < 3 || simulationStage > 8) return null;
    
    const { distanceToEnd, distanceToFlatArea, distanceToNextRamp, nextRamp } = calculateDistances();
    
    return (
      <div className={`fixed bottom-0 left-0 right-0 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} bg-opacity-90 p-3 border-t border-gray-700 shadow-lg z-10`}>
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm">
              <span className="text-blue-400 font-medium">Serra:</span> {serraInfo.name}
            </div>
            <div className="text-sm">
              <span className="text-blue-400 font-medium">Progresso:</span> {currentPosition.toFixed(1)} / {serraInfo.length} km
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="p-2 bg-blue-900/40 rounded">
              <div className="text-xs text-gray-300 mb-1">Até o final da serra:</div>
              <div className="font-medium text-white flex items-center">
                <TrendingDown className="w-4 h-4 mr-1 text-blue-400" />
                {distanceToEnd} km
              </div>
            </div>
            
            <div className="p-2 bg-green-900/40 rounded">
              <div className="text-xs text-gray-300 mb-1">Até área plana:</div>
              <div className="font-medium text-white flex items-center">
                <ArrowRight className="w-4 h-4 mr-1 text-green-400" />
                {distanceToFlatArea} km
              </div>
            </div>
            
            {serraInfo.hasEscapeRamps ? (
              <div className="p-2 bg-yellow-900/40 rounded">
                <div className="text-xs text-gray-300 mb-1">Próxima saída de escape:</div>
                <div className="font-medium text-white">
                  {nextRamp ? (
                    <div className="flex items-center">
                      <AlertTriangle className="w-4 h-4 mr-1 text-yellow-400" />
                      {distanceToNextRamp} km
                    </div>
                  ) : (
                    <span className="text-gray-400">Nenhuma restante</span>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-2 bg-red-900/40 rounded">
                <div className="text-xs text-gray-300 mb-1">Saídas de escape:</div>
                <div className="font-medium text-red-400 flex items-center">
                  <X className="w-4 h-4 mr-1" />
                  Indisponível
                </div>
              </div>
            )}
          </div>
          
          {nextRamp && (
            <div className="mt-2 text-xs text-center text-yellow-400">
              {nextRamp.name} - {nextRamp.condition}
            </div>
          )}
        </div>
      </div>
    );
  };
  
  // Painel de simulação para controlar o fluxo da demonstração
  const renderSimulationControls = () => {
    return (
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-6`}>
        <h2 className="text-lg font-medium mb-4">Controles de Simulação</h2>
        
        <div className="flex items-center justify-between mb-6">
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Posição Atual</div>
            <div className="text-2xl font-bold text-blue-500">
              {currentPosition.toFixed(1)} <span className="text-sm">km</span>
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-1">Estágio Atual</div>
            <div className="text-xl font-bold text-green-500">
              {simulationStage}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <button 
            onClick={() => setSimulationStage(1)}
            className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
          >
            Início - Triângulo Amarelo
          </button>
          
          <button 
            onClick={() => setSimulationStage(2)}
            className="p-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg"
          >
            Info Saídas de Escape
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <button 
            onClick={() => setSimulationStage(3)}
            className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg"
          >
            Pergunta sobre Carga
          </button>
          
          <button 
            onClick={() => {
              setSimulationStage(5);
              setCurrentPosition(0);
            }}
            className="p-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg"
          >
            Iniciar Descida
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => setSimulationStage(9)}
            className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
          >
            Aviso Pós-Descida
          </button>
          
          <button 
            onClick={() => {
              setSimulationStage(0);
              setCurrentPosition(0);
              setIsLoaded(null);
              setShowTriangle(false);
              setShowEscapeInfo(false);
              setShowPostDescentWarning(false);
            }}
            className="p-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
          >
            Reiniciar Tudo
          </button>
        </div>
      </div>
    );
  };
  
  // Renderização da pergunta sobre carga
  const renderLoadQuestion = () => {
    if (simulationStage !== 3 && simulationStage !== 4) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
        <div className="bg-red-900 rounded-lg shadow-lg max-w-md w-full p-6 animate-pulse">
          <div className="flex items-center justify-center mb-4">
            <TrendingDown className="w-16 h-16 text-yellow-400" />
          </div>
          
          <h2 className="text-2xl font-bold text-center text-white mb-6">
            VOCÊ ESTÁ CARREGADO?
          </h2>
          
          <div className="text-center mb-6 text-yellow-200">
            <p>Você está prestes a descer a {serraInfo.name}</p>
            <p>Declive médio: {serraInfo.avgDeclive} • Extensão: {serraInfo.length} km</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => {
                setIsLoaded(true);
                setSimulationStage(5);
              }}
              className="py-4 bg-yellow-600 hover:bg-yellow-700 text-white text-xl font-bold rounded-lg transition-colors flex items-center justify-center"
            >
              <Truck className="w-6 h-6 mr-2" />
              SIM
            </button>
            
            <button 
              onClick={() => {
                setIsLoaded(false);
                setSimulationStage(5);
              }}
              className="py-4 bg-blue-600 hover:bg-blue-700 text-white text-xl font-bold rounded-lg transition-colors flex items-center justify-center"
            >
              <Check className="w-6 h-6 mr-2" />
              NÃO
            </button>
          </div>
          
          <div className="mt-6 text-center text-yellow-200 text-sm">
            <p>Esta informação é crucial para sua segurança</p>
            <p>e a de outros motoristas.</p>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className={`${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'} min-h-screen p-4 pb-20`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-6 border-b border-gray-700 pb-3">
        <div className="flex items-center">
          <TrendingDown className="w-6 h-6 mr-2 text-red-500" />
          <h1 className="text-xl font-bold">King Road - Alerta Completo para Descida de Serra</h1>
        </div>
      </div>
      
      {/* Renders dos elementos de interface baseados no estágio atual */}
      {renderSimulationControls()}
      {renderTriangle()}
      {renderEscapeRampInfo()}
      {renderLoadQuestion()}
      {renderDescentInfoPanel()}
      {renderPostDescentWarning()}
      
      {/* Informações da serra atual */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4`}>
        <h2 className="text-lg font-medium mb-4">Informações da Serra</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Nome</div>
            <div className="font-medium">{serraInfo.name}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Extensão</div>
            <div className="font-medium">{serraInfo.length} km</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Declive Médio</div>
            <div className="font-medium">{serraInfo.avgDeclive}</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Área Plana Inicia em</div>
            <div className="font-medium">{serraInfo.flatEndPosition} km</div>
          </div>
          
          <div className="p-3 bg-gray-700 rounded-lg text-center">
            <div className="text-xs text-gray-400 mb-1">Saídas de Escape</div>
            <div className="font-medium">{serraInfo.hasEscapeRamps ? serraInfo.escapeRamps.length : "Nenhuma"}</div>
          </div>
        </div>
        
        <div className="p-3 bg-blue-900/30 rounded-lg text-sm">
          <p>
            Esta demonstração simula o sistema completo de alertas para descida de serra, incluindo:
          </p>
          <ul className="mt-2 space-y-1 list-disc pl-5">
            <li>Alerta inicial 200m antes da descida (triângulo amarelo)</li>
            <li>Informações sobre saídas de escape disponíveis</li>
            <li>Pergunta sobre o estado de carga do caminhão</li>
            <li>Painel de informações durante a descida mostrando distâncias para saídas de escape e área plana</li>
            <li>Aviso pós-descida sobre cuidados com freios superaquecidos</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SerraAlertSystemComplete;