// confirmacao_modo_desenvolvedor_kingroad.js
export const devModeConfig = {
  fileReference: "modo_desenvolvedor_kingroad_completo_v3.json",
  description: "Modo desenvolvedor completo do KingRoad, com personalização avançada de interface, métricas visuais e ferramentas de edição em tempo real. Compatível com todos os países da base global.",
  status: "VALIDATED",
  appliesToAllCountriesFromGlobalReference: true,
  features: [
    "Ativação por toque e senha",
    "Edição visual de menus, botões e cores",
    "Fixação e organização de atalhos",
    "Exibição de métricas como zoom, inclinação e distâncias",
    "Gravação de tela e prints liberados",
    "Pré-visualização em tempo real para ajustes",
    "Numeração visual inteligente por tipo de tela"
  ],
  note: "Este modo é exclusivo para o administrador e não afeta a navegação do usuário comum. Ideal para testes e ajustes finos no layout do KingRoad."
};

export default devModeConfig;