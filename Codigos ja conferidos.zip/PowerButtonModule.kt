// PowerButtonModule.kt
package com.kingroad.native

import android.app.Activity
import android.content.Context
import android.os.Process
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.kingroad.cache.CacheManager
import com.kingroad.utils.Logger

/**
 * Módulo nativo para controle de desligamento do aplicativo e gerenciamento de cache
 */
class PowerButtonModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val MODULE_NAME = "KingRoadNative"
        private const val TAG = "PowerButtonModule"
    }

    override fun getName(): String = MODULE_NAME

    /**
     * Encerrar aplicativo imediatamente sem confirmação
     */
    @ReactMethod
    fun exitApplication() {
        Logger.d(TAG, "Encerrando aplicativo por solicitação do usuário")
        
        val mainHandler = android.os.Handler(reactContext.mainLooper)
        mainHandler.post {
            try {
                val activity = currentActivity
                if (activity != null) {
                    activity.finishAffinity()
                    Process.killProcess(Process.myPid())
                }
            } catch (e: Exception) {
                Logger.e(TAG, "Erro ao encerrar aplicativo: ${e.message}")
                Process.killProcess(Process.myPid())
            }
        }
    }

    /**
     * Verificar se a plataforma é Android
     */
    @ReactMethod(isBlockingSynchronousMethod = true)
    fun isAndroid(): Boolean = true
    
    /**
     * Verificar se a plataforma é iOS
     */
    @ReactMethod(isBlockingSynchronousMethod = true)
    fun isIOS(): Boolean = false
    
    /**
     * Verificar se a plataforma é Windows
     */
    @ReactMethod(isBlockingSynchronousMethod = true)
    fun isWindows(): Boolean = false
    
    /**
     * Obter o gerenciador de cache
     */
    @ReactMethod(isBlockingSynchronousMethod = true)
    fun getCacheManager(): CacheManager {
        return CacheManager(reactContext)
    }
}