package com.kingfamily.kingroad.developer

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.kingfamily.kingroad.R
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Diálogo para ativar o modo desenvolvedor através de senha.
 */
class DeveloperModeDialog : DialogFragment() {

    companion object {
        private const val CONFIG_FILE = "king_family_config.json"
        private const val DEFAULT_PASSWORD = "kingdev2025"
    }

    private lateinit var passwordEditText: EditText
    private lateinit var confirmButton: Button
    private lateinit var cancelButton: Button

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity())
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.dialog_developer_mode, null)

        // Inicializa componentes da UI
        passwordEditText = view.findViewById(R.id.password_edit_text)
        confirmButton = view.findViewById(R.id.confirm_button)
        cancelButton = view.findViewById(R.id.cancel_button)

        // Configura botões
        setupButtons()

        // Configura o diálogo
        builder.setView(view)
        builder.setTitle(R.string.developer_mode_prompt)

        val dialog = builder.create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)

        return dialog
    }

    /**
     * Configura os botões do diálogo
     */
    private fun setupButtons() {
        confirmButton.setOnClickListener {
            val password = passwordEditText.text.toString()
            if (checkPassword(password)) {
                activateDeveloperMode()
                dismiss()
            } else {
                Toast.makeText(
                    requireContext(),
                    R.string.developer_mode_denied,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        cancelButton.setOnClickListener {
            dismiss()
        }
    }

    /**
     * Verifica se a senha informada está correta
     */
    private fun checkPassword(password: String): Boolean {
        val correctPassword = getDeveloperPassword()
        return password == correctPassword
    }

    /**
     * Obtém a senha do modo desenvolvedor do arquivo de configuração
     */
    private fun getDeveloperPassword(): String {
        try {
            val inputStream = requireContext().assets.open(CONFIG_FILE)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.readText()
            reader.close()

            val config = JSONObject(jsonString)
            return config.optJSONObject("developer_mode")
                ?.optString("password", DEFAULT_PASSWORD) ?: DEFAULT_PASSWORD
        } catch (e: Exception) {
            // Em caso de erro, retorna a senha padrão
            return DEFAULT_PASSWORD
        }
    }

    /**
     * Ativa o modo desenvolvedor
     */
    private fun activateDeveloperMode() {
        // Exibe uma mensagem de confirmação
        Toast.makeText(
            requireContext(),
            R.string.developer_mode_activated,
            Toast.LENGTH_SHORT
        ).show()

        // Inicia a Activity do modo desenvolvedor
        val intent = Intent(requireContext(), DeveloperModeActivity::class.java)
        startActivity(intent)
    }
}