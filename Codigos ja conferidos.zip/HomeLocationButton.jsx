// HomeLocationButton.jsx
import React from 'react';

/**
 * Botão na tela inicial para acesso rápido à localização atual no mapa
 * ID do componente: 8506 (seguindo o sistema de IDs numéricos)
 */
const HomeLocationButton = ({ onPress }) => {
  const handlePress = () => {
    // Abre o mapa e centraliza na localização atual do usuário
    if (onPress) {
      onPress();
    } else if (window.KingRoadNative && window.KingRoadNative.navigation) {
      window.KingRoadNative.navigation.openMapAtCurrentLocation();
    }
  };
  
  return (
    <button 
      className="flex flex-col items-center justify-center p-3 bg-black border border-gray-800 rounded-xl hover:border-gold transition-colors"
      onClick={handlePress}
      id="home-location-button-8506"
    >
      {/* Ícone de localização */}
      <div className="w-14 h-14 rounded-full bg-blue-600 flex items-center justify-center mb-2">
        <svg 
          width="32" 
          height="32" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="white" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="8"></circle>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
      </div>
      
      {/* Texto */}
      <span className="text-white text-sm font-medium">Onde Estou?</span>
    </button>
  );
};

export default HomeLocationButton;