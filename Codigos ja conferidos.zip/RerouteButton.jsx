import React, { useState } from 'react';
import { RotateCcw, ArrowRightCircle, Shield, Clock, Fuel } from 'lucide-react';

// Caminho: web/src/components/RerouteButton.jsx
const RerouteButton = ({ onRerouteRequest, isLoading = false }) => {
  const [showAlternatives, setShowAlternatives] = useState(false);
  const [alternativeRoutes, setAlternativeRoutes] = useState([]);

  // Mock data for preview purposes
  const mockAlternativeRoutes = [
    { 
      id: 1, 
      name: 'Via BR-101', 
      distance: '423 km', 
      time: '4h 35min', 
      fuel: '52L',
      securityScore: 4.2,
      isRecommended: true
    },
    { 
      id: 2, 
      name: 'Via SP-330', 
      distance: '455 km', 
      time: '5h 10min', 
      fuel: '58L',
      securityScore: 4.8,
      isRecommended: false
    },
    { 
      id: 3, 
      name: 'Via BR-381', 
      distance: '490 km', 
      time: '5h 45min', 
      fuel: '60L',
      securityScore: 3.5,
      isRecommended: false
    }
  ];

  const handleRerouteClick = async () => {
    setShowAlternatives(true);
    
    // In a real implementation, this would call an API to get alternative routes
    // For preview, we'll use mock data and simulate a loading state
    setAlternativeRoutes([]);
    
    if (onRerouteRequest) {
      try {
        const routes = await onRerouteRequest();
        setAlternativeRoutes(routes);
      } catch (error) {
        console.error("Error fetching alternative routes:", error);
        // Fallback to mock data
        setAlternativeRoutes(mockAlternativeRoutes);
      }
    } else {
      // For preview/demo purposes
      setTimeout(() => {
        setAlternativeRoutes(mockAlternativeRoutes);
      }, 1500);
    }
  };

  const handleRouteSelect = (routeId) => {
    // Select the route and close the alternatives panel
    console.log(`Selected route with ID: ${routeId}`);
    setShowAlternatives(false);
    
    // In a real implementation, this would trigger the route change in the map
  };

  const handleCloseAlternatives = () => {
    setShowAlternatives(false);
  };

  return (
    <div className="relative">
      {/* Main Reroute Button */}
      <button 
        className="flex items-center justify-center p-3 bg-black border-2 border-yellow-500 rounded-full shadow-lg hover:bg-gray-900 active:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-yellow-500 transition-all duration-200"
        onClick={handleRerouteClick}
        disabled={isLoading}
        aria-label="Reroute"
      >
        <RotateCcw 
          className={`w-6 h-6 text-yellow-500 ${isLoading ? 'animate-spin' : ''}`} 
        />
      </button>

      {/* Alternative Routes Panel */}
      {showAlternatives && (
        <div className="absolute bottom-16 right-0 w-64 bg-gray-900 border-2 border-yellow-500 rounded-lg shadow-xl overflow-hidden">
          <div className="flex justify-between items-center p-3 bg-black border-b border-yellow-500">
            <h3 className="text-yellow-500 font-bold">Rotas Alternativas</h3>
            <button 
              onClick={handleCloseAlternatives}
              className="text-gray-400 hover:text-white"
              aria-label="Fechar"
            >
              ×
            </button>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {alternativeRoutes.length === 0 ? (
              <div className="p-4 text-center text-gray-400">
                <div className="flex justify-center my-2">
                  <RotateCcw className="w-6 h-6 animate-spin text-yellow-500" />
                </div>
                <p>Buscando melhores rotas...</p>
              </div>
            ) : (
              <ul>
                {alternativeRoutes.map((route) => (
                  <li 
                    key={route.id} 
                    className={`p-3 border-b border-gray-800 hover:bg-gray-800 cursor-pointer ${
                      route.isRecommended ? 'bg-gray-800' : ''
                    }`}
                    onClick={() => handleRouteSelect(route.id)}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-white font-medium">{route.name}</span>
                      {route.isRecommended && (
                        <span className="bg-yellow-500 text-black text-xs px-2 py-0.5 rounded-full">Recomendada</span>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-1 text-sm">
                      <div className="flex items-center text-gray-300">
                        <ArrowRightCircle className="w-4 h-4 mr-1 text-gray-400" />
                        <span>{route.distance}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Clock className="w-4 h-4 mr-1 text-gray-400" />
                        <span>{route.time}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Fuel className="w-4 h-4 mr-1 text-gray-400" />
                        <span>{route.fuel}</span>
                      </div>
                    </div>
                    <div className="flex items-center mt-1">
                      <Shield className="w-4 h-4 mr-1 text-gray-400" />
                      <div className="w-full bg-gray-700 h-2 rounded-full">
                        <div 
                          className="bg-yellow-500 h-2 rounded-full" 
                          style={{ width: `${(route.securityScore / 5) * 100}%` }}
                        />
                      </div>
                      <span className="ml-2 text-xs text-gray-300">{route.securityScore}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default RerouteButton;