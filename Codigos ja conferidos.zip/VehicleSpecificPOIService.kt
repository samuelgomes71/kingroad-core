class VehicleSpecificPOIService {
    private val supportedVehicleTypes = setOf(
        "TRUCK",
        "LIVESTOCK_TRUCK",
        "CATTLE_TRUCK",
        "HEAVY_TRUCK",
        "FUEL_TRUCK",
        "CAR_CARRIER_TRUCK"
    )

    fun shouldShowPOI(poiType: POIType, vehicleConfig: VehicleConfiguration): Boolean {
        // Primeiro verifica se é um veículo suportado
        if (!supportedVehicleTypes.contains(vehicleConfig.type)) {
            return false
        }

        // Depois verifica as regras específicas para cada tipo de POI
        return when (poiType) {
            POIType.BULLTEL -> {
                vehicleConfig.type in setOf("LIVESTOCK_TRUCK", "CATTLE_TRUCK")
            }
            POIType.FUEL_DISTRIBUTOR -> {
                vehicleConfig.type in setOf("TRUCK", "HEAVY_TRUCK", "FUEL_TRUCK")
            }
            POIType.TRUCKER_LAUNDRY -> {
                vehicleConfig.type in supportedVehicleTypes // Todos os tipos de caminhão
            }
            POIType.CENTRE_ROUTIER -> {
                vehicleConfig.type in supportedVehicleTypes // Todos os tipos de caminhão
            }
            POIType.CAR_FACTORY -> {
                vehicleConfig.type == "CAR_CARRIER_TRUCK"
            }
            POIType.PRIVATE_TRUCK_PARKING -> {
                vehicleConfig.type in supportedVehicleTypes // Todos os tipos de caminhão
            }
            else -> false
        }
    }
}

enum class POIType {
    BULLTEL,              // Paradas para descanso de animais
    FUEL_DISTRIBUTOR,     // Distribuidoras de combustível
    TRUCKER_LAUNDRY,      // Lavanderias para caminhoneiros
    TRUCK_STOP,           // Paradas de caminhão
    TRUCK_PARKING,        // Estacionamentos para caminhões
    PRIVATE_TRUCK_PARKING,// Estacionamentos privados pagos
    TRUCK_SERVICE,        // Serviços para caminhões
    CENTRE_ROUTIER,       // Centros rodoviários na França
    CAR_FACTORY           // Fábricas de carros (para cegonhas)
}

data class VehicleConfiguration(
    val type: String,           // Tipo do veículo
    val subType: String? = null,// Subtipo específico
    val cargo: String? = null,  // Tipo de carga (se aplicável)
    val restrictions: List<String> = listOf()
)