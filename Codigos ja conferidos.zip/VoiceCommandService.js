/**
 * VoiceCommandService.js
 * 
 * Serviço para gerenciar comandos de voz no sistema KingRoad.
 * Implementa a base funcional e o sistema em desenvolvimento mencionados no relatório.
 */

import { TranslationsService } from './TranslationsService';
import { NavigationService } from './NavigationService';
import { POIService } from './POIService';

class VoiceCommandService {
  constructor() {
    this.isActive = false;
    this.isListening = false;
    this.recognition = null;
    this.translations = TranslationsService.getInstance();
    this.navigationService = NavigationService.getInstance();
    this.poiService = POIService.getInstance();
    this.commands = this.setupCommands();
  }

  /**
   * Instância singleton do serviço
   */
  static instance = null;
  
  /**
   * Obtém a instância do serviço, criando-a se necessário
   */
  static getInstance() {
    if (!VoiceCommandService.instance) {
      VoiceCommandService.instance = new VoiceCommandService();
    }
    return VoiceCommandService.instance;
  }

  /**
   * Configura os comandos de voz disponíveis
   * Exemplos do relatório: "Encontrar [nome]", "Calcular pernoite", "Caminho inverso",
   * "Mudar para KingChat", "Qual o seu Q.R.A.?"
   */
  setupCommands() {
    return {
      find: {
        patterns: ["encontrar", "localizar", "buscar", "achar"],
        handler: (params) => this.handleFindCommand(params)
      },
      overnight: {
        patterns: ["calcular pernoite", "pernoite", "local para dormir"],
        handler: () => this.handleOvernightCommand()
      },
      reverseRoute: {
        patterns: ["caminho inverso", "rota inversa", "inverter rota", "voltar"],
        handler: () => this.handleReverseRouteCommand()
      },
      switchToChat: {
        patterns: ["mudar para kingchat", "abrir chat", "kingchat"],
        handler: () => this.handleSwitchToChatCommand()
      },
      qra: {
        patterns: ["qual o seu q.r.a", "qual seu qra", "seu qra"],
        handler: () => this.handleQRACommand()
      }
    };
  }

  /**
   * Inicializa o sistema de reconhecimento de voz
   */
  initialize() {
    try {
      // Verificar se o navegador suporta reconhecimento de voz
      if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        console.error('Reconhecimento de voz não suportado neste dispositivo');
        return false;
      }

      // Criar instância de reconhecimento de voz
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      
      // Configurar reconhecimento
      this.recognition.continuous = true;
      this.recognition.interimResults = false;
      
      // Definir idioma com base na configuração atual
      this.recognition.lang = this.translations.getCurrentLanguage() || 'pt-BR';
      
      // Configurar handlers de eventos
      this.recognition.onresult = this.handleSpeechResult.bind(this);
      this.recognition.onerror = this.handleSpeechError.bind(this);
      this.recognition.onend = this.handleSpeechEnd.bind(this);
      
      this.isActive = true;
      return true;
    } catch (error) {
      console.error('Erro ao inicializar reconhecimento de voz:', error);
      this.isActive = false;
      return false;
    }
  }

  /**
   * Inicia a escuta de comandos de voz
   */
  startListening() {
    if (!this.isActive) {
      if (!this.initialize()) {
        return false;
      }
    }
    
    try {
      this.recognition.start();
      this.isListening = true;
      console.log('Serviço de comandos de voz iniciado');
      return true;
    } catch (error) {
      console.error('Erro ao iniciar reconhecimento de voz:', error);
      this.isListening = false;
      return false;
    }
  }

  /**
   * Para a escuta de comandos de voz
   */
  stopListening() {
    if (this.isListening && this.recognition) {
      try {
        this.recognition.stop();
        this.isListening = false;
        console.log('Serviço de comandos de voz parado');
      } catch (error) {
        console.error('Erro ao parar reconhecimento de voz:', error);
      }
    }
  }

  /**
   * Processa os resultados do reconhecimento de voz
   */
  handleSpeechResult(event) {
    if (!event.results || event.results.length === 0) {
      return;
    }
    
    const lastResult = event.results[event.results.length - 1];
    if (!lastResult.isFinal) {
      return;
    }
    
    const transcript = lastResult[0].transcript.trim().toLowerCase();
    console.log('Comando detectado:', transcript);
    
    this.processCommand(transcript);
  }

  /**
   * Processa um comando de voz e executa a ação correspondente
   */
  processCommand(transcript) {
    // Verificar cada comando registrado
    for (const [commandKey, commandObj] of Object.entries(this.commands)) {
      // Verificar se o transcript contém algum dos padrões do comando
      for (const pattern of commandObj.patterns) {
        if (transcript.includes(pattern.toLowerCase())) {
          // Extrair parâmetros (se necessário)
          let params = null;
          if (commandKey === 'find') {
            // Extrair o que vem após o padrão
            const patternIndex = transcript.indexOf(pattern);
            if (patternIndex !== -1) {
              params = transcript.substring(patternIndex + pattern.length).trim();
            }
          }
          
          // Executar o handler do comando
          commandObj.handler(params);
          return;
        }
      }
    }
    
    // Se chegou aqui, nenhum comando foi reconhecido
    this.handleUnknownCommand(transcript);
  }

  /**
   * Handler para erros de reconhecimento de voz
   */
  handleSpeechError(event) {
    console.error('Erro no reconhecimento de voz:', event.error);
    
    // Reiniciar a escuta em caso de erro (exceto se for um erro de rede)
    if (event.error !== 'network' && this.isListening) {
      setTimeout(() => {
        this.startListening();
      }, 1000);
    }
  }

  /**
   * Handler para o fim do reconhecimento de voz
   */
  handleSpeechEnd() {
    console.log('Reconhecimento de voz finalizado');
    
    // Reiniciar a escuta se ainda estiver marcado como ouvindo
    if (this.isListening) {
      this.startListening();
    }
  }

  /**
   * Implementações dos handlers de comandos
   */
  
  handleFindCommand(searchTerm) {
    if (!searchTerm || searchTerm.length < 2) {
      // Feedback ao usuário sobre termo de busca inválido
      return;
    }
    
    console.log(`Buscando: "${searchTerm}"`);
    // Usar o serviço POI para buscar o termo
    this.poiService.searchPOIByName(searchTerm)
      .then(results => {
        if (results && results.length > 0) {
          // Exibir resultados ou navegar diretamente se for único
          if (results.length === 1) {
            this.navigationService.navigateTo(results[0]);
          } else {
            // Mostrar lista de resultados na interface
            // (implementação depende da integração com UI)
          }
        } else {
          // Feedback ao usuário: nenhum resultado encontrado
        }
      });
  }

  handleOvernightCommand() {
    console.log('Calculando locais para pernoite próximos');
    
    // Buscar a localização atual
    this.navigationService.getCurrentLocation()
      .then(location => {
        // Usar o serviço POI para encontrar locais de pernoite
        this.poiService.findNearbyPOIByCategory(location, 'overnight')
          .then(results => {
            // Mostrar resultados na interface
            // (implementação depende da integração com UI)
          });
      });
  }

  handleReverseRouteCommand() {
    console.log('Invertendo rota atual');
    
    // Verificar se há uma rota ativa
    const currentRoute = this.navigationService.getCurrentRoute();
    if (!currentRoute) {
      // Feedback ao usuário: nenhuma rota ativa
      return;
    }
    
    // Inverter origem e destino
    this.navigationService.createReversedRoute(currentRoute)
      .then(newRoute => {
        // Ativar nova rota
        this.navigationService.startNavigation(newRoute);
      });
  }

  handleSwitchToChatCommand() {
    console.log('Mudando para o KingChat');
    
    // Evento para a aplicação mudar para a tela de chat
    // (implementação depende da integração com o sistema de navegação da aplicação)
    const event = new CustomEvent('switchToKingChat');
    document.dispatchEvent(event);
  }

  handleQRACommand() {
    console.log('Respondendo QRA');
    
    // QRA é o "nome" do sistema para os caminhoneiros
    const response = "Meu QRA é King Road, estou aqui para te ajudar nas estradas!";
    
    // Usar TTS para responder (se disponível)
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(response);
      utterance.lang = this.translations.getCurrentLanguage() || 'pt-BR';
      window.speechSynthesis.speak(utterance);
    }
    
    // Também mostrar na interface (implementação depende da UI)
  }

  handleUnknownCommand(transcript) {
    console.log(`Comando não reconhecido: ${transcript}`);
    
    // Feedback ao usuário sobre comando não reconhecido
    const response = "Desculpe, não reconheci esse comando. Pode tentar novamente?";
    
    // Usar TTS para responder (se disponível)
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(response);
      utterance.lang = this.translations.getCurrentLanguage() || 'pt-BR';
      window.speechSynthesis.speak(utterance);
    }
    
    // Também mostrar na interface (implementação depende da UI)
  }
}

export { VoiceCommandService };