// web/src/utils/themeManager.js

import { useState, useEffect } from 'react';

/**
 * Gerenciador de temas para o aplicativo KingRoad
 * Controla os temas diurno e noturno e ajusta configurações com base no tamanho da tela
 */

// Definição dos temas
export const themes = {
  // Tema diurno - bege e café (baseado na imagem)
  day: {
    name: 'day',
    title: 'Modo Diurno',
    colors: {
      bege: {
        claro: '#F5EEE0',    // Bege claro para fundo do mapa
        medio: '#E8DCC9',    // Bege médio para elementos secundários
        escuro: '#D0C0A6'    // Bege escuro para bordas e detalhes
      },
      cafe: {
        claro: '#9C8369',    // Café claro para botões e elementos interativos
        medio: '#6E5C4A',    // Café médio para textos e ícones
        escuro: '#3F3329'    // Café escuro para barras e elementos de destaque
      },
      agua: '#B5D6D6',       // Cor para água no mapa
      estrada: {
        principal: '#3A3330', // Estradas principais
        secundaria: '#5D4B3E' // Estradas secundárias
      },
      marcadores: {
        destacado: '#E8A87C', // Cor para marcadores destacados
        padrao: '#9C8369'     // Cor padrão para marcadores
      },
      texto: {
        claro: '#F5EEE0',    // Texto claro para fundos escuros
        escuro: '#3F3329'    // Texto escuro para fundos claros
      },
      interface: {
        botao: '#6E5C4A',    // Cor para botões
        botaoAtivo: '#3F3329', // Cor para botões ativos
        borda: '#9C8369',    // Cor para bordas
        destaque: '#E8A87C'  // Cor para elementos em destaque
      }
    },
    mapStyle: {
      terreno: '#F5EEE0',
      agua: '#B5D6D6',
      vegetacao: '#C1CDAA',
      construcoes: '#D5C5B5',
      administrativo: '#E8DCC9',
      textoPrincipal: '#3F3329',
      textoSecundario: '#6E5C4A'
    }
  },
  
  // Tema noturno - preto com detalhes dourados (conforme especificação técnica)
  night: {
    name: 'night',
    title: 'Modo Noturno',
    colors: {
      preto: {
        claro: '#2A2A2A',    // Preto claro para elementos secundários
        medio: '#1A1A1A',    // Preto médio para fundo
        escuro: '#000000'    // Preto escuro para elementos em destaque
      },
      dourado: {
        claro: '#FFD700',    // Dourado claro para destaques
        medio: '#DAA520',    // Dourado médio para elementos principais
        escuro: '#B8860B'    // Dourado escuro para detalhes
      },
      agua: '#103754',       // Azul escuro para água no mapa
      estrada: {
        principal: '#444444', // Estradas principais
        secundaria: '#333333' // Estradas secundárias
      },
      marcadores: {
        destacado: '#FFD700', // Marcadores em destaque
        padrao: '#DAA520'     // Marcadores padrão
      },
      texto: {
        claro: '#FFFFFF',    // Texto claro
        escuro: '#CCCCCC'    // Texto secundário
      },
      interface: {
        botao: '#2A2A2A',    // Cor para botões
        botaoAtivo: '#000000', // Cor para botões ativos
        borda: '#DAA520',    // Cor para bordas
        destaque: '#FFD700'  // Cor para elementos em destaque
      }
    },
    mapStyle: {
      terreno: '#1A1A1A',
      agua: '#103754',
      vegetacao: '#1D2A1D',
      construcoes: '#2A2A2A',
      administrativo: '#333333',
      textoPrincipal: '#DAA520',
      textoSecundario: '#A8A8A8'
    }
  }
};

/**
 * Configurações de tamanho para diferentes dispositivos
 */
export const sizesConfig = {
  phone: {
    minWidth: 0,
    maxWidth: 599,
    defaultOrientation: 'portrait',
    iconSizes: {
      small: 16,
      medium: 24,
      large: 32
    },
    fontSizes: {
      small: 12,
      medium: 14,
      large: 18,
      xlarge: 24
    },
    spacing: {
      small: 4,
      medium: 8,
      large: 16
    }
  },
  smallTablet: {
    minWidth: 600,
    maxWidth: 839,
    defaultOrientation: 'portrait',
    iconSizes: {
      small: 20,
      medium: 28,
      large: 36
    },
    fontSizes: {
      small: 14,
      medium: 16,
      large: 20,
      xlarge: 28
    },
    spacing: {
      small: 6,
      medium: 12,
      large: 20
    }
  },
  largeTablet: {
    minWidth: 840,
    maxWidth: Infinity,
    defaultOrientation: 'landscape', // Força orientação horizontal
    iconSizes: {
      small: 24,
      medium: 32,
      large: 44
    },
    fontSizes: {
      small: 16,
      medium: 20,
      large: 24,
      xlarge: 32
    },
    spacing: {
      small: 8,
      medium: 16,
      large: 24
    }
  }
};

/**
 * Determina a categoria de dispositivo com base na largura da tela
 * @param {number} width - Largura da tela em pixels
 * @returns {string} - Categoria do dispositivo ('phone', 'smallTablet', 'largeTablet')
 */
export const getDeviceCategory = (width) => {
  if (width < sizesConfig.smallTablet.minWidth) return 'phone';
  if (width < sizesConfig.largeTablet.minWidth) return 'smallTablet';
  return 'largeTablet';
};

/**
 * Verifica se a orientação do dispositivo é correta com base na categoria
 * @param {string} category - Categoria do dispositivo
 * @param {number} width - Largura atual da tela
 * @param {number} height - Altura atual da tela
 * @returns {boolean} - Verdadeiro se a orientação está correta
 */
export const isCorrectOrientation = (category, width, height) => {
  const isLandscape = width > height;
  
  if (category === 'largeTablet') {
    return isLandscape; // Tablets grandes devem SEMPRE estar em modo paisagem
  }
  
  return true; // Outros dispositivos podem ter qualquer orientação
};

/**
 * Aplica o tema ao documento
 * @param {string} themeName - Nome do tema ('day' ou 'night')
 */
export const applyTheme = (themeName) => {
  const theme = themes[themeName] || themes.day;
  
  // Aplicar variáveis CSS para o tema
  const root = document.documentElement;
  
  // Cores de fundo
  root.style.setProperty('--background', themeName === 'day' ? theme.colors.bege.claro : theme.colors.preto.medio);
  root.style.setProperty('--background-secondary', themeName === 'day' ? theme.colors.bege.medio : theme.colors.preto.claro);
  
  // Cores de texto
  root.style.setProperty('--text-primary', themeName === 'day' ? theme.colors.cafe.escuro : theme.colors.texto.claro);
  root.style.setProperty('--text-secondary', themeName === 'day' ? theme.colors.cafe.medio : theme.colors.texto.escuro);
  
  // Cores de destaque
  root.style.setProperty('--accent', themeName === 'day' ? theme.colors.cafe.claro : theme.colors.dourado.medio);
  root.style.setProperty('--accent-highlight', themeName === 'day' ? theme.colors.cafe.medio : theme.colors.dourado.claro);
  
  // Cores de interface
  root.style.setProperty('--button', themeName === 'day' ? theme.colors.interface.botao : theme.colors.interface.botao);
  root.style.setProperty('--button-active', themeName === 'day' ? theme.colors.interface.botaoAtivo : theme.colors.interface.botaoAtivo);
  root.style.setProperty('--border', themeName === 'day' ? theme.colors.interface.borda : theme.colors.interface.borda);
  
  // Cores de mapa
  root.style.setProperty('--water', theme.colors.agua);
  root.style.setProperty('--road-primary', theme.colors.estrada.principal);
  root.style.setProperty('--road-secondary', theme.colors.estrada.secundaria);
};

/**
 * Hook personalizado para gerenciar temas
 * @param {string} initialTheme - Tema inicial ('day' ou 'night')
 * @returns {Object} - Objeto com tema atual e funções para alterá-lo
 */
export const useTheme = (initialTheme = 'day') => {
  const [currentTheme, setCurrentTheme] = useState(initialTheme);
  
  useEffect(() => {
    applyTheme(currentTheme);
  }, [currentTheme]);
  
  const toggleTheme = () => {
    setCurrentTheme(prev => prev === 'day' ? 'night' : 'day');
  };
  
  return {
    currentTheme,
    setTheme: setCurrentTheme,
    toggleTheme,
    themeData: themes[currentTheme]
  };
};