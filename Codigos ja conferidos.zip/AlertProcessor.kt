class AlertProcessor {
    private val database: UserDatabase // Assumindo uma classe de banco de dados
    private val messagingService: FirebaseMessaging

    constructor(database: UserDatabase, messagingService: FirebaseMessaging) {
        this.database = database
        this.messagingService = messagingService
    }

    fun processAlert(alert: Map<String, Any>) {
        val location = alert["location"] as Location
        val nearbyUsers = getNearbyUsers(location, DEFAULT_RADIUS)
        
        nearbyUsers.forEach { user ->
            sendNotification(user, alert)
        }
    }
    
    private fun getUserLocation(userId: String): Location {
        return database.getUserCurrentLocation(userId)
    }
    
    private fun getNearbyUsers(location: Location, radius: Int): List<User> {
        return database.findUsersNearLocation(location, radius)
    }
    
    private fun sendNotification(user: User, alert: Map<String, Any>) {
        val message = RemoteMessage.Builder(user.fcmToken)
            .setMessageId(alert["id"].toString())
            .setData(alert)
            .build()
            
        messagingService.send(message)
    }

    companion object {
        private const val DEFAULT_RADIUS = 10 // km
    }
}