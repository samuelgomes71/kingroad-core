package com.kingroad.poi

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.AppDatabase
import com.kingroad.utils.LocationUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Gerenciador de POIs para lavagens de veículos
 * Responsável por buscar, filtrar e gerenciar POIs de lavagem de caminhões e carros
 */
class TruckWasherPoiManager(private val context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val poiDao = database.truckWasherPoiDao()
    private val reviewDao = database.truckWasherReviewDao()
    
    private val coroutineScope = CoroutineScope(Job() + Dispatchers.Main)
    
    // Armazenamento em cache para POIs próximos
    private val nearbyPoiCache = MutableLiveData<List<TruckWasherPoi>>()
    private var lastQueryLocation: Pair<Double, Double>? = null
    private var lastQueryTime: Long = 0
    private var lastQueryVehicleMode: String = "truck"
    
    // Período para considerar o cache válido (10 minutos)
    private val cacheValidityPeriodMs = TimeUnit.MINUTES.toMillis(10)
    
    /**
     * Busca lavagens próximas com vários critérios de filtro
     * 
     * @param latitude Latitude atual do usuário
     * @param longitude Longitude atual do usuário
     * @param maxDistance Distância máxima de busca em km
     * @param vehicleMode Modo de veículo (truck, car)
     * @param washerTypes Tipos de lavagem a filtrar
     * @param truckTypes Tipos de caminhões suportados a filtrar
     * @param minRating Avaliação mínima
     * @param maxWaitTime Tempo máximo de espera em minutos
     * @param priceRange Faixa de preço para filtrar
     * @param open Buscar apenas locais abertos
     * @param forceRefresh Ignorar o cache e forçar atualização
     * @return LiveData com lista de POIs
     */
    fun findNearbyWashers(
        latitude: Double,
        longitude: Double,
        maxDistance: Double = 50.0,
        vehicleMode: String = "truck",
        washerTypes: List<WasherType>? = null,
        truckTypes: List<TruckType>? = null,
        minRating: Float = 0.0f,
        maxWaitTime: Int = Int.MAX_VALUE,
        priceRange: Pair<Float, Float>? = null,
        open: Boolean = false,
        forceRefresh: Boolean = false
    ): LiveData<List<TruckWasherPoi>> {
        // Verifica se podemos usar o cache
        val currentLocation = Pair(latitude, longitude)
        val currentTime = System.currentTimeMillis()
        val useCache = !forceRefresh && 
                      lastQueryLocation != null && 
                      LocationUtils.calculateDistance(
                          lastQueryLocation!!.first, lastQueryLocation!!.second, 
                          latitude, longitude
                      ) < 1.0 && // Menos de 1km de diferença
                      (currentTime - lastQueryTime) < cacheValidityPeriodMs && // Cache válido
                      lastQueryVehicleMode == vehicleMode // Mesmo modo de veículo
        
        if (useCache) {
            return nearbyPoiCache
        }
        
        // Atualiza informações de cache
        lastQueryLocation = currentLocation
        lastQueryTime = currentTime
        lastQueryVehicleMode = vehicleMode
        
        // Realiza a busca no banco de dados em background
        coroutineScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    // Busca todos os POIs do tipo correto no banco
                    var pois = poiDao.findByVehicleMode(vehicleMode)
                    
                    // Filtra por distância
                    pois = pois.filter { poi ->
                        val distance = LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                        distance <= maxDistance
                    }
                    
                    // Aplica os demais filtros
                    if (washerTypes != null && washerTypes.isNotEmpty()) {
                        pois = pois.filter { poi -> 
                            washerTypes.any { it in poi.washerTypes } 
                        }
                    }
                    
                    if (vehicleMode == "truck" && truckTypes != null && truckTypes.isNotEmpty()) {
                        pois = pois.filter { poi -> 
                            truckTypes.any { it in poi.truckTypes } 
                        }
                    }
                    
                    if (minRating > 0.0f) {
                        pois = pois.filter { poi -> poi.rating >= minRating }
                    }
                    
                    if (open) {
                        pois = pois.filter { poi -> poi.status == WasherStatus.OPEN }
                    }
                    
                    if (maxWaitTime < Int.MAX_VALUE) {
                        pois = pois.filter { poi -> 
                            poi.waitTimes.currentWaitTime <= maxWaitTime 
                        }
                    }
                    
                    if (priceRange != null) {
                        pois = pois.filter { poi -> 
                            poi.prices.basicWash in priceRange.first..priceRange.second
                        }
                    }
                    
                    // Adiciona a distância atual para cada POI
                    pois.forEach { poi ->
                        val distance = LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                        // Em uma implementação real, poderíamos adicionar esse valor em um campo temporário
                        // Para o mock, vamos apenas ordenar por distância
                    }
                    
                    // Ordena por distância (simulado aqui)
                    pois.sortedBy { poi ->
                        LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                    }
                }
                
                // Atualiza o cache com os resultados
                nearbyPoiCache.value = result
                
            } catch (e: Exception) {
                // Em caso de erro, limpa o cache para forçar nova tentativa na próxima consulta
                nearbyPoiCache.value = emptyList()
                lastQueryTime = 0
            }
        }
        
        return nearbyPoiCache
    }
    
    /**
     * Busca lavagens que suportam caminhões de grande porte
     * 
     * @param latitude Latitude atual do usuário
     * @param longitude Longitude atual do usuário
     * @param maxDistance Distância máxima em km
     * @return LiveData com lista de POIs
     */
    fun findWashersForLargeTrucks(
        latitude: Double,
        longitude: Double,
        maxDistance: Double = 100.0
    ): LiveData<List<TruckWasherPoi>> {
        val result = MutableLiveData<List<TruckWasherPoi>>()
        
        coroutineScope.launch {
            try {
                val largeTruckPois = withContext(Dispatchers.IO) {
                    // Busca POIs que suportam caminhões grandes
                    val largeTruckTypes = listOf(
                        TruckType.FULL_TRAILER,
                        TruckType.DOUBLE_TRAILER,
                        TruckType.TRIPLE_TRAILER
                    )
                    
                    // Busca todos os POIs do tipo caminhão no banco
                    var pois = poiDao.findByVehicleMode("truck")
                    
                    // Filtra apenas os que suportam caminhões grandes
                    pois = pois.filter { poi ->
                        poi.truckTypes.any { it in largeTruckTypes }
                    }
                    
                    // Filtra por distância
                    pois = pois.filter { poi ->
                        val distance = LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                        distance <= maxDistance
                    }
                    
                    // Verifica dimensões máximas (assume que grandes caminhões têm mais de 4m altura)
                    pois = pois.filter { poi ->
                        poi.maxHeight >= 4.0f && poi.maxLength >= 20.0f
                    }
                    
                    // Ordena por distância
                    pois.sortedBy { poi ->
                        LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                    }
                }
                
                result.value = largeTruckPois
            } catch (e: Exception) {
                result.value = emptyList()
            }
        }
        
        return result
    }
 /**
     * Busca lavagens ecológicas (com reciclagem de água)
     * 
     * @param latitude Latitude atual do usuário
     * @param longitude Longitude atual do usuário
     * @param maxDistance Distância máxima em km
     * @param vehicleMode Modo de veículo (truck, car)
     * @return LiveData com lista de POIs
     */
    fun findEcoFriendlyWashers(
        latitude: Double,
        longitude: Double,
        maxDistance: Double = 50.0,
        vehicleMode: String = "truck"
    ): LiveData<List<TruckWasherPoi>> {
        val result = MutableLiveData<List<TruckWasherPoi>>()
        
        coroutineScope.launch {
            try {
                val ecoFriendlyPois = withContext(Dispatchers.IO) {
                    // Busca todos os POIs do tipo correto no banco
                    var pois = poiDao.findByVehicleMode(vehicleMode)
                    
                    // Filtra por ecológicos
                    pois = pois.filter { poi ->
                        poi.hasWaterRecycling || 
                        poi.usesEcoProducts || 
                        WasherType.ECO_FRIENDLY in poi.washerTypes
                    }
                    
                    // Filtra por distância
                    pois = pois.filter { poi ->
                        val distance = LocationUtils.calculateDistance(
                            latitude, longitude, poi.latitude, poi.longitude
                        )
                        distance <= maxDistance
                    }
                    
                    // Ordena os resultados (prioriza reciclagem de água)
                    pois.sortedWith(compareBy(
                        { !it.hasWaterRecycling }, // False vem primeiro (tem reciclagem = prioridade)
                        { !it.usesEcoProducts },   // False vem primeiro (usa produtos eco = prioridade)
                        { // Distância como terceiro critério
                            LocationUtils.calculateDistance(
                                latitude, longitude, it.latitude, it.longitude
                            )
                        }
                    ))
                }
                
                result.value = ecoFriendlyPois
            } catch (e: Exception) {
                result.value = emptyList()
            }
        }
        
        return result
    }
    
    /**
     * Permite usuários reportarem informações sobre o POI
     * 
     * @param poiId ID do POI
     * @param status Novo status reportado
     * @param waitTime Novo tempo de espera reportado
     * @param isClosed Informação se está fechado
     * @param userId ID do usuário que está reportando
     * @return True se o report foi aceito
     */
    fun reportPoiStatus(
        poiId: String,
        status: WasherStatus? = null,
        waitTime: Int? = null,
        isClosed: Boolean? = null,
        userId: String
    ): Boolean {
        var success = false
        
        coroutineScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // Busca o POI atual
                    val poi = poiDao.findById(poiId) ?: return@withContext
                    
                    // Atualiza informações reportadas
                    var updated = false
                    
                    if (status != null && status != poi.status) {
                        // Em uma implementação real, teríamos validação adicional
                        // e possivelmente um sistema de votação para mudanças de status
                        
                        // Para o mock, simplesmente atualizamos se o usuário já reportou
                        // algo anteriormente (considerado mais confiável)
                        val userReportCount = reviewDao.getReviewCountByUser(userId)
                        if (userReportCount > 0) {
                            // Usuário tem histórico, aceitamos o report
                            updated = true
                        }
                    }
                    
                    if (waitTime != null && waitTime != poi.waitTimes.currentWaitTime) {
                        // Atualiza o tempo de espera com uma média ponderada
                        // Damos mais peso ao valor atual para evitar manipulações
                        val newWaitTime = (poi.waitTimes.currentWaitTime * 2 + waitTime) / 3
                        
                        val updatedWaitTimes = poi.waitTimes.copy(
                            currentWaitTime = newWaitTime,
                            lastUpdated = System.currentTimeMillis()
                        )
                        
                        // TODO: Em uma implementação real, usaríamos Room para atualizar
                        // apenas o campo waitTimes do POI
                        updated = true
                    }
                    
                    if (isClosed != null && isClosed && poi.status != WasherStatus.CLOSED) {
                        // Reportes de fechamento são importantes e geralmente verdadeiros
                        // Atualizamos para "temporariamente fechado" até verificação
                        
                        // TODO: Em uma implementação real, enviaríamos para um sistema de
                        // verificação e possivelmente notificaríamos administradores
                        updated = true
                    }
                    
                    // Se houve atualização, salvamos o POI
                    if (updated) {
                        // TODO: Salvar as alterações no banco
                        // poiDao.update(poi)
                        success = true
                    }
                }
            } catch (e: Exception) {
                success = false
            }
        }
        
        return success
    }
 /**
     * Adiciona sugestões de novos POIs
     * 
     * @param name Nome do estabelecimento
     * @param latitude Latitude da localização
     * @param longitude Longitude da localização
     * @param address Endereço completo
     * @param vehicleMode Modo de veículo (truck, car)
     * @param washerTypes Tipos de lavagem disponíveis
     * @param userId ID do usuário que está sugerindo
     * @return ID do POI criado, ou null em caso de erro
     */
    fun suggestNewWasherPoi(
        name: String,
        latitude: Double,
        longitude: Double,
        address: String,
        vehicleMode: String,
        washerTypes: List<WasherType>,
        userId: String
    ): String? {
        var newPoiId: String? = null
        
        coroutineScope.launch {
            try {
                val id = withContext(Dispatchers.IO) {
                    // Extrair informações do endereço
                    // Em uma implementação real, usaríamos uma API de geocodificação reversa
                    val addressParts = address.split(",")
                    val street = if (addressParts.isNotEmpty()) addressParts[0].trim() else ""
                    val city = if (addressParts.size > 1) addressParts[1].trim() else ""
                    val stateZip = if (addressParts.size > 2) addressParts[2].trim() else ""
                    
                    val stateParts = stateZip.split(" ")
                    val state = if (stateParts.isNotEmpty()) stateParts[0].trim() else ""
                    val postalCode = if (stateParts.size > 1) stateParts[1].trim() else ""
                    
                    val country = if (addressParts.size > 3) addressParts[3].trim() else "Brazil"
                    
                    // Criar o novo POI com as informações sugeridas
                    val newPoi = TruckWasherPoi(
                        name = name,
                        latitude = latitude,
                        longitude = longitude,
                        address = street,
                        city = city,
                        state = state,
                        country = country,
                        postalCode = postalCode,
                        washerTypes = washerTypes,
                        vehicleMode = vehicleMode,
                        userReported = true,
                        verified = false,
                        status = WasherStatus.OPEN
                    )
                    
                    // Em uma implementação real, marcaríamos como "não verificado"
                    // e enviaríamos para um processo de moderação/verificação
                    
                    // Salvar no banco
                    poiDao.insert(newPoi)
                    
                    // Adicionar uma "nota" ao usuário por sua contribuição
                    // Em uma implementação real, teríamos um sistema de reputação
                    
                    newPoi.id
                }
                
                newPoiId = id
            } catch (e: Exception) {
                newPoiId = null
            }
        }
        
        return newPoiId
    }
    
    /**
     * Obtém detalhes completos de um POI específico
     * 
     * @param poiId ID do POI
     * @return LiveData com o POI ou null se não encontrado
     */
    fun getPoiDetails(poiId: String): LiveData<TruckWasherPoi?> {
        val result = MutableLiveData<TruckWasherPoi?>()
        
        coroutineScope.launch {
            try {
                val poi = withContext(Dispatchers.IO) {
                    // Incrementa o contador de visualizações
                    poiDao.incrementViewCount(poiId)
                    
                    // Busca o POI
                    poiDao.findById(poiId)
                }
                
                result.value = poi
            } catch (e: Exception) {
                result.value = null
            }
        }
        
        return result
    }
    
    /**
     * Obtém as avaliações de um POI específico
     * 
     * @param poiId ID do POI
     * @param limit Número máximo de avaliações (0 = sem limite)
     * @param offset Deslocamento para paginação
     * @return LiveData com lista de avaliações
     */
    fun getPoiReviews(
        poiId: String,
        limit: Int = 0,
        offset: Int = 0
    ): LiveData<List<TruckWasherReview>> {
        val result = MutableLiveData<List<TruckWasherReview>>()
        
        coroutineScope.launch {
            try {
                val reviews = withContext(Dispatchers.IO) {
                    if (limit > 0) {
                        reviewDao.findByPoiIdPaginated(poiId, limit, offset)
                    } else {
                        reviewDao.findByPoiId(poiId)
                    }
                }
                
                result.value = reviews
            } catch (e: Exception) {
                result.value = emptyList()
            }
        }
        
        return result
    }
/**
     * Adiciona ou atualiza uma avaliação para um POI
     * 
     * @param poiId ID do POI
     * @param userId ID do usuário
     * @param userName Nome do usuário
     * @param rating Avaliação (0-5)
     * @param comment Comentário
     * @param vehicleType Tipo de veículo do usuário
     * @return ID da avaliação criada ou atualizada, ou null em caso de erro
     */
    fun addOrUpdateReview(
        poiId: String,
        userId: String,
        userName: String,
        rating: Float,
        comment: String,
        vehicleType: String
    ): String? {
        var reviewId: String? = null
        
        coroutineScope.launch {
            try {
                val id = withContext(Dispatchers.IO) {
                    // Verifica se o usuário já avaliou este POI
                    val existingReview = reviewDao.findByPoiIdAndUserId(poiId, userId)
                    
                    if (existingReview != null) {
                        // Atualiza a avaliação existente
                        val updatedReview = existingReview.copy(
                            rating = rating,
                            comment = comment,
                            vehicleType = vehicleType,
                            date = System.currentTimeMillis()
                        )
                        
                        reviewDao.update(updatedReview)
                        updatedReview.id
                    } else {
                        // Cria uma nova avaliação
                        val newReview = TruckWasherReview(
                            poiId = poiId,
                            userId = userId,
                            userName = userName,
                            rating = rating,
                            comment = comment,
                            vehicleType = vehicleType
                        )
                        
                        reviewDao.insert(newReview)
                        
                        // Atualiza a média de avaliações do POI
                        updatePoiRating(poiId)
                        
                        newReview.id
                    }
                }
                
                reviewId = id
            } catch (e: Exception) {
                reviewId = null
            }
        }
        
        return reviewId
    }
    
    /**
     * Atualiza a classificação média de um POI com base em todas as avaliações
     * 
     * @param poiId ID do POI
     */
    private suspend fun updatePoiRating(poiId: String) {
        withContext(Dispatchers.IO) {
            try {
                // Busca todas as avaliações para este POI
                val reviews = reviewDao.findByPoiId(poiId)
                
                if (reviews.isNotEmpty()) {
                    // Calcula a nova média
                    val averageRating = reviews.map { it.rating }.average().toFloat()
                    
                    // Atualiza o POI
                    poiDao.updateRating(poiId, averageRating, reviews.size)
                }
            } catch (e: Exception) {
                // Ignora erros aqui
            }
        }
    }
    
    /**
     * Adiciona ou remove um POI dos favoritos
     * 
     * @param poiId ID do POI
     * @param userId ID do usuário
     * @param favorite True para adicionar, False para remover
     * @return True se a operação foi bem-sucedida
     */
    fun toggleFavoritePoi(
        poiId: String,
        userId: String,
        favorite: Boolean
    ): Boolean {
        var success = false
        
        coroutineScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // Em uma implementação real, teríamos uma tabela de favoritos
                    // Aqui apenas simulamos o incremento/decremento do contador
                    
                    if (favorite) {
                        poiDao.incrementFavoriteCount(poiId)
                    } else {
                        poiDao.decrementFavoriteCount(poiId)
                    }
                    
                    success = true
                }
            } catch (e: Exception) {
                success = false
            }
        }
        
        return success
    }
}