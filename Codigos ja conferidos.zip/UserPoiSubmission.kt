package com.kingroad.poi

import com.kingroad.common.Location
import com.kingroad.database.PoiDatabase
import com.kingroad.database.UserSubmissionQueue
import com.kingroad.network.NetworkManager
import com.kingroad.utils.GeoUtils
import com.kingroad.utils.ValidationUtils
import com.kingroad.utils.FileUtils
import java.util.UUID

/**
 * Sistema de submissão de POIs pelo usuário para o KingRoad
 * Permite que motoristas adicionem novos locais que não estão no sistema
 */

// Enum para tipos de submissão de POI
enum class UserPoiType {
    DOCUMENT_SERVICE,  // Serviços de impressão/documentos
    CERTIFIED_SCALE,   // Balança certificada
    FUEL_STATION,      // Posto de combustível
    REPAIR_SHOP,       // Oficina mecânica
    RESTAURANT,        // Restaurante/Lanchonete
    REST_AREA,         // Área de descanso
    TRUCK_PARKING,     // Estacionamento para caminhões
    CARGO_FACILITY,    // Instalação de carga/descarga
    OTHER              // Outro tipo de POI
}

// Status de validação da submissão
enum class SubmissionStatus {
    PENDING,           // Aguardando revisão
    APPROVED,          // Aprovado e adicionado ao banco de dados principal
    REJECTED,          // Rejeitado
    NEEDS_VERIFICATION // Precisa de verificação adicional
}

// Classe para submissão de POI pelo usuário
data class UserSubmittedPoi(
    val id: String = UUID.randomUUID().toString(),
    val type: UserPoiType,
    val name: String,
    val location: Location,
    val address: String,
    val description: String = "",
    val contactPhone: String? = null,
    val website: String? = null,
    val submittedByUserId: String,
    val submissionDate: Long = System.currentTimeMillis(),
    val photoPaths: List<String> = emptyList(),
    val additionalInfo: Map<String, String> = emptyMap(),
    val status: SubmissionStatus = SubmissionStatus.PENDING,
    val verificationCount: Int = 0, // Número de outros usuários que verificaram este POI
    val countryCode: String,
    val regionCode: String
)

// Extensões específicas para cada tipo de POI
data class DocumentServiceSubmission(
    val userPoi: UserSubmittedPoi,
    val availableServices: List<DocumentServices>,
    val operatingHours: String? = null,
    val servicePrice: Map<DocumentServices, Double> = emptyMap()
)

data class CertifiedScaleSubmission(
    val userPoi: UserSubmittedPoi,
    val scaleType: ScaleType,
    val scaleOperationHours: String? = null,
    val scalePrice: Double? = null,
    val paymentMethods: List<String> = emptyList(),
    val maxWeight: Int? = null,
    val isOpen24h: Boolean = false,
    val requiresAppointment: Boolean = false,
    val providesOfficialCertificate: Boolean = true
)

// Gerenciador de submissões de POIs pelo usuário
class UserPoiSubmissionManager(
    private val database: PoiDatabase,
    private val submissionQueue: UserSubmissionQueue,
    private val networkManager: NetworkManager
) {
    
    // Submete um novo POI de serviço de documentos
    fun submitDocumentServicePoi(submission: DocumentServiceSubmission): String {
        // Valida a submissão
        validateSubmission(submission.userPoi)
        
        // Adiciona à fila de submissões
        submissionQueue.addDocumentServiceSubmission(submission)
        
        // Tenta enviar para o servidor se estiver online
        if (networkManager.isOnline()) {
            uploadSubmissionToServer(submission.userPoi.id)
        }
        
        return submission.userPoi.id
    }
    
    // Submete um novo POI de balança certificada
    fun submitCertifiedScalePoi(submission: CertifiedScaleSubmission): String {
        // Valida a submissão
        validateSubmission(submission.userPoi)
        
        // Adiciona à fila de submissões
        submissionQueue.addCertifiedScaleSubmission(submission)
        
        // Tenta enviar para o servidor se estiver online
        if (networkManager.isOnline()) {
            uploadSubmissionToServer(submission.userPoi.id)
        }
        
        return submission.userPoi.id
    }
    
    // Submete um novo POI genérico
    fun submitGenericPoi(poi: UserSubmittedPoi): String {
        // Valida a submissão
        validateSubmission(poi)
        
        // Adiciona à fila de submissões
        submissionQueue.addGenericPoiSubmission(poi)
        
        // Tenta enviar para o servidor se estiver online
        if (networkManager.isOnline()) {
            uploadSubmissionToServer(poi.id)
        }
        
        return poi.id
    }
    
    // Anexa foto a uma submissão existente
    fun attachPhotoToSubmission(submissionId: String, photoPath: String): Boolean {
        val submission = submissionQueue.getSubmission(submissionId) ?: return false
        
        return try {
            // Copia a foto para o diretório de armazenamento permanente
            val permanentPath = FileUtils.copyImageToPermanentStorage(photoPath, "user_pois/$submissionId/")
            
            // Atualiza a submissão com o novo caminho da foto
            submissionQueue.updateSubmissionPhotos(submissionId, permanentPath)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    // Verifica outro POI adicionado por usuário (confirma que ele existe)
    fun verifyUserSubmittedPoi(submissionId: String, userId: String, comment: String? = null): Boolean {
        return submissionQueue.addVerification(submissionId, userId, comment)
    }
    
    // Obtém submissões pendentes próximas para potencial verificação
    fun getNearbyPendingSubmissions(location: Location, radiusKm: Double): List<UserSubmittedPoi> {
        return submissionQueue.getPendingSubmissionsNearby(location, radiusKm)
    }
    
    // Verifica status de uma submissão
    fun checkSubmissionStatus(submissionId: String): SubmissionStatus? {
        return submissionQueue.getSubmissionStatus(submissionId)
    }
    
    // Obtém submissões feitas pelo usuário atual
    fun getUserSubmissions(userId: String): List<UserSubmittedPoi> {
        return submissionQueue.getSubmissionsByUser(userId)
    }
    
    // Métodos privados de suporte
    
    private fun validateSubmission(poi: UserSubmittedPoi) {
        // Verifica nome
        require(poi.name.isNotBlank()) { "Nome do POI não pode estar vazio" }
        
        // Verifica coordenadas
        require(ValidationUtils.isValidLatitude(poi.location.latitude)) { "Latitude inválida" }
        require(ValidationUtils.isValidLongitude(poi.location.longitude)) { "Longitude inválida" }
        
        // Verifica endereço
        require(poi.address.isNotBlank()) { "Endereço não pode estar vazio" }
        
        // Verifica telefone (se fornecido)
        poi.contactPhone?.let {
            require(ValidationUtils.isValidPhoneNumber(it)) { "Número de telefone inválido" }
        }
        
        // Verifica website (se fornecido)
        poi.website?.let {
            require(ValidationUtils.isValidUrl(it)) { "URL do website inválida" }
        }
    }
    
    private fun uploadSubmissionToServer(submissionId: String) {
        // Implementação da lógica de upload para o servidor
        // Seria implementado com base no sistema de sincronização do KingRoad
    }
}

// Frontend: UI para submissão de POIs pelo usuário
class UserPoiSubmissionController(
    private val submissionManager: UserPoiSubmissionManager,
    private val locationManager: LocationManager,
    private val userManager: UserManager,
    private val cameraController: CameraController
) {
    
    // Inicia uma nova submissão de POI usando a localização atual
    fun startNewSubmission(type: UserPoiType, name: String): String? {
        // Obter localização atual
        val currentLocation = locationManager.getCurrentLocation() ?: return null
        
        // Obter ID do usuário atual
        val userId = userManager.getCurrentUserId()
        
        // Obter país e região com base na localização
        val geocodeResult = GeoUtils.reverseGeocode(currentLocation)
        
        // Criar submissão básica
        val poi = UserSubmittedPoi(
            type = type,
            name = name,
            location = currentLocation,
            address = geocodeResult.formattedAddress ?: "",
            submittedByUserId = userId,
            countryCode = geocodeResult.countryCode ?: "XX",
            regionCode = geocodeResult.regionCode ?: "XX"
        )
        
        // Submeter POI genérico
        return submissionManager.submitGenericPoi(poi)
    }
    
    // Completa a submissão de um POI de serviço de documentos
    fun completeDocumentServiceSubmission(
        submissionId: String,
        address: String,
        description: String,
        phone: String?,
        services: List<DocumentServices>,
        operatingHours: String?
    ): Boolean {
        // Obter submissão existente
        val existingSubmission = submissionManager.getUserSubmissions(userManager.getCurrentUserId())
            .find { it.id == submissionId } ?: return false
        
        // Atualizar com informações específicas
        val updatedPoi = existingSubmission.copy(
            address = address,
            description = description,
            contactPhone = phone
        )
        
        // Criar submissão específica para serviço de documentos
        val documentSubmission = DocumentServiceSubmission(
            userPoi = updatedPoi,
            availableServices = services,
            operatingHours = operatingHours
        )
        
        // Submeter POI específico
        submissionManager.submitDocumentServicePoi(documentSubmission)
        return true
    }
    
    // Completa a submissão de um POI de balança certificada
    fun completeCertifiedScaleSubmission(
        submissionId: String,
        address: String,
        description: String,
        phone: String?,
        scaleType: ScaleType,
        operatingHours: String?,
        price: Double?,
        maxWeight: Int?,
        isOpen24h: Boolean,
        providesOfficialCertificate: Boolean
    ): Boolean {
        // Obter submissão existente
        val existingSubmission = submissionManager.getUserSubmissions(userManager.getCurrentUserId())
            .find { it.id == submissionId } ?: return false
        
        // Atualizar com informações específicas
        val updatedPoi = existingSubmission.copy(
            address = address,
            description = description,
            contactPhone = phone
        )
        
        // Criar submissão específica para balança certificada
        val scaleSubmission = CertifiedScaleSubmission(
            userPoi = updatedPoi,
            scaleType = scaleType,
            scaleOperationHours = operatingHours,
            scalePrice = price,
            maxWeight = maxWeight,
            isOpen24h = isOpen24h,
            providesOfficialCertificate = providesOfficialCertificate
        )
        
        // Submeter POI específico
        submissionManager.submitCertifiedScalePoi(scaleSubmission)
        return true
    }
    
    // Tira uma foto para anexar à submissão
    fun takePhotoForSubmission(submissionId: String, onPhotoTaken: (Boolean) -> Unit) {
        cameraController.takePicture { photoPath ->
            if (photoPath != null) {
                val success = submissionManager.attachPhotoToSubmission(submissionId, photoPath)
                onPhotoTaken(success)
            } else {
                onPhotoTaken(false)
            }
        }
    }
    
    // Verifica uma submissão de outro usuário
    fun verifyNearbySubmission(submissionId: String, comment: String? = null): Boolean {
        val userId = userManager.getCurrentUserId()
        return submissionManager.verifyUserSubmittedPoi(submissionId, userId, comment)
    }
}

// Classes stub para dependências
class LocationManager {
    fun getCurrentLocation(): Location? = null
}

class UserManager {
    fun getCurrentUserId(): String = ""
}

class CameraController {
    fun takePicture(callback: (String?) -> Unit) {}
}