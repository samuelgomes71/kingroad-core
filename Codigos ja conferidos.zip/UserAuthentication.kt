// app/src/main/kotlin/com/kingroad/auth/UserAuthentication.kt

package com.kingroad.auth

import com.kingroad.database.AuthDatabase
import com.kingroad.utils.CryptoUtils
import com.kingroad.utils.ValidationUtils
import com.kingroad.utils.DeviceUtils
import com.kingroad.network.NetworkManager
import java.util.UUID
import java.time.LocalDateTime

/**
 * Sistema de autenticação e gerenciamento de usuários para o KingRoad
 * Inclui verificação de período de avaliação e prevenção de múltiplos cadastros
 */

// Classe que representa um usuário do sistema
data class KingRoadUser(
    val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val email: String,
    val phoneNumber: String,
    val address: String,
    val country: String,
    val passwordHash: String,
    val registrationDate: LocalDateTime = LocalDateTime.now(),
    val trialStartDate: LocalDateTime? = null,
    val trialEndDate: LocalDateTime? = null,
    val lastLoginDate: LocalDateTime? = null,
    val odometer: Double = 0.0, // Quilometragem atual em km
    val trialOdometerStart: Double? = null, // Marcação do odômetro no início do período de teste
    val isActive: Boolean = true,
    val isTrialActive: Boolean = false,
    val isPremium: Boolean = false,
    val lastDeviceId: String? = null,
    val registeredDevices: List<DeviceInfo> = emptyList(),
    val failedLoginAttempts: Int = 0,
    val lastFailedLoginAttempt: LocalDateTime? = null
)

// Informações do dispositivo do usuário
data class DeviceInfo(
    val deviceId: String,          // Identificador único do dispositivo
    val deviceModel: String,       // Modelo do dispositivo
    val deviceBrand: String,       // Marca do dispositivo
    val osVersion: String,         // Versão do sistema operacional
    val appVersion: String,        // Versão do aplicativo
    val registrationDate: LocalDateTime = LocalDateTime.now(),
    val lastLoginDate: LocalDateTime? = null,
    val isBlocked: Boolean = false // Bloqueado por suspeita de abuso
)

// Resultado de autenticação
sealed class AuthResult {
    object Success : AuthResult()
    object InvalidCredentials : AuthResult()
    object UserNotFound : AuthResult()
    object DeviceNotAuthorized : AuthResult()
    object TrialExpired : AuthResult()
    object AccountLocked : AuthResult()
    object AccountInactive : AuthResult()
    data class Error(val message: String) : AuthResult()
}

// Resultado de registro
sealed class RegistrationResult {
    data class Success(val userId: String) : RegistrationResult()
    data class DuplicateAccount(val reason: String) : RegistrationResult()
    data class ValidationError(val fields: List<String>) : RegistrationResult()
    data class Error(val message: String) : RegistrationResult()
}

// Gerenciador de autenticação e registro
class UserAuthManager(
    private val database: AuthDatabase,
    private val networkManager: NetworkManager
) {
    // Constantes para o período de avaliação
    companion object {
        const val TRIAL_PERIOD_DAYS = 30
        const val TRIAL_PERIOD_KM = 15000.0
    }
    
    // Registra um novo usuário
    suspend fun registerUser(
        fullName: String,
        email: String,
        phoneNumber: String,
        address: String,
        country: String,
        password: String,
        deviceInfo: DeviceInfo
    ): RegistrationResult {
        // Validação básica
        val validationErrors = validateUserData(fullName, email, phoneNumber, address, country, password)
        if (validationErrors.isNotEmpty()) {
            return RegistrationResult.ValidationError(validationErrors)
        }
        
        // Verifica se o e-mail já está em uso
        if (database.getUserByEmail(email) != null) {
            return RegistrationResult.DuplicateAccount("Email already registered")
        }
        
        // Verifica se o número de telefone já está em uso
        if (database.getUserByPhoneNumber(phoneNumber) != null) {
            return RegistrationResult.DuplicateAccount("Phone number already registered")
        }
        
        // Verificações avançadas de duplicidade
        val potentialDuplicates = checkPotentialDuplicates(fullName, email, phoneNumber, address, deviceInfo)
        if (potentialDuplicates.isNotEmpty()) {
            return RegistrationResult.DuplicateAccount("Possible duplicate account detected")
        }
        
        // Gera hash da senha
        val passwordHash = CryptoUtils.hashPassword(password)
        
        // Configura o período de avaliação
        val now = LocalDateTime.now()
        val trialEndDate = now.plusDays(TRIAL_PERIOD_DAYS.toLong())
        
        // Cria o novo usuário
        val newUser = KingRoadUser(
            fullName = fullName,
            email = email,
            phoneNumber = phoneNumber,
            address = address,
            country = country,
            passwordHash = passwordHash,
            registrationDate = now,
            trialStartDate = now,
            trialEndDate = trialEndDate,
            isTrialActive = true,
            lastDeviceId = deviceInfo.deviceId,
            registeredDevices = listOf(deviceInfo)
        )
        
        // Salva o usuário no banco de dados
        return try {
            val userId = database.insertUser(newUser)
            RegistrationResult.Success(userId)
        } catch (e: Exception) {
            RegistrationResult.Error("Failed to register user: ${e.message}")
        }
    }
    
    // Realiza login
    suspend fun login(email: String, password: String, deviceInfo: DeviceInfo): AuthResult {
        // Busca o usuário pelo e-mail
        val user = database.getUserByEmail(email) ?: return AuthResult.UserNotFound
        
        // Verifica se a conta está ativa
        if (!user.isActive) {
            return AuthResult.AccountInactive
        }
        
        // Verifica se a conta está bloqueada por muitas tentativas de login falhas
        if (isAccountLocked(user)) {
            return AuthResult.AccountLocked
        }
        
        // Verifica a senha
        if (!CryptoUtils.verifyPassword(password, user.passwordHash)) {
            // Incrementa contagem de tentativas falhas
            database.updateFailedLoginAttempts(user.id, user.failedLoginAttempts + 1)
            return AuthResult.InvalidCredentials
        }
        
        // Verifica se o dispositivo é autorizado ou se é um novo dispositivo
        val isAuthorizedDevice = user.registeredDevices.any { it.deviceId == deviceInfo.deviceId && !it.isBlocked }
        
        // Se não for um dispositivo autorizado, realiza verificações adicionais
        if (!isAuthorizedDevice) {
            // Verifica se o usuário já atingiu o limite de dispositivos
            if (user.registeredDevices.size >= 2) {
                return AuthResult.DeviceNotAuthorized
            }
            
            // Adiciona o novo dispositivo à lista de dispositivos autorizados
            val updatedDevices = user.registeredDevices + deviceInfo
            database.updateUserDevices(user.id, updatedDevices)
        } else {
            // Atualiza a data do último login para este dispositivo
            val updatedDevices = user.registeredDevices.map {
                if (it.deviceId == deviceInfo.deviceId) it.copy(lastLoginDate = LocalDateTime.now()) else it
            }
            database.updateUserDevices(user.id, updatedDevices)
        }
        
        // Verifica o status do período de avaliação
        if (user.isTrialActive && !user.isPremium) {
            val trialStatus = checkTrialStatus(user)
            if (trialStatus != AuthResult.Success) {
                return trialStatus
            }
        }
        
        // Atualiza as informações de login
        database.updateUserLastLogin(user.id, LocalDateTime.now(), deviceInfo.deviceId)
        
        // Reseta contador de falhas
        database.updateFailedLoginAttempts(user.id, 0)
        
        return AuthResult.Success
    }
    
    // Atualiza a quilometragem do usuário
    suspend fun updateOdometer(userId: String, currentOdometer: Double): Boolean {
        val user = database.getUserById(userId) ?: return false
        
        // Atualiza a quilometragem
        database.updateUserOdometer(userId, currentOdometer)
        
        // Se estiver no período de avaliação, verifica se excedeu o limite
        if (user.isTrialActive && !user.isPremium) {
            val trialOdometerStart = user.trialOdometerStart ?: currentOdometer
            
            // Se excedeu o limite de km do período de avaliação
            if (currentOdometer - trialOdometerStart >= TRIAL_PERIOD_KM) {
                // Desativa o período de avaliação
                database.updateUserTrialStatus(userId, false)
                
                // Envia notificação
                notifyTrialExpired(user, "distance_limit")
                
                return false
            }
        }
        
        return true
    }
    
    // Atualiza a conta para premium
    suspend fun upgradeToPremium(userId: String): Boolean {
        return database.updateUserPremiumStatus(userId, true)
    }
    
    // Verificação de potenciais contas duplicadas
    private suspend fun checkPotentialDuplicates(
        fullName: String,
        email: String,
        phoneNumber: String,
        address: String,
        deviceInfo: DeviceInfo
    ): List<String> {
        val duplicateReasons = mutableListOf<String>()
        
        // Verificação por e-mail similar (sem pontos em gmail, por exemplo)
        val normalizedEmail = normalizeEmail(email)
        if (database.getUserByNormalizedEmail(normalizedEmail) != null) {
            duplicateReasons.add("email_similar")
        }
        
        // Verificação por nome similar
        val similarNameUsers = database.getUsersByNameSimilarity(fullName)
        if (similarNameUsers.isNotEmpty()) {
            duplicateReasons.add("name_similar")
        }
        
        // Verificação por endereço
        val usersWithSameAddress = database.getUsersByAddressSimilarity(address)
        if (usersWithSameAddress.isNotEmpty()) {
            duplicateReasons.add("address_similar")
        }
        
        // Verificação por dispositivo
        val usersWithSameDevice = database.getUsersByDeviceId(deviceInfo.deviceId)
        if (usersWithSameDevice.isNotEmpty()) {
            duplicateReasons.add("device_used")
        }
        
        return duplicateReasons
    }
    
    // Normaliza o email (remove pontos em contas gmail, etc)
    private fun normalizeEmail(email: String): String {
        val parts = email.lowercase().split("@")
        if (parts.size != 2) return email.lowercase()
        
        val (username, domain) = parts
        
        // Tratamento especial para Gmail
        if (domain == "gmail.com") {
            // Remove pontos e tudo após o "+"
            val normalizedUsername = username.replace(".", "").split("+")[0]
            return "$normalizedUsername@$domain"
        }
        
        return email.lowercase()
    }
    
    // Verifica o status do período de avaliação
    private fun checkTrialStatus(user: KingRoadUser): AuthResult {
        val now = LocalDateTime.now()
        
        // Verifica se o período de avaliação expirou por data
        if (user.trialEndDate != null && now.isAfter(user.trialEndDate)) {
            // Desativa o período de avaliação
            database.updateUserTrialStatus(user.id, false)
            
            // Envia notificação
            notifyTrialExpired(user, "time_limit")
            
            return AuthResult.TrialExpired
        }
        
        return AuthResult.Success
    }
    
    // Verifica se a conta está bloqueada por muitas tentativas de login falhas
    private fun isAccountLocked(user: KingRoadUser): Boolean {
        if (user.failedLoginAttempts >= 5) {
            val lastFailure = user.lastFailedLoginAttempt ?: return false
            val lockoutPeriod = LocalDateTime.now().minusMinutes(30)
            
            // Verifica se ainda está dentro do período de bloqueio
            return lastFailure.isAfter(lockoutPeriod)
        }
        
        return false
    }
    
    // Envia notificação sobre expiração do período de avaliação
    private suspend fun notifyTrialExpired(user: KingRoadUser, reason: String) {
        try {
            // Envia notificação ao usuário
            networkManager.sendNotification(
                userId = user.id,
                title = "Trial Period Expired",
                message = getTrialExpiredMessage(reason),
                data = mapOf("action" to "upgrade_premium")
            )
        } catch (e: Exception) {
            // Log do erro
            println("Failed to send notification: ${e.message}")
        }
    }
    
    // Mensagem personalizada sobre a expiração do período de avaliação
    private fun getTrialExpiredMessage(reason: String): String {
        return when (reason) {
            "time_limit" -> "Your 30-day trial period has expired. Upgrade to premium to continue using KingRoad."
            "distance_limit" -> "You've reached the 15,000 km limit of your trial. Upgrade to premium to continue using KingRoad."
            else -> "Your trial period has expired. Upgrade to premium to continue using KingRoad."
        }
    }
    
    // Validação dos dados do usuário
    private fun validateUserData(
        fullName: String,
        email: String,
        phoneNumber: String,
        address: String,
        country: String,
        password: String
    ): List<String> {
        val errors = mutableListOf<String>()
        
        if (!ValidationUtils.isValidName(fullName)) errors.add("fullName")
        if (!ValidationUtils.isValidEmail(email)) errors.add("email")
        if (!ValidationUtils.isValidPhoneNumber(phoneNumber)) errors.add("phoneNumber")
        if (address.isBlank()) errors.add("address")
        if (country.isBlank()) errors.add("country")
        if (!ValidationUtils.isValidPassword(password)) errors.add("password")
        
        return errors
    }
}