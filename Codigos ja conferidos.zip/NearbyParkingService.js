import api from './api';
import { getAuthToken } from '../utils/authUtils';
import { saveToLocalStorage, getFromLocalStorage } from '../utils/storageUtils';
import { PARKING_CACHE_KEY, PARKING_CACHE_EXPIRY } from '../constants/cacheKeys';

/**
 * Serviço para gerenciar as interações com a API relacionadas a estacionamentos próximos
 */
class NearbyParkingService {
  /**
   * Busca estacionamentos próximos a um POI específico
   * 
   * @param {string} poiId - ID do ponto de interesse
   * @param {number} radius - Raio de busca em metros
   * @param {object} truckSpecs - Especificações do caminhão
   * @returns {Promise<Array>} - Lista de estacionamentos próximos
   */
  async findNearbyParkingForPoi(poiId, radius, truckSpecs) {
    try {
      const token = await getAuthToken();
      
      const response = await api.get('/parking/nearby', {
        params: {
          poiId,
          radius,
          height: truckSpecs.height,
          weight: truckSpecs.weight,
          length: truckSpecs.length,
          hazardous: truckSpecs.hasHazardousMaterials,
          refrigerated: truckSpecs.hasRefrigeration
        },
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const results = response.data;
      
      // Salva em cache para acesso offline
      await this.cacheParkingResults(poiId, radius, results);
      
      return results;
    } catch (error) {
      console.error('Error fetching nearby parking:', error);
      throw error;
    }
  }
  
  /**
   * Busca estacionamentos próximos a um POI usando dados em cache (modo offline)
   * 
   * @param {string} poiId - ID do ponto de interesse
   * @param {number} radius - Raio de busca em metros
   * @param {object} truckSpecs - Especificações do caminhão
   * @returns {Promise<Array>} - Lista de estacionamentos próximos do cache
   */
  async findNearbyParkingOffline(poiId, radius, truckSpecs) {
    const cacheKey = `${PARKING_CACHE_KEY}_${poiId}_${radius}`;
    const cachedData = await getFromLocalStorage(cacheKey);
    
    if (!cachedData) {
      return [];
    }
    
    const { results, timestamp } = cachedData;
    
    // Verifica se o cache expirou
    const now = Date.now();
    if (now - timestamp > PARKING_CACHE_EXPIRY) {
      console.log('Cache expired for parking data');
      return [];
    }
    
    // Filtra resultados com base nas especificações do caminhão
    return results.filter(item => 
      (!item.parkingSpot.maxHeight || item.parkingSpot.maxHeight >= truckSpecs.height) &&
      (!item.parkingSpot.maxWeight || item.parkingSpot.maxWeight >= truckSpecs.weight) &&
      (!item.parkingSpot.maxLength || item.parkingSpot.maxLength >= truckSpecs.length)
    );
  }
  
  /**
   * Salva resultados de estacionamento em cache para uso offline
   * 
   * @param {string} poiId - ID do ponto de interesse
   * @param {number} radius - Raio de busca em metros
   * @param {Array} results - Resultados de estacionamento
   * @returns {Promise<void>}
   */
  async cacheParkingResults(poiId, radius, results) {
    const cacheKey = `${PARKING_CACHE_KEY}_${poiId}_${radius}`;
    const cacheData = {
      results,
      timestamp: Date.now()
    };
    
    await saveToLocalStorage(cacheKey, cacheData);
  }
  
  /**
   * Busca detalhes completos de um estacionamento específico
   * 
   * @param {string} parkingId - ID do estacionamento
   * @returns {Promise<Object>} - Detalhes do estacionamento
   */
  async getParkingDetails(parkingId) {
    try {
      const token = await getAuthToken();
      
      const response = await api.get(`/parking/${parkingId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      console.error('Error fetching parking details:', error);
      throw error;
    }
  }
  
  /**
   * Calcula a distância entre dois pontos (POI e estacionamento)
   * 
   * @param {string} poiId - ID do ponto de interesse
   * @param {string} parkingId - ID do estacionamento
   * @returns {Promise<Object>} - Distância e tempo de caminhada
   */
  async calculateDistanceBetweenPoints(poiId, parkingId) {
    try {
      const token = await getAuthToken();
      
      const response = await api.get('/distance/calculate', {
        params: {
          originId: poiId,
          destinationId: parkingId,
          mode: 'walking'
        },
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      console.error('Error calculating distance:', error);
      throw error;
    }
  }
  
  /**
   * Adiciona um novo estacionamento reportado pelo usuário
   * 
   * @param {Object} parkingSpot - Dados do novo estacionamento
   * @returns {Promise<string>} - ID do estacionamento criado
   */
  async addNewParkingSpot(parkingSpot) {
    try {
      const token = await getAuthToken();
      
      const response = await api.post('/parking', parkingSpot, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.data.id;
    } catch (error) {
      console.error('Error adding new parking spot:', error);
      throw error;
    }
  }
  
  /**
   * Salva uma avaliação de segurança para um estacionamento
   * 
   * @param {string} parkingId - ID do estacionamento
   * @param {number} securityRating - Avaliação de segurança (0-10)
   * @param {string} comment - Comentário opcional
   * @returns {Promise<boolean>} - Sucesso ou falha
   */
  async saveSecurityRating(parkingId, securityRating, comment = '') {
    try {
      const token = await getAuthToken();
      
      await api.post(`/parking/${parkingId}/security-rating`, {
        rating: securityRating,
        comment
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return true;
    } catch (error) {
      console.error('Error saving security rating:', error);
      
      // Se estiver offline, salva para sincronização posterior
      if (!navigator.onLine) {
        await this.queueSecurityRating(parkingId, securityRating, comment);
        return true;
      }
      
      throw error;
    }
  }
  
  /**
   * Salva uma avaliação de segurança na fila para sincronização posterior
   * 
   * @param {string} parkingId - ID do estacionamento
   * @param {number} securityRating - Avaliação de segurança (0-10)
   * @param {string} comment - Comentário opcional
   * @returns {Promise<void>}
   */
  async queueSecurityRating(parkingId, securityRating, comment) {
    const queueKey = 'SECURITY_RATINGS_QUEUE';
    
    // Busca a fila atual
    const currentQueue = await getFromLocalStorage(queueKey) || [];
    
    // Adiciona a nova avaliação
    currentQueue.push({
      parkingId,
      securityRating,
      comment,
      timestamp: Date.now()
    });
    
    // Salva a fila atualizada
    await saveToLocalStorage(queueKey, currentQueue);
  }
  
  /**
   * Reporta um problema com um estacionamento
   * 
   * @param {string} parkingId - ID do estacionamento
   * @param {string} issueType - Tipo de problema
   * @param {string} description - Descrição do problema
   * @returns {Promise<boolean>} - Sucesso ou falha
   */
  async reportParkingIssue(parkingId, issueType, description) {
    try {
      const token = await getAuthToken();
      
      await api.post(`/parking/${parkingId}/issues`, {
        issueType,
        description
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return true;
    } catch (error) {
      console.error('Error reporting parking issue:', error);
      throw error;
    }
  }

  /**
   * Encontra POIs próximos a um local específico com estacionamentos seguros para caminhões nas proximidades
   * 
   * @param {string} poiType - Tipo de POI que o motorista está procurando (ex: "RESTAURANT", "CAFE")
   * @param {object} location - Localização atual ou destino {latitude, longitude}
   * @param {number} radius - Raio em metros para procurar estacionamentos (padrão: 200m)
   * @param {object} truckSpecs - Especificações do caminhão
   * @returns {Promise<Array>} - Lista de POIs com estacionamentos próximos
   */
  async findPoisWithNearbyParking(poiType, location, radius = 200, truckSpecs) {
    try {
      const token = await getAuthToken();
      
      // Primeiro, busca POIs do tipo especificado na área
      const poisResponse = await api.get('/poi/search', {
        params: {
          type: poiType,
          latitude: location.latitude,
          longitude: location.longitude,
          radius: 1000 // Raio maior para encontrar POIs, depois filtramos pelos que têm estacionamento próximo
        },
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const pois = poisResponse.data;
      const results = [];
      
      // Para cada POI, verifica se há estacionamentos próximos
      for (const poi of pois) {
        try {
          // Busca estacionamentos próximos para cada POI
          const parkingResponse = await api.get('/parking/nearby', {
            params: {
              latitude: poi.location.latitude,
              longitude: poi.location.longitude,
              radius,
              height: truckSpecs.height,
              weight: truckSpecs.weight,
              length: truckSpecs.length,
              hazardous: truckSpecs.hasHazardousMaterials,
              refrigerated: truckSpecs.hasRefrigeration
            },
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          
          const parkingSpots = parkingResponse.data;
          
          // Se houver pelo menos um estacionamento próximo
          if (parkingSpots.length > 0) {
            // Encontra o estacionamento mais próximo e seguro
            const bestParking = this.findBestParkingSpot(parkingSpots, poi);
            
            // Calcula distância e tempo de caminhada
            const distance = bestParking.distance;
            const walkingTimeMins = this.calculateWalkingTime(distance);
            
            // Adiciona aos resultados
            results.push({
              poi,
              bestParkingSpot: bestParking.spot,
              distanceToParking: distance,
              securityRating: bestParking.securityRating,
              walkingTimeMins
            });
          }
        } catch (error) {
          console.error(`Error finding parking for POI ${poi.id}:`, error);
          // Continua para o próximo POI
        }
      }
      
      // Ordena por distância ao estacionamento
      return results.sort((a, b) => a.distanceToParking - b.distanceToParking);
    } catch (error) {
      console.error('Error finding POIs with nearby parking:', error);
      throw error;
    }
  }

  /**
   * Calcula tempo aproximado de caminhada baseado na distância em metros
   * 
   * @param {number} distanceMeters - Distância em metros
   * @returns {number} - Tempo estimado de caminhada em minutos
   */
  calculateWalkingTime(distanceMeters) {
    // Considerando velocidade média de caminhada de 5km/h = 83.33m/min
    const walkingSpeedMetersPerMin = 83.33;
    return Math.min(30, Math.ceil(distanceMeters / walkingSpeedMetersPerMin));
  }

  /**
   * Encontra o melhor estacionamento com base na segurança e proximidade
   * 
   * @param {Array} parkingSpots - Lista de estacionamentos
   * @param {object} poi - Ponto de interesse
   * @returns {object} - Melhor estacionamento encontrado com distância e avaliação
   */
  findBestParkingSpot(parkingSpots, poi) {
    let bestSpot = null;
    let bestScore = -Infinity;
    let bestDistance = 0;
    let bestSecurity = 0;
    
    for (const spot of parkingSpots) {
      // Calcula distância entre o POI e o estacionamento
      const distance = this.calculateDistance(
        poi.location.latitude, 
        poi.location.longitude,
        spot.location.latitude, 
        spot.location.longitude
      );
      
      // Usa a avaliação de segurança do estacionamento, ou um valor padrão se não existir
      const securityRating = spot.securityRating || 5.0;
      
      // Fórmula que prioriza segurança e proximidade (igual ao Kotlin)
      const score = (securityRating * 0.7) - (distance * 0.3);
      
      if (score > bestScore) {
        bestScore = score;
        bestSpot = spot;
        bestDistance = distance;
        bestSecurity = securityRating;
      }
    }
    
    return {
      spot: bestSpot,
      distance: bestDistance,
      securityRating: bestSecurity
    };
  }

  /**
   * Calcula a distância entre dois pontos geográficos
   * 
   * @param {number} lat1 - Latitude do ponto 1
   * @param {number} lon1 - Longitude do ponto 1
   * @param {number} lat2 - Latitude do ponto 2
   * @param {number} lon2 - Longitude do ponto 2
   * @returns {number} - Distância em metros
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    // Fórmula de Haversine para calcular distância
    const R = 6371e3; // Raio da Terra em metros
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distância em metros
  }
}

export default new NearbyParkingService();