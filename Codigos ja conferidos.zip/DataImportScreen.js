/**
 * DataImportScreen.js
 * 
 * Tela de importação de dados para o aplicativo KingRoad
 * Permite aos usuários importar rotas, pontos de interesse e outros dados
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  FlatList
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import DataImportService from '../services/DataImportService';
import { useTheme } from '../contexts/ThemeContext';

const DataImportScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [recentImports, setRecentImports] = useState([]);
  const [supportedFormats, setSupportedFormats] = useState([]);
  
  useEffect(() => {
    loadData();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma
      loadData();
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, []);

  const loadData = async () => {
    try {
      // Carrega importações recentes
      const recent = await DataImportService.getRecentImports();
      setRecentImports(recent);
      
      // Carrega formatos suportados
      const formats = await DataImportService.getSupportedFormats();
      setSupportedFormats(formats);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      Alert.alert(
        t('alert.error'),
        t('error.load_import_data'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const handleImportFile = async () => {
    try {
      // Abre seletor de documentos
      const result = await DocumentPicker.pick({
        type: supportedFormats.map(format => format.mimeType),
        allowMultiSelection: false,
      });
      
      const file = result[0];
      
      // Verifica tamanho do arquivo
      const fileSizeInMB = file.size / (1024 * 1024);
      const maxSizeInMB = 50; // Tamanho máximo permitido em MB
      
      if (fileSizeInMB > maxSizeInMB) {
        Alert.alert(
          t('alert.error'),
          t('error.file_too_large', { size: RegionalSettingsService.formatFileSize(file.size), maxSize: `${maxSizeInMB} MB` }),
          [{ text: t('button.ok') }]
        );
        return;
      }
      
      // Inicia importação
      setImporting(true);
      setProgress(0);
      
      // Configura callback de progresso
      const progressCallback = (currentProgress) => {
        setProgress(currentProgress);
      };
      
      // Importa arquivo
      const importResult = await DataImportService.importFile(file.uri, progressCallback);
      
      setImporting(false);
      
      // Atualiza lista de importações recentes
      loadData();
      
      // Mostra resultado
      Alert.alert(
        t('alert.success'),
        t('success.file_imported', { 
          name: file.name, 
          items: importResult.itemsImported 
        }),
        [
          { 
            text: t('button.view_data'), 
            onPress: () => navigation.navigate('ImportedData', { importId: importResult.id }) 
          },
          { text: t('button.ok') }
        ]
      );
    } catch (error) {
      setImporting(false);
      
      if (DocumentPicker.isCancel(error)) {
        // Usuário cancelou a seleção
        return;
      }
      
      console.error('Erro ao importar arquivo:', error);
      
      Alert.alert(
        t('alert.error'),
        t('error.import_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const handleDeleteImport = async (importId) => {
    try {
      Alert.alert(
        t('alert.confirm'),
        t('alert.confirm_delete_import'),
        [
          {
            text: t('button.cancel'),
            style: 'cancel'
          },
          {
            text: t('button.delete'),
            style: 'destructive',
            onPress: async () => {
              await DataImportService.deleteImport(importId);
              loadData();
            }
          }
        ]
      );
    } catch (error) {
      console.error('Erro ao excluir importação:', error);
      Alert.alert(
        t('alert.error'),
        t('error.delete_failed'),
        [{ text: t('button.ok') }]
      );
    }
  };

  const renderImportItem = ({ item }) => (
    <View style={[styles.importItem, { backgroundColor: theme.card }]}>
      <View style={styles.importIconContainer}>
        <Icon 
          name={getIconForFileType(item.fileType)} 
          size={24} 
          color={theme.primary} 
        />
      </View>
      
      <View style={styles.importDetails}>
        <Text style={[styles.importName, { color: theme.text }]}>
          {item.fileName}
        </Text>
        <Text style={[styles.importMeta, { color: theme.textSecondary }]}>
          {formatImportDate(item.date)} • {RegionalSettingsService.formatFileSize(item.fileSize)}
        </Text>
        <Text style={[styles.importStats, { color: theme.textSecondary }]}>
          {t('screen.data_import.imported_items', { count: item.itemsImported })}
        </Text>
      </View>
      
      <View style={styles.importActions}>
        <TouchableOpacity
          style={styles.importAction}
          onPress={() => navigation.navigate('ImportedData', { importId: item.id })}
        >
          <Icon name="visibility" size={20} color={theme.primary} />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.importAction}
          onPress={() => handleDeleteImport(item.id)}
        >
          <Icon name="delete" size={20} color={theme.danger} />
        </TouchableOpacity>
      </View>
    </View>
  );

  const getIconForFileType = (fileType) => {
    const iconMap = {
      'gpx': 'route',
      'kml': 'map',
      'csv': 'grid-on',
      'json': 'code',
      'zip': 'folder-zip',
    };
    
    return iconMap[fileType] || 'insert-drive-file';
  };

  const formatImportDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(TranslationsService.getCurrentLocale(), {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const renderSupportedFormat = ({ item }) => (
    <View style={[styles.formatItem, { backgroundColor: theme.card }]}>
      <Icon name={getIconForFileType(item.extension)} size={20} color={theme.primary} />
      <Text style={[styles.formatName, { color: theme.text }]}>
        {item.name}
      </Text>
      <Text style={[styles.formatExtension, { color: theme.textSecondary }]}>
        {item.extension.toUpperCase()}
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* Seção de importação de arquivo */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.data_import.import_file')}
          </Text>
          
          <View style={[styles.importCard, { backgroundColor: theme.card }]}>
            <Icon name="file-upload" size={48} color={theme.primary} />
            
            <Text style={[styles.importCardText, { color: theme.text }]}>
              {t('screen.data_import.drag_drop_prompt')}
            </Text>
            
            <TouchableOpacity
              style={[styles.importButton, { backgroundColor: theme.primary }]}
              onPress={handleImportFile}
              disabled={importing}
            >
              <Text style={styles.importButtonText}>
                {t('button.select_file')}
              </Text>
            </TouchableOpacity>
            
            <Text style={[styles.importNote, { color: theme.textSecondary }]}>
              {t('screen.data_import.max_size_note', { maxSize: '50 MB' })}
            </Text>
          </View>
          
          {/* Indicador de progresso de importação */}
          {importing && (
            <View style={[styles.progressContainer, { backgroundColor: theme.card }]}>
              <Text style={[styles.progressText, { color: theme.text }]}>
                {t('screen.data_import.importing')}
              </Text>
              
              <View style={styles.progressBarContainer}>
                <View 
                  style={[
                    styles.progressBar, 
                    { 
                      backgroundColor: theme.primary,
                      width: `${progress}%`
                    }
                  ]} 
                />
              </View>
              
              <Text style={[styles.progressPercentage, { color: theme.textSecondary }]}>
                {progress}%
              </Text>
            </View>
          )}
        </View>
        
        {/* Formatos suportados */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.data_import.supported_formats')}
          </Text>
          
          <View style={styles.formatsContainer}>
            {supportedFormats.map((format, index) => (
              <View 
                key={`format-${index}`} 
                style={[styles.formatItem, { backgroundColor: theme.card }]}
              >
                <Icon name={getIconForFileType(format.extension)} size={20} color={theme.primary} />
                <Text style={[styles.formatName, { color: theme.text }]}>
                  {format.name}
                </Text>
                <Text style={[styles.formatExtension, { color: theme.textSecondary }]}>
                  .{format.extension}
                </Text>
              </View>
            ))}
          </View>
        </View>
        
        {/* Importações recentes */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.data_import.recent_imports')}
          </Text>
          
          {recentImports.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: theme.card }]}>
              <Icon name="history" size={48} color={theme.textSecondary} />
              <Text style={[styles.emptyStateText, { color: theme.textSecondary }]}>
                {t('screen.data_import.no_recent_imports')}
              </Text>
            </View>
          ) : (
            recentImports.map((item) => renderImportItem({ item }))
          )}
        </View>
        
        {/* Dicas de importação */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            {t('screen.data_import.tips_title')}
          </Text>
          
          <View style={[styles.tipsContainer, { backgroundColor: theme.card }]}>
            <View style={styles.tipItem}>
              <Icon name="lightbulb" size={20} color={theme.warning} />
              <Text style={[styles.tipText, { color: theme.text }]}>
                {t('screen.data_import.tip_1')}
              </Text>
            </View>
            
            <View style={styles.tipItem}>
              <Icon name="lightbulb" size={20} color={theme.warning} />
              <Text style={[styles.tipText, { color: theme.text }]}>
                {t('screen.data_import.tip_2')}
              </Text>
            </View>
            
            <View style={styles.tipItem}>
              <Icon name="lightbulb" size={20} color={theme.warning} />
              <Text style={[styles.tipText, { color: theme.text }]}>
                {t('screen.data_import.tip_3')}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  importCard: {
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  importCardText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  importButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  importButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  importNote: {
    fontSize: 12,
    marginTop: 16,
  },
  progressContainer: {
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  progressText: {
    fontSize: 14,
    marginBottom: 8,
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: '#f0f0f0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 4,
  },
  progressPercentage: {
    fontSize: 12,
    marginTop: 8,
    alignSelf: 'flex-end',
  },
  formatsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  formatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  formatName: {
    fontSize: 14,
    marginLeft: 8,
    marginRight: 4,
  },
  formatExtension: {
    fontSize: 12,
  },
  importItem: {
    flexDirection: 'row',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  importIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  importDetails: {
    flex: 1,
  },
  importName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  importMeta: {
    fontSize: 12,
    marginBottom: 2,
  },
  importStats: {
    fontSize: 12,
  },
  importActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  importAction: {
    padding: 8,
    marginLeft: 8,
  },
  emptyState: {
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  emptyStateText: {
    fontSize: 14,
    textAlign: 'center',
    marginTop: 12,
  },
  tipsContainer: {
    borderRadius: 12,
    padding: 16,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  tipText: {
    fontSize: 14,
    marginLeft: 12,
    flex: 1,
  },
});

export default DataImportScreen;