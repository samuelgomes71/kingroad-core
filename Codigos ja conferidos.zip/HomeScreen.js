import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  SafeAreaView,
  StatusBar,
  TextInput,
  Animated,
  Platform,
  Dimensions,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import LinearGradient from 'react-native-linear-gradient';

const HomeScreen = () => {
  const navigation = useNavigation();
  const [isOnline, setIsOnline] = useState(true);
  const [userName, setUserName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [recentRoutes, setRecentRoutes] = useState([]);
  const [weatherInfo, setWeatherInfo] = useState(null);
  const [showAssistant, setShowAssistant] = useState(false);
  const [assistantMessage, setAssistantMessage] = useState('');
  const [currentLocation, setCurrentLocation] = useState(null);
  const assistantAnimation = useRef(new Animated.Value(0)).current;
  
  // Constantes para modos de navegação
  const navigationModes = [
    { id: 'truck', name: 'Caminhão', icon: 'truck', color: '#4A90E2' },
    { id: 'hike', name: 'Trilha', icon: 'hiking', color: '#4CAF50' },
    { id: 'bike', name: 'Bike', icon: 'bike', color: '#FF9800' },
    { id: 'moto', name: 'Moto', icon: 'motorbike', color: '#E91E63' },
    { id: '4x4', name: '4x4', icon: 'jeepney', color: '#795548' },
    { id: 'snowmobile', name: 'Snow', icon: 'snowflake', color: '#9C27B0' }
  ];

  // Constantes para ações rápidas
  const quickActions = [
    { id: 'saved', name: 'Rotas Salvas', icon: 'bookmark-outline', screen: 'SavedRoutes' },
    { id: 'poi', name: 'Pontos de Interesse', icon: 'map-marker', screen: 'POIScreen' },
    { id: 'alerts', name: 'Alertas', icon: 'alert-circle-outline', screen: 'AlertsScreen' },
    { id: 'safety', name: 'Segurança', icon: 'shield-check', screen: 'RouteSafetyScreen' },
    { id: 'satellite', name: 'Satélite', icon: 'satellite-variant', screen: 'SatelliteOverlayScreen' },
    { id: 'profile', name: 'Perfil', icon: 'account-circle-outline', screen: 'UserProfileScreen' }
  ];

  // Verificar conexão ao iniciar e monitorar mudanças
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsOnline(state.isConnected);
      if (state.isConnected === false) {
        setAssistantMessage('Modo offline ativado. Suas rotas salvas e mapas baixados estão disponíveis.');
        showAssistantBubble();
      }
    });

    // Carregar nome do usuário
    loadUserName();
    // Carregar localização atual (simulada neste exemplo)
    fetchCurrentLocation();
    // Carregar rotas recentes
    loadRecentRoutes();
    // Carregar informações do clima (simulado)
    fetchWeatherInfo();

    return () => {
      unsubscribe();
    };
  }, []);

  // Recarregar dados quando a tela receber foco
  useFocusEffect(
    React.useCallback(() => {
      loadRecentRoutes();
    }, [])
  );

  // Funções para carregar dados
  const loadUserName = async () => {
    try {
      const storedName = await AsyncStorage.getItem('user_name');
      if (storedName) {
        setUserName(storedName);
      } else {
        setUserName('Viajante');
      }
    } catch (error) {
      console.error('Erro ao carregar nome do usuário:', error);
    }
  };

  const loadRecentRoutes = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('saved_routes');
      if (jsonValue) {
        const routes = JSON.parse(jsonValue)
          .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
          .slice(0, 3); // Apenas as 3 rotas mais recentes
        
        setRecentRoutes(routes.map(route => ({
          ...route,
          color: navigationModes.find(mode => mode.id === route.mode)?.color || '#607D8B',
          icon: navigationModes.find(mode => mode.id === route.mode)?.icon || 'map-marker-path'
        })));
      }
    } catch (error) {
      console.error('Erro ao carregar rotas recentes:', error);
    }
  };

  const fetchCurrentLocation = () => {
    // Simulando obtenção de localização atual
    // Em um app real, usaria Geolocation
    setTimeout(() => {
      setCurrentLocation({
        name: 'Rodovia BR-101',
        description: 'Próximo a São Paulo'
      });
    }, 1000);
  };

  const fetchWeatherInfo = () => {
    // Simulando obtenção de informações do clima
    // Em um app real, chamaria uma API de clima
    setTimeout(() => {
      setWeatherInfo({
        temperature: 28,
        condition: 'Parcialmente Nublado',
        icon: 'weather-partly-cloudy'
      });
    }, 1500);
  };

  // Função para mostrar a bolha do assistente
  const showAssistantBubble = () => {
    setShowAssistant(true);
    Animated.timing(assistantAnimation, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true
    }).start();

    // Esconder automaticamente após alguns segundos
    setTimeout(() => {
      Animated.timing(assistantAnimation, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true
      }).start(() => setShowAssistant(false));
    }, 6000);
  };

  // Iniciar navegação com um modo específico
  const startNavigation = (mode) => {
    navigation.navigate('NavigationScreen', { mode });
  };

  // Navegar para tela de detalhes de rota
  const viewRouteDetails = (route) => {
    navigation.navigate('RouteDetails', { route });
  };

  // Navegar para tela de rotas salvas
  const viewAllSavedRoutes = () => {
    navigation.navigate('SavedRoutes');
  };

  // Iniciar pesquisa
  const handleSearch = () => {
    if (searchQuery.trim() === '') return;
    
    navigation.navigate('SearchResults', { query: searchQuery });
  };

  // Ativar assistente AI "Tio Sam"
  const activateAssistant = () => {
    // Frases do assistente baseadas no estilo "PX (rádio de caminhoneiros)"
    const phrases = [
      'Qual o seu Q.R.A., parceiro?',
      'Loura dá um 5.3 na escuta, câmbio!',
      'Tá pegando muito congestionamento na Dutra hoje, melhor seguir pela Airton Senna.',
      'Tá na escuta, amigo? Aqui é o Tio Sam, pronto pra te ajudar na estrada.',
      'Tem blitz na rodovia, sai fora dessa e pega o desvio no próximo retorno.'
    ];
    
    setAssistantMessage(phrases[Math.floor(Math.random() * phrases.length)]);
    showAssistantBubble();
  };

  // Navegar para uma tela de ação rápida
  const navigateToAction = (screen) => {
    navigation.navigate(screen);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#4A90E2" barStyle="light-content" />
      
      {/* Cabeçalho */}
      <LinearGradient 
        colors={['#4A90E2', '#5A9AE8']} 
        style={styles.header}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Olá, {userName}</Text>
            <View style={styles.locationContainer}>
              <Icon name="map-marker" size={16} color="#FFF" />
              <Text style={styles.locationText}>
                {currentLocation ? currentLocation.name : 'Carregando localização...'}
              </Text>
            </View>
          </View>
          
          <View style={styles.headerIcons}>
            {!isOnline && (
              <View style={styles.offlineIndicator}>
                <Icon name="wifi-off" size={16} color="#FFF" />
              </View>
            )}
            
            <TouchableOpacity 
              style={styles.iconButton}
              onPress={() => navigation.navigate('UserProfileScreen')}
            >
              <Icon name="account-circle" size={28} color="#FFF" />
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Barra de pesquisa */}
        <View style={styles.searchContainer}>
          <Icon name="magnify" size={20} color="#777" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Buscar destino ou endereço..."
            placeholderTextColor="#999"
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
          />
          <TouchableOpacity 
            style={styles.micButton}
            onPress={activateAssistant}
          >
            <Icon name="microphone" size={20} color="#4A90E2" />
          </TouchableOpacity>
        </View>
      </LinearGradient>
      
      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        {/* Modos de navegação */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Modos de Navegação</Text>
          <View style={styles.navigationModes}>
            {navigationModes.map((mode) => (
              <TouchableOpacity
                key={mode.id}
                style={styles.modeItem}
                onPress={() => startNavigation(mode.id)}
              >
                <View style={[styles.modeIconContainer, { backgroundColor: mode.color }]}>
                  <Icon name={mode.icon} size={24} color="#FFF" />
                </View>
                <Text style={styles.modeText}>{mode.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* Clima e Condições */}
        {weatherInfo && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Condições Atuais</Text>
            <View style={styles.weatherCard}>
              <View style={styles.weatherMain}>
                <Icon 
                  name={weatherInfo.icon} 
                  size={32} 
                  color="#4A90E2" 
                />
                <View style={styles.weatherInfo}>
                  <Text style={styles.temperature}>{weatherInfo.temperature}°C</Text>
                  <Text style={styles.weatherCondition}>{weatherInfo.condition}</Text>
                </View>
              </View>
              
              <View style={styles.weatherDetails}>
                <TouchableOpacity 
                  style={styles.weatherButton}
                  onPress={() => navigation.navigate('WeatherDetails')}
                >
                  <Text style={styles.weatherButtonText}>Ver Previsão Completa</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
        
        {/* Rotas Recentes */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Rotas Recentes</Text>
            <TouchableOpacity onPress={viewAllSavedRoutes}>
              <Text style={styles.seeAllText}>Ver Todas</Text>
            </TouchableOpacity>
          </View>
          
          {recentRoutes.length > 0 ? (
            <View style={styles.recentRoutes}>
              {recentRoutes.map((route) => (
                <TouchableOpacity
                  key={route.id}
                  style={styles.recentRouteItem}
                  onPress={() => viewRouteDetails(route)}
                >
                  <View style={[styles.routeIconContainer, { backgroundColor: route.color }]}>
                    <Icon name={route.icon} size={20} color="#FFF" />
                  </View>
                  <View style={styles.routeInfo}>
                    <Text style={styles.routeTitle} numberOfLines={1}>
                      {route.title || 'Rota sem nome'}
                    </Text>
                    <Text style={styles.routeDetails} numberOfLines={1}>
                      {route.distance ? `${route.distance.toFixed(1)} km` : 'Distância N/A'}
                      {route.duration ? ` • ${Math.round(route.duration / 60)} min` : ''}
                    </Text>
                  </View>
                  <Icon name="chevron-right" size={20} color="#CCC" />
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <View style={styles.emptyRoutes}>
              <Icon name="map-marker-off" size={40} color="#DDD" />
              <Text style={styles.emptyRoutesText}>Nenhuma rota recente</Text>
              <TouchableOpacity 
                style={styles.startRouteButton}
                onPress={() => navigation.navigate('NavigationScreen')}
              >
                <Icon name="navigation" size={16} color="#FFF" style={styles.startRouteIcon} />
                <Text style={styles.startRouteText}>Iniciar Nova Rota</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
        
        {/* Ações Rápidas */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ações Rápidas</Text>
          <View style={styles.quickActions}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                style={styles.actionItem}
                onPress={() => navigateToAction(action.screen)}
              >
                <View style={styles.actionIconContainer}>
                  <Icon name={action.icon} size={24} color="#4A90E2" />
                </View>
                <Text style={styles.actionText}>{action.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* Dica do Dia / Beta Label */}
        <View style={styles.tipCard}>
          <View style={styles.betaLabel}>
            <Text style={styles.betaText}>BETA</Text>
          </View>
          
          <View style={styles.tipContent}>
            <Icon name="lightbulb-outline" size={24} color="#FFD700" />
            <View style={styles.tipTextContainer}>
              <Text style={styles.tipTitle}>Dica do Dia</Text>
              <Text style={styles.tipText}>
                Mantenha seus mapas atualizados para navegação offline. Toque para sincronizar agora.
              </Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.tipButton}
            onPress={() => navigation.navigate('OfflineMaps')}
          >
            <Text style={styles.tipButtonText}>Sincronizar</Text>
          </TouchableOpacity>
        </View>
        
        {/* Espaço para o assistente não sobrepor conteúdo */}
        <View style={styles.bottomPadding} />
      </ScrollView>
      
      {/* Assistente "Tio Sam" */}
      {showAssistant && (
        <Animated.View 
          style={[
            styles.assistantContainer,
            {
              opacity: assistantAnimation,
              transform: [
                {
                  translateY: assistantAnimation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [50, 0]
                  })
                }
              ]
            }
          ]}
        >
          <View style={styles.assistantBubble}>
            <Image
              source={require('../assets/tio-sam.png')} // Certifique-se de ter esta imagem
              style={styles.assistantAvatar}
              defaultSource={require('../assets/tio-sam-default.png')} // Fallback
            />
            <View style={styles.assistantMessageContainer}>
              <Text style={styles.assistantMessage}>{assistantMessage}</Text>
            </View>
            <TouchableOpacity 
              style={styles.closeAssistantButton}
              onPress={() => {
                Animated.timing(assistantAnimation, {
                  toValue: 0,
                  duration: 200,
                  useNativeDriver: true
                }).start(() => setShowAssistant(false));
              }}
            >
              <Icon name="close" size={16} color="#999" />
            </TouchableOpacity>
          </View>
        </Animated.View>
      )}
      
      {/* Botão de Navegação Rápida */}
      <TouchableOpacity
        style={styles.fabButton}
        onPress={() => navigation.navigate('NavigationScreen')}
      >
        <Icon name="navigation" size={28} color="#FFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    paddingTop: Platform.OS === 'ios' ? 0 : StatusBar.currentHeight,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 16,
  },
  greeting: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  locationText: {
    fontSize: 14,
    color: '#FFF',
    marginLeft: 4,
    opacity: 0.9,
  },
  headerIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  offlineIndicator: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 10,
  },
  iconButton: {
    padding: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 46,
    marginTop: 4,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#333',
    height: '100%',
  },
  micButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    marginHorizontal: 16,
    marginTop: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  seeAllText: {
    fontSize: 14,
    color: '#4A90E2',
  },
  navigationModes: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  modeItem: {
    width: width / 3 - 20,
    alignItems: 'center',
    marginBottom: 16,
  },
  modeIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  modeText: {
    fontSize: 14,
    color: '#444',
  },
  weatherCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  weatherMain: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  weatherInfo: {
    marginLeft: 12,
  },
  temperature: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  weatherCondition: {
    fontSize: 14,
    color: '#666',
  },
  weatherDetails: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  weatherButton: {
    backgroundColor: '#F5F8FF',
    borderRadius: 4,
    paddingVertical: 8,
    alignItems: 'center',
  },
  weatherButtonText: {
    fontSize: 14,
    color: '#4A90E2',
    fontWeight: '500',
  },
  recentRoutes: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  recentRouteItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  routeIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  routeInfo: {
    flex: 1,
    marginLeft: 12,
  },
  routeTitle: {
    fontSize: 15,
    fontWeight: '500',
    color: '#333',
  },
  routeDetails: {
    fontSize: 13,
    color: '#999',
    marginTop: 2,
  },
  emptyRoutes: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginTop: 12,
  },
  emptyRoutesText: {
    fontSize: 15,
    color: '#666',
    marginTop: 8,
    marginBottom: 12,
  },
  startRouteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4A90E2',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 6,
  },
  startRouteIcon: {
    marginRight: 6,
  },
  startRouteText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#FFF',
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionItem: {
    width: width / 3 - 20,
    alignItems: 'center',
    marginBottom: 16,
  },
  actionIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F8FF',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 13,
    color: '#444',
    textAlign: 'center',
  },
  tipCard: {
    marginHorizontal: 16,
    marginTop: 20,
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    position: 'relative',
  },
  betaLabel: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF9800',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderTopRightRadius: 12,
    borderBottomLeftRadius: 8,
  },
  betaText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#FFF',
  },
  tipContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tipTextContainer: {
    flex: 1,
    marginLeft: 12,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  tipText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  tipButton: {
    backgroundColor: '#F5F8FF',
    borderRadius: 4,
    paddingVertical: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  tipButtonText: {
    fontSize: 14,
    color: '#4A90E2',
    fontWeight: '500',
  },
  bottomPadding: {
    height: 80,
  },
  assistantContainer: {
    position: 'absolute',
    bottom: 90,
    left: 16,
    right: 16,
    zIndex: 100,
  },
  assistantBubble: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  assistantAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
  },
  assistantMessageContainer: {
    flex: 1,
    marginHorizontal: 12,
  },
  assistantMessage: {
    fontSize: 14,
    color: '#333',
  },
  closeAssistantButton: {
    padding: 4,
  },
  fabButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4A90E2',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
});

export default HomeScreen;