// MapActivity.kt
package com.kingroad.activities

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.kingroad.R
import com.kingroad.map.KingRoadMapView
import com.kingroad.map.PulsatingLocationMarker
import com.kingroad.utils.Logger

/**
 * Activity para exibição do mapa de navegação
 */
class MapActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "MapActivity"
        private const val LOCATION_PERMISSION_REQUEST = 1001
    }

    private lateinit var mapView: KingRoadMapView
    private lateinit var mapContainer: FrameLayout
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var pulsatingMarker: PulsatingLocationMarker? = null
    private var showCurrentLocation = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        // Obter extras da Intent
        showCurrentLocation = intent.getBooleanExtra("SHOW_CURRENT_LOCATION", false)

        // Inicializar componentes
        mapContainer = findViewById(R.id.map_container)
        mapView = findViewById(R.id.map_view)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Configurar mapa
        mapView.initialize(savedInstanceState)

        // Verificar permissão e mostrar localização atual se necessário
        if (showCurrentLocation) {
            checkLocationPermissionAndShowMarker()
        }
    }

    /**
     * Verifica permissão de localização e exibe marcador se concedida
     */
    private fun checkLocationPermissionAndShowMarker() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            showCurrentLocationMarker()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
        }
    }

    /**
     * Exibe marcador na localização atual
     */
    private fun showCurrentLocationMarker() {
        try {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                    location?.let {
                        Logger.d(TAG, "Localização atual: ${it.latitude}, ${it.longitude}")
                        
                        // Centralizar mapa na localização atual
                        mapView.centerOnLocation(it.latitude, it.longitude)
                        
                        // Exibir marcador pulsante
                        showPulsatingMarker(it.latitude, it.longitude)
                    } ?: run {
                        Logger.e(TAG, "Não foi possível obter localização atual")
                    }
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Erro ao obter localização: ${e.message}")
        }
    }

    /**
     * Exibe marcador pulsante na posição especificada
     */
    private fun showPulsatingMarker(latitude: Double, longitude: Double) {
        // Remover marcador existente, se houver
        if (pulsatingMarker != null) {
            mapContainer.removeView(pulsatingMarker)
        }

        // Criar novo marcador pulsante
        pulsatingMarker = PulsatingLocationMarker(this).apply {
            setMapView(mapView)
            setLocation(latitude, longitude)
        }

        // Adicionar marcador ao mapa
        mapContainer.addView(pulsatingMarker)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showCurrentLocationMarker()
            } else {
                Logger.w(TAG, "Permissão de localização negada")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.onDestroy()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }
}