import React, { useState, useEffect, useRef } from 'react';
import { Download, Map, X, CheckCircle, AlertCircle, Pause, RotateCw } from 'lucide-react';

/**
 * Interface para baixar mapas por região antes da viagem
 * (ex: estado, rota, raio de 50km).
 * 
 * @param {Object} props Propriedades do componente
 * @param {Object[]} props.availableRegions Lista de regiões disponíveis para download
 * @param {Function} props.onDownloadRegion Callback quando o usuário solicita download de uma região
 * @param {Function} props.onCancelDownload Callback quando o usuário cancela um download
 * @param {Object} props.downloadStatus Estado atual do download (progress, region, status)
 * @param {Object} props.currentLocation Localização atual do usuário {lat, lng}
 * @param {Function} props.onSelectArea Callback quando o usuário seleciona uma área no mapa
 * @param {string} props.className Classes CSS adicionais
 */
const OfflineMapSelector = ({
  availableRegions = [],
  onDownloadRegion = () => {},
  onCancelDownload = () => {},
  downloadStatus = { progress: 0, region: null, status: 'idle' },
  currentLocation = null,
  onSelectArea = () => {},
  className = ""
}) => {
  const [activeTab, setActiveTab] = useState('regions');
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [customRadius, setCustomRadius] = useState(50);
  const [downloadedRegions, setDownloadedRegions] = useState([]);
  const [storageInfo, setStorageInfo] = useState({ used: 0, total: 0 });
  const [isExpanded, setIsExpanded] = useState(false);
  
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);

  // Atualiza informações sobre regiões já baixadas
  useEffect(() => {
    // Filtra regiões que já estão baixadas
    const downloaded = availableRegions.filter(region => region.isDownloaded);
    setDownloadedRegions(downloaded);
    
    // Calcula espaço usado
    let totalUsed = 0;
    downloaded.forEach(region => {
      totalUsed += region.size || 0;
    });
    
    // Em uma aplicação real, seria obtido do sistema
    const totalStorage = 1024 * 8; // 8 GB em MB
    
    setStorageInfo({
      used: totalUsed,
      total: totalStorage
    });
  }, [availableRegions]);

  // Inicializa mapa quando o componente montar ou quando mudar para a aba de mapa
  useEffect(() => {
    if (activeTab === 'map' && mapContainerRef.current && !mapRef.current) {
      initMap();
    }
    
    return () => {
      // Limpa recursos do mapa quando o componente desmontar
      if (mapRef.current) {
        // Em uma implementação real, limparia o mapa aqui
        mapRef.current = null;
      }
    };
  }, [activeTab]);

  // Inicializa o mapa (mockup - em um app real, usaria uma biblioteca como Leaflet ou Google Maps)
  const initMap = () => {
    // Simulação da inicialização do mapa
    setTimeout(() => {
      // Código de mock para simular que o mapa carregou
      console.log("Mapa inicializado");
      mapRef.current = {
        initialized: true
      };
      
      // Se tiver localização atual, centraliza o mapa nela
      if (currentLocation) {
        console.log(`Centralizando mapa em: ${currentLocation.lat}, ${currentLocation.lng}`);
      }
    }, 500);
  };

  // Inicia download de uma região
  const handleDownloadRegion = () => {
    if (selectedRegion) {
      onDownloadRegion(selectedRegion);
    } else if (activeTab === 'map' && currentLocation) {
      // Para downloads baseados em localização atual e raio
      onDownloadRegion({
        name: `Área ao redor da localização atual (${customRadius}km)`,
        center: currentLocation,
        radius: customRadius,
        type: 'radius'
      });
    }
  };

  // Seleciona uma região
  const handleSelectRegion = (region) => {
    setSelectedRegion(region);
  };

  // Altera o raio para download personalizado
  const handleRadiusChange = (e) => {
    const value = parseInt(e.target.value, 10);
    setCustomRadius(value);
  };

  // Renderiza a lista de regiões disponíveis
  const renderRegionsList = () => {
    if (availableRegions.length === 0) {
      return (
        <div className="text-center py-6 text-gray-500 dark:text-gray-400">
          Nenhuma região disponível para download
        </div>
      );
    }
    
    return (
      <div className="space-y-2 mt-4">
        {availableRegions.map((region) => (
          <div 
            key={region.id}
            className={`
              p-3 rounded-lg border cursor-pointer transition-colors
              ${selectedRegion?.id === region.id ? 
                'bg-blue-50 border-blue-300 dark:bg-blue-900 dark:border-blue-700' : 
                'bg-white border-gray-200 hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700'}
            `}
            onClick={() => handleSelectRegion(region)}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Map className="w-5 h-5 text-gray-400 dark:text-gray-500 mr-2" />
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-gray-100">{region.name}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {region.size ? `${(region.size / 1024).toFixed(1)} GB` : 'Tamanho desconhecido'}
                    {region.isDownloaded && ' • Baixado'}
                  </p>
                </div>
              </div>
              {region.isDownloaded ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <Download className="w-5 h-5 text-blue-500" />
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  // Renderiza a interface de seleção no mapa
  const renderMapSelector = () => {
    return (
      <div className="space-y-4 mt-4">
        <div className="relative w-full h-64 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden" ref={mapContainerRef}>
          {/* Placeholder para o mapa - em uma aplicação real, seria um componente de mapa */}
          <div className="absolute inset-0 flex items-center justify-center text-gray-400 dark:text-gray-500">
            <div className="text-center">
              <Map className="w-12 h-12 mx-auto mb-2" />
              <p>Mapa interativo carregaria aqui</p>
              {currentLocation && (
                <p className="text-xs mt-2">Localização atual: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}</p>
              )}
            </div>
          </div>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="radius-slider" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Raio ao redor da posição atual: {customRadius} km
          </label>
          <input
            id="radius-slider"
            type="range"
            min="10"
            max="100"
            step="5"
            value={customRadius}
            onChange={handleRadiusChange}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
          />
          <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
            <span>10km</span>
            <span>50km</span>
            <span>100km</span>
          </div>
        </div>
        
        <div className="text-xs text-gray-500 dark:text-gray-400">
          <p>Tamanho estimado: {((Math.PI * Math.pow(customRadius, 2) * 0.05) / 1024).toFixed(2)} GB</p>
          <p className="mt-1">O download de mapas offline consome dados e armazenamento.</p>
        </div>
      </div>
    );
  };

  // Renderiza o progresso do download
  const renderDownloadProgress = () => {
    if (downloadStatus.status === 'idle' || !downloadStatus.region) {
      return null;
    }
    
    let statusIcon;
    let statusColor;
    let statusText;
    
    switch (downloadStatus.status) {
      case 'downloading':
        statusIcon = <RotateCw className="w-5 h-5 animate-spin" />;
        statusColor = 'text-blue-500';
        statusText = `Baixando ${downloadStatus.progress}%`;
        break;
      case 'paused':
        statusIcon = <Pause className="w-5 h-5" />;
        statusColor = 'text-yellow-500';
        statusText = 'Download pausado';
        break;
      case 'error':
        statusIcon = <AlertCircle className="w-5 h-5" />;
        statusColor = 'text-red-500';
        statusText = 'Erro no download';
        break;
      case 'completed':
        statusIcon = <CheckCircle className="w-5 h-5" />;
        statusColor = 'text-green-500';
        statusText = 'Download concluído';
        break;
      default:
        return null;
    }
    
    return (
      <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center">
            <div className={`mr-2 ${statusColor}`}>
              {statusIcon}
            </div>
            <div>
              <h4 className="font-medium text-gray-900 dark:text-gray-100">{downloadStatus.region.name}</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400">{statusText}</p>
            </div>
          </div>
          
          {downloadStatus.status === 'downloading' && (
            <button
              onClick={onCancelDownload}
              className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
              aria-label="Cancelar download"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
        
        {downloadStatus.status === 'downloading' && (
          <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 rounded-full transition-all duration-300" 
              style={{ width: `${downloadStatus.progress}%` }}
            />
          </div>
        )}
      </div>
    );
  };

  // Renderiza informações de armazenamento
  const renderStorageInfo = () => {
    const usedPercentage = (storageInfo.used / storageInfo.total) * 100;
    const usedGB = (storageInfo.used / 1024).toFixed(1);
    const totalGB = (storageInfo.total / 1024).toFixed(1);
    
    return (
      <div className="mt-4">
        <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400 mb-1">
          <span>Armazenamento usado: {usedGB} GB de {totalGB} GB</span>
          <span>{usedPercentage.toFixed(1)}%</span>
        </div>
        <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div 
            className={`
              h-full rounded-full transition-all duration-300
              ${usedPercentage > 90 ? 'bg-red-500' : usedPercentage > 70 ? 'bg-yellow-500' : 'bg-green-500'}
            `}
            style={{ width: `${usedPercentage}%` }}
          />
        </div>
      </div>
    );
  };

  // Alternar entre mostrar todos os detalhes ou visão simplificada
  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className={`border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-800 ${className}`}>
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Mapas Offline</h2>
        <button
          onClick={toggleExpanded}
          className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
        >
          {isExpanded ? "Minimizar" : "Expandir"}
        </button>
      </div>
      
      {/* Conteúdo principal - visível apenas se expandido */}
      {isExpanded && (
        <>
          {/* Tabs */}
          <div className="border-b border-gray-200 dark:border-gray-700">
            <nav className="flex" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('regions')}
                className={`
                  py-3 px-4 text-sm font-medium border-b-2 transition-colors
                  ${activeTab === 'regions' ? 
                    'border-blue-500 text-blue-600 dark:text-blue-400' : 
                    'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'}
                `}
              >
                Regiões predefinidas
              </button>
              <button
                onClick={() => setActiveTab('map')}
                className={`
                  py-3 px-4 text-sm font-medium border-b-2 transition-colors
                  ${activeTab === 'map' ? 
                    'border-blue-500 text-blue-600 dark:text-blue-400' : 
                    'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'}
                `}
              >
                Selecionar no mapa
              </button>
            </nav>
          </div>
          
          {/* Conteúdo da tab ativa */}
          <div className="p-4">
            {activeTab === 'regions' ? renderRegionsList() : renderMapSelector()}
            
            {/* Progresso de download atual */}
            {renderDownloadProgress()}
            
            {/* Informações de armazenamento */}
            {renderStorageInfo()}
            
            {/* Botão de download */}
            <button
              onClick={handleDownloadRegion}
              disabled={activeTab === 'regions' && !selectedRegion}
              className={`
                mt-4 w-full py-2 px-4 rounded-md flex justify-center items-center
                ${(activeTab === 'regions' && !selectedRegion) ? 
                  'bg-gray-300 text-gray-500 cursor-not-allowed dark:bg-gray-700 dark:text-gray-500' : 
                  'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-700'}
              `}
            >
              <Download className="w-5 h-5 mr-2" />
              <span>Baixar {activeTab === 'regions' ? 'região selecionada' : 'área personalizada'}</span>
            </button>
          </div>
        </>
      )}
      
      {/* Visão simplificada - visível apenas se minimizado */}
      {!isExpanded && (
        <div className="p-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {downloadedRegions.length} {downloadedRegions.length === 1 ? 'região baixada' : 'regiões baixadas'}
              </p>
              <p className="text-xs text-gray-400 dark:text-gray-500">
                {(storageInfo.used / 1024).toFixed(1)} GB usados
              </p>
            </div>
            <button
              onClick={() => setIsExpanded(true)}
              className="py-2 px-4 bg-blue-100 hover:bg-blue-200 text-blue-700 text-sm font-medium rounded-md dark:bg-blue-900 dark:hover:bg-blue-800 dark:text-blue-300"
            >
              Gerenciar mapas
            </button>
          </div>
          
          {/* Mostrar progresso do download atual mesmo na visão minimizada */}
          {renderDownloadProgress()}
        </div>
      )}
    </div>
  );
};

export default OfflineMapSelector;