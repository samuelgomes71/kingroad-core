import React, { useState } from 'react';
import { AlertTriangle } from '../components';

const AlertDemo = () => {
  const [showAlerts, setShowAlerts] = useState({
    warning: false,
    danger: false,
    fullScreenWarning: false,
    fullScreenDanger: false,
    custom: false
  });
  
  return (
    <div className="p-6 bg-gray-900 text-white min-h-screen">
      <h1 className="text-2xl font-bold mb-6">King Road - Sistema de Alertas</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        <button 
          onClick={() => setShowAlerts({...showAlerts, warning: true})}
          className="p-4 bg-yellow-500 text-black rounded-lg font-bold hover:bg-yellow-400"
        >
          Mostrar Alerta Amarelo
        </button>
        
        <button 
          onClick={() => setShowAlerts({...showAlerts, danger: true})}
          className="p-4 bg-red-600 text-white rounded-lg font-bold hover:bg-red-500"
        >
          Mostrar Alerta Vermelho
        </button>
        
        <button 
          onClick={() => setShowAlerts({...showAlerts, fullScreenWarning: true})}
          className="p-4 bg-yellow-500 text-black rounded-lg font-bold hover:bg-yellow-400"
        >
          Alerta Amarelo (Tela Cheia)
        </button>
        
        <button 
          onClick={() => setShowAlerts({...showAlerts, fullScreenDanger: true})}
          className="p-4 bg-red-600 text-white rounded-lg font-bold hover:bg-red-500"
        >
          Alerta Vermelho (Tela Cheia)
        </button>
        
        <button 
          onClick={() => setShowAlerts({...showAlerts, custom: true})}
          className="p-4 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-500"
        >
          Alerta Personalizado
        </button>
      </div>
      
      {/* Exemplos de uso de alertas */}
      {showAlerts.warning && (
        <AlertTriangle 
          type="warning" 
          message="ATENÇÃO!"
          subMessage="Redução de velocidade à frente"
          onClose={() => setShowAlerts({...showAlerts, warning: false})}
          autoClose={5000}
        />
      )}
      
      {showAlerts.danger && (
        <AlertTriangle 
          type="danger" 
          message="PERIGO!"
          subMessage="Curva acentuada, reduza a velocidade"
          onClose={() => setShowAlerts({...showAlerts, danger: false})}
        />
      )}
      
      {showAlerts.fullScreenWarning && (
        <AlertTriangle 
          type="warning" 
          message="ATENÇÃO! TRECHO EM OBRAS"
          subMessage="Limite de velocidade: 40 km/h"
          onClose={() => setShowAlerts({...showAlerts, fullScreenWarning: false})}
          fullScreen={true}
        />
      )}
      
      {showAlerts.fullScreenDanger && (
        <AlertTriangle 
          type="danger" 
          message="PERIGO! SERRA ÍNGREME"
          subMessage="Use marcha reduzida. 80% dos acidentes neste trecho são causados por falha nos freios."
          onClose={() => setShowAlerts({...showAlerts, fullScreenDanger: false})}
          fullScreen={true}
        />
      )}
      
      {showAlerts.custom && (
        <AlertTriangle 
          type="custom" 
          message="VEÍCULO CARREGADO?"
          subMessage="Selecione para receber instruções específicas de segurança"
          onClose={() => setShowAlerts({...showAlerts, custom: false})}
          fullScreen={true}
        />
      )}
      
      <div className="mt-8 p-4 bg-gray-800 rounded-lg">
        <h2 className="text-xl font-bold mb-4">Instruções de Uso</h2>
        <p className="mb-2">Os triângulos de alerta do King Road podem ser usados em diversas situações:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><span className="text-yellow-400 font-bold">Amarelo</span>: Para alertas de atenção e avisos gerais</li>
          <li><span className="text-red-500 font-bold">Vermelho</span>: Para alertas críticos e situações de perigo</li>
          <li><span className="text-blue-400 font-bold">Personalizado</span>: Para outras necessidades específicas</li>
        </ul>
        <p className="mt-4">Os alertas podem ser configurados como:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Notificações na parte superior da tela</li>
          <li>Alertas de tela cheia para informações críticas</li>
          <li>Com fechamento automático ou manual</li>
        </ul>
      </div>
    </div>
  );
};

export default AlertDemo;