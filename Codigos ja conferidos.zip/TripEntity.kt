// TripEntity.kt
package com.kingroad.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.kingroad.database.converters.PointListConverter
import java.util.*

/**
 * Entidade de banco de dados que representa uma viagem no King Road
 */
@Entity(tableName = "trips")
@TypeConverters(PointListConverter::class)
data class TripEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    // Informações básicas da viagem
    val name: String,                 // Nome/descrição da viagem
    val startAddress: String,         // Endereço de origem
    val endAddress: String,           // Endereço de destino
    val startLat: Double,             // Latitude do ponto de origem
    val startLng: Double,             // Longitude do ponto de origem
    val endLat: Double,               // Latitude do destino
    val endLng: Double,               // Longitude do destino
    
    // Datas da viagem
    val startDate: Long,              // Data/hora de início da viagem (timestamp)
    val endDate: Long? = null,        // Data/hora de término (null se não concluída)
    val createdAt: Long = System.currentTimeMillis(), // Data de criação do registro
    
    // Estatísticas da viagem
    val distanceKm: Double,           // Distância total em quilômetros
    val estimatedDurationMinutes: Int, // Duração estimada em minutos
    val actualDurationMinutes: Int? = null, // Duração real (null se não concluída)
    
    // Pontos de interesse e rota
    val waypoints: List<GeoPoint> = emptyList(), // Lista de pontos da rota completa
    val poiIds: String = "",          // IDs dos pontos de interesse na rota, separados por vírgula
    
    // Flags de estado
    val isActive: Boolean = false,    // Flag indicando se é a viagem atual
    val isCompleted: Boolean = false, // Flag indicando se foi concluída
    val isFavorite: Boolean = false   // Flag indicando se é favorita
)

/**
 * Classe que representa um ponto geográfico com metadados
 */
data class GeoPoint(
    val lat: Double,           // Latitude
    val lng: Double,           // Longitude
    val type: Int = 0,         // Tipo do ponto (0=rota, 1=parada, 2=alerta, etc)
    val name: String? = null,  // Nome do ponto (opcional)
    val timestamp: Long? = null // Timestamp de quando o ponto foi registrado (opcional)
)