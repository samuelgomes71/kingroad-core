data class PrivateTruckParking(
    val id: String,
    val name: String,
    val location: Location,
    val parkingType: ParkingType,
    val accessControl: AccessControlType,
    val spots: List<ParkingSpot>,
    val facilities: ParkingFacilities,
    val reservation: ReservationSystem?,
    val payment: PaymentSystem,
    val securityFeatures: SecurityFeatures,
    val operatingHours: OperatingHours,
    val contact: ContactInfo,
    val lastUpdate: Long = System.currentTimeMillis()
)

enum class ParkingType {
    FULLY_PRIVATE,      // Todas as vagas são pagas (estilo Holanda/Bélgica)
    MIXED,              // Algumas vagas grátis, outras pagas (estilo EUA)
    RESERVATION_ONLY    // Apenas com reserva prévia
}

enum class AccessControlType {
    BARRIER_TICKET,     // Sistema de cancela com ticket (Europa)
    RESERVED_SPOTS,     // Vagas marcadas no chão (EUA/Canadá)
    MOBILE_APP,         // Controle via aplicativo
    CARD_ACCESS,        // Acesso com cartão
    GUARD_CONTROLLED    // Controlado por segurança
}

data class Location(
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val country: String,
    val accessRoutes: List<AccessRoute>
)

data class AccessRoute(
    val name: String,
    val instructions: String,
    val restrictions: List<Restriction>
)

data class Restriction(
    val type: String,
    val value: String,
    val description: String
)

data class ParkingSpot(
    val id: String,
    val type: SpotType,
    val size: SpotSize,
    val pricing: SpotPricing,
    val reservable: Boolean,
    val currentStatus: SpotStatus
)

enum class SpotType {
    STANDARD,           // Vaga padrão
    OVERSIZED,          // Para veículos maiores
    HAZMAT,            // Para cargas perigosas
    REFRIGERATED,      // Com conexão elétrica para refrigerados
    RESERVED_FLEET     // Reservada para frotas específicas
}

data class SpotSize(
    val length: Double,
    val width: Double,
    val heightLimit: Double?
)

data class SpotPricing(
    val currency: String,
    val hourlyRate: Double?,
    val dailyRate: Double,
    val weeklyRate: Double?,
    val monthlyRate: Double?,
    val minimumStay: Int? = null,     // em horas
    val maximumStay: Int? = null      // em horas
)

data class SpotStatus(
    val isOccupied: Boolean,
    val isReserved: Boolean,
    val nextAvailable: Long? = null,   // timestamp
    val reservedUntil: Long? = null    // timestamp
)

data class ReservationSystem(
    val supportedPlatforms: List<String>,  // "App", "Website", "Phone"
    val advanceBooking: Boolean,
    val minimumNotice: Int?,               // horas mínimas para reserva
    val maximumAdvance: Int?,              // dias máximos de antecedência
    val cancellationPolicy: String,
    val platformDetails: Map<String, String> // URLs, app names, etc
)

data class PaymentSystem(
    val methods: List<PaymentMethod>,
    val autoPayment: Boolean,              // Pagamento automático via app/tag
    val prepayment: Boolean,               // Necessário pagar antes
    val invoicing: Boolean                 // Faturamento para empresas
)

data class PaymentMethod(
    val type: String,
    val details: String,
    val surcharge: Double?
)

data class SecurityFeatures(
    val isGuarded: Boolean,
    val hasCctv: Boolean,
    val hasPerimeterFence: Boolean,
    val isLighted: Boolean,
    val hasPatrols: Boolean,
    val certifications: List<String>
)

data class ParkingFacilities(
    val hasRestrooms: Boolean,
    val hasShowers: Boolean,
    val hasRestArea: Boolean,
    val hasFood: Boolean,
    val hasWifi: Boolean,
    val electricalHookups: Boolean,
    val hasWaterSupply: Boolean,
    val hasWasteDisposal: Boolean
)

data class OperatingHours(
    val is24hours: Boolean,
    val schedule: Schedule?,
    val holidays: List<Holiday>
)

data class Schedule(
    val weekday: TimeRange,
    val saturday: TimeRange?,
    val sunday: TimeRange?
)

data class TimeRange(
    val start: String,  // "HH:mm"
    val end: String     // "HH:mm"
)

data class Holiday(
    val date: String,   // "MM-DD"
    val name: String,
    val schedule: TimeRange?
)

data class ContactInfo(
    val phone: String?,
    val emergency: String,
    val email: String?,
    val website: String?,
    val app: AppInfo?
)

data class AppInfo(
    val name: String,
    val ios: String?,   // App Store URL
    val android: String? // Play Store URL
)

class PrivateTruckParkingService(
    private val vehiclePOIService: VehicleSpecificPOIService
) {
    private val parkings = mutableMapOf<String, PrivateTruckParking>()

    fun addParking(parking: PrivateTruckParking) {
        parkings[parking.id] = parking
    }

    fun getNearbyParkings(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 50.0,
        vehicleConfig: VehicleConfiguration,
        filters: ParkingFilters = ParkingFilters()
    ): List<PrivateTruckParking> {
        // Validação de tipo de veículo
        if (!vehiclePOIService.shouldShowPOI(POIType.PRIVATE_TRUCK_PARKING, vehicleConfig)) {
            return emptyList()
        }

        return parkings.values.filter { parking ->
            // Verifica distância
            val distance = calculateDistance(
                latitude, longitude,
                parking.location.latitude, parking.location.longitude
            )
            
            if (distance > radiusKm) return@filter false

            // Aplica filtros
            if (filters.requiresReservation && parking.reservation == null) {
                return@filter false
            }

            if (filters.maxPrice > 0.0) {
                val hasAffordableSpots = parking.spots.any { spot ->
                    spot.pricing.hourlyRate?.let { it <= filters.maxPrice } ?: false
                }
                if (!hasAffordableSpots) return@filter false
            }

            if (filters.requiredFacilities.isNotEmpty()) {
                filters.requiredFacilities.all { facility ->
                    when (facility) {
                        "showers" -> parking.facilities.hasShowers
                        "food" -> parking.facilities.hasFood
                        "wifi" -> parking.facilities.hasWifi
                        "electrical" -> parking.facilities.electricalHookups
                        else -> true
                    }
                }
            }

            if (filters.securityLevel > 0) {
                val securityScore = calculateSecurityScore(parking.securityFeatures)
                if (securityScore < filters.securityLevel) return@filter false
            }

            true
        }.sortedBy { parking ->
            calculateDistance(
                latitude, longitude,
                parking.location.latitude, parking.location.longitude
            )
        }
    }

    data class ParkingFilters(
        val requiresReservation: Boolean = false,
        val maxPrice: Double = 0.0,
        val requiredFacilities: List<String> = listOf(),
        val securityLevel: Int = 0,  // 0-3: 0=básico, 3=máximo
        val spotType: SpotType? = null
    )

    private fun calculateSecurityScore(features: SecurityFeatures): Int {
        var score = 0
        if (features.isGuarded) score++
        if (features.hasCctv && features.hasPerimeterFence) score++
        if (features.hasPatrols) score++
        return score
    }

    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val R = 6371.0 // Raio da Terra em km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }
}