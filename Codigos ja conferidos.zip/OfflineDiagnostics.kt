package com.kingroad.cache

import android.content.Context
import android.util.Log
import com.kingroad.database.*
import com.kingroad.utils.FileUtils
import com.kingroad.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * Fornece relatório ao usuário sobre o estado da aplicação offline
 * (mapas carregados, fila pendente, satélite disponível, etc.)
 */
class OfflineDiagnostics(
    private val context: Context,
    private val mapRegionDao: MapRegionDao,
    private val poiDao: POIDao,
    private val localQueueDao: LocalQueueDao,
    private val attachmentDao: AttachmentDao,
    private val routeDao: RouteDao,
    private val offlineMapCacheManager: OfflineMapCacheManager? = null,
    private val localSyncQueue: LocalSyncQueue? = null,
    private val offlineAttachmentStore: OfflineAttachmentStore? = null,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher)
) {
    companion object {
        private const val TAG = "OfflineDiagnostics"
        
        // Status de disponibilidade de componentes offline
        enum class AvailabilityStatus {
            AVAILABLE,       // Disponível e funcional
            PARTIAL,         // Parcialmente disponível
            UNAVAILABLE,     // Indisponível
            UNKNOWN          // Estado desconhecido
        }
        
        // Categorias de componentes offline
        enum class ComponentCategory {
            MAPS,            // Mapas offline
            DATA,            // Dados offline (POIs, rotas, etc.)
            SYNC,            // Fila de sincronização
            ATTACHMENTS,     // Anexos offline
            STORAGE          // Armazenamento do dispositivo
        }
    }

    // Estado atual do diagnóstico
    private val _diagnosticsState = MutableStateFlow<DiagnosticsState>(DiagnosticsState.Idle)
    val diagnosticsState: StateFlow<DiagnosticsState> = _diagnosticsState.asStateFlow()
    
    // Job atual de diagnóstico
    private var currentDiagnosticsJob: Job? = null
    
    // Última data de atualização dos diagnósticos
    private var lastUpdateTimestamp: Long = 0
    
    // Último relatório gerado
    private var lastReport: DiagnosticsReport? = null

    /**
     * Realiza um diagnóstico completo da aplicação offline
     * @param forceRefresh Força a atualização mesmo se um diagnóstico recente existir
     * @return Job que pode ser aguardado para obter o resultado
     */
    fun runDiagnostics(forceRefresh: Boolean = false): Job {
        // Verifica se há um diagnóstico recente (menos de 5 minutos)
        val now = System.currentTimeMillis()
        if (!forceRefresh && 
            lastReport != null && 
            (now - lastUpdateTimestamp) < 5 * 60 * 1000) {
            _diagnosticsState.value = DiagnosticsState.Success(lastReport!!)
            return scope.launch { }
        }
        
        // Cancela job anterior se existir
        currentDiagnosticsJob?.cancel()
        
        _diagnosticsState.value = DiagnosticsState.Running
        
        val job = scope.launch {
            try {
                val report = collectDiagnosticsData()
                lastReport = report
                lastUpdateTimestamp = System.currentTimeMillis()
                _diagnosticsState.value = DiagnosticsState.Success(report)
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao executar diagnóstico: ${e.message}", e)
                _diagnosticsState.value = DiagnosticsState.Error(e.message ?: "Erro desconhecido")
            }
        }
        
        currentDiagnosticsJob = job
        return job
    }
    
    /**
     * Coleta dados de diagnóstico de todos os componentes
     */
    private suspend fun collectDiagnosticsData(): DiagnosticsReport = withContext(dispatcher) {
        val startTime = System.currentTimeMillis()
        
        // Diagnóstico do dispositivo
        val deviceInfo = collectDeviceInfo()
        
        // Diagnóstico dos mapas offline
        val mapsReport = collectMapsReport()
        
        // Diagnóstico da base de dados offline
        val dataReport = collectDataReport()
        
        // Diagnóstico da fila de sincronização
        val syncReport = collectSyncReport()
        
        // Diagnóstico dos anexos offline
        val attachmentsReport = collectAttachmentsReport()
        
        // Diagnóstico do armazenamento
        val storageReport = collectStorageReport()
        
        // Status global da aplicação offline
        val overallStatus = calculateOverallStatus(
            mapsReport, dataReport, syncReport, attachmentsReport, storageReport
        )
        
        // Criação do relatório completo
        val report = DiagnosticsReport(
            timestamp = System.currentTimeMillis(),
            deviceInfo = deviceInfo,
            mapsReport = mapsReport,
            dataReport = dataReport,
            syncReport = syncReport,
            attachmentsReport = attachmentsReport,
            storageReport = storageReport,
            overallStatus = overallStatus,
            diagnosticsDurationMs = System.currentTimeMillis() - startTime
        )
        
        // Log para debugging
        Log.d(TAG, "Diagnóstico concluído em ${report.diagnosticsDurationMs}ms. Status geral: $overallStatus")
        
        return@withContext report
    }
    
    /**
     * Coleta informações sobre o dispositivo
     */
    private suspend fun collectDeviceInfo(): DeviceInfo = withContext(dispatcher) {
        val isNetworkAvailable = NetworkUtils.isConnected(context)
        val isWifiConnected = NetworkUtils.isWifiConnected(context)
        val availableStorage = FileUtils.getAvailableStorageSpaceInMB(context)
        val totalStorage = FileUtils.getTotalStorageSpaceInMB(context)
        
        return@withContext DeviceInfo(
            isNetworkAvailable = isNetworkAvailable,
            networkType = if (isNetworkAvailable) {
                if (isWifiConnected) "WIFI" else "MÓVEL"
            } else {
                "DESCONECTADO"
            },
            availableStorageMB = availableStorage,
            totalStorageMB = totalStorage,
            storagePercentage = if (totalStorage > 0) {
                (availableStorage.toDouble() / totalStorage.toDouble() * 100).toInt()
            } else {
                0
            },
            deviceTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
            androidVersion = android.os.Build.VERSION.RELEASE,
            appVersion = try {
                val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                packageInfo.versionName
            } catch (e: Exception) {
                "Desconhecido"
            }
        )
    }
    
    /**
     * Coleta informações sobre os mapas offline
     */
    private suspend fun collectMapsReport(): MapsReport = withContext(dispatcher) {
        // Busca regiões de mapas disponíveis
        val mapRegions = mapRegionDao.getAllRegions()
        
        // Calcula tamanho total dos mapas
        var totalMapSizeKB = 0L
        mapRegions.forEach { region ->
            totalMapSizeKB += region.size
        }
        
        // Verifica disponibilidade do cache manager
        val hasOfflineMapsManager = offlineMapCacheManager != null
        
        // Calcula a área total coberta (em km²)
        var totalCoverageAreaKm2 = 0.0
        mapRegions.forEach { region ->
            val latDiff = region.maxLat - region.minLat
            val lngDiff = region.maxLng - region.minLng
            
            // Aproximação simples da área (não leva em conta a curvatura da Terra)
            val areaKm2 = latDiff * lngDiff * 111.0 * 111.0
            totalCoverageAreaKm2 += areaKm2
        }
        
        // Determina o status geral dos mapas
        val mapsStatus = when {
            mapRegions.isEmpty() -> AvailabilityStatus.UNAVAILABLE
            mapRegions.size >= 5 -> AvailabilityStatus.AVAILABLE
            else -> AvailabilityStatus.PARTIAL
        }
        
        return@withContext MapsReport(
            availableRegions = mapRegions.map { it.name },
            totalRegions = mapRegions.size,
            totalSizeMB = totalMapSizeKB / 1024.0,
            coverageAreaKm2 = totalCoverageAreaKm2,
            maxZoomLevel = mapRegions.maxOfOrNull { it.maxZoom } ?: 0,
            minZoomLevel = mapRegions.minOfOrNull { it.minZoom } ?: 0,
            oldestRegionDate = mapRegions.minOfOrNull { it.downloadDate } ?: 0,
            newestRegionDate = mapRegions.maxOfOrNull { it.downloadDate } ?: 0,
            mapsStatus = mapsStatus,
            hasTileProvider = hasOfflineMapsManager
        )
    }
    
    /**
     * Coleta informações sobre os dados offline
     */
    private suspend fun collectDataReport(): DataReport = withContext(dispatcher) {
        // Contagens das diferentes entidades
        val poisCount = poiDao.getTotalCount()
        val routesCount = routeDao.getTotalCount()
        
        // Obtém estatísticas de POIs por tipo
        val poiTypes = poiDao.getCountByType()
        
        // Obtém estatísticas de rotas
        val totalRouteDistanceKm = routeDao.getTotalRouteDistanceKm()
        val userCreatedRoutesCount = routeDao.getUserCreatedRoutesCount()
        
        // Última atualização
        val lastPoiUpdate = poiDao.getLatestTimestamp() ?: 0
        val lastRouteUpdate = routeDao.getLatestTimestamp() ?: 0
        val lastDataUpdate = maxOf(lastPoiUpdate, lastRouteUpdate)
        
        // Determina o status geral dos dados
        val dataStatus = when {
            poisCount == 0 && routesCount == 0 -> AvailabilityStatus.UNAVAILABLE
            poisCount > 1000 && routesCount > 10 -> AvailabilityStatus.AVAILABLE
            else -> AvailabilityStatus.PARTIAL
        }
        
        return@withContext DataReport(
            poisCount = poisCount,
            routesCount = routesCount,
            poiTypeDistribution = poiTypes,
            totalRouteDistanceKm = totalRouteDistanceKm,
            userCreatedRoutesCount = userCreatedRoutesCount,
            lastDataUpdateTimestamp = lastDataUpdate,
            dataStatus = dataStatus
        )
    }
    
    /**
     * Coleta informações sobre a fila de sincronização
     */
    private suspend fun collectSyncReport(): SyncReport = withContext(dispatcher) {
        // Obtém itens pendentes
        val pendingItemsCount = localQueueDao.getPendingItemsCount()
        
        // Obtém distribuição por tipo
        val itemsByType = localQueueDao.getItemCountByType()
        
        // Obtém distribuição por status de retry
        val itemsByRetryCount = localQueueDao.getItemCountByRetryCount()
        
        // Item mais antigo
        val oldestItem = localQueueDao.getOldestItem()
        val oldestItemTimestamp = oldestItem?.createdAt ?: 0
        
        // Verifica status do componente
        val hasSyncQueue = localSyncQueue != null
        
        // Determina o status geral da sincronização
        val syncStatus = when {
            !hasSyncQueue -> AvailabilityStatus.UNAVAILABLE
            pendingItemsCount == 0 -> AvailabilityStatus.AVAILABLE
            pendingItemsCount > 100 -> AvailabilityStatus.PARTIAL
            else -> AvailabilityStatus.AVAILABLE
        }
        
        return@withContext SyncReport(
            pendingItemsCount = pendingItemsCount,
            itemsByType = itemsByType,
            itemsByRetryCount = itemsByRetryCount,
            oldestItemTimestamp = oldestItemTimestamp,
            hasSyncQueue = hasSyncQueue,
            syncStatus = syncStatus
        )
    }
    
    /**
     * Coleta informações sobre os anexos offline
     */
    private suspend fun collectAttachmentsReport(): AttachmentsReport = withContext(dispatcher) {
        // Obtém contagem de anexos
        val totalAttachments = attachmentDao.getTotalCount()
        
        // Obtém distribuição por categoria
        val attachmentsByCategory = attachmentDao.getCountByCategory()
        
        // Obtém distribuição por status
        val attachmentsByStatus = attachmentDao.getCountByStatus()
        
        // Calcula tamanho total
        val totalSizeBytes = attachmentDao.getTotalSizeBytes()
        
        // Verifica status do componente
        val hasAttachmentStore = offlineAttachmentStore != null
        
        // Determina o status geral dos anexos
        val attachmentsStatus = when {
            !hasAttachmentStore -> AvailabilityStatus.UNAVAILABLE
            totalAttachments == 0 -> AvailabilityStatus.PARTIAL
            else -> AvailabilityStatus.AVAILABLE
        }
        
        return@withContext AttachmentsReport(
            totalAttachments = totalAttachments,
            attachmentsByCategory = attachmentsByCategory,
            attachmentsByStatus = attachmentsByStatus,
            totalSizeMB = totalSizeBytes / (1024.0 * 1024.0),
            hasAttachmentStore = hasAttachmentStore,
            attachmentsStatus = attachmentsStatus
        )
    }
    
    /**
     * Coleta informações sobre o armazenamento
     */
    private suspend fun collectStorageReport(): StorageReport = withContext(dispatcher) {
        // Diretórios principais
        val appDir = context.filesDir
        val cacheDir = context.cacheDir
        
        // Tamanho dos diretórios principais
        val appDirSizeMB = FileUtils.getFolderSizeInBytes(appDir) / (1024.0 * 1024.0)
        val cacheDirSizeMB = FileUtils.getFolderSizeInBytes(cacheDir) / (1024.0 * 1024.0)
        
        // Informações de armazenamento
        val availableStorage = FileUtils.getAvailableStorageSpaceInMB(context)
        val totalStorage = FileUtils.getTotalStorageSpaceInMB(context)
        val usedStorage = totalStorage - availableStorage
        
        // Para cada componente offline, calcula o espaço usado
        val mapsCacheDir = File(appDir, "map_cache")
        val mapsCacheSizeMB = if (mapsCacheDir.exists()) {
            FileUtils.getFolderSizeInBytes(mapsCacheDir) / (1024.0 * 1024.0)
        } else {
            0.0
        }
        
        val attachmentsDir = File(appDir, "attachments")
        val attachmentsSizeMB = if (attachmentsDir.exists()) {
            FileUtils.getFolderSizeInBytes(attachmentsDir) / (1024.0 * 1024.0)
        } else {
            0.0
        }
        
        // Determina o status geral do armazenamento
        val storageStatus = when {
            availableStorage < 100 -> AvailabilityStatus.PARTIAL // Menos de 100MB disponível
            availableStorage < 50 -> AvailabilityStatus.UNAVAILABLE // Menos de 50MB disponível
            else -> AvailabilityStatus.AVAILABLE
        }
        
        return@withContext StorageReport(
            availableStorageMB = availableStorage,
            usedStorageMB = usedStorage,
            totalStorageMB = totalStorage,
            appDataSizeMB = appDirSizeMB,
            cacheSizeMB = cacheDirSizeMB,
            mapsCacheSizeMB = mapsCacheSizeMB,
            attachmentsSizeMB = attachmentsSizeMB,
            storageStatus = storageStatus
        )
    }
    
    /**
     * Calcula o status geral da aplicação offline
     */
    private fun calculateOverallStatus(
        mapsReport: MapsReport,
        dataReport: DataReport,
        syncReport: SyncReport,
        attachmentsReport: AttachmentsReport,
        storageReport: StorageReport
    ): AvailabilityStatus {
        // Lista de todos os status
        val statuses = listOf(
            mapsReport.mapsStatus,
            dataReport.dataStatus,
            syncReport.syncStatus,
            attachmentsReport.attachmentsStatus,
            storageReport.storageStatus
        )
        
        // Regras para determinar o status geral
        return when {
            // Se algum componente essencial estiver indisponível, o sistema está parcialmente disponível
            statuses.contains(AvailabilityStatus.UNAVAILABLE) -> {
                // Se os mapas ou dados estiverem indisponíveis, o sistema está indisponível
                if (mapsReport.mapsStatus == AvailabilityStatus.UNAVAILABLE || 
                    dataReport.dataStatus == AvailabilityStatus.UNAVAILABLE) {
                    AvailabilityStatus.UNAVAILABLE
                } else {
                    AvailabilityStatus.PARTIAL
                }
            }
            // Se todos os componentes estiverem disponíveis, o sistema está disponível
            statuses.all { it == AvailabilityStatus.AVAILABLE } -> AvailabilityStatus.AVAILABLE
            // Se algum componente estiver parcialmente disponível, o sistema está parcialmente disponível
            else -> AvailabilityStatus.PARTIAL
        }
    }
    
    /**
     * Cancela o diagnóstico atual
     */
    fun cancelDiagnostics() {
        currentDiagnosticsJob?.cancel()
        currentDiagnosticsJob = null
        _diagnosticsState.value = DiagnosticsState.Idle
    }
    
    /**
     * Exporta o diagnóstico como JSON
     * @param includeDeviceInfo Se true, inclui informações do dispositivo
     * @return String com o diagnóstico em formato JSON
     */
    fun exportAsJson(includeDeviceInfo: Boolean = true): String {
        val report = lastReport ?: return "{\"error\": \"No diagnostic report available\"}"
        
        val json = JSONObject()
        
        // Informações gerais
        json.put("timestamp", report.timestamp)
        json.put("overallStatus", report.overallStatus.toString())
        json.put("diagnosticsDurationMs", report.diagnosticsDurationMs)
        
        // Informações do dispositivo
        if (includeDeviceInfo) {
            val deviceJson = JSONObject()
            deviceJson.put("isNetworkAvailable", report.deviceInfo.isNetworkAvailable)
            deviceJson.put("networkType", report.deviceInfo.networkType)
            deviceJson.put("availableStorageMB", report.deviceInfo.availableStorageMB)
            deviceJson.put("totalStorageMB", report.deviceInfo.totalStorageMB)
            deviceJson.put("storagePercentage", report.deviceInfo.storagePercentage)
            deviceJson.put("deviceTime", report.deviceInfo.deviceTime)
            deviceJson.put("androidVersion", report.deviceInfo.androidVersion)
            deviceJson.put("appVersion", report.deviceInfo.appVersion)
            json.put("deviceInfo", deviceJson)
        }
        
        // Relatório de mapas
        val mapsJson = JSONObject()
        mapsJson.put("availableRegions", report.mapsReport.availableRegions.joinToString(","))
        mapsJson.put("totalRegions", report.mapsReport.totalRegions)
        mapsJson.put("totalSizeMB", report.mapsReport.totalSizeMB)
        mapsJson.put("coverageAreaKm2", report.mapsReport.coverageAreaKm2)
        mapsJson.put("maxZoomLevel", report.mapsReport.maxZoomLevel)
        mapsJson.put("minZoomLevel", report.mapsReport.minZoomLevel)
        mapsJson.put("oldestRegionDate", report.mapsReport.oldestRegionDate)
        mapsJson.put("newestRegionDate", report.mapsReport.newestRegionDate)
        mapsJson.put("mapsStatus", report.mapsReport.mapsStatus.toString())
        mapsJson.put("hasTileProvider", report.mapsReport.hasTileProvider)
        json.put("mapsReport", mapsJson)
        
        // Relatório de dados
        val dataJson = JSONObject()
        dataJson.put("poisCount", report.dataReport.poisCount)
        dataJson.put("routesCount", report.dataReport.routesCount)
        
        val poiTypesJson = JSONObject()
        report.dataReport.poiTypeDistribution.forEach { (type, count) ->
            poiTypesJson.put(type, count)
        }
        dataJson.put("poiTypeDistribution", poiTypesJson)
        
        dataJson.put("totalRouteDistanceKm", report.dataReport.totalRouteDistanceKm)
        dataJson.put("userCreatedRoutesCount", report.dataReport.userCreatedRoutesCount)
        dataJson.put("lastDataUpdateTimestamp", report.dataReport.lastDataUpdateTimestamp)
        dataJson.put("dataStatus", report.dataReport.dataStatus.toString())
        json.put("dataReport", dataJson)
        
        // Relatório de sincronização
        val syncJson = JSONObject()
        syncJson.put("pendingItemsCount", report.syncReport.pendingItemsCount)
        
        val itemsByTypeJson = JSONObject()
        report.syncReport.itemsByType.forEach { (type, count) ->
            itemsByTypeJson.put(type, count)
        }
        syncJson.put("itemsByType", itemsByTypeJson)
        
        val itemsByRetryJson = JSONObject()
        report.syncReport.itemsByRetryCount.forEach { (retry, count) ->
            itemsByRetryJson.put(retry.toString(), count)
        }
        syncJson.put("itemsByRetryCount", itemsByRetryJson)
        
        syncJson.put("oldestItemTimestamp", report.syncReport.oldestItemTimestamp)
        syncJson.put("hasSyncQueue", report.syncReport.hasSyncQueue)
        syncJson.put("syncStatus", report.syncReport.syncStatus.toString())
        json.put("syncReport", syncJson)
        
        // Relatório de anexos
        val attachmentsJson = JSONObject()
        attachmentsJson.put("totalAttachments", report.attachmentsReport.totalAttachments)
        
        val attachmentsByCategoryJson = JSONObject()
        report.attachmentsReport.attachmentsByCategory.forEach { (category, count) ->
            attachmentsByCategoryJson.put(category, count)
        }
        attachmentsJson.put("attachmentsByCategory", attachmentsByCategoryJson)
        
        val attachmentsByStatusJson = JSONObject()
        report.attachmentsReport.attachmentsByStatus.forEach { (status, count) ->
            attachmentsByStatusJson.put(status, count)
        }
        attachmentsJson.put("attachmentsByStatus", attachmentsByStatusJson)
        
        attachmentsJson.put("totalSizeMB", report.attachmentsReport.totalSizeMB)
        attachmentsJson.put("hasAttachmentStore", report.attachmentsReport.hasAttachmentStore)
        attachmentsJson.put("attachmentsStatus", report.attachmentsReport.attachmentsStatus.toString())
        json.put("attachmentsReport", attachmentsJson)
        
        // Relatório de armazenamento
        val storageJson = JSONObject()
        storageJson.put("availableStorageMB", report.storageReport.availableStorageMB)
        storageJson.put("usedStorageMB", report.storageReport.usedStorageMB)
        storageJson.put("totalStorageMB", report.storageReport.totalStorageMB)
        storageJson.put("appDataSizeMB", report.storageReport.appDataSizeMB)
        storageJson.put("cacheSizeMB", report.storageReport.cacheSizeMB)
        storageJson.put("mapsCacheSizeMB", report.storageReport.mapsCacheSizeMB)
        storageJson.put("attachmentsSizeMB", report.storageReport.attachmentsSizeMB)
        storageJson.put("storageStatus", report.storageReport.storageStatus.toString())
        json.put("storageReport", storageJson)
        
        return json.toString(2)
    }
    
    /**
     * Libera recursos
     */
    fun shutdown() {
        currentDiagnosticsJob?.cancel()
        currentDiagnosticsJob = null
    }
    
    /**
     * Data class que representa um relatório de diagnóstico completo
     */
    data class DiagnosticsReport(
        val timestamp: Long,
        val deviceInfo: DeviceInfo,
        val mapsReport: MapsReport,
        val dataReport: DataReport,
        val syncReport: SyncReport,
        val attachmentsReport: AttachmentsReport,
        val storageReport: StorageReport,
        val overallStatus: AvailabilityStatus,
        val diagnosticsDurationMs: Long
    )
    
    /**
     * Data class que representa informações sobre o dispositivo
     */
    data class DeviceInfo(
        val isNetworkAvailable: Boolean,
        val networkType: String,
        val availableStorageMB: Long,
        val totalStorageMB: Long,
        val storagePercentage: Int,
        val deviceTime: String,
        val androidVersion: String,
        val appVersion: String
    )
    
    /**
     * Data class que representa um relatório de mapas offline
     */
    data class MapsReport(
        val availableRegions: List<String>,
        val totalRegions: Int,
        val totalSizeMB: Double,
        val coverageAreaKm2: Double,
        val maxZoomLevel: Int,
        val minZoomLevel: Int,
        val oldestRegionDate: Long,
        val newestRegionDate: Long,
        val mapsStatus: AvailabilityStatus,
        val hasTileProvider: Boolean
    )
    
    /**
     * Data class que representa um relatório de dados offline
     */
    data class DataReport(
        val poisCount: Int,
        val routesCount: Int,
        val poiTypeDistribution: Map<String, Int>,
        val totalRouteDistanceKm: Double,
        val userCreatedRoutesCount: Int,
        val lastDataUpdateTimestamp: Long,
        val dataStatus: AvailabilityStatus
    )
    
    /**
     * Data class que representa um relatório de sincronização
     */
    data class SyncReport(
        val pendingItemsCount: Int,
        val itemsByType: Map<String, Int>,
        val itemsByRetryCount: Map<Int, Int>,
        val oldestItemTimestamp: Long,
        val hasSyncQueue: Boolean,
        val syncStatus: AvailabilityStatus
    )
    
    /**
     * Data class que representa um relatório de anexos offline
     */
    data class AttachmentsReport(
        val totalAttachments: Int,
        val attachmentsByCategory: Map<String, Int>,
        val attachmentsByStatus: Map<String, Int>,
        val totalSizeMB: Double,
        val hasAttachmentStore: Boolean,
        val attachmentsStatus: AvailabilityStatus
    )
    
    /**
     * Data class que representa um relatório de armazenamento
     */
    data class StorageReport(
        val availableStorageMB: Long,
        val usedStorageMB: Long,
        val totalStorageMB: Long,
        val appDataSizeMB: Double,
        val cacheSizeMB: Double,
        val mapsCacheSizeMB: Double,
        val attachmentsSizeMB: Double,
        val storageStatus: AvailabilityStatus
    )
    
    /**
     * Sealed class que representa o estado do diagnóstico
     */
    sealed class DiagnosticsState {
        object Idle : DiagnosticsState()
        object Running : DiagnosticsState()
        data class Success(val report: DiagnosticsReport) : DiagnosticsState()
        data class Error(val message: String) : DiagnosticsState()
    }
}