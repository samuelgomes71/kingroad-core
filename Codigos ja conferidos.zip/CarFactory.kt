data class CarFactory(
    val id: String,
    val name: String,
    val manufacturer: String,
    val location: Location,
    val country: String,
    val address: String,
    val loadingPoints: List<LoadingPoint>,
    val operatingHours: OperatingHours,
    val contact: ContactInfo,
    val facilities: FactoryFacilities,
    val securityRequirements: SecurityRequirements,
    val vehicles: List<VehicleType>,
    val lastUpdate: Long = System.currentTimeMillis()
)