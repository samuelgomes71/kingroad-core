import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  RefreshCw,
  Download,
  Activity,
  Settings,
  Info
} from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import StorageService from '../utils/StorageService';
import DatabaseService from '../database/DatabaseService';
import MapCacheService from '../cache/MapCacheService';

const SystemDiagnostics = () => {
  // Estados para diagnóstico e testes
  const [testResults, setTestResults] = useState({});
  const [isRunning, setIsRunning] = useState(false);
  const [errorLog, setErrorLog] = useState([]);
  const [storageStatus, setStorageStatus] = useState(null);

  // Carregar logs de erro do armazenamento ao montar o componente
  useEffect(() => {
    const loadErrorLogs = async () => {
      try {
        const savedLogs = await StorageService.getData('error_logs');
        if (savedLogs) {
          setErrorLog(savedLogs);
        }
      } catch (error) {
        console.error('Erro ao carregar logs:', error);
      }
    };
    
    loadErrorLogs();
  }, []);

  // Funções de teste básicas
  const runStorageTest = async () => {
    try {
      const testKey = 'test_storage';
      await StorageService.saveData(testKey, 'test');
      const testData = await StorageService.getData(testKey);
      const result = testData === 'test';
      await StorageService.removeData(testKey);
      return result;
    } catch (error) {
      logError('Storage Test', error);
      return false;
    }
  };

  const runConnectionTest = () => {
    return navigator.onLine;
  };

  const runDatabaseTest = async () => {
    try {
      // Tentativa de inicializar o banco de dados
      await DatabaseService.initDatabase();
      return true;
    } catch (error) {
      logError('Database Test', error);
      return false;
    }
  };

  const runCacheTest = async () => {
    try {
      // Obter cache index
      const cacheIndex = await MapCacheService.getCacheIndex();
      return true;
    } catch (error) {
      logError('Cache Test', error);
      return false;
    }
  };

  const checkStorageSpace = async () => {
    try {
      let used = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        used += (key.length + (value ? value.length : 0));
      }

      // Converter para KB
      used = Math.round(used / 1024);
      
      // Obter tamanho do cache de mapas
      try {
        const mapCacheInfo = await MapCacheService.getCachedTiles();
        if (mapCacheInfo && mapCacheInfo.totalSizeBytes) {
          used += Math.round(mapCacheInfo.totalSizeBytes / 1024);
        }
      } catch (error) {
        console.warn('Erro ao obter tamanho do cache de mapas:', error);
      }
      
      return {
        used,
        total: 5120, // Estimativa de 5MB
        percentage: Math.min(100, Math.round((used / 5120) * 100))
      };
    } catch (error) {
      logError('Storage Space Check', error);
      return null;
    }
  };

  // Logger de erros
  const logError = (context, error) => {
    const newLog = {
      context,
      message: error.message || 'Erro desconhecido',
      timestamp: new Date().toISOString()
    };
    
    setErrorLog(prev => {
      const updated = [newLog, ...prev].slice(0, 50); // Manter no máximo 50 logs
      
      // Salvar logs no armazenamento
      StorageService.saveData('error_logs', updated)
        .catch(e => console.error('Erro ao salvar logs:', e));
      
      return updated;
    });
  };

  // Executar todos os testes
  const runAllTests = async () => {
    setIsRunning(true);
    
    try {
      const storageResult = await runStorageTest();
      const connectionResult = runConnectionTest();
      const databaseResult = await runDatabaseTest();
      const cacheResult = await runCacheTest();
      const spaceInfo = await checkStorageSpace();
      
      const results = {
        storage: storageResult,
        connection: connectionResult,
        database: databaseResult,
        cache: cacheResult,
        space: spaceInfo
      };
      
      setTestResults(results);
      setStorageStatus(spaceInfo);
    } catch (error) {
      logError('Test Suite', error);
    } finally {
      setIsRunning(false);
    }
  };

  // Limpar cache
  const clearCache = async () => {
    try {
      setIsRunning(true);
      
      // Limpar cache de mapas
      await MapCacheService.clearCache({ all: true });
      
      // Limpar armazenamento local (preservando logs de erro)
      const logs = await StorageService.getData('error_logs');
      await StorageService.clearAll();
      if (logs) {
        await StorageService.saveData('error_logs', logs);
      }
      
      // Executar testes novamente
      await runAllTests();
    } catch (error) {
      logError('Cache Clear', error);
    } finally {
      setIsRunning(false);
    }
  };

  // Exportar backup
  const exportBackup = async () => {
    try {
      // Coletar dados para backup
      const backup = {
        localStorage: {},
        errorLogs: errorLog,
        timestamp: Date.now(),
        device: navigator.userAgent,
        version: '1.0.0'
      };
      
      // Obter todos os dados do localStorage
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        try {
          backup.localStorage[key] = JSON.parse(localStorage.getItem(key));
        } catch (e) {
          backup.localStorage[key] = localStorage.getItem(key);
        }
      }
      
      // Criar e baixar o arquivo
      const dataStr = JSON.stringify(backup, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kingroad_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      logError('Backup Export', error);
    }
  };

  // Componente de Resultados
  const TestResults = () => (
    <div className="space-y-3">
      {Object.entries(testResults).map(([key, value]) => {
        if (key === 'space') return null;
        return (
          <div key={key} className="flex items-center justify-between bg-gray-800 p-3 rounded">
            <div className="flex items-center">
              {value ? (
                <CheckCircle className="text-green-500 mr-2" size={20} />
              ) : (
                <XCircle className="text-red-500 mr-2" size={20} />
              )}
              <span className="text-white capitalize">
                {key === 'storage' && 'Armazenamento Local'}
                {key === 'connection' && 'Conexão'}
                {key === 'database' && 'Banco de Dados'}
                {key === 'cache' && 'Cache de Mapas'}
              </span>
            </div>
            <span className={value ? 'text-green-500' : 'text-red-500'}>
              {value ? 'OK' : 'Falha'}
            </span>
          </div>
        );
      })}
    </div>
  );

  // Componente de Status de Armazenamento
  const StorageStatus = () => (
    storageStatus && (
      <div className="mt-4 bg-gray-800 p-4 rounded">
        <h3 className="text-white font-medium mb-2">Status do Armazenamento</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-gray-400">Usado</span>
            <span className="text-white">{storageStatus.used} KB</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Total</span>
            <span className="text-white">{storageStatus.total} KB</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Porcentagem</span>
            <span className={storageStatus.percentage > 80 ? 'text-red-500' : 'text-white'}>
              {storageStatus.percentage}%
            </span>
          </div>
          <div className="h-2 bg-gray-700 rounded overflow-hidden">
            <div 
              className={`h-full ${
                storageStatus.percentage > 90 ? 'bg-red-600' : 
                storageStatus.percentage > 70 ? 'bg-yellow-600' : 
                'bg-blue-600'
              }`}
              style={{ width: `${storageStatus.percentage}%` }}
            />
          </div>
        </div>
      </div>
    )
  );

  // Componente de Log de Erros
  const ErrorLog = () => (
    <div className="mt-4">
      <h3 className="text-white font-medium mb-2 flex items-center">
        <AlertTriangle size={16} className="text-amber-500 mr-2" />
        Log de Erros
      </h3>
      <div className="bg-gray-800 rounded max-h-48 overflow-y-auto">
        {errorLog.length === 0 ? (
          <p className="text-gray-400 p-3">Nenhum erro registrado</p>
        ) : (
          errorLog.map((log, index) => (
            <div key={index} className="p-3 border-b border-gray-700">
              <div className="flex justify-between">
                <span className="text-red-500">{log.context}</span>
                <span className="text-gray-400 text-sm">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <p className="text-white mt-1">{log.message}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );

  // Ações de Manutenção
  const MaintenanceActions = () => (
    <div className="mt-4">
      <h3 className="text-white font-medium mb-2">Ações de Manutenção</h3>
      <div className="grid grid-cols-2 gap-3">
        <button 
          className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded flex items-center justify-center"
          onClick={clearCache}
          disabled={isRunning}
        >
          <RefreshCw size={16} className="mr-2" />
          Limpar Cache
        </button>
        <button 
          className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded flex items-center justify-center"
          onClick={exportBackup}
          disabled={isRunning}
        >
          <Download size={16} className="mr-2" />
          Backup Dados
        </button>
      </div>
    </div>
  );

  return (
    <div className="bg-gray-900 p-4 rounded-lg">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl text-white font-bold">Diagnóstico do Sistema</h2>
        <button 
          className={`${isRunning ? 'bg-gray-600' : 'bg-blue-600 hover:bg-blue-700'} text-white px-4 py-2 rounded flex items-center`}
          onClick={runAllTests}
          disabled={isRunning}
        >
          <Activity size={16} className={`mr-2 ${isRunning ? 'animate-spin' : ''}`} />
          {isRunning ? 'Executando...' : 'Executar Testes'}
        </button>
      </div>

      <TestResults />
      <StorageStatus />
      <ErrorLog />
      <MaintenanceActions />
    </div>
  );
};

export default SystemDiagnostics;