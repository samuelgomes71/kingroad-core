import { logEvent } from '../services/analyticsService';
import { calculateRoute } from '../services/navigationService';
import { saveRouteHistory, getRecentRoutes } from '../services/historyService';

/**
 * useNavigationActions - Funções principais do módulo de navegação do KingRoad
 */
const useNavigationActions = ({
  currentLocation,
  vehicleSpecs,
  waypoints,
  routeOptions,
  setCurrentRoute,
  setAlternativeRoutes,
  setDestination,
  setEta,
  setDistance,
  setShowRouteDetails,
  setIsNavigating,
  mapRef,
  audioEnabled,
  playVoiceInstruction,
  showAlert,
  hideAlert,
  fetchTrafficAlerts,
  t
}) => {
  /**
   * Calcula a rota até um destino
   */
  const handleRouteCalculation = async (dest) => {
    try {
      if (!currentLocation) {
        showAlert({
          type: 'error',
          message: t('Não foi possível obter sua localização atual'),
          duration: 3000
        });
        return;
      }

      logEvent('route_calculation_started', {
        origin: `${currentLocation.latitude},${currentLocation.longitude}`,
        destination: `${dest.latitude},${dest.longitude}`,
        vehicleType: vehicleSpecs.type
      });

      showAlert({
        type: 'info',
        message: t('Calculando sua rota, aguarde...'),
        autoHide: false,
        id: 'route-calculation'
      });

      const routeResult = await calculateRoute(
        currentLocation,
        dest,
        waypoints,
        routeOptions,
        vehicleSpecs
      );

      hideAlert('route-calculation');

      if (!routeResult.success) {
        throw new Error(routeResult.error || 'Erro desconhecido no cálculo da rota');
      }

      setCurrentRoute(routeResult.route);
      setAlternativeRoutes(routeResult.alternatives || []);
      setDestination(dest);
      setEta(routeResult.eta);
      setDistance(routeResult.distance);

      if (dest.name) {
        await saveRouteHistory({
          destination: dest,
          timestamp: new Date().toISOString(),
          distance: routeResult.distance,
          estimatedDuration: routeResult.duration
        });

        const recent = await getRecentRoutes();
        setRecentDestinations(recent);
      }

      checkRouteHazards(routeResult.route);
      setShowRouteDetails(true);

      logEvent('route_calculation_completed', {
        origin: `${currentLocation.latitude},${currentLocation.longitude}`,
        destination: `${dest.latitude},${dest.longitude}`,
        distance: routeResult.distance,
        estimatedDuration: routeResult.duration,
        alternativeRoutesCount: routeResult.alternatives?.length || 0
      });

      return routeResult;
    } catch (error) {
      console.error('Erro no cálculo da rota:', error);
      hideAlert('route-calculation');
      showAlert({
        type: 'error',
        message: t('Não foi possível calcular uma rota para este destino'),
        duration: 5000
      });

      logEvent('route_calculation_error', {
        error: error.message,
        origin: currentLocation ? `${currentLocation.latitude},${currentLocation.longitude}` : 'unknown',
        destination: dest ? `${dest.latitude},${dest.longitude}` : 'unknown'
      });

      return null;
    }
  };

  /**
   * Verifica riscos e restrições especiais na rota
   */
  const checkRouteHazards = (route) => {
    try {
      const hazards = route.hazards || [];
      if (hazards.length > 0) {
        const hazardMessage = hazards.map(h => `- ${h.type}: ${h.description} (km ${h.distance})`).join('\n');
        showAlert({
          type: 'warning',
          title: t('Atenção! Trechos perigosos na rota'),
          message: hazardMessage,
          duration: 10000
        });
      }

      if (vehicleSpecs.type === 'truck' && route.truckRestrictions?.length > 0) {
        const restrictionsMessage = route.truckRestrictions.map(r => `- ${r.type}: ${r.description} (km ${r.distance})`).join('\n');
        showAlert({
          type: 'warning',
          title: t('Restrições para caminhões na rota'),
          message: restrictionsMessage,
          duration: 10000
        });
      }
    } catch (error) {
      console.error('Erro ao verificar perigos da rota:', error);
    }
  };

  /**
   * Inicia a navegação para o destino atual
   */
  const startNavigation = () => {
    if (!currentLocation || !mapRef?.current) return;

    logEvent('navigation_started', {
      origin: `${currentLocation.latitude},${currentLocation.longitude}`,
      vehicleType: vehicleSpecs.type
    });

    setIsNavigating(true);
    setShowRouteDetails(false);

    mapRef.current.setNavigationMode(true);

    showAlert({
      type: 'success',
      message: t('Navegação iniciada. Dirija com segurança!'),
      duration: 3000
    });

    if (audioEnabled) {
      playVoiceInstruction('navigation_started');
    }

    fetchTrafficAlerts();
  };

  return {
    handleRouteCalculation,
    checkRouteHazards,
    startNavigation
  };
};

export default useNavigationActions;
