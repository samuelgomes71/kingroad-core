import React, { useState, useEffect } from 'react';
import { Truck, Car, Droplet, Star, Navigation, X, ArrowRight, Clock } from 'lucide-react';

// Componente principal para overlay do mapa
const VehicleWashMapOverlay = ({ vehicleMode = 'truck', mapInstance, onSelectPoi }) => {
  // Estados
  const [pois, setPois] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMarker, setSelectedMarker] = useState(null);
  const [userLocation, setUserLocation] = useState({ lat: -23.550520, lng: -46.633309 }); // Default: São Paulo
  
  // Efeito para carregar POIs baseados no modo do veículo
  useEffect(() => {
    setLoading(true);
    
    // Simulação de carregamento de dados
    setTimeout(() => {
      if (vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv') {
        setPois(mockTruckWasherLocations);
      } else {
        setPois(mockCarWasherLocations);
      }
      setLoading(false);
    }, 1000);
  }, [vehicleMode]);
  
  // Efeito para simular a adição de marcadores ao mapa
  useEffect(() => {
    // Em uma implementação real, aqui você adicionaria marcadores ao mapa
    console.log('Adicionando marcadores ao mapa:', pois);
    
    // Cleanup function para remover marcadores quando o componente for desmontado
    return () => {
      console.log('Removendo marcadores do mapa');
    };
  }, [pois, mapInstance]);
  
  // Função para selecionar um marcador
  const handleMarkerSelect = (poi) => {
    setSelectedMarker(poi);
  };
  
  // Função para fechar o popup de informações
  const handleCloseInfoWindow = () => {
    setSelectedMarker(null);
  };
  
  // Função para abrir os detalhes completos do POI
  const handleViewDetails = (poi) => {
    if (onSelectPoi) {
      onSelectPoi(poi.id);
    }
  };
  
  // Renderização do componente
  return (
    <div className="relative w-full h-full">
      {/* Este seria o overlay do mapa em uma implementação real */}
      {/* Aqui mostraremos apenas um mock para visualização */}
      
      {/* Simulação de mapa com marcadores */}
      <div className="absolute inset-0 bg-gray-300 overflow-hidden">
        {/* Indicador do mapa simulado - apenas para preview */}
        <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-lg font-bold">
          Mapa (Visualização simulada)
        </div>
        
        {/* Simulação de marcadores no mapa */}
        {pois.map(poi => (
          <div 
            key={poi.id}
            className="absolute w-8 h-8 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
            style={{ 
              left: `${30 + Math.random() * 40}%`, 
              top: `${30 + Math.random() * 40}%` 
            }}
            onClick={() => handleMarkerSelect(poi)}
          >
            <MarkerIcon 
              vehicleMode={vehicleMode} 
              isSelected={selectedMarker?.id === poi.id}
            />
          </div>
        ))}
        
        {/* Simulação de localização do usuário */}
        <div 
          className="absolute w-6 h-6 bg-blue-500 rounded-full border-2 border-white transform -translate-x-1/2 -translate-y-1/2"
          style={{ left: '50%', top: '50%' }}
        >
          <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
        </div>
      </div>
      
      {/* Janela de informações do marcador selecionado */}
      {selectedMarker && (
        <InfoWindow 
          poi={selectedMarker} 
          vehicleMode={vehicleMode}
          onClose={handleCloseInfoWindow}
          onViewDetails={() => handleViewDetails(selectedMarker)}
        />
      )}
    </div>
  );
};

// Componente para o ícone do marcador
const MarkerIcon = ({ vehicleMode, isSelected }) => {
  const baseClasses = "flex items-center justify-center rounded-full shadow-lg transition-all duration-200 transform";
  const selectedClasses = isSelected 
    ? "w-10 h-10 bg-amber-500 text-black scale-110 z-20" 
    : "w-8 h-8 bg-gray-800 hover:bg-gray-700 text-amber-400 hover:scale-110 z-10";
  
  return (
    <div className={`${baseClasses} ${selectedClasses}`}>
      {vehicleMode === 'truck' || vehicleMode === 'bus' || vehicleMode === 'rv' ? (
        <Truck size={isSelected ? 24 : 18} />
      ) : (
        <Car size={isSelected ? 24 : 18} />
      )}
    </div>
  );
};

// Componente para a janela de informações
const InfoWindow = ({ poi, vehicleMode, onClose, onViewDetails }) => {
  return (
    <div className="absolute right-4 bottom-24 w-72 bg-gray-900 text-white rounded-lg shadow-xl p-4 z-30 border border-gray-700">
      {/* Botão de fechar */}
      <button 
        onClick={onClose}
        className="absolute top-2 right-2 text-gray-400 hover:text-white"
      >
        <X size={16} />
      </button>
      
      {/* Conteúdo */}
      <div className="mb-2">
        <h3 className="font-bold text-lg text-amber-400">{poi.name}</h3>
        <div className="flex items-center text-sm text-gray-400">
          <Clock size={14} className="mr-1" />
          <span>{poi.isOpen ? 'Aberto agora' : 'Fechado'}</span>
          <span className="mx-2">•</span>
          <span>{poi.distance} km</span>
        </div>
      </div>
      
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center">
          <div className="flex items-center bg-amber-500 text-black font-bold px-2 py-1 rounded text-sm mr-2">
            <Star size={12} className="mr-1" />
            <span>{poi.rating.toFixed(1)}</span>
          </div>
          <span className="text-xs text-gray-400">{poi.reviewCount} avaliações</span>
        </div>
      </div>
      
      {/* Tempo de espera */}
      <div className="flex items-center justify-between p-2 bg-gray-800 rounded mb-3">
        <span className="text-sm">Tempo de espera estimado:</span>
        <span className="text-amber-400 font-bold">{poi.waitTime} min</span>
      </div>
      
      {/* Preço básico */}
      <div className="text-sm mb-4">
        <span>A partir de </span>
        <span className="text-amber-400 font-bold">{poi.currency} {poi.basePrice}</span>
      </div>
      
      {/* Botões de ação */}
      <div className="flex space-x-2">
        <button 
          onClick={() => window.open(`https://maps.google.com/?q=${poi.latitude},${poi.longitude}`)}
          className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 px-3 rounded-lg text-sm flex items-center justify-center transition-colors"
        >
          <Navigation size={14} className="mr-1" />
          <span>Navegar</span>
        </button>
        
        <button 
          onClick={onViewDetails}
          className="flex-1 bg-amber-500 hover:bg-amber-600 text-black py-2 px-3 rounded-lg text-sm font-bold flex items-center justify-center transition-colors"
        >
          <ArrowRight size={14} className="mr-1" />
          <span>Detalhes</span>
        </button>
      </div>
    </div>
  );
};

// Dados mockados de localização para Truck Washers
const mockTruckWasherLocations = [
  {
    id: 'tw1',
    name: 'Blue Beacon Truck Wash',
    latitude: -23.550520,
    longitude: -46.633309,
    distance: 12.5,
    rating: 4.7,
    reviewCount: 128,
    basePrice: 120,
    currency: 'R$',
    waitTime: 30,
    isOpen: true
  },
  {
    id: 'tw2',
    name: 'Posto Ipiranga Lava-Tudo',
    latitude: -23.556520,
    longitude: -46.639309,
    distance: 24.8,
    rating: 4.2,
    reviewCount: 89,
    basePrice: 90,
    currency: 'R$',
    waitTime: 15,
    isOpen: true
  },
  {
    id: 'tw3',
    name: 'Truck Clean Express',
    latitude: -23.560520,
    longitude: -46.623309,
    distance: 35.2,
    rating: 4.5,
    reviewCount: 64,
    basePrice: 150,
    currency: 'R$',
    waitTime: 45,
    isOpen: false
  }
];

// Dados mockados de localização para Car Washers
const mockCarWasherLocations = [
  {
    id: 'cw1',
    name: 'Lava Rápido Auto Shine',
    latitude: -23.552520,
    longitude: -46.634309,
    distance: 2.1,
    rating: 4.8,
    reviewCount: 246,
    basePrice: 40,
    currency: 'R$',
    waitTime: 20,
    isOpen: true
  },
  {
    id: 'cw2',
    name: 'Shell Box Car Wash',
    latitude: -23.558520,
    longitude: -46.631309,
    distance: 3.5,
    rating: 4.3,
    reviewCount: 138,
    basePrice: 35,
    currency: 'R$',
    waitTime: 10,
    isOpen: true
  },
  {
    id: 'cw3',
    name: 'Eco Car Wash',
    latitude: -23.548520,
    longitude: -46.638309,
    distance: 5.8,
    rating: 4.6,
    reviewCount: 192,
    basePrice: 50,
    currency: 'R$',
    waitTime: 30,
    isOpen: false
  }
];

export default VehicleWashMapOverlay;