package com.kingroad.services

import com.kingroad.models.Location
import com.kingroad.models.ParkingIssue
import com.kingroad.models.ParkingSpot
import com.kingroad.models.PoiType
import com.kingroad.models.SecurityRating
import com.kingroad.models.TruckSpecs
import com.kingroad.repositories.ParkingRepository
import com.kingroad.repositories.PoiRepository
import com.kingroad.security.SecurityAlertService
import com.kingroad.storage.CacheManager
import com.kingroad.storage.OfflineQueueManager
import com.kingroad.utils.DistanceCalculator
import com.kingroad.utils.NetworkUtil
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.Serializable
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min

// Constantes para cache
private const val PARKING_CACHE_KEY = "parking_data"
private const val PARKING_CACHE_EXPIRY = 24 * 60 * 60 * 1000 // 24 horas em milissegundos

/**
 * Serviço responsável por encontrar estacionamentos seguros para caminhões
 * próximos a pontos de interesse (POIs) como restaurantes, cafés, etc.
 */
@Singleton
class NearbyParkingService @Inject constructor(
    private val poiRepository: PoiRepository,
    private val parkingRepository: ParkingRepository,
    private val securityAlertService: SecurityAlertService,
    private val distanceCalculator: DistanceCalculator,
    private val cacheManager: CacheManager,
    private val offlineQueueManager: OfflineQueueManager,
    private val networkUtil: NetworkUtil
) {

    /**
     * Encontra estacionamentos seguros para caminhões em um raio específico de um POI
     * @param poiId ID do ponto de interesse
     * @param radius Raio em metros para procurar estacionamentos (padrão: 200m)
     * @param truckSpecs Especificações do caminhão para filtrar estacionamentos compatíveis
     * @return Flow de spots de estacionamento com distância e avaliação de segurança
     */
    suspend fun findNearbyParkingForPoi(
        poiId: String,
        radius: Int = 200,
        truckSpecs: TruckSpecs
    ): Flow<List<NearbyParkingResult>> = flow {
        try {
            // Tenta buscar online
            if (networkUtil.isNetworkAvailable()) {
                // Busca o POI pelo ID
                val poi = poiRepository.getPoiById(poiId) ?: return@flow
                
                // Busca estacionamentos para caminhões na área
                val parkingSpots = parkingRepository.findParkingInRadius(
                    latitude = poi.location.latitude,
                    longitude = poi.location.longitude,
                    radiusMeters = radius,
                    truckHeight = truckSpecs.height,
                    truckWeight = truckSpecs.weight,
                    truckLength = truckSpecs.length
                )
                
                // Calcula distância e avaliação de segurança para cada spot
                val results = parkingSpots.map { spot ->
                    val distance = distanceCalculator.calculate(
                        poi.location.latitude, poi.location.longitude,
                        spot.location.latitude, spot.location.longitude
                    )
                    
                    val securityRating = securityAlertService.evaluateLocationSafety(
                        spot.location.latitude,
                        spot.location.longitude
                    )
                    
                    NearbyParkingResult(
                        parkingSpot = spot,
                        distanceToPoi = distance,
                        securityRating = securityRating,
                        walkingTimeMins = calculateWalkingTime(distance)
                    )
                }.sortedBy { it.distanceToPoi }
                
                // Salva em cache para uso offline
                cacheParkingResults(poiId, radius, results)
                
                emit(results)
            } else {
                // Se estiver offline, busca do cache
                val cachedResults = findNearbyParkingOffline(poiId, radius, truckSpecs)
                emit(cachedResults)
            }
        } catch (e: Exception) {
            // Em caso de erro, tenta buscar do cache
            val cachedResults = findNearbyParkingOffline(poiId, radius, truckSpecs)
            emit(cachedResults)
        }
    }
    
    /**
     * Busca estacionamentos próximos a um POI usando dados em cache (modo offline)
     * 
     * @param poiId ID do ponto de interesse
     * @param radius Raio de busca em metros
     * @param truckSpecs Especificações do caminhão
     * @return Lista de estacionamentos próximos do cache
     */
    private suspend fun findNearbyParkingOffline(
        poiId: String,
        radius: Int,
        truckSpecs: TruckSpecs
    ): List<NearbyParkingResult> {
        val cacheKey = "${PARKING_CACHE_KEY}_${poiId}_${radius}"
        val cachedData = cacheManager.getFromCache<CachedParkingData>(cacheKey) ?: return emptyList()
        
        // Verifica se o cache expirou
        val now = System.currentTimeMillis()
        if (now - cachedData.timestamp > PARKING_CACHE_EXPIRY) {
            return emptyList()
        }
        
        // Filtra resultados com base nas especificações do caminhão
        return cachedData.results.filter { result ->
            val spot = result.parkingSpot
            (!spot.maxHeight.isNaN() || spot.maxHeight >= truckSpecs.height) &&
            (!spot.maxWeight.isNaN() || spot.maxWeight >= truckSpecs.weight) &&
            (!spot.maxLength.isNaN() || spot.maxLength >= truckSpecs.length)
        }
    }
    
    /**
     * Salva resultados de estacionamento em cache para uso offline
     * 
     * @param poiId ID do ponto de interesse
     * @param radius Raio de busca em metros
     * @param results Resultados de estacionamento
     */
    private suspend fun cacheParkingResults(
        poiId: String,
        radius: Int,
        results: List<NearbyParkingResult>
    ) {
        val cacheKey = "${PARKING_CACHE_KEY}_${poiId}_${radius}"
        val cacheData = CachedParkingData(
            results = results,
            timestamp = System.currentTimeMillis()
        )
        
        cacheManager.saveToCache(cacheKey, cacheData)
    }
    
    /**
     * Encontra POIs próximos a um local específico com estacionamentos seguros para caminhões nas proximidades
     * @param poiType Tipo de POI que o motorista está procurando (ex: RESTAURANT, CAFE)
     * @param location Localização atual ou destino
     * @param radius Raio em metros para procurar estacionamentos (padrão: 200m)
     * @param truckSpecs Especificações do caminhão
     * @return Flow de POIs com estacionamentos próximos disponíveis
     */
    suspend fun findPoisWithNearbyParking(
        poiType: PoiType,
        location: Location,
        radius: Int = 200,
        truckSpecs: TruckSpecs
    ): Flow<List<PoiWithParkingResult>> = flow {
        // Busca POIs do tipo especificado na área
        val pois = poiRepository.findPoisByType(
            type = poiType,
            latitude = location.latitude,
            longitude = location.longitude,
            radiusMeters = 1000 // Raio maior para encontrar POIs, depois filtramos pelos que têm estacionamento próximo
        )
        
        val results = mutableListOf<PoiWithParkingResult>()
        
        for (poi in pois) {
            // Para cada POI, procura estacionamentos próximos
            val nearbyParkings = parkingRepository.findParkingInRadius(
                latitude = poi.location.latitude,
                longitude = poi.location.longitude,
                radiusMeters = radius,
                truckHeight = truckSpecs.height,
                truckWeight = truckSpecs.weight,
                truckLength = truckSpecs.length
            )
            
            // Se houver pelo menos um estacionamento próximo
            if (nearbyParkings.isNotEmpty()) {
                // Encontra o estacionamento mais próximo e seguro
                val bestParking = nearbyParkings.maxByOrNull { spot -> 
                    val distance = distanceCalculator.calculate(
                        poi.location.latitude, poi.location.longitude,
                        spot.location.latitude, spot.location.longitude
                    )
                    
                    val securityRating = securityAlertService.evaluateLocationSafety(
                        spot.location.latitude,
                        spot.location.longitude
                    )
                    
                    // Fórmula que prioriza segurança e proximidade
                    (securityRating * 0.7) - (distance * 0.3)
                }
                
                bestParking?.let { spot ->
                    val distance = distanceCalculator.calculate(
                        poi.location.latitude, poi.location.longitude,
                        spot.location.latitude, spot.location.longitude
                    )
                    
                    val securityRating = securityAlertService.evaluateLocationSafety(
                        spot.location.latitude,
                        spot.location.longitude
                    )
                    
                    results.add(
                        PoiWithParkingResult(
                            poi = poi,
                            bestParkingSpot = spot,
                            distanceToParking = distance,
                            securityRating = securityRating,
                            walkingTimeMins = calculateWalkingTime(distance)
                        )
                    )
                }
            }
        }
        
        emit(results.sortedBy { it.distanceToParking })
    }
    
    /**
     * Busca detalhes completos de um estacionamento específico
     * 
     * @param parkingId ID do estacionamento
     * @return Detalhes do estacionamento
     */
    suspend fun getParkingDetails(parkingId: String): ParkingSpot? {
        return try {
            parkingRepository.getParkingById(parkingId)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Adiciona um novo estacionamento reportado pelo usuário
     * 
     * @param parkingSpot Dados do novo estacionamento
     * @return ID do estacionamento criado
     */
    suspend fun addNewParkingSpot(parkingSpot: ParkingSpot): String? {
        return try {
            if (networkUtil.isNetworkAvailable()) {
                // Adiciona online
                val id = parkingRepository.addParkingSpot(parkingSpot)
                id
            } else {
                // Adiciona à fila para sincronização futura
                val tempId = UUID.randomUUID().toString()
                offlineQueueManager.queueParkingSpot(tempId, parkingSpot)
                tempId
            }
        } catch (e: Exception) {
            // Adiciona à fila para sincronização futura
            val tempId = UUID.randomUUID().toString()
            offlineQueueManager.queueParkingSpot(tempId, parkingSpot)
            tempId
        }
    }
    
    /**
     * Salva uma avaliação de segurança para um estacionamento
     * 
     * @param parkingId ID do estacionamento
     * @param securityRating Avaliação de segurança (0.0-10.0)
     * @param comment Comentário opcional
     * @return Sucesso ou falha
     */
    suspend fun saveSecurityRating(
        parkingId: String,
        securityRating: Double,
        comment: String = ""
    ): Boolean {
        return try {
            if (networkUtil.isNetworkAvailable()) {
                // Salva online
                parkingRepository.saveSecurityRating(
                    parkingId = parkingId,
                    rating = SecurityRating(
                        rating = securityRating,
                        comment = comment,
                        timestamp = System.currentTimeMillis()
                    )
                )
                true
            } else {
                // Adiciona à fila para sincronização futura
                queueSecurityRating(parkingId, securityRating, comment)
                true
            }
        } catch (e: Exception) {
            // Adiciona à fila para sincronização futura
            queueSecurityRating(parkingId, securityRating, comment)
            true
        }
    }
    
    /**
     * Salva uma avaliação de segurança na fila para sincronização posterior
     * 
     * @param parkingId ID do estacionamento
     * @param securityRating Avaliação de segurança (0.0-10.0)
     * @param comment Comentário opcional
     */
    private suspend fun queueSecurityRating(
        parkingId: String, 
        securityRating: Double,
        comment: String
    ) {
        val rating = SecurityRating(
            rating = securityRating,
            comment = comment,
            timestamp = System.currentTimeMillis()
        )
        
        offlineQueueManager.queueSecurityRating(parkingId, rating)
    }
    
    /**
     * Reporta um problema com um estacionamento
     * 
     * @param parkingId ID do estacionamento
     * @param issueType Tipo de problema
     * @param description Descrição do problema
     * @return Sucesso ou falha
     */
    suspend fun reportParkingIssue(
        parkingId: String,
        issueType: String,
        description: String
    ): Boolean {
        return try {
            if (networkUtil.isNetworkAvailable()) {
                // Reporta online
                parkingRepository.reportParkingIssue(
                    parkingId = parkingId,
                    issue = ParkingIssue(
                        type = issueType,
                        description = description,
                        timestamp = System.currentTimeMillis()
                    )
                )
                true
            } else {
                // Adiciona à fila para sincronização futura
                queueParkingIssue(parkingId, issueType, description)
                true
            }
        } catch (e: Exception) {
            // Adiciona à fila para sincronização futura
            queueParkingIssue(parkingId, issueType, description)
            true
        }
    }
    
    /**
     * Adiciona um problema com estacionamento à fila para sincronização posterior
     * 
     * @param parkingId ID do estacionamento
     * @param issueType Tipo de problema
     * @param description Descrição do problema
     */
    private suspend fun queueParkingIssue(
        parkingId: String,
        issueType: String,
        description: String
    ) {
        val issue = ParkingIssue(
            type = issueType,
            description = description,
            timestamp = System.currentTimeMillis()
        )
        
        offlineQueueManager.queueParkingIssue(parkingId, issue)
    }
    
    /**
     * Calcula tempo aproximado de caminhada baseado na distância em metros
     * @param distanceMeters Distância em metros
     * @return Tempo estimado de caminhada em minutos
     */
    private fun calculateWalkingTime(distanceMeters: Double): Int {
        // Considerando velocidade média de caminhada de 5km/h = 83.33m/min
        val walkingSpeedMetersPerMin = 83.33
        return min(30, Math.ceil(distanceMeters / walkingSpeedMetersPerMin).toInt())
    }
    
    /**
     * Classe que representa o resultado de estacionamento próximo
     */
    data class NearbyParkingResult(
        val parkingSpot: ParkingSpot,
        val distanceToPoi: Double,
        val securityRating: Double, // 0.0 a 10.0
        val walkingTimeMins: Int
    )
    
    /**
     * Classe que representa o resultado de POI com estacionamento próximo
     */
    data class PoiWithParkingResult(
        val poi: Location,
        val bestParkingSpot: ParkingSpot,
        val distanceToParking: Double,
        val securityRating: Double, // 0.0 a 10.0
        val walkingTimeMins: Int
    )
    
    /**
     * Classe para armazenar dados de estacionamento em cache
     */
    @Serializable
    data class CachedParkingData(
        val results: List<NearbyParkingResult>,
        val timestamp: Long
    )
}