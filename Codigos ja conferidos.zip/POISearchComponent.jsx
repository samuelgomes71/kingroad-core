import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, Navigation, History, Star, Building, Map, ChevronRight, X, ArrowRight, Truck, Coffee, Home, Settings, Wrench } from 'lucide-react';

const POISearchComponent = () => {
  // Estados para gerenciar o componente
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showRecentDestinations, setShowRecentDestinations] = useState(false);
  const [showLocationSelect, setShowLocationSelect] = useState(false);
  const searchInputRef = useRef(null);

  // Dados simulados para preview
  const recentDestinations = [
    { id: 1, name: 'Posto Shell Bandeirantes', type: 'gas_station', address: 'Rod. dos Bandeirantes, km 72', lastVisit: '2 dias atrás' },
    { id: 2, name: 'Restaurante Bom Prato', type: 'restaurant', address: 'Av. Paulista, 1000', lastVisit: '5 dias atrás' },
    { id: 3, name: 'Auto Peças Truckão', type: 'service', address: 'Rod. Anhanguera, km 15', lastVisit: '1 semana atrás' },
    { id: 4, name: 'Pousada do Caminhoneiro', type: 'hotel', address: 'Rod. Presidente Dutra, km 210', lastVisit: '2 semanas atrás' }
  ];

  const nearbyPOIs = [
    { id: 101, name: 'Posto Ipiranga', type: 'gas_station', distance: '1.2 km', rating: 4.5 },
    { id: 102, name: 'Restaurante Beira Estrada', type: 'restaurant', distance: '0.8 km', rating: 4.2 },
    { id: 103, name: 'Oficina Mecânica 24h', type: 'service', distance: '2.5 km', rating: 4.7 },
    { id: 104, name: 'Área de Descanso Dutra', type: 'rest_area', distance: '3.7 km', rating: 4.0 },
    { id: 105, name: 'Borracharia do Zé', type: 'service', distance: '1.5 km', rating: 4.3 }
  ];

  const categories = [
    { id: 'all', name: 'Todos', icon: <MapPin /> },
    { id: 'gas_station', name: 'Postos', icon: <Truck /> },
    { id: 'restaurant', name: 'Restaurantes', icon: <Coffee /> },
    { id: 'hotel', name: 'Hotéis', icon: <Home /> },
    { id: 'service', name: 'Serviços', icon: <Wrench /> }
  ];

  const cities = [
    'São Paulo, SP',
    'Rio de Janeiro, RJ',
    'Belo Horizonte, MG',
    'Salvador, BA',
    'Curitiba, PR',
    'Campinas, SP',
    'Ribeirão Preto, SP'
  ];

  // Simulação de busca
  useEffect(() => {
    if (searchQuery.length > 2) {
      setIsSearching(true);
      
      // Simular busca com delay para mostrar loading state
      const timer = setTimeout(() => {
        let results = [];
        
        // Simular resultados de POIs próximos
        results = nearbyPOIs.filter(poi => 
          poi.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          (selectedCategory === 'all' || poi.type === selectedCategory)
        );
        
        // Simular resultados do Google Maps
        if (searchQuery.toLowerCase().includes('posto') || searchQuery.toLowerCase().includes('gas')) {
          results.push(
            { id: 201, name: 'Posto Petrobras', type: 'gas_station', address: 'Av. Brasil, 1500, Rio de Janeiro', source: 'google' },
            { id: 202, name: 'Auto Posto Via Dutra', type: 'gas_station', address: 'Rod. Presidente Dutra, km 230', source: 'google' }
          );
        }
        
        setSearchResults(results);
        setIsSearching(false);
      }, 500);
      
      return () => clearTimeout(timer);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery, selectedCategory]);

  // Renderizar icone baseado no tipo de POI
  const renderPOIIcon = (type) => {
    switch (type) {
      case 'gas_station':
        return <Truck className="w-5 h-5 text-blue-500" />;
      case 'restaurant':
        return <Coffee className="w-5 h-5 text-orange-500" />;
      case 'hotel':
        return <Home className="w-5 h-5 text-purple-500" />;
      case 'service':
        return <Wrench className="w-5 h-5 text-gray-500" />;
      case 'rest_area':
        return <Truck className="w-5 h-5 text-green-500" />;
      default:
        return <MapPin className="w-5 h-5 text-gray-500" />;
    }
  };

  // Limpar busca
  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setShowLocationSelect(false);
    searchInputRef.current?.focus();
  };

  // Selecionar POI
  const selectPOI = (poi) => {
    console.log('POI selecionado:', poi);
    // Aqui iríamos navegar até o POI ou mostrar no mapa
    clearSearch();
  };

  return (
    <div className="w-full max-w-md mx-auto bg-gray-900 text-white rounded-lg overflow-hidden shadow-lg border border-gray-800">
      {/* Barra de busca */}
      <div className="relative">
        <div className="flex items-center p-3 bg-gray-800">
          <Search className="w-5 h-5 text-gray-400 mr-2" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Buscar postos, restaurantes, hotéis..."
            className="w-full bg-transparent text-white border-none outline-none placeholder-gray-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button 
              onClick={clearSearch}
              className="p-1 rounded-full hover:bg-gray-700 transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>
        
        {/* Categorias de POI */}
        <div className="flex items-center px-2 py-2 bg-gray-800 border-t border-gray-700 overflow-x-auto">
          {categories.map((category) => (
            <button
              key={category.id}
              className={`flex flex-col items-center px-3 py-1 mr-2 rounded-lg text-xs ${
                selectedCategory === category.id 
                  ? 'bg-yellow-600 text-white' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              } transition-colors`}
              onClick={() => setSelectedCategory(category.id)}
            >
              {React.cloneElement(category.icon, { 
                className: `w-4 h-4 mb-1 ${selectedCategory === category.id ? 'text-white' : 'text-gray-300'}`
              })}
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Resultados da busca */}
      <div className="max-h-80 overflow-y-auto">
        {isSearching ? (
          <div className="p-4 text-center text-gray-400">
            Buscando...
          </div>
        ) : searchResults.length > 0 ? (
          <div>
            <div className="p-2 bg-gray-800 border-b border-gray-700">
              <h3 className="text-sm font-medium text-gray-400">Resultados</h3>
            </div>
            <ul>
              {searchResults.map(result => (
                <li key={result.id} className="border-b border-gray-800">
                  <button 
                    className="w-full text-left p-3 hover:bg-gray-800 transition-colors flex items-center"
                    onClick={() => selectPOI(result)}
                  >
                    {renderPOIIcon(result.type)}
                    <div className="ml-3 flex-1">
                      <p className="text-white font-medium">{result.name}</p>
                      <p className="text-gray-400 text-sm">
                        {result.distance ? `${result.distance} de distância` : result.address}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-500" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : searchQuery.length > 0 ? (
          <div className="p-4 text-center text-gray-400">
            Nenhum resultado encontrado.
            <button 
              className="mt-2 block w-full text-yellow-500 hover:text-yellow-400 transition-colors"
              onClick={() => setShowLocationSelect(true)}
            >
              Buscar em outra localidade
            </button>
          </div>
        ) : (
          <div>
            {/* Opções de busca alternativa */}
            <div className="divide-y divide-gray-800">
              {/* Buscar em outra localidade */}
              <button 
                className="w-full text-left p-4 hover:bg-gray-800 transition-colors flex items-center"
                onClick={() => setShowLocationSelect(true)}
              >
                <Map className="w-5 h-5 text-blue-500" />
                <div className="ml-3 flex-1">
                  <p className="text-white font-medium">Buscar em outra localidade</p>
                  <p className="text-gray-400 text-sm">Pesquisar POIs em outras cidades</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
              
              {/* Destinos recentes */}
              <button 
                className="w-full text-left p-4 hover:bg-gray-800 transition-colors flex items-center"
                onClick={() => setShowRecentDestinations(!showRecentDestinations)}
              >
                <History className="w-5 h-5 text-green-500" />
                <div className="ml-3 flex-1">
                  <p className="text-white font-medium">Destinos recentes</p>
                  <p className="text-gray-400 text-sm">Acessar locais visitados anteriormente</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500 transition-transform duration-200" 
                  style={{transform: showRecentDestinations ? 'rotate(90deg)' : 'rotate(0)'}} />
              </button>
              
              {/* Lista de destinos recentes (expansível) */}
              {showRecentDestinations && (
                <ul className="bg-gray-900">
                  {recentDestinations.map(dest => (
                    <li key={dest.id} className="border-t border-gray-800">
                      <button 
                        className="w-full text-left p-3 pl-12 hover:bg-gray-800 transition-colors flex items-center"
                        onClick={() => selectPOI(dest)}
                      >
                        {renderPOIIcon(dest.type)}
                        <div className="ml-3 flex-1">
                          <p className="text-white font-medium">{dest.name}</p>
                          <p className="text-gray-400 text-sm">{dest.address} • {dest.lastVisit}</p>
                        </div>
                        <ArrowRight className="w-5 h-5 text-yellow-500" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
              
              {/* Buscar POIs próximos no mapa */}
              <button 
                className="w-full text-left p-4 hover:bg-gray-800 transition-colors flex items-center"
                onClick={() => console.log('Abrir mapa')}
              >
                <Navigation className="w-5 h-5 text-yellow-500" />
                <div className="ml-3 flex-1">
                  <p className="text-white font-medium">Ver POIs no mapa</p>
                  <p className="text-gray-400 text-sm">Explorar pontos de interesse próximos</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
              
              {/* Favoritos */}
              <button 
                className="w-full text-left p-4 hover:bg-gray-800 transition-colors flex items-center"
                onClick={() => console.log('Abrir favoritos')}
              >
                <Star className="w-5 h-5 text-yellow-500" />
                <div className="ml-3 flex-1">
                  <p className="text-white font-medium">Favoritos</p>
                  <p className="text-gray-400 text-sm">Acessar seus locais favoritos</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
              
              {/* Buscar empresas */}
              <button 
                className="w-full text-left p-4 hover:bg-gray-800 transition-colors flex items-center"
                onClick={() => console.log('Buscar empresas')}
              >
                <Building className="w-5 h-5 text-purple-500" />
                <div className="ml-3 flex-1">
                  <p className="text-white font-medium">Buscar empresas</p>
                  <p className="text-gray-400 text-sm">Encontrar empresas pelo nome</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
            </div>
          </div>
        )}
        
        {/* Seleção de localidade */}
        {showLocationSelect && (
          <div className="absolute inset-0 bg-gray-900 z-10 flex flex-col">
            <div className="flex items-center p-3 bg-gray-800 border-b border-gray-700">
              <button 
                onClick={() => setShowLocationSelect(false)}
                className="p-1 mr-2 rounded-full hover:bg-gray-700 transition-colors"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
              <h3 className="text-white font-medium">Selecionar localidade</h3>
            </div>
            
            <div className="p-3">
              <input
                type="text"
                placeholder="Digite o nome da cidade..."
                className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white placeholder-gray-500 outline-none focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <div className="p-2 bg-gray-800 border-b border-gray-700">
                <h3 className="text-sm font-medium text-gray-400">Cidades populares</h3>
              </div>
              <ul>
                {cities.map((city, index) => (
                  <li key={index} className="border-b border-gray-800">
                    <button 
                      className="w-full text-left p-3 hover:bg-gray-800 transition-colors flex items-center"
                      onClick={() => {
                        console.log('Cidade selecionada:', city);
                        setShowLocationSelect(false);
                      }}
                    >
                      <MapPin className="w-5 h-5 text-blue-500" />
                      <div className="ml-3 flex-1">
                        <p className="text-white font-medium">{city}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-500" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default POISearchComponent;