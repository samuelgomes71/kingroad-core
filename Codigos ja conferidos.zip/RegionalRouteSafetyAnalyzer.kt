data class RegionalGradeLimits(
    val country: String,
    val region: String? = null,
    val maxGradeThreshold: Double,
    val description: String
)

class RegionalRouteSafetyAnalyzer(
    private val defaultConfig: SafetyConfig = SafetyConfig()
) {
    data class SafetyConfig(
        val defaultMaxGrade: Double = 10.0,      // Padrão global
        val sharpTurnThreshold: Double = 90.0,   // Ângulo para curva fechada
        val hairpinThreshold: Double = 150.0,    // Ângulo para cotovelo
        val segmentLength: Double = 50.0         // Comprimento do segmento para análise
    )

    // Lista de exceções regionais
    private val regionalLimits = listOf(
        RegionalGradeLimits(
            country = "CH",                  // Suíça
            maxGradeThreshold = 12.0,
            description = "Swiss Alpine Roads"
        ),
        RegionalGradeLimits(
            country = "CA",                  // Canadá
            region = "QC",                   // Quebec
            maxGradeThreshold = 14.0,
            description = "Quebec Mountain Routes"
        ),
        RegionalGradeLimits(
            country = "CA",                  // Outras regiões do Canadá
            maxGradeThreshold = 11.0,
            description = "Canadian Routes"
        )
    )

    fun getRegionalGradeLimit(country: String, region: String? = null): Double {
        // Primeiro tenta encontrar limite específico para região
        val regionLimit = regionalLimits.find { 
            it.country == country && it.region == region 
        }
        
        // Se não encontrar, procura limite do país
        val countryLimit = regionalLimits.find { 
            it.country == country && it.region == null 
        }
        
        // Retorna o limite encontrado ou o padrão
        return regionLimit?.maxGradeThreshold 
            ?: countryLimit?.maxGradeThreshold 
            ?: defaultConfig.defaultMaxGrade
    }

    fun analyzeRouteSegment(
        segment: RouteSegment,
        country: String,
        region: String? = null
    ): List<RouteHazard> {
        val hazards = mutableListOf<RouteHazard>()
        val maxGrade = getRegionalGradeLimit(country, region)

        // Verifica inclinação considerando limite regional
        val grade = segment.grade
        when {
            grade > maxGrade -> {
                hazards.add(RouteHazard(
                    type = HazardType.STEEP_ASCENT,
                    location = segment.startPoint,
                    severity = (grade / maxGrade) * 100,
                    description = buildGradeDescription(grade, maxGrade, true)
                ))
            }
            grade < -maxGrade -> {
                hazards.add(RouteHazard(
                    type = HazardType.STEEP_DESCENT,
                    location = segment.startPoint,
                    severity = (Math.abs(grade) / maxGrade) * 100,
                    description = buildGradeDescription(Math.abs(grade), maxGrade, false)
                ))
            }
        }

        // Analisa curvas independente da região
        segment.turnAngle?.let { angle ->
            when {
                angle > defaultConfig.hairpinThreshold -> {
                    hazards.add(RouteHazard(
                        type = HazardType.HAIRPIN_TURN,
                        location = segment.startPoint,
                        severity = (angle / defaultConfig.hairpinThreshold) * 100,
                        description = "Curva cotovelo de ${angle.toInt()}°"
                    ))
                }
                angle > defaultConfig.sharpTurnThreshold -> {
                    hazards.add(RouteHazard(
                        type = HazardType.SHARP_TURN,
                        location = segment.startPoint,
                        severity = (angle / defaultConfig.sharpTurnThreshold) * 100,
                        description = "Curva fechada de ${angle.toInt()}°"
                    ))
                }
            }
        }

        return hazards
    }

    private fun buildGradeDescription(
        grade: Double, 
        limit: Double,
        isAscent: Boolean
    ): String {
        val direction = if (isAscent) "Subida" else "Descida"
        val gradeStr = grade.toInt()
        val limitStr = limit.toInt()
        
        return when {
            grade > limit * 1.2 -> "$direction muito íngreme de $gradeStr% (limite local: $limitStr%)"
            else -> "$direction íngreme de $gradeStr% (limite local: $limitStr%)"
        }
    }

    fun generateWarningMessage(hazards: List<RouteHazard>, country: String, region: String?): String {
        val limit = getRegionalGradeLimit(country, region)
        
        return buildString {
            appendLine("⚠️ ATENÇÃO: Esta rota possui trechos desafiadores:")
            appendLine()
            appendLine("Limite de inclinação local: $limit%")
            appendLine()
            
            hazards.groupBy { it.type }.forEach { (type, typeHazards) ->
                val count = typeHazards.size
                when (type) {
                    HazardType.STEEP_ASCENT -> {
                        appendLine("🔺 $count ${if (count > 1) "subidas íngremes" else "subida íngreme"}")
                        typeHazards.forEach { appendLine("   - ${it.description}") }
                    }
                    HazardType.STEEP_DESCENT -> {
                        appendLine("🔻 $count ${if (count > 1) "descidas íngremes" else "descida íngreme"}")
                        typeHazards.forEach { appendLine("   - ${it.description}") }
                    }
                    HazardType.HAIRPIN_TURN -> {
                        appendLine("↩️ $count ${if (count > 1) "curvas cotovelo" else "curva cotovelo"}")
                        typeHazards.forEach { appendLine("   - ${it.description}") }
                    }
                    HazardType.SHARP_TURN -> {
                        appendLine("↪️ $count ${if (count > 1) "curvas fechadas" else "curva fechada"}")
                        typeHazards.forEach { appendLine("   - ${it.description}") }
                    }
                }
                appendLine()
            }
        }
    }
}