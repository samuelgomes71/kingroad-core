package com.kingroad.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.kingroad.database.converters.CoordinatesConverter
import com.kingroad.database.converters.StringListConverter
import com.kingroad.database.converters.TimestampConverter
import java.util.Date
import java.util.UUID

/**
 * Entidade que representa um alerta de segurança no banco de dados.
 */
@Entity(tableName = "security_alerts")
@TypeConverters(CoordinatesConverter::class, StringListConverter::class, TimestampConverter::class)
data class SecurityAlert(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    
    /**
     * Tipo de alerta: cargo_theft, curtain_cutting, gas_attack
     */
    val alertType: String,
    
    /**
     * Nome da localização (ex: "Posto Shell na A1 próximo a Paris")
     */
    val locationName: String,
    
    /**
     * Coordenadas da localização
     */
    val coordinates: Coordinates,
    
    /**
     * Descrição detalhada do alerta
     */
    val description: String,
    
    /**
     * ID do usuário que criou o alerta
     */
    val reporterId: String,
    
    /**
     * Nome do usuário que criou o alerta
     */
    val reporterName: String,
    
    /**
     * Data e hora de criação do alerta
     */
    val createdAt: Date = Date(),
    
    /**
     * Data e hora da última atualização (novo comentário, etc)
     */
    val updatedAt: Date = Date(),
    
    /**
     * Lista de IDs de usuários que confirmaram o alerta
     */
    val confirmedBy: List<String> = emptyList(),
    
    /**
     * Lista de URLs de fotos anexadas ao alerta
     */
    val photos: List<String> = emptyList(),
    
    /**
     * Número de relatórios deste incidente (confirmações)
     */
    val reportCount: Int = 1,
    
    /**
     * Indica se o alerta foi verificado por moderadores
     */
    val isVerified: Boolean = false,
    
    /**
     * Se o alerta está ativo ou arquivado
     */
    val isActive: Boolean = true
)

/**
 * Classe para as coordenadas geográficas
 */
data class Coordinates(
    val latitude: Double,
    val longitude: Double
)