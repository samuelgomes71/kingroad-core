import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Truck, 
  Filter, 
  Navigation 
} from 'lucide-react';

// Tipos definidos diretamente no arquivo para evitar importações externas
enum RouteType {
  MAIN_ENTRANCE = 'MAIN_ENTRANCE',
  TRUCK_ENTRANCE = 'TRUCK_ENTRANCE', 
  LOADING_ENTRANCE = 'LOADING_ENTRANCE',
  EMERGENCY_EXIT = 'EMERGENCY_EXIT'
}

enum LoadingPointStatus {
  OPERATIONAL = 'OPERATIONAL',
  BUSY = 'BUSY',
  MAINTENANCE = 'MAINTENANCE', 
  CLOSED = 'CLOSED'
}

interface Location {
  latitude: number;
  longitude: number;
  accessRoutes: AccessRoute[];
}

interface AccessRoute {
  name: string;
  type: RouteType;
  recommendedForTrucks: boolean;
  instructions: string;
}

interface FuelType {
  name: string;
  code: string;
  isAvailable: boolean;
  specialRequirements: string[];
}

interface LoadingPoint {
  id: string;
  name: string;
  type: 'TOP_LOADING' | 'BOTTOM_LOADING' | 'DUAL_LOADING';
  capacity: number;
  fuelTypes: FuelType[];
  status: LoadingPointStatus;
  currentQueue: number;
  estimatedWaitTime: number;
}

interface ContactInfo {
  loadingDock?: string;
  emergency?: string;
}

interface DistributorFacilities {
  hasDriverRoom: boolean;
  hasWifi: boolean;
  hasParking: boolean;
  parkingCapacity: number;
  hasRestroom: boolean;
  hasWaitingArea: boolean;
  hasCafeteria: boolean;
  hasGasStation: boolean;
  hasShowers: boolean;
  hasCalibrationService: boolean;
}

interface SecurityRequirements {
  requiresPreRegistration: boolean;
  requiresIdentification: boolean;
  requiresVehicleInspection: boolean;
  requiresLoadingTraining: boolean;
  specialDocuments: string[];
}

interface OperatingHours {
  loadingHours: {
    weekday: { start: string; end: string };
  };
  timeZone?: string;
}

interface QueueStatus {
  totalTrucks: number;
  averageWaitTime: number;
  lastUpdate: number;
}

interface FuelDistributor {
  id: string;
  name: string;
  company: string;
  location: Location;
  address: string;
  country: string;
  countryCode: string;
  language?: string;
  loadingPoints: LoadingPoint[];
  operatingHours: OperatingHours;
  contact: ContactInfo;
  facilities: DistributorFacilities;
  securityRequirements: SecurityRequirements;
  fuelTypes: FuelType[];
  queueStatus: QueueStatus;
  lastUpdate: number;
}

interface DistributorFilters {
  country?: string;
  company?: string;
  fuelType?: string;
}

// Serviço de Distribuidores (versão simplificada para preview)
class FuelDistributorServicePreview {
  private distributors: FuelDistributor[] = [];

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // Dados de exemplo para múltiplos países
    const mockDistributors: FuelDistributor[] = [
      {
        id: 'petrobras_sp1',
        name: 'Base Petrobras São Paulo',
        company: 'Petrobras',
        location: {
          latitude: -23.5505,
          longitude: -46.6333,
          accessRoutes: []
        },
        address: 'Av. Industrial, 1000, São Paulo, SP',
        country: 'Brazil',
        countryCode: 'BR',
        language: 'pt',
        loadingPoints: [
          {
            id: 'sp1_b1',
            name: 'Baia 1',
            type: 'TOP_LOADING',
            capacity: 2,
            fuelTypes: [
              { 
                name: 'Diesel S10', 
                code: 'DS10', 
                isAvailable: true, 
                specialRequirements: [] 
              }
            ],
            status: LoadingPointStatus.OPERATIONAL,
            currentQueue: 3,
            estimatedWaitTime: 45
          }
        ],
        operatingHours: {
          loadingHours: {
            weekday: { start: '00:00', end: '23:59' }
          },
          timeZone: 'America/Sao_Paulo'
        },
        contact: {
          loadingDock: '+55 11 1234-5678',
          emergency: '190'
        },
        facilities: {
          hasDriverRoom: true,
          hasWifi: true,
          hasParking: true,
          parkingCapacity: 30,
          hasRestroom: true,
          hasWaitingArea: true,
          hasCafeteria: true,
          hasGasStation: true,
          hasShowers: true,
          hasCalibrationService: true
        },
        securityRequirements: {
          requiresPreRegistration: true,
          requiresIdentification: true,
          requiresVehicleInspection: true,
          requiresLoadingTraining: false,
          specialDocuments: ['MOPP', 'Ordem de Carregamento']
        },
        fuelTypes: [
          { 
            name: 'Diesel S10', 
            code: 'DS10', 
            isAvailable: true, 
            specialRequirements: [] 
          }
        ],
        queueStatus: {
          totalTrucks: 3,
          averageWaitTime: 45,
          lastUpdate: Date.now()
        },
        lastUpdate: Date.now()
      },
      // Adicionar mais distribuidores de diferentes países
      {
        id: 'shell_tx1',
        name: 'Shell Truck Stop - Texas',
        company: 'Shell',
        location: {
          latitude: 29.7604,
          longitude: -95.3698,
          accessRoutes: []
        },
        address: '1234 Truckers Lane, Houston, TX',
        country: 'United States',
        countryCode: 'US',
        language: 'en',
        loadingPoints: [
          {
            id: 'tx1_b1',
            name: 'Loading Bay 1',
            type: 'BOTTOM_LOADING',
            capacity: 4,
            fuelTypes: [
              { 
                name: 'Diesel', 
                code: 'DSL', 
                isAvailable: true, 
                specialRequirements: [] 
              }
            ],
            status: LoadingPointStatus.OPERATIONAL,
            currentQueue: 2,
            estimatedWaitTime: 30
          }
        ],
        operatingHours: {
          loadingHours: {
            weekday: { start: '06:00', end: '22:00' }
          },
          timeZone: 'America/Chicago'
        },
        contact: {
          loadingDock: '+1 713-555-1234',
          emergency: '911'
        },
        facilities: {
          hasDriverRoom: true,
          hasWifi: true,
          hasParking: true,
          parkingCapacity: 50,
          hasRestroom: true,
          hasWaitingArea: true,
          hasCafeteria: true,
          hasGasStation: true,
          hasShowers: true,
          hasCalibrationService: false
        },
        securityRequirements: {
          requiresPreRegistration: false,
          requiresIdentification: true,
          requiresVehicleInspection: false,
          requiresLoadingTraining: false,
          specialDocuments: ['Commercial Driver License']
        },
        fuelTypes: [
          { 
            name: 'Diesel', 
            code: 'DSL', 
            isAvailable: true, 
            specialRequirements: [] 
          }
        ],
        queueStatus: {
          totalTrucks: 2,
          averageWaitTime: 30,
          lastUpdate: Date.now()
        },
        lastUpdate: Date.now()
      }
    ];

    this.distributors = mockDistributors;
  }

  // Método para buscar distribuidores
  findNearbyDistributors(
    latitude: number, 
    longitude: number, 
    options: {
      radiusKm?: number;
      filters?: DistributorFilters;
    } = {}
  ): FuelDistributor[] {
    const { radiusKm = 500, filters = {} } = options;
    
    return this.distributors.filter(distributor => {
      // Lógica de filtro simplificada
      const matchesCompany = !filters.company || distributor.company === filters.company;
      const matchesFuelType = !filters.fuelType || 
        distributor.fuelTypes.some(fuel => fuel.code === filters.fuelType);
      
      return matchesCompany && matchesFuelType;
    });
  }
}

// Componente de Preview
const FuelDistributorPreview: React.FC = () => {
  const [service] = useState(new FuelDistributorServicePreview());
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [nearbyDistributors, setNearbyDistributors] = useState<FuelDistributor[]>([]);

  // Simula localização do usuário (poderia ser geolocalização real)
  const userLocation = { 
    latitude: -23.5505, 
    longitude: -46.6333 
  };

  useEffect(() => {
    // Busca distribuidores ao carregar e quando filtros mudam
    const distributors = service.findNearbyDistributors(
      userLocation.latitude, 
      userLocation.longitude, 
      {
        filters: {
          country: selectedCountry || undefined,
          company: selectedCompany || undefined
        }
      }
    );
    setNearbyDistributors(distributors);
  }, [selectedCountry, selectedCompany]);

  return (
    <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4 dark:text-white flex items-center">
        <Navigation className="mr-2" /> Distribuidor de Combustível - Preview
      </h2>

      {/* Filtros */}
      <div className="mb-4 grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium dark:text-gray-300">
            Filtrar por País
          </label>
          <select 
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-800 dark:border-gray-700"
          >
            <option value="">Todos os Países</option>
            <option value="Brazil">Brasil</option>
            <option value="United States">Estados Unidos</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium dark:text-gray-300">
            Filtrar por Empresa
          </label>
          <select 
            value={selectedCompany}
            onChange={(e) => setSelectedCompany(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-800 dark:border-gray-700"
          >
            <option value="">Todas as Empresas</option>
            <option value="Petrobras">Petrobras</option>
            <option value="Shell">Shell</option>
          </select>
        </div>
      </div>

      {/* Lista de Distribuidores */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold dark:text-white">
          Distribuidores Próximos
        </h3>
        {nearbyDistributors.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400">
            Nenhum distribuidor encontrado com os filtros selecionados.
          </p>
        ) : (
          nearbyDistributors.map(distributor => (
            <div 
              key={distributor.id} 
              className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-lg font-bold dark:text-white">
                    {distributor.name}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 flex items-center">
                    <MapPin className="mr-2 w-4 h-4" />
                    {distributor.address}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Truck className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                  <span className="text-sm dark:text-white">
                    {distributor.queueStatus.totalTrucks} caminhões
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FuelDistributorPreview;