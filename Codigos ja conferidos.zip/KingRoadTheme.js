import React, { createContext, useContext, useState, useEffect } from 'react';

// Criação do ThemeContext para compartilhar o tema por toda a aplicação
const ThemeContext = createContext();

// Definição dos temas do KingRoad
// Implementa a funcionalidade mencionada em "temas": "Claro/escuro com alternância e suporte futuro a visuais personalizados"
const KingRoadThemes = {
  // Tema claro
  light: {
    primary: '#0063B2', // Azul KingRoad principal
    secondary: '#5CC8FF', // Azul KingRoad secundário 
    accent: '#FFB31A', // Amarelo para alertas e destaques
    danger: '#D62828', // Vermelho para alertas críticos
    success: '#24A148', // Verde para confirmações
    background: '#FFFFFF',
    surface: '#F5F7FA',
    text: {
      primary: '#212121',
      secondary: '#616161',
      disabled: '#9E9E9E',
      inverse: '#FFFFFF'
    },
    border: '#E0E0E0'
  },
  // Tema escuro
  dark: {
    primary: '#1A85FF', // Azul KingRoad mais brilhante para modo escuro
    secondary: '#4DA8DA', // Azul KingRoad secundário para modo escuro
    accent: '#FFBF40', // Amarelo para alertas e destaques (modo escuro)
    danger: '#E53E3E', // Vermelho para alertas críticos (modo escuro)
    success: '#2BB84B', // Verde para confirmações (modo escuro)
    background: '#121212',
    surface: '#1E1E1E',
    text: {
      primary: '#FFFFFF',
      secondary: '#BDBDBD',
      disabled: '#757575',
      inverse: '#212121'
    },
    border: '#2D2D2D'
  },
  // Tema de alto contraste para acessibilidade
  highContrast: {
    primary: '#007AFF',
    secondary: '#00BAFF',
    accent: '#FFD700',
    danger: '#FF0000',
    success: '#00FF00',
    background: '#000000',
    surface: '#0A0A0A',
    text: {
      primary: '#FFFFFF',
      secondary: '#FFFFFF',
      disabled: '#CCCCCC',
      inverse: '#000000'
    },
    border: '#FFFFFF'
  }
};

// Componente provedor do tema
const ThemeProvider = ({ children, initialTheme = 'light' }) => {
  // Estado para o tema atual
  const [currentTheme, setCurrentTheme] = useState(initialTheme);
  
  // Estado para verificar se o dispositivo está em modo escuro
  const [isSystemDarkMode, setIsSystemDarkMode] = useState(false);
  
  // Efeito para detectar a preferência de cor do sistema
  useEffect(() => {
    // Verifica se estamos no navegador e se há suporte para matchMedia
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      setIsSystemDarkMode(mediaQuery.matches);
      
      // Ouvinte para mudanças na preferência de cor do sistema
      const handleChange = (e) => setIsSystemDarkMode(e.matches);
      mediaQuery.addEventListener('change', handleChange);
      
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, []);
  
  // Obtém o tema atual
  const theme = KingRoadThemes[currentTheme] || KingRoadThemes.light;
  
  // Função para alternar entre temas claro e escuro
  const toggleTheme = () => {
    setCurrentTheme(prev => prev === 'light' ? 'dark' : 'light');
  };
  
  // Função para definir um tema específico
  const setTheme = (themeName) => {
    if (KingRoadThemes[themeName]) {
      setCurrentTheme(themeName);
    } else {
      console.warn(`Tema "${themeName}" não encontrado. Usando tema padrão.`);
      setCurrentTheme('light');
    }
  };
  
  // Função para seguir o tema do sistema
  const followSystemTheme = () => {
    setCurrentTheme(isSystemDarkMode ? 'dark' : 'light');
  };
  
  // Valor do contexto
  const contextValue = {
    theme,
    currentTheme,
    toggleTheme,
    setTheme,
    followSystemTheme,
    isSystemDarkMode,
    allThemes: Object.keys(KingRoadThemes)
  };
  
  // Componente de visualização do tema
  return (
    <ThemeContext.Provider value={contextValue}>
      {children}
    </ThemeContext.Provider>
  );
};

// Hook personalizado para usar o tema
const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme deve ser usado dentro de um ThemeProvider');
  }
  return context;
};

// Componente de exibição para visualizar as cores do tema (para fins de Debug/Preview)
const ThemeDisplay = () => {
  const { theme, currentTheme, toggleTheme, setTheme, allThemes } = useTheme();
  
  return (
    <div className="p-6 max-w-lg mx-auto">
      <h2 className="text-xl font-bold mb-4">KingRoad Theme: {currentTheme}</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        {Object.entries(theme).map(([key, value]) => {
          // Pula objetos aninhados para uma exibição mais simples
          if (typeof value === 'object') return null;
          
          return (
            <div key={key} className="flex items-center">
              <div 
                className="w-12 h-12 rounded-md mr-3" 
                style={{ backgroundColor: value }}
              />
              <div>
                <p className="font-medium">{key}</p>
                <p className="text-xs opacity-70">{value}</p>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Cores de texto */}
      <h3 className="font-bold mb-2">Cores de Texto</h3>
      <div className="grid grid-cols-2 gap-4 mb-6">
        {Object.entries(theme.text).map(([key, value]) => (
          <div key={key} className="flex items-center">
            <div 
              className="w-12 h-12 rounded-md mr-3 flex items-center justify-center" 
              style={{ backgroundColor: theme.background, color: value }}
            >
              Aa
            </div>
            <div>
              <p className="font-medium">text.{key}</p>
              <p className="text-xs opacity-70">{value}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Controles de tema */}
      <div className="flex flex-wrap gap-2 mt-4">
        <button 
          onClick={toggleTheme}
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
        >
          Alternar Tema
        </button>
        
        {allThemes.map(themeName => (
          <button 
            key={themeName}
            onClick={() => setTheme(themeName)}
            className={`px-4 py-2 rounded-md ${
              currentTheme === themeName 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            {themeName}
          </button>
        ))}
      </div>
    </div>
  );
};

export { ThemeProvider, useTheme, ThemeDisplay, KingRoadThemes };
export default ThemeProvider;