data class SelfServiceFuelStation(
    val id: String,
    val brand: String,
    val location: Location,
    val address: String,
    val country: String,
    val services: StationServices,
    val fuelTypes: List<FuelType>,
    val paymentMethods: List<PaymentMethod>,
    val facilities: StationFacilities,
    val access: TruckAccess,
    val operatingHours: OperatingHours,
    val reviews: List<StationReview>,
    val lastUpdate: Long = System.currentTimeMillis()
)

data class Location(
    val latitude: Double,
    val longitude: Double,
    val roadInfo: RoadInfo? = null,
    val directions: String? = null
)

data class RoadInfo(
    val roadName: String,
    val kilometer: Double? = null,
    val exitNumber: String? = null,
    val direction: Direction? = null
)

enum class Direction {
    NORTHBOUND,
    SOUTHBOUND,
    EASTBOUND,
    WESTBOUND
}

data class StationServices(
    val selfService: Boolean = true,
    val hasRoof: Boolean = false,
    val highFlowPumps: Boolean = false,
    val adBlue: Boolean = false,
    val adBluePump: Boolean = false,
    val truckWash: Boolean = false,
    val airPump: Boolean = false,
    val shopAvailable: Boolean = false
)

data class FuelType(
    val code: String,
    val name: String,
    val isAvailable: Boolean = true,
    val price: Double? = null,
    val priceDate: Long? = null,
    val currency: String = "EUR"
)

data class PaymentMethod(
    val type: PaymentType,
    val networks: List<String> = listOf(),
    val requiresRegistration: Boolean = false
)

enum class PaymentType {
    FUEL_CARD,
    CREDIT_CARD,
    DEBIT_CARD,
    MOBILE_APP,
    CASH,
    CONTACTLESS
}

data class StationFacilities(
    val restrooms: Boolean = false,
    val parking: Boolean = false,
    val numberOfParkingSpots: Int = 0,
    val overnightParking: Boolean = false,
    val food: Boolean = false,
    val wifi: Boolean = false
)

data class TruckAccess(
    val suitableForTrucks: Boolean = true,
    val maxHeight: Double? = null,
    val maxWeight: Double? = null,
    val wideAccess: Boolean = true,
    val easyEntry: Boolean = true,
    val easyExit: Boolean = true,
    val hasTrafficJams: Boolean = false,
    val accessNotes: String? = null
)

data class OperatingHours(
    val is24Hours: Boolean = true,
    val schedule: Schedule? = null,
    val shopHours: Schedule? = null
)

data class Schedule(
    val monday: TimeRange? = null,
    val tuesday: TimeRange? = null,
    val wednesday: TimeRange? = null,
    val thursday: TimeRange? = null,
    val friday: TimeRange? = null,
    val saturday: TimeRange? = null,
    val sunday: TimeRange? = null
)

data class TimeRange(
    val open: String,  // formato "HH:mm"
    val close: String  // formato "HH:mm"
)

data class StationReview(
    val rating: Int,        // 1-5
    val comment: String,
    val date: Long,
    val driverType: String? = null
)

class SelfServiceStationService(
    private val vehiclePOIService: VehicleSpecificPOIService
) {
    private val stations = mutableMapOf<String, SelfServiceFuelStation>()

    // Adiciona uma estação ao serviço
    fun addStation(station: SelfServiceFuelStation) {
        stations[station.id] = station
    }

    // Busca estações próximas
    fun findNearbyStations(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 50.0,
        vehicleConfig: VehicleConfiguration,
        filters: StationFilters = StationFilters()
    ): List<SelfServiceFuelStation> {
        // Primeiro verifica se é um tipo de veículo suportado
        if (!vehiclePOIService.shouldShowPOI(POIType.SELF_SERVICE_FUEL, vehicleConfig)) {
            return emptyList()
        }

        return stations.values.filter { station ->
            // Verifica distância
            val distance = calculateDistance(
                latitude, longitude,
                station.location.latitude, station.location.longitude
            )
            
            if (distance > radiusKm) return@filter false
            
            // Verifica brand se especificado
            if (filters.brands.isNotEmpty() && 
                !filters.brands.contains(station.brand)) {
                return@filter false
            }
            
            // Verifica disponibilidade de combustível
            if (filters.requiredFuelTypes.isNotEmpty()) {
                val hasFuel = station.fuelTypes.any { fuel ->
                    filters.requiredFuelTypes.contains(fuel.code) && fuel.isAvailable
                }
                if (!hasFuel) return@filter false
            }
            
            // Verifica métodos de pagamento
            if (filters.paymentMethods.isNotEmpty()) {
                val hasPayment = station.paymentMethods.any { payment ->
                    filters.paymentMethods.contains(payment.type)
                }
                if (!hasPayment) return@filter false
            }
            
            // Verifica serviços específicos
            if (filters.requiresAdBlue && 
                !(station.services.adBlue || station.services.adBluePump)) {
                return@filter false
            }
            
            if (filters.requiresHighFlowPumps && !station.services.highFlowPumps) {
                return@filter false
            }
            
            if (filters.requires24Hours && !station.operatingHours.is24Hours) {
                return@filter false
            }
            
            // Passou em todos os filtros
            true
        }.sortedBy { station ->
            calculateDistance(
                latitude, longitude,
                station.location.latitude, station.location.longitude
            )
        }
    }

    data class StationFilters(
        val brands: List<String> = listOf(),
        val requiredFuelTypes: List<String> = listOf(),
        val paymentMethods: List<PaymentType> = listOf(),
        val requiresAdBlue: Boolean = false,
        val requiresHighFlowPumps: Boolean = false,
        val requires24Hours: Boolean = true
    )

    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val R = 6371.0 // Raio da Terra em km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }

    // Carrega dados iniciais para teste
    fun loadEuropeanStations() {
        // AS24 - Espanha
        addStation(
            SelfServiceFuelStation(
                id = "as24_es_md01",
                brand = "AS24",
                location = Location(
                    latitude = 40.4165, 
                    longitude = -3.7026,
                    roadInfo = RoadInfo(
                        roadName = "A-4",
                        kilometer = 17.5,
                        exitNumber = "17"
                    ),
                    directions = "Saída 17, à direita depois do pedágio"
                ),
                address = "Calle Principal s/n, 28001 Madrid, España",
                country = "ES",
                services = StationServices(
                    selfService = true,
                    hasRoof = false,
                    highFlowPumps = true,
                    adBlue = true,
                    adBluePump = true,
                    truckWash = false,
                    airPump = true,
                    shopAvailable = false
                ),
                fuelTypes = listOf(
                    FuelType("DIESEL", "Diesel", true, 1.35, System.currentTimeMillis(), "EUR"),
                    FuelType("ADBLUE", "AdBlue", true, 0.65, System.currentTimeMillis(), "EUR")
                ),
                paymentMethods = listOf(
                    PaymentMethod(
                        type = PaymentType.FUEL_CARD,
                        networks = listOf("AS24", "DKV", "UTA", "EUROWAG"),
                        requiresRegistration = true
                    ),
                    PaymentMethod(
                        type = PaymentType.CREDIT_CARD,
                        networks = listOf("VISA", "MASTERCARD"),
                        requiresRegistration = false
                    )
                ),
                facilities = StationFacilities(
                    restrooms = false,
                    parking = true,
                    numberOfParkingSpots = 10,
                    overnightParking = true,
                    food = false,
                    wifi = false
                ),
                access = TruckAccess(
                    suitableForTrucks = true,
                    maxHeight = null,
                    maxWeight = null,
                    wideAccess = true,
                    easyEntry = true,
                    easyExit = true,
                    hasTrafficJams = false,
                    accessNotes = "Acesso amplo, adequado para todos os caminhões"
                ),
                operatingHours = OperatingHours(
                    is24Hours = true,
                    schedule = null,
                    shopHours = null
                ),
                reviews = listOf(
                    StationReview(
                        rating = 4,
                        comment = "Bom para abastecer rapidamente, sem filas",
                        date = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000),
                        driverType = "TRUCK_LONG_HAUL"
                    )
                )
            )
        )

        // IDS - Holanda
        addStation(
            SelfServiceFuelStation(
                id = "ids_nl_rt01",
                brand = "IDS",
                location = Location(
                    latitude = 51.9244, 
                    longitude = 4.4777,
                    roadInfo = RoadInfo(
                        roadName = "A15",
                        kilometer = 45.8,
                        exitNumber = "12"
                    ),
                    directions = "Na área de descanso após a saída 12"
                ),
                address = "Maasvlakte 125, Rotterdam, Nederland",
                country = "NL",
                services = StationServices(
                    selfService = true,
                    hasRoof = false,
                    highFlowPumps = true,
                    adBlue = true,
                    adBluePump = true,
                    truckWash = false,
                    airPump = true,
                    shopAvailable = false
                ),
                fuelTypes = listOf(
                    FuelType("DIESEL", "Diesel", true, 1.42, System.currentTimeMillis(), "EUR"),
                    FuelType("ADBLUE", "AdBlue", true, 0.70, System.currentTimeMillis(), "EUR")
                ),
                paymentMethods = listOf(
                    PaymentMethod(
                        type = PaymentType.FUEL_CARD,
                        networks = listOf("IDS", "DKV", "UTA", "EUROWAG"),
                        requiresRegistration = true
                    ),
                    PaymentMethod(
                        type = PaymentType.CONTACTLESS,
                        networks = listOf("VISA", "MASTERCARD"),
                        requiresRegistration = false
                    )
                ),
                facilities = StationFacilities(
                    restrooms = false,
                    parking = true,
                    numberOfParkingSpots = 15,
                    overnightParking = true,
                    food = false,
                    wifi = true
                ),
                access = TruckAccess(
                    suitableForTrucks = true,
                    maxHeight = null,
                    maxWeight = null,
                    wideAccess = true,
                    easyEntry = true,
                    easyExit = true,
                    hasTrafficJams = false,
                    accessNotes = "Localizado em área de serviço para caminhões"
                ),
                operatingHours = OperatingHours(
                    is24Hours = true
                ),
                reviews = listOf(
                    StationReview(
                        rating = 5,
                        comment = "Ótima localização, bomba de AdBlue funciona bem",
                        date = System.currentTimeMillis() - (15L * 24 * 60 * 60 * 1000),
                        driverType = "TRUCK_INTERNATIONAL"
                    )
                )
            )
        )
    }
}