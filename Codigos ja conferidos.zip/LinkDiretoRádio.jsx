import React, { useState, useEffect } from 'react';
import { Link, Radio, ArrowLeft, Play, Star, Check, AlertCircle, Loader } from 'lucide-react';

const LinkDiretoRadio = () => {
  const [radioUrl, setRadioUrl] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [validationStatus, setValidationStatus] = useState(null); // null, 'validating', 'valid', 'invalid'
  const [radioInfo, setRadioInfo] = useState(null);
  const [validationTimer, setValidationTimer] = useState(0);
  const [validationMessage, setValidationMessage] = useState('');
  
  // Estilo "Família 15": borda café, fundo bege claro
  const familyStyle = {
    borderColor: '#8B4513', // café
    backgroundColor: '#F5F5DC' // bege claro
  };
  
  // Simula validação quando o usuário cola um URL
  useEffect(() => {
    if (radioUrl && radioUrl.trim() !== '' && !isValidating) {
      // Limpa qualquer validação pendente
      setValidationStatus('validating');
      setValidationMessage('Verificando link...');
      setIsValidating(true);
      setValidationTimer(0);
      setRadioInfo(null);
      
      // Timer para simular os 3 segundos de validação especificados no documento
      const intervalId = setInterval(() => {
        setValidationTimer(prev => {
          const newTime = prev + 1;
          
          // Após 3 segundos, determinar se é válido (simulação)
          if (newTime >= 3) {
            clearInterval(intervalId);
            
            // Simula validação bem-sucedida para URLs contendo 'radio' ou 'fm'
            if (radioUrl.toLowerCase().includes('radio') || radioUrl.toLowerCase().includes('fm')) {
              setValidationStatus('valid');
              setValidationMessage('Link válido! Rádio pronta para tocar.');
              
              // Informações simuladas da rádio encontrada
              setRadioInfo({
                name: radioUrl.includes('caminhoneiros') 
                  ? 'Rádio Caminhoneiros FM' 
                  : 'Rádio ' + radioUrl.split('.')[0].split('//')[1],
                country: 'Brasil',
                language: 'Português',
                quality: 'Alta (128kbps)',
                format: 'MP3'
              });
            } else {
              setValidationStatus('invalid');
              setValidationMessage('Link inválido ou rádio indisponível. Verifique o endereço.');
            }
            
            setIsValidating(false);
            return 0;
          }
          
          return newTime;
        });
      }, 1000);
      
      return () => clearInterval(intervalId);
    }
  }, [radioUrl]);
  
  const handleInputChange = (e) => {
    setRadioUrl(e.target.value);
  };
  
  const handlePaste = (e) => {
    // Permitir cola normal do conteúdo
    const pasted = e.clipboardData.getData('text');
    if (pasted && pasted.trim() !== '') {
      // Se for uma URL válida, inicia a validação
      if (pasted.startsWith('http://') || pasted.startsWith('https://') || pasted.includes('://')) {
        setRadioUrl(pasted);
      }
    }
  };
  
  const getStatusColor = () => {
    switch (validationStatus) {
      case 'valid': return 'text-green-600';
      case 'invalid': return 'text-red-600';
      case 'validating': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };
  
  const getStatusIcon = () => {
    switch (validationStatus) {
      case 'valid': return <Check className="h-5 w-5 text-green-600" />;
      case 'invalid': return <AlertCircle className="h-5 w-5 text-red-600" />;
      case 'validating': return <Loader className="h-5 w-5 text-blue-600 animate-spin" />;
      default: return <Link className="h-5 w-5 text-gray-400" />;
    }
  };
  
  return (
    <div className="max-w-md mx-auto bg-white">
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="flex items-center">
          <button className="p-1 mr-2 rounded-full hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h2 className="text-lg font-semibold flex items-center">
            <Link className="h-5 w-5 mr-2 text-blue-600" />
            Adicionar Rádio por Link
          </h2>
        </div>
        
        <div className="mt-4">
          <label htmlFor="radio-url" className="block text-sm font-medium text-gray-700 mb-1">
            Link direto da rádio
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <input
              type="text"
              id="radio-url"
              className={`block w-full pr-10 sm:text-sm rounded-md focus:ring-1 focus:outline-none border ${
                validationStatus === 'valid' 
                  ? 'border-green-300 focus:ring-green-500 focus:border-green-500' 
                  : validationStatus === 'invalid'
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                    : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'
              }`}
              placeholder="Exemplo: https://streamingv2.shoutcast.com/radio-caminhoneiros"
              value={radioUrl}
              onChange={handleInputChange}
              onPaste={handlePaste}
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              {getStatusIcon()}
            </div>
          </div>
          
          <div className={`mt-2 text-sm ${getStatusColor()}`}>
            {validationStatus === 'validating' && (
              <div className="flex items-center">
                <span>{validationMessage} ({validationTimer}/3s)</span>
              </div>
            )}
            {validationStatus !== 'validating' && validationMessage && (
              <div>{validationMessage}</div>
            )}
          </div>
        </div>
      </div>
      
      {/* Detalhes da rádio validada */}
      {validationStatus === 'valid' && radioInfo && (
        <div 
          className="p-4 rounded-md mx-4 my-4"
          style={{
            backgroundColor: familyStyle.backgroundColor,
            border: '1px solid',
            borderColor: familyStyle.borderColor
          }}
        >
          <div className="flex items-center mb-3">
            <div className="bg-white p-1 rounded-full mr-3 border border-gray-200">
              <Radio className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{radioInfo.name}</h3>
              <p className="text-xs text-gray-600">{radioInfo.country} • {radioInfo.language}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-xs text-gray-700 mb-4">
            <div>
              <span className="font-medium">Qualidade:</span> {radioInfo.quality}
            </div>
            <div>
              <span className="font-medium">Formato:</span> {radioInfo.format}
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button 
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md font-medium text-sm flex items-center justify-center"
            >
              <Play className="h-4 w-4 mr-1" />
              Tocar agora
            </button>
            <button 
              className="flex-1 bg-white hover:bg-gray-50 text-gray-800 py-2 px-4 rounded-md border border-gray-300 font-medium text-sm flex items-center justify-center"
            >
              <Star className="h-4 w-4 mr-1" />
              Salvar nos favoritos
            </button>
          </div>
        </div>
      )}
      
      {/* Instruções */}
      <div className="p-4 border-t border-gray-200">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Como funciona:</h3>
        <ul className="text-xs text-gray-600 space-y-1">
          <li className="flex items-start">
            <span className="text-blue-600 font-bold mr-2">1.</span>
            Cole o endereço direto da rádio no campo acima
          </li>
          <li className="flex items-start">
            <span className="text-blue-600 font-bold mr-2">2.</span>
            Aguarde a validação automática (leva 3 segundos)
          </li>
          <li className="flex items-start">
            <span className="text-blue-600 font-bold mr-2">3.</span>
            Se válido, você poderá tocar ou salvar nos favoritos
          </li>
        </ul>
        
        <div className="mt-3 p-2 bg-blue-50 rounded-md text-xs text-blue-800">
          <p>Dica: Para encontrar o link direto de uma rádio, visite o site oficial da rádio e procure por "streaming", "ouça ao vivo" ou "escute agora".</p>
        </div>
      </div>
    </div>
  );
};

export default LinkDiretoRadio;