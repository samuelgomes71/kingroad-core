import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, Modal, StyleSheet, Image, ActivityIndicator, Alert, Platform } from 'react-native';
import { Camera } from 'react-native-vision-camera';
import DocumentPicker from 'react-native-document-picker';
import RNFetchBlob from 'rn-fetch-blob';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import RNFS from 'react-native-fs';
import { useTranslation } from 'react-i18next';

// Importe o gerenciador de banco de dados local (SQLite ou outro usado no projeto)
import { getDatabase } from '../database/DatabaseManager'; // Ajuste o caminho conforme seu projeto

/**
 * Modal para captura e envio de documentos escaneados pelo aplicativo
 * 
 * Funcionalidades:
 * - Tirar foto de documento com a câmera
 * - Selecionar documento da galeria/arquivos
 * - Pré-visualização com opção de recorte
 * - OCR básico para detectar texto nos documentos
 * - Envio para o backend com metadados
 * 
 * @param {boolean} visible - Controla a visibilidade do modal
 * @param {function} onClose - Função chamada ao fechar o modal
 * @param {function} onUploadSuccess - Callback quando o upload é bem-sucedido
 * @param {string} tripId - ID da viagem relacionada (opcional)
 * @param {string} poiId - ID do ponto de interesse relacionado (opcional)
 * @param {string} documentType - Tipo de documento (NF, recibo, comprovante)
 * @param {string} storageMode - Modo de armazenamento (permanent, temporary, cache)
 */
const KingScannerUploadModal = ({ 
  visible, 
  onClose, 
  onUploadSuccess, 
  tripId = null, 
  poiId = null,
  documentType = 'receipt', // Valores possíveis: 'receipt', 'invoice', 'delivery_proof'
  storageMode = 'permanent' // Valores possíveis: 'permanent', 'temporary', 'cache'
}) => {
  const { t } = useTranslation();
  const [image, setImage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasPermission, setHasPermission] = useState(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');
  const cameraRef = useRef(null);

  // Solicitar permissões de câmera ao montar o componente
  useEffect(() => {
    (async () => {
      const cameraPermission = await Camera.requestCameraPermission();
      setHasPermission(cameraPermission === 'authorized');
    })();
  }, []);

  // Reset do estado ao abrir o modal
  useEffect(() => {
    if (visible) {
      setImage(null);
      setRecognizedText('');
      setIsProcessing(false);
    }
  }, [visible]);

  // Função para tirar foto
  const takePicture = async () => {
    try {
      if (cameraRef.current) {
        setIsLoading(true);
        const photo = await cameraRef.current.takePhoto({
          flash: 'auto',
          enableShutterSound: false,
        });
        
        setImage(`file://${photo.path}`);
        setIsCameraOpen(false);
        
        // Processar OCR após capturar a imagem
        processOCR(`file://${photo.path}`);
      }
    } catch (error) {
      console.error('Erro ao capturar foto:', error);
      Alert.alert(t('error'), t('camera_error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Função para selecionar documento da galeria
  const pickDocument = async () => {
    try {
      setIsLoading(true);
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.pdf],
      });
      
      if (result[0].type === 'application/pdf') {
        // Processar PDF (não implementado neste exemplo)
        setImage(null);
        Alert.alert(t('info'), t('pdf_not_supported_yet'));
      } else {
        setImage(result[0].uri);
        processOCR(result[0].uri);
      }
    } catch (error) {
      if (!DocumentPicker.isCancel(error)) {
        console.error('Erro ao selecionar documento:', error);
        Alert.alert(t('error'), t('document_selection_error'));
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Função que simula o processamento OCR 
  // (em produção, seria integrado com uma biblioteca OCR real)
  const processOCR = async (imageUri) => {
    try {
      setIsProcessing(true);
      
      // Simulação de OCR - Em produção, usar biblioteca como Tesseract.js ou API
      // Este é apenas um placeholder para a funcionalidade real
      setTimeout(() => {
        // Dados simulados detectados pelo OCR
        const simulatedText = documentType === 'receipt' 
          ? 'Total: R$ 235,90\nData: 22/03/2025\nPosto: KINGS GAS STATION' 
          : 'Nº Documento: 78954\nEmissor: KingRoad Logistics\nData: 22/03/2025';
        
        setRecognizedText(simulatedText);
        setIsProcessing(false);
      }, 2000);
      
    } catch (error) {
      console.error('Erro no processamento OCR:', error);
      setIsProcessing(false);
      Alert.alert(t('error'), t('ocr_processing_error'));
    }
  };

  // Função para salvar informações do documento no banco de dados local
  const saveDocumentInfoToDatabase = async (docInfo) => {
    try {
      const db = await getDatabase();
      // Inserir as informações do documento no banco de dados
      await db.executeSql(
        `INSERT INTO documents (
          local_path, 
          remote_path, 
          document_type, 
          trip_id, 
          poi_id, 
          recognized_text, 
          created_at,
          is_uploaded,
          file_name
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          docInfo.localPath,
          docInfo.remotePath || null,
          docInfo.documentType,
          docInfo.tripId || null,
          docInfo.poiId || null,
          docInfo.recognizedText || '',
          new Date().toISOString(),
          docInfo.isUploaded ? 1 : 0,
          docInfo.fileName
        ]
      );
      console.log('Documento salvo no banco de dados local');
    } catch (error) {
      console.error('Erro ao salvar no banco de dados:', error);
      // Continuamos mesmo com erro no banco, pois o arquivo já está salvo no sistema
    }
  };

  // Determina o caminho adequado baseado no modo de armazenamento
  const getStoragePath = () => {
    // Base do caminho por tipo de armazenamento
    let basePath;
    
    switch (storageMode) {
      case 'permanent':
        // Para documentos que precisam persistir mesmo após reiniciar o app
        basePath = RNFS.DocumentDirectoryPath;
        break;
      case 'temporary':
        // Para documentos temporários que podem ser excluídos se necessário
        basePath = Platform.OS === 'ios' 
          ? `${RNFS.TemporaryDirectoryPath}` 
          : `${RNFS.ExternalDirectoryPath}`;
        break;
      case 'cache':
      default:
        // Para arquivos de cache (removidos pelo sistema se necessário)
        basePath = RNFS.CachesDirectoryPath;
        break;
    }
    
    return basePath;
  };

  // Função para fazer upload do documento
  const uploadDocument = async () => {
    if (!image) return;
    
    try {
      setIsLoading(true);
      
      // Preparar dados para upload
      const filename = `doc_${Date.now()}.jpg`;
      
      // Definir o caminho apropriado para armazenamento dos documentos
      const currentDate = new Date();
      const year = currentDate.getFullYear();
      const month = String(currentDate.getMonth() + 1).padStart(2, '0');
      const day = String(currentDate.getDate()).padStart(2, '0');
      
      // Obter base do caminho conforme configuração
      const baseStoragePath = getStoragePath();
      
      // Criar estrutura de diretórios organizada
      const docsBasePath = `${baseStoragePath}/KingRoad/Documents/${documentType}/${year}/${month}/${day}`;
      
      try {
        // Criar diretório recursivamente (para garantir que toda estrutura existe)
        await RNFS.mkdir(docsBasePath, { NSURLIsExcludedFromBackupKey: false });
      } catch (dirError) {
        console.log('Diretório já existe ou erro ao criar:', dirError);
        // Continuar mesmo se o diretório já existir
      }
      
      // Caminho completo para o documento
      const destPath = `${docsBasePath}/${filename}`;
      
      console.log(`Salvando documento em: ${destPath}`);
      
      // Comprimir imagem antes do upload (em produção, usar biblioteca de compressão)
      await RNFS.copyFile(image, destPath);
      
      // Preparar metadados com informação de caminho
      const metadata = {
        tripId,
        poiId,
        documentType,
        captureDate: new Date().toISOString(),
        recognizedText,
        isOffline: false, // Verificação se está online
        localPath: destPath, // Caminho local do arquivo
        remotePath: null, // Será preenchido após upload bem-sucedido
        fileName: filename
      };
      
      // Código de upload - aqui seria sua API real
      // Simulando upload bem-sucedido após 2 segundos
      setTimeout(() => {
        setIsLoading(false);
        
        // Simular resposta do servidor com caminho remoto
        const serverResponse = {
          success: true,
          documentId: `doc_${Date.now()}`,
          remotePath: `https://api.kingroad.com/documents/${filename}`,
          // Em produção, o servidor retornaria o caminho real do arquivo no S3 ou outro storage
        };
        
        // Atualizar metadados com o caminho remoto
        metadata.remotePath = serverResponse.remotePath;
        
        // Criar objeto completo de informações do documento
        const documentInfo = {
          id: serverResponse.documentId,
          localPath: destPath,
          remotePath: serverResponse.remotePath,
          documentType,
          tripId,
          poiId,
          recognizedText,
          fileName: filename,
          isUploaded: true
        };
        
        // Salvar informações do documento no banco de dados local
        saveDocumentInfoToDatabase(documentInfo);
        
        // Notificar sucesso e fechar modal
        if (onUploadSuccess) {
          onUploadSuccess({
            id: serverResponse.documentId,
            url: image,
            localPath: destPath,
            remotePath: serverResponse.remotePath,
            metadata
          });
        }
        
        // Limpar e fechar
        setImage(null);
        onClose();
        
        // Feedback visual
        Alert.alert(
          t('success'),
          t('document_uploaded_successfully')
        );
      }, 2000);
      
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      setIsLoading(false);
      Alert.alert(t('error'), t('upload_error'));
    }
  };

  // Renderização da câmera
  const renderCamera = () => {
    if (hasPermission === null) {
      return <View style={styles.centerContainer}><ActivityIndicator size="large" color="#0066CC" /></View>;
    }
    
    if (hasPermission === false) {
      return (
        <View style={styles.centerContainer}>
          <Text style={styles.errorText}>{t('camera_permission_denied')}</Text>
          <TouchableOpacity style={styles.button} onPress={onClose}>
            <Text style={styles.buttonText}>{t('close')}</Text>
          </TouchableOpacity>
        </View>
      );
    }
    
    return (
      <View style={styles.cameraContainer}>
        <Camera
          ref={cameraRef}
          style={styles.camera}
          device={Camera.getAvailableCameraDevices()[0]}
          isActive={true}
          photo={true}
          preset="high"
        />
        
        <View style={styles.cameraControls}>
          <TouchableOpacity style={styles.closeButton} onPress={() => setIsCameraOpen(false)}>
            <Icon name="close" size={30} color="#FFF" />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.captureButton} onPress={takePicture} disabled={isLoading}>
            {isLoading ? (
              <ActivityIndicator size="large" color="#FFF" />
            ) : (
              <Icon name="camera" size={36} color="#FFF" />
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // Renderização principal
  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        {/* Cabeçalho */}
        <View style={styles.header}>
          <Text style={styles.headerText}>
            {t('document_scanner')} - {t(documentType)}
          </Text>
          <TouchableOpacity onPress={onClose} style={styles.closeHeaderButton}>
            <Icon name="close" size={24} color="#333" />
          </TouchableOpacity>
        </View>

        {/* Conteúdo principal */}
        {isCameraOpen ? (
          renderCamera()
        ) : (
          <View style={styles.content}>
            {/* Área de visualização da imagem */}
            {image ? (
              <View style={styles.previewContainer}>
                <Image source={{ uri: image }} style={styles.preview} />
                
                {isProcessing ? (
                  <View style={styles.processingOverlay}>
                    <ActivityIndicator size="large" color="#FFF" />
                    <Text style={styles.processingText}>{t('processing_document')}</Text>
                  </View>
                ) : null}
                
                <TouchableOpacity 
                  style={styles.retakeButton} 
                  onPress={() => setImage(null)}
                >
                  <Icon name="refresh" size={24} color="#FFF" />
                  <Text style={styles.retakeText}>{t('retake')}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.placeholderContainer}>
                <Icon name="file-document-outline" size={80} color="#CCC" />
                <Text style={styles.placeholderText}>{t('no_document_selected')}</Text>
              </View>
            )}

            {/* Área de texto reconhecido */}
            {recognizedText ? (
              <View style={styles.recognizedTextContainer}>
                <Text style={styles.recognizedTextTitle}>{t('recognized_text')}:</Text>
                <Text style={styles.recognizedTextContent}>{recognizedText}</Text>
              </View>
            ) : null}

            {/* Botões de ação */}
            <View style={styles.actionButtons}>
              {!image ? (
                <>
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.cameraButton]} 
                    onPress={() => setIsCameraOpen(true)}
                  >
                    <Icon name="camera" size={24} color="#FFF" />
                    <Text style={styles.actionButtonText}>{t('take_photo')}</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.galleryButton]} 
                    onPress={pickDocument}
                  >
                    <Icon name="file-image" size={24} color="#FFF" />
                    <Text style={styles.actionButtonText}>{t('select_document')}</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <TouchableOpacity 
                  style={[styles.actionButton, styles.uploadButton]} 
                  onPress={uploadDocument}
                  disabled={isLoading || isProcessing}
                >
                  {isLoading ? (
                    <ActivityIndicator size="small" color="#FFF" />
                  ) : (
                    <>
                      <Icon name="cloud-upload" size={24} color="#FFF" />
                      <Text style={styles.actionButtonText}>{t('upload_document')}</Text>
                    </>
                  )}
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
};

// Estilos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  closeHeaderButton: {
    padding: 5,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#E74C3C',
    textAlign: 'center',
    marginBottom: 20,
  },
  placeholderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F9F9F9',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    borderStyle: 'dashed',
    marginBottom: 16,
  },
  placeholderText: {
    fontSize: 16,
    color: '#999',
    marginTop: 16,
  },
  previewContainer: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#000',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
  },
  preview: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  processingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  processingText: {
    color: '#FFF',
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  retakeButton: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 30,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  retakeText: {
    color: '#FFF',
    marginLeft: 8,
    fontSize: 14,
  },
  recognizedTextContainer: {
    backgroundColor: '#FFF',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  recognizedTextTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  recognizedTextContent: {
    fontSize: 14,
    color: '#555',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    minWidth: 150,
  },
  cameraButton: {
    backgroundColor: '#3498DB',
  },
  galleryButton: {
    backgroundColor: '#9B59B6',
  },
  uploadButton: {
    backgroundColor: '#27AE60',
    minWidth: 240,
  },
  actionButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
    marginLeft: 8,
  },
  cameraContainer: {
    flex: 1,
    position: 'relative',
  },
  camera: {
    flex: 1,
  },
  cameraControls: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 30,
    padding: 8,
  },
  captureButton: {
    backgroundColor: '#E74C3C',
    borderRadius: 40,
    height: 80,
    width: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#3498DB',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  buttonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});

export default KingScannerUploadModal;