import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Map, 
  Share2, 
  Truck, 
  Navigation, 
  Eye,
  Camera,
  Share
} from 'lucide-react';

const IntegratedSearchComponent = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedResult, setSelectedResult] = useState(null);
  const [viewMode, setViewMode] = useState('map'); // 'map' ou 'satellite'
  const [isSharing, setIsSharing] = useState(false);

  const SearchBar = () => (
    <div className="w-full p-4 bg-white shadow-lg rounded-lg">
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar cliente, empresa ou endereço..."
          className="w-full px-4 py-2 pr-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <Search className="absolute right-3 top-2.5 text-gray-400" />
      </div>
    </div>
  );

  const ResultCard = ({ result }) => (
    <div className="bg-white rounded-lg shadow-md p-4 mb-2 cursor-pointer hover:bg-gray-50">
      <div className="flex justify-between">
        <div>
          <h3 className="font-bold text-lg">{result.name}</h3>
          <p className="text-gray-600 text-sm">{result.address}</p>
        </div>
        {result.truckAccess && (
          <div className="flex items-center bg-green-100 text-green-800 px-2 py-1 rounded">
            <Truck className="w-4 h-4 mr-1" />
            Acesso para Caminhões
          </div>
        )}
      </div>

      <div className="mt-4 flex space-x-4">
        <button 
          onClick={() => setViewMode(viewMode === 'map' ? 'satellite' : 'map')}
          className="flex items-center text-blue-600 hover:text-blue-800"
        >
          <Eye className="w-4 h-4 mr-1" />
          {viewMode === 'map' ? 'Ver Satélite' : 'Ver Mapa'}
        </button>
        
        <button 
          onClick={() => handleStartNavigation(result)}
          className="flex items-center text-green-600 hover:text-green-800"
        >
          <Navigation className="w-4 h-4 mr-1" />
          Iniciar Navegação
        </button>
      </div>

      {result.truckAccess && (
        <div className="mt-4 bg-blue-50 p-3 rounded">
          <h4 className="font-medium text-blue-800">Informações para Caminhões:</h4>
          <ul className="mt-2 space-y-1 text-sm">
            {result.truckAccess.maxHeight && (
              <li>Altura máxima: {result.truckAccess.maxHeight}m</li>
            )}
            {result.truckAccess.maxWeight && (
              <li>Peso máximo: {result.truckAccess.maxWeight}t</li>
            )}
            {result.truckAccess.instructions && (
              <li className="text-blue-700">{result.truckAccess.instructions}</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );

  const ShareTripModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 className="text-xl font-bold mb-4">Compartilhar Progresso da Viagem</h3>
        
        <div className="space-y-4">
          <button 
            onClick={() => handleShare('WHATSAPP')}
            className="w-full flex items-center justify-center space-x-2 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
          >
            <Share2 className="w-5 h-5" />
            <span>WhatsApp</span>
          </button>

          <button 
            onClick={() => handleShare('EMAIL')}
            className="w-full flex items-center justify-center space-x-2 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
          >
            <Share2 className="w-5 h-5" />
            <span>Email</span>
          </button>

          <button 
            onClick={() => handleShare('KING_ROAD')}
            className="w-full flex items-center justify-center space-x-2 bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600"
          >
            <Share2 className="w-5 h-5" />
            <span>King Road</span>
          </button>
        </div>

        <button 
          onClick={() => setIsSharing(false)}
          className="mt-4 w-full text-gray-600 hover:text-gray-800"
        >
          Cancelar
        </button>
      </div>
    </div>
  );

  const handleStartNavigation = (result) => {
    setSelectedResult(result);
    // Inicia a navegação usando as coordenadas do ponto de entrada para caminhões
    const coordinates = result.truckAccess?.entranceLocation || result.coordinates;
    startNavigation(coordinates);
  };

  const handleShare = async (method) => {
    if (!selectedResult) return;

    try {
      const shareResult = await shareTripProgress(
        selectedResult.tripId,
        method,
        // Informações adicionais específicas do método
        method === 'WHATSAPP' ? 'phone_number' :
        method === 'EMAIL' ? 'email' :
        'user_id'
      );

      if (shareResult.success) {
        // Mostra confirmação
        alert(`Compartilhamento via ${method} realizado com sucesso!`);
      }
    } catch (error) {
      console.error('Erro ao compartilhar:', error);
      alert('Erro ao compartilhar a viagem. Tente novamente.');
    }

    setIsSharing(false);
  };

  return (
    <div className="h-full flex flex-col">
      <SearchBar />
      
      <div className="flex-1 overflow-auto p-4">
        {searchResults.map((result, index) => (
          <ResultCard key={index} result={result} />
        ))}
      </div>

      {selectedResult && (
        <div className="fixed bottom-4 right-4">
          <button
            onClick={() => setIsSharing(true)}
            className="bg-blue-500 text-white p-3 rounded-full shadow-lg hover:bg-blue-600"
          >
            <Share className="w-6 h-6" />
          </button>
        </div>
      )}

      {isSharing && <ShareTripModal />}
    </div>
  );
};

export default IntegratedSearchComponent;