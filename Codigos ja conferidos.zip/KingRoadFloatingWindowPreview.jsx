import React, { useState, useEffect } from 'react';
import { Minimize2, Maximize2, X, Map, Truck, Car, Navigation } from 'lucide-react';

// Componente FloatingWindowController
const FloatingWindowController = ({ 
  children, 
  title = "KingRoad",
  icon = null,
  initialMinimized = false,
  onClose
}) => {
  const [minimized, setMinimized] = useState(initialMinimized);
  const [position, setPosition] = useState({ x: 20, y: window.innerHeight - 200 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  const toggleMinimize = () => {
    setMinimized(!minimized);
  };
  
  const handleMouseDown = (e) => {
    if (minimized) {
      const rect = e.currentTarget.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      setIsDragging(true);
    }
  };
  
  useEffect(() => {
    const handleMouseMove = (e) => {
      if (isDragging) {
        const newX = Math.max(0, Math.min(window.innerWidth - 150, e.clientX - dragOffset.x));
        const newY = Math.max(0, Math.min(window.innerHeight - 100, e.clientY - dragOffset.y));
        
        setPosition({ x: newX, y: newY });
      }
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
    };
    
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset]);

  if (minimized) {
    return (
      <div 
        className={`fixed rounded-lg overflow-hidden shadow-lg z-50 bg-gray-900 border border-gray-800 ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        style={{ 
          width: '200px', 
          height: '125px',
          left: `${position.x}px`,
          top: `${position.y}px`
        }}
      >
        <div 
          className="h-8 bg-gray-800 flex items-center justify-between px-2 text-gray-200"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center truncate">
            {icon && <span className="mr-1">{icon}</span>}
            <span className="text-xs font-medium truncate">{title}</span>
          </div>
          <div className="flex items-center">
            <button 
              onClick={toggleMinimize}
              className="p-1 text-gray-400 hover:text-white"
            >
              <Maximize2 size={14} />
            </button>
            {onClose && (
              <button 
                onClick={onClose}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>
        
        <div className="h-[calc(100%-32px)] overflow-hidden bg-gray-900">
          <div className="transform scale-[0.3] origin-top-left h-[350%] w-[350%] pointer-events-none">
            {children}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="relative w-full h-full">
      <button 
        onClick={toggleMinimize}
        className="absolute top-4 right-4 z-50 bg-gray-800 hover:bg-gray-700 text-amber-400 p-2 rounded-full shadow-lg transition-colors"
        title="Minimizar"
      >
        <Minimize2 size={20} />
      </button>
      
      {children}
    </div>
  );
};

// Demo interativo
const KingRoadFloatingWindowPreview = () => {
  const [view, setView] = useState('map');
  const [vehicleMode, setVehicleMode] = useState('truck');
  const [mapMinimized, setMapMinimized] = useState(false);
  
  const toggleVehicleMode = () => {
    setVehicleMode(prev => prev === 'truck' ? 'car' : 'truck');
  };
  
  const showMap = () => {
    setView('map');
  };
  
  const showDetails = () => {
    setView('details');
    // Ao mostrar detalhes, minimizamos o mapa automaticamente
    setMapMinimized(true);
  };
  
  // Simulação dos componentes
  const MapComponent = () => (
    <div className="bg-gray-800 rounded-lg overflow-hidden w-full h-[70vh] relative">
      <div className="absolute inset-0 flex items-center justify-center text-gray-500">
        Mapa (Simulação)
      </div>
      
      {/* Grid simulando estradas */}
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: 'linear-gradient(to right, #333 1px, transparent 1px), linear-gradient(to bottom, #333 1px, transparent 1px)',
        backgroundSize: '50px 50px'
      }}></div>
      
      {/* Linhas mais escuras simulando estradas principais */}
      <div className="absolute left-[40%] top-0 h-full w-4 bg-gray-600 opacity-30"></div>
      <div className="absolute top-[60%] left-0 w-full h-4 bg-gray-600 opacity-30"></div>
      
      {/* Marcadores */}
      <div className="absolute left-[30%] top-[40%]">
        <button 
          className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center text-black shadow-lg hover:bg-amber-400 transition-colors"
          onClick={showDetails}
        >
          {vehicleMode === 'truck' ? <Truck size={20} /> : <Car size={20} />}
        </button>
      </div>
      
      <div className="absolute left-[60%] top-[30%]">
        <button 
          className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-amber-400 shadow-lg hover:bg-gray-600 transition-colors"
        >
          {vehicleMode === 'truck' ? <Truck size={16} /> : <Car size={16} />}
        </button>
      </div>
      
      <div className="absolute left-[50%] top-[70%]">
        <button 
          className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-amber-400 shadow-lg hover:bg-gray-600 transition-colors"
        >
          {vehicleMode === 'truck' ? <Truck size={16} /> : <Car size={16} />}
        </button>
      </div>
      
      {/* Controles do mapa */}
      <div className="absolute bottom-4 left-4 bg-gray-900 bg-opacity-80 p-3 rounded-lg shadow-lg">
        <div className="text-white text-sm">
          <div className="font-bold mb-1">Locais próximos</div>
          <div className="text-xs text-gray-300">
            3 locais de lavagem encontrados
          </div>
        </div>
      </div>
    </div>
  );
  
  const DetailsComponent = () => (
    <div className="bg-gray-900 rounded-lg p-4 w-full">
      <div className="flex justify-between items-center mb-4">
        <button onClick={showMap} className="flex items-center text-amber-400 hover:text-amber-300">
          <span>← Voltar</span>
        </button>
        
        <div className="flex items-center">
          {vehicleMode === 'truck' ? <Truck className="mr-2" size={20} /> : <Car className="mr-2" size={20} />}
          <h2 className="text-lg font-bold text-amber-400">{vehicleMode === 'truck' ? "Truck Washer" : "Car Wash"}</h2>
        </div>
      </div>
      
      <div className="mb-4">
        <h1 className="text-xl font-bold mb-2">Auto Lava Premium</h1>
        <div className="flex items-center mb-2">
          <div className="flex items-center bg-amber-500 text-black font-bold px-2 py-1 rounded mr-3">
            <span>★ 4.8</span>
          </div>
          <span className="text-gray-400">148 avaliações</span>
        </div>
        
        <div className="text-gray-400 mb-2">
          <span>BR-116, km 432, Curitiba - PR</span>
        </div>
      </div>
      
      <div className="bg-gray-800 h-40 rounded-lg mb-4 flex items-center justify-center text-gray-500">
        Imagem do local
      </div>
      
      <div className="mb-3 border-b border-gray-800">
        <div className="flex">
          <button className="py-2 px-4 font-medium text-amber-400 border-b-2 border-amber-400">
            Informações
          </button>
          <button className="py-2 px-4 font-medium text-gray-400">
            Avaliações
          </button>
        </div>
      </div>
      
      <div className="mb-4">
        <h3 className="text-lg font-bold text-amber-400 mb-3">Horários de Funcionamento</h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex justify-between p-2 bg-gray-800 rounded">
            <span className="font-medium">Segunda-feira</span>
            <span>07:00 - 22:00</span>
          </div>
          <div className="flex justify-between p-2 bg-gray-800 rounded">
            <span className="font-medium">Terça-feira</span>
            <span>07:00 - 22:00</span>
          </div>
        </div>
      </div>
      
      <div className="flex justify-between mt-6">
        <button className="text-amber-400 border border-amber-400 hover:bg-amber-400 hover:text-black font-medium py-2 px-4 rounded transition-colors">
          <span>Adicionar aos Favoritos</span>
        </button>
        
        <button className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-6 rounded transition-colors">
          Traçar Rota
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-950 p-4">
      {/* Barra de navegação */}
      <div className="mb-4 bg-gray-900 p-4 rounded-lg shadow-lg">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold text-amber-400">KingRoad - Preview da Janela Flutuante</h1>
          
          <div className="flex space-x-3">
            <button 
              className="flex items-center bg-gray-800 hover:bg-gray-700 text-white px-3 py-2 rounded transition-colors"
              onClick={toggleVehicleMode}
            >
              {vehicleMode === 'truck' ? <Truck size={18} className="mr-2" /> : <Car size={18} className="mr-2" />}
              <span>{vehicleMode === 'truck' ? 'Caminhão' : 'Carro'}</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Instruções */}
      <div className="mb-6 bg-gray-900 p-4 rounded-lg text-white">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Como testar:</h2>
        <ol className="list-decimal pl-5 space-y-2 text-gray-300">
          <li>Clique no botão <strong>Minimizar</strong> (canto superior direito) para ver como o mapa é minimizado para uma janela flutuante</li>
          <li>Arraste a janela flutuante pela barra superior para movê-la pela tela</li>
          <li>Clique em um dos marcadores para abrir os detalhes (o mapa será minimizado automaticamente)</li>
          <li>Observe como você pode manter o mapa minimizado enquanto vê os detalhes do local</li>
        </ol>
      </div>
      
      {/* Área principal */}
      <div className="relative">
        {view === 'map' ? (
          <FloatingWindowController
            title={`Mapa - ${vehicleMode === 'truck' ? 'Truck Washer' : 'Car Wash'}`}
            icon={<Map size={14} className="text-amber-400" />}
            initialMinimized={mapMinimized}
          >
            <MapComponent />
          </FloatingWindowController>
        ) : (
          <DetailsComponent />
        )}
        
        {/* Mantenha o mapa minimizado quando estiver vendo detalhes */}
        {view === 'details' && (
          <FloatingWindowController
            title={`Mapa - ${vehicleMode === 'truck' ? 'Truck Washer' : 'Car Wash'}`}
            icon={<Map size={14} className="text-amber-400" />}
            initialMinimized={true}
            onClose={() => setMapMinimized(false)}
          >
            <MapComponent />
          </FloatingWindowController>
        )}
      </div>
    </div>
  );
};

export default KingRoadFloatingWindowPreview;