package com.kingroad.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.kingroad.MainActivity
import com.kingroad.R
import com.kingroad.utils.PreferenceManager

/**
 * Serviço para gerenciar notificações push do aplicativo
 */
class KingRoadNotificationService : FirebaseMessagingService() {

    // Canais de notificação
    companion object {
        const val CHANNEL_SECURITY = "security_alerts"
        const val CHANNEL_TRAFFIC = "traffic_updates"
        const val CHANNEL_ROUTE = "route_updates"
        const val CHANNEL_GENERAL = "general"
    }
    
    private lateinit var preferenceManager: PreferenceManager

    override fun onCreate() {
        super.onCreate()
        preferenceManager = PreferenceManager(this)
        createNotificationChannels()
    }

    /**
     * Cria os canais de notificação (requisito para Android 8.0+)
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Canal de alertas de segurança (alta prioridade)
            val securityChannel = NotificationChannel(
                CHANNEL_SECURITY,
                "Alertas de Segurança",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas críticos sobre segurança na estrada"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            
            // Canal de atualizações de tráfego (prioridade média)
            val trafficChannel = NotificationChannel(
                CHANNEL_TRAFFIC,
                "Atualizações de Tráfego",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Informações sobre congestionamentos e incidentes"
            }
            
            // Canal de atualizações de rota (prioridade média)
            val routeChannel = NotificationChannel(
                CHANNEL_ROUTE,
                "Atualizações de Rota",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Atualizações sobre sua rota atual"
            }
            
            // Canal geral (prioridade baixa)
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "Notificações Gerais",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificações gerais do aplicativo"
            }
            
            // Registrar todos os canais
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.let {
                it.createNotificationChannel(securityChannel)
                it.createNotificationChannel(trafficChannel)
                it.createNotificationChannel(routeChannel)
                it.createNotificationChannel(generalChannel)
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        // Verificar se a mensagem contém dados
        val data = remoteMessage.data
        if (data.isNullOrEmpty()) {
            return
        }
        
        // Verificar se as notificações estão habilitadas pelo usuário
        if (!preferenceManager.areNotificationsEnabled()) {
            return
        }
        
        // Obter o tipo de notificação
        var notificationType = data["type"]
        if (notificationType == null) {
            notificationType = CHANNEL_GENERAL
        }
        
        // Verificar configurações específicas por tipo
        val shouldShow = when (notificationType) {
            CHANNEL_SECURITY -> preferenceManager.areSecurityAlertsEnabled()
            CHANNEL_TRAFFIC -> preferenceManager.areTrafficAlertsEnabled()
            CHANNEL_ROUTE -> preferenceManager.areRouteUpdatesEnabled()
            else -> true
        }
        
        if (!shouldShow) {
            return
        }

        // Processar a notificação de acordo com tipo
        processNotification(remoteMessage, notificationType)
    }

    /**
     * Processa a notificação recebida
     * @param remoteMessage Mensagem recebida
     * @param notificationType Tipo de notificação
     */
    private fun processNotification(remoteMessage: RemoteMessage, notificationType: String) {
        val title = remoteMessage.notification?.title ?: "KingRoad"
        val message = remoteMessage.notification?.body ?: remoteMessage.data["message"]
        
        if (message == null) {
            return
        }
        
        // Criar intent para ação ao clicar na notificação
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("notification_type", notificationType)
            
            // Adicionar qualquer dado extra
            for ((key, value) in remoteMessage.data) {
                putExtra(key, value)
            }
            
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        
        val pendingIntent = PendingIntent.getActivity(
            this, 
            0, 
            intent, 
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Construir a notificação
        val builder = NotificationCompat.Builder(this, notificationType)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(getPriorityForType(notificationType))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
        
        // Para mensagens longas, usar estilo de expansão
        if (message.length > 100) {
            builder.setStyle(NotificationCompat.BigTextStyle().bigText(message))
        }
        
        // Obter ID para a notificação
        val notificationId = System.currentTimeMillis().toInt()
        
        // Mostrar a notificação
        val notificationManager = NotificationManagerCompat.from(this)
        
        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Permissão de notificação negada
            e.printStackTrace()
        }
    }
    
    /**
     * Determina a prioridade de acordo com o tipo de notificação
     */
    private fun getPriorityForType(type: String): Int = when (type) {
        CHANNEL_SECURITY -> NotificationCompat.PRIORITY_HIGH
        CHANNEL_TRAFFIC, CHANNEL_ROUTE -> NotificationCompat.PRIORITY_DEFAULT
        else -> NotificationCompat.PRIORITY_LOW
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        
        // Salvar novo token para registro posterior
        preferenceManager.saveNotificationToken(token)
        
        // TODO: Enviar token para o servidor
    }
}