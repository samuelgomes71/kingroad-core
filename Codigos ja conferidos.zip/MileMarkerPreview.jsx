import React, { useState } from 'react';
import { MapPin, AlertTriangle, Info } from 'lucide-react';

// Componente Marker com props explicitamente tipadas
const MileMarker = ({ 
  kilometer = 127, 
  Icon = MapPin, 
  iconColor = 'text-blue-500', 
  description = 'Estado Padrão' 
}) => (
  <div className="w-64 bg-[#1E1E1E] bg-opacity-90 flex flex-col items-center py-4 rounded-lg shadow-lg">
    <Icon className={`w-8 h-8 ${iconColor} mb-2`} />
    <div className="text-white text-center">
      <div className="font-bold text-sm uppercase">{description}</div>
      <div className="text-3xl font-bold mt-1">{kilometer}</div>
      <div className="text-xs mt-1 text-gray-400">Km na Rodovia</div>
    </div>
  </div>
);

// Componente Preview
const MileMarkerPreview = () => {
  const [activeVariant, setActiveVariant] = useState('default');
  
  // Variantes de aparência e estado
  const markerVariants = [
    { 
      id: 'default', 
      kilometer: 127, 
      Icon: MapPin, 
      iconColor: 'text-blue-500', 
      description: 'Estado Padrão' 
    },
    { 
      id: 'warning', 
      kilometer: 132, 
      Icon: AlertTriangle, 
      iconColor: 'text-yellow-500', 
      description: 'Ponto de Atenção' 
    },
    { 
      id: 'info', 
      kilometer: 145, 
      Icon: Info, 
      iconColor: 'text-green-500', 
      description: 'Informação Adicional' 
    }
  ];

  // Encontrar a variante ativa
  const activeVariantData = markerVariants.find(v => v.id === activeVariant) || markerVariants[0];

  return (
    <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center">
      <h1 className="text-white text-2xl mb-6">Modo Preview: Mile Marker</h1>
      
      {/* Exibição da variante atual */}
      <div className="mb-6">
        <MileMarker 
          kilometer={activeVariantData.kilometer}
          Icon={activeVariantData.Icon}
          iconColor={activeVariantData.iconColor}
          description={activeVariantData.description}
        />
      </div>
      
      {/* Seletor de variantes */}
      <div className="flex space-x-4">
        {markerVariants.map(variant => (
          <button
            key={variant.id}
            onClick={() => setActiveVariant(variant.id)}
            className={`
              px-4 py-2 rounded-lg 
              ${activeVariant === variant.id 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}
            `}
          >
            {variant.description}
          </button>
        ))}
      </div>
      
      {/* Detalhes interativos */}
      <div className="mt-6 bg-gray-800 p-4 rounded-lg text-white max-w-md">
        <h2 className="font-bold mb-2">Detalhes da Variante</h2>
        <pre className="text-sm">
          {JSON.stringify(activeVariantData, null, 2)}
        </pre>
      </div>
    </div>
  );
};

export default MileMarkerPreview;