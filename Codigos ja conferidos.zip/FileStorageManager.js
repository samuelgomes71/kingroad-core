// FileStorageManager.js
// Gerenciador de armazenamento de arquivos para o KingChat

import { Platform } from 'react-native';
import RNFS from 'react-native-fs';
import axios from 'axios';
import moment from 'moment';
import { API_URL } from '../config/constants';
import { getToken } from '../utils/authToken';
import { schedulePushNotification } from '../utils/notifications';

class FileStorageManager {
  constructor() {
    // Tamanho máximo para arquivos no servidor (4MB)
    this.MAX_SERVER_FILE_SIZE = 4 * 1024 * 1024; // 4MB em bytes
    
    // Tempo de vida do arquivo no servidor (48 horas)
    this.FILE_LIFE_TIME = 48 * 60 * 60 * 1000; // 48 horas em milissegundos
    
    // Tempo antes da exclusão para notificar o usuário (6 horas)
    this.NOTIFICATION_BEFORE_DELETION = 6 * 60 * 60 * 1000; // 6 horas em milissegundos
    
    // Diretório base para arquivos baixados
    this.BASE_DIRECTORY = Platform.OS === 'ios' 
      ? RNFS.DocumentDirectoryPath 
      : RNFS.DownloadDirectoryPath;
    
    // Diretório para arquivos do KingChat
    this.KING_CHAT_DIRECTORY = `${this.BASE_DIRECTORY}/KingChat`;
    
    // Diretório para arquivos temporários
    this.TEMP_DIRECTORY = `${this.KING_CHAT_DIRECTORY}/temp`;
    
    // Diretório para arquivos na lixeira
    this.TRASH_DIRECTORY = `${this.KING_CHAT_DIRECTORY}/trash`;
    
    // Inicializar diretórios
    this.initializeDirectories();
  }
  
  /**
   * Inicializa os diretórios necessários para o funcionamento do gerenciador
   */
  async initializeDirectories() {
    try {
      // Verificar se o diretório base do KingChat existe
      const baseExists = await RNFS.exists(this.KING_CHAT_DIRECTORY);
      if (!baseExists) {
        await RNFS.mkdir(this.KING_CHAT_DIRECTORY);
      }
      
      // Verificar se o diretório temporário existe
      const tempExists = await RNFS.exists(this.TEMP_DIRECTORY);
      if (!tempExists) {
        await RNFS.mkdir(this.TEMP_DIRECTORY);
      }
      
      // Verificar se o diretório da lixeira existe
      const trashExists = await RNFS.exists(this.TRASH_DIRECTORY);
      if (!trashExists) {
        await RNFS.mkdir(this.TRASH_DIRECTORY);
      }
      
      console.log('Diretórios do gerenciador de arquivos inicializados com sucesso');
    } catch (error) {
      console.error('Erro ao inicializar diretórios:', error);
    }
  }
  
  /**
   * Faz o upload de um arquivo para o servidor
   * @param {String} filePath Caminho do arquivo no dispositivo
   * @param {String} fileType Tipo MIME do arquivo
   * @param {Object} metadata Metadados adicionais do arquivo
   * @returns {Promise<Object>} Objeto com informações do arquivo no servidor
   */
  async uploadFile(filePath, fileType, metadata = {}) {
    try {
      // Verificar o tamanho do arquivo
      const fileStats = await RNFS.stat(filePath);
      const fileSize = fileStats.size;
      
      // Se arquivo maior que 4MB, apenas armazena localmente
      if (fileSize > this.MAX_SERVER_FILE_SIZE) {
        console.log('Arquivo maior que 4MB, será mantido apenas localmente');
        await this.scheduleFileDeletion(filePath, 48);
        return {
          uploaded: false,
          localPath: filePath,
          message: 'Arquivo grande demais para upload, mantido apenas localmente',
          willBeDeletedAt: moment().add(48, 'hours').toISOString()
        };
      }
      
      // Preparar o formulário para upload
      const formData = new FormData();
      formData.append('file', {
        uri: Platform.OS === 'android' ? `file://${filePath}` : filePath,
        name: filePath.split('/').pop(),
        type: fileType
      });
      
      // Adicionar metadados
      Object.keys(metadata).forEach(key => {
        formData.append(key, metadata[key]);
      });
      
      // Obter token de autenticação
      const token = await getToken();
      
      // Enviar arquivo para o servidor
      const response = await axios.post(`${API_URL}/files/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        }
      });
      
      // Programar a exclusão automática do arquivo do servidor
      this.scheduleServerFileDeletion(response.data.fileId);
      
      // Notificar o usuário antes da exclusão
      this.scheduleDeleteNotification(response.data.fileId, response.data.fileName);
      
      return {
        ...response.data,
        uploaded: true,
        localPath: filePath,
        willBeDeletedAt: moment().add(48, 'hours').toISOString()
      };
    } catch (error) {
      console.error('Erro ao fazer upload do arquivo:', error);
      throw new Error('Falha ao fazer upload do arquivo');
    }
  }
  
  /**
   * Faz o download de um arquivo do servidor para o dispositivo
   * @param {String} fileUrl URL do arquivo no servidor
   * @param {String} fileName Nome do arquivo
   * @param {String} mimeType Tipo MIME do arquivo
   * @returns {Promise<String>} Caminho do arquivo no dispositivo
   */
  async downloadFile(fileUrl, fileName, mimeType) {
    try {
      // Determinar o diretório de destino com base no tipo de arquivo
      let destinationDir = this.KING_CHAT_DIRECTORY;
      
      if (mimeType.startsWith('image/')) {
        destinationDir = `${this.KING_CHAT_DIRECTORY}/images`;
      } else if (mimeType.startsWith('video/')) {
        destinationDir = `${this.KING_CHAT_DIRECTORY}/videos`;
      } else if (mimeType.startsWith('audio/')) {
        destinationDir = `${this.KING_CHAT_DIRECTORY}/audios`;
      } else {
        destinationDir = `${this.KING_CHAT_DIRECTORY}/documents`;
      }
      
      // Criar o diretório se não existir
      const dirExists = await RNFS.exists(destinationDir);
      if (!dirExists) {
        await RNFS.mkdir(destinationDir);
      }
      
      // Caminho completo do arquivo
      const timestamp = moment().format('YYYYMMDD_HHmmss');
      const filePath = `${destinationDir}/${timestamp}_${fileName}`;
      
      // Fazer o download do arquivo
      const result = await RNFS.downloadFile({
        fromUrl: fileUrl,
        toFile: filePath,
        background: true,
        discretionary: true,
        cacheable: true,
        progressDivider: 10,
      }).promise;
      
      if (result.statusCode === 200) {
        console.log('Arquivo baixado com sucesso:', filePath);
        return filePath;
      } else {
        throw new Error(`Download falhou com status ${result.statusCode}`);
      }
    } catch (error) {
      console.error('Erro ao baixar arquivo:', error);
      throw new Error('Falha ao baixar arquivo');
    }
  }
  
  /**
   * Move um arquivo para a lixeira
   * @param {String} filePath Caminho do arquivo
   * @returns {Promise<String>} Caminho do arquivo na lixeira
   */
  async moveToTrash(filePath) {
    try {
      const fileName = filePath.split('/').pop();
      const trashFilePath = `${this.TRASH_DIRECTORY}/${fileName}`;
      
      // Mover o arquivo para a lixeira
      await RNFS.moveFile(filePath, trashFilePath);
      
      // Programar a exclusão permanente após 7 dias
      this.schedulePermanentDeletion(trashFilePath);
      
      return trashFilePath;
    } catch (error) {
      console.error('Erro ao mover arquivo para a lixeira:', error);
      throw new Error('Falha ao mover arquivo para a lixeira');
    }
  }
  
  /**
   * Restaura um arquivo da lixeira
   * @param {String} trashFilePath Caminho do arquivo na lixeira
   * @returns {Promise<String>} Novo caminho do arquivo
   */
  async restoreFromTrash(trashFilePath) {
    try {
      const fileName = trashFilePath.split('/').pop();
      const restoredFilePath = `${this.KING_CHAT_DIRECTORY}/${fileName}`;
      
      // Mover o arquivo de volta
      await RNFS.moveFile(trashFilePath, restoredFilePath);
      
      return restoredFilePath;
    } catch (error) {
      console.error('Erro ao restaurar arquivo da lixeira:', error);
      throw new Error('Falha ao restaurar arquivo da lixeira');
    }
  }
  
  /**
   * Exclui permanentemente um arquivo
   * @param {String} filePath Caminho do arquivo
   * @returns {Promise<Boolean>} Verdadeiro se excluído com sucesso
   */
  async deletePermanently(filePath) {
    try {
      await RNFS.unlink(filePath);
      console.log('Arquivo excluído permanentemente:', filePath);
      return true;
    } catch (error) {
      console.error('Erro ao excluir arquivo permanentemente:', error);
      return false;
    }
  }
  
  /**
   * Programa a exclusão de um arquivo após um tempo determinado
   * @param {String} filePath Caminho do arquivo
   * @param {Number} hours Horas antes da exclusão
   */
  async scheduleFileDeletion(filePath, hours = 48) {
    try {
      // Armazenar informações sobre o arquivo e quando deve ser excluído
      const deletionTime = moment().add(hours, 'hours').valueOf();
      
      // Aqui você poderia usar AsyncStorage ou outro mecanismo de armazenamento
      // para armazenar o filePath e deletionTime para verificar mais tarde
      console.log(`Arquivo ${filePath} programado para exclusão em ${hours} horas`);
      
      // Esse método pode ser chamado por um serviço em background periódico
      // que verifica quais arquivos devem ser excluídos
    } catch (error) {
      console.error('Erro ao programar exclusão de arquivo:', error);
    }
  }
  
  /**
   * Programa a exclusão de um arquivo do servidor
   * @param {String} fileId ID do arquivo no servidor
   */
  async scheduleServerFileDeletion(fileId) {
    try {
      // Obter token de autenticação
      const token = await getToken();
      
      // Enviar solicitação para programar exclusão no servidor
      await axios.post(`${API_URL}/files/${fileId}/schedule-deletion`, {
        deletionTime: this.FILE_LIFE_TIME,
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      console.log(`Exclusão do arquivo ${fileId} programada no servidor`);
    } catch (error) {
      console.error('Erro ao programar exclusão no servidor:', error);
    }
  }
  
  /**
   * Programa uma notificação para o usuário antes da exclusão
   * @param {String} fileId ID do arquivo
   * @param {String} fileName Nome do arquivo
   */
  async scheduleDeleteNotification(fileId, fileName) {
    try {
      // Calcular o tempo para a notificação (6 horas antes da exclusão)
      const notificationTime = this.FILE_LIFE_TIME - this.NOTIFICATION_BEFORE_DELETION;
      
      // Programar a notificação
      await schedulePushNotification({
        title: 'Aviso de exclusão de arquivo',
        body: `O arquivo "${fileName}" será excluído do servidor em 6 horas.`,
        data: { fileId },
      }, notificationTime);
      
      console.log(`Notificação programada para o arquivo ${fileName}`);
    } catch (error) {
      console.error('Erro ao programar notificação:', error);
    }
  }
  
  /**
   * Programa a exclusão permanente de um arquivo da lixeira após 7 dias
   * @param {String} trashFilePath Caminho do arquivo na lixeira
   */
  async schedulePermanentDeletion(trashFilePath) {
    try {
      // Calcular a data de exclusão (7 dias a partir de agora)
      const deletionTime = moment().add(7, 'days').valueOf();
      
      // Aqui você poderia usar AsyncStorage ou outro mecanismo de armazenamento
      // para armazenar o trashFilePath e deletionTime para verificar mais tarde
      console.log(`Arquivo ${trashFilePath} programado para exclusão permanente em 7 dias`);
      
      // Esse método pode ser chamado por um serviço em background periódico
      // que verifica quais arquivos devem ser excluídos permanentemente
    } catch (error) {
      console.error('Erro ao programar exclusão permanente:', error);
    }
  }
  
  /**
   * Obtém lista de arquivos na lixeira
   * @returns {Promise<Array>} Lista de arquivos na lixeira
   */
  async getTrashFiles() {
    try {
      const files = await RNFS.readDir(this.TRASH_DIRECTORY);
      
      // Mapear arquivos com informações adicionais
      const trashFiles = await Promise.all(files.map(async (file) => {
        const stats = await RNFS.stat(file.path);
        return {
          name: file.name,
          path: file.path,
          size: stats.size,
          mtime: stats.mtime
        };
      }));
      
      return trashFiles;
    } catch (error) {
      console.error('Erro ao obter arquivos da lixeira:', error);
      return [];
    }
  }
  
  /**
   * Limpa a lixeira, excluindo todos os arquivos permanentemente
   * @returns {Promise<Boolean>} Verdadeiro se a operação foi bem-sucedida
   */
  async emptyTrash() {
    try {
      const files = await RNFS.readDir(this.TRASH_DIRECTORY);
      
      // Excluir cada arquivo
      await Promise.all(files.map(file => 
        RNFS.unlink(file.path)
      ));
      
      console.log('Lixeira esvaziada com sucesso');
      return true;
    } catch (error) {
      console.error('Erro ao esvaziar lixeira:', error);
      return false;
    }
  }
}

// Exportar uma instância única do gerenciador
export default new FileStorageManager();