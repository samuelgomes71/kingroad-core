import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const RAMCheckInterface = () => {
  return (
    <div className="h-screen bg-gray-900 text-gray-200">
      {/* Cabeçalho */}
      <div className="bg-gray-800 p-4">
        <h1 className="text-xl font-bold">Verificação de Memória RAM</h1>
        <p className="text-gray-400 text-sm mt-1">
          Analisando capacidades do dispositivo
        </p>
      </div>

      {/* Área de resultado */}
      <div className="p-4">
        {/* Status da RAM */}
        <div className="bg-gray-800 p-4 rounded-lg mb-4">
          <div className="flex items-center mb-4">
            <div className="w-6 h-6 bg-blue-500 rounded-full mr-2"></div>
            <span className="font-medium">Memória RAM Detectada: 2.5 GB</span>
          </div>

          <Alert variant="warning" className="mb-4">
            <AlertTitle>Modo de Operação: Otimizado</AlertTitle>
          </Alert>
        </div>

        {/* Funcionalidades disponíveis */}
        <div className="bg-gray-800 p-4 rounded-lg mb-4">
          <h3 className="font-medium mb-3">Funcionalidades Disponíveis</h3>
          <div className="space-y-2">
            <div className="flex items-center text-green-400">
              <div className="w-4 h-4 mr-2">✓</div>
              <span>Navegação básica</span>
            </div>
            <div className="flex items-center text-green-400">
              <div className="w-4 h-4 mr-2">✓</div>
              <span>Mapas offline limitados</span>
            </div>
            <div className="flex items-center text-red-400">
              <div className="w-4 h-4 mr-2">×</div>
              <span>Recursos sociais avançados</span>
            </div>
            <div className="flex items-center text-red-400">
              <div className="w-4 h-4 mr-2">×</div>
              <span>Gráficos em alta qualidade</span>
            </div>
          </div>
        </div>

        {/* Recomendações */}
        <div className="bg-gray-800 p-4 rounded-lg mb-4">
          <h3 className="font-medium mb-3">Recomendações</h3>
          <div className="space-y-2 text-gray-400">
            <div className="flex items-start">
              <div className="w-4 h-4 mr-2 mt-1">ℹ</div>
              <span>Mantenha apenas mapas essenciais offline</span>
            </div>
            <div className="flex items-start">
              <div className="w-4 h-4 mr-2 mt-1">ℹ</div>
              <span>Feche outros aplicativos durante a navegação</span>
            </div>
            <div className="flex items-start">
              <div className="w-4 h-4 mr-2 mt-1">ℹ</div>
              <span>Considere atualizar seu dispositivo para 4GB+ RAM para acesso a todas as funcionalidades</span>
            </div>
          </div>
        </div>

        {/* Aviso de performance */}
        <Alert variant="warning" className="mb-4">
          <AlertTitle>Aviso de Performance</AlertTitle>
          <AlertDescription>
            Seu dispositivo atende aos requisitos mínimos, mas algumas funcionalidades avançadas estarão desativadas para garantir melhor performance.
          </AlertDescription>
        </Alert>
      </div>

      {/* Botões de ação */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gray-800">
        <div className="flex space-x-4">
          <button className="flex-1 bg-gray-700 text-gray-200 p-4 rounded-lg">
            Mais Detalhes
          </button>
          <button className="flex-1 bg-blue-600 text-white p-4 rounded-lg">
            Continuar Instalação
          </button>
        </div>
      </div>
    </div>
  );
};

export default RAMCheckInterface;