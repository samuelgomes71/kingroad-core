import React, { useState } from 'react';
import { 
  Waves, 
  Timer,
  Phone, 
  Wifi,
  Truck,
  CreditCard,
  CircleParking,
  Coffee,
  Clock,
  X,
  Car,
  AlertCircle
} from 'lucide-react';

const LaundryPOIPreview = () => {
  const [selectedLaundry, setSelectedLaundry] = useState(mockLaundries[0]);
  const [showDetails, setShowDetails] = useState(true);
  const [filters, setFilters] = useState({
    open24h: false,
    hasParking: false,
    acceptsCards: false
  });

  const formatCurrency = (amount, currency) => {
    const formatter = new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency: currency
    });
    return formatter.format(amount);
  };

  const LaundryMarker = ({ laundry, onClick }) => (
    <div 
      className="relative cursor-pointer"
      onClick={() => onClick(laundry)}
    >
      <div className="absolute flex items-center justify-center w-8 h-8 bg-blue-500 rounded-full hover:bg-blue-600">
        <Waves className="w-5 h-5 text-white" />
      </div>
      {laundry.operatingHours.is24Hours && (
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
          <Clock className="w-3 h-3 text-white" />
        </div>
      )}
    </div>
  );

  const LaundryDetails = ({ laundry }) => (
    <div className="bg-white rounded-lg shadow-lg p-4 max-w-md mx-auto">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-bold">{laundry.name}</h3>
          <p className="text-gray-600">{laundry.address}</p>
        </div>
        <button 
          onClick={() => setShowDetails(false)}
          className="p-1 hover:bg-gray-100 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Facilities Icons */}
      <div className="mt-4 flex space-x-4">
        {laundry.facilities.hasParking && (
          <div className="flex flex-col items-center">
            <Car className="w-5 h-5 text-blue-600" />
            <span className="text-xs mt-1">{laundry.facilities.parkingSpots} spots</span>
          </div>
        )}
        {laundry.facilities.hasWifi && (
          <div className="flex flex-col items-center">
            <Wifi className="w-5 h-5 text-blue-600" />
            <span className="text-xs mt-1">WiFi</span>
          </div>
        )}
        {laundry.facilities.acceptsCards && (
          <div className="flex flex-col items-center">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span className="text-xs mt-1">Cards</span>
          </div>
        )}
        {laundry.facilities.hasWaitingArea && (
          <div className="flex flex-col items-center">
            <Coffee className="w-5 h-5 text-blue-600" />
            <span className="text-xs mt-1">Waiting Area</span>
          </div>
        )}
      </div>

      {/* Operating Hours */}
      <div className="mt-4 bg-gray-50 rounded-lg p-3">
        <div className="flex items-center mb-2">
          <Clock className="w-4 h-4 mr-2 text-gray-600" />
          <span className="font-medium">Hours:</span>
        </div>
        {laundry.operatingHours.is24Hours ? (
          <p className="text-green-600 font-medium">Open 24/7</p>
        ) : (
          <div className="space-y-1 text-sm">
            <p>Mon-Fri: {laundry.operatingHours.weekday.opening} - {laundry.operatingHours.weekday.closing}</p>
            {laundry.operatingHours.saturday && (
              <p>Sat: {laundry.operatingHours.saturday.opening} - {laundry.operatingHours.saturday.closing}</p>
            )}
            {laundry.operatingHours.sunday && (
              <p>Sun: {laundry.operatingHours.sunday.opening} - {laundry.operatingHours.sunday.closing}</p>
            )}
          </div>
        )}
      </div>

      {/* Services and Prices */}
      <div className="mt-4">
        <h4 className="font-medium mb-2">Available Services:</h4>
        <div className="space-y-3">
          {laundry.services.map((service, index) => (
            <div key={index} className="bg-gray-50 p-3 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{service.type}</p>
                  <p className="text-sm text-gray-600">
                    Capacity: {service.capacity} • Duration: {service.duration}min
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{formatCurrency(service.price.amount, service.price.currency)}</p>
                  {service.price.includesDetergent && (
                    <p className="text-xs text-green-600">Includes detergent</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Info */}
      <div className="mt-4">
        {laundry.contact.phone && (
          <div className="flex items-center mt-2">
            <Phone className="w-4 h-4 mr-2 text-gray-600" />
            <a href={`tel:${laundry.contact.phone}`} className="text-blue-600 hover:underline">
              {laundry.contact.phone}
            </a>
          </div>
        )}
        {laundry.contact.email && (
          <div className="flex items-center mt-2">
            <AlertCircle className="w-4 h-4 mr-2 text-gray-600" />
            <a href={`mailto:${laundry.contact.email}`} className="text-blue-600 hover:underline">
              {laundry.contact.email}
            </a>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="relative p-4 bg-gray-100 min-h-screen">
      {/* Filtros */}
      <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg p-4 z-10 w-64">
        <h3 className="font-bold mb-3">Filter Laundries</h3>
        <div className="space-y-2">
          <label className="flex items-center space-x-2">
            <input 
              type="checkbox" 
              checked={filters.open24h}
              onChange={(e) => setFilters({...filters, open24h: e.target.checked})}
              className="form-checkbox"
            />
            <span>Open 24/7</span>
          </label>
          <label className="flex items-center space-x-2">
            <input 
              type="checkbox"
              checked={filters.hasParking}
              onChange={(e) => setFilters({...filters, hasParking: e.target.checked})}
              className="form-checkbox"
            />
            <span>With Parking</span>
          </label>
          <label className="flex items-center space-x-2">
            <input 
              type="checkbox"
              checked={filters.acceptsCards}
              onChange={(e) => setFilters({...filters, acceptsCards: e.target.checked})}
              className="form-checkbox"
            />
            <span>Accepts Cards</span>
          </label>
        </div>
      </div>

      {/* Detalhes da lavanderia selecionada */}
      {selectedLaundry && showDetails && (
        <div className="absolute bottom-4 left-4 right-4 z-10">
          <LaundryDetails laundry={selectedLaundry} />
        </div>
      )}

      {/* Marcadores de lavanderias (simulados) */}
      <div className="absolute top-20 left-64">
        {mockLaundries.map((laundry, index) => (
          <div 
            key={index} 
            style={{
              position: 'absolute', 
              left: `${Math.random() * 400}px`, 
              top: `${Math.random() * 300}px`
            }}
          >
            <LaundryMarker 
              laundry={laundry} 
              onClick={() => {
                setSelectedLaundry(laundry);
                setShowDetails(true);
              }} 
            />
          </div>
        ))}
      </div>
    </div>
  );
};

// Dados mock para demonstração
const mockLaundries = [
  {
    id: 'truck_laundry_1',
    name: 'King Road Laundry Services',
    address: 'Rodovia BR-101, km 123',
    country: 'BR',
    type: 'TRUCK_STOP',
    operatingHours: {
      weekday: { opening: '06:00', closing: '22:00' },
      saturday: { opening: '07:00', closing: '20:00' },
      sunday: { opening: '08:00', closing: '18:00' },
      is24Hours: false
    },
    services: [
      {
        type: 'Standard Wash',
        capacity: '20kg',
        duration: 60,
        price: { amount: 25.0, currency: 'BRL', includesDetergent: true }
      },
      {
        type: 'Large Load',
        capacity: '30kg',
        duration: 90,
        price: { amount: 35.0, currency: 'BRL', includesDetergent: false }
      }
    ],
    facilities: {
      totalWashers: 6,
      totalDryers: 6,
      hasParking: true,
      parkingSpots: 15,
      hasWifi: true,
      hasWaitingArea: true,
      acceptsCards: true,
      hasRestroom: true
    },
    contact: {
      phone: '+55 11 98765-4321',
      email: 'contato@kingroadlaundry.com.br'
    }
  },
  {
    id: 'truck_laundry_2',
    name: '24/7 Truck Laundry Center',
    address: 'Highway A1, Exit 45',
    country: 'DE',
    type: 'SELF_SERVICE',
    operatingHours: {
      weekday: { opening: '00:00', closing: '23:59' },
      is24Hours: true
    },
    services: [
      {
        type: 'Quick Wash',
        capacity: '15kg',
        duration: 45,
        price: { amount: 10.0, currency: 'EUR', includesDetergent: true }
      }
    ],
    facilities: {
      totalWashers: 8,
      totalDryers: 8,
      hasParking: true,
      parkingSpots: 20,
      hasWifi: true,
      hasRestroom: true,
      acceptsCards: true
    },
    contact: {
      phone: '+49 40 12345678',
      email: 'info@24trucklarundry.de'
    }
  }
];

export default LaundryPOIPreview;