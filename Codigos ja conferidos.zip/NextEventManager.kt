// Sistema de Gerenciamento de Próximo Evento
// app/src/main/kotlin/com/kingroad/navigation/nextevent

import android.location.Location
import java.time.Duration

class NextEventManager(
    private val navigationService: NavigationService,
    private val locationService: LocationService,
    private val timeService: TimeService,
    private val displayManager: DisplayManager
) {
    data class NavigationEvent(
        val type: EventType,
        val location: Location,
        val distance: Double,
        val estimatedTime: Duration,
        val description: String,
        val idealSpeed: Double? = null,
        val recommendedLane: Lane? = null,
        val importance: EventImportance = EventImportance.NORMAL,
        val exitNumber: String? = null,
        val direction: String? = null
    )

    enum class EventType {
        EXIT,               // Saída
        TURN,              // Curva
        TRAFFIC_LIGHT,     // Semáforo
        ROUNDABOUT,        // Rotatória
        MERGE,             // Junção
        LANE_CHANGE,       // Mudança de faixa
        DESTINATION       // Destino final
    }

    enum class EventImportance {
        HIGH,    // Ex: Saída do destino
        NORMAL,  // Ex: Curva normal
        LOW      // Ex: Informação adicional
    }

    data class Lane(
        val number: Int,
        val position: LanePosition,
        val description: String
    )
    
    enum class LanePosition {
        LEFT_MOST,
        LEFT,
        CENTER,
        RIGHT,
        RIGHT_MOST
    }

    // Monitorar próximo evento
    suspend fun startEventMonitoring() {
        locationService.startLocationUpdates { location ->
            updateNextEvent(location)
        }
    }

    // Atualizar informações do próximo evento
    private suspend fun updateNextEvent(currentLocation: Location) {
        val nextEvent = navigationService.getNextEvent(currentLocation)
        
        // Calcular distância e tempo
        val distance = calculateDistance(currentLocation, nextEvent.location)
        val estimatedTime = calculateEstimatedTime(
            distance = distance,
            currentSpeed = locationService.getCurrentSpeed(),
            trafficConditions = getTrafficConditions()
        )
        
        // Atualizar display
        updateEventDisplay(
            event = nextEvent,
            distance = distance,
            estimatedTime = estimatedTime
        )
    }

    // Calcular distância entre dois pontos
    private fun calculateDistance(current: Location, target: Location): Double {
        val results = FloatArray(1)
        Location.distanceBetween(
            current.latitude, current.longitude,
            target.latitude, target.longitude,
            results
        )
        return results[0].toDouble()
    }
    
    // Obter condições de tráfego atual
    private fun getTrafficConditions(): TrafficConditions {
        return navigationService.getCurrentTrafficConditions()
    }

    // Calcular velocidade ideal
    private fun calculateIdealSpeed(
        event: NavigationEvent,
        distance: Double
    ): Double? {
        return when (event.type) {
            EventType.EXIT -> calculateExitApproachSpeed(distance)
            EventType.TURN -> calculateTurnApproachSpeed(distance)
            EventType.TRAFFIC_LIGHT -> calculateTrafficLightApproachSpeed(distance)
            EventType.ROUNDABOUT -> calculateRoundaboutApproachSpeed(distance)
            else -> null
        }
    }

    // Calcular velocidade de aproximação para saída
    private fun calculateExitApproachSpeed(distance: Double): Double {
        return when {
            distance < 100 -> 30.0
            distance < 300 -> 50.0
            distance < 500 -> 70.0
            else -> 80.0
        }
    }

    // Calcular velocidade de aproximação para curva
    private fun calculateTurnApproachSpeed(distance: Double): Double {
        return when {
            distance < 50 -> 20.0
            distance < 100 -> 30.0
            distance < 200 -> 40.0
            else -> 50.0
        }
    }

    // Calcular velocidade de aproximação para semáforo
    private fun calculateTrafficLightApproachSpeed(distance: Double): Double {
        return when {
            distance < 50 -> 20.0
            distance < 100 -> 30.0
            distance < 200 -> 40.0
            else -> 50.0
        }
    }

    // Calcular velocidade de aproximação para rotatória
    private fun calculateRoundaboutApproachSpeed(distance: Double): Double {
        return when {
            distance < 50 -> 20.0
            distance < 100 -> 30.0
            distance < 200 -> 40.0
            else -> 50.0
        }
    }

    // Calcular tempo estimado
    private fun calculateEstimatedTime(
        distance: Double,
        currentSpeed: Double,
        trafficConditions: TrafficConditions
    ): Duration {
        val baseTime = distance / currentSpeed
        val trafficFactor = when (trafficConditions) {
            TrafficConditions.LIGHT -> 1.0
            TrafficConditions.MODERATE -> 1.2
            TrafficConditions.HEAVY -> 1.5
            TrafficConditions.SEVERE -> 2.0
        }
        
        return Duration.ofSeconds((baseTime * trafficFactor).toLong())
    }

    // Gerar descrição do evento
    private fun generateEventDescription(event: NavigationEvent): String {
        return when (event.type) {
            EventType.EXIT -> buildString {
                append("Saída ${event.exitNumber}")
                event.recommendedLane?.let { lane ->
                    append(" - Use a faixa ${lane.description}")
                }
            }
            EventType.TURN -> "Curva à ${event.direction}"
            EventType.TRAFFIC_LIGHT -> "Semáforo"
            EventType.ROUNDABOUT -> "Rotatória - ${event.exitNumber}ª saída"
            EventType.MERGE -> "Junção de pistas"
            EventType.LANE_CHANGE -> "Mude para a faixa ${event.recommendedLane?.description}"
            EventType.DESTINATION -> "Destino final"
        }
    }

    // Formatar tempo
    private fun formatTime(duration: Duration): String {
        val minutes = duration.toMinutes()
        val seconds = duration.minusMinutes(minutes).seconds
        
        return when {
            minutes > 0 -> "$minutes:${seconds.toString().padStart(2, '0')}"
            else -> "$seconds s"
        }
    }

    // Formatar distância
    private fun formatDistance(meters: Double): String {
        return when {
            meters >= 1000 -> "%.1f km".format(meters / 1000)
            else -> "${meters.toInt()} m"
        }
    }

    // Atualizar display
    private suspend fun updateEventDisplay(
        event: NavigationEvent,
        distance: Double,
        estimatedTime: Duration
    ) {
        val idealSpeed = calculateIdealSpeed(event, distance)
        
        displayManager.updateNextEvent(
            NextEventDisplay(
                distance = formatDistance(distance),
                time = formatTime(estimatedTime),
                description = generateEventDescription(event),
                idealSpeed = idealSpeed?.let { "${it.toInt()} km/h" },
                importance = event.importance
            )
        )
    }
}

data class NextEventDisplay(
    val distance: String,
    val time: String,
    val description: String,
    val idealSpeed: String? = null,
    val importance: NextEventManager.EventImportance
)

enum class TrafficConditions {
    LIGHT,
    MODERATE,
    HEAVY,
    SEVERE
}

// Interfaces necessárias
interface NavigationService {
    suspend fun getNextEvent(currentLocation: Location): NextEventManager.NavigationEvent
    fun getCurrentTrafficConditions(): TrafficConditions
}

interface LocationService {
    suspend fun startLocationUpdates(callback: suspend (Location) -> Unit)
    fun getCurrentSpeed(): Double
}

interface TimeService {
    fun getCurrentTime(): Long
    fun calculateTimeToDistance(distance: Double, speed: Double): Duration
}

interface DisplayManager {
    suspend fun updateNextEvent(eventDisplay: NextEventDisplay)
}