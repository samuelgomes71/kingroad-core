// kingroad_eventos_navegacao_global.js
export const navigationEventDisplaySystem = {
  "version": "1.0",
  "lastUpdated": "2025-03-30",
  "modules": {
    "eventSidePositioning": {
      "description": "Exibe eventos do lado correspondente à direção da saída.",
      "behavior": {
        "rightExit": {
          "displaySide": "right",
          "overlapExistingUI": true
        },
        "leftExit": {
          "displaySide": "left",
          "overlapExistingUI": true
        }
      },
      "overrideDuration": 10,
      "note": "Os avisos desaparecem automaticamente após o tempo definido se não houver nova instrução."
    },
    "laneGuidanceArrows": {
      "description": "Exibe setas dinâmicas indicando a faixa correta a ser usada pelo motorista.",
      "enabled": true,
      "style": {
        "type": "animated",
        "color": "yellow",
        "position": "bottomOverlay"
      },
      "examples": [
        "↖ Fique na faixa da esquerda",
        "↑ Siga em frente na faixa central",
        "↘ Pegue a saída à direita"
      ]
    },
    "visualAndAudioAlerts": {
      "description": "Combina alerta visual e sonoro para reforçar eventos importantes como saídas, curvas ou radares.",
      "soundEnabled": true,
      "visualFlash": true,
      "volumeLevel": "adaptive",
      "soundExamples": [
        "Atenção! Saída à direita em 500 metros.",
        "Prepare-se! Curva acentuada à esquerda."
      ]
    }
  },
  "globalAvailability": true,
  "appliesToAllCountriesFromGlobalReference": true
};

export default navigationEventDisplaySystem;