import React, { useState, useEffect } from 'react';
import { AlertTriangle, Heart, MessageCircle, Home, Users, Shield } from 'lucide-react';

const SafetyAppealSystem = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [dangerLevel, setDangerLevel] = useState('medium'); // 'low', 'medium', 'high', 'extreme'
  const [currentLocation, setCurrentLocation] = useState('Serra da Cantareira - SP');
  const [speedWarning, setSpeedWarning] = useState(true);
  const [showMessage, setShowMessage] = useState(false);
  const [customAppeals, setCustomAppeals] = useState([]);
  const [familyContacts, setFamilyContacts] = useState([
    { id: 1, name: 'Amanda (Esposa)', photo: '/api/placeholder/50/50', lastMessage: 'Te amo, volte seguro.' },
    { id: 2, name: 'Pedro (Filho)', photo: '/api/placeholder/50/50', lastMessage: 'Pai, vamos jogar bola quando você voltar?' },
    { id: 3, name: 'Maria (Mãe)', photo: '/api/placeholder/50/50', lastMessage: 'Filho, estou rezando por você.' }
  ]);
  
  // Dados de áreas de risco
  const dangerZones = {
    'Serra da Cantareira - SP': {
      level: 'extreme',
      risks: ['declives acentuados', 'curvas fechadas', 'freios superaquecidos'],
      accidents: 27,
      fatalAccidents: 12,
      familyMessage: "Freios superaquecidos já causaram 12 mortes de pais de família aqui.",
      tip: "Use o freio motor para não perder quem ama você."
    },
    'Serra das Araras - RJ': {
      level: 'high',
      risks: ['declives acentuados', 'curvas fechadas', 'neblina'],
      accidents: 35,
      fatalAccidents: 18,
      familyMessage: "18 famílias já perderam seus pais nesta serra por excesso de velocidade.",
      tip: "Reduza a velocidade para voltar para quem ama você."
    },
    'Serra do Guaraú - SP': {
      level: 'medium',
      risks: ['declives médios', 'curvas perigosas'],
      accidents: 14,
      fatalAccidents: 6,
      familyMessage: "6 crianças já ficaram sem pai aqui por imprudência na direção.",
      tip: "Mantenha velocidade segura para ver seu filho crescer."
    }
  };
  
  // Simulação de mudança de região para demonstração
  useEffect(() => {
    const locations = Object.keys(dangerZones);
    let currentIndex = 0;
    
    const interval = setInterval(() => {
      const location = locations[currentIndex];
      setCurrentLocation(location);
      setDangerLevel(dangerZones[location].level);
      
      // Mostrar mensagem na primeira vez que entrar numa zona de perigo extremo
      if (dangerZones[location].level === 'extreme' || dangerZones[location].level === 'high') {
        setShowMessage(true);
        
        // Esconder a mensagem após alguns segundos
        setTimeout(() => {
          setShowMessage(false);
        }, 8000);
      }
      
      currentIndex = (currentIndex + 1) % locations.length;
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Adicionar um apelo personalizado
  const addCustomAppeal = () => {
    const newAppeals = [...customAppeals];
    
    // Exemplos de apelos personalizados
    const appeals = [
      "Lembre-se que sua família espera você voltar para o jantar.",
      "Sua filha tem apresentação de balé no domingo, não se atrase.",
      "Você prometeu levar seu filho ao jogo de futebol este fim de semana."
    ];
    
    if (newAppeals.length < appeals.length) {
      newAppeals.push(appeals[newAppeals.length]);
      setCustomAppeals(newAppeals);
    }
  };
  
  // Remove um apelo personalizado
  const removeAppeal = (index) => {
    const newAppeals = [...customAppeals];
    newAppeals.splice(index, 1);
    setCustomAppeals(newAppeals);
  };
  
  // Determina a cor com base no nível de perigo
  const getDangerColor = () => {
    switch (dangerLevel) {
      case 'extreme':
        return 'bg-red-600';
      case 'high':
        return 'bg-red-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-yellow-400';
      default:
        return 'bg-green-500';
    }
  };
  
  // Classifica o nível de perigo para exibição
  const getDangerText = () => {
    switch (dangerLevel) {
      case 'extreme':
        return 'PERIGO EXTREMO';
      case 'high':
        return 'PERIGO ALTO';
      case 'medium':
        return 'PERIGO MODERADO';
      case 'low':
        return 'PERIGO BAIXO';
      default:
        return 'SEGURO';
    }
  };
  
  // Obter os detalhes da zona de perigo atual
  const getCurrentZoneDetails = () => {
    return dangerZones[currentLocation] || { 
      level: 'low', 
      risks: ['Sem riscos significativos'],
      accidents: 0,
      fatalAccidents: 0,
      familyMessage: "",
      tip: "Dirija com segurança sempre."
    };
  };

  return (
    <div className={`${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'} min-h-screen p-4`}>
      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-4 border-b border-gray-700 pb-3">
        <div className="flex items-center">
          <Heart className="w-6 h-6 mr-2 text-red-500" />
          <h1 className="text-xl font-bold">King Road - Segurança Familiar</h1>
        </div>
      </div>
      
      {/* Mensagem de alerta para áreas perigosas */}
      {showMessage && (
        <div className="fixed inset-x-0 top-20 mx-auto max-w-md z-50 transform transition-all duration-500 ease-in-out animate-pulse">
          <div className="bg-red-600 rounded-lg shadow-lg p-4 mx-4">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-white" />
              </div>
              <div className="ml-3 w-0 flex-1 pt-0.5">
                <p className="text-lg font-medium text-white">Atenção: Zona de Alto Risco!</p>
                <p className="mt-1 text-white">{getCurrentZoneDetails().familyMessage}</p>
                <p className="mt-2 text-white font-bold">{getCurrentZoneDetails().tip}</p>
                <div className="mt-3 flex items-center">
                  <button
                    className="bg-white bg-opacity-20 rounded-md px-3 py-1.5 text-sm font-medium text-white hover:bg-opacity-30 focus:outline-none"
                    onClick={() => setShowMessage(false)}
                  >
                    Entendi
                  </button>
                  <span className="ml-3 text-white text-sm opacity-80">
                    Esta mensagem salva vidas
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Indicador de área perigosa */}
      <div className="mb-4">
        <div className={`${getDangerColor()} rounded-lg p-4 text-white`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <AlertTriangle className="h-6 w-6 mr-2" />
              <span className="font-bold">{getDangerText()}</span>
            </div>
            <span className="text-sm opacity-90">{currentLocation}</span>
          </div>
          
          <div className="mt-2">
            <p className="text-sm mb-1">Riscos nesta área:</p>
            <ul className="text-sm list-disc list-inside">
              {getCurrentZoneDetails().risks.map((risk, index) => (
                <li key={index}>{risk}</li>
              ))}
            </ul>
          </div>
          
          <div className="mt-3 pt-3 border-t border-white border-opacity-20">
            <div className="grid grid-cols-2 gap-2 text-center">
              <div>
                <p className="text-xs opacity-80">Acidentes registrados</p>
                <p className="text-xl font-bold">{getCurrentZoneDetails().accidents}</p>
              </div>
              <div>
                <p className="text-xs opacity-80">Acidentes fatais</p>
                <p className="text-xl font-bold">{getCurrentZoneDetails().fatalAccidents}</p>
              </div>
            </div>
          </div>
        </div>
        
        {speedWarning && dangerLevel === 'extreme' && (
          <div className="mt-2 bg-red-700 p-3 rounded-lg text-white text-center animate-pulse">
            <p className="font-medium">ATENÇÃO! Use o freio motor nesta descida!</p>
            <p className="text-sm">Freios superaquecidos já causaram muitas tragédias familiares aqui.</p>
          </div>
        )}
      </div>
      
      {/* Lembretes familiares */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-4`}>
        <div className="flex items-center mb-3">
          <Home className="w-5 h-5 mr-2 text-blue-500" />
          <h2 className="text-lg font-medium">Lembretes de Casa</h2>
        </div>
        
        <div className="space-y-3">
          {familyContacts.map((contact) => (
            <div key={contact.id} className={`p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-500">
                  <img src={contact.photo} alt={contact.name} className="w-full h-full object-cover" />
                </div>
                <div className="ml-3">
                  <p className="font-medium">{contact.name}</p>
                  <p className="text-sm opacity-80">"{contact.lastMessage}"</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4">
          <button 
            onClick={() => {}}
            className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Enviar mensagem: "Estou dirigindo com segurança"
          </button>
        </div>
      </div>
      
      {/* Apelos personalizados */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4 mb-4`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <Users className="w-5 h-5 mr-2 text-blue-500" />
            <h2 className="text-lg font-medium">Meus Lembretes</h2>
          </div>
          <button 
            onClick={addCustomAppeal}
            className="p-1 rounded-full bg-blue-600 text-white"
          >
            <span className="sr-only">Adicionar lembrete</span>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
            </svg>
          </button>
        </div>
        
        {customAppeals.length > 0 ? (
          <div className="space-y-2">
            {customAppeals.map((appeal, index) => (
              <div 
                key={index} 
                className={`p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} flex justify-between items-center`}
              >
                <p>{appeal}</p>
                <button 
                  onClick={() => removeAppeal(index)}
                  className="p-1 rounded-full hover:bg-gray-600"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} text-center`}>
            <p className="text-gray-400">Clique no + para adicionar lembretes pessoais</p>
          </div>
        )}
      </div>
      
      {/* Compromisso de segurança */}
      <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-4`}>
        <div className="flex items-center mb-3">
          <Shield className="w-5 h-5 mr-2 text-green-500" />
          <h2 className="text-lg font-medium">Meu Compromisso</h2>
        </div>
        
        <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-blue-900/30' : 'bg-blue-100'}`}>
          <p className="font-medium text-center">
            "Eu dirijo com segurança porque tenho pessoas que me amam e me esperam em casa."
          </p>
        </div>
        
        <div className="mt-4 grid grid-cols-3 gap-2">
          <button className="p-2 bg-red-600/20 text-red-400 rounded-lg text-center">
            <p className="text-xs mb-1">Acidentes evitados</p>
            <p className="font-bold">7</p>
          </button>
          <button className="p-2 bg-green-600/20 text-green-400 rounded-lg text-center">
            <p className="text-xs mb-1">Dias seguros</p>
            <p className="font-bold">43</p>
          </button>
          <button className="p-2 bg-blue-600/20 text-blue-400 rounded-lg text-center">
            <p className="text-xs mb-1">Viagens seguras</p>
            <p className="font-bold">21</p>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SafetyAppealSystem;