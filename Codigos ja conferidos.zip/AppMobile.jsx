import React from 'react';
import AppNavigator from './native/navigation/AppNavigator';

const App = () => {
  return <AppNavigator />;
};

export default App;