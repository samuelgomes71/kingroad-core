/**
 * DeveloperModeService.js
 * 
 * Service to manage developer mode functionality in the KingRoad app.
 * This mode provides additional tools and settings for debugging and testing.
 * 
 * Features:
 * - Screen recording
 * - Menu editing
 * - Visual adjustments
 * - Zoom, tilt, position controls
 * - Size customization
 * 
 * Access: 5 toques no logo + senha
 * 
 * @author KingRoad Development Team
 * @version 1.0.0
 */

import { Alert, Platform } from 'react-native';
import OfflineCacheManager from './OfflineCacheManager';
import LogService from './LogService';
import { TranslationsService } from './TranslationsService';

// Singleton instance
let instance = null;

class DeveloperModeService {
  constructor() {
    if (instance) {
      return instance;
    }
    
    // Developer mode state
    this.state = {
      active: false,        // If dev mode is currently enabled
      activationAttempts: 0, // Number of logo taps
      activationTimeout: null, // Timeout to reset tap count
      sessionStartTime: null, // When the dev session started
      recording: false,     // If screen recording is active
      recordingData: [],    // Recorded actions/events
    };
    
    // Developer mode settings (persistent)
    this.settings = {
      password: 'kingroad2025', // Default password
      autoExit: 20,          // Auto-exit after X minutes of inactivity (0 = disabled)
      enableLogging: true,   // Enhanced logging
      showCoordinates: false, // Display coordinates on screen
      showFPS: false,        // Display FPS counter
      showMemory: false,     // Display memory usage
      showGrid: false,       // Display alignment grid
      customMenus: {},       // Custom menu configurations
      visualAdjustments: {   // Visual adjustments
        brightness: 1.0,
        contrast: 1.0,
        saturation: 1.0,
        scale: 1.0,
      },
      cameraSettings: {      // Camera/map view settings
        defaultZoom: 15,
        defaultTilt: 45,
        minZoom: 2,
        maxZoom: 22,
      },
      screenSizes: [         // Predefined screen sizes for testing
        { name: 'Phone Small', width: 320, height: 568 },
        { name: 'Phone Medium', width: 375, height: 667 },
        { name: 'Phone Large', width: 414, height: 736 },
        { name: 'Tablet Small', width: 768, height: 1024 },
        { name: 'Tablet Large', width: 1024, height: 1366 },
      ],
      lastUsedSize: null,    // Last used screen size
    };
    
    // Event listeners
    this.listeners = {
      onActivate: [],
      onDeactivate: [],
      onSettingsChange: [],
    };
    
    // Initialize
    this.init();
    
    instance = this;
  }
  
  /**
   * Initialize the service
   */
  async init() {
    try {
      // Load settings from storage
      const savedSettings = await OfflineCacheManager.getItem('developer_mode_settings');
      if (savedSettings) {
        this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
      }
      
      // Check if dev mode was active last time
      const wasActive = await OfflineCacheManager.getItem('developer_mode_active');
      if (wasActive === 'true') {
        this.activate(true); // Silent activation (no password)
      }
      
      LogService.debug('DeveloperModeService initialized');
    } catch (error) {
      LogService.error('Error initializing DeveloperModeService:', error);
    }
  }
  
  /**
   * Save settings to persistent storage
   */
  async saveSettings() {
    try {
      await OfflineCacheManager.setItem(
        'developer_mode_settings',
        JSON.stringify(this.settings)
      );
      
      // Notify listeners
      this.notifyListeners('onSettingsChange', this.settings);
      
      LogService.debug('Developer mode settings saved');
    } catch (error) {
      LogService.error('Error saving developer mode settings:', error);
    }
  }
  
  /**
   * Save active state to persistent storage
   */
  async saveActiveState() {
    try {
      await OfflineCacheManager.setItem(
        'developer_mode_active',
        this.state.active.toString()
      );
    } catch (error) {
      LogService.error('Error saving developer mode active state:', error);
    }
  }
  
  /**
   * Handle logo tap (part of activation sequence)
   */
  handleLogoTap() {
    // Clear timeout if exists
    if (this.state.activationTimeout) {
      clearTimeout(this.state.activationTimeout);
    }
    
    // Increment tap count
    this.state.activationAttempts += 1;
    
    // Set timeout to reset count
    this.state.activationTimeout = setTimeout(() => {
      this.state.activationAttempts = 0;
    }, 3000); // Reset after 3 seconds
    
    // Check if we've reached the required number of taps
    if (this.state.activationAttempts >= 5) {
      this.promptPassword();
      this.state.activationAttempts = 0;
    }
  }
  
  /**
   * Prompt for password
   */
  promptPassword() {
    // Use platform's native alert for password prompt
    Alert.prompt(
      TranslationsService.getTranslation('devMode.passwordPrompt'),
      TranslationsService.getTranslation('devMode.enterPassword'),
      [
        {
          text: TranslationsService.getTranslation('common.cancel'),
          style: 'cancel',
        },
        {
          text: TranslationsService.getTranslation('common.ok'),
          onPress: (password) => this.verifyPassword(password),
        },
      ],
      'secure-text' // Password input
    );
  }
  
  /**
   * Verify password and activate if correct
   * @param {string} password - Entered password
   */
  verifyPassword(password) {
    if (password === this.settings.password) {
      this.activate();
    } else {
      Alert.alert(
        TranslationsService.getTranslation('devMode.incorrectPassword'),
        TranslationsService.getTranslation('devMode.tryAgain')
      );
    }
  }
  
  /**
   * Activate developer mode
   * @param {boolean} silent - If true, activate without notifications
   */
  activate(silent = false) {
    if (this.state.active) return;
    
    this.state.active = true;
    this.state.sessionStartTime = Date.now();
    
    // Save active state
    this.saveActiveState();
    
    // Enable enhanced logging if configured
    if (this.settings.enableLogging) {
      LogService.setLogLevel('trace');
      LogService.enableFileLogging(true);
    }
    
    // Set auto-exit timeout if enabled
    if (this.settings.autoExit > 0) {
      this.startAutoExitTimer();
    }
    
    // Notify listeners
    if (!silent) {
      this.notifyListeners('onActivate');
      
      // Display activation notification
      Alert.alert(
        TranslationsService.getTranslation('devMode.activated'),
        TranslationsService.getTranslation('devMode.modeEnabled')
      );
    }
    
    LogService.info('Developer mode activated');
  }
  
  /**
   * Deactivate developer mode
   * @param {boolean} silent - If true, deactivate without notifications
   */
  deactivate(silent = false) {
    if (!this.state.active) return;
    
    // Stop recording if active
    if (this.state.recording) {
      this.stopRecording();
    }
    
    this.state.active = false;
    this.state.sessionStartTime = null;
    
    // Save active state
    this.saveActiveState();
    
    // Reset logging to normal
    LogService.setLogLevel('info');
    LogService.enableFileLogging(false);
    
    // Notify listeners
    if (!silent) {
      this.notifyListeners('onDeactivate');
      
      // Display deactivation notification
      Alert.alert(
        TranslationsService.getTranslation('devMode.deactivated'),
        TranslationsService.getTranslation('devMode.modeDisabled')
      );
    }
    
    LogService.info('Developer mode deactivated');
  }
  
  /**
   * Start the auto-exit timer
   */
  startAutoExitTimer() {
    // Clear any existing timer
    if (this.state.autoExitTimer) {
      clearTimeout(this.state.autoExitTimer);
    }
    
    // Set new timer
    this.state.autoExitTimer = setTimeout(() => {
      LogService.info('Developer mode auto-exited due to inactivity');
      this.deactivate(true);
    }, this.settings.autoExit * 60 * 1000); // Convert minutes to milliseconds
  }
  
  /**
   * Reset the auto-exit timer (call when user interacts with dev tools)
   */
  resetAutoExitTimer() {
    if (this.settings.autoExit > 0 && this.state.active) {
      this.startAutoExitTimer();
    }
  }
  
  /**
   * Start screen recording
   */
  startRecording() {
    if (!this.state.active || this.state.recording) return;
    
    this.state.recording = true;
    this.state.recordingData = [];
    this.state.recordingStartTime = Date.now();
    
    LogService.info('Developer mode recording started');
    
    return {
      success: true,
      startTime: this.state.recordingStartTime,
    };
  }
  
  /**
   * Stop screen recording
   */
  stopRecording() {
    if (!this.state.active || !this.state.recording) return;
    
    this.state.recording = false;
    const endTime = Date.now();
    const duration = endTime - this.state.recordingStartTime;
    
    LogService.info(`Developer mode recording stopped (${duration}ms)`);
    
    return {
      success: true,
      startTime: this.state.recordingStartTime,
      endTime: endTime,
      duration: duration,
      events: this.state.recordingData.length,
      data: this.state.recordingData,
    };
  }
  
  /**
   * Record an event
   * @param {string} type - Event type
   * @param {Object} data - Event data
   */
  recordEvent(type, data) {
    if (!this.state.active || !this.state.recording) return;
    
    this.state.recordingData.push({
      timestamp: Date.now(),
      type,
      data,
    });
  }
  
  /**
   * Get the current recording data
   * @returns {Object} Recording data and metadata
   */
  getRecordingData() {
    return {
      recording: this.state.recording,
      startTime: this.state.recordingStartTime,
      duration: this.state.recording ? Date.now() - this.state.recordingStartTime : 0,
      events: this.state.recordingData.length,
      data: [...this.state.recordingData],
    };
  }
  
  /**
   * Get all developer mode settings
   * @returns {Object} Clone of settings
   */
  getSettings() {
    return { ...this.settings };
  }
  
  /**
   * Update developer mode settings
   * @param {Object} newSettings - Settings to update
   * @returns {Object} Updated settings
   */
  async updateSettings(newSettings) {
    this.settings = {
      ...this.settings,
      ...newSettings,
    };
    
    // Apply settings immediately
    if (this.state.active && newSettings.enableLogging !== undefined) {
      LogService.setLogLevel(newSettings.enableLogging ? 'trace' : 'info');
      LogService.enableFileLogging(newSettings.enableLogging);
    }
    
    // Save to storage
    await this.saveSettings();
    
    return this.settings;
  }
  
  /**
   * Reset settings to defaults
   */
  async resetSettings() {
    this.settings = {
      password: 'kingroad2025',
      autoExit: 20,
      enableLogging: true,
      showCoordinates: false,
      showFPS: false,
      showMemory: false,
      showGrid: false,
      customMenus: {},
      visualAdjustments: {
        brightness: 1.0,
        contrast: 1.0,
        saturation: 1.0,
        scale: 1.0,
      },
      cameraSettings: {
        defaultZoom: 15,
        defaultTilt: 45,
        minZoom: 2,
        maxZoom: 22,
      },
      screenSizes: [
        { name: 'Phone Small', width: 320, height: 568 },
        { name: 'Phone Medium', width: 375, height: 667 },
        { name: 'Phone Large', width: 414, height: 736 },
        { name: 'Tablet Small', width: 768, height: 1024 },
        { name: 'Tablet Large', width: 1024, height: 1366 },
      ],
      lastUsedSize: null,
    };
    
    // Save to storage
    await this.saveSettings();
    
    return this.settings;
  }
  
  /**
   * Update visual adjustments
   * @param {Object} adjustments - Visual adjustments to update
   * @returns {Object} Updated visual adjustments
   */
  async updateVisualAdjustments(adjustments) {
    this.settings.visualAdjustments = {
      ...this.settings.visualAdjustments,
      ...adjustments,
    };
    
    // Save settings
    await this.saveSettings();
    
    return this.settings.visualAdjustments;
  }
  
  /**
   * Update camera settings
   * @param {Object} settings - Camera settings to update
   * @returns {Object} Updated camera settings
   */
  async updateCameraSettings(settings) {
    this.settings.cameraSettings = {
      ...this.settings.cameraSettings,
      ...settings,
    };
    
    // Save settings
    await this.saveSettings();
    
    return this.settings.cameraSettings;
  }
  
  /**
   * Set the screen size for testing
   * @param {Object} size - Screen size object or index
   * @returns {Object} Selected screen size
   */
  async setScreenSize(size) {
    let selectedSize;
    
    if (typeof size === 'number') {
      // Use index
      if (size >= 0 && size < this.settings.screenSizes.length) {
        selectedSize = this.settings.screenSizes[size];
      } else {
        return null;
      }
    } else if (typeof size === 'object') {
      // Use object
      selectedSize = size;
    } else {
      return null;
    }
    
    this.settings.lastUsedSize = selectedSize;
    
    // Save settings
    await this.saveSettings();
    
    return selectedSize;
  }
  
  /**
   * Get the current screen size
   * @returns {Object} Current screen size
   */
  getCurrentScreenSize() {
    return this.settings.lastUsedSize;
  }
  
  /**
   * Get available screen sizes
   * @returns {Array} Available screen sizes
   */
  getScreenSizes() {
    return [...this.settings.screenSizes];
  }
  
  /**
   * Add a custom screen size
   * @param {Object} size - Screen size to add
   * @returns {Array} Updated screen sizes
   */
  async addScreenSize(size) {
    if (!size.name || !size.width || !size.height) {
      return null;
    }
    
    this.settings.screenSizes.push(size);
    
    // Save settings
    await this.saveSettings();
    
    return this.settings.screenSizes;
  }
  
  /**
   * Delete a custom screen size
   * @param {number} index - Index of screen size to delete
   * @returns {Array} Updated screen sizes
   */
  async deleteScreenSize(index) {
    if (index < 0 || index >= this.settings.screenSizes.length) {
      return null;
    }
    
    this.settings.screenSizes.splice(index, 1);
    
    // Save settings
    await this.saveSettings();
    
    return this.settings.screenSizes;
  }
  
  /**
   * Add or update a custom menu
   * @param {string} menuId - Menu ID
   * @param {Object} menuConfig - Menu configuration
   * @returns {Object} Updated custom menus
   */
  async setCustomMenu(menuId, menuConfig) {
    this.settings.customMenus[menuId] = menuConfig;
    
    // Save settings
    await this.saveSettings();
    
    return { ...this.settings.customMenus };
  }
  
  /**
   * Delete a custom menu
   * @param {string} menuId - Menu ID to delete
   * @returns {Object} Updated custom menus
   */
  async deleteCustomMenu(menuId) {
    if (this.settings.customMenus[menuId]) {
      delete this.settings.customMenus[menuId];
      
      // Save settings
      await this.saveSettings();
    }
    
    return { ...this.settings.customMenus };
  }
  
  /**
   * Get all custom menus
   * @returns {Object} Custom menus
   */
  getCustomMenus() {
    return { ...this.settings.customMenus };
  }
  
  /**
   * Check if developer mode is active
   * @returns {boolean} True if active
   */
  isActive() {
    return this.state.active;
  }
  
  /**
   * Check if currently recording
   * @returns {boolean} True if recording
   */
  isRecording() {
    return this.state.recording;
  }
  
  /**
   * Add event listener
   * @param {string} event - Event name ('onActivate', 'onDeactivate', 'onSettingsChange')
   * @param {Function} listener - Event listener function
   * @returns {number} Listener ID
   */
  addEventListener(event, listener) {
    if (!this.listeners[event]) {
      return -1;
    }
    
    this.listeners[event].push(listener);
    return this.listeners[event].length - 1;
  }
  
  /**
   * Remove event listener
   * @param {string} event - Event name
   * @param {number|Function} listenerOrId - Listener function or ID
   * @returns {boolean} Success
   */
  removeEventListener(event, listenerOrId) {
    if (!this.listeners[event]) {
      return false;
    }
    
    if (typeof listenerOrId === 'number') {
      // Remove by ID
      if (listenerOrId >= 0 && listenerOrId < this.listeners[event].length) {
        this.listeners[event].splice(listenerOrId, 1);
        return true;
      }
    } else if (typeof listenerOrId === 'function') {
      // Remove by function reference
      const index = this.listeners[event].indexOf(listenerOrId);
      if (index !== -1) {
        this.listeners[event].splice(index, 1);
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * Notify all listeners of an event
   * @param {string} event - Event name
   * @param {*} data - Event data
   */
  notifyListeners(event, data) {
    if (!this.listeners[event]) {
      return;
    }
    
    this.listeners[event].forEach((listener) => {
      try {
        listener(data);
      } catch (error) {
        LogService.error(`Error in developer mode ${event} listener:`, error);
      }
    });
  }
}

export default new DeveloperModeService();