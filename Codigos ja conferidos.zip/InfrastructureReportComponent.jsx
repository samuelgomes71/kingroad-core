import React, { useState, useEffect } from 'react';
import { Camera, MapPin, Send, AlertTriangle, Clipboard, Share, Upload, Check, X, Info, Phone, MessageCircle } from 'lucide-react';

// Componente principal para denúncias de infraestrutura pública
const InfrastructureReportComponent = ({ userLocation, userId, onSuccess, onCancel }) => {
  // Estados
  const [reportType, setReportType] = useState('');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(userLocation);
  const [showSocialMediaOptions, setShowSocialMediaOptions] = useState(false);
  const [postToSocialMedia, setPostToSocialMedia] = useState(false);
  const [municipality, setMunicipality] = useState(null);
  const [step, setStep] = useState(1); // 1: Tipo, 2: Detalhes, 3: Fotos, 4: Confirmação
  
  // Buscar informações da municipalidade quando a localização mudar
  useEffect(() => {
    if (currentLocation) {
      // Simulação de busca de municipalidade
      setTimeout(() => {
        setMunicipality({
          id: "mun123",
          name: "São Paulo",
          country: "Brasil",
          hasApiIntegration: true,
          hasSocialMedia: true,
          socialAccounts: ["Twitter", "Facebook", "Instagram"]
        });
      }, 1000);
    }
  }, [currentLocation]);
  
  // Tipos de problemas disponíveis para denúncia
  const reportTypes = [
    { id: 'POTHOLE', label: 'Buraco na via', icon: '🕳️' },
    { id: 'FALLEN_TREE', label: 'Árvore caída', icon: '🌳' },
    { id: 'BROKEN_TRAFFIC_LIGHT', label: 'Semáforo quebrado', icon: '🚦' },
    { id: 'WATER_LEAK', label: 'Vazamento de água', icon: '💧' },
    { id: 'DAMAGED_BRIDGE', label: 'Ponte danificada', icon: '🌉' },
    { id: 'STREET_LIGHT_OUTAGE', label: 'Iluminação pública defeituosa', icon: '💡' },
    { id: 'ILLEGAL_DUMPING', label: 'Descarte irregular de lixo', icon: '🗑️' },
    { id: 'ABANDONED_WASTE', label: 'Lixo abandonado', icon: '🚮' },
    { id: 'FLOODING', label: 'Alagamento', icon: '🌊' },
    { id: 'OTHER', label: 'Outro problema', icon: '❓' }
  ];
  
  // Manipuladores de eventos
  const handleAddPhoto = () => {
    // Em uma implementação real, isto abriria a câmera/galeria
    // Para mock, adicionamos uma "foto" fictícia
    const newPhoto = {
      id: Date.now(),
      uri: `/api/placeholder/300/300?text=Foto${photos.length + 1}`,
      thumbnail: `/api/placeholder/100/100?text=T${photos.length + 1}`
    };
    
    setPhotos([...photos, newPhoto]);
  };
  
  const handleRemovePhoto = (photoId) => {
    setPhotos(photos.filter(photo => photo.id !== photoId));
  };
  
  const handleSubmit = () => {
    setUploading(true);
    
    // Simulação de envio
    setTimeout(() => {
      setUploading(false);
      
      if (onSuccess) {
        onSuccess({
          id: `report-${Date.now()}`,
          type: reportType,
          municipality: municipality.name,
          protocolNumber: `PROT-${Math.floor(Math.random() * 100000)}`,
          timestamp: new Date().toISOString()
        });
      }
    }, 2000);
  };
  
  const handleUpdateLocation = () => {
    // Em uma implementação real, isto usaria a API de geolocalização
    // Para mock, simulamos uma pequena alteração na localização
    setCurrentLocation({
      latitude: userLocation.latitude + (Math.random() * 0.002 - 0.001),
      longitude: userLocation.longitude + (Math.random() * 0.002 - 0.001)
    });
  };
  
  const renderStepIndicator = () => (
    <div className="flex justify-center mb-6">
      {[1, 2, 3, 4].map(stepNumber => (
        <div 
          key={stepNumber}
          className={`w-8 h-8 mx-1 rounded-full flex items-center justify-center ${
            step === stepNumber 
              ? 'bg-amber-500 text-black font-bold' 
              : step > stepNumber 
                ? 'bg-green-500 text-white' 
                : 'bg-gray-700 text-gray-400'
          }`}
        >
          {step > stepNumber ? <Check size={16} /> : stepNumber}
        </div>
      ))}
    </div>
  );
  
  const renderTypeSelection = () => (
    <div>
      <h3 className="text-lg font-bold text-center mb-4">Selecione o tipo de problema</h3>
      
      <div className="grid grid-cols-2 gap-3">
        {reportTypes.map(type => (
          <button
            key={type.id}
            className={`p-4 rounded-lg flex flex-col items-center justify-center transition-colors ${
              reportType === type.id 
                ? 'bg-amber-500 text-black' 
                : 'bg-gray-800 hover:bg-gray-700 text-white'
            }`}
            onClick={() => setReportType(type.id)}
          >
            <span className="text-2xl mb-2">{type.icon}</span>
            <span className="text-sm font-medium">{type.label}</span>
          </button>
        ))}
      </div>
      
      <div className="mt-6 flex justify-between">
        <button 
          onClick={onCancel}
          className="px-4 py-2 text-gray-400 hover:text-white"
        >
          Cancelar
        </button>
        
        <button 
          onClick={() => setStep(2)}
          disabled={!reportType}
          className={`px-6 py-2 rounded-lg font-medium ${
            reportType 
              ? 'bg-amber-500 text-black' 
              : 'bg-gray-700 text-gray-400 cursor-not-allowed'
          }`}
        >
          Próximo
        </button>
      </div>
    </div>
  );
  
  const renderDetailsForm = () => (
    <div>
      <h3 className="text-lg font-bold text-center mb-4">Detalhes do problema</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">
          Tipo de problema
        </label>
        <div className="p-3 bg-gray-800 rounded-lg flex items-center">
          <span className="text-xl mr-2">
            {reportTypes.find(t => t.id === reportType)?.icon}
          </span>
          <span>
            {reportTypes.find(t => t.id === reportType)?.label}
          </span>
          <button 
            onClick={() => setStep(1)}
            className="ml-auto text-amber-400 hover:text-amber-300"
          >
            Alterar
          </button>
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">
          Localização
        </label>
        <div className="p-3 bg-gray-800 rounded-lg flex items-center">
          <MapPin size={18} className="text-amber-400 mr-2" />
          <span className="text-sm truncate">
            {currentLocation
              ? `${currentLocation.latitude.toFixed(6)}, ${currentLocation.longitude.toFixed(6)}`
              : 'Localização não disponível'}
          </span>
          <button 
            onClick={handleUpdateLocation}
            className="ml-auto text-amber-400 hover:text-amber-300 text-sm"
          >
            Atualizar
          </button>
        </div>
        
        {municipality && (
          <div className="mt-2 text-sm flex items-center text-gray-400">
            <Info size={14} className="mr-1" />
            <span>Município: {municipality.name}, {municipality.country}</span>
          </div>
        )}
      </div>
      
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2">
          Descrição
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Descreva o problema com mais detalhes..."
          className="w-full p-3 bg-gray-800 rounded-lg text-white border border-gray-700 focus:border-amber-500 focus:outline-none resize-none h-32"
        />
        <div className="mt-1 text-sm text-gray-400 flex justify-end">
          {description.length}/200 caracteres
        </div>
      </div>
      
      <div className="mt-6 flex justify-between">
        <button 
          onClick={() => setStep(1)}
          className="px-4 py-2 text-gray-400 hover:text-white"
        >
          Voltar
        </button>
        
        <button 
          onClick={() => setStep(3)}
          className="px-6 py-2 rounded-lg font-medium bg-amber-500 text-black"
        >
          Próximo
        </button>
      </div>
    </div>
  );
  
  const renderPhotoUpload = () => (
    <div>
      <h3 className="text-lg font-bold text-center mb-4">Adicionar fotos</h3>
      
      <div className="mb-4 text-sm text-gray-400 text-center">
        Fotos ajudam a identificar o problema mais rapidamente
      </div>
      
      <div className="grid grid-cols-3 gap-3 mb-6">
        {photos.map(photo => (
          <div key={photo.id} className="relative">
            <img 
              src={photo.uri} 
              alt="Foto do problema" 
              className="w-full h-24 object-cover rounded-lg"
            />
            <button
              onClick={() => handleRemovePhoto(photo.id)}
              className="absolute -top-2 -right-2 bg-red-500 rounded-full w-6 h-6 flex items-center justify-center"
            >
              <X size={14} />
            </button>
          </div>
        ))}
        
        {photos.length < 3 && (
          <button
            onClick={handleAddPhoto}
            className="w-full h-24 border-2 border-dashed border-gray-700 rounded-lg flex flex-col items-center justify-center hover:border-amber-500 transition-colors"
          >
            <Camera size={24} className="text-amber-500 mb-2" />
            <span className="text-xs text-gray-400">Adicionar</span>
          </button>
        )}
      </div>
      
      {municipality && municipality.hasSocialMedia && (
        <div className="mb-6">
          <div 
            className="p-3 bg-gray-800 rounded-lg flex items-center cursor-pointer"
            onClick={() => setShowSocialMediaOptions(!showSocialMediaOptions)}
          >
            <Share size={18} className="text-amber-400 mr-2" />
            <span>Compartilhar nas redes sociais oficiais</span>
            <button 
              className={`ml-auto w-6 h-6 rounded-md flex items-center justify-center ${
                postToSocialMedia ? 'bg-amber-500 text-black' : 'bg-gray-700 text-gray-300'
              }`}
              onClick={(e) => {
                e.stopPropagation();
                setPostToSocialMedia(!postToSocialMedia);
              }}
            >
              {postToSocialMedia && <Check size={14} />}
            </button>
          </div>
          
          {showSocialMediaOptions && (
            <div className="mt-2 ml-6 text-sm text-gray-400">
              <p>Disponível em: {municipality.socialAccounts.join(', ')}</p>
              <p className="mt-1">
                Uma postagem anônima será feita nas redes sociais da prefeitura para 
                aumentar a visibilidade do problema.
              </p>
            </div>
          )}
        </div>
      )}
      
      <div className="mt-6 flex justify-between">
        <button 
          onClick={() => setStep(2)}
          className="px-4 py-2 text-gray-400 hover:text-white"
        >
          Voltar
        </button>
        
        <button 
          onClick={() => setStep(4)}
          className="px-6 py-2 rounded-lg font-medium bg-amber-500 text-black"
        >
          Próximo
        </button>
      </div>
    </div>
  );
  
  const renderConfirmation = () => (
    <div>
      <h3 className="text-lg font-bold text-center mb-4">Confirmar envio</h3>
      
      <div className="bg-gray-800 rounded-lg p-4 mb-6">
        <div className="flex items-start mb-4">
          <div className="mr-3 text-2xl mt-1">
            {reportTypes.find(t => t.id === reportType)?.icon}
          </div>
          <div>
            <h4 className="font-medium text-amber-400">
              {reportTypes.find(t => t.id === reportType)?.label}
            </h4>
            <p className="text-sm text-gray-300 mt-1">{description}</p>
          </div>
        </div>
        
        {photos.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Fotos:</h4>
            <div className="flex space-x-2">
              {photos.map(photo => (
                <img 
                  key={photo.id} 
                  src={photo.thumbnail} 
                  alt="Miniatura" 
                  className="w-16 h-16 object-cover rounded-md"
                />
              ))}
            </div>
          </div>
        )}
        
        <div className="border-t border-gray-700 pt-3 mt-3">
          <div className="flex items-center text-sm text-gray-400">
            <MapPin size={14} className="mr-1" />
            <span>{municipality?.name}, {municipality?.country}</span>
          </div>
          
          {postToSocialMedia && (
            <div className="flex items-center text-sm text-gray-400 mt-2">
              <Share size={14} className="mr-1" />
              <span>Será compartilhado nas redes sociais</span>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-amber-500 bg-opacity-20 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Info size={20} className="text-amber-500 mr-2 mt-1" />
          <div className="text-sm text-amber-200">
            <p>Sua denúncia será enviada para a prefeitura de {municipality?.name}.</p>
            <p className="mt-1">Você receberá um número de protocolo para acompanhamento.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-6 flex justify-between">
        <button 
          onClick={() => setStep(3)}
          className="px-4 py-2 text-gray-400 hover:text-white"
        >
          Voltar
        </button>
        
        <button 
          onClick={handleSubmit}
          disabled={uploading}
          className={`px-6 py-2 rounded-lg font-medium ${
            uploading 
              ? 'bg-gray-700 text-gray-400 cursor-not-allowed' 
              : 'bg-amber-500 text-black'
          }`}
        >
          {uploading ? (
            <span className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-black mr-2"></div>
              Enviando...
            </span>
          ) : 'Enviar Denúncia'}
        </button>
      </div>
    </div>
  );
  
  // Renderização principal
  return (
    <div className="w-full max-w-lg bg-gray-900 text-white rounded-lg shadow-lg p-6">
      {renderStepIndicator()}
      
      {step === 1 && renderTypeSelection()}
      {step === 2 && renderDetailsForm()}
      {step === 3 && renderPhotoUpload()}
      {step === 4 && renderConfirmation()}
    </div>
  );
};

// Componente para visualizar o status de uma denúncia
const InfrastructureReportStatus = ({ report }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'SUBMITTED': return 'bg-blue-500';
      case 'RECEIVED': return 'bg-indigo-500';
      case 'IN_ANALYSIS': return 'bg-yellow-500';
      case 'IN_PROGRESS': return 'bg-orange-500';
      case 'RESOLVED': return 'bg-green-500';
      case 'REJECTED': return 'bg-red-500';
      case 'DUPLICATE': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };
  
  const getStatusLabel = (status) => {
    switch (status) {
      case 'SUBMITTED': return 'Enviada';
      case 'RECEIVED': return 'Recebida';
      case 'IN_ANALYSIS': return 'Em análise';
      case 'IN_PROGRESS': return 'Em andamento';
      case 'RESOLVED': return 'Resolvida';
      case 'REJECTED': return 'Rejeitada';
      case 'DUPLICATE': return 'Duplicada';
      default: return 'Desconhecido';
    }
  };
  
  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-bold text-lg">{report.description || "Denúncia"}</h3>
          <div className="flex items-center text-sm text-gray-400 mt-1">
            <MapPin size={14} className="mr-1" />
            <span>{report.municipalityName}</span>
          </div>
        </div>
        
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(report.status)}`}>
          {getStatusLabel(report.status)}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-700 p-3 rounded-lg">
          <div className="text-xs text-gray-400 mb-1">Protocolo</div>
          <div className="flex items-center">
            <Clipboard size={16} className="text-amber-400 mr-2" />
            <span className="font-medium">{report.protocolNumber || "Pendente"}</span>
          </div>
        </div>
        
        <div className="bg-gray-700 p-3 rounded-lg">
          <div className="text-xs text-gray-400 mb-1">Enviada em</div>
          <div className="flex items-center">
            <Clock size={16} className="text-amber-400 mr-2" />
            <span className="font-medium">{new Date(report.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
      
      {report.photoUrls && report.photoUrls.length > 0 && (
        <div className="flex space-x-2 mb-4">
          {report.photoUrls.map((url, index) => (
            <img 
              key={index}
              src={url}
              alt={`Foto ${index + 1}`}
              className="w-20 h-20 object-cover rounded-md"
            />
          ))}
        </div>
      )}
      
      <div className="border-t border-gray-700 pt-3 mt-3 flex justify-between">
        <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
          <Phone size={16} className="mr-1" />
          <span>Contatar</span>
        </button>
        
        <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
          <MessageCircle size={16} className="mr-1" />
          <span>Atualização</span>
        </button>
        
        <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
          <Share size={16} className="mr-1" />
          <span>Compartilhar</span>
        </button>
      </div>
    </div>
  );
};

export default InfrastructureReportComponent;