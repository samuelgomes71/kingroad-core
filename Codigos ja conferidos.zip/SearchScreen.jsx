import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList } from 'react-native';

// Lista de exemplo de destinos
const EXAMPLE_DESTINATIONS = [
  { id: 'KINSPX', name: 'KingRoad', address: 'Av. Paulista, 1000, São Paulo', coordinates: { latitude: -23.5559, longitude: -46.6615 } },
  { id: 'TRARJX', name: 'Transportes Rápidos', address: 'Rua Copacabana, 500, Rio de Janeiro', coordinates: { latitude: -22.9699, longitude: -43.1823 } },
  { id: 'LOGFOR', name: 'Logística Forte', address: 'Av. Beira Mar, 1200, Fortaleza', coordinates: { latitude: -3.7304, longitude: -38.5217 } }
];

const SearchScreen = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [results, setResults] = useState([]);

  // Função de busca simples
  const handleSearch = (text) => {
    setSearchText(text);
    
    if (text.length > 2) {
      // Filtrar resultados baseado no texto de busca
      const filteredResults = EXAMPLE_DESTINATIONS.filter(
        item => 
          item.id.toLowerCase().includes(text.toLowerCase()) ||
          item.name.toLowerCase().includes(text.toLowerCase()) ||
          item.address.toLowerCase().includes(text.toLowerCase())
      );
      setResults(filteredResults);
    } else {
      setResults([]);
    }
  };

  // Função para selecionar um destino e navegar para confirmação
  const handleSelectDestination = (destination) => {
    navigation.navigate('RouteConfirmation', {
      destination: destination,
      customerID: destination.id,
      searchMethod: 'customerid'
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Buscar Destino</Text>
      
      <View style={styles.searchBox}>
        <TextInput
          style={styles.input}
          placeholder="Digite um Customer ID, nome ou endereço..."
          value={searchText}
          onChangeText={handleSearch}
        />
      </View>
      
      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.resultItem}
            onPress={() => handleSelectDestination(item)}
          >
            <Text style={styles.resultId}>{item.id}</Text>
            <Text style={styles.resultName}>{item.name}</Text>
            <Text style={styles.resultAddress}>{item.address}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={() => (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {searchText.length > 2 
                ? 'Nenhum resultado encontrado.' 
                : 'Digite pelo menos 3 caracteres para buscar.'}
            </Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 16
  },
  searchBox: {
    backgroundColor: '#1f1f1f',
    borderRadius: 8,
    marginBottom: 16
  },
  input: {
    color: '#fff',
    padding: 12,
    fontSize: 16
  },
  resultItem: {
    backgroundColor: '#1f1f1f',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8
  },
  resultId: {
    color: '#f59e0b',
    fontWeight: 'bold',
    fontSize: 16
  },
  resultName: {
    color: '#fff',
    fontSize: 16,
    marginVertical: 4
  },
  resultAddress: {
    color: '#9ca3af',
    fontSize: 14
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center'
  },
  emptyText: {
    color: '#9ca3af',
    fontSize: 16,
    textAlign: 'center'
  }
});

export default SearchScreen;