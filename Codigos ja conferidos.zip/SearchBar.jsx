import React from 'react';
import { View, TextInput, StyleSheet, FlatList, Text, TouchableOpacity } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

/**
 * SearchBar - Componente de busca com suporte a destinos online/offline para o KingRoad
 */
const SearchBar = ({
  searchQuery,
  setSearchQuery,
  searchResults,
  onSearch,
  onSelectDestination,
  isDarkMode
}) => {
  return (
    <View style={styles.container}>
      {/* Barra de pesquisa */}
      <View style={[styles.searchBar, isDarkMode && styles.searchBarDark]}>
        <FontAwesomeIcon icon={faSearch} size={18} color={isDarkMode ? '#FFF' : '#000'} />
        <TextInput
          placeholder="Buscar destino..."
          placeholderTextColor={isDarkMode ? '#CCC' : '#888'}
          style={[styles.input, isDarkMode && styles.inputDark]}
          value={searchQuery}
          onChangeText={text => onSearch(text)}
        />
      </View>

      {/* Resultados da busca */}
      {searchResults.length > 0 && (
        <FlatList
          data={searchResults}
          keyExtractor={(item) => item.id}
          style={styles.resultsList}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.resultItem}
              onPress={() => onSelectDestination(item)}
            >
              <Text style={[styles.resultText, isDarkMode && styles.resultTextDark]}>{item.name}</Text>
              <Text style={[styles.resultSubText, isDarkMode && styles.resultTextDark]}>{item.address}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 40,
    left: 20,
    right: 20,
    zIndex: 10
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4
  },
  searchBarDark: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)'
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: '#000'
  },
  inputDark: {
    color: '#FFF'
  },
  resultsList: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: 10,
    marginTop: 5,
    maxHeight: 200
  },
  resultItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE'
  },
  resultText: {
    fontSize: 16,
    color: '#333'
  },
  resultSubText: {
    fontSize: 12,
    color: '#666'
  },
  resultTextDark: {
    color: '#FFF'
  }
});

export default SearchBar;