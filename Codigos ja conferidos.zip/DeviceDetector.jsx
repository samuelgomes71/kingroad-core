import React, { useState, useEffect } from 'react';

const DeviceDetector = ({ onDeviceDetected }) => {
  const [deviceInfo, setDeviceInfo] = useState({
    screenSize: '',
    deviceType: '',
    splashScreenVersion: '',
    isDetecting: true
  });

  useEffect(() => {
    // Detecção do dispositivo
    const detectDevice = () => {
      // Obter dimensões da tela
      const width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      const height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
      
      // Obter informações do user agent
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      
      // Determinar tipo de dispositivo
      let deviceType = 'desktop';
      if (/android/i.test(userAgent)) {
        deviceType = 'android';
      } else if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        deviceType = 'ios';
      } else if (/Windows/.test(userAgent)) {
        deviceType = 'windows';
      }
      
      // Tentar obter DPI mais preciso
      let dpi = 96; // Valor padrão
      
      // Alguns navegadores modernos oferecem informações mais precisas
      if (window.devicePixelRatio) {
        dpi = 96 * window.devicePixelRatio;
      }
      
      // Diagonal em polegadas (aproximação baseada em DPI)
      const diagonalPixels = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
      const diagonalInches = diagonalPixels / dpi;
      
      // Categorizar por tamanho de tela
      let screenSize;
      let splashVersion;
      
      if (diagonalInches < 5) {
        screenSize = 'extra-small'; // < 5 polegadas
        splashVersion = 'splash-xs';
      } else if (diagonalInches >= 5 && diagonalInches < 7) {
        screenSize = 'small'; // 5-7 polegadas (maioria dos smartphones)
        splashVersion = 'splash-sm';
      } else if (diagonalInches >= 7 && diagonalInches < 9) {
        screenSize = 'medium'; // 7-9 polegadas (tablets pequenos)
        splashVersion = 'splash-md';
      } else if (diagonalInches >= 9 && diagonalInches < 11) {
        screenSize = 'large'; // 9-11 polegadas (tablets médios)
        splashVersion = 'splash-lg';
      } else {
        screenSize = 'extra-large'; // 11+ polegadas (tablets grandes)
        splashVersion = 'splash-xl';
      }
      
      // Para garantir que o logo correto também seja baixado
      const logoVersion = `logo-${splashVersion.split('-')[1]}`;
      
      // Atualizar o estado
      const detectedInfo = {
        screenSize,
        deviceType,
        splashScreenVersion: splashVersion,
        logoVersion,
        width,
        height,
        dpi,
        diagonalInches: diagonalInches.toFixed(1)
      };
      
      setDeviceInfo({
        ...detectedInfo,
        isDetecting: false
      });
      
      // Passar informações para o componente pai automaticamente
      if (onDeviceDetected) {
        // Pequeno atraso para simular o processo de detecção
        setTimeout(() => {
          onDeviceDetected(detectedInfo);
        }, 1500);
      }
    };
    
    // Executar a detecção automaticamente
    detectDevice();
    
    // Adicionar listener para redimensionamento da janela
    window.addEventListener('resize', detectDevice);
    
    // Limpar listener ao desmontar o componente
    return () => window.removeEventListener('resize', detectDevice);
  }, [onDeviceDetected]);

  // Este componente agora pode ser configurado para renderizar ou não informações visuais
  // Para manter um comportamento consistente com o restante do sistema, 
  // estamos retornando null para que ele funcione apenas como um detector
  return null;
};

export default DeviceDetector;