import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// Main Activity for the Navigation Screen
class NavigationActivity : AppCompatActivity() {

    // Define colors for day/night mode
    private val DAY_BG_COLOR = Color.parseColor("#F5F0E1") // Beige color for day mode
    private val NIGHT_BG_COLOR = Color.parseColor("#121212") // Dark color for night mode
    
    // POI types
    enum class PoiType {
        TRUCK_STOP, REST_AREA, TOLL, TOLL_BRIDGE, ROADWORK, 
        ACCIDENT, TRAFFIC_CONTROL, WEIGHT_STATION
    }
    
    // POI data class with position information
    data class PointOfInterest(
        val type: PoiType,
        val name: String,
        val distance: Float, // in km
        val isOnSameDirection: Boolean // true if on same side of road, false if opposite
    )

    private lateinit var mapView: FrameLayout
    private lateinit var rightSidebar: LinearLayout
    private lateinit var poiRecyclerView: RecyclerView
    private lateinit var cancelRouteButton: ImageButton
    private var isDayMode = true
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation)
        
        // Initialize UI components
        mapView = findViewById(R.id.map_view)
        rightSidebar = findViewById(R.id.right_sidebar)
        poiRecyclerView = findViewById(R.id.poi_recycler_view)
        cancelRouteButton = findViewById(R.id.cancel_route_button)
        
        // Set the UI mode based on time of day (can be determined by system or GPS)
        setDayNightMode(isDayMode)
        
        // Setup POI sidebar recycler view
        setupPoiSidebar()
        
        // Setup cancel route button without confirmation
        cancelRouteButton.setOnClickListener {
            cancelNavigationRoute()
        }
    }
    
    private fun setDayNightMode(isDay: Boolean) {
        isDayMode = isDay
        
        if (isDay) {
            // Set day mode colors
            mapView.setBackgroundColor(DAY_BG_COLOR)
            rightSidebar.setBackgroundColor(Color.parseColor("#FFFFFF"))
        } else {
            // Set night mode colors
            mapView.setBackgroundColor(NIGHT_BG_COLOR)
            rightSidebar.setBackgroundColor(Color.parseColor("#333333"))
        }
    }
    
    private fun setupPoiSidebar() {
        // Sample POI data - in a real app this would come from your navigation system
        val pois = listOf(
            PointOfInterest(PoiType.TRUCK_STOP, "Big Rig Stop", 29.0f, true),
            PointOfInterest(PoiType.REST_AREA, "Highway Rest", 11.0f, true),
            PointOfInterest(PoiType.WEIGHT_STATION, "County Weigh Station", 5.7f, true),
            PointOfInterest(PoiType.TOLL, "River Toll", 0.7f, false)
        )
        
        poiRecyclerView.layoutManager = LinearLayoutManager(this)
        poiRecyclerView.adapter = PoiAdapter(this, pois, isDayMode)
    }
    
    private fun cancelNavigationRoute() {
        // Immediately cancel navigation without confirmation
        // In a real implementation, this would stop navigation and return to the previous screen
        // or to the map overview mode
        finish() // For demo purposes, we just finish the activity
    }
    
    // Adapter for the POI sidebar
    inner class PoiAdapter(
        private val context: Context,
        private val pois: List<PointOfInterest>,
        private val isDayMode: Boolean
    ) : RecyclerView.Adapter<PoiAdapter.PoiViewHolder>() {
        
        inner class PoiViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val poiIcon: ImageView = view.findViewById(R.id.poi_icon)
            val poiDistance: TextView = view.findViewById(R.id.poi_distance)
            val poiContainer: ConstraintLayout = view.findViewById(R.id.poi_container)
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PoiViewHolder {
            val view = LayoutInflater.from(context)
                .inflate(R.layout.item_poi, parent, false)
            return PoiViewHolder(view)
        }
        
        override fun getItemCount() = pois.size
        
        override fun onBindViewHolder(holder: PoiViewHolder, position: Int) {
            val poi = pois[position]
            
            // Set POI icon based on type
            holder.poiIcon.setImageResource(getPoiIconResource(poi.type))
            
            // Set distance text
            holder.poiDistance.text = "${poi.distance} km"
            
            // Position the POI indicator based on direction (same or opposite side)
            val params = holder.poiContainer.layoutParams as FrameLayout.LayoutParams
            if (poi.isOnSameDirection) {
                // Place on right side of sidebar
                params.gravity = Gravity.END
            } else {
                // Place on left side of sidebar
                params.gravity = Gravity.START
            }
            holder.poiContainer.layoutParams = params
            
            // Set colors based on day/night mode
            if (isDayMode) {
                holder.poiDistance.setTextColor(Color.BLACK)
            } else {
                holder.poiDistance.setTextColor(Color.WHITE)
            }
        }
        
        private fun getPoiIconResource(type: PoiType): Int {
            return when (type) {
                PoiType.TRUCK_STOP -> R.drawable.ic_truck_stop
                PoiType.REST_AREA -> R.drawable.ic_rest_area
                PoiType.TOLL -> R.drawable.ic_toll
                PoiType.TOLL_BRIDGE -> R.drawable.ic_toll_bridge
                PoiType.ROADWORK -> R.drawable.ic_roadwork
                PoiType.ACCIDENT -> R.drawable.ic_accident
                PoiType.TRAFFIC_CONTROL -> R.drawable.ic_traffic_control
                PoiType.WEIGHT_STATION -> R.drawable.ic_weight_station
            }
        }
    }
}