import React, { useState, useEffect, useCallback } from 'react';
import { debounce } from 'lodash';

const FoodTruckPOILayer = () => {
  const [foodTrucks, setFoodTrucks] = useState([
    { id: 1, name: "Dave's English Breakfast", latitude: 51.509865, longitude: -0.118092, verifiedByCommunity: true, userRating: 4.8 },
    { id: 2, name: "Celtic Catering", latitude: 51.520847, longitude: -0.195521, verifiedByCommunity: true, userRating: 4.5 },
    { id: 3, name: "Highway Delights", latitude: 51.503491, longitude: -0.127182, verifiedByCommunity: false, userRating: 3.9 },
    { id: 4, name: "Irish Coffee Stop", latitude: 51.536694, longitude: -0.174008, verifiedByCommunity: true, userRating: 4.7 }
  ]);
  const [selectedFoodTruck, setSelectedFoodTruck] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    country: 'all',
    parkingSpace: false,
    minRating: 0,
    cuisineType: [],
    openNow: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isVisible, setIsVisible] = useState(true);

  // Simulação de função para buscar food trucks
  const fetchFoodTrucksInBounds = useCallback(
    debounce((south, north, west, east, filters) => {
      setIsLoading(true);
      // Simulação de chamada API
      setTimeout(() => {
        console.log(`Buscando food trucks nos limites: ${south}, ${north}, ${west}, ${east}`);
        console.log('Filtros:', filters);
        setIsLoading(false);
      }, 800);
    }, 500),
    [filters]
  );

  // Manipula a seleção de um food truck
  const handleFoodTruckSelect = (foodTruck) => {
    setSelectedFoodTruck(foodTruck.id === selectedFoodTruck ? null : foodTruck.id);
  };

  // Atualiza os filtros
  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    setShowFilters(false);
  };

  // Interface de demonstração
  return (
    <div className="relative w-full h-screen bg-gray-900 overflow-hidden">
      {/* Fundo simulando o mapa */}
      <div className="absolute inset-0 bg-gray-800">
        <img 
          src="/api/placeholder/800/600" 
          alt="Map Background" 
          className="w-full h-full object-cover opacity-50"
        />
      </div>

      {/* Barra de filtros */}
      <div className="absolute top-4 left-4 right-4 flex justify-between items-center bg-gray-900 bg-opacity-80 rounded-lg p-3 z-10">
        <h2 className="text-xl font-bold text-yellow-500">Food Trucks</h2>
        <button className="flex items-center bg-gray-800 px-3 py-2 rounded-md">
          <span className="text-yellow-500 mr-2">Filtros</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
          </svg>
        </button>
      </div>

      {/* POIs de Food Trucks no mapa */}
      {foodTrucks.map(truck => (
        <div 
          key={truck.id}
          className={`absolute p-2 rounded-full cursor-pointer transform transition-all duration-300 ${
            selectedFoodTruck === truck.id ? 'scale-125 z-20' : 'z-10'
          }`}
          style={{
            top: `${40 + Math.random() * 40}%`,
            left: `${20 + Math.random() * 60}%`,
            backgroundColor: truck.verifiedByCommunity ? '#1E293B' : '#1A202C',
            border: truck.verifiedByCommunity ? '2px solid #4CAF50' : '2px solid #FFD700',
            boxShadow: '0 0 10px rgba(0,0,0,0.5)'
          }}
          onClick={() => handleFoodTruckSelect(truck)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9z"/>
            <path d="M3 9l2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9"/>
            <path d="M6 13h.01"/>
            <path d="M18 13h.01"/>
          </svg>
          
          {/* Badge para food trucks bem avaliados */}
          {truck.userRating > 4.5 && (
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-yellow-600 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="#FFD700" stroke="none">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
              </svg>
            </div>
          )}
        </div>
      ))}

      {/* Detalhes do food truck selecionado */}
      {selectedFoodTruck && (
        <div className="absolute bottom-4 left-4 right-4 bg-gray-900 rounded-lg p-4 border border-yellow-600 shadow-lg">
          {foodTrucks.filter(truck => truck.id === selectedFoodTruck).map(truck => (
            <div key={`detail-${truck.id}`}>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-bold text-white">{truck.name}</h3>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#FFD700" stroke="none" className="mr-1">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                  </svg>
                  <span className="text-yellow-500">{truck.userRating.toFixed(1)}</span>
                </div>
              </div>
              
              <div className="mb-3 text-gray-300 text-sm">
                <div className="flex items-center mb-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                  </svg>
                  <span>Aberto agora (06:00 - 14:00)</span>
                </div>
                
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFD700" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                    <circle cx="12" cy="10" r="3"/>
                  </svg>
                  <span>A1 Northbound, Junction 15</span>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white py-2 px-4 rounded-md text-sm flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <polygon points="3 11 22 2 13 21 11 13 3 11"/>
                  </svg>
                  Navegar
                </button>
                <button className="flex-1 border border-gray-600 text-gray-300 py-2 px-4 rounded-md text-sm flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                    <polyline points="9 22 9 12 15 12 15 22"/>
                  </svg>
                  Adicionar parada
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Indicador de carregamento */}
      {isLoading && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-gray-900 bg-opacity-80 px-4 py-2 rounded-full">
          <p className="text-yellow-500">Carregando food trucks...</p>
        </div>
      )}
    </div>
  );
};

export default FoodTruckPOILayer;