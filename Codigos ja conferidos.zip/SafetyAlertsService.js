/**
 * SafetyAlertsService.js
 * Sistema de alertas de segurança para o KingRoad
 * Implementa alertas ativos para diferentes regiões, com versões nacionais e internacionais
 */

import translationsService from './TranslationsService';

class SafetyAlertsService {
  constructor() {
    this.alertTypes = {
      // Alertas de tráfego
      traffic: {
        priority: 'high',
        sound: 'traffic_alert.mp3',
        icon: 'traffic_alert',
        color: '#FF5722',
        subtypes: ['congestion', 'accident', 'road_closed', 'construction']
      },
      // Alertas de condições climáticas
      weather: {
        priority: 'high',
        sound: 'weather_alert.mp3',
        icon: 'weather_alert',
        color: '#2196F3',
        subtypes: ['rain', 'snow', 'fog', 'ice', 'flooding', 'wind']
      },
      // Alertas de velocidade
      speed: {
        priority: 'medium',
        sound: 'speed_alert.mp3',
        icon: 'speed_alert',
        color: '#FFC107',
        subtypes: ['speed_camera', 'speed_limit_change', 'school_zone']
      },
      // Alertas de fiscalização
      enforcement: {
        priority: 'medium',
        sound: 'enforcement_alert.mp3',
        icon: 'enforcement_alert',
        color: '#9C27B0',
        subtypes: ['police', 'weighing_station', 'customs', 'document_check']
      },
      // Alertas de risco
      hazard: {
        priority: 'high',
        sound: 'hazard_alert.mp3', 
        icon: 'hazard_alert',
        color: '#F44336',
        subtypes: ['sharp_curve', 'steep_grade', 'falling_rocks', 'crossing', 'narrow_road']
      },
      // Alertas de serviços
      service: {
        priority: 'low',
        sound: 'service_alert.mp3',
        icon: 'service_alert',
        color: '#4CAF50',
        subtypes: ['rest_area', 'fuel_station', 'restaurant', 'truck_service', 'parking']
      },
      // Alertas de segurança pública
      security: {
        priority: 'high',
        sound: 'security_alert.mp3',
        icon: 'security_alert',
        color: '#E91E63',
        subtypes: ['theft_risk', 'hijacking_risk', 'unsafe_area', 'protest']
      }
    };
    
    this.activeAlerts = [];
    this.alertListeners = [];
    this.maxHistorySize = 100;
    this.alertHistory = [];
    this.userReportedAlerts = [];
    this.alertUpdateInterval = null;
    this.isAlertSystemActive = true;
    this.userSettings = {
      showAllAlertTypes: true,
      enabledAlertTypes: Object.keys(this.alertTypes),
      alertRadius: 10000, // metros (10 km)
      soundEnabled: true,
      showVisualAlert: true,
      voiceAlerts: true,
      autoReportAccidents: true,
      hideExpiredAlerts: true,
      filterDuplicates: true,
      maxAlertAgeDays: 30, // dias
      // Configurações específicas por tipo de alerta
      typeSettings: {}
    };
    
    this.regionalSettings = new Map();
    this.currentRegion = 'GLOBAL';
    
    // Inicialização
    this._initializeRegionalSettings();
    Object.keys(this.alertTypes).forEach(type => {
      this.userSettings.typeSettings[type] = {
        enabled: true,
        sound: true,
        priority: this.alertTypes[type].priority
      };
    });
    
    // Inicia o timer para atualizações periódicas de alertas
    this._startAlertUpdates();
  }
  
  /**
   * Inicializa configurações regionais
   * @private
   */
  _initializeRegionalSettings() {
    // Configurações globais (padrão)
    this.regionalSettings.set('GLOBAL', {
      priorityAlerts: ['traffic', 'hazard', 'weather', 'security'],
      alwaysOnAlerts: ['traffic.accident', 'weather.flooding', 'security.theft_risk'],
      distanceUnits: 'km',
      voiceLanguage: 'en-US',
      enforceLocalRestrictions: true,
      defaultAlertRadius: 10000 // 10km
    });
    
    // Configurações para EUA
    this.regionalSettings.set('US', {
      priorityAlerts: ['traffic', 'hazard', 'enforcement', 'weather'],
      alwaysOnAlerts: ['traffic.accident', 'enforcement.weighing_station', 'hazard.steep_grade'],
      distanceUnits: 'mi',
      voiceLanguage: 'en-US',
      enforceLocalRestrictions: true,
      defaultAlertRadius: 8000 // 5mi (aproximadamente)
    });
    
    // Configurações para Brasil
    this.regionalSettings.set('BR', {
      priorityAlerts: ['security', 'traffic', 'hazard', 'enforcement'],
      alwaysOnAlerts: ['security.theft_risk', 'security.hijacking_risk', 'traffic.accident', 'enforcement.police'],
      distanceUnits: 'km',
      voiceLanguage: 'pt-BR',
      enforceLocalRestrictions: true,
      defaultAlertRadius: 15000 // 15km
    });
    
    // Configurações para Europa
    this.regionalSettings.set('EU', {
      priorityAlerts: ['traffic', 'speed', 'hazard', 'weather'],
      alwaysOnAlerts: ['speed.speed_camera', 'traffic.accident', 'traffic.construction'],
      distanceUnits: 'km',
      voiceLanguage: 'en-GB', // Padrão, pode mudar por país
      enforceLocalRestrictions: true,
      defaultAlertRadius: 10000 // 10km
    });
  }
  
  /**
   * Define a região atual
   * @param {string} regionCode - Código da região
   * @returns {Object} Configurações da região
   */
  setRegion(regionCode) {
    if (!regionCode || !this.regionalSettings.has(regionCode)) {
      console.warn(`Região ${regionCode} não encontrada, usando configurações globais`);
      this.currentRegion = 'GLOBAL';
    } else {
      this.currentRegion = regionCode;
    }
    
    // Atualiza raio de alerta com base na configuração regional
    const regionalSettings = this.getRegionalSettings();
    this.userSettings.alertRadius = regionalSettings.defaultAlertRadius;
    
    // Re-inicia as atualizações de alertas para aplicar as novas configurações regionais
    this._restartAlertUpdates();
    
    return regionalSettings;
  }
  
  /**
   * Obtém as configurações regionais atuais
   * @returns {Object} Configurações da região atual
   */
  getRegionalSettings() {
    return { ...this.regionalSettings.get(this.currentRegion) };
  }
  
  /**
   * Inicia atualizações de alertas
   * @private
   */
  _startAlertUpdates() {
    if (this.alertUpdateInterval) {
      clearInterval(this.alertUpdateInterval);
    }
    
    // Atualiza a cada 30 segundos por padrão
    this.alertUpdateInterval = setInterval(() => {
      this._updateAlerts();
    }, 30 * 1000);
    
    // Executa a primeira atualização imediatamente
    this._updateAlerts();
  }
  
  /**
   * Reinicia atualizações de alertas
   * @private
   */
  _restartAlertUpdates() {
    this._startAlertUpdates();
  }
  
  /**
   * Atualiza alertas baseado na posição atual
   * @private
   */
  async _updateAlerts() {
    if (!this.isAlertSystemActive) {
      return;
    }
    
    try {
      // Obter posição atual (mock)
      const currentPosition = await this._getCurrentPosition();
      
      // Busca alertas do servidor ou dados locais
      const alerts = await this._fetchAlerts(currentPosition);
      
      // Processa os novos alertas
      this._processNewAlerts(alerts);
      
    } catch (error) {
      console.error('Erro ao atualizar alertas:', error);
    }
  }
  
  /**
   * Obtém posição atual
   * @private
   * @returns {Promise<Object>} Posição atual {lat, lng}
   */
  async _getCurrentPosition() {
    // Mock - em uma implementação real, usaria GPS
    return new Promise((resolve) => {
      // Verifica se temos uma posição recente em cache
      if (this._lastPosition) {
        // Simula um pequeno movimento
        this._lastPosition = {
          lat: this._lastPosition.lat + (Math.random() - 0.5) * 0.001,
          lng: this._lastPosition.lng + (Math.random() - 0.5) * 0.001
        };
        resolve(this._lastPosition);
      } else {
        // Posição inicial fictícia (São Paulo, Brasil)
        this._lastPosition = {
          lat: -23.55 + (Math.random() - 0.5) * 0.1,
          lng: -46.63 + (Math.random() - 0.5) * 0.1
        };
        resolve(this._lastPosition);
      }
    });
  }
  
  /**
   * Busca alertas do servidor ou localmente
   * @private
   * @param {Object} position - Posição atual
   * @returns {Promise<Array>} Lista de alertas
   */
  async _fetchAlerts(position) {
    // Obtém configurações e tipos de alertas habilitados
    const settings = this.userSettings;
    const enabledTypes = settings.showAllAlertTypes ? 
      Object.keys(this.alertTypes) : settings.enabledAlertTypes;
    
    try {
      // Tenta buscar online
      const response = await fetch(`https://api.kingroad.com/alerts/nearby`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          lat: position.lat,
          lng: position.lng,
          radius: settings.alertRadius,
          types: enabledTypes,
          region: this.currentRegion,
          maxAgeDays: settings.maxAlertAgeDays
        })
      });
      
      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`);
      }
      
      const data = await response.json();
      return data.alerts;
      
    } catch (error) {
      console.warn('Erro ao buscar alertas online, usando dados offline:', error);
      
      // Fallback para alertas offline/simulados
      return this._generateSimulatedAlerts(position, enabledTypes);
    }
  }
  
  /**
   * Gera alertas simulados para demonstração
   * @private
   * @param {Object} position - Posição atual
   * @param {Array} types - Tipos de alertas habilitados
   * @returns {Array} Alertas simulados
   */
  _generateSimulatedAlerts(position, types) {
    const alerts = [];
    const count = Math.floor(Math.random() * 5) + 2; // 2-6 alertas
    const regionalSettings = this.getRegionalSettings();
    
    // Aumenta a chance de alertas prioritários
    const weightedTypes = [
      ...regionalSettings.priorityAlerts,
      ...types
    ];
    
    for (let i = 0; i < count; i++) {
      // Seleciona um tipo aleatório com maior peso para os prioritários
      const typeIndex = Math.floor(Math.random() * weightedTypes.length);
      const alertType = weightedTypes[typeIndex];
      
      // Verifica se o tipo é suportado
      if (!this.alertTypes[alertType]) {
        continue;
      }
      
      // Seleciona um subtipo aleatório
      const subtypes = this.alertTypes[alertType].subtypes;
      const subtype = subtypes[Math.floor(Math.random() * subtypes.length)];
      
      // Gera uma posição aleatória próxima
      const maxDistance = this.userSettings.alertRadius;
      const randomDistance = Math.random() * maxDistance;
      const randomAngle = Math.random() * Math.PI * 2;
      
      // Conversão aproximada de graus para km (simplificada)
      const latOffset = (randomDistance / 111000) * Math.cos(randomAngle);
      const lngOffset = (randomDistance / (111000 * Math.cos(position.lat * Math.PI / 180))) * Math.sin(randomAngle);
      
      // Cria o alerta
      const now = Date.now();
      const alert = {
        id: `alert_${now}_${i}`,
        type: alertType,
        subtype: subtype,
        position: {
          lat: position.lat + latOffset,
          lng: position.lng + lngOffset
        },
        distance: randomDistance,
        title: this._getAlertTitle(alertType, subtype),
        description: this._getAlertDescription(alertType, subtype),
        priority: this.alertTypes[alertType].priority,
        icon: this._getAlertIcon(alertType, subtype),
        color: this.alertTypes[alertType].color,
        reportCount: Math.floor(Math.random() * 10) + 1,
        createdAt: now - Math.floor(Math.random() * 24 * 60 * 60 * 1000), // Até 24h atrás
        expiresAt: now + Math.floor(Math.random() * 3 * 60 * 60 * 1000), // Expira em até 3h
        source: Math.random() > 0.7 ? 'community' : 'official', // 30% da comunidade, 70% oficial
        verified: Math.random() > 0.2, // 80% verificado
        regionSpecific: this.currentRegion !== 'GLOBAL'
      };
      
      alerts.push(alert);
    }
    
    // Adiciona sempre pelo menos um alerta dos tipos "sempre ativos" da região atual
    const alwaysOnAlerts = regionalSettings.alwaysOnAlerts;
    if (alwaysOnAlerts && alwaysOnAlerts.length > 0) {
      const alwaysOnType = alwaysOnAlerts[Math.floor(Math.random() * alwaysOnAlerts.length)];
      const [mainType, subType] = alwaysOnType.split('.');
      
      // Distância aleatória, mas um pouco mais próxima
      const randomDistance = Math.random() * (this.userSettings.alertRadius / 2);
      const randomAngle = Math.random() * Math.PI * 2;
      
      // Conversão aproximada de graus para km
      const latOffset = (randomDistance / 111000) * Math.cos(randomAngle);
      const lngOffset = (randomDistance / (111000 * Math.cos(position.lat * Math.PI / 180))) * Math.sin(randomAngle);
      
      // Cria o alerta prioritário
      const now = Date.now();
      alerts.push({
        id: `priority_alert_${now}`,
        type: mainType,
        subtype: subType,
        position: {
          lat: position.lat + latOffset,
          lng: position.lng + lngOffset
        },
        distance: randomDistance,
        title: this._getAlertTitle(mainType, subType),
        description: this._getAlertDescription(mainType, subType),
        priority: 'high', // Forçado como alta prioridade
        icon: this._getAlertIcon(mainType, subType),
        color: this.alertTypes[mainType].color,
        reportCount: Math.floor(Math.random() * 20) + 10, // 10-30 reports
        createdAt: now - Math.floor(Math.random() * 30 * 60 * 1000), // Até 30min atrás
        expiresAt: now + Math.floor(Math.random() * 3 * 60 * 60 * 1000), // Expira em até 3h
        source: 'official',
        verified: true,
        regionSpecific: true
      });
    }
    
    return alerts;
  }
  
  /**
   * Obtém título para o alerta
   * @private
   * @param {string} type - Tipo do alerta
   * @param {string} subtype - Subtipo do alerta
   * @returns {string} Título traduzido
   */
  _getAlertTitle(type, subtype) {
    return translationsService.translate(`alerts.${type}.${subtype}.title`);
  }
  
  /**
   * Obtém descrição para o alerta
   * @private
   * @param {string} type - Tipo do alerta
   * @param {string} subtype - Subtipo do alerta
   * @returns {string} Descrição traduzida
   */
  _getAlertDescription(type, subtype) {
    return translationsService.translate(`alerts.${type}.${subtype}.description`);
  }
  
  /**
   * Obtém ícone para o alerta
   * @private
   * @param {string} type - Tipo do alerta
   * @param {string} subtype - Subtipo do alerta
   * @returns {string} Caminho para o ícone
   */
  _getAlertIcon(type, subtype) {
    // Verifica se tem ícone específico para o subtipo
    const iconFolder = this.currentRegion === 'GLOBAL' ? 'standard' : this.currentRegion.toLowerCase();
    return `assets/icons/alerts/${iconFolder}/${type}_${subtype}.svg`;
  }
  
  /**
   * Processa novos alertas e notifica ouvintes
   * @private
   * @param {Array} newAlerts - Novos alertas recebidos
   */
  _processNewAlerts(newAlerts) {
    if (!newAlerts || newAlerts.length === 0) {
      return;
    }
    
    // Filtra alertas expirados se configurado
    const now = Date.now();
    let filteredAlerts = newAlerts;
    
    if (this.userSettings.hideExpiredAlerts) {
      filteredAlerts = newAlerts.filter(alert => !alert.expiresAt || alert.expiresAt > now);
    }
    
    // Filtra duplicados se configurado
    if (this.userSettings.filterDuplicates) {
      filteredAlerts = this._removeDuplicateAlerts(filteredAlerts);
    }
    
    // Ordena por proximidade e prioridade
    const sortedAlerts = this._sortAlertsByImportance(filteredAlerts);
    
    // Compara com alertas ativos atuais
    const currentIds = new Set(this.activeAlerts.map(a => a.id));
    const newActiveAlerts = [];
    const brandNewAlerts = [];
    
    for (const alert of sortedAlerts) {
      newActiveAlerts.push(alert);
      
      // Se não estava na lista ativa anterior, é um novo alerta
      if (!currentIds.has(alert.id)) {
        brandNewAlerts.push(alert);
        
        // Adiciona ao histórico
        this._addToHistory(alert);
      }
    }
    
    // Atualiza a lista de alertas ativos
    this.activeAlerts = newActiveAlerts;
    
    // Notifica sobre novos alertas, se houver algum
    if (brandNewAlerts.length > 0) {
      this._notifyNewAlerts(brandNewAlerts);
    }
    
    // Notifica sobre a atualização da lista completa
    this._notifyAlertListeners('update', this.activeAlerts);
  }
  
  /**
   * Remove alertas duplicados
   * @private
   * @param {Array} alerts - Lista de alertas
   * @returns {Array} Lista sem duplicados
   */
  _removeDuplicateAlerts(alerts) {
    // Agrupa alertas por tipo/subtipo e proximidade geográfica
    const groups = new Map();
    
    for (const alert of alerts) {
      const key = `${alert.type}_${alert.subtype}`;
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key).push(alert);
    }
    
    // Para cada grupo, mantém apenas o alerta mais recente se estiverem próximos
    const result = [];
    for (const [key, groupAlerts] of groups.entries()) {
      if (groupAlerts.length === 1) {
        result.push(groupAlerts[0]);
        continue;
      }
      
      // Ordena por data de criação (mais recente primeiro)
      const sortedByDate = [...groupAlerts].sort((a, b) => b.createdAt - a.createdAt);
      
      // Adiciona o mais recente
      const mostRecent = sortedByDate[0];
      result.push(mostRecent);
      
      // Verifica os outros para ver se estão distantes o suficiente para serem incluídos
      for (let i = 1; i < sortedByDate.length; i++) {
        const alert = sortedByDate[i];
        // Calcula distância para todos os já incluídos
        let tooClose = false;
        
        for (const includedAlert of result) {
          if (includedAlert.type === alert.type && includedAlert.subtype === alert.subtype) {
            const distance = this._calculateDistance(
              includedAlert.position,
              alert.position
            );
            
            // Se estiver muito próximo (menos de 300m), é considerado duplicado
            if (distance < 300) {
              tooClose = true;
              break;
            }
          }
        }
        
        if (!tooClose) {
          result.push(alert);
        }
      }
    }
    
    return result;
  }
  
  /**
   * Calcula distância entre dois pontos (Haversine)
   * @private
   * @param {Object} point1 - Ponto 1 {lat, lng}
   * @param {Object} point2 - Ponto 2 {lat, lng}
   * @returns {number} Distância em metros
   */
  _calculateDistance(point1, point2) {
    const R = 6371e3; // Raio da Terra em metros
    const φ1 = point1.lat * Math.PI / 180;
    const φ2 = point2.lat * Math.PI / 180;
    const Δφ = (point2.lat - point1.lat) * Math.PI / 180;
    const Δλ = (point2.lng - point1.lng) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distância em metros
  }
  
  /**
   * Ordena alertas por importância (prioridade + proximidade)
   * @private
   * @param {Array} alerts - Lista de alertas
   * @returns {Array} Alertas ordenados
   */
  _sortAlertsByImportance(alerts) {
    // Define valores numéricos para prioridades
    const priorityValues = {
      high: 3,
      medium: 2,
      low: 1
    };
    
    // Copia os alertas para não modificar o original
    return [...alerts].sort((a, b) => {
      // Prioridade é o fator principal
      const priorityDiff = priorityValues[b.priority] - priorityValues[a.priority];
      if (priorityDiff !== 0) {
        return priorityDiff;
      }
      
      // Em caso de mesma prioridade, ordena por distância
      return a.distance - b.distance;
    });
  }
  
  /**
   * Adiciona alerta ao histórico
   * @private
   * @param {Object} alert - Alerta a ser adicionado
   */
  _addToHistory(alert) {
    // Adiciona ao início da lista
    this.alertHistory.unshift({
      ...alert,
      seenAt: Date.now()
    });
    
    // Mantém o tamanho máximo do histórico
    if (this.alertHistory.length > this.maxHistorySize) {
      this.alertHistory = this.alertHistory.slice(0, this.maxHistorySize);
    }
  }
  
  /**
   * Notifica sobre novos alertas
   * @private
   * @param {Array} newAlerts - Novos alertas
   */
  _notifyNewAlerts(newAlerts) {
    if (!newAlerts || newAlerts.length === 0) {
      return;
    }
    
    // Notifica cada alerta individualmente
    for (const alert of newAlerts) {
      // Verifica se o alerta deve ter som
      const enableSound = this.userSettings.soundEnabled && 
                         this.userSettings.typeSettings[alert.type]?.sound !== false;
      
      // Verifica se deve ter alerta visual
      const enableVisual = this.userSettings.showVisualAlert;
      
      // Verifica se deve ter alerta por voz
      const enableVoice = this.userSettings.voiceAlerts;
      
      // Emite evento para notificação
      this._notifyAlertListeners('new', alert, {
        sound: enableSound ? this.alertTypes[alert.type]?.sound : null,
        visual: enableVisual,
        voice: enableVoice
      });
    }
  }
  
  /**
   * Notifica ouvintes de alertas
   * @private
   * @param {string} event - Tipo de evento
   * @param {Object|Array} data - Dados do evento
   * @param {Object} options - Opções adicionais
   */
  _notifyAlertListeners(event, data, options = {}) {
    // Notifica todos os ouvintes registrados
    for (const listener of this.alertListeners) {
      try {
        listener(event, data, options);
      } catch (error) {
        console.error('Erro ao notificar ouvinte de alertas:', error);
      }
    }
    
    // Emite evento para a UI (mock)
    if (typeof window !== 'undefined' && window.dispatchEvent) {
      window.dispatchEvent(new CustomEvent(`kingroad:alert_${event}`, {
        detail: { data, options }
      }));
    }
  }
  
  /**
   * Registra ouvinte para notificações de alertas
   * @param {Function} listener - Função callback
   * @returns {Function} Função para remover o ouvinte
   */
  addAlertListener(listener) {
    if (typeof listener !== 'function') {
      throw new Error('Ouvinte de alertas deve ser uma função');
    }
    
    this.alertListeners.push(listener);
    
    // Retorna função para remover o ouvinte
    return () => {
      this.removeAlertListener(listener);
    };
  }
  
  /**
   * Remove um ouvinte de alertas
   * @param {Function} listener - Ouvinte a ser removido
   */
  removeAlertListener(listener) {
    this.alertListeners = this.alertListeners.filter(l => l !== listener);
  }
  
  /**
   * Obtém todos os alertas ativos
   * @returns {Array} Lista de alertas ativos
   */
  getActiveAlerts() {
    return [...this.activeAlerts];
  }
  
  /**
   * Obtém os alertas de maior prioridade
   * @param {number} limit - Limite de alertas
   * @returns {Array} Lista de alertas prioritários
   */
  getPriorityAlerts(limit = 3) {
    return this.activeAlerts.slice(0, limit);
  }
  
  /**
   * Obtém o histórico de alertas
   * @param {Object} options - Opções de filtragem
   * @returns {Array} Histórico de alertas
   */
  getAlertHistory(options = {}) {
    let history = [...this.alertHistory];
    
    // Filtra por tipo, se especificado
    if (options.type) {
      history = history.filter(alert => alert.type === options.type);
    }
    
    // Filtra por subtipo, se especificado
    if (options.subtype) {
      history = history.filter(alert => alert.subtype === options.subtype);
    }
    
    // Filtra por idade, se especificado
    if (options.maxAgeDays) {
      const cutoff = Date.now() - (options.maxAgeDays * 24 * 60 * 60 * 1000);
      history = history.filter(alert => alert.seenAt >= cutoff);
    }
    
    // Aplica limite, se especificado
    if (options.limit && options.limit > 0) {
      history = history.slice(0, options.limit);
    }
    
    return history;
  }
  
  /**
   * Ativa ou desativa o sistema de alertas
   * @param {boolean} active - Estado de ativação
   */
  setAlertSystemActive(active) {
    this.isAlertSystemActive = active;
    
    if (active) {
      this._restartAlertUpdates();
    } else if (this.alertUpdateInterval) {
      clearInterval(this.alertUpdateInterval);
      this.alertUpdateInterval = null;
    }
    
    return this.isAlertSystemActive;
  }
  
  /**
   * Atualiza as configurações do usuário
   * @param {Object} settings - Novas configurações
   * @returns {Object} Configurações atualizadas
   */
  updateSettings(settings) {
    // Atualiza apenas os campos fornecidos
    this.userSettings = {
      ...this.userSettings,
      ...settings
    };
    
    // Se alterou os tipos de alertas habilitados, reinicia as atualizações
    if (settings.enabledAlertTypes || settings.showAllAlertTypes !== undefined) {
      this._restartAlertUpdates();
    }
    
    return { ...this.userSettings };
  }
  
  /**
   * Reporta um novo alerta pelo usuário
   * @param {Object} alertData - Dados do alerta
   * @returns {Promise<Object>} Alerta criado
   */
  async reportAlert(alertData) {
    if (!alertData || !alertData.type || !alertData.subtype || !alertData.position) {
      throw new Error('Dados insuficientes para reportar alerta');
    }
    
    try {
      // Em uma implementação real, enviaria para o servidor
      // Simulação para demonstração
      const now = Date.now();
      
      // Cria o novo alerta
      const newAlert = {
        id: `user_report_${now}`,
        type: alertData.type,
        subtype: alertData.subtype,
        position: alertData.position,
        distance: alertData.distance || 0,
        title: alertData.title || this._getAlertTitle(alertData.type, alertData.subtype),
        description: alertData.description || this._getAlertDescription(alertData.type, alertData.subtype),
        priority: alertData.priority || this.alertTypes[alertData.type]?.priority || 'medium',
        icon: this._getAlertIcon(alertData.type, alertData.subtype),
        color: this.alertTypes[alertData.type]?.color,
        reportCount: 1,
        createdAt: now,
        expiresAt: now + (alertData.duration || 3600000), // 1h por padrão
        source: 'community',
        verified: false,
        regionSpecific: true,
        reporter: {
          isCurrentUser: true,
          timestamp: now
        }
      };
      
      // Adiciona aos alertas reportados pelo usuário
      this.userReportedAlerts.unshift(newAlert);
      
      // Mantém apenas os últimos 50 alertas reportados
      if (this.userReportedAlerts.length > 50) {
        this.userReportedAlerts = this.userReportedAlerts.slice(0, 50);
      }
      
      // Adiciona aos alertas ativos
      this.activeAlerts.unshift(newAlert);
      this._sortAlertsByImportance(this.activeAlerts);
      
      // Notifica sobre a atualização da lista
      this._notifyAlertListeners('update', this.activeAlerts);
      
      // Em uma implementação real, enviaria para o servidor
      // Simulação de envio bem-sucedido
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(newAlert);
        }, 500);
      });
    } catch (error) {
      console.error('Erro ao reportar alerta:', error);
      throw error;
    }
  }
  
  /**
   * Obtém os alertas reportados pelo usuário
   * @param {Object} options - Opções de filtragem
   * @returns {Array} Alertas reportados
   */
  getUserReportedAlerts(options = {}) {
    let reports = [...this.userReportedAlerts];
    
    // Filtra por tipo, se especificado
    if (options.type) {
      reports = reports.filter(alert => alert.type === options.type);
    }
    
    // Filtra por idade, se especificado
    if (options.maxAgeDays) {
      const cutoff = Date.now() - (options.maxAgeDays * 24 * 60 * 60 * 1000);
      reports = reports.filter(alert => alert.createdAt >= cutoff);
    }
    
    // Aplica limite, se especificado
    if (options.limit && options.limit > 0) {
      reports = reports.slice(0, options.limit);
    }
    
    return reports;
  }
  
  /**
   * Verifica e confirma um alerta existente
   * @param {string} alertId - ID do alerta
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async confirmAlert(alertId) {
    // Encontra o alerta na lista ativa
    const alertIndex = this.activeAlerts.findIndex(a => a.id === alertId);
    if (alertIndex === -1) {
      return false;
    }
    
    try {
      // Em uma implementação real, enviaria para o servidor
      // Simulação para demonstração
      const updatedAlert = {
        ...this.activeAlerts[alertIndex],
        reportCount: this.activeAlerts[alertIndex].reportCount + 1,
        confirmedByCurrentUser: true
      };
      
      // Atualiza o alerta na lista
      this.activeAlerts[alertIndex] = updatedAlert;
      
      // Notifica sobre a atualização
      this._notifyAlertListeners('update', this.activeAlerts);
      
      return true;
    } catch (error) {
      console.error('Erro ao confirmar alerta:', error);
      return false;
    }
  }
  
  /**
   * Reporta que um alerta não existe mais
   * @param {string} alertId - ID do alerta
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async reportAlertNotExists(alertId) {
    // Encontra o alerta na lista ativa
    const alertIndex = this.activeAlerts.findIndex(a => a.id === alertId);
    if (alertIndex === -1) {
      return false;
    }
    
    try {
      // Em uma implementação real, enviaria para o servidor
      // Simulação para demonstração
      const alert = this.activeAlerts[alertIndex];
      
      // Remove o alerta da lista ativa
      this.activeAlerts.splice(alertIndex, 1);
      
      // Adiciona ao histórico com marcação especial
      this._addToHistory({
        ...alert,
        reportedNotExists: true,
        reportedNotExistsAt: Date.now()
      });
      
      // Notifica sobre a atualização
      this._notifyAlertListeners('update', this.activeAlerts);
      
      return true;
    } catch (error) {
      console.error('Erro ao reportar alerta como inexistente:', error);
      return false;
    }
  }
  
  /**
   * Força uma atualização imediata dos alertas
   */
  async refreshAlerts() {
    await this._updateAlerts();
    return this.activeAlerts.length;
  }
  
  /**
   * Formata distância conforme unidade regional
   * @param {number} meters - Distância em metros
   * @returns {string} Distância formatada
   */
  formatDistance(meters) {
    const unit = this.regionalSettings.get(this.currentRegion).distanceUnits;
    
    if (unit === 'mi') {
      // Converte para milhas
      const miles = meters / 1609.34;
      
      if (miles < 0.1) {
        return `${Math.round(miles * 5280)} pés`;
      } else if (miles < 10) {
        return `${miles.toFixed(1)} mi`;
      } else {
        return `${Math.round(miles)} mi`;
      }
    } else {
      // Usa quilômetros
      if (meters < 1000) {
        return `${Math.round(meters)} m`;
      } else {
        const km = meters / 1000;
        if (km < 10) {
          return `${km.toFixed(1)} km`;
        } else {
          return `${Math.round(km)} km`;
        }
      }
    }
  }
  
  /**
   * Obtém alertas próximos a um ponto da rota
   * @param {Object} position - Posição na rota
   * @param {number} radius - Raio de busca (metros)
   * @param {Array} types - Tipos de alertas (opcional)
   * @returns {Array} Alertas encontrados
   */
  getNearbyAlerts(position, radius = 5000, types = null) {
    if (!position) {
      return [];
    }
    
    const enabledTypes = types || (this.userSettings.showAllAlertTypes ? 
      Object.keys(this.alertTypes) : this.userSettings.enabledAlertTypes);
    
    // Filtra alertas por distância e tipo
    return this.activeAlerts.filter(alert => {
      // Verifica se o tipo está habilitado
      if (!enabledTypes.includes(alert.type)) {
        return false;
      }
      
      // Calcula distância ao ponto
      const distance = this._calculateDistance(position, alert.position);
      
      // Retorna se estiver dentro do raio
      return distance <= radius;
    }).map(alert => ({
      ...alert,
      distance: this._calculateDistance(position, alert.position)
    })).sort((a, b) => a.distance - b.distance);
  }
  
  /**
   * Obtém estatísticas de alertas
   * @returns {Object} Estatísticas
   */
  getAlertStats() {
    // Conta alertas por tipo
    const typeCount = {};
    const activeCount = this.activeAlerts.length;
    const historyCount = this.alertHistory.length;
    const userReportedCount = this.userReportedAlerts.length;
    
    // Conta por tipo e prioridade
    for (const alert of this.activeAlerts) {
      if (!typeCount[alert.type]) {
        typeCount[alert.type] = {
          count: 0,
          byPriority: { high: 0, medium: 0, low: 0 }
        };
      }
      
      typeCount[alert.type].count++;
      typeCount[alert.type].byPriority[alert.priority]++;
    }
    
    return {
      activeCount,
      historyCount,
      userReportedCount,
      byType: typeCount,
      lastUpdated: Date.now()
    };
  }
}

// Exporta o serviço como singleton
const safetyAlertsService = new SafetyAlertsService();
export default safetyAlertsService;