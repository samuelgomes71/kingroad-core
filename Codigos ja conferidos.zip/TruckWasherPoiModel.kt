package com.kingroad.poi

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.*

/**
 * Tipos de lavagem de veículos
 */
enum class WasherType {
    MANUAL,
    AUTOMATIC,
    SELF_SERVICE,
    STEAM,
    HIGH_PRESSURE,
    MIXED,
    ECO_FRIENDLY
}

/**
 * Tipos de veículos suportados
 */
enum class TruckType {
    SMALL_TRUCK,    // Caminhão leve (VUC, Toco)
    MEDIUM_TRUCK,   // Caminhão médio (Truck)
    FULL_TRAILER,   // Carreta
    DOUBLE_TRAILER, // Bitrem
    TRIPLE_TRAILER, // Rodotrem
    BUS,            // Ônibus
    RV              // Motorhome/RV
}

/**
 * Redes conhecidas de lavagem de caminhões
 */
enum class WasherChain {
    BLUE_BEACON,
    LOVES_TRUCK_WASH,
    PETROBRAS_WASH,
    SHELL_WASH,
    IPIRANGA_WASH,
    TA_TRUCK_SERVICE,
    FLYING_J,
    INDEPENDENT,
    OTHER
}

/**
 * Estados de operação de uma lavagem
 */
enum class WasherStatus {
    OPEN,
    CLOSED,
    TEMPORARILY_CLOSED,
    BUSY,
    UNDER_MAINTENANCE
}

/**
 * Modelo principal para POI de lavagem de caminhões
 */
@Entity(tableName = "truck_washer_pois")
@TypeConverters(TruckWasherConverters::class)
@Serializable
data class TruckWasherPoi(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    
    // Informações básicas
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val city: String,
    val state: String,
    val country: String,
    val postalCode: String,
    val phone: String = "",
    val website: String = "",
    
    // Categorização
    val washerTypes: List<WasherType> = emptyList(),
    val truckTypes: List<TruckType> = emptyList(),
    val washerChain: WasherChain = WasherChain.INDEPENDENT,
    
    // Status e avaliações
    val status: WasherStatus = WasherStatus.OPEN,
    val rating: Float = 0.0f,
    val reviewCount: Int = 0,
    
    // Preços e horários
    val prices: WasherPrices = WasherPrices(),
    val waitTimes: WasherWaitTimes = WasherWaitTimes(),
    val operatingHours: OperatingHours = OperatingHours(),
    
    // Especificações técnicas
    val maxHeight: Float = 0.0f,  // metros
    val maxLength: Float = 0.0f,  // metros
    val maxWeight: Float = 0.0f,  // toneladas
    
    // Recursos e comodidades
    val amenities: List<String> = emptyList(),
    val services: List<String> = emptyList(),
    val photos: List<String> = emptyList(),
    
    // Metadados do sistema
    val lastUpdated: Long = System.currentTimeMillis(),
    val userReported: Boolean = false,
    val verified: Boolean = false,
    
    // Específico para modo de veículo
    val vehicleMode: String = "truck", // truck, car
    
    // Informações ecológicas
    val hasWaterRecycling: Boolean = false,
    val usesEcoProducts: Boolean = false,
    
    // Dados de visualização
    val viewCount: Int = 0,
    val favoriteCount: Int = 0
)

/**
 * Estrutura para preços das diferentes opções de serviço
 */
@Serializable
data class WasherPrices(
    val currency: String = "USD",
    val basicWash: Float = 0.0f,
    val standardWash: Float = 0.0f,
    val premiumWash: Float = 0.0f,
    val interiorCleaning: Float = 0.0f,
    val engineCleaning: Float = 0.0f,
    val chassisCleaning: Float = 0.0f,
    val additionalServices: Map<String, Float> = emptyMap()
)

/**
 * Estrutura para tempos de espera e horários de pico
 */
@Serializable
data class WasherWaitTimes(
    val currentWaitTime: Int = 0, // minutos
    val averageWaitTime: Int = 0, // minutos
    val peakHours: List<String> = emptyList(), // ex: "Monday 16:00-18:00"
    val offPeakHours: List<String> = emptyList(), // ex: "Tuesday 10:00-12:00"
    val lastUpdated: Long = System.currentTimeMillis()
)

/**
 * Estrutura para horários de funcionamento
 */
@Serializable
data class OperatingHours(
    val monday: DayHours = DayHours(),
    val tuesday: DayHours = DayHours(),
    val wednesday: DayHours = DayHours(),
    val thursday: DayHours = DayHours(),
    val friday: DayHours = DayHours(),
    val saturday: DayHours = DayHours(),
    val sunday: DayHours = DayHours(),
    val holidays: DayHours = DayHours(),
    val specialDays: Map<String, DayHours> = emptyMap() // ex: "2023-12-25" -> DayHours
)

/**
 * Estrutura para horários de um dia específico
 */
@Serializable
data class DayHours(
    val isOpen: Boolean = true,
    val openTime: String = "08:00",
    val closeTime: String = "18:00",
    val breaks: List<TimeRange> = emptyList() // períodos de pausa no funcionamento
)

/**
 * Estrutura para um intervalo de tempo
 */
@Serializable
data class TimeRange(
    val start: String,
    val end: String
)

/**
 * Avaliação de um usuário para um POI
 */
@Entity(tableName = "truck_washer_reviews")
@Serializable
data class TruckWasherReview(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val poiId: String,
    val userId: String,
    val userName: String,
    val rating: Float,
    val comment: String = "",
    val vehicleType: String = "",
    val date: Long = System.currentTimeMillis(),
    val helpful: Int = 0,
    val notHelpful: Int = 0,
    val photos: List<String> = emptyList()
)

/**
 * Classe para converter tipos complexos para armazenamento no Room Database
 */
class TruckWasherConverters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun fromWasherTypeList(value: List<WasherType>): String = json.encodeToString(value)

    @TypeConverter
    fun toWasherTypeList(value: String): List<WasherType> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)

    @TypeConverter
    fun fromTruckTypeList(value: List<TruckType>): String = json.encodeToString(value)

    @TypeConverter
    fun toTruckTypeList(value: String): List<TruckType> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)

    @TypeConverter
    fun fromStringList(value: List<String>): String = json.encodeToString(value)

    @TypeConverter
    fun toStringList(value: String): List<String> = 
        if (value.isBlank()) emptyList() else json.decodeFromString(value)

    @TypeConverter
    fun fromWasherPrices(value: WasherPrices): String = json.encodeToString(value)

    @TypeConverter
    fun toWasherPrices(value: String): WasherPrices = json.decodeFromString(value)

    @TypeConverter
    fun fromWasherWaitTimes(value: WasherWaitTimes): String = json.encodeToString(value)

    @TypeConverter
    fun toWasherWaitTimes(value: String): WasherWaitTimes = json.decodeFromString(value)

    @TypeConverter
    fun fromOperatingHours(value: OperatingHours): String = json.encodeToString(value)

    @TypeConverter
    fun toOperatingHours(value: String): OperatingHours = json.decodeFromString(value)

    @TypeConverter
    fun fromStringFloatMap(value: Map<String, Float>): String = json.encodeToString(value)

    @TypeConverter
    fun toStringFloatMap(value: String): Map<String, Float> = 
        if (value.isBlank()) emptyMap() else json.decodeFromString(value)
}