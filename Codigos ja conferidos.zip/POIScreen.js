/**
 * POIScreen.js
 * 
 * Tela de Pontos de Interesse (Points of Interest)
 * Exibe pontos de interesse próximos à localização do usuário ou à rota atual
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
  Alert,
  ActivityIndicator
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Marker, Callout } from 'react-native-maps';
import { useFocusEffect } from '@react-navigation/native';

// Importa serviço de traduções
import TranslationsService, { t } from '../services/TranslationsService';
import RegionalSettingsService from '../services/RegionalSettingsService';
import POIService from '../services/POIService';
import LocationService from '../services/LocationService';
import { useTheme } from '../contexts/ThemeContext';

const POIScreen = ({ route, navigation }) => {
  const { theme } = useTheme();
  const mapRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [pois, setPois] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [region, setRegion] = useState(null);
  const [selectedPOI, setSelectedPOI] = useState(null);
  const [viewMode, setViewMode] = useState('map'); // 'map' ou 'list'
  
  // Obtém parâmetros da rota se houver
  const routeId = route.params?.routeId;
  const initialCategory = route.params?.category;
  const initialRegion = route.params?.region;
  
  useEffect(() => {
    // Define a categoria inicial se fornecida
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
    
    // Define a região inicial se fornecida
    if (initialRegion) {
      setRegion(initialRegion);
    }
    
    // Carrega as categorias de POI
    loadCategories();
    
    // Adiciona listener para mudanças de locale
    const removeListener = TranslationsService.addLocaleChangeListener(() => {
      // Recarrega dados ao mudar o idioma
      loadCategories();
      loadPOIs();
    });
    
    return () => {
      // Remove listener ao desmontar componente
      removeListener();
    };
  }, [initialCategory, initialRegion]);
  
  // Recarrega os POIs quando o componente ganha foco
  useFocusEffect(
    React.useCallback(() => {
      loadUserLocation();
      return () => {};
    }, [])
  );
  
  // Efeito para carregar POIs quando categoria ou região mudam
  useEffect(() => {
    if (mapReady || viewMode === 'list') {
      loadPOIs();
    }
  }, [selectedCategory, region, mapReady, viewMode]);
  
  const loadCategories = async () => {
    try {
      const categoriesData = await POIService.getCategories();
      setCategories(categoriesData);
    } catch (error) {
      console.error('Erro ao carregar categorias:', error);
      Alert.alert(
        t('alert.error'),
        t('error.load_categories'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const loadUserLocation = async () => {
    try {
      const location = await LocationService.getCurrentLocation();
      setUserLocation(location);
      
      // Se não houver região definida, usa a localização do usuário
      if (!region) {
        setRegion({
          latitude: location.latitude,
          longitude: location.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05
        });
      }
    } catch (error) {
      console.error('Erro ao obter localização:', error);
      Alert.alert(
        t('alert.error'),
        t('error.location_unavailable'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const loadPOIs = async () => {
    if (!region) return;
    
    setLoading(true);
    
    try {
      let poisData;
      
      if (routeId) {
        // Carrega POIs ao longo da rota
        poisData = await POIService.getPOIsAlongRoute(
          routeId, 
          selectedCategory ? selectedCategory.id : null
        );
      } else {
        // Carrega POIs próximos à região atual
        poisData = await POIService.getPOIsNearby(
          region.latitude,
          region.longitude,
          5000, // raio em metros
          selectedCategory ? selectedCategory.id : null
        );
      }
      
      // Filtra por texto de busca se houver
      if (searchText) {
        const lowercaseSearch = searchText.toLowerCase();
        poisData = poisData.filter(poi => 
          poi.name.toLowerCase().includes(lowercaseSearch) ||
          poi.description.toLowerCase().includes(lowercaseSearch)
        );
      }
      
      setPois(poisData);
      setLoading(false);
      
      // Ajusta o mapa para exibir todos os POIs se houver pelo menos um
      if (mapRef.current && poisData.length > 0 && viewMode === 'map') {
        setTimeout(() => {
          mapRef.current.fitToCoordinates(
            poisData.map(poi => ({ latitude: poi.latitude, longitude: poi.longitude })),
            { edgePadding: { top: 50, right: 50, bottom: 50, left: 50 }, animated: true }
          );
        }, 500);
      }
    } catch (error) {
      console.error('Erro ao carregar POIs:', error);
      setLoading(false);
      Alert.alert(
        t('alert.error'),
        t('error.load_pois'),
        [{ text: t('button.ok') }]
      );
    }
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadPOIs();
    setRefreshing(false);
  };
  
  const handleCategorySelect = (category) => {
    setSelectedCategory(category === selectedCategory ? null : category);
  };
  
  const handlePOISelect = (poi) => {
    setSelectedPOI(poi);
    
    if (viewMode === 'map' && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: poi.latitude,
        longitude: poi.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
      }, 500);
    }
  };
  
  const handleMapRegionChange = (newRegion) => {
    setRegion(newRegion);
  };
  
  const handleViewModeToggle = () => {
    setViewMode(viewMode === 'map' ? 'list' : 'map');
  };
  
  const handlePOIDetails = (poi) => {
    navigation.navigate('POIDetails', { poiId: poi.id });
  };
  
  const getCategoryIcon = (categoryId) => {
    const iconMap = {
      'restaurant': 'restaurant',
      'hotel': 'hotel',
      'gas_station': 'local-gas-station',
      'parking': 'local-parking',
      'atm': 'local-atm',
      'hospital': 'local-hospital',
      'pharmacy': 'local-pharmacy',
      'police': 'local-police',
      'shopping': 'shopping-cart',
      'attraction': 'attractions',
      'camping': 'deck',
      'mechanic': 'build',
    };
    
    const category = categories.find(cat => cat.id === categoryId);
    return iconMap[category?.key] || 'place';
  };
  
  const getMarkerColor = (categoryId) => {
    const colorMap = {
      'restaurant': theme.poiRestaurant,
      'hotel': theme.poiLodging,
      'gas_station': theme.poiGas,
      'parking': theme.poiParking,
      'atm': theme.poiATM,
      'hospital': theme.poiMedical,
      'pharmacy': theme.poiMedical,
      'police': theme.poiEmergency,
      'shopping': theme.poiShopping,
      'attraction': theme.poiAttraction,
      'camping': theme.poiOutdoor,
      'mechanic': theme.poiService,
    };
    
    const category = categories.find(cat => cat.id === categoryId);
    return colorMap[category?.key] || theme.poiDefault;
  };
  
  const formatDistance = (meters) => {
    return RegionalSettingsService.formatDistance(meters / 1000); // converte metros para km
  };
  
  const renderCategory = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.categoryButton,
        selectedCategory?.id === item.id && { backgroundColor: theme.primaryLight }
      ]}
      onPress={() => handleCategorySelect(item)}
    >
      <Icon 
        name={getCategoryIcon(item.id)} 
        size={24} 
        color={selectedCategory?.id === item.id ? theme.primary : theme.textSecondary}
      />
      <Text
        style={[
          styles.categoryText,
          { color: selectedCategory?.id === item.id ? theme.primary : theme.text }
        ]}
      >
        {t(`poi_category.${item.key}`)}
      </Text>
    </TouchableOpacity>
  );
  
  const renderPOIItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.poiItem, { backgroundColor: theme.card }]}
      onPress={() => handlePOISelect(item)}
    >
      <View 
        style={[
          styles.poiCategoryIcon, 
          { backgroundColor: getMarkerColor(item.categoryId) }
        ]}
      >
        <Icon name={getCategoryIcon(item.categoryId)} size={24} color="white" />
      </View>
      
      <View style={styles.poiInfo}>
        <Text style={[styles.poiName, { color: theme.text }]}>
          {item.name}
        </Text>
        
        <Text 
          style={[styles.poiDescription, { color: theme.textSecondary }]}
          numberOfLines={2}
        >
          {item.description}
        </Text>
        
        <View style={styles.poiMeta}>
          <View style={styles.poiMetaItem}>
            <Icon name="place" size={12} color={theme.textSecondary} />
            <Text style={[styles.poiMetaText, { color: theme.textSecondary }]}>
              {formatDistance(item.distance)}
            </Text>
          </View>
          
          {item.rating && (
            <View style={styles.poiMetaItem}>
              <Icon name="star" size={12} color={theme.warning} />
              <Text style={[styles.poiMetaText, { color: theme.textSecondary }]}>
                {item.rating.toFixed(1)}
              </Text>
            </View>
          )}
          
          {item.isOpen !== undefined && (
            <View style={styles.poiMetaItem}>
              <Icon 
                name="access-time" 
                size={12} 
                color={item.isOpen ? theme.success : theme.danger} 
              />
              <Text 
                style={[
                  styles.poiMetaText, 
                  { color: item.isOpen ? theme.success : theme.danger }
                ]}
              >
                {item.isOpen 
                  ? t('poi.open_now') 
                  : t('poi.closed_now')
                }
              </Text>
            </View>
          )}
        </View>
      </View>
      
      <TouchableOpacity
        style={styles.poiActionButton}
        onPress={() => handlePOIDetails(item)}
      >
        <Icon name="chevron-right" size={24} color={theme.textSecondary} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
  
  const renderMap = () => (
    <View style={styles.mapContainer}>
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={region}
        onRegionChangeComplete={handleMapRegionChange}
        showsUserLocation
        showsMyLocationButton
        onMapReady={() => setMapReady(true)}
      >
        {pois.map(poi => (
          <Marker
            key={poi.id}
            coordinate={{
              latitude: poi.latitude,
              longitude: poi.longitude
            }}
            title={poi.name}
            description={poi.description}
            pinColor={getMarkerColor(poi.categoryId)}
            onPress={() => handlePOISelect(poi)}
          >
            <Callout onPress={() => handlePOIDetails(poi)}>
              <View style={styles.callout}>
                <Text style={styles.calloutTitle}>{poi.name}</Text>
                <Text style={styles.calloutDescription} numberOfLines={2}>
                  {poi.description}
                </Text>
                <Text style={styles.calloutAction}>
                  {t('button.tap_for_details')}
                </Text>
              </View>
            </Callout>
          </Marker>
        ))}
      </MapView>
      
      {/* Botões flutuantes */}
      <TouchableOpacity
        style={[styles.floatingButton, { backgroundColor: theme.card }]}
        onPress={handleViewModeToggle}
      >
        <Icon 
          name={viewMode === 'map' ? 'view-list' : 'map'} 
          size={24} 
          color={theme.primary} 
        />
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[styles.recenterButton, { backgroundColor: theme.card }]}
        onPress={() => {
          if (userLocation && mapRef.current) {
            mapRef.current.animateToRegion({
              latitude: userLocation.latitude,
              longitude: userLocation.longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01
            }, 500);
          }
        }}
      >
        <Icon name="my-location" size={24} color={theme.primary} />
      </TouchableOpacity>
    </View>
  );
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Cabeçalho */}
      <View style={[styles.header, { backgroundColor: theme.card }]}>
        <View style={styles.searchContainer}>
          <Icon name="search" size={20} color={theme.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: theme.text }]}
            placeholder={t('screen.poi.search_placeholder')}
            placeholderTextColor={theme.textSecondary}
            value={searchText}
            onChangeText={(text) => {
              setSearchText(text);
              if (text === '') {
                loadPOIs();
              }
            }}
            onSubmitEditing={loadPOIs}
            returnKeyType="search"
          />
          {searchText !== '' && (
            <TouchableOpacity
              onPress={() => {
                setSearchText('');
                loadPOIs();
              }}
            >
              <Icon name="clear" size={20} color={theme.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
      </View>
      
      {/* Categorias */}
      <View style={styles.categoriesContainer}>
        <FlatList
          data={categories}
          renderItem={renderCategory}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesList}
        />
      </View>
      
      {/* Loader */}
      {loading && (
        <View style={[styles.loaderContainer, { backgroundColor: 'rgba(0,0,0,0.1)' }]}>
          <ActivityIndicator size="large" color={theme.primary} />
        </View>
      )}
      
      {/* Conteúdo principal */}
      <View style={styles.content}>
        {viewMode === 'map' ? (
          renderMap()
        ) : (
          <FlatList
            data={pois}
            renderItem={renderPOIItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.poiList}
            onRefresh={handleRefresh}
            refreshing={refreshing}
            ListEmptyComponent={() => (
              <View style={styles.emptyContainer}>
                <Icon name="place" size={48} color={theme.textSecondary} />
                <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
                  {t('screen.poi.no_pois_found')}
                </Text>
              </View>
            )}
          />
        )}
      </View>
      
      {/* Detalhes do POI selecionado no modo mapa */}
      {viewMode === 'map' && selectedPOI && (
        <View style={[styles.poiDetailCard, { backgroundColor: theme.card }]}>
          <View style={styles.poiDetailHeader}>
            <Text style={[styles.poiDetailName, { color: theme.text }]}>
              {selectedPOI.name}
            </Text>
            <TouchableOpacity onPress={() => setSelectedPOI(null)}>
              <Icon name="close" size={24} color={theme.textSecondary} />
            </TouchableOpacity>
          </View>
          
          <Text 
            style={[styles.poiDetailDescription, { color: theme.textSecondary }]}
            numberOfLines={2}
          >
            {selectedPOI.description}
          </Text>
          
          <View style={styles.poiDetailMeta}>
            <View style={styles.poiMetaItem}>
              <Icon name="place" size={14} color={theme.textSecondary} />
              <Text style={[styles.poiMetaText, { color: theme.textSecondary }]}>
                {formatDistance(selectedPOI.distance)}
              </Text>
            </View>
            
            {selectedPOI.rating && (
              <View style={styles.poiMetaItem}>
                <Icon name="star" size={14} color={theme.warning} />
                <Text style={[styles.poiMetaText, { color: theme.textSecondary }]}>
                  {selectedPOI.rating.toFixed(1)}
                </Text>
              </View>
            )}
            
            {selectedPOI.isOpen !== undefined && (
              <View style={styles.poiMetaItem}>
                <Icon 
                  name="access-time" 
                  size={14} 
                  color={selectedPOI.isOpen ? theme.success : theme.danger} 
                />
                <Text 
                  style={[
                    styles.poiMetaText, 
                    { color: selectedPOI.isOpen ? theme.success : theme.danger }
                  ]}
                >
                  {selectedPOI.isOpen 
                    ? t('poi.open_now') 
                    : t('poi.closed_now')
                  }
                </Text>
              </View>
            )}
          </View>
          
          <View style={styles.poiDetailActions}>
            <TouchableOpacity
              style={[styles.poiDetailButton, { backgroundColor: theme.primaryLight }]}
              onPress={() => handlePOIDetails(selectedPOI)}
            >
              <Icon name="info" size={16} color={theme.primary} />
              <Text style={[styles.poiDetailButtonText, { color: theme.primary }]}>
                {t('button.details')}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.poiDetailButton, { backgroundColor: theme.primaryLight }]}
              onPress={() => {
                navigation.navigate('DirectionsScreen', {
                  destination: {
                    latitude: selectedPOI.latitude,
                    longitude: selectedPOI.longitude,
                    name: selectedPOI.name
                  }
                });
              }}
            >
              <Icon name="directions" size={16} color={theme.primary} />
              <Text style={[styles.poiDetailButtonText, { color: theme.primary }]}>
                {t('button.directions')}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.poiDetailButton, { backgroundColor: theme.primaryLight }]}
              onPress={() => {
                // Código para salvar o POI
                Alert.alert(
                  t('alert.success'),
                  t('success.poi_saved'),
                  [{ text: t('button.ok') }]
                );
              }}
            >
              <Icon name="bookmark" size={16} color={theme.primary} />
              <Text style={[styles.poiDetailButtonText, { color: theme.primary }]}>
                {t('button.save')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  searchInput: {
    flex: 1,
    height: 40,
    paddingVertical: 8,
    paddingHorizontal: 8,
    fontSize: 16,
  },
  categoriesContainer: {
    height: 56,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  categoriesList: {
    paddingHorizontal: 12,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    marginVertical: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
  },
  categoryText: {
    marginLeft: 8,
    fontSize: 14,
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  poiList: {
    padding: 12,
  },
  poiItem: {
    flexDirection: 'row',
    borderRadius: 12,
    marginBottom: 12,
    padding: 12,
  },
  poiCategoryIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  poiInfo: {
    flex: 1,
  },
  poiName: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  poiDescription: {
    fontSize: 14,
    marginBottom: 8,
  },
  poiMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  poiMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  poiMetaText: {
    fontSize: 12,
    marginLeft: 4,
  },
  poiActionButton: {
    paddingHorizontal: 8,
    justifyContent: 'center',
  },
  loaderContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    marginTop: 12,
    fontSize: 16,
    textAlign: 'center',
  },
  floatingButton: {
    position: 'absolute',
    bottom: 110,
    right: 16,
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  recenterButton: {
    position: 'absolute',
    bottom: 168,
    right: 16,
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  callout: {
    padding: 8,
    width: 200,
  },
  calloutTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  calloutDescription: {
    fontSize: 12,
    marginBottom: 4,
  },
  calloutAction: {
    fontSize: 12,
    color: '#0066CC',
    marginTop: 4,
  },
  poiDetailCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  poiDetailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  poiDetailName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  poiDetailDescription: {
    fontSize: 14,
    marginBottom: 12,
  },
  poiDetailMeta: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  poiDetailActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  poiDetailButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  poiDetailButtonText: {
    marginLeft: 4,
    fontSize: 14,
    fontWeight: '500',
  }
});

export default POIScreen;