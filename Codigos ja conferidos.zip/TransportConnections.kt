package com.kingroad.services

import android.util.Log

// Classe de conexão de transportes (ferries, balsas, túneis)
data class TransportConnection(
    val id: String,
    val name: String,
    val country: String,
    val type: String, // Ferry, Balsa, Eurotúnel, etc.
    val startPoint: String,
    val endPoint: String,
    val durationMinutes: Int
)

class TransportConnections {

    private val connections = mutableListOf<TransportConnection>()

    init {
        loadDefaultConnections()
    }

    // Carrega conexões padrão para vários países
    private fun loadDefaultConnections() {
        connections.add(TransportConnection("FR-UK-ET", "Eurotúnel", "França-Reino Unido", "Eurotúnel", "Calais", "Folkestone", 35))
        connections.add(TransportConnection("ES-MA-FERRY", "Ferry Espanha-Marrocos", "Espanha", "Ferry", "Algeciras", "Tânger", 90))
        connections.add(TransportConnection("IT-GR-FERRY", "Ferry Itália-Grécia", "Itália", "Ferry", "Bari", "Patras", 480))
        connections.add(TransportConnection("BR-AR-BALSA", "Balsa Brasil-Argentina", "Brasil", "Balsa", "Uruguaiana", "Paso de los Libres", 15))
        Log.i("TransportConnections", "🚢 Conexões de transporte carregadas.")
    }

    // Busca conexões disponíveis para um determinado país
    fun getConnectionsForCountry(country: String): List<TransportConnection> {
        return connections.filter { it.country.contains(country, ignoreCase = true) }
    }

    // Adiciona uma nova conexão de transporte
    fun addConnection(connection: TransportConnection) {
        connections.add(connection)
        Log.i("TransportConnections", "✅ Nova conexão adicionada: ${connection.name}")
    }

    // Lista todas as conexões disponíveis
    fun listAllConnections(): List<TransportConnection> {
        return connections
    }
}
