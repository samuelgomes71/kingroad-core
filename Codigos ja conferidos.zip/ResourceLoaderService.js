/**
 * Serviço para gerenciar o carregamento seletivo de recursos com base no dispositivo
 * Isso permite que o KingRoad baixe apenas os recursos necessários para o tamanho da tela
 */

import { detectDeviceSize, DeviceSize } from './DeviceDetectorUtil';

class ResourceLoaderService {
  constructor() {
    this.deviceSize = detectDeviceSize();
    this.loadedResources = new Set();
    this.resourceQueue = [];
    this.isProcessingQueue = false;
    
    // Adiciona um listener para mudanças de tamanho de tela
    window.addEventListener('resize', this.handleResize.bind(this));
  }
  
  /**
   * Manipulador para eventos de redimensionamento que podem mudar a categoria do dispositivo
   */
  handleResize() {
    const newSize = detectDeviceSize();
    if (newSize !== this.deviceSize) {
      this.deviceSize = newSize;
      // Poderia acionar um recarregamento de recursos se necessário
      console.log(`Mudança de tamanho de dispositivo detectada: ${this.deviceSize}`);
    }
  }
  
  /**
   * Busca o caminho do recurso adequado para o tamanho de dispositivo atual
   * @param {string} resourceName - Nome base do recurso (sem sufixo de tamanho)
   * @param {string} type - Tipo de recurso (logo, splash, icon, etc)
   * @param {string} extension - Extensão do arquivo
   * @returns {string} Caminho completo do recurso
   */
  getResourcePath(resourceName, type = 'logos', extension = 'png') {
    return `/assets/${type}/${resourceName}-${this.deviceSize}.${extension}`;
  }
  
  /**
   * Pré-carrega um recurso na memória
   * @param {string} resourcePath - Caminho completo do recurso para pré-carregar
   * @returns {Promise} Promessa que resolve quando o recurso é carregado
   */
  preloadResource(resourcePath) {
    return new Promise((resolve, reject) => {
      // Se o recurso já foi carregado, retorna imediatamente
      if (this.loadedResources.has(resourcePath)) {
        resolve(resourcePath);
        return;
      }
      
      // Dependendo do tipo de recurso
      if (resourcePath.match(/\.(png|jpg|jpeg|gif|webp)$/i)) {
        // Para imagens
        const img = new Image();
        img.onload = () => {
          this.loadedResources.add(resourcePath);
          resolve(resourcePath);
        };
        img.onerror = (error) => reject(error);
        img.src = resourcePath;
      } else if (resourcePath.match(/\.(css)$/i)) {
        // Para arquivos CSS
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = resourcePath;
        link.onload = () => {
          this.loadedResources.add(resourcePath);
          resolve(resourcePath);
        };
        link.onerror = (error) => reject(error);
        document.head.appendChild(link);
      } else {
        // Para outros tipos de recursos
        fetch(resourcePath)
          .then(response => {
            if (!response.ok) throw new Error(`Falha ao carregar ${resourcePath}`);
            this.loadedResources.add(resourcePath);
            resolve(resourcePath);
          })
          .catch(reject);
      }
    });
  }
  
  /**
   * Adiciona um recurso à fila de carregamento
   * @param {string} resourceName - Nome base do recurso
   * @param {string} type - Tipo de recurso
   * @param {string} extension - Extensão do arquivo
   * @param {number} priority - Prioridade (mais alto = mais importante)
   */
  queueResource(resourceName, type = 'logos', extension = 'png', priority = 0) {
    const resourcePath = this.getResourcePath(resourceName, type, extension);
    
    // Adiciona à fila se ainda não foi carregado
    if (!this.loadedResources.has(resourcePath)) {
      this.resourceQueue.push({
        path: resourcePath,
        priority,
        timestamp: Date.now()
      });
      
      // Ordena a fila por prioridade (maior para menor)
      this.resourceQueue.sort((a, b) => {
        // Primeiro por prioridade
        if (b.priority !== a.priority) {
          return b.priority - a.priority;
        }
        // Se prioridades iguais, pelo timestamp (mais antigo primeiro)
        return a.timestamp - b.timestamp;
      });
      
      // Inicia o processamento da fila se não estiver em andamento
      if (!this.isProcessingQueue) {
        this.processQueue();
      }
    }
  }
  
  /**
   * Processa a fila de recursos para carregamento
   */
  processQueue() {
    this.isProcessingQueue = true;
    
    if (this.resourceQueue.length === 0) {
      this.isProcessingQueue = false;
      return;
    }
    
    // Pega o próximo recurso da fila
    const nextResource = this.resourceQueue.shift();
    
    // Carrega o recurso
    this.preloadResource(nextResource.path)
      .then(() => {
        // Continua processando a fila
        this.processQueue();
      })
      .catch(error => {
        console.error(`Erro ao carregar recurso ${nextResource.path}:`, error);
        // Continua processando mesmo com erro
        this.processQueue();
      });
  }
  
  /**
   * Pré-carrega todos os recursos de um determinado tipo para o tamanho atual do dispositivo
   * @param {Array} resourceNames - Array de nomes de recursos para carregar
   * @param {string} type - Tipo de recurso
   * @param {string} extension - Extensão do arquivo
   * @returns {Promise} Promessa que resolve quando todos os recursos são carregados
   */
  preloadResourceSet(resourceNames, type = 'logos', extension = 'png') {
    const promises = resourceNames.map(name => {
      const path = this.getResourcePath(name, type, extension);
      return this.preloadResource(path);
    });
    
    return Promise.all(promises);
  }
  
  /**
   * Carrega apenas os recursos essenciais com base no dispositivo atual
   * Esta função deve ser chamada na inicialização do aplicativo
   */
  loadEssentialResources() {
    // Logos sempre são carregados independentemente do dispositivo
    this.queueResource('kingroad-logo', 'logos', 'png', 100);
    
    // Carregamento específico para cada tamanho de dispositivo
    switch (this.deviceSize) {
      case DeviceSize.EXTRA_SMALL:
        // Recursos específicos para dispositivos muito pequenos
        this.queueResource('splash-compact', 'splashscreens', 'png', 90);
        break;
        
      case DeviceSize.SMALL:
        // Recursos para smartphones maiores
        this.queueResource('splash-standard', 'splashscreens', 'png', 90);
        break;
        
      case DeviceSize.MEDIUM:
        // Recursos para tablets médios
        this.queueResource('splash-tablet', 'splashscreens', 'png', 90);
        // Pode incluir recursos adicionais para tablets
        this.queueResource('map-detail-enhanced', 'maps', 'png', 60);
        break;
        
      case DeviceSize.LARGE:
        // Recursos para tablets grandes
        this.queueResource('splash-large', 'splashscreens', 'png', 90);
        // Incluir recursos de alta resolução
        this.queueResource('map-detail-hd', 'maps', 'png', 60);
        this.queueResource('poi-icons-hd', 'icons', 'png', 50);
        break;
    }
    
    console.log(`Recursos essenciais enfileirados para dispositivo ${this.deviceSize}`);
    return this;
  }
}

// Exporta uma instância singleton
export default new ResourceLoaderService();