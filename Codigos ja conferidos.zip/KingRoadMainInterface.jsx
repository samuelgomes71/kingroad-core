import React, { useState } from 'react';
import { MapPin, Search, Truck, Route, Settings, Info, AlertTriangle } from 'lucide-react';

const KingRoadMainInterface = () => {
  const [currentRegion, setCurrentRegion] = useState('NORTH_AMERICA');
  
  return (
    <div className="h-screen bg-gray-100">
      {/* Barra superior com região atual */}
      <div className="bg-blue-700 p-4 flex justify-between items-center">
        <div className="text-white text-xl font-bold">King Road</div>
        <div className="flex items-center space-x-4">
          <span className="text-white">{currentRegion}</span>
          <Settings className="text-white cursor-pointer" size={24} />
        </div>
      </div>

      {/* Botões principais estilo TomTom - grandes e claros */}
      <div className="p-4 grid grid-cols-2 gap-4">
        <button className="bg-blue-600 p-8 rounded-xl shadow-lg flex flex-col items-center text-white hover:bg-blue-700 transition">
          <MapPin size={64} className="mb-4" />
          <span className="text-2xl font-bold">DRIVE</span>
        </button>

        <button className="bg-green-600 p-8 rounded-xl shadow-lg flex flex-col items-center text-white hover:bg-green-700 transition">
          <Search size={64} className="mb-4" />
          <span className="text-2xl font-bold">SEARCH</span>
        </button>

        <button className="bg-red-600 p-8 rounded-xl shadow-lg flex flex-col items-center text-white hover:bg-red-700 transition">
          <Truck size={64} className="mb-4" />
          <span className="text-2xl font-bold">TRUCK SERVICES</span>
        </button>

        <button className="bg-yellow-600 p-8 rounded-xl shadow-lg flex flex-col items-center text-white hover:bg-yellow-700 transition">
          <Route size={64} className="mb-4" />
          <span className="text-2xl font-bold">ROUTE PLAN</span>
        </button>
      </div>

      {/* Barra de acesso rápido circular */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-800 p-4">
        <div className="flex justify-around items-center">
          {[1, 2, 3, 4, 5].map((_, index) => (
            <div key={index} className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-500 transition">
              <div className="w-8 h-8 bg-white rounded-full"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Alertas regionais */}
      <div className="fixed top-16 right-4 w-64">
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-4 rounded shadow-lg">
          <div className="flex items-center">
            <AlertTriangle className="text-yellow-500 mr-2" size={20} />
            <p className="text-sm text-yellow-700">Entrando em zona de baixa emissão</p>
          </div>
        </div>
      </div>

      {/* Menu de configurações regionais (normalmente oculto) */}
      <div className="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="bg-white p-6 rounded-lg w-full max-w-md mx-4">
          <h3 className="text-xl font-bold mb-4">Regional Settings</h3>
          <div className="space-y-4">
            <button className="w-full p-4 bg-blue-100 text-blue-800 rounded-lg flex items-center justify-between">
              North America
              <Info size={20} />
            </button>
            <button className="w-full p-4 bg-blue-100 text-blue-800 rounded-lg flex items-center justify-between">
              Europe
              <Info size={20} />
            </button>
            <button className="w-full p-4 bg-blue-100 text-blue-800 rounded-lg flex items-center justify-between">
              Brazil
              <Info size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KingRoadMainInterface;