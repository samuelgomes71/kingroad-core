import React, { useState } from 'react';
import { AlertTriangle, MapPin, Camera, X, Check, Info, Star, Clock, Phone, MessageCircle, Share } from 'lucide-react';

// Demo app para visualizar o funcionamento do sistema de denúncias
const InfrastructureReportDemo = () => {
  const [showReportForm, setShowReportForm] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showReportHistory, setShowReportHistory] = useState(false);
  const [currentVehicleMode, setCurrentVehicleMode] = useState('truck');
  
  const mockUserLocation = {
    latitude: -23.550520,
    longitude: -46.633309
  };
  
  const mockUserId = "user123";
  
  const mockReports = [
    {
      id: "report1",
      reportType: "POTHOLE",
      description: "Buraco grande na via, risco para veículos",
      status: "IN_PROGRESS",
      municipalityName: "São Paulo",
      createdAt: Date.now() - 86400000 * 3, // 3 dias atrás
      protocolNumber: "PROT-12345",
      photoUrls: ["/api/placeholder/300/200?text=Foto+Buraco"]
    },
    {
      id: "report2",
      reportType: "FALLEN_TREE",
      description: "Árvore caída bloqueando parcialmente a via",
      status: "SUBMITTED",
      municipalityName: "Campinas",
      createdAt: Date.now() - 86400000 * 1, // 1 dia atrás
      protocolNumber: "PROT-54321",
      photoUrls: ["/api/placeholder/300/200?text=Foto+Árvore"]
    }
  ];
  
  const handleOpenReportForm = () => {
    setShowReportForm(true);
    setShowReportHistory(false);
    setShowSuccessMessage(false);
  };
  
  const handleReportSuccess = (report) => {
    setShowReportForm(false);
    setShowSuccessMessage(true);
  };
  
  const handleReportCancel = () => {
    setShowReportForm(false);
  };
  
  const handleShowHistory = () => {
    setShowReportHistory(true);
    setShowReportForm(false);
    setShowSuccessMessage(false);
  };
  
  const handleCloseAll = () => {
    setShowReportForm(false);
    setShowReportHistory(false);
    setShowSuccessMessage(false);
  };
  
  const switchVehicleMode = (mode) => {
    setCurrentVehicleMode(mode);
  };
  
  return (
    <div className="bg-gray-100 min-h-screen p-4">
      {/* Header com título e seletor de modo de veículo */}
      <div className="bg-gray-900 text-white p-4 rounded-lg mb-4 flex justify-between items-center">
        <h1 className="text-xl font-bold">KingRoad - Sistema de Denúncias</h1>
        
        <div className="flex space-x-2">
          <button 
            onClick={() => switchVehicleMode('truck')}
            className={`px-3 py-1 rounded-lg ${currentVehicleMode === 'truck' ? 'bg-amber-500 text-black' : 'bg-gray-800'}`}
          >
            Caminhão
          </button>
          <button 
            onClick={() => switchVehicleMode('car')}
            className={`px-3 py-1 rounded-lg ${currentVehicleMode === 'car' ? 'bg-amber-500 text-black' : 'bg-gray-800'}`}
          >
            Carro
          </button>
          <button 
            onClick={() => switchVehicleMode('motorcycle')}
            className={`px-3 py-1 rounded-lg ${currentVehicleMode === 'motorcycle' ? 'bg-amber-500 text-black' : 'bg-gray-800'}`}
          >
            Moto
          </button>
        </div>
      </div>
      
      {/* Mapa simulado */}
      <div className="bg-gray-800 text-white rounded-lg mb-4 h-64 relative flex items-center justify-center">
        <p className="text-gray-400">Mapa de Navegação (Simulação)</p>
        
        {/* Barra de navegação na parte inferior do mapa */}
        <div className="absolute bottom-0 left-0 right-0 bg-gray-900 text-white border-t border-gray-800 shadow-lg flex justify-between items-center px-4 py-2">
          <button className="p-2 text-gray-400 hover:text-white">
            <MapPin size={24} />
          </button>
          
          {/* Botão de denúncia de infraestrutura - Central e destacado */}
          <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <button
              className="bg-black text-amber-500 w-14 h-14 rounded-full flex items-center justify-center shadow-lg border-2 border-amber-500 relative"
              onClick={handleOpenReportForm}
            >
              <div className="flex flex-col items-center justify-center">
                <AlertTriangle size={24} className="text-amber-500" />
                <span className="text-xs mt-1">Denunciar</span>
              </div>
              
              {/* Indicador de localização ativa */}
              <div className="absolute top-1 right-1 w-3 h-3 bg-green-500 rounded-full border border-black"></div>
            </button>
          </div>
          
          <button className="p-2 text-gray-400 hover:text-white">
            <Clock size={24} />
          </button>
        </div>
      </div>
      
      {/* Visualização da tela principal se nenhum formulário estiver aberto */}
      {!showReportForm && !showSuccessMessage && !showReportHistory && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-bold mb-2">Bem-vindo ao KingRoad</h2>
            <p className="text-gray-600 mb-4">Ajude a melhorar a infraestrutura da sua cidade!</p>
            
            <div className="flex space-x-2">
              <button 
                onClick={handleOpenReportForm}
                className="bg-amber-500 hover:bg-amber-600 text-black px-4 py-2 rounded-lg font-medium flex items-center"
              >
                <AlertTriangle size={18} className="mr-2" />
                Fazer Denúncia
              </button>
              
              <button 
                onClick={handleShowHistory}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg font-medium flex items-center"
              >
                <Clock size={18} className="mr-2" />
                Histórico
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-bold mb-2">Problemas Recentes</h2>
            <p className="text-gray-600 mb-4">Problemas reportados na sua área:</p>
            
            <ul className="space-y-2">
              <li className="flex items-center text-sm text-gray-700">
                <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center mr-2">
                  <span className="text-xs">🕳️</span>
                </div>
                <span>3 buracos reportados recentemente</span>
              </li>
              <li className="flex items-center text-sm text-gray-700">
                <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center mr-2">
                  <span className="text-xs">🚦</span>
                </div>
                <span>1 semáforo com defeito</span>
              </li>
              <li className="flex items-center text-sm text-gray-700">
                <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                  <span className="text-xs">🚮</span>
                </div>
                <span>2 casos de lixo abandonado</span>
              </li>
            </ul>
          </div>
        </div>
      )}
      
      {/* Formulário de Denúncia */}
      {showReportForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 text-white rounded-lg shadow-xl w-full max-w-lg">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <h2 className="text-xl font-bold text-amber-500">Nova Denúncia</h2>
              <button 
                onClick={handleReportCancel}
                className="text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6">
              <h3 className="text-lg font-bold text-center mb-4">Selecione o tipo de problema</h3>
              
              <div className="grid grid-cols-2 gap-3 mb-6">
                {[
                  { id: 'POTHOLE', label: 'Buraco na via', icon: '🕳️' },
                  { id: 'FALLEN_TREE', label: 'Árvore caída', icon: '🌳' },
                  { id: 'WATER_LEAK', label: 'Vazamento de água', icon: '💧' },
                  { id: 'ABANDONED_WASTE', label: 'Lixo abandonado', icon: '🚮' },
                  { id: 'ILLEGAL_DUMPING', label: 'Descarte irregular', icon: '🗑️' },
                  { id: 'OTHER', label: 'Outro problema', icon: '❓' }
                ].map(type => (
                  <button
                    key={type.id}
                    className="p-4 rounded-lg flex flex-col items-center justify-center bg-gray-800 hover:bg-gray-700 transition-colors"
                  >
                    <span className="text-2xl mb-2">{type.icon}</span>
                    <span className="text-sm font-medium">{type.label}</span>
                  </button>
                ))}
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">
                  Localização
                </label>
                <div className="p-3 bg-gray-800 rounded-lg flex items-center">
                  <MapPin size={18} className="text-amber-400 mr-2" />
                  <span className="text-sm truncate">
                    {mockUserLocation
                      ? `${mockUserLocation.latitude.toFixed(6)}, ${mockUserLocation.longitude.toFixed(6)}`
                      : 'Localização não disponível'}
                  </span>
                  <button 
                    className="ml-auto text-amber-400 hover:text-amber-300 text-sm"
                  >
                    Atualizar
                  </button>
                </div>
                
                <div className="mt-2 text-sm flex items-center text-gray-400">
                  <Info size={14} className="mr-1" />
                  <span>Município: São Paulo, Brasil</span>
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">
                  Adicionar fotos
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    className="w-full h-24 border-2 border-dashed border-gray-700 rounded-lg flex flex-col items-center justify-center hover:border-amber-500 transition-colors"
                  >
                    <Camera size={24} className="text-amber-500 mb-2" />
                    <span className="text-xs text-gray-400">Adicionar</span>
                  </button>
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <button 
                  onClick={handleReportCancel}
                  className="px-4 py-2 text-gray-400 hover:text-white"
                >
                  Cancelar
                </button>
                
                <button 
                  onClick={handleReportSuccess}
                  className="px-6 py-2 rounded-lg font-medium bg-amber-500 text-black"
                >
                  Continuar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Mensagem de Sucesso */}
      {showSuccessMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 text-white rounded-lg shadow-xl w-full max-w-md p-6">
            <div className="flex flex-col items-center mb-6">
              <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center mb-4">
                <Check size={32} className="text-white" />
              </div>
              <h2 className="text-xl font-bold text-center">Denúncia Enviada!</h2>
              <p className="text-center text-gray-400 mt-2">
                Sua denúncia foi enviada com sucesso para a prefeitura.
              </p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-amber-400 font-medium">Protocolo:</span>
                <span className="font-mono">PROT-98765</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-amber-400 font-medium">Município:</span>
                <span>São Paulo</span>
              </div>
            </div>
            
            <p className="text-sm text-gray-400 mb-6">
              Você pode acompanhar o status da sua denúncia no histórico.
            </p>
            
            <div className="flex space-x-3">
              <button 
                onClick={handleShowHistory}
                className="flex-1 bg-gray-800 hover:bg-gray-700 py-2 rounded-lg font-medium transition-colors"
              >
                Ver Histórico
              </button>
              <button 
                onClick={handleCloseAll}
                className="flex-1 bg-amber-500 hover:bg-amber-600 text-black py-2 rounded-lg font-medium transition-colors"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Histórico de Denúncias */}
      {showReportHistory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 text-white rounded-lg shadow-xl w-full max-w-2xl">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <h2 className="text-xl font-bold text-amber-500">Minhas Denúncias</h2>
              <button 
                onClick={handleCloseAll}
                className="text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-4 max-h-96 overflow-y-auto">
              {mockReports.map(report => (
                <div key={report.id} className="bg-gray-800 rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-lg">{report.description}</h3>
                      <div className="flex items-center text-sm text-gray-400 mt-1">
                        <MapPin size={14} className="mr-1" />
                        <span>{report.municipalityName}</span>
                      </div>
                    </div>
                    
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      report.status === 'SUBMITTED' ? 'bg-blue-500' :
                      report.status === 'IN_PROGRESS' ? 'bg-orange-500' :
                      report.status === 'RESOLVED' ? 'bg-green-500' : 'bg-gray-500'
                    }`}>
                      {report.status === 'SUBMITTED' ? 'Enviada' :
                       report.status === 'IN_PROGRESS' ? 'Em andamento' :
                       report.status === 'RESOLVED' ? 'Resolvida' : 'Desconhecido'}
                    </div>
                  </div>
                  
                  {report.photoUrls && report.photoUrls.length > 0 && (
                    <div className="mb-4">
                      <img 
                        src={report.photoUrls[0]}
                        alt="Foto da denúncia" 
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-gray-700 p-3 rounded-lg">
                      <div className="text-xs text-gray-400 mb-1">Protocolo</div>
                      <div className="flex items-center">
                        <Star size={16} className="text-amber-400 mr-2" />
                        <span className="font-medium">{report.protocolNumber}</span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-700 p-3 rounded-lg">
                      <div className="text-xs text-gray-400 mb-1">Enviada em</div>
                      <div className="flex items-center">
                        <Clock size={16} className="text-amber-400 mr-2" />
                        <span className="font-medium">{new Date(report.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-700 pt-3 mt-3 flex justify-between">
                    <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
                      <Phone size={16} className="mr-1" />
                      <span>Contatar</span>
                    </button>
                    
                    <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
                      <MessageCircle size={16} className="mr-1" />
                      <span>Atualização</span>
                    </button>
                    
                    <button className="flex items-center text-amber-400 hover:text-amber-300 text-sm">
                      <Share size={16} className="mr-1" />
                      <span>Compartilhar</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t border-gray-800">
              <button 
                onClick={handleOpenReportForm}
                className="w-full bg-amber-500 hover:bg-amber-600 text-black py-2 rounded-lg font-medium transition-colors"
              >
                Nova Denúncia
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InfrastructureReportDemo;