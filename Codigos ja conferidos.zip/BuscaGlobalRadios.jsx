import React, { useState } from 'react';
import { Search, Globe, Radio, Share2, Star, Play, ArrowLeft, Filter, Check } from 'lucide-react';

const BuscaGlobalRadios = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('Todos');
  const [selectedLanguage, setSelectedLanguage] = useState('Todos');
  
  // Dados simulados para demonstração
  const countries = ['Todos', 'Brasil', 'EUA', 'Espanha', 'Portugal', 'Argentina'];
  const languages = ['Todos', 'Português', 'Inglês', 'Espanhol'];
  
  const radioResults = [
    { id: 1, name: 'Rádio Estrada BR', country: 'Brasil', language: 'Português', listeners: 1542 },
    { id: 2, name: 'Caminhoneiros FM', country: 'Brasil', language: 'Português', listeners: 879 },
    { id: 3, name: 'Truckers USA', country: 'EUA', language: 'Inglês', listeners: 2150 },
    { id: 4, name: 'Radio Carretera', country: 'Espanha', language: 'Espanhol', listeners: 645 },
    { id: 5, name: 'Rota 66 FM', country: 'Brasil', language: 'Português', listeners: 1235 }
  ];
  
  // Estilo "Família 15": borda café, fundo bege claro
  const familyStyle = {
    borderColor: '#8B4513', // café
    backgroundColor: '#F5F5DC' // bege claro
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };
  
  const handleSearch = (e) => {
    e.preventDefault();
    // Aqui seria implementada a lógica real de busca
    console.log("Buscando por:", searchQuery, selectedCountry, selectedLanguage);
  };
  
  return (
    <div className="max-w-md mx-auto bg-white">
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="flex items-center">
          <button className="p-1 mr-2 rounded-full hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h2 className="text-lg font-semibold flex items-center">
            <Globe className="h-5 w-5 mr-2 text-blue-600" />
            Busca Global de Rádios
          </h2>
        </div>
        
        {/* Formulário de busca */}
        <form onSubmit={handleSearch} className="mt-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white 
                         placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 
                         focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Nome da rádio, estilo musical..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center justify-between mt-2">
            <button
              type="button"
              className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm 
                        leading-5 font-medium rounded-md text-gray-700 bg-white hover:text-gray-500 
                        focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:text-gray-800 
                        active:bg-gray-50 transition ease-in-out duration-150"
              onClick={toggleFilters}
            >
              <Filter className="h-4 w-4 mr-1" />
              Filtros
              <span className="ml-1 text-xs bg-blue-100 text-blue-800 px-1.5 rounded-full">
                {selectedCountry !== 'Todos' || selectedLanguage !== 'Todos' ? '2' : '0'}
              </span>
            </button>
            
            <button
              type="submit"
              className="inline-flex items-center px-4 py-1 border border-transparent text-sm 
                        leading-5 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-500 
                        focus:outline-none focus:border-blue-700 focus:shadow-outline-blue active:bg-blue-700 
                        transition ease-in-out duration-150"
            >
              Buscar
            </button>
          </div>
          
          {/* Filtros expandidos */}
          {showFilters && (
            <div 
              className="mt-2 p-3 rounded-md"
              style={{
                backgroundColor: familyStyle.backgroundColor,
                border: '1px solid',
                borderColor: familyStyle.borderColor
              }}
            >
              <div className="mb-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">País</label>
                <div className="flex flex-wrap gap-1">
                  {countries.map(country => (
                    <button
                      key={country}
                      type="button"
                      className={`px-2 py-1 text-xs rounded-full ${
                        selectedCountry === country 
                          ? 'bg-blue-100 text-blue-800 border-blue-300' 
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                      } border`}
                      onClick={() => setSelectedCountry(country)}
                    >
                      {country}
                      {selectedCountry === country && <Check className="inline h-3 w-3 ml-1" />}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Idioma</label>
                <div className="flex flex-wrap gap-1">
                  {languages.map(language => (
                    <button
                      key={language}
                      type="button"
                      className={`px-2 py-1 text-xs rounded-full ${
                        selectedLanguage === language 
                          ? 'bg-blue-100 text-blue-800 border-blue-300' 
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                      } border`}
                      onClick={() => setSelectedLanguage(language)}
                    >
                      {language}
                      {selectedLanguage === language && <Check className="inline h-3 w-3 ml-1" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </form>
      </div>
      
      {/* Resultados da busca */}
      <div className="divide-y divide-gray-200">
        {radioResults.map((radio) => (
          <div key={radio.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-start">
                <div className="bg-white p-1 rounded-full border border-gray-200 mr-3">
                  <Radio className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{radio.name}</h3>
                  <p className="text-xs text-gray-500">{radio.country} • {radio.language}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    <span className="flex items-center">
                      <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                      {radio.listeners} ouvintes agora
                    </span>
                  </p>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button 
                  className="p-2 rounded-full hover:bg-gray-100"
                  title="Tocar agora"
                >
                  <Play className="h-5 w-5 text-blue-600" />
                </button>
                <button 
                  className="p-2 rounded-full hover:bg-gray-100"
                  title="Salvar nos favoritos"
                >
                  <Star className="h-5 w-5 text-gray-400" />
                </button>
                <button 
                  className="p-2 rounded-full hover:bg-gray-100"
                  title="Compartilhar com um amigo"
                >
                  <Share2 className="h-5 w-5 text-gray-400" />
                </button>
              </div>
            </div>
            
            <div className="mt-2 flex justify-between">
              <button className="text-sm text-blue-600 font-medium hover:underline">
                Tocar agora
              </button>
              <button className="text-sm text-blue-600 font-medium hover:underline">
                Adicionar aos favoritos
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {/* Rodapé informativo */}
      <div className="p-4 bg-gray-50 border-t border-gray-200 text-xs text-gray-500">
        <p>Dados fornecidos por <span className="font-medium">Radio Browser API</span></p>
        <p className="mt-1">É possível adicionar rádios diretamente por URL usando o botão + no topo da lista de favoritos.</p>
      </div>
    </div>
  );
};

export default BuscaGlobalRadios;