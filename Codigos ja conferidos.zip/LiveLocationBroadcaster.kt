package com.kingroad.services

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.kingroad.database.UserDao
import com.kingroad.database.UserLocation
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString

/**
 * Compartilha localização em tempo real com outros motoristas ou com o sistema.
 * Implementa múltiplos métodos de compartilhamento (WebSocket, Firebase, REST).
 */
class LiveLocationBroadcaster(
    private val context: Context,
    private val userDao: UserDao,
    private val apiBaseUrl: String,
    private val apiKey: String? = null,
    private val websocketUrl: String? = null,
    private val firebaseEnabled: Boolean = true,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val scope: CoroutineScope = CoroutineScope(dispatcher + SupervisorJob())
) {
    companion object {
        private const val TAG = "LiveLocationBroadcaster"
        
        // Intervalo de atualização da localização em milissegundos
        private const val DEFAULT_LOCATION_INTERVAL = 10000L // 10 segundos
        private const val FAST_LOCATION_INTERVAL = 5000L // 5 segundos
        
        // Intervalos de sincronização para diferentes métodos
        private const val REST_SYNC_INTERVAL = 15000L // 15 segundos
        private const val FIREBASE_SYNC_INTERVAL = 5000L // 5 segundos
        
        // Modos de compartilhamento de localização
        enum class SharingMode {
            OFF,                // Sem compartilhamento
            FRIENDS_ONLY,       // Apenas amigos
            TRIP_MEMBERS,       // Membros da viagem
            PUBLIC,             // Público (qualquer usuário)
            EMERGENCY           // Modo de emergência (máxima prioridade)
        }
        
        // Métodos de transmissão
        enum class BroadcastMethod {
            REST,              // Usando API REST
            FIREBASE,          // Usando Firebase Realtime Database
            WEBSOCKET,         // Usando WebSocket
            ALL                // Todos os métodos disponíveis
        }
    }
    
    // Clientes e referências para os diferentes métodos de transmissão
    private var fusedLocationClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)
    private var firebaseReference: DatabaseReference? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient.Builder()
        .readTimeout(30, TimeUnit.SECONDS)
        .connectTimeout(30, TimeUnit.SECONDS)
        .build()
    
    // Callback de localização
    private var locationCallback: LocationCallback? = null
    
    // Estado do broadcaster
    private val _broadcastState = MutableStateFlow<BroadcastState>(BroadcastState.Stopped)
    val broadcastState: StateFlow<BroadcastState> = _broadcastState.asStateFlow()
    
    // Última localização compartilhada
    private val _lastSharedLocation = MutableLiveData<UserLocation?>()
    val lastSharedLocation: LiveData<UserLocation?> = _lastSharedLocation
    
    // Estado atual de compartilhamento
    private var currentSharingMode = SharingMode.OFF
    private var currentBroadcastMethod = BroadcastMethod.REST
    private var currentSharingSessionId: String? = null
    private var currentSharingGroupId: String? = null
    
    // ID de usuário atual
    private var userId: String? = null
    private var userName: String? = null
    
    // Configurações
    private var locationInterval = DEFAULT_LOCATION_INTERVAL
    private var restSyncInterval = REST_SYNC_INTERVAL
    private var firebaseSyncInterval = FIREBASE_SYNC_INTERVAL
    private var lastRestSync = 0L
    private var lastFirebaseSync = 0L
    
    init {
        // Inicializa Firebase se habilitado
        if (firebaseEnabled) {
            firebaseReference = FirebaseDatabase.getInstance().getReference("locations")
        }
        
        // Carrega informações do usuário
        scope.launch {
            loadUserInfo()
        }
    }
    
    /**
     * Carrega informações do usuário atual
     */
    private suspend fun loadUserInfo() = withContext(dispatcher) {
        try {
            val user = userDao.getCurrentUser()
            if (user != null) {
                userId = user.id
                userName = user.name
                Log.d(TAG, "Informações do usuário carregadas: $userName")
            } else {
                Log.w(TAG, "Usuário não encontrado no banco de dados local")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar informações do usuário: ${e.message}", e)
        }
    }
    
    /**
     * Inicia o compartilhamento de localização
     * 
     * @param mode Modo de compartilhamento
     * @param method Método de transmissão
     * @param groupId ID do grupo (opcional, usado para viagens ou grupos específicos)
     * @param highAccuracy Se true, usa alta precisão de localização
     * @return true se iniciado com sucesso
     */
    fun startSharing(
        mode: SharingMode,
        method: BroadcastMethod = BroadcastMethod.REST,
        groupId: String? = null,
        highAccuracy: Boolean = false
    ): Boolean {
        // Verifica se já está compartilhando
        if (_broadcastState.value is BroadcastState.Broadcasting) {
            Log.w(TAG, "Já está compartilhando localização. Pare primeiro.")
            return false
        }
        
        // Verifica permissões de localização
        if (!hasLocationPermissions()) {
            Log.e(TAG, "Sem permissões de localização")
            _broadcastState.value = BroadcastState.Error("Permissões de localização necessárias")
            return false
        }
        
        // Verifica se o usuário está carregado
        if (userId == null) {
            Log.e(TAG, "Usuário não carregado")
            _broadcastState.value = BroadcastState.Error("Usuário não identificado")
            return false
        }
        
        try {
            // Define configurações
            currentSharingMode = mode
            currentBroadcastMethod = method
            currentSharingGroupId = groupId
            currentSharingSessionId = UUID.randomUUID().toString()
            
            // Ajusta intervalo de localização baseado no modo
            locationInterval = when (mode) {
                SharingMode.EMERGENCY -> FAST_LOCATION_INTERVAL
                else -> DEFAULT_LOCATION_INTERVAL
            }
            
            // Cria request de localização
            val locationRequest = LocationRequest.Builder(
                if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                locationInterval
            ).build()
            
            // Cria callback de localização
            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    locationResult.lastLocation?.let { location ->
                        handleNewLocation(location)
                    }
                }
            }
            
            // Solicita atualizações de localização
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.requestLocationUpdates(
                    locationRequest,
                    locationCallback!!,
                    Looper.getMainLooper()
                )
                
                // Inicializa os métodos de transmissão escolhidos
                when (method) {
                    BroadcastMethod.REST -> { /* Não precisa de inicialização especial */ }
                    BroadcastMethod.FIREBASE -> setupFirebaseSharing()
                    BroadcastMethod.WEBSOCKET -> setupWebSocketConnection()
                    BroadcastMethod.ALL -> {
                        setupFirebaseSharing()
                        setupWebSocketConnection()
                    }
                }
                
                // Atualiza estado
                _broadcastState.value = BroadcastState.Broadcasting(currentSharingSessionId!!, mode)
                Log.d(TAG, "Compartilhamento de localização iniciado: modo=$mode, método=$method")
                
                return true
            } else {
                _broadcastState.value = BroadcastState.Error("Permissões de localização necessárias")
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar compartilhamento: ${e.message}", e)
            _broadcastState.value = BroadcastState.Error(e.message ?: "Erro desconhecido")
            return false
        }
    }
    
    /**
     * Para o compartilhamento de localização
     */
    fun stopSharing() {
        try {
            // Remove callbacks de localização
            locationCallback?.let {
                fusedLocationClient.removeLocationUpdates(it)
                locationCallback = null
            }
            
            // Fecha WebSocket
            webSocket?.let {
                it.close(1000, "Compartilhamento encerrado pelo usuário")
                webSocket = null
            }
            
            // Limpa dados no Firebase
            if (currentBroadcastMethod == BroadcastMethod.FIREBASE || 
                currentBroadcastMethod == BroadcastMethod.ALL) {
                removeLocationFromFirebase()
            }
            
            // Notifica servidor REST que compartilhamento acabou
            if (currentBroadcastMethod == BroadcastMethod.REST || 
                currentBroadcastMethod == BroadcastMethod.ALL) {
                scope.launch {
                    sendStopSharingToRest()
                }
            }
            
            // Limpa estado atual
            currentSharingSessionId = null
            currentSharingGroupId = null
            currentSharingMode = SharingMode.OFF
            
            // Atualiza estado
            _broadcastState.value = BroadcastState.Stopped
            Log.d(TAG, "Compartilhamento de localização parado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar compartilhamento: ${e.message}", e)
            _broadcastState.value = BroadcastState.Error(e.message ?: "Erro ao parar compartilhamento")
        }
    }
    
    /**
     * Trata uma nova localização recebida
     */
    private fun handleNewLocation(location: Location) {
        // Cria objeto de localização do usuário
        val userLocation = UserLocation(
            userId = userId ?: return,
            userName = userName ?: "Motorista",
            latitude = location.latitude,
            longitude = location.longitude,
            speed = location.speed,
            bearing = location.bearing,
            altitude = location.altitude,
            accuracy = location.accuracy,
            timestamp = System.currentTimeMillis(),
            sessionId = currentSharingSessionId,
            groupId = currentSharingGroupId,
            sharingMode = currentSharingMode.name,
            extras = if (location.extras != null) {
                val json = JSONObject()
                for (key in location.extras!!.keySet()) {
                    json.put(key, location.extras!!.get(key).toString())
                }
                json.toString()
            } else null
        )
        
        // Atualiza última localização
        _lastSharedLocation.postValue(userLocation)
        
        // Salva no banco de dados local
        scope.launch {
            try {
                userDao.updateUserLocation(userLocation)
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao salvar localização local: ${e.message}", e)
            }
        }
        
        // Envia para os canais configurados
        when (currentBroadcastMethod) {
            BroadcastMethod.REST -> {
                // Verifica intervalo para não sobrecarregar
                val now = System.currentTimeMillis()
                if (now - lastRestSync >= restSyncInterval) {
                    scope.launch {
                        sendLocationToRest(userLocation)
                    }
                    lastRestSync = now
                }
            }
            BroadcastMethod.FIREBASE -> {
                // Verifica intervalo para não sobrecarregar
                val now = System.currentTimeMillis()
                if (now - lastFirebaseSync >= firebaseSyncInterval) {
                    sendLocationToFirebase(userLocation)
                    lastFirebaseSync = now
                }
            }
            BroadcastMethod.WEBSOCKET -> {
                sendLocationToWebSocket(userLocation)
            }
            BroadcastMethod.ALL -> {
                // Verifica intervalos para cada método
                val now = System.currentTimeMillis()
                
                // REST
                if (now - lastRestSync >= restSyncInterval) {
                    scope.launch {
                        sendLocationToRest(userLocation)
                    }
                    lastRestSync = now
                }
                
                // Firebase
                if (now - lastFirebaseSync >= firebaseSyncInterval) {
                    sendLocationToFirebase(userLocation)
                    lastFirebaseSync = now
                }
                
                // WebSocket (sempre envia)
                sendLocationToWebSocket(userLocation)
            }
        }
    }
    
    /**
     * Envia localização via REST API
     */
    private suspend fun sendLocationToRest(location: UserLocation) = withContext(dispatcher) {
        try {
            val url = URL("$apiBaseUrl/api/locations/share")
            val connection = url.openConnection() as HttpURLConnection
            
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com dados
            val locationData = JSONObject().apply {
                put("userId", location.userId)
                put("userName", location.userName)
                put("latitude", location.latitude)
                put("longitude", location.longitude)
                put("speed", location.speed)
                put("bearing", location.bearing)
                put("altitude", location.altitude)
                put("accuracy", location.accuracy)
                put("timestamp", location.timestamp)
                put("sessionId", location.sessionId)
                put("groupId", location.groupId ?: JSONObject.NULL)
                put("sharingMode", location.sharingMode)
                if (location.extras != null) {
                    put("extras", JSONObject(location.extras))
                }
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(locationData.toString())
                writer.flush()
            }
            
            // Lê resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                Log.d(TAG, "Localização enviada com sucesso via REST: $responseCode")
            } else {
                Log.e(TAG, "Erro ao enviar localização via REST: $responseCode")
            }
            
            connection.disconnect()
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar localização via REST: ${e.message}", e)
        }
    }
    
    /**
     * Notifica servidor REST que compartilhamento acabou
     */
    private suspend fun sendStopSharingToRest() = withContext(dispatcher) {
        try {
            val url = URL("$apiBaseUrl/api/locations/stopSharing")
            val connection = url.openConnection() as HttpURLConnection
            
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com dados
            val data = JSONObject().apply {
                put("userId", userId)
                put("sessionId", currentSharingSessionId)
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(data.toString())
                writer.flush()
            }
            
            // Lê resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                Log.d(TAG, "Notificação de parada enviada com sucesso via REST: $responseCode")
            } else {
                Log.e(TAG, "Erro ao enviar notificação de parada via REST: $responseCode")
            }
            
            connection.disconnect()
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar notificação de parada via REST: ${e.message}", e)
        }
    }
    
    /**
     * Configura compartilhamento via Firebase
     */
    private fun setupFirebaseSharing() {
        if (!firebaseEnabled || firebaseReference == null) {
            Log.w(TAG, "Firebase não está habilitado ou referência é nula")
            return
        }
        
        // Cria ou limpa nó para este usuário
        firebaseReference?.child(userId ?: return)?.removeValue()
    }
    
    /**
     * Envia localização para o Firebase
     */
    private fun sendLocationToFirebase(location: UserLocation) {
        if (!firebaseEnabled || firebaseReference == null) {
            return
        }
        
        try {
            // Cria mapa de dados
            val locationData = mapOf(
                "userId" to location.userId,
                "userName" to location.userName,
                "latitude" to location.latitude,
                "longitude" to location.longitude,
                "speed" to location.speed,
                "bearing" to location.bearing,
                "altitude" to location.altitude,
                "accuracy" to location.accuracy,
                "timestamp" to location.timestamp,
                "sessionId" to location.sessionId,
                "groupId" to location.groupId,
                "sharingMode" to location.sharingMode,
                "extras" to location.extras
            )
            
            // Salva no Firebase
            firebaseReference?.child(location.userId)?.setValue(locationData)
                ?.addOnSuccessListener {
                    Log.d(TAG, "Localização enviada com sucesso para o Firebase")
                }
                ?.addOnFailureListener { e ->
                    Log.e(TAG, "Erro ao enviar localização para o Firebase: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar localização para o Firebase: ${e.message}", e)
        }
    }
    
    /**
     * Remove localização do Firebase
     */
    private fun removeLocationFromFirebase() {
        if (!firebaseEnabled || firebaseReference == null) {
            return
        }
        
        try {
            firebaseReference?.child(userId ?: return)?.removeValue()
                ?.addOnSuccessListener {
                    Log.d(TAG, "Localização removida com sucesso do Firebase")
                }
                ?.addOnFailureListener { e ->
                    Log.e(TAG, "Erro ao remover localização do Firebase: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao remover localização do Firebase: ${e.message}", e)
        }
    }
    
    /**
     * Configura conexão WebSocket
     */
    private fun setupWebSocketConnection() {
        if (websocketUrl == null) {
            Log.w(TAG, "URL do WebSocket não configurada")
            return
        }
        
        try {
            // Cria e configura conexão
            val request = Request.Builder()
                .url(websocketUrl)
                .build()
            
            // Listener de eventos do WebSocket
            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    Log.d(TAG, "WebSocket conectado")
                    
                    // Envia mensagem de identificação
                    val authMessage = JSONObject().apply {
                        put("type", "auth")
                        put("userId", userId)
                        put("sessionId", currentSharingSessionId)
                        put("groupId", currentSharingGroupId ?: JSONObject.NULL)
                        put("sharingMode", currentSharingMode.name)
                    }
                    
                    webSocket.send(authMessage.toString())
                }
                
                override fun onMessage(webSocket: WebSocket, text: String) {
                    Log.d(TAG, "Mensagem recebida no WebSocket: $text")
                    
                    // Processa comandos do servidor
                    try {
                        val message = JSONObject(text)
                        val type = message.optString("type")
                        
                        when (type) {
                            "stop" -> {
                                // Servidor solicitou parar compartilhamento
                                stopSharing()
                            }
                            "interval_change" -> {
                                // Servidor solicitou alterar intervalo
                                val newInterval = message.optLong("interval", DEFAULT_LOCATION_INTERVAL)
                                if (newInterval > 0) {
                                    locationInterval = newInterval
                                    // Seria necessário recriar o request de localização
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Erro ao processar mensagem do WebSocket: ${e.message}")
                    }
                }
                
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                    Log.d(TAG, "Mensagem binária recebida no WebSocket")
                }
                
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket fechando: $code - $reason")
                    webSocket.close(1000, null)
                }
                
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "WebSocket fechado: $code - $reason")
                }
                
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.e(TAG, "Falha no WebSocket: ${t.message}")
                }
            }
            
            // Inicia conexão
            webSocket = okHttpClient.newWebSocket(request, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao configurar WebSocket: ${e.message}", e)
        }
    }
    
    /**
     * Envia localização para o WebSocket
     */
    private fun sendLocationToWebSocket(location: UserLocation) {
        if (webSocket == null) {
            return
        }
        
        try {
            // Cria JSON com dados
            val locationData = JSONObject().apply {
                put("type", "location")
                put("userId", location.userId)
                put("userName", location.userName)
                put("latitude", location.latitude)
                put("longitude", location.longitude)
                put("speed", location.speed)
                put("bearing", location.bearing)
                put("altitude", location.altitude)
                put("accuracy", location.accuracy)
                put("timestamp", location.timestamp)
                put("sessionId", location.sessionId)
                put("groupId", location.groupId ?: JSONObject.NULL)
                put("sharingMode", location.sharingMode)
                if (location.extras != null) {
                    put("extras", JSONObject(location.extras))
                }
            }
            
            // Envia mensagem
            val success = webSocket?.send(locationData.toString())
            if (success == false) {
                Log.e(TAG, "Erro ao enviar localização para o WebSocket")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exceção ao enviar localização para o WebSocket: ${e.message}", e)
        }
    }
    
    /**
     * Verifica se tem permissões de localização
     */
    private fun hasLocationPermissions(): Boolean {
        return ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Obtém última localização conhecida
     */
    suspend fun getLastKnownLocation(): Location? = withContext(dispatcher) {
        if (!hasLocationPermissions()) {
            return@withContext null
        }
        
        try {
            return@withContext fusedLocationClient.lastLocation.await()
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao obter última localização: ${e.message}", e)
            return@withContext null
        }
    }
    
    /**
     * Altera modo de compartilhamento sem reiniciar
     */
    fun changeSharingMode(newMode: SharingMode): Boolean {
        if (_broadcastState.value !is BroadcastState.Broadcasting) {
            Log.w(TAG, "Não está compartilhando localização")
            return false
        }
        
        // Atualiza modo
        currentSharingMode = newMode
        
        // Atualiza estado
        val currentSession = (_broadcastState.value as? BroadcastState.Broadcasting)?.sessionId ?: return false
        _broadcastState.value = BroadcastState.Broadcasting(currentSession, newMode)
        
        Log.d(TAG, "Modo de compartilhamento alterado para: $newMode")
        return true
    }
    
    /**
     * Define intervalo de atualização de localização
     */
    fun setLocationInterval(intervalMs: Long): Boolean {
        if (intervalMs <= 0) {
            return false
        }
        
        locationInterval = intervalMs
        
        // Seria necessário recriar o request de localização para aplicar
        // o novo intervalo, o que não implementamos neste exemplo
        
        return true
    }
    
    /**
     * Define intervalos de sincronização
     */
    fun setSyncIntervals(restIntervalMs: Long, firebaseIntervalMs: Long) {
        if (restIntervalMs > 0) {
            restSyncInterval = restIntervalMs
        }
        
        if (firebaseIntervalMs > 0) {
            firebaseSyncInterval = firebaseIntervalMs
        }
    }
    
    /**
     * Libera recursos
     */
    fun shutdown() {
        // Para compartilhamento se estiver ativo
        if (_broadcastState.value is BroadcastState.Broadcasting) {
            stopSharing()
        }
        
        // Fecha WebSocket
        webSocket?.close(1000, "Shutdown")
        webSocket = null
    }
    
    /**
     * Estados do broadcaster
     */
    sealed class BroadcastState {
        object Stopped : BroadcastState()
        data class Broadcasting(val sessionId: String, val mode: SharingMode) : BroadcastState()
        data class Error(val message: String) : BroadcastState()
    }
}