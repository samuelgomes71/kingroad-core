package com.kingroad.utils

import android.graphics.Color
import kotlin.math.roundToInt

class ThemeManager {
    data class Theme(
        val id: String,
        val name: String,
        val dayColors: ThemeColors,
        val nightColors: ThemeColors,
        val styles: ThemeStyles
    )

    data class ThemeColors(
        val background: String,
        val surface: String,
        val primary: String,
        val secondary: String,
        val accent: String,
        val warning: String,
        val text: String,
        val textSecondary: String,
        val mapRoad: String,
        val mapWater: String,
        val mapLand: String,
        val mapBackground: String
    )

    data class ThemeStyles(
        val cornerRadius: Int,
        val buttonStyle: String,
        val iconStyle: String,
        val fontFamily: String = "Roboto",
        val elevationEnabled: Boolean = true
    )

    // Lista de temas disponíveis
    val themes = listOf(
        // Modern Theme
        Theme(
            id = "modern",
            name = "Modern",
            dayColors = ThemeColors(
                background = "#FFFFFF",
                surface = "#F5F5F5",
                primary = "#2196F3",
                secondary = "#4CAF50",
                accent = "#FF5722",
                warning = "#FFC107",
                text = "#212121",
                textSecondary = "#757575",
                mapRoad = "#FFFFFF",
                mapWater = "#E3F2FD",
                mapLand = "#C8E6C9",
                mapBackground = "#FAFAFA"
            ),
            nightColors = ThemeColors(
                background = "#0A0A0A",
                surface = "#1A1A1A",
                primary = "#3498db",
                secondary = "#2ecc71",
                accent = "#e74c3c",
                warning = "#f1c40f",
                text = "#FFFFFF",
                textSecondary = "#95a5a6",
                mapRoad = "#2c3e50",
                mapWater = "#2980b9",
                mapLand = "#27ae60",
                mapBackground = "#121212"
            ),
            styles = ThemeStyles(
                cornerRadius = 12,
                buttonStyle = "rounded",
                iconStyle = "filled"
            )
        ),

        // Classic Theme
        Theme(
            id = "classic",
            name = "Classic",
            dayColors = ThemeColors(
                background = "#FAFAFA",
                surface = "#FFFFFF",
                primary = "#1976D2",
                secondary = "#388E3C",
                accent = "#D32F2F",
                warning = "#FFA000",
                text = "#212121",
                textSecondary = "#757575",
                mapRoad = "#FFFFFF",
                mapWater = "#BBDEFB",
                mapLand = "#C8E6C9",
                mapBackground = "#F5F5F5"
            ),
            nightColors = ThemeColors(
                background = "#141E30",
                surface = "#243B55",
                primary = "#4A90E2",
                secondary = "#50C878",
                accent = "#FF6B6B",
                warning = "#FFB900",
                text = "#FFFFFF",
                textSecondary = "#B8C6D1",
                mapRoad = "#465670",
                mapWater = "#4A90E2",
                mapLand = "#50C878",
                mapBackground = "#0A1014"
            ),
            styles = ThemeStyles(
                cornerRadius = 8,
                buttonStyle = "square",
                iconStyle = "outlined"
            )
        ),
        
        // Desert Theme
        Theme(
            id = "desert",
            name = "Desert",
            dayColors = ThemeColors(
                background = "#FFFCF2",
                surface = "#FFF8E1",
                primary = "#FF9800",
                secondary = "#8D6E63",
                accent = "#FF5722",
                warning = "#FFC107",
                text = "#3E2723",
                textSecondary = "#795548",
                mapRoad = "#FFFFFF",
                mapWater = "#80DEEA",
                mapLand = "#FFE0B2",
                mapBackground = "#FFF3E0"
            ),
            nightColors = ThemeColors(
                background = "#2D2D2D",
                surface = "#3D3D3D",
                primary = "#D4AC0D",
                secondary = "#BA4A00",
                accent = "#C0392B",
                warning = "#F39C12",
                text = "#ECF0F1",
                textSecondary = "#BDC3C7",
                mapRoad = "#6D4C41",
                mapWater = "#1ABC9C",
                mapLand = "#D35400",
                mapBackground = "#262626"
            ),
            styles = ThemeStyles(
                cornerRadius = 16,
                buttonStyle = "pill",
                iconStyle = "duotone"
            )
        )
    )

    /**
     * Obtém as cores do tema com base no ID do tema e no modo (dia/noite)
     */
    fun getThemeColors(themeId: String, isDayMode: Boolean): ThemeColors {
        val theme = themes.find { it.id == themeId } ?: themes.first()
        return if (isDayMode) theme.dayColors else theme.nightColors
    }

    /**
     * Determina se deve usar o modo dia com base na hora
     */
    fun shouldUseDayMode(hour: Int): Boolean {
        return hour in 6..17  // Dia: 6h às 17h
    }

    /**
     * Obtém cores de transição para animação suave entre modos dia/noite
     * @param fromColors Cores iniciais
     * @param toColors Cores finais
     * @param progress Valor de 0.0 a 1.0 que indica o progresso da transição
     */
    fun getTransitionColors(fromColors: ThemeColors, toColors: ThemeColors, progress: Float): ThemeColors {
        return ThemeColors(
            background = interpolateColor(fromColors.background, toColors.background, progress),
            surface = interpolateColor(fromColors.surface, toColors.surface, progress),
            primary = interpolateColor(fromColors.primary, toColors.primary, progress),
            secondary = interpolateColor(fromColors.secondary, toColors.secondary, progress),
            accent = interpolateColor(fromColors.accent, toColors.accent, progress),
            warning = interpolateColor(fromColors.warning, toColors.warning, progress),
            text = interpolateColor(fromColors.text, toColors.text, progress),
            textSecondary = interpolateColor(fromColors.textSecondary, toColors.textSecondary, progress),
            mapRoad = interpolateColor(fromColors.mapRoad, toColors.mapRoad, progress),
            mapWater = interpolateColor(fromColors.mapWater, toColors.mapWater, progress),
            mapLand = interpolateColor(fromColors.mapLand, toColors.mapLand, progress),
            mapBackground = interpolateColor(fromColors.mapBackground, toColors.mapBackground, progress)
        )
    }

    /**
     * Interpola entre duas cores no formato hexadecimal
     */
    private fun interpolateColor(from: String, to: String, progress: Float): String {
        try {
            // Converter strings hexadecimais para inteiros
            val fromColor = Color.parseColor(from)
            val toColor = Color.parseColor(to)
            
            // Extrair componentes RGB
            val fromA = Color.alpha(fromColor)
            val fromR = Color.red(fromColor)
            val fromG = Color.green(fromColor)
            val fromB = Color.blue(fromColor)
            
            val toA = Color.alpha(toColor)
            val toR = Color.red(toColor)
            val toG = Color.green(toColor)
            val toB = Color.blue(toColor)
            
            // Calcular valores interpolados
            val a = (fromA + ((toA - fromA) * progress)).roundToInt()
            val r = (fromR + ((toR - fromR) * progress)).roundToInt()
            val g = (fromG + ((toG - fromG) * progress)).roundToInt()
            val b = (fromB + ((toB - fromB) * progress)).roundToInt()
            
            // Criar nova cor interpolada
            val interpolatedColor = Color.argb(
                a.coerceIn(0, 255), 
                r.coerceIn(0, 255), 
                g.coerceIn(0, 255), 
                b.coerceIn(0, 255)
            )
            
            // Converter para string hexadecimal
            return String.format("#%08X", interpolatedColor)
        } catch (e: Exception) {
            // Em caso de erro, retornar a cor de destino
            return to
        }
    }

    /**
     * Obter o tema padrão do sistema
     */
    fun getDefaultTheme(): Theme {
        return themes.first()
    }

    /**
     * Obter um tema por ID
     */
    fun getThemeById(id: String): Theme {
        return themes.find { it.id == id } ?: getDefaultTheme()
    }
}