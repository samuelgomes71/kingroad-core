/**
 * MapCacheService.js
 * 
 * Serviço responsável pelo gerenciamento de cache do mapa
 * Permite baixar, armazenar e gerenciar mapas offline
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform, Alert } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import * as FileSystem from 'expo-file-system';
import * as SQLite from 'expo-sqlite';
import * as Permissions from 'expo-permissions';
import * as Battery from 'expo-battery';

// Importar serviço de traduções
import TranslationsService, { t } from './TranslationsService';
import RegionalSettingsService from './RegionalSettingsService';

// Constantes
const CACHE_DB_NAME = 'map_cache.db';
const CACHE_DIRECTORY = `${FileSystem.documentDirectory}maps/`;
const CACHE_METADATA_KEY = '@KingRoad:mapCacheMetadata';
const CACHE_SETTINGS_KEY = '@KingRoad:mapCacheSettings';
const DEFAULT_MAX_CACHE_SIZE = 512; // MB
const DEFAULT_EXPIRATION_DAYS = 30;
const DEFAULT_DOWNLOAD_WIFI_ONLY = true;
const MIN_BATTERY_FOR_DOWNLOAD = 20;
const DEFAULT_AUTO_UPDATE = true;

class MapCacheService {
  constructor() {
    this.db = null;
    this.initialized = false;
    this.currentDownloads = {};
    this.downloadQueue = [];
    this.settings = {
      maxCacheSize: DEFAULT_MAX_CACHE_SIZE,
      expirationDays: DEFAULT_EXPIRATION_DAYS,
      downloadWifiOnly: DEFAULT_DOWNLOAD_WIFI_ONLY,
      autoUpdate: DEFAULT_AUTO_UPDATE
    };
    this.localeChangeListener = null;
  }
  
  /**
   * Inicializa o serviço de cache
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      // Verifica se o diretório de cache existe
      const dirInfo = await FileSystem.getInfoAsync(CACHE_DIRECTORY);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(CACHE_DIRECTORY, { intermediates: true });
      }
      
      // Abre/cria o banco de dados do cache
      this.db = SQLite.openDatabase(CACHE_DB_NAME);
      await this.createTablesIfNeeded();
      
      // Carrega configurações do cache
      await this.loadSettings();
      
      // Limpa cache expirado
      await this.cleanExpiredCache();
      
      // Adiciona listener para mudanças de locale
      this.localeChangeListener = TranslationsService.addLocaleChangeListener(() => {
        // Se necessário, atualizar algum comportamento baseado no idioma
      });
      
      this.initialized = true;
      console.log(t('services.map_cache.initialized'));
    } catch (error) {
      console.error('MapCacheService initialize error:', error);
      throw new Error(t('services.map_cache.init_error'));
    }
  }
  
  /**
   * Cria as tabelas do cache se não existirem
   */
  async createTablesIfNeeded() {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `CREATE TABLE IF NOT EXISTS tiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            z INTEGER NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            region TEXT NOT NULL,
            file_path TEXT NOT NULL,
            size INTEGER NOT NULL,
            download_date INTEGER NOT NULL,
            last_access INTEGER NOT NULL,
            UNIQUE(z, x, y, region)
          )`,
          [],
          () => {
            tx.executeSql(
              `CREATE TABLE IF NOT EXISTS regions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                bbox TEXT NOT NULL,
                size INTEGER NOT NULL,
                download_date INTEGER NOT NULL,
                last_access INTEGER NOT NULL,
                description TEXT,
                UNIQUE(name)
              )`,
              [],
              resolve,
              (_, error) => reject(error)
            );
          },
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Carrega as configurações do cache
   */
  async loadSettings() {
    try {
      const settingsJson = await AsyncStorage.getItem(CACHE_SETTINGS_KEY);
      if (settingsJson) {
        this.settings = { ...this.settings, ...JSON.parse(settingsJson) };
      }
    } catch (error) {
      console.warn(t('services.map_cache.settings_load_error'), error);
      // Continua com as configurações padrão
    }
  }
  
  /**
   * Salva as configurações do cache
   */
  async saveSettings(newSettings) {
    try {
      this.settings = { ...this.settings, ...newSettings };
      await AsyncStorage.setItem(CACHE_SETTINGS_KEY, JSON.stringify(this.settings));
      return true;
    } catch (error) {
      console.error(t('services.map_cache.settings_save_error'), error);
      return false;
    }
  }
  
  /**
   * Solicita permissão de armazenamento (necessário no Android)
   */
  async requestStoragePermission() {
    if (Platform.OS !== 'android') return true;
    
    const { status } = await Permissions.askAsync(Permissions.MEDIA_LIBRARY_WRITE_ONLY);
    return status === 'granted';
  }
  
  /**
   * Obtém o tamanho total do cache em MB
   */
  async getTotalCacheSize() {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          'SELECT SUM(size) as total_size FROM tiles',
          [],
          (_, result) => {
            const totalBytes = result.rows.item(0).total_size || 0;
            resolve(totalBytes / (1024 * 1024)); // Converte para MB
          },
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Verifica se o dispositivo pode baixar mapas
   */
  async canDownloadMaps() {
    try {
      // Verifica permissão de armazenamento
      const hasPermission = await this.requestStoragePermission();
      if (!hasPermission) {
        throw new Error(t('services.map_cache.no_storage_permission'));
      }
      
      // Verifica o estado da rede
      const netInfo = await NetInfo.fetch();
      if (!netInfo.isConnected) {
        throw new Error(t('services.map_cache.no_network'));
      }
      
      if (this.settings.downloadWifiOnly && netInfo.type !== 'wifi') {
        throw new Error(t('services.map_cache.wifi_only'));
      }
      
      // Verifica se há espaço suficiente para o cache
      const currentSize = await this.getTotalCacheSize();
      if (currentSize >= this.settings.maxCacheSize) {
        await this.cleanCache(this.settings.maxCacheSize * 0.2); // Libera 20% do tamanho máximo
      }
      
      // Verifica nível da bateria
      const batteryLevel = await Battery.getBatteryLevelAsync();
      if (batteryLevel * 100 < MIN_BATTERY_FOR_DOWNLOAD) {
        throw new Error(t('services.map_cache.low_battery', { level: MIN_BATTERY_FOR_DOWNLOAD }));
      }
      
      return true;
    } catch (error) {
      console.warn('canDownloadMaps error:', error);
      return false;
    }
  }
  
  /**
   * Baixa uma região do mapa para uso offline
   * @param {Object} region - Região a ser baixada (nome, bbox, etc)
   * @param {Function} progressCallback - Callback para reportar progresso
   */
  async downloadRegion(region, progressCallback) {
    if (!region || !region.name || !region.bbox) {
      throw new Error(t('services.map_cache.invalid_region'));
    }
    
    // Verifica se já existe um download em andamento para essa região
    if (this.currentDownloads[region.name]) {
      throw new Error(t('services.map_cache.download_in_progress', { region: region.name }));
    }
    
    // Verifica se o dispositivo pode baixar mapas
    const canDownload = await this.canDownloadMaps();
    if (!canDownload) {
      throw new Error(t('services.map_cache.cannot_download'));
    }
    
    // Calcula os tiles necessários para a região
    const tiles = this.calculateTilesForRegion(region.bbox);
    const totalTiles = tiles.length;
    
    if (totalTiles === 0) {
      throw new Error(t('services.map_cache.no_tiles_in_region'));
    }
    
    // Registra o download e inicia
    this.currentDownloads[region.name] = {
      total: totalTiles,
      downloaded: 0,
      progress: 0,
      interrupted: false
    };
    
    try {
      // Registra a região no banco de dados
      await this.registerRegion(region, totalTiles);
      
      // Baixa os tiles
      for (let i = 0; i < tiles.length; i++) {
        if (this.currentDownloads[region.name].interrupted) {
          throw new Error(t('services.map_cache.download_interrupted'));
        }
        
        const tile = tiles[i];
        await this.downloadTile(tile, region.name);
        
        // Atualiza o progresso
        this.currentDownloads[region.name].downloaded++;
        this.currentDownloads[region.name].progress = 
          (this.currentDownloads[region.name].downloaded / totalTiles) * 100;
        
        // Chama o callback de progresso
        if (progressCallback) {
          progressCallback({
            region: region.name,
            tile: tile,
            downloaded: this.currentDownloads[region.name].downloaded,
            total: totalTiles,
            progress: this.currentDownloads[region.name].progress
          });
        }
      }
      
      // Download concluído
      delete this.currentDownloads[region.name];
      return { success: true, region: region.name, tiles: totalTiles };
    } catch (error) {
      // Em caso de erro, remove o download em andamento
      delete this.currentDownloads[region.name];
      console.error('downloadRegion error:', error);
      throw error;
    }
  }
  
  /**
   * Interrompe o download de uma região
   * @param {string} regionName - Nome da região
   */
  cancelDownload(regionName) {
    if (this.currentDownloads[regionName]) {
      this.currentDownloads[regionName].interrupted = true;
      return true;
    }
    return false;
  }
  
  /**
   * Baixa um tile individual
   * @param {Object} tile - Tile a ser baixado (z, x, y)
   * @param {string} regionName - Nome da região
   */
  async downloadTile(tile, regionName) {
    const tileUrl = this.getTileUrl(tile.z, tile.x, tile.y);
    const tileFilename = `${tile.z}_${tile.x}_${tile.y}.png`;
    const tilePath = `${CACHE_DIRECTORY}${regionName}/${tileFilename}`;
    
    // Cria o diretório da região se não existir
    const regionDir = `${CACHE_DIRECTORY}${regionName}/`;
    const regionDirInfo = await FileSystem.getInfoAsync(regionDir);
    if (!regionDirInfo.exists) {
      await FileSystem.makeDirectoryAsync(regionDir, { intermediates: true });
    }
    
    // Baixa o tile
    try {
      const downloadResult = await FileSystem.downloadAsync(tileUrl, tilePath);
      
      // Registra o tile no banco de dados
      if (downloadResult.status === 200) {
        await this.registerTile({
          ...tile,
          region: regionName,
          file_path: tilePath,
          size: downloadResult.headers['Content-Length'] || 0,
          download_date: Date.now(),
          last_access: Date.now()
        });
        return downloadResult;
      } else {
        throw new Error(t('services.map_cache.tile_download_failed', { status: downloadResult.status }));
      }
    } catch (error) {
      console.error('downloadTile error:', error);
      throw error;
    }
  }
  
  /**
   * Calcula os tiles necessários para uma região (bbox)
   * @param {Array} bbox - Bounding box [minLon, minLat, maxLon, maxLat]
   * @param {number} minZoom - Zoom mínimo
   * @param {number} maxZoom - Zoom máximo
   */
  calculateTilesForRegion(bbox, minZoom = 10, maxZoom = 15) {
    const tiles = [];
    const [minLon, minLat, maxLon, maxLat] = bbox;
    
    for (let z = minZoom; z <= maxZoom; z++) {
      // Converte coordenadas para tiles
      const minX = this.lon2tile(minLon, z);
      const maxX = this.lon2tile(maxLon, z);
      const minY = this.lat2tile(maxLat, z);
      const maxY = this.lat2tile(minLat, z);
      
      // Adiciona cada tile à lista
      for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
          tiles.push({ z, x, y });
        }
      }
    }
    
    return tiles;
  }
  
  /**
   * Converte longitude para coordenada X do tile
   */
  lon2tile(lon, zoom) {
    return Math.floor((lon + 180) / 360 * Math.pow(2, zoom));
  }
  
  /**
   * Converte latitude para coordenada Y do tile
   */
  lat2tile(lat, zoom) {
    return Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom));
  }
  
  /**
   * Obtém a URL para um tile
   */
  getTileUrl(z, x, y) {
    // Serviço de tiles padrão (OpenStreetMap)
    return `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
  }
  
  /**
   * Registra um tile no banco de dados
   */
  async registerTile(tileData) {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `INSERT OR REPLACE INTO tiles 
           (z, x, y, region, file_path, size, download_date, last_access) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            tileData.z, 
            tileData.x, 
            tileData.y, 
            tileData.region, 
            tileData.file_path, 
            tileData.size, 
            tileData.download_date, 
            tileData.last_access
          ],
          (_, result) => resolve(result),
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Registra uma região no banco de dados
   */
  async registerRegion(region, totalTiles) {
    const estimatedSize = totalTiles * 15 * 1024; // Estimativa de 15KB por tile
    
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `INSERT OR REPLACE INTO regions 
           (name, bbox, size, download_date, last_access, description) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [
            region.name,
            JSON.stringify(region.bbox),
            estimatedSize,
            Date.now(),
            Date.now(),
            region.description || ''
          ],
          (_, result) => resolve(result),
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Limpa cache antigo quando necessário
   * @param {number} bytesToFree - Bytes a serem liberados
   */
  async cleanCache(mbToFree = 100) {
    try {
      const bytesToFree = mbToFree * 1024 * 1024;
      
      return new Promise((resolve, reject) => {
        this.db.transaction(tx => {
          // Obtém os tiles mais antigos até atingir o tamanho necessário
          tx.executeSql(
            `SELECT id, file_path, size FROM tiles 
             ORDER BY last_access ASC 
             LIMIT 1000`,
            [],
            async (_, result) => {
              const tilesToDelete = [];
              let freedSpace = 0;
              
              for (let i = 0; i < result.rows.length; i++) {
                const tile = result.rows.item(i);
                tilesToDelete.push(tile.id);
                freedSpace += tile.size;
                
                // Tenta excluir o arquivo do tile
                try {
                  await FileSystem.deleteAsync(tile.file_path, { idempotent: true });
                } catch (fileError) {
                  console.warn(t('services.map_cache.file_delete_error'), fileError);
                }
                
                if (freedSpace >= bytesToFree) break;
              }
              
              if (tilesToDelete.length > 0) {
                // Remove os tiles do banco de dados
                tx.executeSql(
                  `DELETE FROM tiles WHERE id IN (${tilesToDelete.join(',')})`,
                  [],
                  () => {
                    resolve({
                      tilesDeleted: tilesToDelete.length,
                      spaceCleaned: freedSpace / (1024 * 1024)
                    });
                  },
                  (_, error) => reject(error)
                );
              } else {
                resolve({ tilesDeleted: 0, spaceCleaned: 0 });
              }
            },
            (_, error) => reject(error)
          );
        });
      });
    } catch (error) {
      console.error(t('services.map_cache.clean_error'), error);
      throw error;
    }
  }
  
  /**
   * Limpa o cache expirado
   */
  async cleanExpiredCache() {
    try {
      const expirationTime = Date.now() - (this.settings.expirationDays * 24 * 60 * 60 * 1000);
      
      return new Promise((resolve, reject) => {
        this.db.transaction(tx => {
          // Obtém os tiles expirados
          tx.executeSql(
            `SELECT id, file_path FROM tiles 
             WHERE last_access < ?`,
            [expirationTime],
            async (_, result) => {
              const tilesToDelete = [];
              
              for (let i = 0; i < result.rows.length; i++) {
                const tile = result.rows.item(i);
                tilesToDelete.push(tile.id);
                
                // Tenta excluir o arquivo do tile
                try {
                  await FileSystem.deleteAsync(tile.file_path, { idempotent: true });
                } catch (fileError) {
                  console.warn(t('services.map_cache.file_delete_error'), fileError);
                }
              }
              
              if (tilesToDelete.length > 0) {
                // Remove os tiles do banco de dados
                tx.executeSql(
                  `DELETE FROM tiles WHERE id IN (${tilesToDelete.join(',')})`,
                  [],
                  () => {
                    console.log(t('services.map_cache.expired_cleaned', { count: tilesToDelete.length }));
                    resolve({ tilesDeleted: tilesToDelete.length });
                  },
                  (_, error) => reject(error)
                );
              } else {
                resolve({ tilesDeleted: 0 });
              }
            },
            (_, error) => reject(error)
          );
        });
      });
    } catch (error) {
      console.error(t('services.map_cache.clean_expired_error'), error);
      // Não propaga o erro para não impedir a inicialização
      return { tilesDeleted: 0, error };
    }
  }
  
  /**
   * Verifica se um tile está no cache
   */
  async isTileInCache(z, x, y, region = 'default') {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `SELECT file_path FROM tiles 
           WHERE z = ? AND x = ? AND y = ? AND region = ?`,
          [z, x, y, region],
          (_, result) => {
            if (result.rows.length > 0) {
              const tile = result.rows.item(0);
              resolve({ cached: true, filePath: tile.file_path });
            } else {
              resolve({ cached: false });
            }
          },
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Atualiza a data de último acesso de um tile
   */
  async updateTileAccess(z, x, y, region = 'default') {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `UPDATE tiles SET last_access = ? 
           WHERE z = ? AND x = ? AND y = ? AND region = ?`,
          [Date.now(), z, x, y, region],
          (_, result) => resolve(result),
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Lista as regiões disponíveis no cache
   */
  async getRegions() {
    return new Promise((resolve, reject) => {
      this.db.transaction(tx => {
        tx.executeSql(
          `SELECT * FROM regions ORDER BY last_access DESC`,
          [],
          (_, result) => {
            const regions = [];
            for (let i = 0; i < result.rows.length; i++) {
              const region = result.rows.item(i);
              regions.push({
                ...region,
                bbox: JSON.parse(region.bbox),
                sizeMB: region.size / (1024 * 1024)
              });
            }
            resolve(regions);
          },
          (_, error) => reject(error)
        );
      });
    });
  }
  
  /**
   * Exclui uma região do cache
   */
  async deleteRegion(regionName) {
    try {
      // Primeiro, exclui os arquivos dos tiles
      return new Promise((resolve, reject) => {
        this.db.transaction(tx => {
          tx.executeSql(
            `SELECT file_path FROM tiles WHERE region = ?`,
            [regionName],
            async (_, result) => {
              // Exclui os arquivos dos tiles
              for (let i = 0; i < result.rows.length; i++) {
                const tile = result.rows.item(i);
                try {
                  await FileSystem.deleteAsync(tile.file_path, { idempotent: true });
                } catch (fileError) {
                  console.warn(t('services.map_cache.file_delete_error'), fileError);
                }
              }
              
              // Remove a entrada da região
              tx.executeSql(
                `DELETE FROM regions WHERE name = ?`,
                [regionName],
                () => {
                  // Remove os tiles da região
                  tx.executeSql(
                    `DELETE FROM tiles WHERE region = ?`,
                    [regionName],
                    () => {
                      // Tenta remover o diretório da região
                      const regionDir = `${CACHE_DIRECTORY}${regionName}/`;
                      FileSystem.deleteAsync(regionDir, { idempotent: true })
                        .then(() => resolve({ success: true }))
                        .catch(error => {
                          console.warn(t('services.map_cache.directory_delete_error'), error);
                          resolve({ success: true, directoryError: error });
                        });
                    },
                    (_, error) => reject(error)
                  );
                },
                (_, error) => reject(error)
              );
            },
            (_, error) => reject(error)
          );
        });
      });
    } catch (error) {
      console.error(t('services.map_cache.region_delete_error'), error);
      throw error;
    }
  }
  
  /**
   * Limpa todo o cache
   */
  async clearAllCache() {
    try {
      // Primeiro exclui os arquivos
      try {
        await FileSystem.deleteAsync(CACHE_DIRECTORY, { idempotent: true });
        await FileSystem.makeDirectoryAsync(CACHE_DIRECTORY, { intermediates: true });
      } catch (fileError) {
        console.warn(t('services.map_cache.directory_delete_error'), fileError);
      }
      
      // Então limpa o banco de dados
      return new Promise((resolve, reject) => {
        this.db.transaction(tx => {
          tx.executeSql(
            `DELETE FROM tiles`,
            [],
            () => {
              tx.executeSql(
                `DELETE FROM regions`,
                [],
                () => resolve({ success: true }),
                (_, error) => reject(error)
              );
            },
            (_, error) => reject(error)
          );
        });
      });
    } catch (error) {
      console.error(t('services.map_cache.clear_all_error'), error);
      throw error;
    }
  }
  
  /**
   * Obtém informações sobre o cache
   */
  async getCacheInfo() {
    try {
      const [cacheSize, regions, settings] = await Promise.all([
        this.getTotalCacheSize(),
        this.getRegions(),
        this.loadSettings()
      ]);
      
      let tileCount = 0;
      regions.forEach(region => {
        tileCount += region.tileCount || 0;
      });
      
      return {
        size: cacheSize,
        regions: regions.length,
        tiles: tileCount,
        settings: this.settings,
        maxSize: this.settings.maxCacheSize,
        usagePercentage: (cacheSize / this.settings.maxCacheSize) * 100
      };
    } catch (error) {
      console.error(t('services.map_cache.info_error'), error);
      throw error;
    }
  }
  
  /**
   * Destrói o serviço liberando recursos
   */
  destroy() {
    if (this.localeChangeListener) {
      this.localeChangeListener();
      this.localeChangeListener = null;
    }
    
    this.initialized = false;
    this.db = null;
    this.currentDownloads = {};
    this.downloadQueue = [];
  }
}

export default new MapCacheService();