// FuelStationService.ts - Serviço para integração com postos de combustível
import axios from 'axios';
import { FuelStation, FuelPrice, FuelType } from '../types/fuel';
import { LatLng } from '../types/common';
import { secureStorage } from '../utils/storage';

class FuelStationService {
  private readonly API_URL = 'https://api.kingroad.com.br/fuel';
  private readonly CACHE_TTL = 30 * 60 * 1000; // 30 minutos
  
  /**
   * Busca postos de combustível próximos à localização atual
   * @param location Coordenadas atuais
   * @param radius Raio de busca em km (padrão: 5km)
   * @param filters Filtros de busca (e.g. tipos de combustível, serviços)
   * @returns Lista de postos próximos
   */
  async findNearbyStations(
    location: LatLng,
    radius: number = 5,
    filters?: {
      fuelTypes?: FuelType[],
      services?: string[],
      openNow?: boolean,
      minRating?: number
    }
  ): Promise<FuelStation[]> {
    try {
      // Verificar cache primeiro
      const cacheKey = `fuel_stations:${location.latitude},${location.longitude}:${radius}:${JSON.stringify(filters || {})}`;
      const cachedData = await this.getFromCache(cacheKey);
      
      if (cachedData) {
        return cachedData;
      }
      
      // Fazer requisição à API
      const response = await axios.get(`${this.API_URL}/stations/nearby`, {
        params: {
          lat: location.latitude,
          lng: location.longitude,
          radius,
          ...filters
        }
      });
      
      // Armazenar no cache
      await this.saveToCache(cacheKey, response.data.stations);
      
      return response.data.stations;
    } catch (error) {
      console.error('Erro ao buscar postos próximos:', error);
      throw new Error('Não foi possível obter os postos de combustível próximos');
    }
  }
  
  /**
   * Busca detalhes de um posto específico
   * @param stationId ID do posto
   * @returns Detalhes do posto
   */
  async getStationDetails(stationId: string): Promise<FuelStation> {
    try {
      const response = await axios.get(`${this.API_URL}/stations/${stationId}`);
      return response.data.station;
    } catch (error) {
      console.error(`Erro ao buscar detalhes do posto ${stationId}:`, error);
      throw new Error('Não foi possível obter os detalhes do posto');
    }
  }
  
  /**
   * Reporta preço de combustível para um posto
   * @param stationId ID do posto
   * @param price Informações de preço
   * @returns Confirmação do reporte
   */
  async reportPrice(stationId: string, price: {
    fuelType: FuelType,
    price: number,
    date: Date
  }): Promise<{ success: boolean, message: string }> {
    try {
      const response = await axios.post(`${this.API_URL}/prices/report`, {
        stationId,
        fuelType: price.fuelType,
        price: price.price,
        reportDate: price.date.toISOString()
      });
      
      return {
        success: true,
        message: 'Preço reportado com sucesso'
      };
    } catch (error) {
      console.error('Erro ao reportar preço:', error);
      throw new Error('Não foi possível reportar o preço do combustível');
    }
  }
  
  /**
   * Calcula economia em combustível para uma rota
   * @param distance Distância da rota em km
   * @param fuelConsumption Consumo do veículo (km/l)
   * @param stations Lista de postos para considerar
   * @param fuelType Tipo de combustível
   * @returns Melhores opções para abastecimento
   */
  calculateFuelSavings(
    distance: number,
    fuelConsumption: number,
    stations: FuelStation[],
    fuelType: FuelType = 'diesel'
  ): {
    bestOption: FuelStation | null,
    potentialSavings: number,
    comparisonTable: Array<{
      station: FuelStation,
      totalCost: number,
      savings: number
    }>
  } {
    // Filtrar postos com o tipo de combustível desejado
    const validStations = stations.filter(s => 
      s.fuels.some(f => f.type === fuelType)
    );
    
    if (validStations.length === 0) {
      return {
        bestOption: null,
        potentialSavings: 0,
        comparisonTable: []
      };
    }
    
    // Quantidade de combustível necessária
    const fuelNeeded = distance / fuelConsumption;
    
    // Calcular custo total para cada posto
    const comparisonTable = validStations.map(station => {
      const fuelPrice = station.fuels.find(f => f.type === fuelType)?.price || 0;
      const totalCost = fuelNeeded * fuelPrice;
      
      return {
        station,
        totalCost,
        savings: 0 // Será calculado depois
      };
    });
    
    // Ordenar por custo total (menor primeiro)
    comparisonTable.sort((a, b) => a.totalCost - b.totalCost);
    
    // Opção mais cara (para calcular economia potencial)
    const mostExpensive = comparisonTable[comparisonTable.length - 1];
    
    // Opção mais barata (melhor opção)
    const bestOption = comparisonTable[0];
    
    // Calcular economia para cada posto em relação ao mais caro
    comparisonTable.forEach(item => {
      item.savings = mostExpensive.totalCost - item.totalCost;
    });
    
    return {
      bestOption: bestOption.station,
      potentialSavings: bestOption.savings,
      comparisonTable
    };
  }
  
  /**
   * Busca dados do cache
   * @param key Chave de cache
   * @returns Dados armazenados ou null
   */
  private async getFromCache<T>(key: string): Promise<T | null> {
    try {
      const cachedItem = await secureStorage.getItem(key);
      
      if (!cachedItem) {
        return null;
      }
      
      const { data, timestamp } = JSON.parse(cachedItem);
      
      // Verificar se o cache expirou
      if (Date.now() - timestamp > this.CACHE_TTL) {
        await secureStorage.removeItem(key);
        return null;
      }
      
      return data;
    } catch (error) {
      console.error('Erro ao acessar cache:', error);
      return null;
    }
  }
  
  /**
   * Salva dados no cache
   * @param key Chave de cache
   * @param data Dados a serem armazenados
   */
  private async saveToCache<T>(key: string, data: T): Promise<void> {
    try {
      const cacheItem = {
        data,
        timestamp: Date.now()
      };
      
      await secureStorage.setItem(key, JSON.stringify(cacheItem));
    } catch (error) {
      console.error('Erro ao salvar no cache:', error);
    }
  }
}

export default new FuelStationService();