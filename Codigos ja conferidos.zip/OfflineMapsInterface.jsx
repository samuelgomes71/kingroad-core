import React, { useState } from 'react';
import { Map, Download, Trash, Settings, Globe, HardDrive, Check } from 'lucide-react';

const OfflineMapsInterface = () => {
  const [selectedContinent, setSelectedContinent] = useState(null);
  const [selectedCountry, setSelectedCountry] = useState(null);
  
  return (
    <div className="h-screen bg-[#121212]">
      {/* Barra superior */}
      <div className="bg-[#1E1E1E] p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-white text-xl font-bold">Mapas Offline</h1>
          <button className="p-2 rounded-lg bg-[#252525]">
            <Settings size={24} className="text-gray-300" />
          </button>
        </div>

        {/* Status de armazenamento */}
        <div className="mt-4 bg-[#252525] p-4 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center">
              <HardDrive size={20} className="text-gray-400 mr-2" />
              <span className="text-gray-200">Armazenamento</span>
            </div>
            <span className="text-gray-400">45.3 GB livres</span>
          </div>
          <div className="w-full bg-[#1E1E1E] rounded-full h-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '35%' }}></div>
          </div>
        </div>
      </div>

      {/* Seleção de continente */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {['Europa', 'América do Norte', 'América do Sul', 'Ásia', 'África', 'Oceania'].map((continent) => (
            <button
              key={continent}
              onClick={() => setSelectedContinent(continent)}
              className={`p-4 rounded-lg flex flex-col items-center ${
                selectedContinent === continent ? 'bg-blue-600' : 'bg-[#252525]'
              }`}
            >
              <Globe size={24} className="text-gray-200 mb-2" />
              <span className="text-gray-200">{continent}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Lista de países/regiões */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {/* País com download em progresso */}
          <div className="bg-[#1E1E1E] p-4 rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-gray-200 font-medium">França</h3>
                <p className="text-sm text-gray-400">12.3 GB</p>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-blue-400">45%</span>
                <Download size={20} className="text-blue-400" />
              </div>
            </div>
            <div className="w-full bg-[#252525] rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '45%' }}></div>
            </div>
          </div>

          {/* País instalado */}
          <div className="bg-[#1E1E1E] p-4 rounded-lg">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-gray-200 font-medium">Alemanha</h3>
                <p className="text-sm text-gray-400">15.7 GB</p>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 rounded-lg bg-[#252525]">
                  <Check size={20} className="text-green-500" />
                </button>
                <button className="p-2 rounded-lg bg-[#252525]">
                  <Trash size={20} className="text-red-500" />
                </button>
              </div>
            </div>
          </div>

          {/* País disponível */}
          <div className="bg-[#1E1E1E] p-4 rounded-lg">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-gray-200 font-medium">Espanha</h3>
                <p className="text-sm text-gray-400">10.1 GB</p>
              </div>
              <button className="p-2 rounded-lg bg-[#252525]">
                <Download size={20} className="text-gray-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Menu de configurações de download */}
      <div className="p-4 bg-[#1E1E1E]">
        <h3 className="text-gray-200 font-medium mb-3">Opções de Download</h3>
        <div className="space-y-3">
          <label className="flex items-center">
            <input type="checkbox" className="mr-3" />
            <span className="text-gray-300">Apenas dados de navegação</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="mr-3" />
            <span className="text-gray-300">Incluir áreas rurais</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="mr-3" />
            <span className="text-gray-300">Download apenas em Wi-Fi</span>
          </label>
        </div>
      </div>
    </div>
  );
};

export default OfflineMapsInterface;