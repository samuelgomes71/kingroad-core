// Sistema de Ajuste de Rotas
// app/src/main/kotlin/com/kingroad/routing/adjustment

class RouteAdjustmentManager(
    private val routeService: RouteService,
    private val roadService: RoadService,
    private val mapService: MapService
) {
    data class DragPoint(
        val originalPoint: Location,
        val newPoint: Location,
        val nearestRoad: Road?,
        val segmentIndex: Int
    )

    data class RouteSegment(
        val start: Location,
        val end: Location,
        val path: List<Location>,
        val isAdjusted: Boolean = false
    )

    // Gerenciar arrasto de rota
    suspend fun handleRouteDrag(
        originalRoute: Route,
        dragStart: Location,
        dragEnd: Location
    ): Route {
        // Encontrar ponto mais próximo na rota original
        val nearestPointOnRoute = findNearestPointOnRoute(
            route = originalRoute,
            point = dragStart
        )
        
        // Encontrar estrada mais próxima do ponto final
        val targetRoad = findNearestRoad(dragEnd)
        
        // Criar novo ponto de passagem
        val waypoint = createWaypoint(
            originalPoint = nearestPointOnRoute,
            draggedPoint = dragEnd,
            targetRoad = targetRoad
        )
        
        // Recalcular rota com novo ponto
        return recalculateRoute(
            originalRoute = originalRoute,
            waypoint = waypoint,
            segmentIndex = findSegmentIndex(originalRoute, nearestPointOnRoute)
        )
    }

    // Encontrar ponto mais próximo na rota
    private suspend fun findNearestPointOnRoute(
        route: Route,
        point: Location
    ): Location {
        var nearestPoint = route.path.first()
        var minDistance = Double.MAX_VALUE
        
        route.path.forEach { routePoint ->
            val distance = calculateDistance(point, routePoint)
            if (distance < minDistance) {
                minDistance = distance
                nearestPoint = routePoint
            }
        }
        
        return nearestPoint
    }

    // Encontrar estrada mais próxima
    private suspend fun findNearestRoad(
        point: Location,
        maxDistance: Double = 100.0 // metros
    ): Road? {
        val nearbyRoads = roadService.getNearbyRoads(
            location = point,
            radius = maxDistance
        )
        
        return nearbyRoads
            .minByOrNull { road ->
                calculateDistanceToRoad(point, road)
            }
    }

    // Criar ponto de passagem
    private suspend fun createWaypoint(
        originalPoint: Location,
        draggedPoint: Location,
        targetRoad: Road?
    ): Waypoint {
        // Se encontrou uma estrada próxima
        val snappedPoint = targetRoad?.let { road ->
            snapPointToRoad(draggedPoint, road)
        } ?: draggedPoint
        
        return Waypoint(
            location = snappedPoint,
            type = WaypointType.DRAGGED,
            originalPoint = originalPoint
        )
    }

    // Recalcular rota com novo ponto
    private suspend fun recalculateRoute(
        originalRoute: Route,
        waypoint: Waypoint,
        segmentIndex: Int
    ): Route {
        // Dividir rota em segmentos
        val (beforeSegment, afterSegment) = splitRouteAtIndex(
            route = originalRoute,
            index = segmentIndex
        )
        
        // Calcular novos segmentos
        val firstHalf = routeService.calculateRoute(
            start = beforeSegment.start,
            end = waypoint.location,
            preferences = originalRoute.preferences
        )
        
        val secondHalf = routeService.calculateRoute(
            start = waypoint.location,
            end = afterSegment.end,
            preferences = originalRoute.preferences
        )
        
        // Combinar segmentos
        return routeService.combineRoutes(
            firstHalf,
            secondHalf,
            waypoint
        )
    }

    // Verificar se novo ponto é válido
    private suspend fun validateNewPoint(
        point: Location,
        vehicle: Vehicle
    ): Boolean {
        val road = findNearestRoad(point) ?: return false
        
        return road.isAccessibleBy(vehicle) &&
               !road.hasRestrictions(vehicle) &&
               road.canHandleVehicle(vehicle)
    }

    // Ajustar ponto à estrada mais próxima
    private fun snapPointToRoad(
        point: Location,
        road: Road
    ): Location {
        val roadGeometry = road.geometry
        return roadGeometry.findClosestPoint(point)
    }

    // Dividir rota em segmentos
    private fun splitRouteAtIndex(
        route: Route,
        index: Int
    ): Pair<RouteSegment, RouteSegment> {
        val beforePoints = route.path.subList(0, index + 1)
        val afterPoints = route.path.subList(index, route.path.size)
        
        return Pair(
            RouteSegment(
                start = route.start,
                end = route.path[index],
                path = beforePoints
            ),
            RouteSegment(
                start = route.path[index],
                end = route.end,
                path = afterPoints
            )
        )
    }

    companion object {
        const val MIN_DRAG_DISTANCE = 10.0 // metros
        const val MAX_SNAP_DISTANCE = 100.0 // metros
        const val MIN_SEGMENT_LENGTH = 1000.0 // metros
    }
}

// Tipos de pontos de passagem
enum class WaypointType {
    MANUAL,     // Adicionado manualmente
    DRAGGED,    // Criado por arrasto
    REQUIRED,   // Ponto obrigatório
    SUGGESTED   // Sugerido pelo sistema
}

// Extensões úteis
fun Road.isAccessibleBy(vehicle: Vehicle): Boolean {
    return this.width >= vehicle.width &&
           this.height >= vehicle.height &&
           this.weight >= vehicle.weight
}

fun Road.canHandleVehicle(vehicle: Vehicle): Boolean {
    return this.type != RoadType.RESIDENTIAL &&
           this.surface.canHandle(vehicle) &&
           this.turningRadius >= vehicle.turningRadius
}