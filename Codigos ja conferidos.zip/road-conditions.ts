// Parte 1: Configuração e rota POST para reportar condições da estrada
import express from 'express';
import { body, param, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { RoadConditionRepository } from '../repositories/roadConditionRepository';
import { broadcastAlert } from '../services/alertService';
import { geofire } from '../utils/geofire';

const router = express.Router();
const roadConditionRepo = new RoadConditionRepository();

/**
 * @route   POST /api/road-conditions
 * @desc    Reportar uma nova condição de estrada
 * @access  Private (requer autenticação)
 */
router.post(
  '/',
  authenticate,
  [
    body('latitude').isFloat({ min: -90, max: 90 }).withMessage('Latitude inválida'),
    body('longitude').isFloat({ min: -180, max: 180 }).withMessage('Longitude inválida'),
    body('type').isIn([
      'accident',
      'construction',
      'police',
      'hazard',
      'road_closure',
      'traffic',
      'poor_road',
      'flooding',
      'landslide'
    ]).withMessage('Tipo de condição inválido'),
    body('description').optional().isString().isLength({ min: 3, max: 280 }),
    body('severity').isIn(['low', 'medium', 'high']).withMessage('Severidade inválida'),
    body('expectedDuration').optional().isNumeric().withMessage('Duração esperada inválida'),
    body('imageUrl').optional().isURL().withMessage('URL de imagem inválida')
  ],
  async (req, res) => {
    // Validar input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const {
        latitude,
        longitude,
        type,
        description,
        severity,
        expectedDuration,
        imageUrl
      } = req.body;

      // Obter endereço aproximado da coordenada
      const location = await geofire.getAddressFromCoords(latitude, longitude);

      // Criar novo relatório de condição
      const newCondition = await roadConditionRepo.create({
        userId: req.user.id,
        latitude,
        longitude,
        type,
        description: description || '',
        severity,
        location,
        expectedDuration: expectedDuration || null,
        imageUrl: imageUrl || null,
        createdAt: new Date(),
        upvotes: 0,
        downvotes: 0,
        confirmedBy: [req.user.id]
      });

      // Broadcast para usuários próximos
      if (severity === 'high') {
        await broadcastAlert(newCondition, 10); // 10km raio
      }

      res.status(201).json(newCondition);
    } catch (error) {
      console.error('Erro ao criar relatório de condição:', error);
      res.status(500).json({ message: 'Erro ao processar relatório de condição' });
    }
  }
);