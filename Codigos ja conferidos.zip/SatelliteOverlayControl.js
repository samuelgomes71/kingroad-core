import React, { useState, useEffect } from 'react';
import { Layers, Eye, EyeOff, Image, Map, Sliders, Sun, CloudRain, Thermometer } from 'lucide-react';

// Botão e controle para ativar camadas de imagem de satélite na navegação
// Implementa o componente futuro descrito em globalRecommendations: "SatelliteOverlayControl.js"

const SatelliteOverlayControl = ({
  onToggleOverlay = () => {},
  onChangeOpacity = () => {},
  onSelectLayer = () => {},
  language = 'pt',
  position = 'top-right', // top-left, top-right, bottom-left, bottom-right
  initialState = {
    active: false,
    opacity: 0.5,
    currentLayer: 'satellite'
  }
}) => {
  // Estados para controlar o componente
  const [isOpen, setIsOpen] = useState(false);
  const [isActive, setIsActive] = useState(initialState.active);
  const [opacity, setOpacity] = useState(initialState.opacity);
  const [currentLayer, setCurrentLayer] = useState(initialState.currentLayer);
  
  // Traduções para diferentes idiomas
  const translations = {
    pt: {
      title: 'Camadas de Satélite',
      satellite: 'Satélite',
      hybrid: 'Híbrido',
      terrain: 'Terreno',
      traffic: 'Tráfego',
      weather: 'Clima',
      heatmap: 'Mapa de Calor',
      opacity: 'Opacidade',
      showSatellite: 'Mostrar camada de satélite',
      hideSatellite: 'Esconder camada de satélite'
    },
    en: {
      title: 'Satellite Layers',
      satellite: 'Satellite',
      hybrid: 'Hybrid',
      terrain: 'Terrain',
      traffic: 'Traffic',
      weather: 'Weather',
      heatmap: 'Heatmap',
      opacity: 'Opacity',
      showSatellite: 'Show satellite layer',
      hideSatellite: 'Hide satellite layer'
    },
    es: {
      title: 'Capas de Satélite',
      satellite: 'Satélite',
      hybrid: 'Híbrido',
      terrain: 'Terreno',
      traffic: 'Tráfico',
      weather: 'Clima',
      heatmap: 'Mapa de Calor',
      opacity: 'Opacidad',
      showSatellite: 'Mostrar capa de satélite',
      hideSatellite: 'Ocultar capa de satélite'
    }
  };
  
  // Texto conforme o idioma, com fallback para inglês
  const text = translations[language] || translations.en;
  
  // Definição das camadas disponíveis
  const availableLayers = [
    { 
      id: 'satellite', 
      name: text.satellite, 
      icon: <Image size={18} />, 
      color: '#4A90E2'
    },
    { 
      id: 'hybrid', 
      name: text.hybrid, 
      icon: <Layers size={18} />, 
      color: '#7ED321' 
    },
    { 
      id: 'terrain', 
      name: text.terrain, 
      icon: <Map size={18} />, 
      color: '#D0021B' 
    },
    { 
      id: 'traffic', 
      name: text.traffic, 
      icon: <Sliders size={18} />, 
      color: '#F5A623' 
    },
    { 
      id: 'weather', 
      name: text.weather, 
      icon: <CloudRain size={18} />, 
      color: '#50E3C2' 
    },
    { 
      id: 'heatmap', 
      name: text.heatmap, 
      icon: <Thermometer size={18} />, 
      color: '#BD10E0' 
    }
  ];
  
  // Camada atual
  const layer = availableLayers.find(layer => layer.id === currentLayer) || availableLayers[0];
  
  // Define classes CSS com base na posição
  const positionClasses = {
    'top-left': 'top-4 left-4',
    'top-right': 'top-4 right-4',
    'bottom-left': 'bottom-20 left-4', // Espaço para outros controles
    'bottom-right': 'bottom-20 right-4' // Espaço para outros controles
  };
  
  // Efeito para atualizar estados quando as props mudam
  useEffect(() => {
    if (initialState) {
      setIsActive(initialState.active);
      setOpacity(initialState.opacity);
      setCurrentLayer(initialState.currentLayer);
    }
  }, [initialState]);
  
  // Função para alternar a visibilidade do menu
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  
  // Função para alternar a ativação da camada
  const toggleActive = () => {
    const newActiveState = !isActive;
    setIsActive(newActiveState);
    onToggleOverlay(newActiveState, currentLayer);
  };
  
  // Função para alterar a opacidade
  const handleOpacityChange = (e) => {
    const newOpacity = parseFloat(e.target.value);
    setOpacity(newOpacity);
    onChangeOpacity(newOpacity);
  };
  
  // Função para selecionar uma camada
  const selectLayer = (layerId) => {
    setCurrentLayer(layerId);
    onSelectLayer(layerId, opacity);
  };
  
  // Renderiza o menu de controle
  const renderMenu = () => {
    if (!isOpen) return null;
    
    return (
      <div className={`absolute ${position.includes('right') ? 'right-0' : 'left-0'} top-full mt-2 w-64 bg-white rounded-lg shadow-xl overflow-hidden z-40`}>
        <div className="p-3 border-b border-gray-200">
          <h3 className="font-medium text-gray-800">{text.title}</h3>
        </div>
        
        {/* Lista de camadas disponíveis */}
        <div className="p-3 grid grid-cols-2 gap-2">
          {availableLayers.map((layer) => (
            <button
              key={layer.id}
              onClick={() => selectLayer(layer.id)}
              className={`flex items-center p-2 rounded-md ${
                currentLayer === layer.id 
                  ? 'bg-blue-50 text-blue-600' 
                  : 'hover:bg-gray-50'
              }`}
            >
              <div 
                className="w-6 h-6 rounded-full flex items-center justify-center mr-2"
                style={{ backgroundColor: layer.color, opacity: 0.2 }}
              >
                <div 
                  className="text-white"
                  style={{ color: layer.color }}
                >
                  {layer.icon}
                </div>
              </div>
              <span className="text-sm">{layer.name}</span>
            </button>
          ))}
        </div>
        
        {/* Controle de opacidade */}
        <div className="p-3 border-t border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm text-gray-600">{text.opacity}</label>
            <span className="text-sm text-gray-800">{Math.round(opacity * 100)}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={opacity}
            onChange={handleOpacityChange}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
    );
  };
  
  return (
    <div className={`fixed z-30 ${positionClasses[position]}`}>
      <div className="relative">
        {/* Botão principal */}
        <button
          onClick={toggleMenu}
          className="p-3 bg-white rounded-lg shadow-md hover:bg-gray-50 transition-colors flex items-center"
        >
          <Layers size={20} className="text-gray-700" />
        </button>
        
        {/* Menu de controle */}
        {renderMenu()}
      </div>
      
      {/* Botão de toggle rápido para ativar/desativar a camada atual */}
      <button
        onClick={toggleActive}
        className={`mt-2 p-3 rounded-lg shadow-md transition-colors flex items-center ${
          isActive 
            ? 'bg-blue-600 text-white hover:bg-blue-700' 
            : 'bg-white text-gray-700 hover:bg-gray-50'
        }`}
        aria-label={isActive ? text.hideSatellite : text.showSatellite}
        style={{
          backgroundColor: isActive ? layer.color : '#FFFFFF',
          color: isActive ? '#FFFFFF' : layer.color
        }}
      >
        {isActive ? (
          <EyeOff size={20} />
        ) : (
          <Eye size={20} />
        )}
      </button>
    </div>
  );
};

export default SatelliteOverlayControl;