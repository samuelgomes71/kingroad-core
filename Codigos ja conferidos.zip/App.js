import React, { useState, useEffect } from 'react';
import { AppProvider, useAppContext } from './context/AppContext';
import MainNavigationScreen from './components/MainNavigationScreen';
import MapViewModes from './components/MapViewModes';
import AlertSubmissionScreen from './components/AlertSubmissionScreen';
import MapVisualizationPreview from './components/MapVisualizationPreview';
import LoadingOverlay from './components/LoadingOverlay';
import ErrorBoundary from './components/ErrorBoundary';
import { registerCarpoolPOI } from './poi/CarpoolPOIHandler';

/**
 * Componente principal do aplicativo KingRoad
 */
const AppContent = () => {
  const { loading, errors, clearErrors, loadSecurityAlerts, loadSavedRoutes } = useAppContext();
  const [showAlertScreen, setShowAlertScreen] = useState(false);
  
  // Carrega dados iniciais ao montar o componente
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        await loadSecurityAlerts();
        await loadSavedRoutes();
        
        // Registrar o POI de Carpool
        registerCarpoolPOI();
      } catch (error) {
        console.error('Erro ao carregar dados iniciais:', error);
      }
    };
    
    loadInitialData();
  }, [loadSecurityAlerts, loadSavedRoutes]);

  // Determina se deve mostrar overlay de carregamento
  const isLoading = Object.values(loading).some(status => status);
  
  // Manipulador para fechar a tela de alerta
  const handleCloseAlertScreen = () => {
    setShowAlertScreen(false);
  };
  
  // Manipulador para mostrar a tela de alerta
  const handleShowAlertScreen = () => {
    setShowAlertScreen(true);
  };

  return (
    <ErrorBoundary>
      <div className="app bg-gray-900 min-h-screen relative">
        {/* Overlay de carregamento */}
        {isLoading && <LoadingOverlay />}
        
        {/* Componentes principais */}
        <MainNavigationScreen onAddAlert={handleShowAlertScreen} />
        <MapViewModes />
        
        {/* Modal para envio de alertas */}
        {showAlertScreen && (
          <div className="fixed inset-0 z-50 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="relative w-full max-w-md">
              <AlertSubmissionScreen onClose={handleCloseAlertScreen} />
            </div>
          </div>
        )}
        
        {/* Tratamento de erros globais */}
        {Object.values(errors).some(error => error) && (
          <div className="fixed bottom-4 left-4 right-4 bg-red-800 text-white p-4 rounded-lg shadow-lg z-50">
            <div className="flex justify-between">
              <h3 className="font-bold">Erro na aplicação</h3>
              <button onClick={clearErrors} className="text-white">×</button>
            </div>
            <div className="mt-2">
              {Object.entries(errors)
                .filter(([key, value]) => value)
                .map(([key, value]) => (
                  <p key={key} className="text-sm">
                    <strong>{key}:</strong> {value}
                  </p>
                ))}
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

/**
 * Componente raiz que envolve a aplicação com o provedor de contexto
 */
const App = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;