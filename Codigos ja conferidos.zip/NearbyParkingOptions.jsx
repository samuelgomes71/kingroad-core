import React, { useState } from 'react';

const NearbyParkingOptions = () => {
  const [expandedOption, setExpandedOption] = useState(null);
  
  // Dados de exemplo para o preview
  const parkingOptions = [
    {
      parkingSpot: {
        id: "park1",
        name: "Truck Stop Express",
        spotType: "TRUCK_STOP",
        features: ["RESTROOMS", "SHOWERS", "FUEL", "RESTAURANT"],
        totalSpaces: 28,
        availableSpaces: 12,
        hasPaidSpaces: false,
        pricePerHour: null
      },
      distanceToPoi: 120,
      securityRating: 8.7,
      walkingTimeMins: 2
    },
    {
      parkingSpot: {
        id: "park2",
        name: "Estacionamento Seguro 24h",
        spotType: "DEDICATED_PARKING",
        features: ["RESTROOMS", "SECURITY_SURVEILLANCE", "LIGHTED_AREA", "FENCED_AREA"],
        totalSpaces: 15,
        availableSpaces: 5,
        hasPaidSpaces: true,
        pricePerHour: 5.50
      },
      distanceToPoi: 180,
      securityRating: 9.2,
      walkingTimeMins: 3
    },
    {
      parkingSpot: {
        id: "park3",
        name: "Posto Shell Caminhoneiros",
        spotType: "GAS_STATION",
        features: ["RESTROOMS", "CONVENIENCE_STORE", "FUEL"],
        totalSpaces: 8,
        availableSpaces: 2,
        hasPaidSpaces: false,
        pricePerHour: null
      },
      distanceToPoi: 195,
      securityRating: 7.5,
      walkingTimeMins: 4
    }
  ];

  // Função para mostrar detalhes de um estacionamento
  const toggleDetails = (id) => {
    if (expandedOption === id) {
      setExpandedOption(null);
    } else {
      setExpandedOption(id);
    }
  };

  // Renderiza um ícone para o tipo de estacionamento
  const renderSpotTypeIcon = (type) => {
    switch(type) {
      case "TRUCK_STOP": return "🚚";
      case "GAS_STATION": return "⛽";
      case "DEDICATED_PARKING": return "🅿️";
      default: return "🅿️";
    }
  };

  // Renderiza ícones para os recursos disponíveis
  const renderFeatureIcons = (features) => {
    const icons = {
      "RESTROOMS": "🚻",
      "SHOWERS": "🚿",
      "RESTAURANT": "🍽️",
      "CONVENIENCE_STORE": "🏪",
      "FUEL": "⛽",
      "SECURITY_SURVEILLANCE": "📹",
      "LIGHTED_AREA": "💡",
      "FENCED_AREA": "🔒"
    };
    
    return features.map(feature => (
      <span key={feature} className="mr-1" title={feature}>
        {icons[feature] || "✓"}
      </span>
    ));
  };

  return (
    <div className="p-4 max-w-lg mx-auto bg-gray-50 rounded-lg">
      <div className="mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <span className="text-blue-600 mr-2">📍</span>
          Estacionamentos Próximos
        </h2>
        <p className="text-gray-600 ml-6">
          Opções seguras para estacionar próximo ao Tim Hortons (raio de 200m)
        </p>
      </div>

      {parkingOptions.map(option => (
        <div 
          key={option.parkingSpot.id}
          className="mb-3 bg-white rounded-lg shadow-md overflow-hidden"
        >
          <div 
            className="px-4 py-3 flex justify-between items-center cursor-pointer"
            onClick={() => toggleDetails(option.parkingSpot.id)}
          >
            <div className="flex items-center">
              <span className="text-xl mr-2">
                {renderSpotTypeIcon(option.parkingSpot.spotType)}
              </span>
              <div>
                <h3 className="font-semibold">{option.parkingSpot.name}</h3>
                <div className="text-sm text-gray-600 flex">
                  {renderFeatureIcons(option.parkingSpot.features)}
                </div>
              </div>
            </div>
            <div className="flex items-center">
              <div className="mr-3 text-right">
                <div className="text-sm">
                  <span className="font-medium">{option.distanceToPoi}m</span>
                  <span className="mx-1">•</span>
                  <span>{option.walkingTimeMins} min</span>
                </div>
                <div className="flex items-center justify-end mt-1">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    option.securityRating >= 8 
                      ? 'bg-green-100 text-green-800' 
                      : option.securityRating >= 6 
                        ? 'bg-yellow-100 text-yellow-800' 
                        : 'bg-red-100 text-red-800'
                  }`}>
                    Segurança: {option.securityRating.toFixed(1)}
                  </span>
                </div>
              </div>
              <span className="text-gray-400">
                {expandedOption === option.parkingSpot.id ? '▲' : '▼'}
              </span>
            </div>
          </div>
          
          {expandedOption === option.parkingSpot.id && (
            <div className="px-4 py-3 border-t border-gray-100">
              <div className="flex justify-between mb-2">
                <div>
                  <span className="text-sm text-gray-600">Vagas disponíveis:</span>
                  <span className="ml-2 font-semibold">
                    {option.parkingSpot.availableSpaces}/{option.parkingSpot.totalSpaces}
                  </span>
                </div>
                <div>
                  {option.parkingSpot.hasPaidSpaces ? (
                    <span className="text-sm text-orange-600">
                      Pago: R$ {option.parkingSpot.pricePerHour.toFixed(2)}/hora
                    </span>
                  ) : (
                    <span className="text-sm text-green-600">Estacionamento Gratuito</span>
                  )}
                </div>
              </div>
              
              <button 
                className="w-full mt-2 py-2 bg-blue-600 text-white rounded-md flex items-center justify-center"
              >
                <span className="mr-2">🧭</span> Navegar até este estacionamento
              </button>
            </div>
          )}
        </div>
      ))}
      
      <button className="mt-4 w-full py-3 border-2 border-dashed border-blue-300 text-blue-600 rounded-lg flex items-center justify-center">
        <span className="mr-2">➕</span> Adicionar novo estacionamento
      </button>
    </div>
  );
};

export default NearbyParkingOptions;