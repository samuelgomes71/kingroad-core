package com.kingroad.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.kingroad.database.Alert
import com.kingroad.database.AlertDao
import com.kingroad.database.Document
import com.kingroad.database.DocumentDao
import com.kingroad.database.Feedback
import com.kingroad.database.FeedbackDao
import com.kingroad.database.POI
import com.kingroad.database.POIDao
import com.kingroad.database.UserPreferences
import com.kingroad.utils.FileCompressor
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Serviço que observa eventos no banco local e envia automaticamente para o backend
 * via API REST ou Firebase (alertas, POIs, feedbacks, etc.)
 */
class RealtimeSyncService : Service() {
    companion object {
        private const val TAG = "RealtimeSyncService"
        
        // Intervalo de sincronização base (15 segundos)
        private const val BASE_SYNC_INTERVAL = 15000L
        
        // Intervalo de verificação de itens para sincronizar (5 segundos)
        private const val CHECK_INTERVAL = 5000L
        
        // Tempo máximo para wake lock (10 minutos)
        private const val MAX_WAKE_LOCK_TIME = 10 * 60 * 1000L
        
        // Tipos de conexão
        enum class ConnectionType {
            NONE,
            CELLULAR,
            WIFI,
            ETHERNET,
            OTHER
        }
        
        // Valores para política de sincronização
        enum class SyncPolicy {
            WIFI_ONLY,        // Apenas em WiFi
            ANY_CONNECTION,   // Qualquer conexão
            MANUAL_ONLY       // Apenas manual
        }
        
        // Prioridades de sincronização
        enum class SyncPriority {
            HIGH,     // Alta prioridade (alertas)
            MEDIUM,   // Média prioridade (POIs, feedbacks)
            LOW       // Baixa prioridade (documentos, imagens)
        }
    }
    
    // Estado do serviço
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()
    
    // Estatísticas de sincronização
    private val _syncStats = MutableLiveData(SyncStats())
    val syncStats: LiveData<SyncStats> = _syncStats
    
    // Binder para comunicação com os componentes da aplicação
    private val binder = LocalBinder()
    
    // Coroutine scope para operações assíncronas
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    // DAOs para acesso ao banco de dados
    private lateinit var alertDao: AlertDao
    private lateinit var poiDao: POIDao
    private lateinit var feedbackDao: FeedbackDao
    private lateinit var documentDao: DocumentDao
    private lateinit var userPreferences: UserPreferences
    
    // APIs e configurações
    private lateinit var apiBaseUrl: String
    private var apiKey: String? = null
    private var firebaseEnabled = false
    private var fileCompressor: FileCompressor? = null
    
    // Controle do ciclo de vida
    private val isRunning = AtomicBoolean(false)
    private var syncJob: kotlinx.coroutines.Job? = null
    
    // Controle de redes
    private lateinit var connectivityManager: ConnectivityManager
    private var currentConnectionType = ConnectionType.NONE
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    
    // Política de sincronização
    private var syncPolicy = SyncPolicy.ANY_CONNECTION
    private var syncOnMeteredConnection = true
    private var syncLowPriorityOnMetered = false
    
    // Retry e throttling
    private val syncRetryCount = AtomicInteger(0)
    private val maxRetries = 3
    private var retryBackoffTime = 5000L
    
    // Wake lock para garantir que o sistema não dorme durante sincronização
    private var wakeLock: PowerManager.WakeLock? = null
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Serviço de sincronização criado")
        
        // Inicializa o gerenciador de conectividade
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        
        // Registra callback para mudanças de rede
        registerNetworkCallback()
        
        // Inicializa wake lock
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "KingRoad:RealtimeSyncWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Serviço de sincronização iniciado")
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    override fun onDestroy() {
        Log.d(TAG, "Serviço de sincronização destruído")
        
        // Cancela trabalhos em execução
        stopSync()
        
        // Cancela o escopo de coroutines
        serviceScope.cancel()
        
        // Libera wake lock se estiver ativo
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        
        // Remove callback de rede
        unregisterNetworkCallback()
        
        super.onDestroy()
    }

    /**
     * Inner class para fornecer interface para os clientes do serviço
     */
    inner class LocalBinder : Binder() {
        fun getService(): RealtimeSyncService = this@RealtimeSyncService
    }
    
    /**
     * Inicializa o serviço com as dependências necessárias
     */
    fun initialize(
        alertDao: AlertDao,
        poiDao: POIDao,
        feedbackDao: FeedbackDao,
        documentDao: DocumentDao,
        userPreferences: UserPreferences,
        apiBaseUrl: String,
        apiKey: String? = null,
        firebaseEnabled: Boolean = false,
        fileCompressor: FileCompressor? = null
    ) {
        this.alertDao = alertDao
        this.poiDao = poiDao
        this.feedbackDao = feedbackDao
        this.documentDao = documentDao
        this.userPreferences = userPreferences
        this.apiBaseUrl = apiBaseUrl
        this.apiKey = apiKey
        this.firebaseEnabled = firebaseEnabled
        this.fileCompressor = fileCompressor
        
        // Carrega configurações
        serviceScope.launch {
            loadSyncPreferences()
        }
        
        Log.d(TAG, "Serviço de sincronização inicializado")
    }
    
    /**
     * Carrega as preferências de sincronização do usuário
     */
    private suspend fun loadSyncPreferences() {
        try {
            val prefs = userPreferences.getSyncPreferences()
            
            // Define política de sincronização
            syncPolicy = when (prefs.syncMode) {
                "wifi_only" -> SyncPolicy.WIFI_ONLY
                "any_connection" -> SyncPolicy.ANY_CONNECTION
                "manual_only" -> SyncPolicy.MANUAL_ONLY
                else -> SyncPolicy.ANY_CONNECTION // Default
            }
            
            // Define outras configurações
            syncOnMeteredConnection = prefs.syncOnMeteredConnection
            syncLowPriorityOnMetered = prefs.syncLowPriorityOnMetered
            
            Log.d(TAG, "Preferências de sincronização carregadas: $syncPolicy")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao carregar preferências de sincronização: ${e.message}")
            
            // Valores padrão em caso de erro
            syncPolicy = SyncPolicy.ANY_CONNECTION
            syncOnMeteredConnection = true
            syncLowPriorityOnMetered = false
        }
    }
    
    /**
     * Inicia a sincronização em segundo plano
     */
    fun startSync() {
        // Verifica se já está rodando
        if (isRunning.getAndSet(true)) {
            Log.d(TAG, "Sincronização já está em andamento")
            return
        }
        
        // Inicializa estatísticas
        resetSyncStats()
        
        // Verifica a política de sincronização
        if (syncPolicy == SyncPolicy.MANUAL_ONLY) {
            Log.d(TAG, "Política de sincronização definida como apenas manual")
            _syncState.value = SyncState.ManualOnly
            isRunning.set(false)
            return
        }
        
        // Verifica conectividade
        if (!isNetworkAvailable()) {
            Log.d(TAG, "Sem conexão de rede disponível")
            _syncState.value = SyncState.NoConnectivity
            isRunning.set(false)
            return
        }
        
        // Verifica política de WiFi
        if (syncPolicy == SyncPolicy.WIFI_ONLY && currentConnectionType != ConnectionType.WIFI) {
            Log.d(TAG, "Política de sincronização requer WiFi, mas conexão atual é $currentConnectionType")
            _syncState.value = SyncState.WaitingForWifi
            isRunning.set(false)
            return
        }
        
        // Adquire wake lock para garantir que o processo continue mesmo com a tela desligada
        acquireWakeLock()
        
        // Inicia o job de sincronização
        syncJob = serviceScope.launch {
            try {
                Log.d(TAG, "Iniciando sincronização")
                _syncState.value = SyncState.Syncing
                
                // Loop de sincronização contínua
                while (isActive && isRunning.get()) {
                    // Verifica se há itens para sincronizar de alta prioridade
                    syncHighPriorityItems()
                    
                    // Verifica se há itens para sincronizar de média prioridade
                    syncMediumPriorityItems()
                    
                    // Verifica se há itens para sincronizar de baixa prioridade
                    // (apenas em WiFi ou se configurado para sincronizar em conexões limitadas)
                    if (currentConnectionType == ConnectionType.WIFI || syncLowPriorityOnMetered) {
                        syncLowPriorityItems()
                    }
                    
                    // Verifica se ainda há itens para sincronizar
                    if (await hasItemsToSync()) {
                        // Permanece ativo, verificando em intervalos regulares
                        delay(CHECK_INTERVAL)
                    } else {
                        // Nada mais para sincronizar, finaliza
                        Log.d(TAG, "Não há mais itens para sincronizar, finalizando")
                        break
                    }
                }
                
                // Atualiza estado para idle
                _syncState.value = SyncState.Idle
                updateSyncStats()
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro durante sincronização: ${e.message}")
                _syncState.value = SyncState.Error(e.message ?: "Erro desconhecido")
                
                // Tenta novamente se não excedeu o limite de tentativas
                if (syncRetryCount.incrementAndGet() <= maxRetries) {
                    Log.d(TAG, "Agendando nova tentativa de sincronização (${syncRetryCount.get()}/$maxRetries)")
                    delay(retryBackoffTime)
                    startSync()
                } else {
                    Log.e(TAG, "Excedido número máximo de tentativas de sincronização")
                }
            } finally {
                // Finaliza
                isRunning.set(false)
                syncJob = null
                releaseWakeLock()
            }
        }
    }
    
    /**
     * Para a sincronização em andamento
     */
    fun stopSync() {
        if (isRunning.getAndSet(false)) {
            syncJob?.cancel()
            syncJob = null
            releaseWakeLock()
            _syncState.value = SyncState.Idle
            Log.d(TAG, "Sincronização interrompida manualmente")
        }
    }
    
    /**
     * Força a sincronização de um item específico (usado para sincronização manual)
     */
    fun forceSyncItem(itemType: String, itemId: String): Boolean {
        // Não inicia uma sincronização completa, apenas força um item específico
        if (_syncState.value is SyncState.Syncing) {
            Log.d(TAG, "Sincronização já em andamento, item será sincronizado no fluxo normal")
            return false
        }
        
        // Verifica conectividade
        if (!isNetworkAvailable()) {
            Log.d(TAG, "Sem conexão de rede disponível")
            _syncState.value = SyncState.NoConnectivity
            return false
        }
        
        // Força a sincronização específica
        serviceScope.launch {
            try {
                _syncState.value = SyncState.Syncing
                
                when (itemType) {
                    "alert" -> syncAlert(itemId)
                    "poi" -> syncPOI(itemId)
                    "feedback" -> syncFeedback(itemId)
                    "document" -> syncDocument(itemId)
                    else -> {
                        Log.e(TAG, "Tipo de item desconhecido: $itemType")
                        _syncState.value = SyncState.Error("Tipo de item desconhecido: $itemType")
                        return@launch
                    }
                }
                
                _syncState.value = SyncState.Idle
                updateSyncStats()
                Log.d(TAG, "Sincronização forçada concluída para $itemType $itemId")
            } catch (e: Exception) {
                Log.e(TAG, "Erro durante sincronização forçada: ${e.message}")
                _syncState.value = SyncState.Error(e.message ?: "Erro desconhecido")
            }
        }
        
        return true
    }
    
    /**
     * Verifica se há itens para sincronizar no banco de dados local
     */
    private suspend fun hasItemsToSync(): Boolean = withContext(Dispatchers.IO) {
        // Conta itens não sincronizados nos vários DAOs
        val alertCount = alertDao.getUnsyncedCount()
        val poiCount = poiDao.getUnsyncedCount()
        val feedbackCount = feedbackDao.getUnsyncedCount()
        val documentCount = documentDao.getUnsyncedCount()
        
        // Atualiza contagem nas estatísticas
        _syncStats.postValue(_syncStats.value?.copy(
            pendingAlerts = alertCount,
            pendingPOIs = poiCount,
            pendingFeedbacks = feedbackCount,
            pendingDocuments = documentCount
        ))
        
        return@withContext alertCount > 0 || poiCount > 0 || feedbackCount > 0 || documentCount > 0
    }
    
    /**
     * Sincroniza itens de alta prioridade (alertas, etc.)
     */
    private suspend fun syncHighPriorityItems() = withContext(Dispatchers.IO) {
        try {
            // Alertas são considerados alta prioridade
            val unsyncedAlerts = alertDao.getUnsyncedAlerts()
            
            if (unsyncedAlerts.isNotEmpty()) {
                Log.d(TAG, "Sincronizando ${unsyncedAlerts.size} alertas")
                
                for (alert in unsyncedAlerts) {
                    syncAlert(alert.id)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar itens de alta prioridade: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza itens de média prioridade (POIs, feedbacks, etc.)
     */
    private suspend fun syncMediumPriorityItems() = withContext(Dispatchers.IO) {
        try {
            // POIs
            val unsyncedPOIs = poiDao.getUnsyncedPOIs()
            if (unsyncedPOIs.isNotEmpty()) {
                Log.d(TAG, "Sincronizando ${unsyncedPOIs.size} POIs")
                
                for (poi in unsyncedPOIs) {
                    syncPOI(poi.id)
                }
            }
            
            // Feedbacks
            val unsyncedFeedbacks = feedbackDao.getUnsyncedFeedbacks()
            if (unsyncedFeedbacks.isNotEmpty()) {
                Log.d(TAG, "Sincronizando ${unsyncedFeedbacks.size} feedbacks")
                
                for (feedback in unsyncedFeedbacks) {
                    syncFeedback(feedback.id)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar itens de média prioridade: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza itens de baixa prioridade (documentos, imagens, etc.)
     */
    private suspend fun syncLowPriorityItems() = withContext(Dispatchers.IO) {
        try {
            // Documentos
            val unsyncedDocuments = documentDao.getUnsyncedDocuments()
            if (unsyncedDocuments.isNotEmpty()) {
                Log.d(TAG, "Sincronizando ${unsyncedDocuments.size} documentos")
                
                for (document in unsyncedDocuments) {
                    syncDocument(document.id)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar itens de baixa prioridade: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza um alerta específico
     */
    private suspend fun syncAlert(alertId: String) = withContext(Dispatchers.IO) {
        try {
            val alert = alertDao.getById(alertId) ?: throw IllegalArgumentException("Alerta não encontrado: $alertId")
            
            // Verifica se usa Firebase ou API
            if (firebaseEnabled) {
                // Sincroniza via Firebase
                syncAlertViaFirebase(alert)
            } else {
                // Sincroniza via API REST
                syncAlertViaRest(alert)
            }
            
            // Atualiza estatísticas
            _syncStats.postValue(_syncStats.value?.copy(
                syncedAlerts = _syncStats.value?.syncedAlerts?.plus(1) ?: 1
            ))
            
            Log.d(TAG, "Alerta sincronizado com sucesso: $alertId")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar alerta $alertId: ${e.message}")
            _syncStats.postValue(_syncStats.value?.copy(
                failedAlerts = _syncStats.value?.failedAlerts?.plus(1) ?: 1
            ))
            throw e
        }
    }
    
    /**
     * Sincroniza um POI específico
     */
    private suspend fun syncPOI(poiId: String) = withContext(Dispatchers.IO) {
        try {
            val poi = poiDao.getById(poiId) ?: throw IllegalArgumentException("POI não encontrado: $poiId")
            
            // Verifica se usa Firebase ou API
            if (firebaseEnabled) {
                // Sincroniza via Firebase
                syncPOIViaFirebase(poi)
            } else {
                // Sincroniza via API REST
                syncPOIViaRest(poi)
            }
            
            // Atualiza estatísticas
            _syncStats.postValue(_syncStats.value?.copy(
                syncedPOIs = _syncStats.value?.syncedPOIs?.plus(1) ?: 1
            ))
            
            Log.d(TAG, "POI sincronizado com sucesso: $poiId")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar POI $poiId: ${e.message}")
            _syncStats.postValue(_syncStats.value?.copy(
                failedPOIs = _syncStats.value?.failedPOIs?.plus(1) ?: 1
            ))
            throw e
        }
    }
    
    /**
     * Sincroniza um feedback específico
     */
    private suspend fun syncFeedback(feedbackId: String) = withContext(Dispatchers.IO) {
        try {
            val feedback = feedbackDao.getById(feedbackId) ?: throw IllegalArgumentException("Feedback não encontrado: $feedbackId")
            
            // Verifica se usa Firebase ou API
            if (firebaseEnabled) {
                // Sincroniza via Firebase
                syncFeedbackViaFirebase(feedback)
            } else {
                // Sincroniza via API REST
                syncFeedbackViaRest(feedback)
            }
            
            // Atualiza estatísticas
            _syncStats.postValue(_syncStats.value?.copy(
                syncedFeedbacks = _syncStats.value?.syncedFeedbacks?.plus(1) ?: 1
            ))
            
            Log.d(TAG, "Feedback sincronizado com sucesso: $feedbackId")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar feedback $feedbackId: ${e.message}")
            _syncStats.postValue(_syncStats.value?.copy(
                failedFeedbacks = _syncStats.value?.failedFeedbacks?.plus(1) ?: 1
            ))
            throw e
        }
    }
    
    /**
     * Sincroniza um documento específico
     */
    private suspend fun syncDocument(documentId: String) = withContext(Dispatchers.IO) {
        try {
            val document = documentDao.getById(documentId) ?: throw IllegalArgumentException("Documento não encontrado: $documentId")
            
            // Verifica se o arquivo existe
            val documentFile = File(document.filePath)
            if (!documentFile.exists()) {
                throw IllegalStateException("Arquivo do documento não encontrado: ${document.filePath}")
            }
            
            // Verifica se usa Firebase ou API
            if (firebaseEnabled) {
                // Sincroniza via Firebase
                syncDocumentViaFirebase(document, documentFile)
            } else {
                // Sincroniza via API REST
                syncDocumentViaRest(document, documentFile)
            }
            
            // Atualiza estatísticas
            _syncStats.postValue(_syncStats.value?.copy(
                syncedDocuments = _syncStats.value?.syncedDocuments?.plus(1) ?: 1
            ))
            
            Log.d(TAG, "Documento sincronizado com sucesso: $documentId")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar documento $documentId: ${e.message}")
            _syncStats.postValue(_syncStats.value?.copy(
                failedDocuments = _syncStats.value?.failedDocuments?.plus(1) ?: 1
            ))
            throw e
        }
    }
    
    /**
     * Sincroniza alerta via Firebase
     */
    private suspend fun syncAlertViaFirebase(alert: Alert) {
        // Referência para o nó de alertas no Firebase
        val alertsRef = FirebaseDatabase.getInstance().getReference("alerts")
        
        // Cria o mapa de dados a ser enviado
        val alertData = mapOf(
            "id" to alert.id,
            "type" to alert.type,
            "latitude" to alert.latitude,
            "longitude" to alert.longitude,
            "description" to alert.description,
            "createdAt" to alert.createdAt,
            "expiresAt" to alert.expiresAt,
            "severity" to alert.severity,
            "direction" to alert.direction,
            "createdBy" to alert.createdBy,
            "metadata" to alert.metadata
        )
        
        // Envia para o Firebase
        try {
            alertsRef.child(alert.id).setValue(alertData).await()
            
            // Atualiza o alerta local como sincronizado
            val updatedAlert = alert.copy(
                synced = true,
                syncTimestamp = System.currentTimeMillis(),
                serverRef = alert.id
            )
            alertDao.update(updatedAlert)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar alerta via Firebase: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza alerta via REST
     */
    private suspend fun syncAlertViaRest(alert: Alert) {
        val url = URL("$apiBaseUrl/api/alerts")
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com os dados do POI
            val poiJson = JSONObject().apply {
                put("id", poi.id)
                put("name", poi.name)
                put("type", poi.type)
                put("latitude", poi.latitude)
                put("longitude", poi.longitude)
                put("description", poi.description)
                put("createdAt", poi.createdAt)
                put("updatedAt", poi.updatedAt)
                put("createdBy", poi.createdBy)
                put("isVerified", poi.isVerified)
                put("isActive", poi.isActive)
                put("metadata", poi.metadata)
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(poiJson.toString())
                writer.flush()
            }
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Lê resposta
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(response)
                
                // Obtém o identificador no servidor
                val serverRef = responseJson.optString("id", poi.id)
                
                // Atualiza o POI local como sincronizado
                val updatedPOI = poi.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef
                )
                poiDao.update(updatedPOI)
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                throw Exception("Erro na API REST: $responseCode - $errorResponse")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar POI via REST: ${e.message}")
            throw e
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Sincroniza feedback via Firebase
     */
    private suspend fun syncFeedbackViaFirebase(feedback: Feedback) {
        // Referência para o nó de feedbacks no Firebase
        val feedbacksRef = FirebaseDatabase.getInstance().getReference("feedbacks")
        
        // Cria o mapa de dados a ser enviado
        val feedbackData = mapOf(
            "id" to feedback.id,
            "type" to feedback.type,
            "content" to feedback.content,
            "rating" to feedback.rating,
            "userId" to feedback.userId,
            "poiId" to feedback.poiId,
            "alertId" to feedback.alertId,
            "createdAt" to feedback.createdAt,
            "metadata" to feedback.metadata
        )
        
        // Verifica se há imagem associada
        val hasImage = !feedback.imagePath.isNullOrEmpty()
        
        // Se tiver imagem, primeiro faz upload
        var imageUrl: String? = null
        if (hasImage) {
            // Faz upload da imagem para o Firebase Storage
            imageUrl = uploadImageToFirebase(
                File(feedback.imagePath!!),
                "feedbacks/${feedback.id}",
                "feedback_image"
            )
        }
        
        // Adiciona URL da imagem ao mapa de dados se houver
        val dataWithImage = if (imageUrl != null) {
            feedbackData + ("imageUrl" to imageUrl)
        } else {
            feedbackData
        }
        
        // Envia para o Firebase
        try {
            feedbacksRef.child(feedback.id).setValue(dataWithImage).await()
            
            // Atualiza o feedback local como sincronizado
            val updatedFeedback = feedback.copy(
                synced = true,
                syncTimestamp = System.currentTimeMillis(),
                serverRef = feedback.id,
                serverImageUrl = imageUrl
            )
            feedbackDao.update(updatedFeedback)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar feedback via Firebase: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza feedback via REST
     */
    private suspend fun syncFeedbackViaRest(feedback: Feedback) {
        val url = URL("$apiBaseUrl/api/feedbacks")
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com os dados do feedback
            val feedbackJson = JSONObject().apply {
                put("id", feedback.id)
                put("type", feedback.type)
                put("content", feedback.content)
                put("rating", feedback.rating)
                put("userId", feedback.userId)
                put("poiId", feedback.poiId)
                put("alertId", feedback.alertId)
                put("createdAt", feedback.createdAt)
                put("metadata", feedback.metadata)
                
                // TODO: Implementar upload da imagem se houver
                if (!feedback.imagePath.isNullOrEmpty()) {
                    put("hasImage", true)
                }
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(feedbackJson.toString())
                writer.flush()
            }
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Lê resposta
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(response)
                
                // Obtém o identificador no servidor
                val serverRef = responseJson.optString("id", feedback.id)
                
                // Se tiver imagem e o servidor retornar um upload URL
                var serverImageUrl: String? = null
                if (!feedback.imagePath.isNullOrEmpty() && responseJson.has("uploadUrl")) {
                    // Usa a URL retornada para fazer upload da imagem
                    val uploadUrl = responseJson.getString("uploadUrl")
                    serverImageUrl = uploadImageToUrl(File(feedback.imagePath!!), uploadUrl)
                }
                
                // Atualiza o feedback local como sincronizado
                val updatedFeedback = feedback.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef,
                    serverImageUrl = serverImageUrl
                )
                feedbackDao.update(updatedFeedback)
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                throw Exception("Erro na API REST: $responseCode - $errorResponse")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar feedback via REST: ${e.message}")
            throw e
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Sincroniza documento via Firebase
     */
    private suspend fun syncDocumentViaFirebase(document: Document, documentFile: File) {
        // Primeiro, faz upload do arquivo para o Firebase Storage
        val storageUrl = uploadFileToFirebase(
            documentFile,
            "documents/${document.id}",
            document.fileName
        )
        
        // Referência para o nó de documentos no Firebase
        val documentsRef = FirebaseDatabase.getInstance().getReference("documents")
        
        // Cria o mapa de dados a ser enviado
        val documentData = mapOf(
            "id" to document.id,
            "type" to document.type,
            "fileName" to document.fileName,
            "fileUrl" to storageUrl,
            "extractedText" to document.extractedText,
            "tripId" to document.tripId,
            "deliveryId" to document.deliveryId,
            "createdAt" to document.createdAt,
            "metadata" to document.metadata
        )
        
        // Envia para o Firebase
        try {
            documentsRef.child(document.id).setValue(documentData).await()
            
            // Atualiza o documento local como sincronizado
            val updatedDocument = document.copy(
                synced = true,
                syncTimestamp = System.currentTimeMillis(),
                serverRef = document.id,
                serverFileUrl = storageUrl
            )
            documentDao.update(updatedDocument)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar documento via Firebase: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza documento via REST
     */
    private suspend fun syncDocumentViaRest(document: Document, documentFile: File) {
        val url = URL("$apiBaseUrl/api/documents")
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com os dados do documento
            val documentJson = JSONObject().apply {
                put("id", document.id)
                put("type", document.type)
                put("fileName", document.fileName)
                put("extractedText", document.extractedText)
                put("tripId", document.tripId)
                put("deliveryId", document.deliveryId)
                put("createdAt", document.createdAt)
                put("metadata", document.metadata)
                put("hasFile", true)
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(documentJson.toString())
                writer.flush()
            }
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Lê resposta
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(response)
                
                // Obtém o identificador no servidor
                val serverRef = responseJson.optString("id", document.id)
                
                // Se o servidor retornar um upload URL, usa para fazer upload do arquivo
                var serverFileUrl: String? = null
                if (responseJson.has("uploadUrl")) {
                    val uploadUrl = responseJson.getString("uploadUrl")
                    serverFileUrl = uploadFileToUrl(documentFile, uploadUrl)
                }
                
                // Atualiza o documento local como sincronizado
                val updatedDocument = document.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef,
                    serverFileUrl = serverFileUrl
                )
                documentDao.update(updatedDocument)
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                throw Exception("Erro na API REST: $responseCode - $errorResponse")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar documento via REST: ${e.message}")
            throw e
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Faz upload de um arquivo para o Firebase Storage
     */
    private suspend fun uploadFileToFirebase(file: File, path: String, fileName: String): String {
        // Referência para o Storage
        val storageRef = FirebaseStorage.getInstance().reference
        val fileRef = storageRef.child(path)
        
        return try {
            // Faz upload do arquivo
            val uploadTask = fileRef.putFile(android.net.Uri.fromFile(file)).await()
            
            // Obtém a URL de download
            val downloadUrl = fileRef.downloadUrl.await()
            downloadUrl.toString()
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao fazer upload de arquivo para Firebase Storage: ${e.message}")
            throw e
        }
    }
    
    /**
     * Faz upload de uma imagem para o Firebase Storage
     */
    private suspend fun uploadImageToFirebase(file: File, path: String, fileName: String): String {
        // Comprime a imagem se necessário
        val compressedFile = if (fileCompressor != null) {
            fileCompressor.compressImageFile(file, 800, 600, 85)
        } else {
            file
        }
        
        // Usa o método de upload de arquivo
        return uploadFileToFirebase(compressedFile, path, fileName)
    }
    
    /**
     * Faz upload de um arquivo para uma URL
     */
    private suspend fun uploadFileToUrl(file: File, uploadUrl: String): String {
        val url = URL(uploadUrl)
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "PUT"
            connection.setRequestProperty("Content-Type", "application/octet-stream")
            connection.doOutput = true
            
            // Faz upload do arquivo
            connection.outputStream.use { outputStream ->
                file.inputStream().use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Retorna a URL de download, que pode ser a mesma URL de upload
                // ou uma URL diferente fornecida pelo servidor na resposta
                val responseHeaders = connection.headerFields
                return uploadUrl
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                throw Exception("Erro ao fazer upload de arquivo: $responseCode - $errorResponse")
            }
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Faz upload de uma imagem para uma URL
     */
    private suspend fun uploadImageToUrl(file: File, uploadUrl: String): String {
        // Comprime a imagem se necessário
        val compressedFile = if (fileCompressor != null) {
            fileCompressor.compressImageFile(file, 800, 600, 85)
        } else {
            file
        }
        
        // Usa o método de upload de arquivo
        return uploadFileToUrl(compressedFile, uploadUrl)
    }
    
    /**
     * Adquire wake lock para manter o CPU ativo durante sincronização
     */
    private fun acquireWakeLock() {
        wakeLock?.let { lock ->
            if (!lock.isHeld) {
                lock.acquire(MAX_WAKE_LOCK_TIME)
                Log.d(TAG, "Wake lock adquirido")
            }
        }
    }
    
    /**
     * Libera wake lock
     */
    private fun releaseWakeLock() {
        wakeLock?.let { lock ->
            if (lock.isHeld) {
                lock.release()
                Log.d(TAG, "Wake lock liberado")
            }
        }
    }
    
    /**
     * Registra callback para monitorar mudanças de rede
     */
    private fun registerNetworkCallback() {
        // Primeiro, identifica o tipo de conexão atual
        checkCurrentConnectionType()
        
        // Cria callback
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                super.onAvailable(network)
                checkCurrentConnectionType()
                
                // Se havia perdido a conexão, tenta reiniciar a sincronização
                if (_syncState.value is SyncState.NoConnectivity) {
                    Log.d(TAG, "Conexão restaurada, tentando reiniciar sincronização")
                    startSync()
                }
            }
            
            override fun onLost(network: Network) {
                super.onLost(network)
                checkCurrentConnectionType()
                
                // Se perder todas as conexões, interrompe a sincronização
                if (currentConnectionType == ConnectionType.NONE) {
                    Log.d(TAG, "Conexão perdida, interrompendo sincronização")
                    stopSync()
                    _syncState.value = SyncState.NoConnectivity
                }
            }
            
            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                super.onCapabilitiesChanged(network, networkCapabilities)
                checkCurrentConnectionType()
                
                // Se a política exige WiFi e estamos em WiFi agora, inicia a sincronização
                if (syncPolicy == SyncPolicy.WIFI_ONLY &&
                    currentConnectionType == ConnectionType.WIFI &&
                    _syncState.value is SyncState.WaitingForWifi
                ) {
                    Log.d(TAG, "Wifi disponível, iniciando sincronização")
                    startSync()
                }
            }
        }
        
        // Registra o callback
        val networkRequest = NetworkRequest.Builder().build()
        connectivityManager.registerNetworkCallback(networkRequest, networkCallback!!)
    }
    
    /**
     * Remove o callback de rede
     */
    private fun unregisterNetworkCallback() {
        networkCallback?.let {
            try {
                connectivityManager.unregisterNetworkCallback(it)
                networkCallback = null
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao desregistrar network callback: ${e.message}")
            }
        }
    }
    
    /**
     * Verifica o tipo de conexão atual
     */
    private fun checkCurrentConnectionType() {
        currentConnectionType = when {
            !isNetworkAvailable() -> ConnectionType.NONE
            isWifiConnected() -> ConnectionType.WIFI
            isCellularConnected() -> ConnectionType.CELLULAR
            isEthernetConnected() -> ConnectionType.ETHERNET
            else -> ConnectionType.OTHER
        }
        
        Log.d(TAG, "Tipo de conexão atual: $currentConnectionType")
    }
    
    /**
     * Verifica se há alguma rede disponível
     */
    private fun isNetworkAvailable(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    
    /**
     * Verifica se WiFi está conectado
     */
    private fun isWifiConnected(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }
    
    /**
     * Verifica se rede móvel está conectada
     */
    private fun isCellularConnected(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }
    
    /**
     * Verifica se ethernet está conectada
     */
    private fun isEthernetConnected(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }
    
    /**
     * Reseta as estatísticas de sincronização
     */
    private fun resetSyncStats() {
        _syncStats.postValue(SyncStats())
    }
    
    /**
     * Atualiza as estatísticas de sincronização
     */
    private suspend fun updateSyncStats() = withContext(Dispatchers.IO) {
        // Conta itens pendentes
        val alertCount = alertDao.getUnsyncedCount()
        val poiCount = poiDao.getUnsyncedCount()
        val feedbackCount = feedbackDao.getUnsyncedCount()
        val documentCount = documentDao.getUnsyncedCount()
        
        // Atualiza o objeto de estatísticas
        val currentStats = _syncStats.value ?: SyncStats()
        _syncStats.postValue(currentStats.copy(
            pendingAlerts = alertCount,
            pendingPOIs = poiCount,
            pendingFeedbacks = feedbackCount,
            pendingDocuments = documentCount,
            lastSyncTime = System.currentTimeMillis()
        ))
    }
    
    /**
     * Estados possíveis do serviço de sincronização
     */
    sealed class SyncState {
        object Idle : SyncState()
        object Syncing : SyncState()
        object NoConnectivity : SyncState()
        object WaitingForWifi : SyncState()
        object ManualOnly : SyncState()
        data class Error(val message: String) : SyncState()
    }
    
    /**
     * Classe para estatísticas de sincronização
     */
    data class SyncStats(
        val syncedAlerts: Int = 0,
        val syncedPOIs: Int = 0,
        val syncedFeedbacks: Int = 0,
        val syncedDocuments: Int = 0,
        
        val failedAlerts: Int = 0,
        val failedPOIs: Int = 0,
        val failedFeedbacks: Int = 0,
        val failedDocuments: Int = 0,
        
        val pendingAlerts: Int = 0,
        val pendingPOIs: Int = 0,
        val pendingFeedbacks: Int = 0,
        val pendingDocuments: Int = 0,
        
        val lastSyncTime: Long = 0
    )
}application/json")
            connection.setRequestProperty("Accept", "application/json")
            
            // Adiciona chave API se disponível
            if (apiKey != null) {
                connection.setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            connection.doOutput = true
            
            // Cria JSON com os dados do alerta
            val alertJson = JSONObject().apply {
                put("id", alert.id)
                put("type", alert.type)
                put("latitude", alert.latitude)
                put("longitude", alert.longitude)
                put("description", alert.description)
                put("createdAt", alert.createdAt)
                put("expiresAt", alert.expiresAt)
                put("severity", alert.severity)
                put("direction", alert.direction)
                put("createdBy", alert.createdBy)
                put("metadata", alert.metadata)
            }
            
            // Envia dados
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(alertJson.toString())
                writer.flush()
            }
            
            // Verifica resposta
            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                // Lê resposta
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(response)
                
                // Obtém o identificador no servidor
                val serverRef = responseJson.optString("id", alert.id)
                
                // Atualiza o alerta local como sincronizado
                val updatedAlert = alert.copy(
                    synced = true,
                    syncTimestamp = System.currentTimeMillis(),
                    serverRef = serverRef
                )
                alertDao.update(updatedAlert)
            } else {
                // Lê mensagem de erro
                val errorResponse = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "Erro desconhecido"
                throw Exception("Erro na API REST: $responseCode - $errorResponse")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar alerta via REST: ${e.message}")
            throw e
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Sincroniza POI via Firebase
     */
    private suspend fun syncPOIViaFirebase(poi: POI) {
        // Referência para o nó de POIs no Firebase
        val poisRef = FirebaseDatabase.getInstance().getReference("pois")
        
        // Cria o mapa de dados a ser enviado
        val poiData = mapOf(
            "id" to poi.id,
            "name" to poi.name,
            "type" to poi.type,
            "latitude" to poi.latitude,
            "longitude" to poi.longitude,
            "description" to poi.description,
            "createdAt" to poi.createdAt,
            "updatedAt" to poi.updatedAt,
            "createdBy" to poi.createdBy,
            "isVerified" to poi.isVerified,
            "isActive" to poi.isActive,
            "metadata" to poi.metadata
        )
        
        // Envia para o Firebase
        try {
            poisRef.child(poi.id).setValue(poiData).await()
            
            // Atualiza o POI local como sincronizado
            val updatedPOI = poi.copy(
                synced = true,
                syncTimestamp = System.currentTimeMillis(),
                serverRef = poi.id
            )
            poiDao.update(updatedPOI)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao sincronizar POI via Firebase: ${e.message}")
            throw e
        }
    }
    
    /**
     * Sincroniza POI via REST
     */
    private suspend fun syncPOIViaRest(poi: POI) {
        val url = URL("$apiBaseUrl/api/pois")
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "