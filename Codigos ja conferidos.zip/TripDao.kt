// TripDao.kt
package com.kingroad.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

/**
 * Interface DAO (Data Access Object) para acesso à tabela de viagens
 */
@Dao
interface TripDao {
    /**
     * Insere uma nova viagem no banco de dados
     * @param trip Entidade de viagem a ser inserida
     * @return ID da viagem inserida
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(trip: TripEntity): Long

    /**
     * Atualiza uma viagem existente
     * @param trip Entidade de viagem a ser atualizada
     */
    @Update
    suspend fun update(trip: TripEntity)

    /**
     * Obtém uma viagem pelo ID
     * @param tripId ID da viagem
     * @return Entidade da viagem ou null se não existir
     */
    @Query("SELECT * FROM trips WHERE id = :tripId")
    suspend fun getTripById(tripId: Long): TripEntity?

    /**
     * Obtém todas as viagens ordenadas pela data de início (decrescente)
     * @return Lista de entidades de viagens
     */
    @Query("SELECT * FROM trips ORDER BY startDate DESC")
    suspend fun getAllTrips(): List<TripEntity>

    /**
     * Obtém os IDs das últimas viagens
     * @param limit Número máximo de viagens a retornar
     * @return Lista de IDs das viagens
     */
    @Query("SELECT id FROM trips ORDER BY startDate DESC LIMIT :limit")
    suspend fun getLastTripIds(limit: Int): List<Long>

    /**
     * Obtém os IDs das viagens realizadas após uma data específica
     * @param date Data de referência em milissegundos
     * @return Lista de IDs das viagens
     */
    @Query("SELECT id FROM trips WHERE startDate >= :date ORDER BY startDate DESC")
    suspend fun getTripIdsAfterDate(date: Long): List<Long>
    
    /**
     * Obtém as viagens realizadas após uma data específica
     * @param date Data de referência em milissegundos
     * @return Lista de entidades de viagem
     */
    @Query("SELECT * FROM trips WHERE startDate >= :date ORDER BY startDate DESC")
    suspend fun getTripsAfterDate(date: Long): List<TripEntity>

    /**
     * Exclui todas as viagens exceto as especificadas
     * @param tripIds Lista de IDs de viagens a preservar
     * @return Número de viagens excluídas
     */
    @Query("DELETE FROM trips WHERE id NOT IN (:tripIds)")
    suspend fun deleteAllExcept(tripIds: List<Long>): Int

    /**
     * Exclui viagens anteriores a uma data específica
     * @param date Data de referência em milissegundos
     * @return Número de viagens excluídas
     */
    @Query("DELETE FROM trips WHERE startDate < :date")
    suspend fun deleteTripsBeforeDate(date: Long): Int
}