/**
 * Icon.js
 * 
 * Componente reutilizável para exibição de ícones.
 * Implementa wrapper para biblioteca de ícones com suporte
 * a diferentes tamanhos, cores e estados.
 * 
 * @author KingRoad Team
 * @version 1.0.0
 * @date 2025-03-30
 */

import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import PropTypes from 'prop-types';

// Importações de bibliotecas de ícones
import Feather from 'react-native-vector-icons/Feather';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import Octicons from 'react-native-vector-icons/Octicons';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import Foundation from 'react-native-vector-icons/Foundation';

// Constantes para bibliotecas de ícones suportadas
const ICON_SETS = {
  FEATHER: 'feather',
  MATERIAL: 'material',
  MATERIAL_COMMUNITY: 'material-community',
  FONT_AWESOME: 'font-awesome',
  FONT_AWESOME_5: 'font-awesome-5',
  IONICONS: 'ionicons',
  ANT_DESIGN: 'ant-design',
  ENTYPO: 'entypo',
  OCTICONS: 'octicons',
  SIMPLE_LINE: 'simple-line',
  FOUNDATION: 'foundation'
};

// Mapeamento de tamanhos de ícones
const ICON_SIZES = {
  TINY: 12,
  EXTRA_SMALL: 16,
  SMALL: 18,
  MEDIUM: 24,
  LARGE: 32,
  EXTRA_LARGE: 40,
  HUGE: 56
};

// Estados dos ícones
const ICON_STATES = {
  DEFAULT: 'default', 
  DISABLED: 'disabled',
  ACTIVE: 'active',
  WARNING: 'warning',
  ERROR: 'error',
  SUCCESS: 'success'
};

/**
 * Componente Icon - Wrapper unificado para diversas bibliotecas de ícones
 * @param {Object} props - Propriedades do componente
 * @returns {React.Component} Componente Icon
 */
const Icon = ({
  // Propriedades principais
  name,
  set = ICON_SETS.FEATHER,
  size = ICON_SIZES.MEDIUM,
  color = null,
  state = ICON_STATES.DEFAULT,
  
  // Outras propriedades
  style = {},
  backgroundColor = null,
  onPress = null,
  disabled = false,
  testID = null,
  
  // Props adicionais específicas para alguns ícones
  solid = false,
  brand = false,
  
  // Acessibilidade
  accessibilityLabel = null,
  
  // Props adicionais que serão passadas para o componente de ícone
  ...iconProps
}) => {
  // Define a cor baseada no estado, se nenhuma cor específica for fornecida
  const iconColor = color || getColorByState(state);
  
  // Seleciona o componente de ícone baseado no conjunto escolhido
  const IconComponent = getIconComponent(set);
  
  // Se o componente não for encontrado, retorna um View vazio
  if (!IconComponent) {
    console.warn(`[Icon] Conjunto de ícones '${set}' não encontrado ou não suportado`);
    return <View style={[styles.placeholder, { width: size, height: size }]} />;
  }
  
  // Se o IconComponent for um Componente React
  if (typeof IconComponent === 'function') {
    // Props específicas para o FontAwesome5
    const iconSpecificProps = set === ICON_SETS.FONT_AWESOME_5 ? { solid, brand } : {};

    // Preparamos o componente de ícone
    const iconElement = (
      <IconComponent
        name={name}
        size={size}
        color={iconColor}
        style={[styles.icon, style]}
        testID={testID}
        accessibilityLabel={accessibilityLabel || `Ícone ${name}`}
        {...iconSpecificProps}
        {...iconProps}
      />
    );

    // Se o ícone tiver background, o envolvemos em um container
    if (backgroundColor) {
      return (
        <View style={[styles.container, { backgroundColor }, style]}>
          {iconElement}
        </View>
      );
    }

    // Caso contrário, retornamos apenas o ícone
    return iconElement;
  }

  // Se não for um componente válido, retorna um View vazio
  return <View style={[styles.placeholder, { width: size, height: size }]} />;
};

/**
 * Obtém o componente de ícone baseado no conjunto selecionado
 * @private
 * @param {string} set - Conjunto de ícones
 * @returns {React.Component|null} Componente React para o conjunto de ícones
 */
const getIconComponent = (set) => {
  switch (set.toLowerCase()) {
    case ICON_SETS.FEATHER:
      return Feather;
    case ICON_SETS.MATERIAL:
      return MaterialIcons;
    case ICON_SETS.MATERIAL_COMMUNITY:
      return MaterialCommunityIcons;
    case ICON_SETS.FONT_AWESOME:
      return FontAwesome;
    case ICON_SETS.FONT_AWESOME_5:
      return FontAwesome5;
    case ICON_SETS.IONICONS:
      return Ionicons;
    case ICON_SETS.ANT_DESIGN:
      return AntDesign;
    case ICON_SETS.ENTYPO:
      return Entypo;
    case ICON_SETS.OCTICONS:
      return Octicons;
    case ICON_SETS.SIMPLE_LINE:
      return SimpleLineIcons;
    case ICON_SETS.FOUNDATION:
      return Foundation;
    default:
      return null;
  }
};

/**
 * Obtém a cor do ícone baseado no estado
 * @private
 * @param {string} state - Estado do ícone
 * @returns {string} Código de cor para o estado
 */
const getColorByState = (state) => {
  // Estas cores são apenas exemplos e devem ser substituídas pelas cores do tema
  const colors = {
    [ICON_STATES.DEFAULT]: '#1A1A1A',   // Cor padrão (quase preto)
    [ICON_STATES.DISABLED]: '#BDBDBD',  // Cinza claro
    [ICON_STATES.ACTIVE]: '#1E88E5',    // Azul principal
    [ICON_STATES.WARNING]: '#FFC107',   // Amarelo de aviso
    [ICON_STATES.ERROR]: '#E53935',     // Vermelho de erro
    [ICON_STATES.SUCCESS]: '#43A047'    // Verde de sucesso
  };
  
  return colors[state] || colors[ICON_STATES.DEFAULT];
};

// Definição de estilos
const styles = StyleSheet.create({
  icon: {
    // Alinhamento e margem básicos para o ícone
    alignSelf: 'center',
    textAlign: 'center',
    includeFontPadding: false, // Remove o padding extra em Android
    ...Platform.select({
      android: {
        paddingTop: 0, // Ajuste para alinhamento Android
      },
    }),
  },
  container: {
    // Estilo para o container quando o ícone tiver background
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    padding: 4,
  },
  placeholder: {
    // Estilo para o placeholder quando o ícone não é encontrado
    backgroundColor: 'transparent',
  }
});

// Definição de PropTypes para documentação e validação
Icon.propTypes = {
  name: PropTypes.string.isRequired,
  set: PropTypes.oneOf(Object.values(ICON_SETS)),
  size: PropTypes.oneOfType([
    PropTypes.oneOf(Object.values(ICON_SIZES)),
    PropTypes.number
  ]),
  color: PropTypes.string,
  state: PropTypes.oneOf(Object.values(ICON_STATES)),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  backgroundColor: PropTypes.string,
  onPress: PropTypes.func,
  disabled: PropTypes.bool,
  solid: PropTypes.bool,
  brand: PropTypes.bool,
  testID: PropTypes.string,
  accessibilityLabel: PropTypes.string,
};

// Exporta o componente Icon e as constantes úteis
export { ICON_SETS, ICON_SIZES, ICON_STATES };
export default Icon;