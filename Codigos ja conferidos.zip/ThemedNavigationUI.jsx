import React, { useState } from 'react';
import { Menu, Volume2, ChevronUp, X, AlertTriangle, Search, MapPin, Map } from 'lucide-react';

// Definição dos temas disponíveis
const THEMES = {
  modern: {
    name: 'Modern Dark',
    colors: {
      background: '#121212',
      surface: '#1E1E1E',
      primary: '#3498db',
      secondary: '#2ecc71',
      accent: '#e74c3c',
      warning: '#f1c40f',
      text: '#FFFFFF',
      textSecondary: '#95a5a6'
    }
  },
  classic: {
    name: 'Classic Pro',
    colors: {
      background: '#141E30',
      surface: '#243B55',
      primary: '#4A90E2',
      secondary: '#50C878',
      accent: '#FF6B6B',
      warning: '#FFB900',
      text: '#FFFFFF',
      textSecondary: '#B8C6D1'
    }
  }
};

const ThemedNavigationUI = ({ 
  currentTheme = 'modern',
  onThemeChange = () => {},
  pois = [],
  alerts = []
}) => {
  const [showSearch, setShowSearch] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);

  // Usar o tema atual ou fallback para modern
  const theme = THEMES[currentTheme] || THEMES.modern;
  const colors = theme.colors;

  // Dados de exemplo
  const defaultPois = [
    {
      id: '1',
      name: 'Truck Stop A',
      distance: '2.5 km',
      amenities: ['Fuel', 'Restaurant', 'Showers']
    },
    {
      id: '2',
      name: 'Rest Area',
      distance: '5 km',
      amenities: ['Parking', 'Restrooms']
    }
  ];

  const displayPois = pois.length > 0 ? pois : defaultPois;

  const SearchBar = () => (
    <div 
      className="absolute top-0 left-0 right-0 p-4"
      style={{ backgroundColor: colors.surface }}
    >
      <div className="flex items-center gap-2">
        <div 
          className="flex-1 flex items-center rounded-lg px-3 py-2"
          style={{ backgroundColor: colors.background }}
        >
          <Search size={20} style={{ color: colors.textSecondary }} />
          <input
            type="text"
            placeholder="Search destination..."
            className="flex-1 ml-2 bg-transparent outline-none"
            style={{ color: colors.text }}
          />
        </div>
        <button 
          onClick={() => setShowSearch(false)}
          className="p-2 rounded-lg"
          style={{ backgroundColor: colors.background }}
        >
          <X size={20} style={{ color: colors.textSecondary }} />
        </button>
      </div>
    </div>
  );

  const Sidebar = () => (
    <div 
      className="absolute top-0 bottom-0 right-0 w-64"
      style={{ backgroundColor: colors.surface }}
    >
      <div className="p-4">
        <h2 
          className="font-bold mb-4"
          style={{ color: colors.text }}
        >
          Nearby POIs
        </h2>
        <div className="space-y-2">
          {displayPois.map((poi) => (
            <div 
              key={poi.id}
              className="p-3 rounded-lg"
              style={{ backgroundColor: colors.background }}
            >
              <div className="flex justify-between">
                <div style={{ color: colors.text }}>{poi.name}</div>
                <div style={{ color: colors.primary }}>{poi.distance}</div>
              </div>
              <div 
                className="mt-1 text-sm"
                style={{ color: colors.textSecondary }}
              >
                {poi.amenities.join(' • ')}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const BottomControls = () => (
    <div className="absolute bottom-4 left-4 flex gap-2">
      {[Menu, Map, Volume2].map((Icon, index) => (
        <button
          key={index}
          className="p-3 rounded-full"
          style={{ backgroundColor: colors.surface }}
        >
          <Icon size={24} style={{ color: colors.textSecondary }} />
        </button>
      ))}
    </div>
  );

  return (
    <div 
      className="relative h-screen"
      style={{ backgroundColor: colors.background }}
    >
      {/* Barra de busca */}
      {showSearch ? (
        <SearchBar />
      ) : (
        <button
          className="absolute top-4 left-4 p-3 rounded-full"
          style={{ backgroundColor: colors.surface }}
          onClick={() => setShowSearch(true)}
        >
          <Search size={24} style={{ color: colors.textSecondary }} />
        </button>
      )}

      {/* Barra lateral */}
      {showSidebar && <Sidebar />}

      {/* Controles inferiores */}
      <BottomControls />

      {/* Alerta de exemplo */}
      <div
        className="absolute bottom-20 left-4 right-4 p-4 rounded-lg"
        style={{ backgroundColor: colors.accent }}
      >
        <div className="flex items-center">
          <AlertTriangle size={24} className="mr-2" style={{ color: colors.text }} />
          <span style={{ color: colors.text }}>
            Weight restriction ahead: 17t
          </span>
        </div>
      </div>
    </div>
  );
};

// Componente de demonstração
const DemoComponent = () => {
  return (
    <div className="h-screen">
      <ThemedNavigationUI />
    </div>
  );
};

export default ThemedNavigationUI;