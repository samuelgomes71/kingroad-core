/**
 * TranslationsService.js
 * Serviço de internacionalização (i18n) para o sistema KingRoad
 * Suporta múltiplos idiomas com carregamento dinâmico e fallback para Português
 */

class TranslationsService {
  constructor() {
    this.currentLanguage = 'pt-BR'; // Idioma padrão: Português
    this.translations = {};
    this.supportedLanguages = [
      { code: 'pt-BR', name: 'Português (Brasil)', complete: true },
      { code: 'en-US', name: 'English (US)', complete: false },
      { code: 'es-ES', name: 'Español', complete: false },
      { code: 'fr-FR', name: 'Français', complete: false },
      { code: 'de-DE', name: 'Deutsch', complete: false },
      { code: 'it-IT', name: 'Italiano', complete: false },
      { code: 'ru-RU', name: 'Русский', complete: false },
      { code: 'zh-CN', name: '中文 (简体)', complete: false },
      { code: 'ja-JP', name: '日本語', complete: false },
      { code: 'ko-KR', name: '한국어', complete: false },
      { code: 'ar-SA', name: 'العربية', complete: false },
      { code: 'hi-IN', name: 'हिन्दी', complete: false },
      // Estrutura para outros idiomas (até 34 conforme documento)
    ];
    
    // Inicialização
    this.loadLanguage(this.currentLanguage);
  }

  /**
   * Carrega um pacote de idioma específico
   * @param {string} langCode - Código do idioma (ex: pt-BR, en-US)
   * @returns {Promise<boolean>} - Sucesso do carregamento
   */
  async loadLanguage(langCode) {
    try {
      // Tenta carregar o idioma solicitado
      const langPack = await this._fetchLanguagePack(langCode);
      this.translations[langCode] = langPack;
      this.currentLanguage = langCode;
      return true;
    } catch (error) {
      console.error(`Erro ao carregar idioma ${langCode}:`, error);
      
      // Se o idioma não for Português e falhar, carrega Português como fallback
      if (langCode !== 'pt-BR') {
        console.warn(`Usando Português como fallback para ${langCode}`);
        if (!this.translations['pt-BR']) {
          await this._fetchLanguagePack('pt-BR');
        }
        this.currentLanguage = 'pt-BR';
      }
      return false;
    }
  }

  /**
   * Busca o pacote de idioma do armazenamento ou servidor
   * @private
   * @param {string} langCode - Código do idioma
   * @returns {Promise<Object>} - Pacote de traduções
   */
  async _fetchLanguagePack(langCode) {
    // Verifica se já está em cache
    if (this.translations[langCode]) {
      return this.translations[langCode];
    }

    // Tenta buscar do armazenamento local primeiro
    const localPack = await this._getFromStorage(langCode);
    if (localPack) {
      return localPack;
    }

    // Se não encontrar localmente, busca do servidor
    return this._getFromServer(langCode);
  }

  /**
   * Busca o pacote de idioma do armazenamento local
   * @private
   * @param {string} langCode - Código do idioma
   * @returns {Promise<Object|null>} - Pacote de traduções ou null
   */
  async _getFromStorage(langCode) {
    try {
      const storedData = localStorage.getItem(`kingroad_lang_${langCode}`);
      if (storedData) {
        return JSON.parse(storedData);
      }
      return null;
    } catch (error) {
      console.warn(`Erro ao buscar idioma ${langCode} do armazenamento local:`, error);
      return null;
    }
  }

  /**
   * Busca o pacote de idioma do servidor
   * @private
   * @param {string} langCode - Código do idioma
   * @returns {Promise<Object>} - Pacote de traduções
   */
  async _getFromServer(langCode) {
    // Simula uma chamada de API
    const response = await fetch(`https://api.kingroad.com/i18n/${langCode}`);
    
    if (!response.ok) {
      throw new Error(`Falha ao buscar idioma ${langCode}`);
    }
    
    const langPack = await response.json();
    
    // Armazena localmente para uso offline
    try {
      localStorage.setItem(`kingroad_lang_${langCode}`, JSON.stringify(langPack));
    } catch (error) {
      console.warn(`Não foi possível armazenar o idioma ${langCode} localmente:`, error);
    }
    
    return langPack;
  }

  /**
   * Obtém a tradução de uma chave específica
   * @param {string} key - Chave de tradução (ex: 'navigation.startRoute')
   * @param {Object} [params] - Parâmetros para substituição na string
   * @returns {string} - Texto traduzido
   */
  translate(key, params = {}) {
    const langPack = this.translations[this.currentLanguage] || {};
    
    // Busca a tradução pela chave
    let translation = this._getNestedTranslation(langPack, key);
    
    // Se não encontrar no idioma atual e não for português, tenta em português
    if (!translation && this.currentLanguage !== 'pt-BR' && this.translations['pt-BR']) {
      translation = this._getNestedTranslation(this.translations['pt-BR'], key);
    }
    
    // Se ainda não encontrar, retorna a chave como fallback
    if (!translation) {
      console.warn(`Tradução não encontrada para a chave: ${key}`);
      return key;
    }
    
    // Substitui parâmetros se necessário
    if (params && Object.keys(params).length > 0) {
      return this._replaceParams(translation, params);
    }
    
    return translation;
  }

  /**
   * Busca uma tradução em um objeto aninhado usando uma notação de ponto
   * @private
   * @param {Object} obj - Objeto de traduções
   * @param {string} path - Caminho da chave usando notação de ponto
   * @returns {string|null} - Tradução ou null
   */
  _getNestedTranslation(obj, path) {
    const keys = path.split('.');
    let result = obj;
    
    for (const key of keys) {
      if (result && typeof result === 'object' && key in result) {
        result = result[key];
      } else {
        return null;
      }
    }
    
    return typeof result === 'string' ? result : null;
  }

  /**
   * Substitui parâmetros em uma string de tradução
   * @private
   * @param {string} text - Texto com placeholders
   * @param {Object} params - Parâmetros para substituição
   * @returns {string} - Texto com parâmetros substituídos
   */
  _replaceParams(text, params) {
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return params[key] !== undefined ? params[key] : match;
    });
  }

  /**
   * Alterna para um novo idioma
   * @param {string} langCode - Código do idioma
   * @returns {Promise<boolean>} - Sucesso da operação
   */
  async changeLanguage(langCode) {
    if (this.getSupportedLanguages().some(lang => lang.code === langCode)) {
      return this.loadLanguage(langCode);
    }
    console.error(`Idioma não suportado: ${langCode}`);
    return false;
  }

  /**
   * Obtém o idioma atual
   * @returns {string} - Código do idioma atual
   */
  getCurrentLanguage() {
    return this.currentLanguage;
  }

  /**
   * Obtém a lista de idiomas suportados
   * @returns {Array} - Lista de idiomas suportados
   */
  getSupportedLanguages() {
    return this.supportedLanguages;
  }

  /**
   * Verifica se um idioma está totalmente implementado
   * @param {string} langCode - Código do idioma
   * @returns {boolean} - Status de implementação
   */
  isLanguageComplete(langCode) {
    const lang = this.supportedLanguages.find(l => l.code === langCode);
    return lang ? lang.complete : false;
  }

  /**
   * Método auxiliar para formatação de data/hora conforme o idioma
   * @param {Date} date - Objeto de data
   * @param {Object} options - Opções de formatação
   * @returns {string} - Data formatada
   */
  formatDate(date, options = {}) {
    return new Intl.DateTimeFormat(this.currentLanguage, options).format(date);
  }

  /**
   * Método auxiliar para formatação de números conforme o idioma
   * @param {number} number - Número a ser formatado
   * @param {Object} options - Opções de formatação
   * @returns {string} - Número formatado
   */
  formatNumber(number, options = {}) {
    return new Intl.NumberFormat(this.currentLanguage, options).format(number);
  }
}

// Exporta o serviço como singleton
const translationsService = new TranslationsService();
export default translationsService;