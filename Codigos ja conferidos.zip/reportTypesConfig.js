/**
 * Configuração dos tipos de reportes disponíveis no sistema KingRoad
 * 
 * Este arquivo define os diferentes tipos de reportes que os usuários
 * podem criar, suas características visuais e comportamentais.
 * 
 * A configuração é ajustada automaticamente conforme o país/região
 * através do sistema de detecção do LocaleService.
 */

import React from 'react';
import { 
  AlertTriangle, 
  AlertOctagon, 
  AlertCircle, 
  Truck, 
  Road, 
  Map, 
  Flag, 
  CloudRain, 
  Zap, 
  UserX, 
  Shield,
  Camera,
  Coffee,
  Droplet,
  Globe,
  DollarSign,
  XCircle
} from 'react-feather';

// Lista de tipos de reportes suportados pelo sistema
export const reportTypes = [
  // Acidentes
  {
    id: 'accident',
    name: 'Acidente na via',
    icon: <AlertOctagon size={24} color="#ef4444" />,
    color: '#ef4444',
    severity: 'high',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 10000, // 10km
    visibilityDuration: 86400000, // 24 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['safety', 'traffic'],
    offlineSupport: true,
    features: ['description', 'photos', 'audio', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report accident', 
      'crash ahead',
      'acidente',
      'reportar accidente',
      'unfall melden',
      'signaler accident'
    ],
    availableCountries: ['global']
  },
  // Perigos
  {
    id: 'hazard',
    name: 'Perigo na estrada',
    icon: <AlertTriangle size={24} color="#f59e0b" />,
    color: '#f59e0b',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 5000, // 5km
    visibilityDuration: 259200000, // 72 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['safety', 'traffic'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report hazard', 
      'dangerous condition',
      'perigo na pista',
      'peligro en carretera',
      'gefahr melden',
      'signaler danger'
    ],
    availableCountries: ['global']
  },
  // Polícia
  {
    id: 'police',
    name: 'Blitz policial',
    icon: <Shield size={24} color="#3b82f6" />,
    color: '#3b82f6',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: false, // Por questões de privacidade/legais
    notificationRadius: 3000, // 3km
    visibilityDuration: 10800000, // 3 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic', 'authority'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report police', 
      'police checkpoint',
      'reportar policía',
      'polícia à frente',
      'polizei melden',
      'signaler police'
    ],
    availableCountries: ['global'],
    legalRestrictions: {
      // Alguns países proíbem alertas sobre blitz
      restrictedCountries: ['DEU', 'FRA', 'AUT', 'CHE'],
      alternativeLabel: 'Ponto de controle',
      showWarning: true
    }
  },
  // Congestionamento
  {
    id: 'traffic',
    name: 'Congestionamento',
    icon: <Truck size={24} color="#8b5cf6" />,
    color: '#8b5cf6',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 8000, // 8km
    visibilityDuration: 10800000, // 3 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report traffic', 
      'traffic jam',
      'congestionamento',
      'reportar tráfico',
      'stau melden',
      'signaler embouteillage'
    ],
    availableCountries: ['global'],
    intensityLevels: [
      { value: 'light', label: 'Leve', color: '#8b5cf6' },
      { value: 'moderate', label: 'Moderado', color: '#7c3aed' },
      { value: 'heavy', label: 'Intenso', color: '#6d28d9' }
    ]
  },
  // Via bloqueada
  {
    id: 'roadClosure',
    name: 'Via bloqueada',
    icon: <XCircle size={24} color="#dc2626" />,
    color: '#dc2626',
    severity: 'high',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 15000, // 15km
    visibilityDuration: 604800000, // 7 dias em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: true, // Requer confirmação para evitar informações falsas
    categories: ['traffic', 'navigation'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report road closure', 
      'road closed',
      'estrada fechada',
      'via cerrada',
      'straße gesperrt',
      'route fermée'
    ],
    availableCountries: ['global'],
    affectsRouting: true // Este tipo de reporte afeta o cálculo de rotas
  },
  // Clima
  {
    id: 'weather',
    name: 'Condição climática',
    icon: <CloudRain size={24} color="#0ea5e9" />,
    color: '#0ea5e9',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 20000, // 20km
    visibilityDuration: 21600000, // 6 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['weather', 'safety'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report weather', 
      'bad weather ahead',
      'clima ruim',
      'mal tiempo',
      'schlechtes wetter',
      'mauvais temps'
    ],
    availableCountries: ['global'],
    weatherTypes: [
      { value: 'rain', label: 'Chuva', icon: <CloudRain size={18} /> },
      { value: 'fog', label: 'Neblina', icon: <CloudRain size={18} /> },
      { value: 'snow', label: 'Neve', icon: <CloudRain size={18} /> },
      { value: 'ice', label: 'Gelo na pista', icon: <CloudRain size={18} /> },
      { value: 'wind', label: 'Vento forte', icon: <CloudRain size={18} /> }
    ]
  },
  // Zona perigosa
  {
    id: 'cargoTheftRisk',
    name: 'Zona perigosa',
    icon: <AlertCircle size={24} color="#b91c1c" />,
    color: '#b91c1c',
    severity: 'high',
    requiresLocation: true,
    allowsPhotos: false,
    notificationRadius: 10000, // 10km
    visibilityDuration: 2592000000, // 30 dias em ms
    defaultDescription: '',
    userTypes: ['MotoristaVIP', 'Administrador'], // Recurso premium
    requiresApproval: true,
    categories: ['safety', 'security'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report cargo theft risk', 
      'theft risk area',
      'área de risco roubo',
      'zona de riesgo robo',
      'risiko ladungsdiebstahl',
      'risque de vol'
    ],
    availableCountries: ['USA', 'Mexico', 'Brazil', 'Colombia', 'South Africa'],
    securityLevel: 'high',
    dangerTypes: [
      { value: 'theft', label: 'Roubo de carga' },
      { value: 'assault', label: 'Assalto a motoristas' },
      { value: 'kidnapping', label: 'Risco de sequestro' },
      { value: 'vandalism', label: 'Vandalismo' }
    ]
  },
  // Pontos de interesse
  {
    id: 'safeParking',
    name: 'Estacionamento seguro',
    icon: <Flag size={24} color="#65a30d" />,
    color: '#65a30d',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 0, // Não envia notificações
    visibilityDuration: 31536000000, // 1 ano em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['navigation', 'facility'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report safe parking', 
      'truck parking',
      'estacionamento seguro',
      'parking seguro',
      'sicherer parkplatz',
      'parking sécurisé'
    ],
    availableCountries: ['USA', 'Canada', 'EU', 'UK', 'Brazil'],
    poiTypes: [
      { value: 'fuel', label: 'Posto de combustível' },
      { value: 'food', label: 'Restaurante/Alimentação' },
      { value: 'rest', label: 'Área de descanso' },
      { value: 'repair', label: 'Oficina mecânica' },
      { value: 'hotel', label: 'Hotel/Pousada' },
      { value: 'parking', label: 'Estacionamento' },
      { value: 'weighing', label: 'Balança para caminhões' },
      { value: 'customs', label: 'Posto de fiscalização' }
    ]
  },
  // Área de descanso
  {
    id: 'restArea',
    name: 'Área de descanso',
    icon: <Coffee size={24} color="#2ecc71" />,
    color: '#2ecc71',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 0, // Não envia notificações
    visibilityDuration: 10080, // 7 dias (áreas de descanso são permanentes)
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['navigation', 'facility'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report rest area', 
      'rest stop ahead',
      'área de descanso',
      'parada de descanso',
      'rastplatz voraus',
      'aire de repos'
    ],
    availableCountries: ['global']
  },
  // Problemas no mapa
  {
    id: 'map_issue',
    name: 'Problema no mapa',
    icon: <Map size={24} color="#0d9488" />,
    color: '#0d9488',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 0, // Não envia notificações
    visibilityDuration: 31536000000, // 1 ano em ms
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: true,
    categories: ['map', 'navigation'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report map issue', 
      'wrong map',
      'mapa errado',
      'mapa incorrecto',
      'karte fehlerhaft',
      'carte incorrecte'
    ],
    availableCountries: ['global'],
    issueTypes: [
      { value: 'wrong_direction', label: 'Sentido errado de via' },
      { value: 'missing_road', label: 'Via inexistente no mapa' },
      { value: 'closed_permanently', label: 'Via permanentemente fechada' },
      { value: 'wrong_speed_limit', label: 'Limite de velocidade incorreto' },
      { value: 'wrong_restriction', label: 'Restrição de veículos incorreta' },
      { value: 'wrong_name', label: 'Nome de via incorreto' }
    ]
  },
  // Falta de energia
  {
    id: 'power_outage',
    name: 'Falta de energia',
    icon: <Zap size={24} color="#eab308" />,
    color: '#eab308',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 5000, // 5km
    visibilityDuration: 43200000, // 12 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaVIP', 'Administrador'], // Recurso premium
    requiresApproval: true,
    categories: ['facility', 'safety'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report power outage', 
      'no power',
      'falta de energia',
      'sin energía',
      'stromausfall',
      'panne de courant'
    ],
    availableCountries: ['global'],
    facilityTypes: [
      { value: 'fuel_station', label: 'Posto de combustível' },
      { value: 'rest_area', label: 'Área de descanso' },
      { value: 'service_area', label: 'Área de serviço' },
      { value: 'truck_stop', label: 'Parada de caminhões' },
      { value: 'urban_area', label: 'Área urbana' }
    ]
  },
  // Atividade suspeita
  {
    id: 'suspicious_activity',
    name: 'Atividade suspeita',
    icon: <UserX size={24} color="#4b5563" />,
    color: '#4b5563',
    severity: 'high',
    requiresLocation: true,
    allowsPhotos: false, // Por questões de privacidade/legais
    notificationRadius: 3000, // 3km
    visibilityDuration: 10800000, // 3 horas em ms
    defaultDescription: '',
    userTypes: ['MotoristaVIP', 'Administrador'], // Recurso premium
    requiresApproval: true,
    categories: ['security', 'safety'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report suspicious activity', 
      'suspicious person',
      'atividade suspeita',
      'persona sospechosa',
      'verdächtige aktivität',
      'activité suspecte'
    ],
    availableCountries: ['global'],
    activityTypes: [
      { value: 'person_on_road', label: 'Pessoa na pista' },
      { value: 'cargo_inspection', label: 'Inspeção de carga suspeita' },
      { value: 'fake_accident', label: 'Falso acidente/emboscada' },
      { value: 'following_vehicle', label: 'Veículo seguindo' }
    ],
    securityNotice: 'Não compartilhe informações que possam identificar indivíduos específicos.'
  },
  // Radar de velocidade
  {
    id: 'speedTrap',
    name: 'Radar de velocidade',
    icon: <Camera size={24} color="#e74c3c" />,
    color: '#e74c3c',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: false,
    notificationRadius: 5000, // 5km
    visibilityDuration: 60, // 60 minutos
    defaultDescription: '',
    userTypes: ['MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic', 'authority'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report speed trap', 
      'radar ahead',
      'radar à frente',
      'radar adelante',
      'blitzer voraus',
      'radar à venir'
    ],
    availableCountries: ['global'],
    legalRestrictions: {
      // Alguns países proíbem alertas sobre radares
      restrictedCountries: ['FRA', 'CHE'],
      alternativeLabel: 'Ponto de verificação',
      showWarning: true
    }
  },
  // Posto de pesagem
  {
    id: 'weighStation',
    name: 'Balança/Posto de pesagem',
    icon: <Truck size={24} color="#2980b9" />,
    color: '#2980b9',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 8000, // 8km
    visibilityDuration: 180, // 3 horas
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic', 'authority'],
    offlineSupport: true,
    features: ['description', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report weigh station', 
      'scale ahead',
      'balança à frente',
      'báscula adelante',
      'peso à frente'
    ],
    availableCountries: ['USA', 'Canada', 'Mexico', 'Brazil', 'Argentina', 'Chile']
  },
  // Pedágio
  {
    id: 'tollBooth',
    name: 'Pedágio',
    icon: <DollarSign size={24} color="#27ae60" />,
    color: '#27ae60',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 10000, // 10km
    visibilityDuration: 1440, // 24 horas
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic', 'navigation'],
    offlineSupport: true,
    features: ['description', 'verifyLocation'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report toll booth', 
      'toll ahead',
      'pedágio à frente',
      'peaje adelante',
      'maut voraus',
      'péage à venir'
    ],
    availableCountries: ['global']
  },
  // Fronteira
  {
    id: 'borderCrossing',
    name: 'Fronteira/Aduana',
    icon: <Globe size={24} color="#16a085" />,
    color: '#16a085',
    severity: 'medium',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 15000, // 15km
    visibilityDuration: 360, // 6 horas
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['traffic', 'navigation', 'authority'],
    offlineSupport: true,
    features: ['description', 'photos', 'verifyLocation', 'severity'],
    offlineFeatures: ['description', 'verifyLocation', 'severity'],
    voiceCommands: [
      'report border crossing', 
      'border ahead',
      'fronteira à frente',
      'frontera adelante',
      'grenze voraus',
      'frontière à venir'
    ],
    availableCountries: ['global']
  },
  // Preço de combustível
  {
    id: 'fuelPrice',
    name: 'Preço de combustível',
    icon: <Droplet size={24} color="#e67e22" />,
    color: '#e67e22',
    severity: 'low',
    requiresLocation: true,
    allowsPhotos: true,
    notificationRadius: 0, // Não envia notificações
    visibilityDuration: 1440, // 24 horas
    defaultDescription: '',
    userTypes: ['MotoristaComum', 'MotoristaVIP', 'Administrador'],
    requiresApproval: false,
    categories: ['facility', 'navigation'],
    offlineSupport: true,
    features: ['description', 'verifyLocation'],
    offlineFeatures: ['description', 'verifyLocation'],
    voiceCommands: [
      'report fuel price', 
      'diesel price',
      'preço combustível',
      'precio combustible',
      'kraftstoffpreis',
      'prix carburant'
    ],
    availableCountries: ['global']
  }
];

/**
 * Função para encontrar um tipo de reporte pelo ID
 */
export const findReportTypeById = (typeId) => {
  return reportTypes.find(type => type.id === typeId) || null;
};

/**
 * Função para filtrar tipos de reporte por categoria
 */
export const filterReportTypesByCategory = (category) => {
  return reportTypes.filter(type => type.categories.includes(category));
};

/**
 * Função para verificar se um tipo de reporte está disponível para o usuário
 */
export const isReportTypeAvailableForUser = (typeId, userType) => {
  const reportType = findReportTypeById(typeId);
  if (!reportType) return false;
  
  return reportType.userTypes.includes(userType);
};

/**
 * Função para filtrar tipos de reporte por país/região
 */
export const filterReportTypesByCountry = (countryCode) => {
  return reportTypes.filter(type => {
    return type.availableCountries.includes('global') || 
           type.availableCountries.includes(countryCode);
  });
};

/**
 * Função para verificar restrições legais em um país específico
 */
export const checkLegalRestrictions = (typeId, countryCode) => {
  const reportType = findReportTypeById(typeId);
  if (!reportType || !reportType.legalRestrictions) return { restricted: false };
  
  const isRestricted = reportType.legalRestrictions.restrictedCountries.includes(countryCode);
  
  return {
    restricted: isRestricted,
    alternativeLabel: isRestricted ? reportType.legalRestrictions.alternativeLabel : null,
    showWarning: isRestricted && reportType.legalRestrictions.showWarning
  };
};

export default reportTypes;