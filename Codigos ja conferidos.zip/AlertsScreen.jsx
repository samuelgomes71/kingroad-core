/**
 * AlertsScreen.jsx
 * 
 * This component renders the alerts screen for the KingRoad navigation system.
 * It displays safety, traffic, and weather alerts with filtering and sorting capabilities.
 * Supports offline mode through integration with OfflineCacheManager.
 * 
 * @author KingRoad Development Team
 * @version 1.0.0
 */

import React, { useState, useEffect, useCallback, useContext } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Image,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';

// Services
import AlertsService from '../services/AlertsService';
import OfflineCacheManager from '../services/OfflineCacheManager';
import LocationService from '../services/LocationService';
import { TranslationsService } from '../services/TranslationsService';

// Components
import AlertItem from '../components/AlertItem';
import FilterChip from '../components/FilterChip';
import ErrorView from '../components/ErrorView';
import EmptyStateView from '../components/EmptyStateView';

// Context and Theme
import { ThemeContext } from '../contexts/ThemeContext';
import { getThemeStyles } from '../styles/theme';

const AlertsScreen = ({ navigation }) => {
  // Theme context for light/dark mode
  const { theme } = useContext(ThemeContext);
  const themeStyles = getThemeStyles(theme);
  
  // Translation service
  const t = TranslationsService.getTranslation;
  
  // States
  const [alerts, setAlerts] = useState([]);
  const [filteredAlerts, setFilteredAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    safety: true,
    traffic: true,
    weather: true,
  });
  const [sortBy, setSortBy] = useState('distance'); // 'distance', 'time', 'severity'
  const [isConnected, setIsConnected] = useState(true);
  
  // Load alerts when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      loadAlerts();
      
      // Check connection status
      const checkConnection = async () => {
        const connected = await OfflineCacheManager.isConnected();
        setIsConnected(connected);
      };
      
      checkConnection();
      
      // Connection status listener
      const connectionListener = OfflineCacheManager.addConnectionListener((connected) => {
        setIsConnected(connected);
      });
      
      return () => {
        OfflineCacheManager.removeConnectionListener(connectionListener);
      };
    }, [])
  );
  
  // Effect to filter and sort alerts when alerts, filters, or sortBy changes
  useEffect(() => {
    if (alerts.length > 0) {
      applyFiltersAndSort();
    }
  }, [alerts, filters, sortBy]);
  
  /**
   * Loads alerts from service or cache
   */
  const loadAlerts = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Get current location
      const location = await LocationService.getCurrentLocation();
      
      // Get alerts
      const alertsData = await AlertsService.getAlertsAroundLocation(
        location.latitude,
        location.longitude,
        100 // radius in km
      );
      
      setAlerts(alertsData);
      setLoading(false);
    } catch (err) {
      console.error('Error loading alerts:', err);
      
      // Try to load from cache if online fetch failed
      try {
        const cachedAlerts = await OfflineCacheManager.getCachedData('alerts');
        if (cachedAlerts && cachedAlerts.length > 0) {
          setAlerts(cachedAlerts);
          setError({
            message: t('alerts.using_cached_data'),
            type: 'warning',
          });
        } else {
          setError({
            message: t('alerts.error_loading'),
            type: 'error',
          });
        }
      } catch (cacheErr) {
        setError({
          message: t('alerts.error_loading_no_cache'),
          type: 'error',
        });
      }
      
      setLoading(false);
    }
  };
  
  /**
   * Apply filters and sorting to the alerts
   */
  const applyFiltersAndSort = () => {
    // Filter by type
    let result = alerts.filter(alert => {
      if (alert.type === 'safety' && filters.safety) return true;
      if (alert.type === 'traffic' && filters.traffic) return true;
      if (alert.type === 'weather' && filters.weather) return true;
      return false;
    });
    
    // Sort alerts
    if (sortBy === 'distance') {
      result.sort((a, b) => a.distance - b.distance);
    } else if (sortBy === 'time') {
      result.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    } else if (sortBy === 'severity') {
      result.sort((a, b) => b.severity - a.severity);
    }
    
    setFilteredAlerts(result);
  };
  
  /**
   * Toggle a specific filter
   */
  const toggleFilter = (filterName) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: !prev[filterName]
    }));
  };
  
  /**
   * Handle refresh action
   */
  const onRefresh = async () => {
    setRefreshing(true);
    await loadAlerts();
    setRefreshing(false);
  };
  
  /**
   * Navigate to report alert screen
   */
  const navigateToReportAlert = () => {
    navigation.navigate('ReportAlert');
  };
  
  /**
   * Render filter bar
   */
  const renderFilterBar = () => (
    <View style={[styles.filterBar, themeStyles.surface]}>
      <View style={styles.filterChips}>
        <FilterChip
          label={t('alerts.filter_safety')}
          icon="warning"
          active={filters.safety}
          onPress={() => toggleFilter('safety')}
          color="#FF5722"
        />
        <FilterChip
          label={t('alerts.filter_traffic')}
          icon="traffic"
          active={filters.traffic}
          onPress={() => toggleFilter('traffic')}
          color="#2196F3"
        />
        <FilterChip
          label={t('alerts.filter_weather')}
          icon="wb-cloudy"
          active={filters.weather}
          onPress={() => toggleFilter('weather')}
          color="#4CAF50"
        />
      </View>
      
      <View style={styles.sortContainer}>
        <Text style={[styles.sortLabel, themeStyles.textSecondary]}>
          {t('alerts.sort_by')}
        </Text>
        <TouchableOpacity
          style={styles.sortButton}
          onPress={() => {
            // Cycle through sort options
            if (sortBy === 'distance') setSortBy('time');
            else if (sortBy === 'time') setSortBy('severity');
            else setSortBy('distance');
          }}
        >
          <Text style={[styles.sortButtonText, themeStyles.textPrimary]}>
            {sortBy === 'distance' ? t('alerts.sort_distance') : 
             sortBy === 'time' ? t('alerts.sort_time') : 
             t('alerts.sort_severity')}
          </Text>
          <Icon name="arrow-drop-down" size={18} color={themeStyles.textPrimary.color} />
        </TouchableOpacity>
      </View>
    </View>
  );
  
  /**
   * Render connection status banner
   */
  const renderConnectionBanner = () => {
    if (isConnected) return null;
    
    return (
      <View style={styles.offlineBanner}>
        <Icon name="cloud-off" size={16} color="#fff" />
        <Text style={styles.offlineBannerText}>
          {t('common.offline_mode')}
        </Text>
      </View>
    );
  };
  
  /**
   * Main render
   */
  return (
    <SafeAreaView style={[styles.container, themeStyles.background]}>
      {renderConnectionBanner()}
      
      <View style={styles.header}>
        <Text style={[styles.title, themeStyles.textPrimary]}>
          {t('alerts.title')}
        </Text>
        
        <TouchableOpacity
          style={[styles.reportButton, themeStyles.accent]}
          onPress={navigateToReportAlert}
        >
          <Icon name="add-alert" size={20} color="#fff" />
          <Text style={styles.reportButtonText}>
            {t('alerts.report')}
          </Text>
        </TouchableOpacity>
      </View>
      
      {renderFilterBar()}
      
      {loading && !refreshing ? (
        <View style={styles.centerContent}>
          <ActivityIndicator size="large" color={themeStyles.accent.backgroundColor} />
          <Text style={[styles.loadingText, themeStyles.textSecondary]}>
            {t('common.loading')}
          </Text>
        </View>
      ) : error && error.type === 'error' ? (
        <ErrorView
          message={error.message}
          onRetry={loadAlerts}
        />
      ) : filteredAlerts.length === 0 ? (
        <EmptyStateView
          icon="notifications-off"
          message={t('alerts.no_alerts')}
          actionText={t('alerts.change_filters')}
          onAction={() => setFilters({ safety: true, traffic: true, weather: true })}
        />
      ) : (
        <FlatList
          data={filteredAlerts}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => <AlertItem alert={item} navigation={navigation} />}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={error && error.type === 'warning' ? (
            <View style={styles.warningBanner}>
              <Icon name="info" size={16} color="#fff" />
              <Text style={styles.warningBannerText}>{error.message}</Text>
            </View>
          ) : null}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  reportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  reportButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 4,
  },
  filterBar: {
    padding: 12,
    borderRadius: 8,
    marginHorizontal: 16,
    marginBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  filterChips: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  sortLabel: {
    marginRight: 8,
    fontSize: 12,
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sortButtonText: {
    fontWeight: '500',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  offlineBanner: {
    backgroundColor: '#FF9800',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
  },
  offlineBannerText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 6,
  },
  warningBanner: {
    backgroundColor: '#FFC107',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: 6,
    marginBottom: 12,
  },
  warningBannerText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 6,
  },
});

export default AlertsScreen;