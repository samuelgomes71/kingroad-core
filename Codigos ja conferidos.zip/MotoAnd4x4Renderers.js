import React from 'react';
import { View, Text, Switch, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

/**
 * Renderiza as configurações para o modo Moto (Motocicleta)
 * 
 * @param {Object} settings - Configurações atuais do modo Moto
 * @param {Function} updateSetting - Função para atualizar uma configuração específica
 * @param {Object} styles - Estilos a serem aplicados aos componentes
 * @returns {JSX.Element} Componente com as configurações do modo Moto
 */
export const renderMotoSettings = (settings, updateSetting, styles) => (
  <View style={styles.settingsContainer}>
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="record-rec" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Gravação de Rota</Text>
      </View>
      <Switch
        value={settings.recordingEnabled}
        onValueChange={(value) => updateSetting('recordingEnabled', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.recordingEnabled ? '#E91E63' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Tipo de Motocicleta</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.motoType === 'urban' && styles.optionButtonActive,
          { borderColor: '#E91E63' }
        ]}
        onPress={() => updateSetting('motoType', 'urban')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.motoType === 'urban' && styles.optionButtonTextActive
        ]}>Urbana</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.motoType === 'road' && styles.optionButtonActive,
          { borderColor: '#E91E63' }
        ]}
        onPress={() => updateSetting('motoType', 'road')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.motoType === 'road' && styles.optionButtonTextActive
        ]}>Estrada</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.motoType === 'trail' && styles.optionButtonActive,
          { borderColor: '#E91E63' }
        ]}
        onPress={() => updateSetting('motoType', 'trail')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.motoType === 'trail' && styles.optionButtonTextActive
        ]}>Trilha</Text>
      </TouchableOpacity>
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="gas-station" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Mostrar Postos de Combustível</Text>
      </View>
      <Switch
        value={settings.showGasStations}
        onValueChange={(value) => updateSetting('showGasStations', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.showGasStations ? '#E91E63' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="image-filter-hdr" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Preferir Rotas Cênicas</Text>
      </View>
      <Switch
        value={settings.preferScenic}
        onValueChange={(value) => updateSetting('preferScenic', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.preferScenic ? '#E91E63' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="highway" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Evitar Autoestradas</Text>
      </View>
      <Switch
        value={settings.avoidHighways}
        onValueChange={(value) => updateSetting('avoidHighways', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.avoidHighways ? '#E91E63' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="road-variant" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Mostrar Condições da Trilha</Text>
      </View>
      <Switch
        value={settings.showTrailConditions}
        onValueChange={(value) => updateSetting('showTrailConditions', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.showTrailConditions ? '#E91E63' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="altimeter" size={20} color="#E91E63" />
        <Text style={styles.settingLabel}>Registrar Altitude</Text>
      </View>
      <Switch
        value={settings.recordAltitude}
        onValueChange={(value) => updateSetting('recordAltitude', value)}
        trackColor={{ false: '#D1D1D1', true: '#F8BBD0' }}
        thumbColor={settings.recordAltitude ? '#E91E63' : '#F5F5F5'}
      />
    </View>
  </View>
);

/**
 * Renderiza as configurações para o modo 4x4
 * 
 * @param {Object} settings - Configurações atuais do modo 4x4
 * @param {Function} updateSetting - Função para atualizar uma configuração específica
 * @param {Object} styles - Estilos a serem aplicados aos componentes
 * @returns {JSX.Element} Componente com as configurações do modo 4x4
 */
export const render4x4Settings = (settings, updateSetting, styles) => (
  <View style={styles.settingsContainer}>
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="record-rec" size={20} color="#795548" />
        <Text style={styles.settingLabel}>Gravação de Rota</Text>
      </View>
      <Switch
        value={settings.recordingEnabled}
        onValueChange={(value) => updateSetting('recordingEnabled', value)}
        trackColor={{ false: '#D1D1D1', true: '#D7CCC8' }}
        thumbColor={settings.recordingEnabled ? '#795548' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Dimensões do Veículo</Text>
    <View style={styles.vehicleDimensions}>
      <View style={styles.dimensionControl}>
        <Text style={styles.dimensionLabel}>Altura (m)</Text>
        <View style={styles.dimensionButtonsRow}>
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('vehicleHeight', Math.max(1.5, settings.vehicleHeight - 0.1))}
          >
            <Icon name="minus" size={16} color="#795548" />
          </TouchableOpacity>
          
          <Text style={styles.dimensionValue}>{settings.vehicleHeight.toFixed(1)}</Text>
          
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('vehicleHeight', Math.min(4.0, settings.vehicleHeight + 0.1))}
          >
            <Icon name="plus" size={16} color="#795548" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.dimensionControl}>
        <Text style={styles.dimensionLabel}>Largura (m)</Text>
        <View style={styles.dimensionButtonsRow}>
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('vehicleWidth', Math.max(1.5, settings.vehicleWidth - 0.1))}
          >
            <Icon name="minus" size={16} color="#795548" />
          </TouchableOpacity>
          
          <Text style={styles.dimensionValue}>{settings.vehicleWidth.toFixed(1)}</Text>
          
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('vehicleWidth', Math.min(3.0, settings.vehicleWidth + 0.1))}
          >
            <Icon name="plus" size={16} color="#795548" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.dimensionControl}>
        <Text style={styles.dimensionLabel}>Altura Livre (m)</Text>
        <View style={styles.dimensionButtonsRow}>
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('clearanceHeight', Math.max(0.1, settings.clearanceHeight - 0.1))}
          >
            <Icon name="minus" size={16} color="#795548" />
          </TouchableOpacity>
          
          <Text style={styles.dimensionValue}>{settings.clearanceHeight.toFixed(1)}</Text>
          
          <TouchableOpacity
            style={styles.dimensionButton}
            onPress={() => updateSetting('clearanceHeight', Math.min(1.0, settings.clearanceHeight + 0.1))}
          >
            <Icon name="plus" size={16} color="#795548" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="waves" size={20} color="#795548" />
        <Text style={styles.settingLabel}>Mostrar Travessias de Água</Text>
      </View>
      <Switch
        value={settings.showWaterCrossings}
        onValueChange={(value) => updateSetting('showWaterCrossings', value)}
        trackColor={{ false: '#D1D1D1', true: '#D7CCC8' }}
        thumbColor={settings.showWaterCrossings ? '#795548' : '#F5F5F5'}
      />
    </View>
    
    <View style={styles.settingRow}>
      <View style={styles.settingInfo}>
        <Icon name="trail-sign" size={20} color="#795548" />
        <Text style={styles.settingLabel}>Mostrar Trilhas Off-Road</Text>
      </View>
      <Switch
        value={settings.showOffRoadTrails}
        onValueChange={(value) => updateSetting('showOffRoadTrails', value)}
        trackColor={{ false: '#D1D1D1', true: '#D7CCC8' }}
        thumbColor={settings.showOffRoadTrails ? '#795548' : '#F5F5F5'}
      />
    </View>
    
    <Text style={styles.settingGroupTitle}>Nível de Dificuldade</Text>
    <View style={styles.optionButtonsRow}>
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyClearance === 'beginner' && styles.optionButtonActive,
          { borderColor: '#795548' }
        ]}
        onPress={() => updateSetting('difficultyClearance', 'beginner')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyClearance === 'beginner' && styles.optionButtonTextActive
        ]}>Iniciante</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyClearance === 'intermediate' && styles.optionButtonActive,
          { borderColor: '#795548' }
        ]}
        onPress={() => updateSetting('difficultyClearance', 'intermediate')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyClearance === 'intermediate' && styles.optionButtonTextActive
        ]}>Intermediário</Text>
      </TouchableOpacity>
      
      <TouchableOpacity
        style={[
          styles.optionButton,
          settings.difficultyClearance === 'advanced' && styles.optionButtonActive,
          { borderColor: '#795548' }
        ]}
        onPress={() => updateSetting('difficultyClearance', 'advanced')}
      >
        <Text style={[
          styles.optionButtonText,
          settings.difficultyClearance === 'advanced' && styles.optionButtonTextActive
        ]}>Avançado</Text>
      </TouchableOpacity>
    </View>
  </View>
);