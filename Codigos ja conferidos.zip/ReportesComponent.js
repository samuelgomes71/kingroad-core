import React, { useState, useEffect, useContext } from 'react';
import { View, TouchableOpacity, StyleSheet, Text, Platform } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import { useConnectivity } from '../hooks/useConnectivity';
import { LocaleContext } from '../contexts/LocaleContext';
import ReportModal from './ReportModal';
import Icon from '../components/common/Icon';
import VoiceCommandListener from '../services/VoiceCommandListener';
import reportTypesConfig from '../config/reportTypesConfig';
import { queueReport, syncReports } from '../services/ReportSyncService';

/**
 * Componente de Reportes Rápidos para o sistema KingRoad
 * Permite aos motoristas reportar ocorrências na estrada
 * com suporte a múltiplos idiomas, modo offline e comandos de voz
 */
const ReportesComponent = ({ screen, position = 'bottomOverlay' }) => {
  const { t } = useTranslation();
  const { theme, isDark } = useTheme();
  const { isConnected } = useConnectivity();
  const { currentLocale, country } = useContext(LocaleContext);
  
  const [isModalVisible, setModalVisible] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState(null);
  const [availableReports, setAvailableReports] = useState([]);

  // Carregar tipos de relatórios disponíveis com base no país/região
  useEffect(() => {
    // Filtra os reportes com base na localização atual
    const reports = reportTypesConfig.filter(report => 
      report.availableCountries.includes(country) || report.availableCountries.includes('global')
    );
    setAvailableReports(reports);
  }, [country]);

  // Configurar listener de comandos de voz para reportes
  useEffect(() => {
    const voiceListener = VoiceCommandListener.initialize();
    
    // Registrar comandos para cada tipo de reporte
    availableReports.forEach(report => {
      // Registra comando em diferentes idiomas conforme configuração
      report.voiceCommands.forEach(command => {
        voiceListener.registerCommand(command, () => handleReportSelection(report.id));
      });
    });
    
    return () => voiceListener.destroy();
  }, [availableReports, currentLocale]);

  // Sincronizar reportes pendentes quando recuperar conexão
  useEffect(() => {
    if (isConnected) {
      syncReports().catch(err => 
        console.error('Erro ao sincronizar reportes pendentes:', err)
      );
    }
  }, [isConnected]);

  const handleReportSelection = (reportId) => {
    setSelectedReportType(reportId);
    setModalVisible(true);
  };

  const handleSubmitReport = async (reportData) => {
    try {
      // Adicionar dados adicionais ao reporte
      const completeReport = {
        ...reportData,
        timestamp: new Date().toISOString(),
        location: {
          // Dados de localização seriam obtidos via GPS
          latitude: 0, 
          longitude: 0
        },
        deviceId: 'unique-device-id',
        reportType: selectedReportType,
        locale: currentLocale,
        offline: !isConnected
      };

      // Se estiver offline, armazena para sincronização posterior
      if (!isConnected) {
        await queueReport(completeReport);
      } else {
        // Implementação do envio direto para o servidor
        // apiService.sendReport(completeReport)
      }
      
      setModalVisible(false);
      // Exibir feedback visual de sucesso
    } catch (error) {
      console.error('Erro ao enviar reporte:', error);
      // Exibir feedback de erro
    }
  };

  // Verifica se o componente deve ser renderizado na tela atual
  const shouldRender = [
    'MainMapScreen',
    'NavigationScreen', 
    'HomeDashboard'
  ].includes(screen);

  if (!shouldRender) return null;

  return (
    <View style={[
      styles.container, 
      position === 'bottomOverlay' ? styles.bottomPosition : styles.sidePosition,
      { backgroundColor: isDark ? 'rgba(20,20,20,0.8)' : 'rgba(255,255,255,0.8)' }
    ]}>
      {availableReports.map(report => (
        <TouchableOpacity
          key={report.id}
          style={styles.reportButton}
          onPress={() => handleReportSelection(report.id)}
          accessibilityLabel={t(`reports.accessibility.${report.id}`)}
        >
          <Icon 
            name={report.icon} 
            size="medium" 
            color={report.color || theme.colors.primary} 
          />
          <Text style={[
            styles.reportText,
            { color: isDark ? theme.colors.textLight : theme.colors.textDark }
          ]}>
            {t(`reports.types.${report.id}`)}
          </Text>
        </TouchableOpacity>
      ))}
      
      {!isConnected && (
        <View style={styles.offlineIndicator}>
          <Icon name="wifi-off" size="small" color={theme.colors.warning} />
          <Text style={[styles.offlineText, { color: theme.colors.warning }]}>
            {t('common.offlineMode')}
          </Text>
        </View>
      )}

      <ReportModal
        visible={isModalVisible}
        reportType={selectedReportType}
        onClose={() => setModalVisible(false)}
        onSubmit={handleSubmitReport}
        isOffline={!isConnected}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 10,
    borderRadius: 10,
    margin: 10,
    justifyContent: 'space-around',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  bottomPosition: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
  },
  sidePosition: {
    position: 'absolute',
    top: 100,
    right: 10,
    flexDirection: 'column',
  },
  reportButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  reportText: {
    fontSize: 12,
    marginTop: 5,
    textAlign: 'center',
  },
  offlineIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    position: 'absolute',
    top: -20,
    right: 10,
  },
  offlineText: {
    fontSize: 10,
    marginLeft: 5,
  },
});

export default ReportesComponent;