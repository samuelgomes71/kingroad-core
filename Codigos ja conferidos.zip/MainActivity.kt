package com.kingfamily.kingroad

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.kingfamily.common.utils.ResourceDownloader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        private const val APP_NAME = "KingRoad"
        private const val DEVELOPER_MODE_TAP_COUNT = 5 // Número de toques necessários para ativar o modo desenvolvedor
    }

    private lateinit var resourceDownloader: ResourceDownloader
    private lateinit var appLogo: ImageView
    private lateinit var menuButton: View
    private lateinit var searchButton: View
    private var logoTapCount = 0 // Contador para ativar o modo desenvolvedor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa o ResourceDownloader
        resourceDownloader = ResourceDownloader(this)

        // Setup do logo no canto superior esquerdo
        setupAppLogo()

        // Setup do botão de menu personalizado
        setupCustomMenuButton()

        // Setup do botão de busca
        setupSearchButton()
    }

    /**
     * Configura o logo do aplicativo no canto superior esquerdo
     */
    private fun setupAppLogo() {
        appLogo = findViewById(R.id.app_logo)
        
        // Carrega o logo apropriado para o tamanho da tela
        loadAppLogo()
        
        // Configura o detector de cliques para ativar o modo desenvolvedor
        setupDeveloperModeDetector()
    }

    /**
     * Carrega o logo do aplicativo com base no tamanho da tela
     */
    private fun loadAppLogo() {
        CoroutineScope(Dispatchers.Main).launch {
            val screenSize = resourceDownloader.getScreenSizeCategory()
            
            // Tenta obter o logo baixado do CDN
            val logoFile = resourceDownloader.getResourceFile(
                ResourceDownloader.Companion.ResourceType.LOGO,
                APP_NAME,
                screenSize
            )
            
            // Se o logo foi baixado com sucesso, usa-o
            if (logoFile != null && logoFile.exists()) {
                appLogo.setImageURI(android.net.Uri.fromFile(logoFile))
            } else {
                // Caso contrário, usa o logo padrão do projeto
                val resourceId = getLogoResourceByScreenSize(screenSize)
                appLogo.setImageResource(resourceId)
                
                // Tenta baixar o logo em segundo plano para uso futuro
                downloadLogoInBackground(screenSize)
            }
        }
    }

    /**
     * Retorna o ID do recurso de logo com base no tamanho da tela
     */
    private fun getLogoResourceByScreenSize(
        screenSize: ResourceDownloader.Companion.ScreenSizeCategory
    ): Int {
        return when (screenSize) {
            ResourceDownloader.Companion.ScreenSizeCategory.SMALL -> R.drawable.logo_king_family_small
            ResourceDownloader.Companion.ScreenSizeCategory.MEDIUM -> R.drawable.logo_king_family_medium
            ResourceDownloader.Companion.ScreenSizeCategory.LARGE -> R.drawable.logo_king_family_large
            ResourceDownloader.Companion.ScreenSizeCategory.XLARGE -> R.drawable.logo_king_family_xlarge
        }
    }

    /**
     * Baixa o logo em segundo plano
     */
    private fun downloadLogoInBackground(
        screenSize: ResourceDownloader.Companion.ScreenSizeCategory
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val file = resourceDownloader.downloadResource(
                    ResourceDownloader.Companion.ResourceType.LOGO,
                    APP_NAME,
                    screenSize
                )
                
                // Se o download foi bem-sucedido, atualiza a UI
                if (file != null) {
                    withContext(Dispatchers.Main) {
                        appLogo.setImageURI(android.net.Uri.fromFile(file))
                    }
                }
            } catch (e: Exception) {
                // Ignora erros de download, já que o logo padrão já foi exibido
            }
        }
    }

    /**
     * Configura o detector de cliques para ativar o modo desenvolvedor
     */
    private fun setupDeveloperModeDetector() {
        appLogo.setOnClickListener {
            logoTapCount++
            if (logoTapCount >= DEVELOPER_MODE_TAP_COUNT) {
                // Ativa o modo desenvolvedor
                promptDeveloperModePassword()
                logoTapCount = 0
            } else {
                // Reseta o contador depois de 3 segundos sem cliques
                appLogo.postDelayed({ logoTapCount = 0 }, 3000)
            }
        }
    }

    /**
     * Exibe a solicitação de senha para o modo desenvolvedor
     */
    private fun promptDeveloperModePassword() {
        // Implementar a lógica de solicitação de senha aqui
        // Por enquanto, apenas exibe um toast informativo
        Toast.makeText(
            this,
            getString(R.string.developer_mode_prompt),
            Toast.LENGTH_SHORT
        ).show()
    }

    /**
     * Configura o botão de menu personalizado
     */
    private fun setupCustomMenuButton() {
        // Inflater para o botão de menu
        val inflater = LayoutInflater.from(this)
        val mainLayout = findViewById<ConstraintLayout>(R.id.main_container)
        
        // Infla o botão de menu
        menuButton = inflater.inflate(R.layout.main_menu_button, mainLayout, false)
        
        // Adiciona o botão ao layout principal
        mainLayout.addView(menuButton)
        
        // Posiciona o botão no canto inferior esquerdo
        val params = menuButton.layoutParams as ConstraintLayout.LayoutParams
        params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        params.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID
        params.bottomMargin = resources.getDimensionPixelSize(R.dimen.margin_medium)
        params.leftMargin = resources.getDimensionPixelSize(R.dimen.margin_medium)
        menuButton.layoutParams = params
        
        // Configura o clique do botão de menu
        menuButton.setOnClickListener {
            showMainMenu()
        }
    }

    /**
     * Configura o botão de busca
     */
    private fun setupSearchButton() {
        searchButton = findViewById(R.id.search_button)
        searchButton.setOnClickListener {
            // Implementar a lógica de busca aqui
            Toast.makeText(
                this,
                getString(R.string.search_not_implemented),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * Exibe o menu principal
     */
    private fun showMainMenu() {
        // Implementar a lógica de exibição do menu aqui
        Toast.makeText(
            this,
            getString(R.string.menu_not_implemented),
            Toast.LENGTH_SHORT
        ).show()
    }
}