// BrazilEmergencyAlertModal.jsx
import React, { useEffect, useRef } from 'react';
import { XCircle, AlertTriangle, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui';
import { KingLocBridge } from '../services/KingLocBridge';

/**
 * Componente de Modal de Alerta de Emergência estilo AMBER Alert/EAS
 * para alertas de alta prioridade no Brasil (tiroteio, sequestro, etc.)
 */
const BrazilEmergencyAlertModal = ({ alert, onClose }) => {
  const audioRef = useRef(null);
  const vibrationRef = useRef(null);
  const kingLocBridge = useRef(new KingLocBridge());
  
  // Efeito para reproduzir som de alerta ao montar o componente
  useEffect(() => {
    // Reproduzir som de alerta EAS
    if (audioRef.current) {
      // Garantir volume máximo independente das configurações do usuário
      audioRef.current.volume = 1.0;
      audioRef.current.play().catch(err => 
        console.error('Erro ao reproduzir som de alerta:', err)
      );
    }
    
    // Iniciar vibração com padrão específico (500ms on, 500ms off, 500ms on, 1500ms off)
    if (window.navigator && window.navigator.vibrate) {
      vibrationRef.current = setInterval(() => {
        window.navigator.vibrate([500, 500, 500, 1500]);
      }, 3000);
    }
    
    // Limpar ao desmontar
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      
      if (vibrationRef.current) {
        clearInterval(vibrationRef.current);
        if (window.navigator && window.navigator.vibrate) {
          window.navigator.vibrate(0); // Parar vibração
        }
      }
    };
  }, []);
  
  // Formata as informações específicas conforme o tipo de alerta
  const renderAlertDetails = () => {
    switch (alert.type) {
      case 'SHOOTING':
        return (
          <div className="alert-details">
            <h3 className="text-lg font-bold mb-2">TIROTEIO REPORTADO</h3>
            <p>
              <strong>Local:</strong> {calculateAddress(alert.latitude, alert.longitude)}
            </p>
            {alert.shootingInfo?.intensity && (
              <p>
                <strong>Intensidade:</strong> {
                  alert.shootingInfo.intensity === 'HIGH' ? 'ALTA' :
                  alert.shootingInfo.intensity === 'MEDIUM' ? 'MÉDIA' : 'BAIXA'
                }
              </p>
            )}
            <div className="recommendations mt-2 p-2 border border-black rounded bg-white bg-opacity-10">
              <p className="font-bold">RECOMENDAÇÕES:</p>
              <ul className="list-disc pl-5">
                <li>Evite a área</li>
                <li>Se estiver próximo, procure abrigo</li>
                <li>Reporte às autoridades - 190</li>
                <li>Aguarde até que a situação esteja controlada</li>
              </ul>
            </div>
          </div>
        );
        
      case 'KIDNAPPING':
        return (
          <div className="alert-details">
            <h3 className="text-lg font-bold mb-2">
              {alert.kidnappingInfo?.kidnapType === 'MASS_ROBBERY' ? 
                'ARRASTÃO REPORTADO' : 'SEQUESTRO REPORTADO'}
            </h3>
            <p>
              <strong>Local:</strong> {calculateAddress(alert.latitude, alert.longitude)}
            </p>
            {alert.kidnappingInfo?.vehiclesCount && (
              <p>
                <strong>Veículos envolvidos:</strong> {alert.kidnappingInfo.vehiclesCount}
              </p>
            )}
            {alert.description && (
              <p>
                <strong>Detalhes:</strong> {alert.description}
              </p>
            )}
            <div className="recommendations mt-2 p-2 border border-black rounded bg-white bg-opacity-10">
              <p className="font-bold">RECOMENDAÇÕES:</p>
              <ul className="list-disc pl-5">
                <li>Evite a área imediatamente</li>
                <li>Reporte às autoridades - 190</li>
                <li>Não pare o veículo nas proximidades</li>
                <li>Utilize rotas alternativas</li>
              </ul>
            </div>
          </div>
        );
        
      default:
        return (
          <div className="alert-details">
            <h3 className="text-lg font-bold mb-2">ALERTA DE EMERGÊNCIA</h3>
            <p>
              <strong>Local:</strong> {calculateAddress(alert.latitude, alert.longitude)}
            </p>
            {alert.description && (
              <p>
                <strong>Detalhes:</strong> {alert.description}
              </p>
            )}
            <div className="recommendations mt-2 p-2 border border-black rounded bg-white bg-opacity-10">
              <p className="font-bold">RECOMENDAÇÕES:</p>
              <ul className="list-disc pl-5">
                <li>Permaneça alerta</li>
                <li>Evite a área se possível</li>
                <li>Considere rotas alternativas</li>
              </ul>
            </div>
          </div>
        );
    }
  };
  
  // Calcula endereço simplificado a partir das coordenadas (simulação)
  const calculateAddress = (lat, lng) => {
    // Em uma implementação real, isso usaria uma API de geocodificação reversa
    // Para fins de demonstração, retornamos uma string genérica com as coordenadas
    return `Próximo a ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  };
  
  // Estima o tempo desde que o alerta foi reportado
  const getTimeElapsed = () => {
    if (!alert.timestamp) return 'Agora';
    
    const alertTime = new Date(alert.timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now - alertTime) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Agora';
    if (diffInMinutes === 1) return '1 minuto atrás';
    if (diffInMinutes < 60) return `${diffInMinutes} minutos atrás`;
    
    const hours = Math.floor(diffInMinutes / 60);
    if (hours === 1) return '1 hora atrás';
    return `${hours} horas atrás`;
  };
  
  return (
    <div className="emergency-alert-modal fixed inset-0 z-50 flex items-center justify-center">
      {/* Overlay escuro */}
      <div className="fixed inset-0 bg-black bg-opacity-75"></div>
      
      {/* Modal com estilo AMBER Alert */}
      <div className="emergency-alert-content relative w-full max-w-xl bg-amber-500 text-black p-5 mx-4 rounded-lg shadow-lg z-10 border-2 border-black">
        {/* Cabeçalho do alerta */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <AlertTriangle size={24} className="mr-2" />
            <span className="font-bold uppercase tracking-wider">Alerta de Emergência</span>
          </div>
          <button 
            onClick={onClose}
            className="text-black hover:text-gray-800"
          >
            <XCircle size={24} />
          </button>
        </div>
        
        {/* Corpo do alerta */}
        <div className="mb-4">
          {renderAlertDetails()}
        </div>
        
        {/* Rodapé do alerta */}
        <div className="flex flex-col sm:flex-row justify-between items-center mt-4 pt-2 border-t border-black">
          <div className="text-sm">
            <p><strong>Reportado:</strong> {getTimeElapsed()}</p>
            <p><strong>Fonte:</strong> Motorista KingRoad</p>
          </div>
          
          <div className="flex space-x-2 mt-3 sm:mt-0">
            <Button
              onClick={() => {
                // Pausa o som
                if (audioRef.current) {
                  audioRef.current.pause();
                  audioRef.current.currentTime = 0;
                }
                onClose();
              }}
              className="bg-gray-800 hover:bg-gray-900 text-white"
            >
              Descartar
            </Button>
            
            <Button
              onClick={() => {
                // Navegar para o local usando KingLoc
                kingLocBridge.current.navigateTo(alert.latitude, alert.longitude);
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Ver no Mapa
            </Button>
          </div>
        </div>
      </div>
      
      {/* Audio de alerta */}
      <audio ref={audioRef} loop>
        <source src="/assets/audio/emergency_alert_system.mp3" type="audio/mpeg" />
      </audio>
    </div>
  );
};

export default BrazilEmergencyAlertModal;