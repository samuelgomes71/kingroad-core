package com.kingroad.poi

import com.kingroad.common.Location
import com.kingroad.database.PersonalPoiDatabase
import com.kingroad.database.PoiRequestsQueue
import com.kingroad.utils.GeoUtils
import com.kingroad.utils.ValidationUtils
import com.kingroad.utils.FileUtils
import java.util.UUID

/**
 * Sistema de POIs para estacionamentos de caminhões (Truck Parking)
 * 
 * Características:
 * - POIs pessoais que só aparecem para o usuário que os cadastrou
 * - Possibilidade de solicitar à equipe do KingRoad a adição oficial de POIs
 * - Compatível com qualquer tipo de terreno (asfaltado, terra, etc.)
 */

// Enums para características do estacionamento
enum class ParkingSurfaceType {
    PAVED,              // Asfaltado
    GRAVEL,             // Cascalho
    DIRT,               // Terra
    CONCRETE,           // Concreto
    MIXED,              // Misto
    UNKNOWN             // Desconhecido
}

enum class ParkingSecurityLevel {
    NONE,               // Sem segurança
    BASIC,              // Segurança básica (iluminação, etc.)
    GUARDED,            // Vigiado/guardado
    GATED,              // Cercado/portão
    SECURE,             // Seguro (câmeras, cercas, portão)
    UNKNOWN             // Desconhecido
}

enum class ParkingSizeCategory {
    SMALL,              // Pequeno (1-5 caminhões)
    MEDIUM,             // Médio (6-20 caminhões)
    LARGE,              // Grande (21-50 caminhões)
    VERY_LARGE,         // Muito grande (50+ caminhões)
    UNKNOWN             // Desconhecido
}

// Classe principal para POI de estacionamento pessoal
data class PersonalTruckParkingPoi(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val location: Location,
    val userId: String,                      // ID do usuário que criou o POI
    val description: String = "",
    val surfaceType: ParkingSurfaceType = ParkingSurfaceType.UNKNOWN,
    val securityLevel: ParkingSecurityLevel = ParkingSecurityLevel.UNKNOWN,
    val sizeCategory: ParkingSizeCategory = ParkingSizeCategory.UNKNOWN,
    val isFree: Boolean = true,              // É gratuito?
    val price: Double? = null,               // Preço se não for gratuito
    val hasFacilities: Boolean = false,      // Tem instalações (banheiro, etc)?
    val hasRestaurant: Boolean = false,      // Tem restaurante/lanchonete perto?
    val notes: String = "",                  // Observações adicionais
    val rating: Int = 0,                     // Classificação pessoal (0-5)
    val photoPaths: List<String> = emptyList(), // Fotos tiradas pelo usuário
    val creationDate: Long = System.currentTimeMillis(),
    val lastVisitDate: Long? = null,         // Última vez que o usuário esteve lá
    val isAccessible: Boolean = true,        // Ainda é acessível ou foi fechado?
    val countryCode: String = "",
    val regionCode: String = "",
    val address: String = ""
)

// Classe para solicitação de adição oficial de POI
data class TruckParkingPoiRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val location: Location,
    val userId: String,                      // ID do usuário que fez a solicitação
    val description: String = "",
    val surfaceType: ParkingSurfaceType = ParkingSurfaceType.UNKNOWN,
    val securityLevel: ParkingSecurityLevel = ParkingSecurityLevel.UNKNOWN,
    val sizeCategory: ParkingSizeCategory = ParkingSizeCategory.UNKNOWN,
    val isFree: Boolean = true,              // É gratuito?
    val price: Double? = null,               // Preço se não for gratuito
    val hasFacilities: Boolean = false,      // Tem instalações (banheiro, etc)?
    val hasRestaurant: Boolean = false,      // Tem restaurante/lanchonete perto?
    val notes: String = "",                  // Observações adicionais
    val photoPaths: List<String> = emptyList(), // Fotos enviadas como evidência
    val submissionDate: Long = System.currentTimeMillis(),
    val status: RequestStatus = RequestStatus.PENDING,
    val reviewNotes: String = "",            // Notas da revisão pela equipe
    val countryCode: String = "",
    val regionCode: String = "",
    val address: String = "",
    val votes: Int = 1                       // Votos de outros usuários (começa com 1 do solicitante)
)

// Status de solicitação de POI
enum class RequestStatus {
    PENDING,        // Aguardando revisão
    APPROVED,       // Aprovado e adicionado ao sistema oficial
    REJECTED,       // Rejeitado
    NEEDS_INFO      // Precisa de mais informações
}

// Gerenciador de POIs pessoais de estacionamento
class PersonalTruckParkingPoiManager(
    private val database: PersonalPoiDatabase
) {
    
    // Adiciona um novo POI pessoal
    fun addPersonalParkingPoi(poi: PersonalTruckParkingPoi): String {
        validatePoi(poi)
        database.addPersonalParkingPoi(poi)
        return poi.id
    }
    
    // Atualiza um POI existente
    fun updatePersonalParkingPoi(poi: PersonalTruckParkingPoi): Boolean {
        validatePoi(poi)
        return database.updatePersonalParkingPoi(poi)
    }
    
    // Exclui um POI
    fun deletePersonalParkingPoi(poiId: String, userId: String): Boolean {
        return database.deletePersonalParkingPoi(poiId, userId)
    }
    
    // Marca um POI como fechado/inacessível
    fun markPoiAsInaccessible(poiId: String, userId: String): Boolean {
        val poi = database.getPersonalParkingPoi(poiId, userId) ?: return false
        return database.updatePersonalParkingPoi(poi.copy(isAccessible = false))
    }
    
    // Busca por estacionamentos próximos à localização atual (apenas do usuário)
    fun findNearbyPersonalParkingPois(
        location: Location,
        userId: String,
        radiusKm: Double = 100.0,
        includeInaccessible: Boolean = false
    ): List<PersonalTruckParkingPoi> {
        val allPois = database.getPersonalParkingPoisByUser(userId)
        
        return allPois.filter { poi ->
            // Filtra por distância
            val isNearby = GeoUtils.isWithinRadius(location, poi.location, radiusKm)
            
            // Filtra por acessibilidade
            val isAccessibleOrIncluded = includeInaccessible || poi.isAccessible
            
            isNearby && isAccessibleOrIncluded
        }
    }
    
    // Anexa foto a um POI existente
    fun attachPhotoToPersonalPoi(poiId: String, userId: String, photoPath: String): Boolean {
        val poi = database.getPersonalParkingPoi(poiId, userId) ?: return false
        
        try {
            // Copia a foto para armazenamento permanente
            val permanentPath = FileUtils.copyImageToPermanentStorage(
                photoPath, 
                "personal_pois/${userId}/${poiId}/"
            )
            
            // Atualiza o POI com o novo caminho de foto
            val updatedPhotos = poi.photoPaths + permanentPath
            return database.updatePersonalParkingPoi(poi.copy(photoPaths = updatedPhotos))
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }
    
    // Atualiza a classificação pessoal de um POI
    fun updatePersonalPoiRating(poiId: String, userId: String, rating: Int): Boolean {
        if (rating !in 0..5) return false
        
        val poi = database.getPersonalParkingPoi(poiId, userId) ?: return false
        return database.updatePersonalParkingPoi(poi.copy(rating = rating))
    }
    
    // Atualiza a data da última visita a um POI
    fun updateLastVisitDate(poiId: String, userId: String): Boolean {
        val poi = database.getPersonalParkingPoi(poiId, userId) ?: return false
        return database.updatePersonalParkingPoi(
            poi.copy(lastVisitDate = System.currentTimeMillis())
        )
    }
    
    // Valida informações do POI
    private fun validatePoi(poi: PersonalTruckParkingPoi) {
        require(poi.name.isNotBlank()) { "Nome do estacionamento não pode estar vazio" }
        require(ValidationUtils.isValidLatitude(poi.location.latitude)) { "Latitude inválida" }
        require(ValidationUtils.isValidLongitude(poi.location.longitude)) { "Longitude inválida" }
        require(poi.userId.isNotBlank()) { "ID do usuário não pode estar vazio" }
        
        // Valida preço quando não é gratuito
        if (!poi.isFree) {
            requireNotNull(poi.price) { "Preço deve ser fornecido quando o estacionamento não é gratuito" }
            require(poi.price > 0) { "Preço deve ser maior que zero" }
        }
    }
}

// Gerenciador de solicitações de POIs oficiais
class TruckParkingPoiRequestManager(
    private val requestsQueue: PoiRequestsQueue,
    private val networkManager: NetworkManager
) {
    
    // Solicita adição de um novo POI oficial
    fun requestNewOfficialPoi(request: TruckParkingPoiRequest): String {
        validateRequest(request)
        requestsQueue.addParkingPoiRequest(request)
        
        // Envia para o servidor se estiver online
        if (networkManager.isOnline()) {
            uploadRequestToServer(request.id)
        }
        
        return request.id
    }
    
    // Solicita com base em um POI pessoal existente
    fun requestFromPersonalPoi(personalPoi: PersonalTruckParkingPoi): String {
        val request = TruckParkingPoiRequest(
            name = personalPoi.name,
            location = personalPoi.location,
            userId = personalPoi.userId,
            description = personalPoi.description,
            surfaceType = personalPoi.surfaceType,
            securityLevel = personalPoi.securityLevel,
            sizeCategory = personalPoi.sizeCategory,
            isFree = personalPoi.isFree,
            price = personalPoi.price,
            hasFacilities = personalPoi.hasFacilities,
            hasRestaurant = personalPoi.hasRestaurant,
            notes = personalPoi.notes,
            photoPaths = personalPoi.photoPaths,
            countryCode = personalPoi.countryCode,
            regionCode = personalPoi.regionCode,
            address = personalPoi.address
        )
        
        return requestNewOfficialPoi(request)
    }
    
    // Anexa foto a uma solicitação existente
    fun attachPhotoToRequest(requestId: String, userId: String, photoPath: String): Boolean {
        val request = requestsQueue.getRequestById(requestId) ?: return false
        
        // Verifica se o usuário é o mesmo que criou a solicitação
        if (request.userId != userId) return false
        
        try {
            // Copia a foto para armazenamento permanente
            val permanentPath = FileUtils.copyImageToPermanentStorage(
                photoPath, 
                "poi_requests/${requestId}/"
            )
            
            // Atualiza a solicitação com o novo caminho de foto
            val updatedPhotos = request.photoPaths + permanentPath
            return requestsQueue.updateRequest(request.copy(photoPaths = updatedPhotos))
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }
    
    // Adiciona um voto a uma solicitação existente
    fun voteForRequest(requestId: String): Boolean {
        val request = requestsQueue.getRequestById(requestId) ?: return false
        return requestsQueue.updateRequest(request.copy(votes = request.votes + 1))
    }
    
    // Obtém status de uma solicitação
    fun getRequestStatus(requestId: String): RequestStatus? {
        return requestsQueue.getRequestById(requestId)?.status
    }
    
    // Obtém solicitações feitas pelo usuário
    fun getUserRequests(userId: String): List<TruckParkingPoiRequest> {
        return requestsQueue.getRequestsByUser(userId)
    }
    
    // Obtém solicitações pendentes próximas para votação
    fun getNearbyPendingRequests(
        location: Location, 
        radiusKm: Double = 100.0,
        excludeUserId: String? = null
    ): List<TruckParkingPoiRequest> {
        val allRequests = requestsQueue.getPendingRequests()
        
        return allRequests.filter { request ->
            // Filtra por distância
            val isNearby = GeoUtils.isWithinRadius(location, request.location, radiusKm)
            
            // Filtra para excluir as solicitações do próprio usuário
            val isFromOtherUser = excludeUserId?.let { request.userId != it } ?: true
            
            isNearby && isFromOtherUser
        }
    }
    
    // Valida solicitação
    private fun validateRequest(request: TruckParkingPoiRequest) {
        require(request.name.isNotBlank()) { "Nome do estacionamento não pode estar vazio" }
        require(ValidationUtils.isValidLatitude(request.location.latitude)) { "Latitude inválida" }
        require(ValidationUtils.isValidLongitude(request.location.longitude)) { "Longitude inválida" }
        require(request.userId.isNotBlank()) { "ID do usuário não pode estar vazio" }
        
        // Valida preço quando não é gratuito
        if (!request.isFree) {
            requireNotNull(request.price) { "Preço deve ser fornecido quando o estacionamento não é gratuito" }
            require(request.price > 0) { "Preço deve ser maior que zero" }
        }
    }
    
    // Envia solicitação para o servidor
    private fun uploadRequestToServer(requestId: String) {
        // Implementação de upload para o servidor
        // Seria integrado com o sistema de sincronização do KingRoad
    }
}

// Classe stub para NetworkManager
class NetworkManager {
    fun isOnline(): Boolean = true
}