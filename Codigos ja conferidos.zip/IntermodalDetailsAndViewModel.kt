package com.kingroad.ui.navigation.intermodal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kingroad.R
import com.kingroad.navigation.intermodal.*
import com.kingroad.ui.theme.KingRoadColors
import com.kingroad.utils.formatCurrency
import com.kingroad.utils.formatDuration
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

/**
 * Chip que exibe uma conexão intermodal
 */
@Composable
fun ConnectionChip(
    connection: IntermodalConnection,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val chipModifier = if (onClick != null) {
        modifier.clickable(onClick = onClick)
    } else {
        modifier
    }
    
    Surface(
        modifier = chipModifier,
        shape = RoundedCornerShape(16.dp),
        color = when (connection.type) {
            ConnectionType.FERRY, ConnectionType.PASSENGER_FERRY -> Color(0xFFBBDEFB)
            ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL, ConnectionType.TRAIN_TUNNEL -> Color(0xFFFFECB3)
            ConnectionType.BRIDGE_TOLL -> Color(0xFFDCEDC8)
        }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ícone baseado no tipo de conexão
            Icon(
                imageVector = when (connection.type) {
                    ConnectionType.FERRY, ConnectionType.PASSENGER_FERRY -> Icons.Default.DirectionsBoat
                    ConnectionType.CAR_TUNNEL, ConnectionType.TRUCK_TUNNEL, ConnectionType.TRAIN_TUNNEL -> Icons.Default.Route
                    ConnectionType.BRIDGE_TOLL -> Icons.Default.Bridge
                },
                contentDescription = null,
                tint = KingRoadColors.TextColor,
                modifier = Modifier.size(16.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = connection.name,
                style = MaterialTheme.typography.bodySmall,
                color = KingRoadColors.TextColor
            )
            
            // Exibir preço se disponível
            if (connection.baseFee != null) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "(${formatCurrency(connection.baseFee, connection.currency)})",
                    style = MaterialTheme.typography.bodySmall,
                    color = KingRoadColors.TextColor.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * Diálogo para exibir detalhes de uma conexão intermodal
 */
@Composable
fun ConnectionDetailsDialog(
    connection: IntermodalConnection,
    onDismiss: () -> Unit,
    onShowFullDetails: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Cabeçalho
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Título da conexão
                    Text(
                        text = connection.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = KingRoadColors.TextColor
                    )
                    
                    // Botão fechar
                    IconButton(onClick = onDismiss) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = stringResource(R.string.close),
                            tint = KingRoadColors.TextColor
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Tipo de conexão
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val (icon, typeName) = when (connection.type) {
                        ConnectionType.FERRY -> Pair(
                            Icons.Default.DirectionsBoat,
                            stringResource(R.string.vehicle_ferry)
                        )
                        ConnectionType.PASSENGER_FERRY -> Pair(
                            Icons.Default.DirectionsBoat,
                            stringResource(R.string.passenger_ferry)
                        )
                        ConnectionType.CAR_TUNNEL -> Pair(
                            Icons.Default.Route,
                            stringResource(R.string.car_tunnel)
                        )
                        ConnectionType.TRUCK_TUNNEL -> Pair(
                            Icons.Default.Route,
                            stringResource(R.string.truck_tunnel)
                        )
                        ConnectionType.TRAIN_TUNNEL -> Pair(
                            Icons.Default.Train,
                            stringResource(R.string.train_tunnel)
                        )
                        ConnectionType.BRIDGE_TOLL -> Pair(
                            Icons.Default.Bridge,
                            stringResource(R.string.bridge_toll)
                        )
                    }
                    
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = KingRoadColors.Accent,
                        modifier = Modifier.size(24.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = typeName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = KingRoadColors.TextColor
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Detalhes principais
                ConnectionDetailItem(
                    icon = Icons.Default.Place,
                    label = stringResource(R.string.route),
                    value = "${connection.startLocation.name ?: ""} → ${connection.endLocation.name ?: ""}"
                )
                
                ConnectionDetailItem(
                    icon = Icons.Default.Map,
                    label = stringResource(R.string.distance),
                    value = "${connection.distance} km"
                )
                
                ConnectionDetailItem(
                    icon = Icons.Default.Timer,
                    label = stringResource(R.string.duration),
                    value = formatDuration(connection.averageDuration)
                )
                
                if (connection.averageWaitingTime > 0) {
                    ConnectionDetailItem(
                        icon = Icons.Default.HourglassBottom,
                        label = stringResource(R.string.avg_waiting_time),
                        value = formatDuration(connection.averageWaitingTime)
                    )
                }
                
                if (connection.baseFee != null) {
                    ConnectionDetailItem(
                        icon = Icons.Default.Payments,
                        label = stringResource(R.string.fee),
                        value = formatCurrency(connection.baseFee, connection.currency)
                    )
                }
                
                ConnectionDetailItem(
                    icon = if (connection.hasSchedule) Icons.Default.Schedule else Icons.Default.Update,
                    label = stringResource(R.string.schedule),
                    value = if (connection.hasSchedule) 
                        stringResource(R.string.fixed_schedule) 
                    else 
                        stringResource(R.string.continuous_service)
                )
                
                ConnectionDetailItem(
                    icon = Icons.Default.DateRange,
                    label = stringResource(R.string.availability),
                    value = if (connection.operatesAllYear) 
                        stringResource(R.string.all_year) 
                    else 
                        stringResource(R.string.seasonal)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Botões de ação
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = stringResource(R.string.close),
                            color = KingRoadColors.TextColor
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Button(
                        onClick = onShowFullDetails,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = KingRoadColors.Accent
                        )
                    ) {
                        Text(stringResource(R.string.show_full_details))
                    }
                }
            }
        }
    }
}

/**
 * Item de detalhe para a conexão
 */
@Composable
fun ConnectionDetailItem(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = KingRoadColors.TextColor.copy(alpha = 0.7f),
            modifier = Modifier.size(20.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = KingRoadColors.TextColor.copy(alpha = 0.7f)
            )
            
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = KingRoadColors.TextColor
            )
        }
    }
}

/**
 * Estado da UI para a tela de rotas intermodais
 */
data class IntermodalRoutesUiState(
    val isLoading: Boolean = false,
    val routes: List<RouteInfo> = emptyList(),
    val nearbyConnections: List<IntermodalConnection> = emptyList(),
    val error: String? = null
)

/**
 * ViewModel para a tela de rotas intermodais
 */
@HiltViewModel
class IntermodalRoutesViewModel @Inject constructor(
    private val connectionsManager: IntermodalConnectionsManager
) : ViewModel() {
    
    // Estado da UI observável
    private val _uiState = MutableStateFlow(IntermodalRoutesUiState())
    val uiState: StateFlow<IntermodalRoutesUiState> = _uiState.asStateFlow()
    
    // Preferências de rota do usuário
    val routePreferences: StateFlow<RoutePreferences> = connectionsManager.routePreferences
    
    init {
        // Observar mudanças nas preferências de rota para atualizar as rotas sugeridas
        viewModelScope.launch {
            connectionsManager.routePreferences
                .collect { preferences ->
                    // Quando as preferências mudam, atualizar rotas sugeridas
                    updateRoutes()
                }
        }
    }
    
    /**
     * Atualiza as rotas com base nas preferências atuais
     */
    private fun updateRoutes() {
        // Esta implementação seria substituída por uma que usa os dados reais
        // Por enquanto, usamos dados de exemplo
        _uiState.value = _uiState.value.copy(
            routes = getSampleRoutes()
        )
    }
    
    /**
     * Atualiza preferências de rota
     */
    suspend fun updateRoutePreferences(preferences: RoutePreferences) {
        connectionsManager.updateRoutePreferences(preferences)
    }
    
    /**
     * Obtém detalhes de uma conexão específica
     */
    suspend fun getConnectionDetails(connectionId: String): ConnectionDetails? {
        return connectionsManager.getConnectionDetails(connectionId)
    }
    
    /**
     * Gera dados de exemplo para testes
     */
    private fun getSampleRoutes(): List<RouteInfo> {
        // Numa implementação real, isso viria do repositório
        return listOf(
            RouteInfo(
                id = "route1",
                startPoint = GeoPoint(0.0, 0.0, "Lisboa"),
                endPoint = GeoPoint(0.0, 0.0, "Londres"),
                distance = 2457.0,
                duration = 27 * 60 + 45, // 27h 45min
                intermodalConnections = listOf(
                    IntermodalConnection(
                        id = "eurotunnel",
                        name = "Eurotúnel",
                        type = ConnectionType.TRAIN_TUNNEL,
                        startLocation = GeoPoint(0.0, 0.0, "Calais"),
                        endLocation = GeoPoint(0.0, 0.0, "Folkestone"),
                        distance = 50.0,
                        averageDuration = 35,
                        baseFee = 199.0,
                        currency = "EUR"
                    )
                ),
                totalCost = 245.0,
                currency = "EUR"
            ),
            RouteInfo(
                id = "route2",
                startPoint = GeoPoint(0.0, 0.0, "Estocolmo"),
                endPoint = GeoPoint(0.0, 0.0, "Helsinque"),
                distance = 484.0,
                duration = 17 * 60 + 30, // 17h 30min
                intermodalConnections = listOf(
                    IntermodalConnection(
                        id = "vikingline",
                        name = "Viking Line",
                        type = ConnectionType.FERRY,
                        startLocation = GeoPoint(0.0, 0.0, "Estocolmo"),
                        endLocation = GeoPoint(0.0, 0.0, "Helsinque"),
                        distance = 400.0,
                        averageDuration = 15 * 60 + 45, // 15h 45min
                        baseFee = 120.0,
                        currency = "EUR"
                    )
                ),
                totalCost = 120.0,
                currency = "EUR"
            ),
            RouteInfo(
                id = "route3",
                startPoint = GeoPoint(0.0, 0.0, "Rio de Janeiro"),
                endPoint = GeoPoint(0.0, 0.0, "Niterói"),
                distance = 22.0,
                duration = 35, // 35min
                intermodalConnections = listOf(
                    IntermodalConnection(
                        id = "rioniteroi",
                        name = "Travessia da Baía",
                        type = ConnectionType.PASSENGER_FERRY,
                        startLocation = GeoPoint(0.0, 0.0, "Rio de Janeiro"),
                        endLocation = GeoPoint(0.0, 0.0, "Niterói"),
                        distance = 12.0,
                        averageDuration = 20,
                        baseFee = 6.90,
                        currency = "BRL"
                    )
                ),
                totalCost = 6.90,
                currency = "BRL"
            )
        )
    }
}