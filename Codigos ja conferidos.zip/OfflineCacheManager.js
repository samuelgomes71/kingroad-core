/**
 * OfflineCacheManager.js
 * 
 * Gerencia o cache offline do sistema KingRoad com funcionalidades para
 * cache de mapas, sincronização local e banners de status conforme mencionado no relatório.
 */

import { NavigationService } from './NavigationService';
import { POIService } from './POIService';
import { TranslationsService } from './TranslationsService';

class OfflineCacheManager {
  constructor() {
    this.isInitialized = false;
    this.navigationService = NavigationService.getInstance();
    this.poiService = POIService.getInstance();
    this.translationsService = TranslationsService.getInstance();
    
    // Status de cache
    this.cacheStatus = {
      maps: {
        lastUpdate: null,
        size: 0,
        areas: []
      },
      pois: {
        lastUpdate: null,
        count: 0,
        categories: {}
      },
      translations: {
        lastUpdate: null,
        languages: []
      },
      routes: {
        lastUpdate: null,
        count: 0
      },
      alerts: {
        lastUpdate: null,
        count: 0
      },
      total: {
        size: 0,
        lastSync: null
      }
    };
    
    // Configurações
    this.config = {
      maxCacheSize: 2048, // tamanho máximo do cache em MB
      autoUpdate: true, // atualização automática de recursos
      downloadOnWifiOnly: true, // baixar atualizações apenas via Wi-Fi
      notifyLowStorage: true, // notificar quando o espaço estiver baixo
      periodicSyncInterval: 24 * 60 * 60 * 1000, // 24 horas em milissegundos
      retryAttempts: 3, // tentativas de sincronização em caso de falha
      precacheRadius: 100, // raio (em km) para pré-cache de áreas ao redor de rotas
      deleteUnusedAfterDays: 30, // dias para manter recursos não utilizados
      compressionLevel: 'high', // nível de compressão para dados
      syncQueue: [], // fila de sincronização de recursos
      priorityAreas: [], // áreas com prioridade para cache
      mapDetailLevel: 'high', // nível de detalhe para mapas offline
    };
    
    // Status da conexão
    this.connectionStatus = {
      online: false,
      type: null,
      lastChecked: null
    };
    
    // Lista de observadores
    this.observers = [];
    
    // Cache indices (para acesso rápido)
    this.mapTiles = new Map(); // mapa de tiles por coordenada
    this.cachedRoutes = new Map(); // rotas armazenadas por ID
    this.pendingDownloads = new Map(); // downloads pendentes
    this.abortControllers = new Map(); // controladores para cancelar downloads
    
    // Dados de uso para gerenciamento inteligente
    this.usageData = {
      frequentAreas: new Map(), // áreas frequentemente acessadas
      frequentRoutes: [], // rotas frequentes
      lastPositions: [], // últimas posições do usuário
    };
  }

  /**
   * Instância singleton do serviço
   */
  static instance = null;
  
  /**
   * Obtém a instância do serviço, criando-a se necessário
   */
  static getInstance() {
    if (!OfflineCacheManager.instance) {
      OfflineCacheManager.instance = new OfflineCacheManager();
    }
    return OfflineCacheManager.instance;
  }

  /**
   * Inicializa o gerenciador de cache offline
   */
  async initialize() {
    if (this.isInitialized) return true;
    
    try {
      // Verificar suporte à API de armazenamento
      await this.checkStorageSupport();
      
      // Carregar configurações salvas
      await this.loadSavedConfig();
      
      // Carregar status de cache existente
      await this.loadCacheStatus();
      
      // Verificar estado da conexão
      await this.checkConnectionStatus();
      
      // Configurar listeners de eventos
      this.setupEventListeners();
      
      // Iniciar sincronização periódica
      this.startPeriodicSync();
      
      // Verificar e limpar cache antigo
      this.cleanupStaleCache();
      
      this.isInitialized = true;
      this.notifyObservers('init', { success: true });
      
      return true;
    } catch (error) {
      console.error('Erro ao inicializar OfflineCacheManager:', error);
      this.notifyObservers('error', { type: 'init', error });
      return false;
    }
  }
  
  /**
   * Verifica o suporte a APIs de armazenamento necessárias
   */
  async checkStorageSupport() {
    // Verificar suporte a IndexedDB
    if (!window.indexedDB) {
      throw new Error('IndexedDB não suportado neste navegador');
    }
    
    // Verificar suporte a Cache API
    if (!('caches' in window)) {
      throw new Error('Cache API não suportada neste navegador');
    }
    
    // Verificar quota de armazenamento disponível
    try {
      const { quota, usage } = await navigator.storage.estimate();
      this.storageQuota = {
        total: quota || 0,
        used: usage || 0,
        available: (quota || 0) - (usage || 0)
      };
      
      // Verificar se há espaço suficiente (ao menos 100MB)
      if (this.storageQuota.available < 100 * 1024 * 1024) {
        console.warn('Espaço de armazenamento limitado:', this.storageQuota);
      }
    } catch (error) {
      console.warn('Não foi possível estimar o armazenamento disponível:', error);
    }
  }
  
  /**
   * Carrega configurações salvas
   */
  async loadSavedConfig() {
    try {
      const savedConfig = localStorage.getItem('kingroad_offline_config');
      if (savedConfig) {
        const parsedConfig = JSON.parse(savedConfig);
        this.config = { ...this.config, ...parsedConfig };
      }
    } catch (error) {
      console.error('Erro ao carregar configurações de cache:', error);
    }
  }
  
  /**
   * Salva as configurações atuais
   */
  async saveConfig() {
    try {
      localStorage.setItem('kingroad_offline_config', JSON.stringify(this.config));
    } catch (error) {
      console.error('Erro ao salvar configurações de cache:', error);
    }
  }
  
  /**
   * Carrega o status do cache atual
   */
  async loadCacheStatus() {
    try {
      // Carregar status do cache do IndexedDB
      const db = await this.openDatabase();
      const transaction = db.transaction(['cacheStatus'], 'readonly');
      const store = transaction.objectStore('cacheStatus');
      const request = store.get('status');
      
      return new Promise((resolve, reject) => {
        request.onsuccess = (event) => {
          if (event.target.result) {
            this.cacheStatus = event.target.result;
          }
          resolve();
        };
        
        request.onerror = (event) => {
          console.error('Erro ao carregar status do cache:', event.target.error);
          reject(event.target.error);
        };
      });
    } catch (error) {
      console.error('Erro ao acessar o banco de dados de cache:', error);
      // Criar o banco se não existir
      await this.createDatabase();
    }
  }
  
  /**
   * Abre a conexão com o banco de dados
   */
  async openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('KingRoadOfflineCache', 1);
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // Criar stores se não existirem
        if (!db.objectStoreNames.contains('cacheStatus')) {
          db.createObjectStore('cacheStatus', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('mapTiles')) {
          db.createObjectStore('mapTiles', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('pois')) {
          db.createObjectStore('pois', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('routes')) {
          db.createObjectStore('routes', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('translations')) {
          db.createObjectStore('translations', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('alerts')) {
          db.createObjectStore('alerts', { keyPath: 'id' });
        }
      };
      
      request.onsuccess = (event) => {
        resolve(event.target.result);
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Cria o banco de dados se não existir
   */
  async createDatabase() {
    const db = await this.openDatabase();
    // Salvar status inicial no banco
    const transaction = db.transaction(['cacheStatus'], 'readwrite');
    const store = transaction.objectStore('cacheStatus');
    store.put({ id: 'status', ...this.cacheStatus });
    
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => {
        resolve(true);
      };
      
      transaction.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Verifica o status da conexão com a internet
   */
  async checkConnectionStatus() {
    const online = navigator.onLine;
    
    // Determinar o tipo de conexão (se disponível)
    let connectionType = null;
    if (navigator.connection) {
      connectionType = navigator.connection.effectiveType || navigator.connection.type;
    }
    
    // Testar conectividade real com o servidor
    let serverReachable = false;
    if (online) {
      try {
        const response = await fetch('https://api.kingroad.app/ping', {
          method: 'HEAD',
          cache: 'no-store',
          mode: 'no-cors',
          timeout: 3000
        });
        serverReachable = true;
      } catch (error) {
        serverReachable = false;
      }
    }
    
    const newStatus = {
      online: online && serverReachable,
      type: connectionType,
      lastChecked: new Date()
    };
    
    // Se o status mudou, atualizar e notificar observadores
    if (this.connectionStatus.online !== newStatus.online) {
      const oldStatus = { ...this.connectionStatus };
      this.connectionStatus = newStatus;
      
      this.notifyObservers('connectionChange', {
        from: oldStatus,
        to: newStatus
      });
      
      // Se voltou a ficar online, tentar sincronizar
      if (newStatus.online && !oldStatus.online) {
        this.syncCacheWhenOnline();
      }
    } else {
      this.connectionStatus = newStatus;
    }
    
    return this.connectionStatus;
  }
  
  /**
   * Configura listeners para eventos relevantes
   */
  setupEventListeners() {
    // Listener para mudanças na conexão
    window.addEventListener('online', () => this.handleConnectionChange(true));
    window.addEventListener('offline', () => this.handleConnectionChange(false));
    
    // Listener para mudanças de localização significativas
    document.addEventListener('locationChange', (event) => {
      this.handleLocationChange(event.detail);
    });
    
    // Listener para mudanças de região/país
    document.addEventListener('regionChange', (event) => {
      this.handleRegionChange(event.detail);
    });
    
    // Listener para início de navegação (para pré-cache de rota)
    document.addEventListener('navigationStart', (event) => {
      this.handleNavigationStart(event.detail);
    });
    
    // Listener para eventos de armazenamento (caso outro contexto modifique o cache)
    window.addEventListener('storage', (event) => {
      if (event.key && event.key.startsWith('kingroad_')) {
        this.handleStorageChange(event);
      }
    });
  }
  
  /**
   * Manipula mudanças no estado da conexão
   */
  async handleConnectionChange(isOnline) {
    await this.checkConnectionStatus();
    
    if (isOnline) {
      // Se ficou online, iniciar sincronização
      this.syncCacheWhenOnline();
    } else {
      // Se ficou offline, mostrar banner de modo offline
      this.showOfflineBanner();
    }
  }
  
  /**
   * Manipula mudanças significativas de localização
   */
  handleLocationChange(location) {
    // Registrar posição
    this.usageData.lastPositions.push({
      position: location,
      timestamp: Date.now()
    });
    
    // Manter apenas as 20 últimas posições
    if (this.usageData.lastPositions.length > 20) {
      this.usageData.lastPositions.shift();
    }
    
    // Atualizar áreas frequentes
    this.updateFrequentAreas(location);
    
    // Verificar se é necessário pré-carregar a região atual
    this.precacheCurrentArea(location);
  }
  
  /**
   * Manipula mudanças de região/país
   */
  handleRegionChange({ previousRegion, newRegion }) {
    if (newRegion && this.connectionStatus.online) {
      // Pré-carregar dados para a nova região
      this.precacheRegion(newRegion);
    }
  }
  
  /**
   * Manipula o início de uma navegação
   */
  handleNavigationStart({ route }) {
    if (route) {
      // Pré-carregar dados para a rota
      this.precacheRoute(route);
      
      // Registrar rota como frequente
      this.updateFrequentRoutes(route);
    }
  }
  
  /**
   * Manipula mudanças de armazenamento
   */
  handleStorageChange(event) {
    if (event.key === 'kingroad_offline_config') {
      try {
        const newConfig = JSON.parse(event.newValue);
        this.config = { ...this.config, ...newConfig };
      } catch (error) {
        console.error('Erro ao processar alteração de configuração:', error);
      }
    }
  }
  
  /**
   * Inicia o processo de sincronização periódica
   */
  startPeriodicSync() {
    // Limpar qualquer intervalo existente
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
    
    // Configurar novo intervalo com base nas configurações
    this.syncInterval = setInterval(() => {
      this.performPeriodicSync();
    }, this.config.periodicSyncInterval);
    
    // Primeira sincronização
    if (this.connectionStatus.online) {
      setTimeout(() => this.performPeriodicSync(), 30000); // 30 segundos após inicialização
    }
  }
  
  /**
   * Realiza a sincronização periódica
   */
  async performPeriodicSync() {
    // Verificar se está online
    await this.checkConnectionStatus();
    if (!this.connectionStatus.online) return;
    
    // Verificar se pode usar a conexão atual
    if (this.config.downloadOnWifiOnly && this.connectionStatus.type !== 'wifi') {
      console.log('Sincronização adiada: aguardando conexão Wi-Fi');
      return;
    }
    
    // Verificar espaço disponível
    await this.updateStorageStats();
    if (this.storageQuota.available < 50 * 1024 * 1024) { // menos de 50MB
      if (this.config.notifyLowStorage) {
        this.notifyObservers('storage', {
          type: 'low',
          available: this.storageQuota.available
        });
      }
      // Tentar liberar espaço
      await this.cleanupStaleCache();
    }
    
    // Sincronizar em ordem de prioridade
    await this.syncTranslations();
    await this.syncPOIs();
    await this.syncAlerts();
    
    // Sincronizar mapas frequentes
    const frequentAreas = Array.from(this.usageData.frequentAreas.entries())
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5); // Top 5 áreas mais frequentes
    
    for (const [areaKey, areaData] of frequentAreas) {
      await this.syncMapArea(areaData.area);
    }
    
    // Atualizar o status global
    this.cacheStatus.total.lastSync = new Date();
    await this.saveCacheStatus();
    
    this.notifyObservers('sync', {
      type: 'periodic',
      timestamp: this.cacheStatus.total.lastSync
    });
  }
  
  /**
   * Sincroniza o cache quando volta a ter conexão
   */
  async syncCacheWhenOnline() {
    // Processar fila de sincronização pendente
    if (this.config.syncQueue.length > 0) {
      for (const syncTask of this.config.syncQueue) {
        try {
          await this.processSyncTask(syncTask);
        } catch (error) {
          console.error('Erro ao processar tarefa de sincronização:', error);
        }
      }
      
      // Limpar fila após processamento
      this.config.syncQueue = [];
      await this.saveConfig();
    }
    
    // Notificar que está online novamente
    this.notifyObservers('online', {
      timestamp: new Date()
    });
    
    // Esconder banner de offline, se estiver visível
    this.hideOfflineBanner();
  }
  
  /**
   * Processa uma tarefa de sincronização específica
   */
  async processSyncTask(task) {
    switch (task.type) {
      case 'mapArea':
        return this.syncMapArea(task.area);
      case 'poi':
        return this.syncPOI(task.poiId);
      case 'route':
        return this.syncRoute(task.route);
      case 'translation':
        return this.syncTranslation(task.language);
      default:
        console.warn('Tipo de tarefa de sincronização desconhecido:', task.type);
    }
  }
  
  /**
   * Atualiza estatísticas de armazenamento
   */
  async updateStorageStats() {
    try {
      const { quota, usage } = await navigator.storage.estimate();
      this.storageQuota = {
        total: quota || 0,
        used: usage || 0,
        available: (quota || 0) - (usage || 0)
      };
      
      return this.storageQuota;
    } catch (error) {
      console.error('Erro ao atualizar estatísticas de armazenamento:', error);
      return null;
    }
  }
  
  /**
   * Limpa cache antigo ou não utilizado
   */
  async cleanupStaleCache() {
    try {
      const now = Date.now();
      const expiryThreshold = now - (this.config.deleteUnusedAfterDays * 24 * 60 * 60 * 1000);
      
      // Remover tiles de mapa antigos/não usados
      await this.cleanupMapTiles(expiryThreshold);
      
      // Remover POIs antigos/não usados
      await this.cleanupPOIs(expiryThreshold);
      
      // Remover rotas antigas/não usadas
      await this.cleanupRoutes(expiryThreshold);
      
      // Atualizar status de cache
      await this.calculateCacheSize();
      await this.saveCacheStatus();
      
      return true;
    } catch (error) {
      console.error('Erro ao limpar cache antigo:', error);
      return false;
    }
  }
  
  /**
   * Limpa tiles de mapa antigos
   */
  async cleanupMapTiles(expiryThreshold) {
    const db = await this.openDatabase();
    const transaction = db.transaction(['mapTiles'], 'readwrite');
    const store = transaction.objectStore('mapTiles');
    
    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      let deletedCount = 0;
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          const tile = cursor.value;
          
          // Verificar se o tile é antigo ou raramente usado
          if (tile.lastAccessed < expiryThreshold && !tile.isPriority) {
            cursor.delete();
            deletedCount++;
          }
          
          cursor.continue();
        } else {
          resolve(deletedCount);
        }
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Limpa POIs antigos
   */
  async cleanupPOIs(expiryThreshold) {
    const db = await this.openDatabase();
    const transaction = db.transaction(['pois'], 'readwrite');
    const store = transaction.objectStore('pois');
    
    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      let deletedCount = 0;
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          const poi = cursor.value;
          
          // Verificar se o POI é antigo ou raramente usado
          if (poi.lastAccessed < expiryThreshold && !poi.isFavorite) {
            cursor.delete();
            deletedCount++;
          }
          
          cursor.continue();
        } else {
          resolve(deletedCount);
        }
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Limpa rotas antigas
   */
  async cleanupRoutes(expiryThreshold) {
    const db = await this.openDatabase();
    const transaction = db.transaction(['routes'], 'readwrite');
    const store = transaction.objectStore('routes');
    
    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      let deletedCount = 0;
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          const route = cursor.value;
          
          // Verificar se a rota é antiga ou raramente usada
          if (route.lastAccessed < expiryThreshold && !route.isFrequent) {
            cursor.delete();
            deletedCount++;
          }
          
          cursor.continue();
        } else {
          resolve(deletedCount);
        }
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Calcula o tamanho total do cache
   */
  async calculateCacheSize() {
    try {
      const db = await this.openDatabase();
      const stores = ['mapTiles', 'pois', 'routes', 'translations', 'alerts'];
      let totalSize = 0;
      
      for (const storeName of stores) {
        const size = await this.calculateStoreSize(db, storeName);
        totalSize += size;
        
        // Atualizar tamanho específico no status
        if (storeName === 'mapTiles') {
          this.cacheStatus.maps.size = size;
        }
      }
      
      this.cacheStatus.total.size = totalSize;
      return totalSize;
    } catch (error) {
      console.error('Erro ao calcular tamanho do cache:', error);
      return 0;
    }
  }
  
  /**
   * Calcula o tamanho de um store específico
   */
  async calculateStoreSize(db, storeName) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.openCursor();
      let size = 0;
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          // Estimar o tamanho usando JSON
          const serialized = JSON.stringify(cursor.value);
          size += serialized.length;
          cursor.continue();
        } else {
          // Converter para KB
          resolve(Math.round(size / 1024));
        }
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Salva o status atual do cache
   */
  async saveCacheStatus() {
    try {
      const db = await this.openDatabase();
      const transaction = db.transaction(['cacheStatus'], 'readwrite');
      const store = transaction.objectStore('cacheStatus');
      
      return new Promise((resolve, reject) => {
        const request = store.put({ id: 'status', ...this.cacheStatus });
        
        request.onsuccess = () => {
          resolve(true);
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
    } catch (error) {
      console.error('Erro ao salvar status do cache:', error);
      return false;
    }
  }
  
  /**
   * Adiciona um observador para eventos do cache
   */
  addObserver(callback) {
    if (typeof callback === 'function' && !this.observers.includes(callback)) {
      this.observers.push(callback);
      return true;
    }
    return false;
  }
  
  /**
   * Remove um observador
   */
  removeObserver(callback) {
    const index = this.observers.indexOf(callback);
    if (index !== -1) {
      this.observers.splice(index, 1);
      return true;
    }
    return false;
  }
  
  /**
   * Notifica observadores sobre eventos
   */
  notifyObservers(event, data) {
    this.observers.forEach(callback => {
      try {
        callback(event, data);
      } catch (error) {
        console.error('Erro em observador de cache:', error);
      }
    });
    
    // Disparar evento para o documento
    const customEvent = new CustomEvent('cacheEvent', {
      detail: { event, data }
    });
    document.dispatchEvent(customEvent);
  }
  
  /**
   * Mostra um banner indicando que o aplicativo está no modo offline
   */
  showOfflineBanner() {
    this.notifyObservers('ui', {
      type: 'banner',
      action: 'show',
      bannerType: 'offline',
      message: 'Você está no modo offline. Algumas funcionalidades podem estar limitadas.'
    });
  }
  
  /**
   * Esconde o banner de modo offline
   */
  hideOfflineBanner() {
    this.notifyObservers('ui', {
      type: 'banner',
      action: 'hide',
      bannerType: 'offline'
    });
  }
  
  /**
   * Atualiza o registro de áreas frequentes
   */
  updateFrequentAreas(location) {
    // Calcular chave de área com precisão de ~10km
    const precision = 2; // 2 casas decimais ≈ 1.1km na linha do equador
    const areaKey = `${location.latitude.toFixed(precision)},${location.longitude.toFixed(precision)}`;
    
    // Atualizar ou criar entrada
    if (this.usageData.frequentAreas.has(areaKey)) {
      const areaData = this.usageData.frequentAreas.get(areaKey);
      areaData.count++;
      areaData.lastVisit = Date.now();
      this.usageData.frequentAreas.set(areaKey, areaData);
    } else {
      this.usageData.frequentAreas.set(areaKey, {
        area: {
          latitude: parseFloat(location.latitude.toFixed(precision)),
          longitude: parseFloat(location.longitude.toFixed(precision)),
          radius: 10 // 10km
        },
        count: 1,
        lastVisit: Date.now()
      });
    }
    
    // Limitar a 20 áreas frequentes
    if (this.usageData.frequentAreas.size > 20) {
      // Remover a área menos frequente
      let leastFrequentKey = null;
      let leastFrequentCount = Infinity;
      
      for (const [key, data] of this.usageData.frequentAreas.entries()) {
        if (data.count < leastFrequentCount) {
          leastFrequentCount = data.count;
          leastFrequentKey = key;
        }
      }
      
      if (leastFrequentKey) {
        this.usageData.frequentAreas.delete(leastFrequentKey);
      }
    }
    
    // Salvar estatísticas de uso
    this.saveUsageData();
  }
  
  /**
   * Atualiza o registro de rotas frequentes
   */
  updateFrequentRoutes(route) {
    // Criar chave única para a rota
    const routeKey = `${route.origin.latitude.toFixed(2)},${route.origin.longitude.toFixed(2)}_${route.destination.latitude.toFixed(2)},${route.destination.longitude.toFixed(2)}`;
    
    // Verificar se a rota já existe no registro
    const existingIndex = this.usageData.frequentRoutes.findIndex(r => r.key === routeKey);
    
    if (existingIndex >= 0) {
      // Atualizar rota existente
      this.usageData.frequentRoutes[existingIndex].count++;
      this.usageData.frequentRoutes[existingIndex].lastUsed = Date.now();
    } else {
      // Adicionar nova rota
      this.usageData.frequentRoutes.push({
        key: routeKey,
        origin: {
          latitude: route.origin.latitude,
          longitude: route.origin.longitude,
          name: route.origin.name || 'Origem'
        },
        destination: {
          latitude: route.destination.latitude,
          longitude: route.destination.longitude,
          name: route.destination.name || 'Destino'
        },
        count: 1,
        lastUsed: Date.now()
      });
    }
    
    // Ordenar por contagem (mais frequente primeiro)
    this.usageData.frequentRoutes.sort((a, b) => b.count - a.count);
    
    // Limitar a 10 rotas frequentes
    if (this.usageData.frequentRoutes.length > 10) {
      this.usageData.frequentRoutes = this.usageData.frequentRoutes.slice(0, 10);
    }
    
    // Salvar dados de uso
    this.saveUsageData();
  }
  
  /**
   * Salva dados de uso para análise e otimização de cache
   */
  async saveUsageData() {
    try {
      // Converter Map para formato serializável
      const serializedFrequentAreas = Array.from(this.usageData.frequentAreas.entries())
        .map(([key, value]) => ({ key, ...value }));
      
      // Salvar no localStorage para persistência básica
      localStorage.setItem('kingroad_cache_usage', JSON.stringify({
        frequentAreas: serializedFrequentAreas,
        frequentRoutes: this.usageData.frequentRoutes,
        lastUpdate: Date.now()
      }));
      
      return true;
    } catch (error) {
      console.error('Erro ao salvar dados de uso de cache:', error);
      return false;
    }
  }
  
  /**
   * Carrega dados de uso salvos anteriormente
   */
  async loadUsageData() {
    try {
      const savedData = localStorage.getItem('kingroad_cache_usage');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        
        // Restaurar áreas frequentes como Map
        this.usageData.frequentAreas = new Map();
        if (parsed.frequentAreas) {
          parsed.frequentAreas.forEach(item => {
            this.usageData.frequentAreas.set(item.key, {
              area: item.area,
              count: item.count,
              lastVisit: item.lastVisit
            });
          });
        }
        
        // Restaurar rotas frequentes
        if (parsed.frequentRoutes) {
          this.usageData.frequentRoutes = parsed.frequentRoutes;
        }
        
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erro ao carregar dados de uso de cache:', error);
      return false;
    }
  }
  
  /**
   * Pré-carrega dados para a área atual
   */
  async precacheCurrentArea(location) {
    // Verificar se está online
    if (!this.connectionStatus.online) return false;
    
    // Verificar se deve usar a conexão atual
    if (this.config.downloadOnWifiOnly && this.connectionStatus.type !== 'wifi') {
      return false;
    }
    
    // Definir área para pré-cache
    const area = {
      latitude: location.latitude,
      longitude: location.longitude,
      radius: 10 // 10km ao redor da posição atual
    };
    
    // Iniciar downloads em paralelo
    const tasks = [
      this.syncMapArea(area),
      this.syncPOIsInArea(area),
      this.syncAlertsInArea(area)
    ];
    
    try {
      await Promise.all(tasks);
      return true;
    } catch (error) {
      console.error('Erro ao pré-carregar área atual:', error);
      return false;
    }
  }
  
  /**
   * Pré-carrega dados para uma região/país
   */
  async precacheRegion(regionCode) {
    // Verificar se está online
    if (!this.connectionStatus.online) return false;
    
    // Verificar se deve usar a conexão atual
    if (this.config.downloadOnWifiOnly && this.connectionStatus.type !== 'wifi') {
      return false;
    }
    
    try {
      // Sincronizar traduções para a região
      const regionLanguage = this.getRegionLanguage(regionCode);
      if (regionLanguage) {
        await this.syncTranslation(regionLanguage);
      }
      
      // Pré-carregar dados específicos da região
      // (a implementação depende da API do sistema)
      
      return true;
    } catch (error) {
      console.error(`Erro ao pré-carregar região ${regionCode}:`, error);
      return false;
    }
  }
  
  /**
   * Obtém o idioma principal de uma região
   */
  getRegionLanguage(regionCode) {
    const regionLanguageMap = {
      'BR': 'pt-BR',
      'US': 'en-US',
      'AR': 'es-AR',
      'MX': 'es-MX',
      'ES': 'es-ES',
      'PT': 'pt-PT',
      'FR': 'fr-FR',
      'DE': 'de-DE',
      'IT': 'it-IT',
      'GB': 'en-GB'
      // Adicionar mais conforme necessário
    };
    
    return regionLanguageMap[regionCode] || null;
  }
  
  /**
   * Pré-carrega dados para uma rota específica
   */
  async precacheRoute(route) {
    // Verificar se está online
    if (!this.connectionStatus.online) return false;
    
    // Verificar se deve usar a conexão atual
    if (this.config.downloadOnWifiOnly && this.connectionStatus.type !== 'wifi') {
      // Adicionar à fila para sincronização futura
      this.config.syncQueue.push({
        type: 'route',
        route: {
          id: route.id,
          origin: route.origin,
          destination: route.destination
        },
        timestamp: Date.now()
      });
      await this.saveConfig();
      
      return false;
    }
    
    try {
      // Sincronizar a rota em si
      await this.syncRoute(route);
      
      // Sincronizar mapas ao longo da rota
      if (route.waypoints && route.waypoints.length > 0) {
        // Processar waypoints em lotes para não sobrecarregar
        const waypointBatches = this.chunkArray(route.waypoints, 5);
        
        for (const batch of waypointBatches) {
          const syncPromises = batch.map(waypoint => {
            return this.syncMapArea({
              latitude: waypoint.latitude,
              longitude: waypoint.longitude,
              radius: 5 // 5km ao redor de cada ponto da rota
            });
          });
          
          await Promise.all(syncPromises);
        }
      }
      
      // Sincronizar POIs ao longo da rota (paradas, postos, etc.)
      await this.syncPOIsAlongRoute(route);
      
      // Sincronizar alertas ao longo da rota
      await this.syncAlertsAlongRoute(route);
      
      return true;
    } catch (error) {
      console.error('Erro ao pré-carregar rota:', error);
      return false;
    }
  }
  
  /**
   * Divide um array em lotes menores
   */
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
  
  /**
   * Sincroniza tiles de mapa para uma área específica
   */
  async syncMapArea(area) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Calcular os tiles necessários para a área
      const tiles = await this.calculateMapTilesForArea(area);
      
      // Armazenar cada tile no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['mapTiles'], 'readwrite');
      const store = transaction.objectStore('mapTiles');
      
      // Baixar tiles em paralelo, mas em lotes para não sobrecarregar
      const tileBatches = this.chunkArray(tiles, 10);
      
      for (const batch of tileBatches) {
        const downloadPromises = batch.map(async tile => {
          try {
            // Verificar se já existe no cache
            const existingTile = await this.getTileFromStore(store, tile.id);
            if (existingTile && existingTile.version === tile.version) {
              // Tile já está atualizado
              return null;
            }
            
            // Baixar o tile
            const tileData = await this.downloadMapTile(tile);
            
            // Armazenar no cache
            return new Promise((resolve, reject) => {
              const request = store.put({
                ...tile,
                data: tileData,
                lastAccessed: Date.now(),
                isPriority: area.isPriority || false
              });
              
              request.onsuccess = () => resolve(tile);
              request.onerror = (event) => reject(event.target.error);
            });
          } catch (error) {
            console.error(`Erro ao baixar tile ${tile.id}:`, error);
            return null;
          }
        });
        
        await Promise.all(downloadPromises);
      }
      
      // Atualizar status do cache
      this.cacheStatus.maps.lastUpdate = new Date();
      if (!this.cacheStatus.maps.areas.includes(area.name || `${area.latitude},${area.longitude}`)) {
        this.cacheStatus.maps.areas.push(area.name || `${area.latitude},${area.longitude}`);
      }
      
      await this.saveCacheStatus();
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar área do mapa:', error);
      return false;
    }
  }
  
  /**
   * Busca um tile do armazenamento
   */
  async getTileFromStore(store, tileId) {
    return new Promise((resolve, reject) => {
      const request = store.get(tileId);
      
      request.onsuccess = (event) => {
        resolve(event.target.result);
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Calcula quais tiles são necessários para cobrir uma área
   */
  async calculateMapTilesForArea(area) {
    // Esta é uma função simplificada
    // Em um sistema real, a lógica dependeria do esquema de tiling e zoom levels
    
    const { latitude, longitude, radius } = area;
    const zoomLevels = this.getZoomLevelsForDetailLevel(this.config.mapDetailLevel);
    
    // Aproximação grosseira: 1 grau = ~111km no equador
    // Ajustar para diferentes latitudes
    const latFactor = Math.cos(latitude * Math.PI / 180);
    const kmPerDegLat = 111.32; // km por grau de latitude
    const kmPerDegLon = 111.32 * latFactor; // km por grau de longitude
    
    // Calcular delta para cobrir o raio em todas as direções
    const latDelta = radius / kmPerDegLat;
    const lonDelta = radius / kmPerDegLon;
    
    const tiles = [];
    
    for (const zoom of zoomLevels) {
      // Quanto maior o zoom, mais tiles serão necessários
      const factor = Math.pow(2, zoom - 10); // Ajuste para zoom
      
      // Calcular limites de latitude/longitude
      const minLat = latitude - latDelta;
      const maxLat = latitude + latDelta;
      const minLon = longitude - lonDelta;
      const maxLon = longitude + lonDelta;
      
      // Converter para coordenadas de tile
      // Fórmula comum para Mercator (simplificada)
      const minTileX = Math.floor((minLon + 180) / 360 * Math.pow(2, zoom));
      const maxTileX = Math.floor((maxLon + 180) / 360 * Math.pow(2, zoom));
      const minTileY = Math.floor((1 - Math.log(Math.tan(minLat * Math.PI / 180) + 1 / Math.cos(minLat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom));
      const maxTileY = Math.floor((1 - Math.log(Math.tan(maxLat * Math.PI / 180) + 1 / Math.cos(maxLat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom));
      
      // Gerar lista de tiles
      for (let x = minTileX; x <= maxTileX; x++) {
        for (let y = minTileY; y <= maxTileY; y++) {
          const tileId = `${zoom}/${x}/${y}`;
          const version = 1; // Versão do tile (para controle de atualização)
          
          tiles.push({
            id: tileId,
            zoom,
            x,
            y,
            version,
            url: `https://api.kingroad.app/maps/tiles/${zoom}/${x}/${y}.png`
          });
        }
      }
    }
    
    return tiles;
  }
  
  /**
   * Determina quais níveis de zoom usar com base no nível de detalhe
   */
  getZoomLevelsForDetailLevel(detailLevel) {
    switch (detailLevel) {
      case 'low':
        return [10, 11, 12];
      case 'medium':
        return [10, 11, 12, 13, 14];
      case 'high':
        return [10, 11, 12, 13, 14, 15, 16];
      case 'ultra':
        return [10, 11, 12, 13, 14, 15, 16, 17, 18];
      default:
        return [10, 11, 12, 13, 14]; // medium por padrão
    }
  }
  
  /**
   * Baixa um tile de mapa do servidor
   */
  async downloadMapTile(tile) {
    try {
      // Criar um controlador para poder cancelar o download
      const controller = new AbortController();
      this.abortControllers.set(tile.id, controller);
      
      const response = await fetch(tile.url, {
        signal: controller.signal,
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao baixar tile: ${response.status} ${response.statusText}`);
      }
      
      // Obter os dados como blob
      const blob = await response.blob();
      
      // Removar o controlador após download concluído
      this.abortControllers.delete(tile.id);
      
      return blob;
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log(`Download de tile ${tile.id} cancelado`);
      } else {
        console.error(`Erro ao baixar tile ${tile.id}:`, error);
      }
      
      // Remover o controlador em caso de erro
      this.abortControllers.delete(tile.id);
      throw error;
    }
  }
  
  /**
   * Cancela todos os downloads ativos
   */
  cancelAllDownloads() {
    for (const controller of this.abortControllers.values()) {
      controller.abort();
    }
    this.abortControllers.clear();
    
    this.notifyObservers('download', {
      type: 'cancel',
      message: 'Todos os downloads cancelados'
    });
  }
  
  /**
   * Sincroniza traduções para o idioma atual ou específico
   */
  async syncTranslations(language = null) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Se não for especificado, usar o idioma atual
      const targetLanguage = language || this.translationsService.getCurrentLanguage();
      if (!targetLanguage) return false;
      
      // Baixar arquivo de traduções
      const response = await fetch(`https://api.kingroad.app/translations/${targetLanguage}.json`, {
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao baixar traduções: ${response.status} ${response.statusText}`);
      }
      
      const translations = await response.json();
      
      // Armazenar no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['translations'], 'readwrite');
      const store = transaction.objectStore('translations');
      
      return new Promise((resolve, reject) => {
        const request = store.put({
          id: targetLanguage,
          data: translations,
          lastAccessed: Date.now(),
          version: translations.version || 1
        });
        
        request.onsuccess = () => {
          // Atualizar status do cache
          this.cacheStatus.translations.lastUpdate = new Date();
          
          if (!this.cacheStatus.translations.languages.includes(targetLanguage)) {
            this.cacheStatus.translations.languages.push(targetLanguage);
          }
          
          this.saveCacheStatus().then(() => resolve(true));
        };
        
        request.onerror = (event) => reject(event.target.error);
      });
    } catch (error) {
      console.error('Erro ao sincronizar traduções:', error);
      return false;
    }
  }
  
  /**
   * Sincroniza um idioma específico
   */
  async syncTranslation(language) {
    return this.syncTranslations(language);
  }
  
  /**
   * Sincroniza POIs para uma área específica
   */
  async syncPOIsInArea(area) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Buscar POIs na área
      const response = await fetch(`https://api.kingroad.app/pois?lat=${area.latitude}&lon=${area.longitude}&radius=${area.radius}`, {
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao buscar POIs: ${response.status} ${response.statusText}`);
      }
      
      const pois = await response.json();
      
      // Armazenar no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['pois'], 'readwrite');
      const store = transaction.objectStore('pois');
      
      const savePromises = pois.map(poi => {
        return new Promise((resolve, reject) => {
          const request = store.put({
            id: poi.id,
            data: poi,
            lastAccessed: Date.now(),
            area: `${area.latitude.toFixed(2)},${area.longitude.toFixed(2)}`,
            category: poi.category
          });
          
          request.onsuccess = () => resolve(poi);
          request.onerror = (event) => reject(event.target.error);
        });
      });
      
      await Promise.all(savePromises);
      
      // Atualizar status do cache
      this.cacheStatus.pois.lastUpdate = new Date();
      this.cacheStatus.pois.count = await this.countCachedPOIs();
      
      // Atualizar contagem de categorias
      const categories = {};
      for (const poi of pois) {
        categories[poi.category] = (categories[poi.category] || 0) + 1;
      }
      
      // Mesclar com categorias existentes
      this.cacheStatus.pois.categories = {
        ...this.cacheStatus.pois.categories,
        ...categories
      };
      
      await this.saveCacheStatus();
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar POIs:', error);
      return false;
    }
  }
  
  /**
   * Conta o número total de POIs em cache
   */
  async countCachedPOIs() {
    const db = await this.openDatabase();
    const transaction = db.transaction(['pois'], 'readonly');
    const store = transaction.objectStore('pois');
    
    return new Promise((resolve, reject) => {
      const countRequest = store.count();
      
      countRequest.onsuccess = () => {
        resolve(countRequest.result);
      };
      
      countRequest.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Sincroniza todos os POIs
   */
  async syncPOIs() {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Sincronizar POIs das áreas frequentes
      const frequentAreas = Array.from(this.usageData.frequentAreas.values())
        .map(data => data.area);
      
      const syncPromises = frequentAreas.map(area => this.syncPOIsInArea(area));
      await Promise.all(syncPromises);
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar todos os POIs:', error);
      return false;
    }
  }
  
  /**
   * Sincroniza POIs ao longo de uma rota
   */
  async syncPOIsAlongRoute(route) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Se não houver waypoints, usar apenas origem e destino
      const points = route.waypoints && route.waypoints.length > 0 ?
        route.waypoints :
        [route.origin, route.destination];
      
      // Processar em lotes para não sobrecarregar
      const pointBatches = this.chunkArray(points, 3);
      
      for (const batch of pointBatches) {
        const syncPromises = batch.map(point => {
          return this.syncPOIsInArea({
            latitude: point.latitude,
            longitude: point.longitude,
            radius: 5 // 5km ao redor de cada ponto
          });
        });
        
        await Promise.all(syncPromises);
      }
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar POIs ao longo da rota:', error);
      return false;
    }
  }
  
  /**
   * Sincroniza um POI específico por ID
   */
  async syncPOI(poiId) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Buscar POI pelo ID
      const response = await fetch(`https://api.kingroad.app/pois/${poiId}`, {
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao buscar POI: ${response.status} ${response.statusText}`);
      }
      
      const poi = await response.json();
      
      // Armazenar no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['pois'], 'readwrite');
      const store = transaction.objectStore('pois');
      
      return new Promise((resolve, reject) => {
        const request = store.put({
          id: poi.id,
          data: poi,
          lastAccessed: Date.now(),
          category: poi.category
        });
        
        request.onsuccess = () => resolve(true);
        request.onerror = (event) => reject(event.target.error);
      });
    } catch (error) {
      console.error(`Erro ao sincronizar POI ${poiId}:`, error);
      return false;
    }
  }
  
  /**
   * Sincroniza alertas para uma área específica
   */
  async syncAlertsInArea(area) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Buscar alertas na área
      const response = await fetch(`https://api.kingroad.app/alerts?lat=${area.latitude}&lon=${area.longitude}&radius=${area.radius}`, {
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ao buscar alertas: ${response.status} ${response.statusText}`);
      }
      
      const alerts = await response.json();
      
      // Armazenar no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['alerts'], 'readwrite');
      const store = transaction.objectStore('alerts');
      
      const savePromises = alerts.map(alert => {
        return new Promise((resolve, reject) => {
          const request = store.put({
            id: alert.id,
            data: alert,
            lastAccessed: Date.now(),
            expiration: alert.expiration || null
          });
          
          request.onsuccess = () => resolve(alert);
          request.onerror = (event) => reject(event.target.error);
        });
      });
      
      await Promise.all(savePromises);
      
      // Atualizar status do cache
      this.cacheStatus.alerts.lastUpdate = new Date();
      this.cacheStatus.alerts.count = await this.countCachedAlerts();
      
      await this.saveCacheStatus();
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar alertas:', error);
      return false;
    }
  }
  
  /**
   * Conta o número total de alertas em cache
   */
  async countCachedAlerts() {
    const db = await this.openDatabase();
    const transaction = db.transaction(['alerts'], 'readonly');
    const store = transaction.objectStore('alerts');
    
    return new Promise((resolve, reject) => {
      const countRequest = store.count();
      
      countRequest.onsuccess = () => {
        resolve(countRequest.result);
      };
      
      countRequest.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
  
  /**
   * Sincroniza todos os alertas
   */
  async syncAlerts() {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Sincronizar alertas das áreas frequentes
      const frequentAreas = Array.from(this.usageData.frequentAreas.values())
        .map(data => data.area);
      
      const syncPromises = frequentAreas.map(area => this.syncAlertsInArea(area));
      await Promise.all(syncPromises);
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar todos os alertas:', error);
      return false;
    }
  }
  
  /**
   * Sincroniza alertas ao longo de uma rota
   */
  async syncAlertsAlongRoute(route) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Se não houver waypoints, usar apenas origem e destino
      const points = route.waypoints && route.waypoints.length > 0 ?
        route.waypoints :
        [route.origin, route.destination];
      
      // Processar em lotes para não sobrecarregar
      const pointBatches = this.chunkArray(points, 3);
      
      for (const batch of pointBatches) {
        const syncPromises = batch.map(point => {
          return this.syncAlertsInArea({
            latitude: point.latitude,
            longitude: point.longitude,
            radius: 5 // 5km ao redor de cada ponto
          });
        });
        
        await Promise.all(syncPromises);
      }
      
      return true;
    } catch (error) {
      console.error('Erro ao sincronizar alertas ao longo da rota:', error);
      return false;
    }
  }
  
  /**
   * Sincroniza uma rota específica
   */
  async syncRoute(route) {
    try {
      // Verificar se está online
      if (!this.connectionStatus.online) return false;
      
      // Em um sistema real, isso poderia envolver o download de dados da rota
      // do servidor, como instruções detalhadas, restrições, etc.
      
      // Armazenar no cache
      const db = await this.openDatabase();
      const transaction = db.transaction(['routes'], 'readwrite');
      const store = transaction.objectStore('routes');
      
      return new Promise((resolve, reject) => {
        const request = store.put({
          id: route.id || `${route.origin.latitude},${route.origin.longitude}_${route.destination.latitude},${route.destination.longitude}`,
          data: route,
          lastAccessed: Date.now(),
          isFrequent: this.isFrequentRoute(route),
          expiration: Date.now() + (30 * 24 * 60 * 60 * 1000) // 30 dias
        });
        
        request.onsuccess = () => {
          // Atualizar status do cache
          this.cacheStatus.routes.lastUpdate = new Date();
          this.cacheStatus.routes.count++;
          
          this.saveCacheStatus().then(() => resolve(true));
        };
        
        request.onerror = (event) => reject(event.target.error);
      });
    } catch (error) {
      console.error('Erro ao sincronizar rota:', error);
      return false;
    }
  }
  
  /**
   * Verifica se uma rota é frequente
   */
  isFrequentRoute(route) {
    const routeKey = `${route.origin.latitude.toFixed(2)},${route.origin.longitude.toFixed(2)}_${route.destination.latitude.toFixed(2)},${route.destination.longitude.toFixed(2)}`;
    
    return this.usageData.frequentRoutes.some(r => r.key === routeKey && r.count > 2);
  }
  
  /**
   * Busca um tile de mapa do cache
   */
  async getMapTile(zoom, x, y) {
    try {
      const tileId = `${zoom}/${x}/${y}`;
      
      // Verificar cache interno para acesso rápido
      if (this.mapTiles.has(tileId)) {
        const cachedTile = this.mapTiles.get(tileId);
        
        // Atualizar timestamp de acesso
        this.updateTileAccessTime(tileId);
        
        return cachedTile;
      }
      
      // Buscar do banco de dados
      const db = await this.openDatabase();
      const transaction = db.transaction(['mapTiles'], 'readwrite');
      const store = transaction.objectStore('mapTiles');
      
      return new Promise((resolve, reject) => {
        const request = store.get(tileId);
        
        request.onsuccess = (event) => {
          const tile = event.target.result;
          
          if (tile) {
            // Atualizar timestamp de acesso
            tile.lastAccessed = Date.now();
            store.put(tile);
            
            // Adicionar ao cache interno
            this.mapTiles.set(tileId, tile.data);
            
            resolve(tile.data);
          } else {
            resolve(null);
          }
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
    } catch (error) {
      console.error('Erro ao buscar tile do cache:', error);
      return null;
    }
  }
  
  /**
   * Atualiza o timestamp de acesso de um tile
   */
  async updateTileAccessTime(tileId) {
    try {
      const db = await this.openDatabase();
      const transaction = db.transaction(['mapTiles'], 'readwrite');
      const store = transaction.objectStore('mapTiles');
      
      const request = store.get(tileId);
      
      request.onsuccess = (event) => {
        const tile = event.target.result;
        
        if (tile) {
          tile.lastAccessed = Date.now();
          store.put(tile);
        }
      };
    } catch (error) {
      console.error('Erro ao atualizar timestamp de acesso do tile:', error);
    }
  }
  
  /**
   * Busca POIs em cache de uma área específica
   */
  async getCachedPOIsInArea(area, categories = null) {
    try {
      const db = await this.openDatabase();
      const transaction = db.transaction(['pois'], 'readonly');
      const store = transaction.objectStore('pois');
      
      // Buscar todos os POIs
      const allPOIs = await new Promise((resolve, reject) => {
        const request = store.getAll();
        
        request.onsuccess = (event) => {
          resolve(event.target.result);
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
      
      // Filtrar POIs por área e categoria
      const filteredPOIs = allPOIs.filter(poi => {
        // Verificar se está dentro da área
        const distance = this.calculateDistance(
          area.latitude,
          area.longitude,
          poi.data.latitude,
          poi.data.longitude
        );
        
        const isWithinArea = distance <= area.radius;
        
        // Verificar categoria, se especificada
        const matchesCategory = !categories || 
          categories.includes(poi.data.category);
        
        return isWithinArea && matchesCategory;
      });
      
      // Extrair apenas os dados dos POIs
      return filteredPOIs.map(poi => poi.data);
    } catch (error) {
      console.error('Erro ao buscar POIs em cache:', error);
      return [];
    }
  }
  
  /**
   * Calcula a distância entre dois pontos (Haversine)
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Raio da Terra em km
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c;
  }
  
  /**
   * Converte graus para radianos
   */
  toRad(value) {
    return value * Math.PI / 180;
  }
  
  /**
   * Busca alertas em cache de uma área específica
   */
  async getCachedAlertsInArea(area, types = null) {
    try {
      const db = await this.openDatabase();
      const transaction = db.transaction(['alerts'], 'readonly');
      const store = transaction.objectStore('alerts');
      
      // Buscar todos os alertas
      const allAlerts = await new Promise((resolve, reject) => {
        const request = store.getAll();
        
        request.onsuccess = (event) => {
          resolve(event.target.result);
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
      
      // Filtrar alertas por área, tipo e expiração
      const currentTime = Date.now();
      
      const filteredAlerts = allAlerts.filter(alert => {
        // Verificar expiração
        if (alert.expiration && alert.expiration < currentTime) {
          return false;
        }
        
        // Verificar se está dentro da área
        const distance = this.calculateDistance(
          area.latitude,
          area.longitude,
          alert.data.latitude,
          alert.data.longitude
        );
        
        const isWithinArea = distance <= area.radius;
        
        // Verificar tipo, se especificado
        const matchesType = !types || 
          types.includes(alert.data.type);
        
        return isWithinArea && matchesType;
      });
      
      // Extrair apenas os dados dos alertas
      return filteredAlerts.map(alert => alert.data);
    } catch (error) {
      console.error('Erro ao buscar alertas em cache:', error);
      return [];
    }
  }
  
  /**
   * Busca uma tradução em cache
   */
  async getCachedTranslation(language) {
    try {
      const db = await this.openDatabase();
      const transaction = db.transaction(['translations'], 'readonly');
      const store = transaction.objectStore('translations');
      
      return new Promise((resolve, reject) => {
        const request = store.get(language);
        
        request.onsuccess = (event) => {
          const translation = event.target.result;
          
          if (translation) {
            // Atualizar timestamp de acesso
            transaction.objectStore('translations').put({
              ...translation,
              lastAccessed: Date.now()
            });
            
            resolve(translation.data);
          } else {
            resolve(null);
          }
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
    } catch (error) {
      console.error(`Erro ao buscar tradução em cache para ${language}:`, error);
      return null;
    }
  }
  
  /**
   * Busca uma rota em cache
   */
  async getCachedRoute(originLat, originLon, destLat, destLon) {
    try {
      // Gerar ID da rota
      const routeId = `${originLat},${originLon}_${destLat},${destLon}`;
      
      // Verificar cache interno
      if (this.cachedRoutes.has(routeId)) {
        return this.cachedRoutes.get(routeId);
      }
      
      const db = await this.openDatabase();
      const transaction = db.transaction(['routes'], 'readwrite');
      const store = transaction.objectStore('routes');
      
      return new Promise((resolve, reject) => {
        const request = store.get(routeId);
        
        request.onsuccess = (event) => {
          const route = event.target.result;
          
          if (route) {
            // Atualizar timestamp de acesso
            route.lastAccessed = Date.now();
            store.put(route);
            
            // Adicionar ao cache interno
            this.cachedRoutes.set(routeId, route.data);
            
            resolve(route.data);
          } else {
            resolve(null);
          }
        };
        
        request.onerror = (event) => {
          reject(event.target.error);
        };
      });
    } catch (error) {
      console.error('Erro ao buscar rota em cache:', error);
      return null;
    }
  }
  
  /**
   * Obtém o status atual do cache offline
   */
  async getCacheStatus() {
    // Atualizar estatísticas de armazenamento
    await this.updateStorageStats();
    
    // Calcular tamanho total
    await this.calculateCacheSize();
    
    return {
      ...this.cacheStatus,
      storageQuota: this.storageQuota,
      connectionStatus: this.connectionStatus
    };
  }
  
  /**
   * Limpa todo o cache offline
   */
  async clearAllCache() {
    try {
      // Limpar cache interno
      this.mapTiles.clear();
      this.cachedRoutes.clear();
      
      // Cancelar downloads em andamento
      this.cancelAllDownloads();
      
      // Limpar banco de dados
      const db = await this.openDatabase();
      const stores = ['mapTiles', 'pois', 'routes', 'translations', 'alerts'];
      
      for (const storeName of stores) {
        await this.clearStore(db, storeName);
      }
      
      // Resetar status
      this.cacheStatus = {
        maps: {
          lastUpdate: null,
          size: 0,
          areas: []
        },
        pois: {
          lastUpdate: null,
          count: 0,
          categories: {}
        },
        translations: {
          lastUpdate: null,
          languages: []
        },
        routes: {
          lastUpdate: null,
          count: 0
        },
        alerts: {
          lastUpdate: null,
          count: 0
        },
        total: {
          size: 0,
          lastSync: null
        }
      };
      
      await this.saveCacheStatus();
      
      this.notifyObservers('cache', {
        type: 'clear',
        message: 'Todo o cache foi limpo'
      });
      
      return true;
    } catch (error) {
      console.error('Erro ao limpar cache:', error);
      return false;
    }
  }
  
  /**
   * Limpa um store específico
   */
  async clearStore(db, storeName) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.clear();
      
      request.onsuccess = () => {
        resolve(true);
      };
      
      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
}

export { OfflineCacheManager };