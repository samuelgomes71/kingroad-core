package com.kingroad.safety

import android.content.Context
import android.os.SystemClock
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kingroad.database.AppDatabase
import com.kingroad.model.DriverBreak
import com.kingroad.utils.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Date
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes

/**
 * Monitora o tempo de direção contínua e alerta o motorista sobre a necessidade de pausas
 * seguindo as regulamentações de transporte rodoviário.
 */
class DriverFatigueMonitor(
    private val context: Context,
    private val database: AppDatabase,
    private val preferenceManager: PreferenceManager
) {
    private val _drivingTimeStatus = MutableLiveData<DrivingTimeStatus>()
    val drivingTimeStatus: LiveData<DrivingTimeStatus> = _drivingTimeStatus

    private var drivingStartTime: Long = 0
    private var isMeasuring = false
    private var totalDrivingTime: Long = 0
    private var lastBreakTime: Long = 0

    // Limites configuráveis (podem ser ajustados por país/regulamentação)
    private val maxContinuousDrivingTime = 4.hours.inWholeMilliseconds
    private val requiredShortBreak = 30.minutes.inWholeMilliseconds
    private val maxDailyDrivingTime = 8.hours.inWholeMilliseconds
    
    init {
        // Carrega dados de condução anteriores da sessão atual
        loadDrivingData()
    }
    
    /**
     * Inicia a medição do tempo de condução
     */
    fun startDriving() {
        if (!isMeasuring) {
            if (drivingStartTime == 0L) {
                drivingStartTime = SystemClock.elapsedRealtime()
            }
            isMeasuring = true
            monitorDrivingTime()
        }
    }
    
    /**
     * Pausa a medição quando o veículo está parado
     */
    fun pauseDriving() {
        if (isMeasuring) {
            totalDrivingTime += SystemClock.elapsedRealtime() - drivingStartTime
            drivingStartTime = 0
            isMeasuring = false
            saveDrivingData()
        }
    }
    
    /**
     * Registra uma pausa do motorista
     */
    fun registerBreak(duration: Long) {
        lastBreakTime = SystemClock.elapsedRealtime()
        
        // Salva o registro da pausa no banco de dados
        CoroutineScope(Dispatchers.IO).launch {
            database.driverBreakDao().insert(
                DriverBreak(
                    timestamp = Date().time,
                    durationMs = duration,
                    latitude = 0.0, // Obter da localização atual
                    longitude = 0.0 // Obter da localização atual
                )
            )
        }
        
        updateDrivingStatus()
    }
    
    /**
     * Monitora continuamente o tempo de direção
     */
    private fun monitorDrivingTime() {
        CoroutineScope(Dispatchers.Default).launch {
            while (isMeasuring) {
                updateDrivingStatus()
                delay(60000) // Atualiza a cada minuto
            }
        }
    }
    
    /**
     * Atualiza o status do tempo de condução e verifica necessidade de alertas
     */
    private fun updateDrivingStatus() {
        val currentTime = SystemClock.elapsedRealtime()
        val currentDrivingSession = if (drivingStartTime > 0) currentTime - drivingStartTime else 0
        val totalTime = totalDrivingTime + currentDrivingSession
        
        // Tempo desde a última pausa
        val timeSinceLastBreak = if (lastBreakTime > 0) currentTime - lastBreakTime else totalTime
        
        val status = when {
            timeSinceLastBreak >= maxContinuousDrivingTime -> {
                DrivingTimeStatus.BREAK_REQUIRED
            }
            timeSinceLastBreak >= maxContinuousDrivingTime * 0.8 -> {
                DrivingTimeStatus.BREAK_RECOMMENDED
            }
            totalTime >= maxDailyDrivingTime -> {
                DrivingTimeStatus.DAILY_LIMIT_REACHED
            }
            totalTime >= maxDailyDrivingTime * 0.8 -> {
                DrivingTimeStatus.APPROACHING_DAILY_LIMIT
            }
            else -> {
                DrivingTimeStatus.OK
            }
        }
        
        _drivingTimeStatus.postValue(status)
    }
    
    /**
     * Salva os dados de condução para persistência
     */
    private fun saveDrivingData() {
        preferenceManager.saveLastDrivingSession(totalDrivingTime)
        preferenceManager.saveLastBreakTime(lastBreakTime)
    }
    
    /**
     * Carrega dados de condução anteriores
     */
    private fun loadDrivingData() {
        totalDrivingTime = preferenceManager.getLastDrivingSession()
        lastBreakTime = preferenceManager.getLastBreakTime()
    }
    
    /**
     * Reinicia contadores para um novo dia de trabalho
     */
    fun resetDaily() {
        totalDrivingTime = 0
        saveDrivingData()
    }
    
    /**
     * Status possíveis do tempo de condução
     */
    enum class DrivingTimeStatus {
        OK,
        BREAK_RECOMMENDED,
        BREAK_REQUIRED,
        APPROACHING_DAILY_LIMIT,
        DAILY_LIMIT_REACHED
    }
}