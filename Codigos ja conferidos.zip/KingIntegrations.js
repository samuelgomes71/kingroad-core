/**
 * KingIntegrations.js
 * 
 * Módulo responsável pela integração entre o KingRoad e outros aplicativos
 * da família King (KingSMS, KingLoc, KingChat, KingJob, KingMusic, 
 * KingScan, KingCargo).
 * 
 * Este módulo implementa APIs de comunicação entre aplicativos e
 * gerenciamento de dados compartilhados.
 */

import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

// Mapeamento dos aplicativos da família King
const KING_APPS = {
  KINGSMS: 'com.kingapps.kingsms',
  KINGLOC: 'com.kingapps.kingloc',
  KINGCHAT: 'com.kingapps.kingchat',
  KINGJOB: 'com.kingapps.kingjob',
  KINGMUSIC: 'com.kingapps.kingmusic',
  KINGSCAN: 'com.kingapps.kingscan',
  KINGCARGO: 'com.kingapps.kingcargo'
};

// Tipos de eventos para comunicação entre apps
export const EVENT_TYPES = {
  LOCATION_SHARED: 'location_shared',
  MESSAGE_RECEIVED: 'message_received',
  JOB_AVAILABLE: 'job_available', 
  CARGO_UPDATE: 'cargo_update',
  MUSIC_CONTROL: 'music_control',
  DOCUMENT_SCANNED: 'document_scanned',
  NAVIGATION_REQUEST: 'navigation_request'
};

// Classe para gerenciar integrações
class KingIntegrationsManager {
  constructor() {
    this.listeners = new Map();
    this.connectedApps = new Set();
    this.isInitialized = false;
    this.pendingMessages = [];
  }

  /**
   * Inicializa o gerenciador de integrações
   */
  async initialize() {
    if (this.isInitialized) return;

    try {
      // Registra o canal de comunicação
      if (window.KingBridge) {
        window.KingBridge.registerApp('com.kingapps.kingroad', this.handleIncomingMessage.bind(this));
      } else {
        // Fallback para comunicação via localStorage em ambientes web
        window.addEventListener('storage', this.handleStorageEvent.bind(this));
      }

      // Detecta apps instalados
      const installedApps = await this.detectInstalledApps();
      installedApps.forEach(app => this.connectedApps.add(app));

      this.isInitialized = true;
      
      // Processa mensagens pendentes
      this.processPendingMessages();
      
      console.log('KingIntegrations inicializado com sucesso');
    } catch (error) {
      console.error('Erro ao inicializar KingIntegrations:', error);
    }
  }

  /**
   * Detecta quais aplicativos da família King estão disponíveis
   */
  async detectInstalledApps() {
    const installedApps = [];

    if (window.KingBridge) {
      // Usando a API nativa
      try {
        const result = await window.KingBridge.getInstalledKingApps();
        return result || [];
      } catch (error) {
        console.error('Erro ao detectar apps instalados:', error);
        return [];
      }
    } else {
      // Fallback para web - simula com localStorage
      for (const appId of Object.values(KING_APPS)) {
        const isInstalled = localStorage.getItem(`kingapp_${appId}_installed`) === 'true';
        if (isInstalled) {
          installedApps.push(appId);
        }
      }
    }

    return installedApps;
  }

  /**
   * Processa mensagens recebidas via localStorage (fallback para web)
   */
  handleStorageEvent(event) {
    if (event.key && event.key.startsWith('kingapp_message_')) {
      try {
        const message = JSON.parse(event.newValue);
        this.handleIncomingMessage(message);
      } catch (error) {
        console.error('Erro ao processar mensagem do localStorage:', error);
      }
    }
  }

  /**
   * Processa mensagem recebida de outro app
   */
  handleIncomingMessage(message) {
    if (!message || !message.type || !message.source) {
      console.warn('Mensagem inválida recebida:', message);
      return;
    }

    if (!this.isInitialized) {
      // Armazena para processamento posterior
      this.pendingMessages.push(message);
      return;
    }

    // Notifica listeners registrados para este tipo de evento
    const listeners = this.listeners.get(message.type) || [];
    listeners.forEach(callback => {
      try {
        callback(message);
      } catch (error) {
        console.error(`Erro ao processar mensagem do tipo ${message.type}:`, error);
      }
    });
  }

  /**
   * Processa mensagens pendentes após inicialização
   */
  processPendingMessages() {
    while (this.pendingMessages.length > 0) {
      const message = this.pendingMessages.shift();
      this.handleIncomingMessage(message);
    }
  }

  /**
   * Envia mensagem para um aplicativo específico
   */
  async sendMessage(targetApp, type, data) {
    if (!this.isInitialized) {
      throw new Error('KingIntegrations não foi inicializado');
    }

    const message = {
      source: 'com.kingapps.kingroad',
      target: targetApp,
      type,
      data,
      timestamp: Date.now()
    };

    if (window.KingBridge) {
      // Usando a API nativa
      try {
        return await window.KingBridge.sendMessage(message);
      } catch (error) {
        console.error(`Erro ao enviar mensagem para ${targetApp}:`, error);
        throw error;
      }
    } else {
      // Fallback para web - usa localStorage
      const key = `kingapp_message_${targetApp}_${Date.now()}`;
      localStorage.setItem(key, JSON.stringify(message));
      // Remove depois de um tempo para evitar poluição
      setTimeout(() => localStorage.removeItem(key), 30000);
      return true;
    }
  }

  /**
   * Registra listener para um tipo específico de evento
   */
  addEventListener(eventType, callback) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType).push(callback);

    // Retorna função para remover o listener
    return () => this.removeEventListener(eventType, callback);
  }

  /**
   * Remove listener para um tipo específico de evento
   */
  removeEventListener(eventType, callback) {
    if (!this.listeners.has(eventType)) return;

    const listeners = this.listeners.get(eventType);
    const index = listeners.indexOf(callback);
    
    if (index !== -1) {
      listeners.splice(index, 1);
    }
  }

  /**
   * Verifica se um aplicativo específico está disponível
   */
  isAppAvailable(appId) {
    return this.connectedApps.has(appId);
  }

  /**
   * Abre outro aplicativo da família King
   */
  async openApp(appId, params = {}) {
    if (!this.isAppAvailable(appId)) {
      throw new Error(`Aplicativo ${appId} não está disponível`);
    }

    if (window.KingBridge) {
      try {
        return await window.KingBridge.openApp(appId, params);
      } catch (error) {
        console.error(`Erro ao abrir aplicativo ${appId}:`, error);
        throw error;
      }
    } else {
      // Simulação para ambiente web
      console.log(`Simulando abertura do app ${appId} com parâmetros:`, params);
      return true;
    }
  }

  /**
   * Compartilha dados com outro aplicativo
   */
  async shareData(appId, data) {
    return this.sendMessage(appId, 'shared_data', data);
  }
}

// Instância singleton
const kingIntegrationsManager = new KingIntegrationsManager();

/**
 * Hook para usar as integrações nos componentes React
 */
export const useKingIntegrations = () => {
  const [isReady, setIsReady] = useState(false);
  const [availableApps, setAvailableApps] = useState([]);
  const { t } = useTranslation();

  useEffect(() => {
    const initIntegrations = async () => {
      await kingIntegrationsManager.initialize();
      setIsReady(true);

      // Atualiza lista de apps disponíveis
      const apps = Array.from(kingIntegrationsManager.connectedApps);
      setAvailableApps(apps);
    };

    initIntegrations();
  }, []);

  // Funções específicas de integração para cada aplicativo

  // KingSMS - Integração para mensagens
  const sendSMS = async (phoneNumber, message) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGSMS)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingSMS' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGSMS, 'send_sms', { phoneNumber, message });
  };

  // KingLoc - Integração para compartilhamento de localização
  const shareLocation = async (location, duration) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGLOC)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingLoc' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGLOC, 'share_location', { location, duration });
  };

  // KingChat - Integração para chat entre motoristas
  const sendChatMessage = async (userId, message) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGCHAT)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingChat' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGCHAT, 'send_message', { userId, message });
  };

  // KingJob - Integração para ofertas de trabalho
  const checkAvailableJobs = async (filters) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGJOB)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingJob' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGJOB, 'request_jobs', filters);
  };

  // KingMusic - Integração para controle de música
  const controlMusic = async (command) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGMUSIC)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingMusic' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGMUSIC, 'music_control', command);
  };

  // KingScan - Integração para escaneamento de documentos
  const scanDocument = async (options) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGSCAN)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingScan' }));
    }
    
    return kingIntegrationsManager.openApp(KING_APPS.KINGSCAN, {
      action: 'scan',
      ...options
    });
  };

  // KingCargo - Integração para gestão de carga
  const updateCargoStatus = async (cargoId, status) => {
    if (!kingIntegrationsManager.isAppAvailable(KING_APPS.KINGCARGO)) {
      throw new Error(t('integrations.errors.appNotAvailable', { app: 'KingCargo' }));
    }
    
    return kingIntegrationsManager.sendMessage(KING_APPS.KINGCARGO, 'update_cargo', { cargoId, status });
  };

  // Registra para receber eventos de outro app
  const registerForEvents = (eventType, callback) => {
    return kingIntegrationsManager.addEventListener(eventType, callback);
  };

  // Funções genéricas
  const openKingApp = (appName) => {
    const appId = KING_APPS[appName.toUpperCase()];
    if (!appId) {
      throw new Error(t('integrations.errors.invalidApp', { app: appName }));
    }
    
    return kingIntegrationsManager.openApp(appId);
  };

  return {
    isReady,
    availableApps,
    sendSMS,
    shareLocation,
    sendChatMessage,
    checkAvailableJobs,
    controlMusic,
    scanDocument,
    updateCargoStatus,
    registerForEvents,
    openKingApp
  };
};

export default kingIntegrationsManager;