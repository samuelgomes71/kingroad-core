import React, { useState, useEffect } from 'react';
import { alertColors } from '../constants/alertColors';

const AlertTriangle = ({ type = 'warning', message = '', subMessage = '', onClose, fullScreen = false, autoClose = 0 }) => {
  const [visible, setVisible] = useState(true);
  
  const selectedColors = alertColors[type] || alertColors.warning;
  
  // Auto-fechar alerta após tempo definido
  useEffect(() => {
    if (autoClose > 0 && visible) {
      const timer = setTimeout(() => {
        setVisible(false);
        if (onClose) onClose();
      }, autoClose);
      
      return () => clearTimeout(timer);
    }
  }, [autoClose, visible, onClose]);
  
  // Manipulador de fechamento
  const handleClose = () => {
    setVisible(false);
    if (onClose) onClose();
  };
  
  if (!visible) return null;
  
  return (
    <div 
      className={`fixed z-50 ${fullScreen ? 'inset-0' : 'top-0 left-0 right-0'}`}
      style={{ 
        backgroundColor: selectedColors.background,
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className={`flex flex-col items-center justify-center ${fullScreen ? 'h-screen' : 'py-6'}`}>
        {/* Triângulo de alerta */}
        <div className="relative" style={{ width: fullScreen ? '200px' : '100px', height: fullScreen ? '200px' : '100px' }}>
          <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
            {/* Triângulo */}
            <path 
              d="M50,10 L90,90 L10,90 Z" 
              fill={selectedColors.triangle} 
            />
            
            {/* Símbolo de exclamação */}
            <path 
              d="M50,30 L50,60 L50,60 Z" 
              fill={selectedColors.symbol} 
              stroke={selectedColors.symbol} 
              strokeWidth="10" 
              strokeLinecap="round" 
            />
            <circle 
              cx="50" 
              cy="75" 
              r="5" 
              fill={selectedColors.symbol} 
            />
          </svg>
        </div>
        
        {/* Mensagem principal */}
        {message && (
          <div 
            className={`text-center mt-4 font-bold ${fullScreen ? 'text-3xl' : 'text-xl'}`}
            style={{ color: selectedColors.text }}
          >
            {message}
          </div>
        )}
        
        {/* Submensagem */}
        {subMessage && (
          <div 
            className={`text-center mt-2 ${fullScreen ? 'text-xl' : 'text-base'}`}
            style={{ color: selectedColors.text }}
          >
            {subMessage}
          </div>
        )}
        
        {/* Botão de fechamento */}
        {!fullScreen && (
          <button 
            onClick={handleClose}
            className="absolute top-3 right-3 text-2xl"
            style={{ color: selectedColors.text }}
          >
            &times;
          </button>
        )}
        
        {/* Botão de OK em alertas de tela cheia */}
        {fullScreen && (
          <button
            onClick={handleClose}
            className="mt-6 px-8 py-3 rounded-lg font-bold text-lg"
            style={{ 
              backgroundColor: selectedColors.triangle,
              color: selectedColors.background
            }}
          >
            OK
          </button>
        )}
      </div>
    </div>
  );
};

export default AlertTriangle;