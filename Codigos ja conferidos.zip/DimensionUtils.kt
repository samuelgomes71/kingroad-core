// DimensionUtils.kt
package com.kingroad.utils

import android.content.Context
import android.util.DisplayMetrics

/**
 * Utilitário para conversão de dimensões
 */
object DimensionUtils {
    /**
     * Converte densidade de pixels (dp) para pixels (px)
     * @param context Contexto da aplicação
     * @param dp Valor em dp a ser convertido
     * @return Valor equivalente em pixels
     */
    fun dpToPx(context: Context, dp: Float): Float {
        return dp * (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)
    }

    /**
     * Converte pixels (px) para densidade de pixels (dp)
     * @param context Contexto da aplicação
     * @param px Valor em pixels a ser convertido
     * @return Valor equivalente em dp
     */
    fun pxToDp(context: Context, px: Float): Float {
        return px / (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)
    }
    
    /**
     * Obtém a largura da tela em pixels
     * @param context Contexto da aplicação
     * @return Largura da tela em pixels
     */
    fun getScreenWidth(context: Context): Int {
        return context.resources.displayMetrics.widthPixels
    }
    
    /**
     * Obtém a altura da tela em pixels
     * @param context Contexto da aplicação
     * @return Altura da tela em pixels
     */
    fun getScreenHeight(context: Context): Int {
        return context.resources.displayMetrics.heightPixels
    }
}