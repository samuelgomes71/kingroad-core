import React, { useState } from 'react';
import { Map, AlertTriangle, Truck, Scissors, Wind, Filter, List, MapPin } from 'lucide-react';

// Componente SecurityAlertPOI incorporado diretamente neste arquivo
const SecurityAlertPOI = ({ 
  alertType, 
  location, 
  timestamp, 
  reportCount, 
  description,
  comments = []
}) => {
  const [expanded, setExpanded] = useState(false);
  
  // Definir ícone e cor com base no tipo de alerta
  const getAlertIcon = () => {
    switch (alertType) {
      case 'cargo_theft':
        return <Truck className="text-red-500" size={24} />;
      case 'curtain_cutting':
        return <Scissors className="text-amber-500" size={24} />;
      case 'gas_attack':
        return <Wind className="text-purple-500" size={24} />;
      default:
        return <AlertTriangle className="text-yellow-500" size={24} />;
    }
  };
  
  // Obter título baseado no tipo de alerta
  const getAlertTitle = () => {
    switch (alertType) {
      case 'cargo_theft':
        return 'Roubo de Carga';
      case 'curtain_cutting':
        return 'Corte de Lona';
      case 'gas_attack':
        return 'Ataque com Gás Sonífero';
      default:
        return 'Alerta de Segurança';
    }
  };
  
  // Obter recomendação específica para o tipo de alerta
  const getAlertRecommendation = () => {
    switch (alertType) {
      case 'curtain_cutting':
        return 'Neste local há probabilidade de cortarem a lona do seu trailer. Se você estiver vazio ou carregado com objetos grandes e pesados, considere deixar as portas do trailer abertas para que os ladrões vejam e não cortem a lona.';
      case 'cargo_theft':
        return 'Este local é conhecido por roubos de carga. Recomenda-se estacionar em áreas iluminadas, próximo a outros veículos e manter contato com outros motoristas.';
      case 'gas_attack':
        return 'Esta área possui relatos de ataques com gás sonífero. Mantenha janelas fechadas, use travas adicionais nas portas e considere um detector de gás na cabine.';
      default:
        return 'Tenha cuidado nesta área. Reporte qualquer atividade suspeita.';
    }
  };
  
  // Definir cor de fundo com base no tipo de alerta
  const getBackgroundColor = () => {
    switch (alertType) {
      case 'cargo_theft':
        return 'bg-red-900 border-red-600';
      case 'curtain_cutting':
        return 'bg-amber-900 border-amber-600';
      case 'gas_attack':
        return 'bg-purple-900 border-purple-600';
      default:
        return 'bg-yellow-900 border-yellow-600';
    }
  };
  
  // Formatar a data
  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };
  
  return (
    <div 
      className={`rounded-lg p-4 text-white border ${getBackgroundColor()} shadow-lg max-w-md`}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-center justify-between cursor-pointer">
        <div className="flex items-center space-x-3">
          {getAlertIcon()}
          <div>
            <h3 className="font-bold text-lg">{getAlertTitle()}</h3>
            <p className="text-sm opacity-80">{location}</p>
          </div>
        </div>
        <div className="text-right">
          <span className="bg-black bg-opacity-50 px-2 py-1 rounded-full text-xs">
            {reportCount} {reportCount === 1 ? 'relato' : 'relatos'}
          </span>
        </div>
      </div>
      
      {expanded && (
        <div className="mt-4 border-t border-white border-opacity-20 pt-3">
          <p className="mb-2">{description}</p>
          <p className="text-xs opacity-70 mb-4">Último relato: {formatDate(timestamp)}</p>
          
          {/* Recomendação para o tipo de alerta */}
          <div className="bg-black bg-opacity-40 p-3 rounded-lg mb-3 border-l-4 border-yellow-500">
            <h4 className="font-semibold mb-1 text-yellow-400">Recomendação:</h4>
            <p className="text-sm">{getAlertRecommendation()}</p>
          </div>
          
          {comments.length > 0 && (
            <div className="mt-2">
              <h4 className="font-semibold mb-2">Comentários de Motoristas:</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {comments.map((comment, index) => (
                  <div key={index} className="bg-black bg-opacity-30 p-2 rounded text-sm">
                    <div className="flex justify-between items-start">
                      <span className="font-medium">{comment.author}</span>
                      <span className="text-xs opacity-70">{formatDate(comment.timestamp)}</span>
                    </div>
                    <p>{comment.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <button className="mt-3 bg-black bg-opacity-40 hover:bg-opacity-60 transition-all duration-200 rounded px-4 py-2 text-sm font-medium w-full">
            Adicionar Comentário
          </button>
        </div>
      )}
    </div>
  );
};

const SecurityAlertsMap = () => {
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [viewMode, setViewMode] = useState('map'); // 'map' or 'list'
  
  // Dados de exemplo para demonstração
  const sampleAlerts = [
    {
      id: 1,
      alertType: 'cargo_theft',
      location: 'A1 Highway, próximo a Dover, Inglaterra',
      coordinates: { lat: 51.1279, lng: 1.3134 },
      timestamp: new Date('2024-03-01T22:15:00').getTime(),
      reportCount: 5,
      description: 'Área conhecida por roubo de carga. Vários caminhões foram roubados enquanto os motoristas dormiam.',
      comments: [
        { 
          author: 'João Silva', 
          timestamp: new Date('2024-03-01T23:30:00').getTime(),
          text: 'Tive minha carga de eletrônicos roubada aqui há duas semanas. Evitem pernoitar neste local.'
        },
        { 
          author: 'Maria Oliveira', 
          timestamp: new Date('2024-02-28T14:15:00').getTime(),
          text: 'Há câmeras de segurança na área, mas parecem não funcionar. As autoridades foram pouco prestativas.'
        }
      ]
    },
    {
      id: 2,
      alertType: 'curtain_cutting',
      location: 'Área de descanso na A16, Norte da França',
      coordinates: { lat: 50.9513, lng: 1.8587 },
      timestamp: new Date('2024-03-03T03:45:00').getTime(),
      reportCount: 3,
      description: 'Ladrões cortam lona de siders durante a noite. Motoristas relatam cortes em formato de L para verificar o conteúdo da carga.',
      comments: [
        { 
          author: 'Carlos Mendes', 
          timestamp: new Date('2024-03-03T06:20:00').getTime(),
          text: 'Acordei com a lona cortada. Por sorte não levaram nada pois a carga não era de valor.'
        }
      ]
    },
    {
      id: 3,
      alertType: 'gas_attack',
      location: 'Posto de combustível próximo a Milão, Itália',
      coordinates: { lat: 45.4642, lng: 9.1900 },
      timestamp: new Date('2024-02-28T01:30:00').getTime(),
      reportCount: 7,
      description: 'Relatos de uso de gás sonífero injetado nas cabines. Motoristas acordam sem lembrar o que aconteceu e com pertences roubados.',
      comments: [
        { 
          author: 'Roberto Almeida', 
          timestamp: new Date('2024-02-28T08:15:00').getTime(),
          text: 'Acordei com forte dor de cabeça e náuseas. Minha carteira e celular foram roubados.'
        },
        { 
          author: 'Ana Costa', 
          timestamp: new Date('2024-02-25T11:30:00').getTime(),
          text: 'Use uma trava adicional na porta da cabine. Fiquei sabendo que isso pode dificultar a entrada dos ladrões.'
        },
        { 
          author: 'Marcelo Santos', 
          timestamp: new Date('2024-02-20T19:45:00').getTime(),
          text: 'Companhias de seguro estão começando a pedir sistemas anti-gás nas cabines nesta região.'
        }
      ]
    }
  ];
  
  // Filtrar alertas com base no tipo selecionado
  const filteredAlerts = filterType === 'all' 
    ? sampleAlerts 
    : sampleAlerts.filter(alert => alert.alertType === filterType);
  
  // Simular a seleção de um alerta no mapa (em um app real, isso seria feito com um mapa interativo)
  const handleMapPointClick = (alertId) => {
    const alert = sampleAlerts.find(a => a.id === alertId);
    setSelectedAlert(alert);
  };
  
  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header com controles de filtro e mudança de visualização */}
      <div className="p-4 bg-black bg-opacity-40 border-b border-gray-800 flex justify-between items-center">
        <h2 className="text-xl font-bold flex items-center">
          <AlertTriangle className="mr-2 text-yellow-500" size={24} />
          Alertas de Segurança
        </h2>
        
        <div className="flex space-x-4">
          {/* Filtros de tipo de alerta */}
          <div className="flex items-center space-x-2">
            <Filter size={18} />
            <select 
              className="bg-gray-800 border border-gray-700 rounded py-1 px-2 text-sm"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="all">Todos os Alertas</option>
              <option value="cargo_theft">Roubo de Carga</option>
              <option value="curtain_cutting">Corte de Lona</option>
              <option value="gas_attack">Ataque com Gás</option>
            </select>
          </div>
          
          {/* Toggle entre mapa e lista */}
          <div className="flex bg-gray-800 rounded">
            <button 
              className={`px-3 py-1 flex items-center ${viewMode === 'map' ? 'bg-blue-900 text-blue-200' : ''}`}
              onClick={() => setViewMode('map')}
            >
              <Map size={18} className="mr-1" />
              <span className="text-sm">Mapa</span>
            </button>
            <button 
              className={`px-3 py-1 flex items-center ${viewMode === 'list' ? 'bg-blue-900 text-blue-200' : ''}`}
              onClick={() => setViewMode('list')}
            >
              <List size={18} className="mr-1" />
              <span className="text-sm">Lista</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Conteúdo principal - Mapa ou Lista */}
      <div className="flex-1 relative">
        {viewMode === 'map' ? (
          /* Simulação do mapa - em um app real, usaria um componente de mapa como react-map-gl ou Google Maps */
          <div className="bg-gray-800 h-full relative p-4">
            <div className="absolute inset-0 flex items-center justify-center opacity-50">
              <span className="text-xl">Mapa de Alertas</span>
            </div>
            
            {/* Pontos simulados no mapa */}
            <div className="absolute left-1/4 top-1/3" onClick={() => handleMapPointClick(1)}>
              <div className="relative cursor-pointer">
                <Truck className="text-red-500" size={24} />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-xs flex items-center justify-center">
                  5
                </div>
              </div>
            </div>
            
            <div className="absolute left-1/3 top-1/4" onClick={() => handleMapPointClick(2)}>
              <div className="relative cursor-pointer">
                <Scissors className="text-amber-500" size={24} />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full text-xs flex items-center justify-center">
                  3
                </div>
              </div>
            </div>
            
            <div className="absolute right-1/3 bottom-1/3" onClick={() => handleMapPointClick(3)}>
              <div className="relative cursor-pointer">
                <Wind className="text-purple-500" size={24} />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-purple-500 rounded-full text-xs flex items-center justify-center">
                  7
                </div>
              </div>
            </div>
            
            {/* Legenda */}
            <div className="absolute bottom-4 left-4 bg-black bg-opacity-70 p-3 rounded">
              <h4 className="text-sm font-semibold mb-2">Legenda:</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <Truck className="text-red-500 mr-2" size={16} />
                  <span>Roubo de Carga</span>
                </div>
                <div className="flex items-center">
                  <Scissors className="text-amber-500 mr-2" size={16} />
                  <span>Corte de Lona</span>
                </div>
                <div className="flex items-center">
                  <Wind className="text-purple-500 mr-2" size={16} />
                  <span>Ataque com Gás</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Visualização em Lista */
          <div className="overflow-y-auto h-full p-4 space-y-4 bg-gray-900">
            {filteredAlerts.map(alert => (
              <div key={alert.id} onClick={() => setSelectedAlert(alert)}>
                <SecurityAlertPOI {...alert} />
              </div>
            ))}
            
            {filteredAlerts.length === 0 && (
              <div className="flex flex-col items-center justify-center h-40 text-gray-400">
                <AlertTriangle size={32} className="mb-2" />
                <p>Nenhum alerta encontrado com os filtros atuais</p>
              </div>
            )}
          </div>
        )}
        
        {/* Detalhes do alerta selecionado */}
        {selectedAlert && viewMode === 'map' && (
          <div className="absolute bottom-4 right-4 max-w-md">
            <div className="relative">
              <SecurityAlertPOI {...selectedAlert} />
              <button 
                className="absolute -top-2 -right-2 bg-gray-800 rounded-full w-6 h-6 flex items-center justify-center"
                onClick={() => setSelectedAlert(null)}
              >
                ✕
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Botão de adicionar novo alerta */}
      <div className="absolute bottom-6 right-6">
        <button className="bg-amber-600 hover:bg-amber-700 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg">
          <MapPin size={24} />
        </button>
      </div>
    </div>
  );
};

export default SecurityAlertsMap;