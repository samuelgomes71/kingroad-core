import React from 'react';

const SatelliteViewControls = ({ onZoomChange, onTiltChange, currentMode }) => {
  const isSatelliteMode = ['satellite', 'hybrid'].includes(currentMode);
  
  if (!isSatelliteMode) return null;
  
  return (
    <div className="absolute left-4 bottom-24 z-10">
      <div className="bg-white bg-opacity-80 rounded-lg shadow-lg p-3">
        <div className="mb-3">
          <label className="text-xs text-gray-700 block mb-1">Zoom</label>
          <input 
            type="range" 
            min="12" 
            max="22" 
            defaultValue="18"
            onChange={(e) => onZoomChange(Number(e.target.value))}
            className="w-32"
          />
        </div>
        
        <div>
          <label className="text-xs text-gray-700 block mb-1">Inclinação</label>
          <input 
            type="range" 
            min="0" 
            max="60" 
            defaultValue="0"
            onChange={(e) => onTiltChange(Number(e.target.value))}
            className="w-32"
          />
        </div>
      </div>
    </div>
  );
};

export default SatelliteViewControls;