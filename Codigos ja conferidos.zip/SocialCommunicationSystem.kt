// Sistema de Comunicação e Rastreamento
// app/src/main/kotlin/com/kingroad/social

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

// Entidades principais
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val chatId: String,
    val senderId: String,
    val type: MessageType,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT,
    val location: Location? = null
)

enum class MessageType {
    TEXT,
    AUDIO,
    VIDEO,
    LOCATION,
    TRUCK_STOP_INFO,
    SCALE_INFO,
    ROUTE_SHARE,
    CONVOY_INVITATION
}

enum class MessageStatus {
    SENT,
    DELIVERED,
    READ
}

@Entity(tableName = "chats")
data class Chat(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val type: ChatType,
    val name: String?,
    val participants: List<String>,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ChatType {
    INDIVIDUAL,
    GROUP,
    CONVOY,
    ROUTE_GROUP
}

// Sistema de Rastreamento
data class TrackingInfo(
    val userId: String,
    val location: Location,
    val speed: Float,
    val heading: Float,
    val status: DriverStatus,
    val timestamp: Long = System.currentTimeMillis()
)

enum class DriverStatus {
    DRIVING,
    RESTING,
    OFF_DUTY,
    ON_BREAK
}

// Gerenciador de Mensagens
class MessageManager(
    private val database: LocalDatabase,
    private val messageService: MessageService,
    private val encryptionService: EncryptionService
) {
    suspend fun sendMessage(chatId: String, content: String, type: MessageType) {
        val message = Message(
            chatId = chatId,
            senderId = getCurrentUserId(),
            type = type,
            content = encryptionService.encrypt(content)
        )
        
        database.saveMessage(message)
        messageService.sendMessage(message)
    }
    
    suspend fun sendAudioMessage(chatId: String, audioFile: ByteArray) {
        val encryptedAudio = encryptionService.encryptFile(audioFile)
        val uploadedUrl = messageService.uploadAudio(encryptedAudio)
        
        sendMessage(chatId, uploadedUrl, MessageType.AUDIO)
    }
    
    suspend fun sendVideoMessage(chatId: String, videoFile: ByteArray) {
        val encryptedVideo = encryptionService.encryptFile(videoFile)
        val uploadedUrl = messageService.uploadVideo(encryptedVideo)
        
        sendMessage(chatId, uploadedUrl, MessageType.VIDEO)
    }
    
    fun getMessages(chatId: String): Flow<List<Message>> {
        return database.getMessagesForChat(chatId)
    }
}

// Gerenciador de Rastreamento
class TrackingManager(
    private val database: LocalDatabase,
    private val locationService: LocationService,
    private val trackingService: TrackingService
) {
    private var currentGroup: String? = null
    
    fun startTracking(groupId: String) {
        currentGroup = groupId
        locationService.startLocationUpdates { location ->
            val trackingInfo = TrackingInfo(
                userId = getCurrentUserId(),
                location = location,
                speed = location.speed,
                heading = location.bearing,
                status = calculateDriverStatus()
            )
            
            trackingService.updateLocation(trackingInfo)
            database.saveTrackingInfo(trackingInfo)
        }
    }
    
    fun stopTracking() {
        locationService.stopLocationUpdates()
        currentGroup = null
    }
    
    fun getGroupMembers(groupId: String): Flow<List<TrackingInfo>> {
        return database.getGroupTrackingInfo(groupId)
    }
}

// Sistema de Comboio (Convoy)
class ConvoyManager(
    private val messageManager: MessageManager,
    private val trackingManager: TrackingManager
) {
    suspend fun createConvoy(name: String, route: Route): String {
        val chat = Chat(
            type = ChatType.CONVOY,
            name = name,
            participants = listOf(getCurrentUserId())
        )
        
        database.saveChat(chat)
        trackingManager.startTracking(chat.id)
        
        return chat.id
    }
    
    suspend fun joinConvoy(convoyId: String) {
        val chat = database.getChat(convoyId)
        if (chat?.type == ChatType.CONVOY) {
            database.addParticipantToChat(convoyId, getCurrentUserId())
            trackingManager.startTracking(convoyId)
            
            messageManager.sendMessage(
                chatId = convoyId,
                content = "Joined the convoy",
                type = MessageType.TEXT
            )
        }
    }
}

// Interface do banco de dados para recursos sociais
interface SocialDatabase {
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp DESC")
    fun getMessagesForChat(chatId: String): Flow<List<Message>>
    
    @Query("SELECT * FROM chats WHERE id = :chatId")
    suspend fun getChat(chatId: String): Chat?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMessage(message: Message)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveChat(chat: Chat)
    
    suspend fun addParticipantToChat(chatId: String, userId: String)
    
    suspend fun saveTrackingInfo(trackingInfo: TrackingInfo)
    
    fun getGroupTrackingInfo(groupId: String): Flow<List<TrackingInfo>>
}